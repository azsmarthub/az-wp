<?php
/**
 * AffiliateCMS AI - Dashboard Page
 */

declare(strict_types=1);

namespace AffiliateCMS\AI\Admin;

class DashboardPage
{
    /**
     * Render the AI dashboard page
     */
    public function render(): void
    {
        ?>
        <div class="wrap acms-admin">
            <!-- Header -->
            <div class="acms-page-header">
                <div class="acms-page-header__title">
                    <h1><?php esc_html_e('AI Dashboard', 'affiliatecms-ai'); ?></h1>
                    <span class="acms-badge acms-badge--primary">v<?php echo esc_html(ACMS_AI_VERSION); ?></span>
                </div>

                <div class="acms-page-header__actions">
                    <a href="<?php echo esc_url(admin_url('admin.php?page=acms-ai-settings')); ?>" class="acms-btn acms-btn--secondary">
                        <i class="bi bi-gear"></i>
                        <?php esc_html_e('Settings', 'affiliatecms-ai'); ?>
                    </a>
                </div>
            </div>

            <div class="acms-ai-dashboard" x-data="aiDashboard">
                <!-- Main Content -->
                <div class="acms-ai-dashboard__main">
                    <!-- Stats Cards -->
                    <div class="acms-stats-grid">
                        <div class="acms-stat-card">
                            <div class="acms-stat-card__header">
                                <div class="acms-stat-card__icon acms-stat-card__icon--primary">
                                    <i class="bi bi-currency-dollar"></i>
                                </div>
                            </div>
                            <div class="acms-stat-card__value" x-text="formatCurrency(stats.currentSpend)">$0.00</div>
                            <div class="acms-stat-card__label"><?php esc_html_e('This Month', 'affiliatecms-ai'); ?></div>
                        </div>

                        <div class="acms-stat-card">
                            <div class="acms-stat-card__header">
                                <div class="acms-stat-card__icon acms-stat-card__icon--success">
                                    <i class="bi bi-check-circle"></i>
                                </div>
                            </div>
                            <div class="acms-stat-card__value" x-text="formatNumber(stats.completedJobs)">0</div>
                            <div class="acms-stat-card__label"><?php esc_html_e('Completed Jobs', 'affiliatecms-ai'); ?></div>
                        </div>

                        <div class="acms-stat-card">
                            <div class="acms-stat-card__header">
                                <div class="acms-stat-card__icon acms-stat-card__icon--warning">
                                    <i class="bi bi-hourglass-split"></i>
                                </div>
                            </div>
                            <div class="acms-stat-card__value" x-text="formatNumber(stats.pendingJobs)">0</div>
                            <div class="acms-stat-card__label"><?php esc_html_e('Pending Jobs', 'affiliatecms-ai'); ?></div>
                        </div>

                        <div class="acms-stat-card">
                            <div class="acms-stat-card__header">
                                <div class="acms-stat-card__icon">
                                    <i class="bi bi-lightning"></i>
                                </div>
                            </div>
                            <div class="acms-stat-card__value" x-text="formatNumber(stats.tokensUsed)">0</div>
                            <div class="acms-stat-card__label"><?php esc_html_e('Tokens Used', 'affiliatecms-ai'); ?></div>
                        </div>
                    </div>

                    <!-- Jobs Queue -->
                    <?php $this->renderJobsQueue(); ?>
                </div>

                <!-- Sidebar -->
                <div class="acms-ai-dashboard__sidebar">
                    <!-- Budget Card -->
                    <div class="acms-card">
                        <div class="acms-card__header">
                            <h3 class="acms-card__title">
                                <i class="bi bi-wallet2"></i>
                                <?php esc_html_e('Budget', 'affiliatecms-ai'); ?>
                            </h3>
                        </div>
                        <div class="acms-card__body">
                            <div class="acms-ai-usage">
                                <div class="acms-ai-usage__meter">
                                    <div class="acms-ai-usage__header">
                                        <span class="acms-ai-usage__label"><?php esc_html_e('Monthly Budget', 'affiliatecms-ai'); ?></span>
                                        <span class="acms-ai-usage__value">
                                            <span x-text="formatCurrency(stats.currentSpend)">$0</span>
                                            /
                                            <span x-text="formatCurrency(stats.monthlyBudget)">$50</span>
                                        </span>
                                    </div>
                                    <div class="acms-ai-usage__bar">
                                        <div
                                            class="acms-ai-usage__progress"
                                            :class="budgetProgressClass"
                                            :style="`width: ${budgetPercentage}%`"
                                        ></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Usage by Provider -->
                    <div class="acms-card">
                        <div class="acms-card__header">
                            <h3 class="acms-card__title">
                                <i class="bi bi-pie-chart"></i>
                                <?php esc_html_e('Usage by Provider', 'affiliatecms-ai'); ?>
                            </h3>
                        </div>
                        <div class="acms-card__body">
                            <div class="acms-ai-cost">
                                <template x-for="usage in usageByProvider" :key="usage.provider + usage.model">
                                    <div class="acms-ai-cost__item">
                                        <div class="acms-ai-cost__provider">
                                            <div class="acms-ai-cost__icon" :class="'acms-ai-cost__icon--' + usage.provider">
                                                <i class="bi bi-robot"></i>
                                            </div>
                                            <div>
                                                <div class="acms-ai-cost__name" x-text="usage.model"></div>
                                                <div class="acms-ai-cost__model" x-text="formatNumber(usage.requests) + ' requests'"></div>
                                            </div>
                                        </div>
                                        <div class="acms-ai-cost__amount" x-text="formatCurrency(usage.cost)">$0</div>
                                    </div>
                                </template>

                                <!-- Empty state -->
                                <div class="acms-empty" x-show="usageByProvider.length === 0" style="padding: 24px;">
                                    <div class="acms-empty__text"><?php esc_html_e('No usage data yet', 'affiliatecms-ai'); ?></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Quick Actions -->
                    <div class="acms-card">
                        <div class="acms-card__header">
                            <h3 class="acms-card__title">
                                <i class="bi bi-lightning"></i>
                                <?php esc_html_e('Quick Actions', 'affiliatecms-ai'); ?>
                            </h3>
                        </div>
                        <div class="acms-card__body">
                            <div style="display: flex; flex-direction: column; gap: 8px;">
                                <a href="<?php echo esc_url(admin_url('admin.php?page=acms-ai-settings')); ?>" class="acms-btn acms-btn--secondary acms-btn--block">
                                    <i class="bi bi-gear"></i>
                                    <?php esc_html_e('Configure AI Settings', 'affiliatecms-ai'); ?>
                                </a>
                                <button class="acms-btn acms-btn--secondary acms-btn--block" @click="loadStats()">
                                    <i class="bi bi-arrow-clockwise"></i>
                                    <?php esc_html_e('Refresh Stats', 'affiliatecms-ai'); ?>
                                </button>
                                <button class="acms-btn acms-btn--secondary acms-btn--block" @click="resetStuckJobs()" :disabled="resettingJobs">
                                    <i class="bi" :class="resettingJobs ? 'bi-arrow-clockwise acms-spin' : 'bi-arrow-counterclockwise'"></i>
                                    <?php esc_html_e('Reset Stuck Jobs', 'affiliatecms-ai'); ?>
                                </button>
                                <button class="acms-btn acms-btn--secondary acms-btn--block" @click="rescheduleAs()" :disabled="reschedulingAs">
                                    <i class="bi" :class="reschedulingAs ? 'bi-arrow-clockwise acms-spin' : 'bi-calendar-event'"></i>
                                    <?php esc_html_e('Reschedule AS', 'affiliatecms-ai'); ?>
                                </button>
                                <button class="acms-btn acms-btn--secondary acms-btn--block" @click="debugQueue()" :disabled="debugging">
                                    <i class="bi" :class="debugging ? 'bi-arrow-clockwise acms-spin' : 'bi-bug'"></i>
                                    <?php esc_html_e('Debug Queue', 'affiliatecms-ai'); ?>
                                </button>
                            </div>

                            <!-- Debug Output -->
                            <div x-show="debugOutput" x-cloak style="margin-top: 12px; max-height: 300px; overflow: auto;">
                                <pre style="font-size: 11px; background: #f5f5f5; padding: 10px; border-radius: 4px; white-space: pre-wrap;" x-text="debugOutput"></pre>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Render jobs queue section
     */
    private function renderJobsQueue(): void
    {
        ?>
        <div class="acms-card" x-data="aiJobs">
            <div class="acms-card__header">
                <h3 class="acms-card__title">
                    <i class="bi bi-list-task"></i>
                    <?php esc_html_e('Recent Jobs', 'affiliatecms-ai'); ?>
                </h3>
                <div class="acms-card__actions">
                    <button class="acms-btn acms-btn--ghost acms-btn--sm" @click="loadJobs()">
                        <i class="bi bi-arrow-clockwise"></i>
                    </button>
                </div>
            </div>

            <!-- Filters -->
            <div class="acms-toolbar">
                <div class="acms-toolbar__group">
                    <button
                        class="acms-btn acms-btn--sm"
                        :class="statusFilter === '' ? 'acms-btn--primary' : 'acms-btn--secondary'"
                        @click="filterByStatus('')"
                    >
                        <?php esc_html_e('All', 'affiliatecms-ai'); ?>
                    </button>
                    <button
                        class="acms-btn acms-btn--sm"
                        :class="statusFilter === 'pending' ? 'acms-btn--primary' : 'acms-btn--secondary'"
                        @click="filterByStatus('pending')"
                    >
                        <?php esc_html_e('Pending', 'affiliatecms-ai'); ?>
                    </button>
                    <button
                        class="acms-btn acms-btn--sm"
                        :class="statusFilter === 'processing' ? 'acms-btn--primary' : 'acms-btn--secondary'"
                        @click="filterByStatus('processing')"
                    >
                        <?php esc_html_e('Processing', 'affiliatecms-ai'); ?>
                    </button>
                    <button
                        class="acms-btn acms-btn--sm"
                        :class="statusFilter === 'completed' ? 'acms-btn--primary' : 'acms-btn--secondary'"
                        @click="filterByStatus('completed')"
                    >
                        <?php esc_html_e('Completed', 'affiliatecms-ai'); ?>
                    </button>
                    <button
                        class="acms-btn acms-btn--sm"
                        :class="statusFilter === 'failed' ? 'acms-btn--primary' : 'acms-btn--secondary'"
                        @click="filterByStatus('failed')"
                    >
                        <?php esc_html_e('Failed', 'affiliatecms-ai'); ?>
                    </button>
                </div>

                <div class="acms-toolbar__separator"></div>

                <div class="acms-toolbar__group">
                    <select class="acms-select" @change="filterByType($event.target.value)">
                        <option value=""><?php esc_html_e('All Types', 'affiliatecms-ai'); ?></option>
                        <option value="enhance_asin"><?php esc_html_e('Enhance ASIN', 'affiliatecms-ai'); ?></option>
                        <option value="optimize_review"><?php esc_html_e('Optimize Review', 'affiliatecms-ai'); ?></option>
                        <option value="generate_category"><?php esc_html_e('Generate Category', 'affiliatecms-ai'); ?></option>
                    </select>
                </div>

                <div class="acms-toolbar__separator"></div>

                <div class="acms-toolbar__group">
                    <input type="search" class="acms-input acms-input--sm" placeholder="<?php esc_attr_e('Search jobs...', 'affiliatecms-ai'); ?>"
                           x-model="searchQuery" @input="onSearchInput()" style="width: 200px;">
                </div>
            </div>

            <div class="acms-card__body acms-card__body--flush">
                <!-- Loading State -->
                <div class="acms-loading" x-show="loading && jobs.length === 0">
                    <i class="bi bi-arrow-clockwise acms-loading__spinner"></i>
                    <span><?php esc_html_e('Loading jobs...', 'affiliatecms-ai'); ?></span>
                </div>

                <!-- Empty State -->
                <div class="acms-empty" x-show="!loading && jobs.length === 0">
                    <div class="acms-empty__icon">
                        <i class="bi bi-inbox"></i>
                    </div>
                    <div class="acms-empty__title"><?php esc_html_e('No jobs found', 'affiliatecms-ai'); ?></div>
                    <div class="acms-empty__text"><?php esc_html_e('AI jobs will appear here once triggered', 'affiliatecms-ai'); ?></div>
                </div>

                <!-- Jobs List -->
                <div class="acms-ai-jobs" x-show="jobs.length > 0">
                    <template x-for="job in jobs" :key="job.id">
                        <div class="acms-ai-job">
                            <!-- Status Indicator -->
                            <div class="acms-ai-job__status" :class="'acms-ai-job__status--' + job.status"></div>

                            <!-- Job Info -->
                            <div class="acms-ai-job__info">
                                <div class="acms-ai-job__title" x-text="getTypeLabel(job.type) + ' - ' + job.target_id"></div>
                                <div class="acms-ai-job__meta">
                                    <span x-text="job.model || 'Pending'"></span>
                                    <span>&bull;</span>
                                    <span x-text="formatTimeAgo(job.created_at)"></span>
                                </div>
                            </div>

                            <!-- Tokens -->
                            <div class="acms-ai-job__tokens" x-show="job.tokens_used > 0">
                                <i class="bi bi-lightning"></i>
                                <span x-text="formatTokens(job.tokens_used)"></span>
                            </div>

                            <!-- Cost -->
                            <div class="acms-ai-job__cost" x-show="job.cost > 0" x-text="'$' + job.cost.toFixed(4)"></div>

                            <!-- Actions -->
                            <div class="acms-ai-job__actions" style="display: flex; gap: 4px;">
                                <button
                                    class="acms-btn acms-btn--ghost acms-btn--sm acms-btn--icon"
                                    @click="retryJob(job.id)"
                                    x-show="job.status === 'failed'"
                                    title="<?php esc_attr_e('Retry', 'affiliatecms-ai'); ?>"
                                >
                                    <i class="bi bi-arrow-clockwise"></i>
                                </button>
                                <button
                                    class="acms-btn acms-btn--ghost acms-btn--sm acms-btn--icon"
                                    @click="cancelJob(job.id)"
                                    x-show="job.status === 'pending'"
                                    title="<?php esc_attr_e('Cancel', 'affiliatecms-ai'); ?>"
                                >
                                    <i class="bi bi-x"></i>
                                </button>
                            </div>
                        </div>
                    </template>
                </div>
            </div>

            <div class="acms-card__footer" x-show="jobs.length > 0">
                <span class="text-muted">
                    <?php esc_html_e('Showing', 'affiliatecms-ai'); ?>
                    <strong x-text="jobs.length"></strong>
                    <?php esc_html_e('of', 'affiliatecms-ai'); ?>
                    <strong x-text="totalItems"></strong>
                    <?php esc_html_e('jobs', 'affiliatecms-ai'); ?>
                </span>
                <div style="display: flex; gap: 4px; margin-left: auto;" x-show="totalPages > 1">
                    <button class="acms-btn acms-btn--ghost acms-btn--sm" :disabled="currentPage <= 1" @click="currentPage--; loadJobs()">
                        <i class="bi bi-chevron-left"></i>
                    </button>
                    <span class="text-muted" style="line-height: 28px;" x-text="currentPage + ' / ' + totalPages"></span>
                    <button class="acms-btn acms-btn--ghost acms-btn--sm" :disabled="currentPage >= totalPages" @click="currentPage++; loadJobs()">
                        <i class="bi bi-chevron-right"></i>
                    </button>
                </div>
            </div>
        </div>
        <?php
    }
}
