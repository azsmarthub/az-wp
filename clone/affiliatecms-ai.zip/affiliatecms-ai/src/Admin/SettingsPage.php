<?php
/**
 * AffiliateCMS AI - Unified Settings Page
 *
 * Single page combining API setup, model selection, stats, and settings
 */

declare(strict_types=1);

namespace AffiliateCMS\AI\Admin;

class SettingsPage
{
    /**
     * Render the settings page
     */
    public function render(): void
    {
        // Get current settings
        $settings = $this->getSettings();
        $stats = $this->getStats();
        ?>
        <!-- Critical: Hide x-cloak elements before Alpine loads -->
        <style>[x-cloak] { display: none !important; }</style>

        <style>
            <?php $this->renderStyles(); ?>
        </style>

        <script>
        window.acmsAiConfig = {
            restUrl: '<?php echo esc_js(rest_url('acms-ai/v1/')); ?>',
            nonce: '<?php echo esc_js(wp_create_nonce('wp_rest')); ?>',
            settings: <?php echo wp_json_encode($settings); ?>,
            stats: <?php echo wp_json_encode($stats); ?>,
            defaultPrompts: <?php echo wp_json_encode(\AffiliateCMS\AI\Core\DefaultPrompts::getAll()); ?>
        };
        </script>

        <div id="acms-ai-app" class="acms-admin" x-data="aiSettingsPage()">
            <div class="app-container">
                <!-- Page Header -->
                <header class="page-header">
                    <div class="header-left">
                        <div class="page-title">
                            <i class="bi bi-stars"></i>
                            <h1>AI Assistant</h1>
                            <span class="version-badge">v<?php echo esc_html(ACMS_AI_VERSION); ?></span>
                        </div>
                    </div>
                    <div class="header-actions">
                        <button class="btn btn-secondary" @click="testConnection()" :disabled="testing">
                            <i class="bi" :class="testing ? 'bi-arrow-clockwise animate-spin' : 'bi-plug'"></i>
                            <span x-text="testing ? 'Testing...' : 'Test Connection'"></span>
                        </button>
                        <button class="btn btn-primary" @click="saveSettings()" :disabled="saving">
                            <i class="bi" :class="saving ? 'bi-arrow-clockwise animate-spin' : 'bi-check-lg'"></i>
                            <span x-text="saving ? 'Saving...' : 'Save Settings'"></span>
                        </button>
                    </div>
                </header>

                <!-- Main Content Grid -->
                <div class="content-grid">
                    <!-- Left Column - Main Settings -->
                    <div class="main-column">
                        <!-- API Configuration Card -->
                        <div class="card">
                            <div class="card-header card-header-collapsible" @click="collapsed.apiConfig = !collapsed.apiConfig">
                                <h3 class="card-title">
                                    <i class="bi bi-key"></i>
                                    API Configuration
                                </h3>
                                <div style="display: flex; align-items: center; gap: 12px;">
                                    <div class="connection-status" :class="connectionStatus">
                                        <span class="status-dot"></span>
                                        <span x-text="connectionStatusText"></span>
                                    </div>
                                    <i class="bi collapse-icon" :class="collapsed.apiConfig ? 'bi-chevron-down' : 'bi-chevron-up'"></i>
                                </div>
                            </div>
                            <div class="card-body" x-show="!collapsed.apiConfig" x-transition>
                                <div class="form-group">
                                    <label class="form-label">OpenRouter API Key</label>
                                    <div class="api-key-input">
                                        <input
                                            :type="showApiKey ? 'text' : 'password'"
                                            class="form-input"
                                            x-model="settings.api_key"
                                            placeholder="sk-or-v1-..."
                                        >
                                        <button type="button" class="key-toggle" @click="showApiKey = !showApiKey">
                                            <i class="bi" :class="showApiKey ? 'bi-eye-slash' : 'bi-eye'"></i>
                                        </button>
                                    </div>
                                    <p class="form-hint">
                                        Get your API key from <a href="https://openrouter.ai/keys" target="_blank">openrouter.ai/keys</a>
                                    </p>
                                </div>

                                <div class="form-group">
                                    <label class="form-label">Site URL (for OpenRouter)</label>
                                    <input type="text" class="form-input" x-model="settings.site_url" placeholder="<?php echo esc_attr(home_url()); ?>">
                                    <p class="form-hint">Used for rate limiting and usage tracking on OpenRouter</p>
                                </div>

                                <div class="form-group">
                                    <label class="form-label">Site Name</label>
                                    <input type="text" class="form-input" x-model="settings.site_name" placeholder="<?php echo esc_attr(get_bloginfo('name')); ?>">
                                </div>
                            </div>
                        </div>

                        <!-- Model Selection Card -->
                        <div class="card">
                            <div class="card-header card-header-collapsible" @click="collapsed.modelSelection = !collapsed.modelSelection">
                                <h3 class="card-title">
                                    <i class="bi bi-cpu"></i>
                                    Default Model
                                </h3>
                                <div style="display: flex; align-items: center; gap: 12px;">
                                    <span class="model-badge" x-text="selectedModelName"></span>
                                    <i class="bi collapse-icon" :class="collapsed.modelSelection ? 'bi-chevron-down' : 'bi-chevron-up'"></i>
                                </div>
                            </div>
                            <div class="card-body" x-show="!collapsed.modelSelection" x-transition>
                                <p class="card-description">Select the default AI model. Different models have different capabilities and costs.</p>

                                <div class="model-tabs">
                                    <button class="model-tab" :class="{ active: modelTab === 'budget' }" @click="modelTab = 'budget'">
                                        <i class="bi bi-piggy-bank"></i> Budget
                                    </button>
                                    <button class="model-tab" :class="{ active: modelTab === 'balanced' }" @click="modelTab = 'balanced'">
                                        <i class="bi bi-speedometer2"></i> Balanced
                                    </button>
                                    <button class="model-tab" :class="{ active: modelTab === 'premium' }" @click="modelTab = 'premium'">
                                        <i class="bi bi-gem"></i> Premium
                                    </button>
                                </div>

                                <div class="model-grid">
                                    <template x-for="model in filteredModels" :key="model.id">
                                        <div class="model-card"
                                             :class="{ selected: settings.default_model === model.id }"
                                             @click="settings.default_model = model.id">
                                            <div class="model-check" x-show="settings.default_model === model.id">
                                                <i class="bi bi-check-lg"></i>
                                            </div>
                                            <div class="model-header">
                                                <span class="model-provider" :class="'provider-' + model.provider" x-text="model.provider"></span>
                                                <span class="model-badge" x-show="model.recommended" x-cloak>Recommended</span>
                                            </div>
                                            <div class="model-name" x-text="model.name"></div>
                                            <div class="model-meta">
                                                <span class="model-context" x-text="model.context"></span>
                                                <span class="model-price" x-text="model.price"></span>
                                            </div>
                                        </div>
                                    </template>
                                </div>
                            </div>
                        </div>

                        <!-- Feature Toggles Card -->
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">
                                    <i class="bi bi-toggles"></i>
                                    AI Features
                                </h3>
                            </div>
                            <div class="card-body">
                                <div class="feature-list">
                                    <div class="feature-item">
                                        <div class="feature-info">
                                            <div class="feature-label">Enhance ASIN Data</div>
                                            <div class="feature-desc">Auto-enhance product titles, descriptions, and extract key benefits when products are scraped</div>
                                        </div>
                                        <div class="feature-actions">
                                            <button type="button" class="btn-icon" @click="openPromptModal('enhance_asin')" title="Edit Prompt Template">
                                                <i class="bi bi-gear"></i>
                                            </button>
                                            <label class="acms-switch">
                                                <input type="checkbox" x-model="settings.enable_enhance_asin">
                                                <span class="acms-switch-slider"></span>
                                            </label>
                                        </div>
                                    </div>

                                    <div class="feature-item">
                                        <div class="feature-info">
                                            <div class="feature-label">Optimize Review Posts</div>
                                            <div class="feature-desc">Generate meta descriptions, FAQs, and improve content when posts are created</div>
                                        </div>
                                        <div class="feature-actions">
                                            <button type="button" class="btn-icon" @click="openPromptModal('optimize_review')" title="Edit Prompt Template">
                                                <i class="bi bi-gear"></i>
                                            </button>
                                            <label class="acms-switch">
                                                <input type="checkbox" x-model="settings.enable_optimize_review">
                                                <span class="acms-switch-slider"></span>
                                            </label>
                                        </div>
                                    </div>

                                    <div class="feature-item">
                                        <div class="feature-info">
                                            <div class="feature-label">
                                                <i class="bi bi-diagram-3" style="color: var(--info); margin-right: 6px;"></i>
                                                Parent Category AI
                                            </div>
                                            <div class="feature-desc">Generate content for <strong>parent categories</strong> in the path (e.g., "Home & Kitchen > Kitchen & Dining") - categories NOT from queue</div>
                                        </div>
                                        <div class="feature-actions">
                                            <button type="button" class="btn-icon" @click="openPromptModal('generate_category')" title="Edit Prompt Template">
                                                <i class="bi bi-gear"></i>
                                            </button>
                                            <label class="acms-switch">
                                                <input type="checkbox" x-model="settings.enable_generate_category">
                                                <span class="acms-switch-slider"></span>
                                            </label>
                                        </div>
                                    </div>

                                    <div class="feature-item feature-item-highlight">
                                        <div class="feature-info">
                                            <div class="feature-label">
                                                <i class="bi bi-folder-fill" style="color: var(--warning); margin-right: 6px;"></i>
                                                Queue Category AI
                                            </div>
                                            <div class="feature-desc">Generate comprehensive SEO content for <strong>keyword categories from Cat Queue</strong> (intro, main content, FAQs, meta tags) - the target category level</div>
                                        </div>
                                        <div class="feature-actions">
                                            <button type="button" class="btn-icon" @click="openPromptModal('seo_category')" title="Edit Prompt Template">
                                                <i class="bi bi-gear"></i>
                                            </button>
                                            <label class="acms-switch">
                                                <input type="checkbox" x-model="settings.enable_seo_category">
                                                <span class="acms-switch-slider"></span>
                                            </label>
                                        </div>
                                    </div>

                                    <div class="feature-item feature-item-highlight">
                                        <div class="feature-info">
                                            <div class="feature-label">
                                                <i class="bi bi-building" style="color: var(--info); margin-right: 6px;"></i>
                                                SEO Brand Pages
                                            </div>
                                            <div class="feature-desc">Generate comprehensive SEO content for <strong>brand pages</strong> (intro, main content, FAQs, meta tags) - for brands extracted from products</div>
                                        </div>
                                        <div class="feature-actions">
                                            <button type="button" class="btn-icon" @click="openPromptModal('seo_brand')" title="Edit Prompt Template">
                                                <i class="bi bi-gear"></i>
                                            </button>
                                            <label class="acms-switch">
                                                <input type="checkbox" x-model="settings.enable_seo_brand">
                                                <span class="acms-switch-slider"></span>
                                            </label>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>

                        <!-- Test API Card -->
                        <div class="card">
                            <div class="card-header card-header-collapsible" @click="collapsed.testApi = !collapsed.testApi">
                                <h3 class="card-title">
                                    <i class="bi bi-terminal"></i>
                                    Test API
                                </h3>
                                <i class="bi collapse-icon" :class="collapsed.testApi ? 'bi-chevron-down' : 'bi-chevron-up'"></i>
                            </div>
                            <div class="card-body" x-show="!collapsed.testApi" x-transition>
                                <div class="form-group">
                                    <label class="form-label">Select Model</label>
                                    <select class="form-input" x-model="testModel">
                                        <template x-for="model in models" :key="model.id">
                                            <option :value="model.id" x-text="model.name + ' (' + model.price + ')'"></option>
                                        </template>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Test Prompt</label>
                                    <textarea class="form-textarea" rows="3" x-model="testPrompt" placeholder="Enter a test prompt..."></textarea>
                                </div>
                                <div class="test-actions">
                                    <button class="btn btn-secondary" @click="runTest()" :disabled="testRunning || !testPrompt.trim()">
                                        <i class="bi" :class="testRunning ? 'bi-arrow-clockwise animate-spin' : 'bi-play-fill'"></i>
                                        <span x-text="testRunning ? 'Running...' : 'Run Test'"></span>
                                    </button>
                                    <span class="test-meta" x-show="testResult.tokens" x-cloak>
                                        <i class="bi bi-lightning"></i> <span x-text="testResult.tokens"></span> tokens
                                        <span class="test-cost" x-text="'$' + testResult.cost"></span>
                                    </span>
                                </div>
                                <div class="test-result" x-show="testResult.response" x-cloak>
                                    <div class="result-header">
                                        <span>Response</span>
                                        <span class="result-model" x-text="testResult.model"></span>
                                        <button class="btn-icon-sm" @click="copyResult()" title="Copy">
                                            <i class="bi bi-clipboard"></i>
                                        </button>
                                    </div>
                                    <div class="result-content" x-text="testResult.response"></div>
                                </div>
                                <div class="test-error" x-show="testResult.error" x-cloak x-text="testResult.error"></div>
                            </div>
                        </div>
                    </div>

                    <!-- Right Column - Sidebar -->
                    <div class="sidebar-column">
                        <!-- Quick Stats Card -->
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">
                                    <i class="bi bi-graph-up"></i>
                                    This Month
                                </h3>
                            </div>
                            <div class="card-body">
                                <div class="stats-mini">
                                    <div class="stat-mini">
                                        <div class="stat-value" x-text="'$' + formatCurrency(stats.currentSpend)">$0.00</div>
                                        <div class="stat-label">Spent</div>
                                    </div>
                                    <div class="stat-mini">
                                        <div class="stat-value" x-text="formatNumber(stats.totalTokens)">0</div>
                                        <div class="stat-label">Tokens</div>
                                    </div>
                                    <div class="stat-mini">
                                        <div class="stat-value" x-text="stats.totalRequests">0</div>
                                        <div class="stat-label">Requests</div>
                                    </div>
                                </div>

                                <!-- Budget Progress -->
                                <div class="budget-section" x-show="settings.monthly_budget > 0">
                                    <div class="budget-header">
                                        <span>Budget Usage</span>
                                        <span x-text="'$' + formatCurrency(stats.currentSpend) + ' / $' + settings.monthly_budget"></span>
                                    </div>
                                    <div class="budget-bar">
                                        <div class="budget-progress" :class="budgetClass" :style="'width: ' + budgetPercent + '%'"></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Budget Control Card -->
                        <div class="card">
                            <div class="card-header card-header-collapsible" @click="collapsed.budgetControl = !collapsed.budgetControl">
                                <h3 class="card-title">
                                    <i class="bi bi-wallet2"></i>
                                    Budget Control
                                </h3>
                                <i class="bi collapse-icon" :class="collapsed.budgetControl ? 'bi-chevron-down' : 'bi-chevron-up'"></i>
                            </div>
                            <div class="card-body" x-show="!collapsed.budgetControl" x-transition>
                                <div class="form-group">
                                    <label class="form-label">Monthly Budget (USD)</label>
                                    <input type="number" class="form-input" x-model.number="settings.monthly_budget" min="0" step="5" placeholder="50">
                                    <p class="form-hint">Set to 0 for unlimited. AI will pause when budget is reached.</p>
                                </div>

                                <div class="cost-estimates">
                                    <div class="cost-header">Estimated Costs (per 1000 items)</div>
                                    <div class="cost-row">
                                        <span>ASIN Enhancement</span>
                                        <span>~$0.50</span>
                                    </div>
                                    <div class="cost-row">
                                        <span>Review Optimization</span>
                                        <span>~$1.00</span>
                                    </div>
                                    <div class="cost-row">
                                        <span>Category Generation</span>
                                        <span>~$0.30</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- AI Jobs Maintenance Card -->
                        <div class="card">
                            <div class="card-header card-header-collapsible" @click="collapsed.queueStatus = !collapsed.queueStatus">
                                <h3 class="card-title">
                                    <i class="bi bi-database"></i>
                                    AI Jobs Table
                                </h3>
                                <div style="display: flex; align-items: center; gap: 8px;">
                                    <span style="font-size: 11px; color: var(--text-muted);" x-text="aiJobsCount + ' rows'"></span>
                                    <i class="bi collapse-icon" :class="collapsed.queueStatus ? 'bi-chevron-down' : 'bi-chevron-up'"></i>
                                </div>
                            </div>
                            <div class="card-body" x-show="!collapsed.queueStatus" x-transition style="padding: 12px 16px;">
                                <div style="display: flex; gap: 6px; margin-bottom: 12px;">
                                    <div style="flex: 1; display: flex; align-items: center; gap: 8px; padding: 8px 10px; background: rgba(251,191,36,0.1); border-radius: 6px; border: 1px solid rgba(251,191,36,0.2);">
                                        <div style="line-height: 1.2;">
                                            <div style="font-size: 16px; font-weight: 600;" x-text="aiJobsStats.pending"></div>
                                            <div style="font-size: 10px; color: var(--text-muted);">Pending</div>
                                        </div>
                                    </div>
                                    <div style="flex: 1; display: flex; align-items: center; gap: 8px; padding: 8px 10px; background: rgba(59,130,246,0.1); border-radius: 6px; border: 1px solid rgba(59,130,246,0.2);">
                                        <div style="line-height: 1.2;">
                                            <div style="font-size: 16px; font-weight: 600;" x-text="aiJobsStats.processing"></div>
                                            <div style="font-size: 10px; color: var(--text-muted);">Processing</div>
                                        </div>
                                    </div>
                                    <div style="flex: 1; display: flex; align-items: center; gap: 8px; padding: 8px 10px; background: rgba(34,197,94,0.1); border-radius: 6px; border: 1px solid rgba(34,197,94,0.2);">
                                        <div style="line-height: 1.2;">
                                            <div style="font-size: 16px; font-weight: 600;" x-text="aiJobsStats.completed"></div>
                                            <div style="font-size: 10px; color: var(--text-muted);">Completed</div>
                                        </div>
                                    </div>
                                    <div style="flex: 1; display: flex; align-items: center; gap: 8px; padding: 8px 10px; background: rgba(239,68,68,0.1); border-radius: 6px; border: 1px solid rgba(239,68,68,0.2);">
                                        <div style="line-height: 1.2;">
                                            <div style="font-size: 16px; font-weight: 600;" x-text="aiJobsStats.failed"></div>
                                            <div style="font-size: 10px; color: var(--text-muted);">Failed</div>
                                        </div>
                                    </div>
                                </div>

                                <div style="display: flex; gap: 6px; flex-wrap: wrap;">
                                    <button class="btn btn-sm btn-outline" @click="refreshAiJobsStats()" :disabled="loadingAiJobs" style="padding: 5px 10px; font-size: 11px;">
                                        <i class="bi" :class="loadingAiJobs ? 'bi-arrow-repeat animate-spin' : 'bi-arrow-clockwise'" style="font-size: 11px;"></i>
                                        Refresh
                                    </button>
                                    <button class="btn btn-sm btn-outline" @click="clearAiJobs()" :disabled="clearingAiJobs" style="padding: 5px 10px; font-size: 11px; color: #f87171;" title="Delete ALL rows from acms_ai_jobs table">
                                        <i class="bi" :class="clearingAiJobs ? 'bi-arrow-repeat animate-spin' : 'bi-trash'" style="font-size: 11px;"></i>
                                        Clear All Jobs
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- Help Card -->
                        <div class="card">
                            <div class="card-header card-header-collapsible" @click="collapsed.quickGuide = !collapsed.quickGuide">
                                <h3 class="card-title">
                                    <i class="bi bi-question-circle"></i>
                                    Quick Guide
                                </h3>
                                <i class="bi collapse-icon" :class="collapsed.quickGuide ? 'bi-chevron-down' : 'bi-chevron-up'"></i>
                            </div>
                            <div class="card-body help-content" x-show="!collapsed.quickGuide" x-transition>
                                <div class="help-section">
                                    <h4>Getting Started</h4>
                                    <ol>
                                        <li>Create an account at <a href="https://openrouter.ai" target="_blank">openrouter.ai</a></li>
                                        <li>Add credits to your account</li>
                                        <li>Generate an API key</li>
                                        <li>Paste the key above and test</li>
                                    </ol>
                                </div>

                                <div class="help-section">
                                    <h4>Why OpenRouter?</h4>
                                    <ul>
                                        <li>Access 400+ AI models</li>
                                        <li>Often 40-70% cheaper</li>
                                        <li>Automatic fallbacks</li>
                                        <li>Single unified API</li>
                                    </ul>
                                </div>

                                <div class="help-links">
                                    <a href="https://openrouter.ai/docs" target="_blank" class="help-link">
                                        <i class="bi bi-book"></i> Documentation
                                    </a>
                                    <a href="https://openrouter.ai/models" target="_blank" class="help-link">
                                        <i class="bi bi-cpu"></i> All Models
                                    </a>
                                    <a href="https://openrouter.ai/activity" target="_blank" class="help-link">
                                        <i class="bi bi-activity"></i> Usage Dashboard
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- ============================================
                     API ACTIVITY LOG
                     ============================================ -->
                <div class="card" style="margin-top: 20px;">
                    <div class="card-header card-header-collapsible" @click="collapsed.apiLog = !collapsed.apiLog">
                        <h3 class="card-title">
                            <i class="bi bi-activity"></i>
                            API Activity Log
                            <span style="font-size: 11px; font-weight: 400; color: var(--text-muted); margin-left: 8px;" x-show="apiLog.summary.total_calls > 0">
                                Today: <strong x-text="apiLog.summary.total_calls"></strong> calls,
                                <strong x-text="formatNumber(apiLog.summary.total_tokens)"></strong> tokens,
                                $<strong x-text="formatCurrency(apiLog.summary.total_cost)"></strong>
                            </span>
                        </h3>
                        <div style="display: flex; align-items: center; gap: 8px;">
                            <template x-if="apiLog.repeated.length > 0">
                                <span style="display: inline-flex; align-items: center; gap: 4px; padding: 2px 8px; border-radius: 10px; font-size: 10px; font-weight: 600; background: rgba(239,68,68,0.15); color: #ef4444;">
                                    <i class="bi bi-exclamation-triangle-fill" style="font-size: 9px;"></i>
                                    <span x-text="apiLog.repeated.length"></span> repeated
                                </span>
                            </template>
                            <button class="btn btn-sm btn-outline" @click.stop="loadApiLog()" :disabled="apiLog.loading" style="padding: 3px 8px; font-size: 11px;">
                                <i class="bi" :class="apiLog.loading ? 'bi-arrow-repeat animate-spin' : 'bi-arrow-clockwise'" style="font-size: 11px;"></i>
                            </button>
                            <i class="bi collapse-icon" :class="collapsed.apiLog ? 'bi-chevron-down' : 'bi-chevron-up'"></i>
                        </div>
                    </div>
                    <div class="card-body" x-show="!collapsed.apiLog" x-transition style="padding: 0;">
                        <!-- Repeated Targets Warning -->
                        <template x-if="apiLog.repeated.length > 0">
                            <div style="padding: 10px 16px; background: rgba(239,68,68,0.06); border-bottom: 1px solid rgba(239,68,68,0.15);">
                                <div style="font-size: 11px; font-weight: 600; color: #ef4444; margin-bottom: 6px;">
                                    <i class="bi bi-exclamation-triangle-fill"></i> Repeated Targets Today (possible loop)
                                </div>
                                <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                                    <template x-for="rt in apiLog.repeated" :key="rt.target_type + rt.target_id">
                                        <span style="display: inline-flex; align-items: center; gap: 4px; padding: 3px 10px; border-radius: 4px; font-size: 11px; font-family: monospace;"
                                              :style="rt.level === 'danger' ? 'background: rgba(239,68,68,0.12); color: #ef4444; border: 1px solid rgba(239,68,68,0.25);' : 'background: rgba(245,158,11,0.12); color: #f59e0b; border: 1px solid rgba(245,158,11,0.25);'">
                                            <span x-text="rt.target_name"></span>
                                            <strong x-text="'×' + rt.call_count"></strong>
                                            <span style="opacity: 0.7;" x-text="'(' + formatNumber(rt.total_tokens) + ' tok)'"></span>
                                        </span>
                                    </template>
                                </div>
                            </div>
                        </template>

                        <!-- Filters -->
                        <div style="padding: 8px 16px; border-bottom: 1px solid var(--border); display: flex; gap: 8px; align-items: center;">
                            <span style="font-size: 11px; color: var(--text-muted);">Filter:</span>
                            <select x-model="apiLog.filterType" @change="loadApiLog()" style="font-size: 11px; padding: 3px 8px; background: var(--bg-surface); border: 1px solid var(--border); border-radius: 4px; color: var(--text-primary);">
                                <option value="">All Types</option>
                                <option value="generate_seo_category">Category SEO</option>
                                <option value="generate_seo_brand">Brand SEO</option>
                                <option value="enhance_asin">ASIN Enhance</option>
                                <option value="optimize_review">Review Optimize</option>
                            </select>
                            <select x-model="apiLog.filterStatus" @change="loadApiLog()" style="font-size: 11px; padding: 3px 8px; background: var(--bg-surface); border: 1px solid var(--border); border-radius: 4px; color: var(--text-primary);">
                                <option value="">All Status</option>
                                <option value="completed">Completed</option>
                                <option value="failed">Failed</option>
                                <option value="processing">Processing</option>
                                <option value="pending">Pending</option>
                            </select>
                            <span style="flex: 1;"></span>
                            <label style="font-size: 11px; color: var(--text-muted); display: flex; align-items: center; gap: 4px; cursor: pointer;">
                                <input type="checkbox" x-model="apiLog.autoRefresh" @change="toggleApiLogRefresh()" style="width: 13px; height: 13px;">
                                Auto-refresh 30s
                            </label>
                        </div>

                        <!-- Log Table -->
                        <div style="max-height: 500px; overflow-y: auto;">
                            <table style="width: 100%; border-collapse: collapse; font-size: 12px;">
                                <thead style="position: sticky; top: 0; background: var(--bg-elevated); z-index: 1;">
                                    <tr style="border-bottom: 2px solid var(--border);">
                                        <th style="padding: 8px 10px; text-align: left; font-size: 10px; font-weight: 600; text-transform: uppercase; color: var(--text-muted); letter-spacing: 0.5px;" title="OpenRouter API timestamp when available">Time</th>
                                        <th style="padding: 8px 6px; text-align: left; font-size: 10px; font-weight: 600; text-transform: uppercase; color: var(--text-muted); letter-spacing: 0.5px;">Type</th>
                                        <th style="padding: 8px 6px; text-align: left; font-size: 10px; font-weight: 600; text-transform: uppercase; color: var(--text-muted); letter-spacing: 0.5px;">Target</th>
                                        <th style="padding: 8px 6px; text-align: left; font-size: 10px; font-weight: 600; text-transform: uppercase; color: var(--text-muted); letter-spacing: 0.5px;">Model</th>
                                        <th style="padding: 8px 6px; text-align: right; font-size: 10px; font-weight: 600; text-transform: uppercase; color: var(--text-muted); letter-spacing: 0.5px;" title="Prompt / Completion">Tokens (in/out)</th>
                                        <th style="padding: 8px 6px; text-align: right; font-size: 10px; font-weight: 600; text-transform: uppercase; color: var(--text-muted); letter-spacing: 0.5px;">Duration</th>
                                        <th style="padding: 8px 10px; text-align: center; font-size: 10px; font-weight: 600; text-transform: uppercase; color: var(--text-muted); letter-spacing: 0.5px;">Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <template x-if="apiLog.items.length === 0 && !apiLog.loading">
                                        <tr>
                                            <td colspan="7" style="padding: 40px; text-align: center; color: var(--text-muted);">
                                                <i class="bi bi-inbox" style="font-size: 24px; display: block; margin-bottom: 8px; opacity: 0.5;"></i>
                                                No API calls found
                                            </td>
                                        </tr>
                                    </template>
                                    <template x-for="item in apiLog.items" :key="item.id">
                                        <tr style="border-bottom: 1px solid var(--border);" :style="item.status === 'failed' ? 'background: rgba(239,68,68,0.04);' : ''">
                                            <!-- Time -->
                                            <td style="padding: 6px 10px; white-space: nowrap; font-family: monospace; font-size: 11px; color: var(--text-secondary);">
                                                <div x-text="formatLogTime(item.api_created_at || item.created_at)"></div>
                                                <div style="font-size: 10px; color: var(--text-muted);" x-text="formatLogDate(item.api_created_at || item.created_at)"></div>
                                                <div x-show="item.api_created_at" style="font-size: 9px; color: var(--text-muted); opacity: 0.6;" title="OpenRouter API timestamp">OR</div>
                                            </td>
                                            <!-- Type -->
                                            <td style="padding: 6px;">
                                                <span style="padding: 2px 7px; border-radius: 3px; font-size: 10px; font-weight: 500; white-space: nowrap;"
                                                      :style="getTypeBadgeStyle(item.type)"
                                                      x-text="item.type_label"></span>
                                            </td>
                                            <!-- Target -->
                                            <td style="padding: 6px; max-width: 250px;">
                                                <div style="font-weight: 500; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" x-text="item.target_name" :title="item.target_name + ' (ID: ' + item.target_id + ')'"></div>
                                                <div style="font-size: 10px; color: var(--text-muted);" x-text="'#' + item.target_id"></div>
                                            </td>
                                            <!-- Model -->
                                            <td style="padding: 6px; font-size: 11px; color: var(--text-secondary); white-space: nowrap;">
                                                <span x-text="item.model ? item.model.split('/').pop() : '-'"></span>
                                            </td>
                                            <!-- Tokens -->
                                            <td style="padding: 6px; text-align: right; font-family: monospace; font-size: 11px;">
                                                <template x-if="item.tokens_input > 0 || item.tokens_output > 0">
                                                    <span :style="item.tokens_used > 5000 ? 'color: var(--warning);' : 'color: var(--text-secondary);'">
                                                        <span x-text="formatNumber(item.tokens_input)" style="opacity: 0.7;" title="Prompt tokens"></span>
                                                        <span style="opacity: 0.35; margin: 0 1px;">/</span>
                                                        <span x-text="formatNumber(item.tokens_output)" style="font-weight: 600;" title="Completion tokens"></span>
                                                    </span>
                                                </template>
                                                <template x-if="!(item.tokens_input > 0 || item.tokens_output > 0)">
                                                    <span x-text="item.tokens_used > 0 ? formatNumber(item.tokens_used) : '-'" :style="item.tokens_used > 5000 ? 'color: var(--warning); font-weight: 600;' : 'color: var(--text-secondary);'"></span>
                                                </template>
                                            </td>
                                            <!-- Duration -->
                                            <td style="padding: 6px; text-align: right; font-family: monospace; font-size: 11px; color: var(--text-secondary);">
                                                <span x-text="item.duration_seconds !== null ? item.duration_seconds + 's' : '-'" :style="item.duration_seconds > 30 ? 'color: var(--warning);' : ''"></span>
                                            </td>
                                            <!-- Status -->
                                            <td style="padding: 6px 10px; text-align: center;">
                                                <span style="padding: 2px 8px; border-radius: 10px; font-size: 10px; font-weight: 600; text-transform: uppercase;"
                                                      :style="{
                                                          completed: 'background: rgba(34,197,94,0.12); color: #22c55e;',
                                                          failed: 'background: rgba(239,68,68,0.12); color: #ef4444;',
                                                          processing: 'background: rgba(59,130,246,0.12); color: #3b82f6;',
                                                          pending: 'background: rgba(251,191,36,0.12); color: #fbbf24;'
                                                      }[item.status]"
                                                      x-text="item.status"></span>
                                                <div x-show="item.error_message" style="font-size: 10px; color: #ef4444; max-width: 150px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-top: 2px;" :title="item.error_message" x-text="item.error_message"></div>
                                            </td>
                                        </tr>
                                    </template>
                                </tbody>
                            </table>
                        </div>

                        <!-- Footer -->
                        <div style="padding: 8px 16px; border-top: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between; font-size: 11px; color: var(--text-muted);">
                            <span x-text="apiLog.items.length + ' entries shown'"></span>
                            <span x-show="apiLog.summary.total_calls > 0">
                                Today: <span x-text="apiLog.summary.completed" style="color: var(--success);"></span> OK /
                                <span x-text="apiLog.summary.failed" style="color: var(--error);"></span> fail /
                                <span x-text="apiLog.summary.processing" style="color: var(--primary);"></span> running
                            </span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Toast Notification -->
            <div class="toast-container" x-show="showToast" x-cloak
                 x-transition:enter="transition ease-out duration-300"
                 x-transition:enter-start="opacity-0 transform translate-y-4"
                 x-transition:enter-end="opacity-100 transform translate-y-0"
                 x-transition:leave="transition ease-in duration-200"
                 x-transition:leave-start="opacity-100"
                 x-transition:leave-end="opacity-0">
                <div class="toast" :class="'toast-' + toastType">
                    <i class="bi" :class="{
                        'bi-check-circle-fill': toastType === 'success',
                        'bi-exclamation-triangle-fill': toastType === 'warning',
                        'bi-x-circle-fill': toastType === 'error',
                        'bi-info-circle-fill': toastType === 'info'
                    }"></i>
                    <span x-text="toastMessage"></span>
                </div>
            </div>

            <!-- Prompt Template Modal -->
            <template x-if="promptModal.show">
            <div class="acmsai-pm-overlay" @click.self="closePromptModal()">
                <div class="acmsai-pm-box" @click.stop>
                    <div class="acmsai-pm-head">
                        <div class="acmsai-pm-headtitle">
                            <i class="bi bi-chat-square-text"></i>
                            <span x-text="promptModal.title"></span>
                        </div>
                        <div class="acmsai-pm-headright">
                            <div class="acmsai-pm-btnalt acmsai-pm-btncompact" @click="previewPrompt()" :class="{ 'acmsai-pm-loading': promptModal.previewing }">
                                <i class="bi" :class="promptModal.previewing ? 'bi-arrow-repeat acmsai-spin' : 'bi-eye'"></i>
                                <span x-text="promptModal.previewing ? 'Loading...' : 'Preview'"></span>
                            </div>
                            <div class="acmsai-pm-close" @click="closePromptModal()">
                                <i class="bi bi-x-lg"></i>
                            </div>
                        </div>
                    </div>
                    <div class="acmsai-pm-body">
                        <div class="acmsai-pm-editor">
                            <div class="acmsai-pm-label">Prompt Template</div>
                            <div class="acmsai-pm-code"
                                 contenteditable="true"
                                 spellcheck="false"
                                 x-ref="codeEditor"
                                 x-init="$nextTick(() => { $el.innerText = promptModal.prompt; editorApplyHighlight($el); })"
                                 @input.debounce.300ms="promptModal.prompt = $el.innerText; editorApplyHighlight($el)"
                                 @paste.prevent="
                                     const text = ($event.clipboardData || window.clipboardData).getData('text/plain');
                                     document.execCommand('insertText', false, text);
                                 "
                                 @keydown.tab.prevent="document.execCommand('insertText', false, '    ')"
                            ></div>
                        </div>
                        <!-- Variables - collapsible -->
                        <div class="acmsai-pm-vars">
                            <div class="acmsai-pm-varstitle" @click="promptModal.varsOpen = !promptModal.varsOpen" style="cursor:pointer">
                                <i class="bi bi-braces"></i>
                                <span>Available Variables</span>
                                <i class="bi" :class="promptModal.varsOpen ? 'bi-chevron-up' : 'bi-chevron-down'" style="margin-left:auto;font-size:12px;opacity:0.5"></i>
                            </div>
                            <div x-show="promptModal.varsOpen" x-transition.duration.200ms>
                                <div class="acmsai-pm-varslist">
                                    <template x-for="variable in promptModal.variables" :key="variable.name">
                                        <div class="acmsai-pm-tag" @click="insertVariable(variable.name)" :title="variable.description">
                                            <span x-text="'{{' + variable.name + '}}'"></span>
                                        </div>
                                    </template>
                                </div>
                                <div class="acmsai-pm-varshelp">Click a variable to insert it at cursor position.</div>
                            </div>
                        </div>
                    </div>
                    <div class="acmsai-pm-foot">
                        <div class="acmsai-pm-btnalt" @click="resetPromptToDefault()">
                            <i class="bi bi-arrow-counterclockwise"></i> Reset
                        </div>
                        <div class="acmsai-pm-footright">
                            <div class="acmsai-pm-btnalt" @click="closePromptModal()">Cancel</div>
                            <div class="acmsai-pm-btnmain" @click="savePromptTemplate()">
                                <i class="bi bi-check-lg"></i> Save
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </template>

            <!-- Preview Modal (separate) -->
            <template x-if="promptModal.showPreview">
            <div class="acmsai-pm-overlay" @click.self="promptModal.showPreview = false" style="z-index:1000000 !important">
                <div class="acmsai-pm-box" @click.stop>
                    <div class="acmsai-pm-head">
                        <div class="acmsai-pm-headtitle">
                            <i class="bi bi-eye"></i>
                            <span>Preview — Rendered with Sample Data</span>
                        </div>
                        <div class="acmsai-pm-close" @click="promptModal.showPreview = false">
                            <i class="bi bi-x-lg"></i>
                        </div>
                    </div>
                    <div class="acmsai-pm-body">
                        <div class="acmsai-pm-preview" x-html="highlightPrompt(promptModal.previewText || '')"></div>
                    </div>
                    <div class="acmsai-pm-foot">
                        <div class="acmsai-pm-footright" style="margin-left:auto">
                            <div class="acmsai-pm-btnalt" @click="promptModal.showPreview = false">Close</div>
                        </div>
                    </div>
                </div>
            </div>
            </template>
        </div>

        <script>
        document.addEventListener('alpine:init', () => {
            Alpine.data('aiSettingsPage', () => ({
                // Settings
                settings: {
                    api_key: '',
                    site_url: '<?php echo esc_js(home_url()); ?>',
                    site_name: '<?php echo esc_js(get_bloginfo('name')); ?>',
                    default_model: 'google/gemini-3-flash-preview',
                    monthly_budget: 50,
                    enable_enhance_asin: false,
                    enable_optimize_review: false,
                    enable_generate_category: false,
                    ...acmsAiConfig.settings
                },

                // Stats
                stats: {
                    currentSpend: 0,
                    totalTokens: 0,
                    totalRequests: 0,
                    ...acmsAiConfig.stats
                },

                // Models list - Updated January 2026
                models: [
                    // Budget Models
                    { id: 'google/gemini-3-flash-preview', name: 'Gemini 3 Flash', provider: 'google', price: '$0.10/1M', context: '1M', tier: 'budget', recommended: true },
                    { id: 'x-ai/grok-4.1-fast', name: 'Grok 4.1 Fast', provider: 'xai', price: '$0.15/1M', context: '128K', tier: 'budget' },
                    { id: 'anthropic/claude-haiku-4.5', name: 'Claude Haiku 4.5', provider: 'anthropic', price: '$0.80/1M', context: '200K', tier: 'budget' },
                    { id: 'openai/o3-mini', name: 'o3 Mini', provider: 'openai', price: '$1.10/1M', context: '200K', tier: 'budget' },
                    { id: 'deepseek/deepseek-v3.2', name: 'DeepSeek V3.2', provider: 'deepseek', price: '$0.14/1M', context: '128K', tier: 'budget' },
                    { id: 'meta-llama/llama-4-scout', name: 'Llama 4 Scout', provider: 'meta', price: '$0.15/1M', context: '10M', tier: 'budget' },
                    // Balanced Models
                    { id: 'openai/gpt-5', name: 'GPT-5', provider: 'openai', price: '$5/1M', context: '196K', tier: 'balanced', recommended: true },
                    { id: 'anthropic/claude-sonnet-4.6', name: 'Claude Sonnet 4.6', provider: 'anthropic', price: '$3/1M', context: '200K', tier: 'balanced' },
                    { id: 'google/gemini-3-pro-preview', name: 'Gemini 3 Pro', provider: 'google', price: '$2.50/1M', context: '2M', tier: 'balanced' },
                    { id: 'x-ai/grok-4', name: 'Grok 4', provider: 'xai', price: '$3/1M', context: '128K', tier: 'balanced' },
                    { id: 'meta-llama/llama-4-maverick', name: 'Llama 4 Maverick', provider: 'meta', price: '$0.50/1M', context: '1M', tier: 'balanced' },
                    // Premium Models
                    { id: 'anthropic/claude-opus-4.6', name: 'Claude Opus 4.6', provider: 'anthropic', price: '$15/1M', context: '200K', tier: 'premium', recommended: true },
                    { id: 'openai/gpt-5.2', name: 'GPT-5.2', provider: 'openai', price: '$10/1M', context: '196K', tier: 'premium' },
                    { id: 'openai/o3', name: 'o3 (Reasoning)', provider: 'openai', price: '$15/1M', context: '200K', tier: 'premium' },
                    { id: 'x-ai/grok-4-heavy', name: 'Grok 4 Heavy', provider: 'xai', price: '$5/1M', context: '128K', tier: 'premium' },
                    { id: 'google/gemini-2.0-flash-thinking-exp', name: 'Gemini 2.0 Flash Thinking', provider: 'google', price: '$0/1M', context: '1M', tier: 'premium' },
                    { id: 'deepseek/deepseek-v3.2-speciale', name: 'DeepSeek V3.2 Speciale', provider: 'deepseek', price: '$2/1M', context: '128K', tier: 'premium' },
                ],

                // UI State
                modelTab: 'budget',
                showApiKey: false,
                saving: false,
                testing: false,
                connectionStatus: 'unknown', // unknown, connected, error

                // Collapse state for sections
                collapsed: {
                    apiConfig: true, // Default collapsed
                    modelSelection: true, // Default collapsed
                    testApi: true, // Default collapsed
                    budgetControl: true, // Default collapsed
                    queueStatus: false, // Default expanded - important status
                    quickGuide: true, // Default collapsed
                    apiLog: false, // Default expanded - monitoring
                },

                // AI Jobs stats
                aiJobsCount: 0,
                aiJobsStats: { pending: 0, processing: 0, completed: 0, failed: 0 },
                loadingAiJobs: false,
                clearingAiJobs: false,

                // Test API
                testModel: 'google/gemini-3-flash-preview',
                testPrompt: 'Write a short product description for wireless Bluetooth headphones.',
                testRunning: false,
                testResult: { response: '', tokens: 0, cost: '0.0000', error: '', model: '' },

                // Toast
                showToast: false,
                toastType: 'success',
                toastMessage: '',

                // API Activity Log
                apiLog: {
                    items: [],
                    summary: { total_calls: 0, completed: 0, failed: 0, processing: 0, total_tokens: 0, total_cost: 0 },
                    repeated: [],
                    loading: false,
                    filterType: '',
                    filterStatus: '',
                    autoRefresh: true,
                    refreshTimer: null,
                },

                // Prompt Modal
                promptModal: {
                    show: false,
                    type: '',
                    title: '',
                    prompt: '',
                    variables: [],
                    varsOpen: false,
                    showPreview: false,
                    previewText: '',
                    previewing: false,
                },

                // Prompt templates: defaults loaded from PHP (single source of truth)
                promptTemplates: {
                    enhance_asin: {
                        title: 'Enhance ASIN Data - Prompt Template',
                        default: acmsAiConfig.defaultPrompts.enhance_asin || '',
                        variables: [
                            // Basic info
                            { name: 'asin_code', description: 'Amazon ASIN code (e.g., B0XXXXXXXXX)' },
                            { name: 'asin_title', description: 'Original product title from Amazon' },
                            { name: 'asin_brand', description: 'Product brand name' },
                            { name: 'asin_category', description: 'Product category' },
                            { name: 'asin_category_path', description: 'Full category breadcrumb path' },
                            // Pricing
                            { name: 'asin_price', description: 'Current product price' },
                            { name: 'asin_original_price', description: 'Original price (before discount)' },
                            { name: 'asin_currency', description: 'Currency code (USD, EUR, etc.)' },
                            // Availability
                            { name: 'asin_in_stock', description: 'Stock status (Yes/No)' },
                            { name: 'asin_is_prime', description: 'Prime eligible (Yes/No)' },
                            // Ratings
                            { name: 'asin_rating', description: 'Product rating (0-5)' },
                            { name: 'asin_reviews_count', description: 'Number of customer reviews' },
                            { name: 'asin_score', description: 'Calculated product score (0-100)' },
                            // Content
                            { name: 'asin_description', description: 'Original product description' },
                            { name: 'asin_features', description: 'Product features/bullet points' },
                            // Details
                            { name: 'asin_specifications', description: 'Technical specifications (JSON)' },
                            { name: 'asin_product_information', description: 'Product information details (JSON)' },
                            { name: 'asin_best_sellers_rank', description: 'Best sellers rank info' },
                            // Reviews
                            { name: 'asin_top_reviews', description: 'Top customer reviews (JSON)' },
                            { name: 'asin_reviews_summary', description: 'Reviews summary/highlights (JSON)' },
                            // Seller
                            { name: 'asin_seller_info', description: 'Seller information (JSON)' },
                            // Media
                            { name: 'asin_image_url', description: 'Main product image URL' },
                            { name: 'asin_images_gallery', description: 'Gallery images (JSON array)' }
                        ]
                    },
                    optimize_review: {
                        title: 'Generate Review Post - Prompt Template',
                        default: acmsAiConfig.defaultPrompts.optimize_review || "",
                        variables: [
                            { name: 'keyword', description: 'Main keyword (lowercase)' },
                            { name: 'keyword_title', description: 'Main keyword (Title Case)' },
                            { name: 'current_title', description: 'Current post title' },
                            { name: 'existing_title', description: 'Alias for current_title' },
                            { name: 'current_content', description: 'Current post content (with shortcodes)' },
                            { name: 'existing_content', description: 'Alias for current_content' },
                            { name: 'products', description: 'Formatted products data (title, brand, price, rating, features, pros, cons)' },
                            { name: 'products_count', description: 'Number of products in the review' },
                            { name: 'related_posts', description: 'Related posts list for internal linking (title + URL)' },
                            { name: 'category_name', description: 'Target category name' },
                            { name: 'shortcode_list', description: 'Extracted [acms_list] shortcode from existing content' },
                            { name: 'price_range', description: 'Price range (e.g. "$29.99 - $149.99")' },
                            { name: 'price_min', description: 'Lowest product price' },
                            { name: 'price_max', description: 'Highest product price' },
                            { name: 'brand_list', description: 'Comma-separated brand names' },
                            { name: 'brand_count', description: 'Number of unique brands' },
                            { name: 'review_count', description: 'Total reviews across all products' },
                            { name: 'year', description: 'Current year' },
                            { name: 'month_text', description: 'Current month name' },
                            { name: 'author', description: 'Site/blog name' }
                        ]
                    },
                    generate_category: {
                        title: 'Parent Category AI - Prompt Template',
                        default: acmsAiConfig.defaultPrompts.generate_category || "",
                        variables: [
                            { name: 'category_name', description: 'Parent category name (e.g., "Kitchen & Dining")' },
                            { name: 'category_path', description: 'Full category breadcrumb path' },
                            { name: 'parent_category', description: 'Parent of this category (if any)' },
                            { name: 'child_count', description: 'Number of child categories' },
                            { name: 'child_categories', description: 'List of direct child category names' },
                            { name: 'depth', description: 'Category depth level (0 = root)' },
                            { name: 'related_categories', description: 'Related categories (siblings, children, ancestors) with URLs for internal linking' }
                        ]
                    },
                    standardize_categories: {
                        title: 'Standardize Category Paths - Prompt Template',
                        default: acmsAiConfig.defaultPrompts.standardize_categories || "",
                        variables: [
                            { name: 'keyword', description: 'Search keyword that generated this queue' },
                            { name: 'products_json', description: 'JSON array of products with ASIN, title, brand, category_path' },
                            { name: 'existing_categories_json', description: 'JSON array of existing category paths in the system' }
                        ]
                    },
                    seo_category: {
                        title: 'Queue Category AI - Prompt Template',
                        default: acmsAiConfig.defaultPrompts.seo_category || "",
                        variables: [
                            { name: 'category_name', description: 'Name of the category (e.g., "Coffee Makers")' },
                            { name: 'category_path', description: 'Full category path (e.g., "Home & Kitchen > Kitchen & Dining > Coffee Makers")' },
                            { name: 'parents_context', description: 'Parent categories text if available' },
                            { name: 'products_context', description: 'List of products in this category for context' },
                            { name: 'product_count', description: 'Number of products in this category' },
                            { name: 'related_categories', description: 'Related categories (siblings, children, ancestors) with URLs for internal linking' },
                            { name: 'brand_links', description: 'Brand pages and brand-category pages available for internal linking' }
                        ]
                    },
                    seo_brand: {
                        title: 'SEO Brand Pages - Prompt Template',
                        default: acmsAiConfig.defaultPrompts.seo_brand || "",
                        variables: [
                            { name: 'brand_name', description: 'Name of the brand (e.g., "Sony", "Apple")' },
                            { name: 'brand_slug', description: 'URL slug for the brand (e.g., "sony", "apple")' },
                            { name: 'website_context', description: 'Official website URL if available' },
                            { name: 'categories_context', description: 'Product categories this brand is in (from product data)' },
                            { name: 'products_context', description: 'Sample products from this brand for context' },
                            { name: 'product_count', description: 'Total number of products from this brand' },
                            { name: 'brand_category_links', description: 'Category pages containing this brand\'s products with URLs for internal linking' }
                        ]
                    }
                },

                init() {
                    // Load saved prompts from DB (always populated via seed on activation)
                    const promptMap = {
                        enhance_asin: 'prompt_enhance_asin',
                        optimize_review: 'prompt_optimize_review',
                        generate_category: 'prompt_generate_category',
                        standardize_categories: 'prompt_standardize_categories',
                        seo_category: 'prompt_seo_category',
                        seo_brand: 'prompt_seo_brand',
                    };
                    for (const [type, settingKey] of Object.entries(promptMap)) {
                        if (this.settings[settingKey]) {
                            this.promptTemplates[type].current = this.settings[settingKey];
                        }
                    }
                    // Check connection on load if API key exists
                    if (this.settings.api_key) {
                        this.testConnection();
                    }

                    // Load AI jobs stats
                    this.refreshAiJobsStats();

                    // Load API Activity Log + start auto-refresh
                    this.loadApiLog();
                    if (this.apiLog.autoRefresh) {
                        this.apiLog.refreshTimer = setInterval(() => this.loadApiLog(), 30000);
                    }
                },

                refreshAiJobsStats() {
                    this.loadingAiJobs = true;
                    fetch(acmsAiConfig.restUrl + 'queue-stats', {
                        headers: { 'X-WP-Nonce': acmsAiConfig.nonce }
                    })
                    .then(r => r.json())
                    .then(result => {
                        if (result?.ai_jobs) {
                            this.aiJobsStats = {
                                pending: result.ai_jobs.pending || 0,
                                processing: result.ai_jobs.processing || 0,
                                completed: result.ai_jobs.completed || 0,
                                failed: result.ai_jobs.failed || 0
                            };
                            this.aiJobsCount = result.ai_jobs.total || 0;
                        }
                    })
                    .catch(e => console.error('Failed to load AI jobs stats:', e))
                    .finally(() => { this.loadingAiJobs = false; });
                },

                clearAiJobs() {
                    if (!confirm('TRUNCATE the acms_ai_jobs table? This deletes ALL rows and cannot be undone.')) {
                        return;
                    }
                    this.clearingAiJobs = true;
                    fetch(acmsAiConfig.restUrl + 'queue-cleanup', {
                        method: 'POST',
                        headers: { 'X-WP-Nonce': acmsAiConfig.nonce, 'Content-Type': 'application/json' },
                        body: JSON.stringify({ clear_all: true })
                    })
                    .then(r => r.json())
                    .then(result => {
                        if (result.success) {
                            this.toast('success', result.message || 'All AI jobs cleared');
                            this.refreshAiJobsStats();
                        } else {
                            this.toast('error', result.message || 'Failed to clear jobs');
                        }
                    })
                    .catch(e => this.toast('error', 'Failed to clear jobs'))
                    .finally(() => { this.clearingAiJobs = false; });
                },

                get filteredModels() {
                    return this.models.filter(m => m.tier === this.modelTab);
                },

                get connectionStatusText() {
                    return {
                        'unknown': 'Not tested',
                        'connected': 'Connected',
                        'error': 'Connection failed'
                    }[this.connectionStatus];
                },

                get selectedModelName() {
                    const model = this.models.find(m => m.id === this.settings.default_model);
                    return model ? model.name : this.settings.default_model;
                },

                get budgetPercent() {
                    if (!this.settings.monthly_budget) return 0;
                    return Math.min(100, (this.stats.currentSpend / this.settings.monthly_budget) * 100);
                },

                get budgetClass() {
                    if (this.budgetPercent >= 90) return 'danger';
                    if (this.budgetPercent >= 70) return 'warning';
                    return '';
                },

                formatNumber(num) {
                    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
                    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
                    return num.toString();
                },

                formatCurrency(amount) {
                    // Smart currency formatter for micro-transactions
                    if (amount >= 0.01) return amount.toFixed(2);
                    if (amount >= 0.0001) return amount.toFixed(4);
                    if (amount > 0) return amount.toFixed(6);
                    return '0.00';
                },

                async testConnection() {
                    if (!this.settings.api_key) {
                        this.toast('error', 'Please enter an API key first');
                        return;
                    }

                    this.testing = true;
                    this.connectionStatus = 'unknown';

                    try {
                        const response = await fetch('https://openrouter.ai/api/v1/models', {
                            headers: {
                                'Authorization': 'Bearer ' + this.settings.api_key
                            }
                        });

                        if (response.ok) {
                            this.connectionStatus = 'connected';
                            this.toast('success', 'API connection successful!');
                        } else {
                            this.connectionStatus = 'error';
                            this.toast('error', 'Invalid API key or connection failed');
                        }
                    } catch (error) {
                        this.connectionStatus = 'error';
                        this.toast('error', 'Connection failed: ' + error.message);
                    } finally {
                        this.testing = false;
                    }
                },

                async saveSettings() {
                    this.saving = true;

                    try {
                        const response = await fetch(acmsAiConfig.restUrl + 'settings', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-WP-Nonce': acmsAiConfig.nonce
                            },
                            body: JSON.stringify(this.settings)
                        });

                        const result = await response.json();
                        if (result.success) {
                            this.toast('success', 'Settings saved successfully');
                        } else {
                            this.toast('error', result.message || 'Failed to save settings');
                        }
                    } catch (error) {
                        this.toast('error', 'Failed to save settings');
                    } finally {
                        this.saving = false;
                    }
                },

                async runTest() {
                    if (!this.testPrompt.trim()) return;
                    if (!this.settings.api_key) {
                        this.toast('error', 'Please enter an API key first');
                        return;
                    }

                    this.testRunning = true;
                    this.testResult = { response: '', tokens: 0, cost: '0.0000', error: '', model: '' };

                    const model = this.models.find(m => m.id === this.testModel);

                    try {
                        const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
                            method: 'POST',
                            headers: {
                                'Authorization': 'Bearer ' + this.settings.api_key,
                                'Content-Type': 'application/json',
                                'HTTP-Referer': this.settings.site_url,
                                'X-Title': this.settings.site_name
                            },
                            body: JSON.stringify({
                                model: this.testModel,
                                messages: [{ role: 'user', content: this.testPrompt }],
                                max_tokens: 500
                            })
                        });

                        const text = await response.text();
                        let result;
                        try {
                            result = JSON.parse(text);
                        } catch (e) {
                            this.testResult.error = 'Invalid response from API';
                            return;
                        }

                        if (result.error) {
                            this.testResult.error = result.error.message || 'API error';
                        } else if (result.choices && result.choices[0]) {
                            this.testResult.response = result.choices[0].message.content;
                            this.testResult.tokens = result.usage?.total_tokens || 0;
                            this.testResult.model = model ? model.name : this.testModel;
                            // Estimate cost based on tokens
                            if (model && this.testResult.tokens) {
                                const pricePerMillion = parseFloat(model.price.replace(/[^0-9.]/g, ''));
                                this.testResult.cost = ((this.testResult.tokens / 1000000) * pricePerMillion).toFixed(6);
                            }
                        }
                    } catch (error) {
                        this.testResult.error = 'Network error: ' + error.message;
                    } finally {
                        this.testRunning = false;
                    }
                },

                copyResult() {
                    navigator.clipboard.writeText(this.testResult.response);
                    this.toast('success', 'Copied to clipboard');
                },

                // Prompt Modal Functions
                openPromptModal(type) {
                    const template = this.promptTemplates[type];
                    if (!template) return;

                    this.promptModal = {
                        show: true,
                        type: type,
                        title: template.title,
                        prompt: template.current || template.default,
                        variables: template.variables,
                        varsOpen: false,
                        showPreview: false,
                        previewText: '',
                        previewing: false,
                    };
                },

                closePromptModal() {
                    this.promptModal.show = false;
                },

                insertVariable(varName) {
                    const editor = this.$refs.codeEditor;
                    if (!editor) return;
                    editor.focus();
                    const variable = '{{' + varName + '}}';
                    document.execCommand('insertText', false, variable);
                },

                resetPromptToDefault() {
                    const template = this.promptTemplates[this.promptModal.type];
                    if (template) {
                        this.promptModal.prompt = template.default;
                        this.promptModal.showPreview = false;
                        this.toast('info', 'Reset to default template');
                    }
                },

                highlightPrompt(text) {
                    if (!text) return '';
                    return this._doHighlight(text);
                },

                _doHighlight(text) {
                    return text
                        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
                        .replace(/\{\{([^}]+)\}\}/g, '<span data-t="var">{{$1}}</span>')
                        .replace(/"([^"]+)"\s*:/g, '<span data-t="key">"$1"</span>:')
                        .replace(/:\s*"([^"]*?)"/g, ': <span data-t="str">"$1"</span>')
                        .replace(/\b(true|false|null)\b/g, '<span data-t="lit">$1</span>')
                        .replace(/^(#{1,4}\s.+)$/gm, '<span data-t="head">$1</span>')
                        .replace(/\*\*([^*]+)\*\*/g, '<span data-t="bold">$1</span>')
                        .replace(/^(={2,}\s.+\s={2,})$/gm, '<span data-t="sec">$1</span>')
                        .replace(/^(\s*-\s)/gm, '<span data-t="li">$1</span>')
                        .replace(/^([A-Z][A-Z\s]+:)$/gm, '<span data-t="note">$1</span>')
                        .replace(/\b(\d+(?:\.\d+)?)\b/g, '<span data-t="num">$1</span>');
                },

                editorApplyHighlight(el) {
                    const sel = window.getSelection();
                    let cursorOffset = 0;
                    let nodeStack, node, foundStart = false;
                    // Save cursor position as text offset
                    if (sel.rangeCount > 0 && el.contains(sel.anchorNode)) {
                        const range = sel.getRangeAt(0);
                        const preRange = document.createRange();
                        preRange.selectNodeContents(el);
                        preRange.setEnd(range.startContainer, range.startOffset);
                        cursorOffset = preRange.toString().length;
                    }
                    // Apply highlight
                    const text = el.innerText;
                    el.innerHTML = this._doHighlight(text);
                    // Restore cursor
                    if (cursorOffset > 0) {
                        const treeWalker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
                        let charCount = 0;
                        while (treeWalker.nextNode()) {
                            const nodeLen = treeWalker.currentNode.length;
                            if (charCount + nodeLen >= cursorOffset) {
                                const newRange = document.createRange();
                                newRange.setStart(treeWalker.currentNode, cursorOffset - charCount);
                                newRange.collapse(true);
                                sel.removeAllRanges();
                                sel.addRange(newRange);
                                break;
                            }
                            charCount += nodeLen;
                        }
                    }
                },

                async previewPrompt() {
                    this.promptModal.previewing = true;
                    try {
                        const response = await fetch(acmsAiConfig.restUrl + 'prompt-preview?type=' + this.promptModal.type, {
                            headers: { 'X-WP-Nonce': acmsAiConfig.nonce }
                        });
                        const result = await response.json();

                        if (result.success && result.data) {
                            let text = this.promptModal.prompt;
                            for (const [key, value] of Object.entries(result.data)) {
                                text = text.replaceAll('{{' + key + '}}', String(value));
                            }
                            this.promptModal.previewText = text;
                            this.promptModal.showPreview = true;
                        } else {
                            this.toast('error', result.message || 'No sample data found');
                        }
                    } catch (error) {
                        this.toast('error', 'Failed to load preview data');
                    } finally {
                        this.promptModal.previewing = false;
                    }
                },

                async savePromptTemplate() {
                    const type = this.promptModal.type;
                    this.promptTemplates[type].current = this.promptModal.prompt;
                    this.settings['prompt_' + type] = this.promptModal.prompt;

                    // Save to server
                    try {
                        const response = await fetch(acmsAiConfig.restUrl + 'settings', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-WP-Nonce': acmsAiConfig.nonce
                            },
                            body: JSON.stringify({ ['prompt_' + type]: this.promptModal.prompt })
                        });

                        const result = await response.json();
                        if (result.success) {
                            this.toast('success', 'Prompt template saved');
                            this.closePromptModal();
                        } else {
                            this.toast('error', result.message || 'Failed to save template');
                        }
                    } catch (error) {
                        this.toast('error', 'Failed to save template');
                    }
                },

                // === API Activity Log Methods ===

                async loadApiLog() {
                    this.apiLog.loading = true;
                    try {
                        const params = new URLSearchParams({ limit: '50' });
                        if (this.apiLog.filterType) params.set('type', this.apiLog.filterType);
                        if (this.apiLog.filterStatus) params.set('status', this.apiLog.filterStatus);

                        const response = await fetch(acmsAiConfig.restUrl + 'api-log?' + params.toString(), {
                            headers: { 'X-WP-Nonce': acmsAiConfig.nonce }
                        });
                        const result = await response.json();
                        if (result.items) {
                            this.apiLog.items = result.items;
                            this.apiLog.summary = result.summary || this.apiLog.summary;
                            this.apiLog.repeated = result.repeated_targets || [];
                        }
                    } catch (error) {
                        console.error('Failed to load API log:', error);
                    } finally {
                        this.apiLog.loading = false;
                    }
                },

                toggleApiLogRefresh() {
                    if (this.apiLog.refreshTimer) {
                        clearInterval(this.apiLog.refreshTimer);
                        this.apiLog.refreshTimer = null;
                    }
                    if (this.apiLog.autoRefresh) {
                        this.apiLog.refreshTimer = setInterval(() => this.loadApiLog(), 30000);
                    }
                },

                parseDate(dateStr) {
                    if (!dateStr) return null;
                    // ISO 8601 with timezone (from OpenRouter): 2026-02-12T05:15:27+00:00
                    if (dateStr.includes('T') && (dateStr.includes('+') || dateStr.endsWith('Z'))) {
                        return new Date(dateStr);
                    }
                    // MySQL datetime (from WP): 2026-02-12 05:15:27
                    return new Date(dateStr.replace(' ', 'T') + 'Z');
                },

                formatLogTime(dateStr) {
                    const d = this.parseDate(dateStr);
                    if (!d) return '-';
                    return d.toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
                },

                formatLogDate(dateStr) {
                    const d = this.parseDate(dateStr);
                    if (!d) return '';
                    const today = new Date();
                    if (d.toDateString() === today.toDateString()) return 'Today';
                    const yesterday = new Date(today); yesterday.setDate(today.getDate() - 1);
                    if (d.toDateString() === yesterday.toDateString()) return 'Yesterday';
                    return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
                },

                getTypeBadgeStyle(type) {
                    const styles = {
                        'generate_seo_category': 'background: rgba(59,130,246,0.12); color: #3b82f6;',
                        'generate_seo_brand': 'background: rgba(168,85,247,0.12); color: #a855f7;',
                        'enhance_asin': 'background: rgba(34,197,94,0.12); color: #22c55e;',
                        'optimize_review': 'background: rgba(245,158,11,0.12); color: #f59e0b;',
                        'generate_category': 'background: rgba(14,165,233,0.12); color: #0ea5e9;',
                        'standardize_categories': 'background: rgba(244,63,94,0.12); color: #f43f5e;',
                    };
                    return styles[type] || 'background: rgba(113,113,122,0.12); color: #71717a;';
                },

                toast(type, message) {
                    this.toastType = type;
                    this.toastMessage = message;
                    this.showToast = true;
                    setTimeout(() => { this.showToast = false; }, 4000);
                }
            }));
        });
        </script>
        <?php
    }

    /**
     * Get current settings
     */
    private function getSettings(): array
    {
        return [
            'api_key' => get_option('acms_ai_api_key', ''),
            'site_url' => get_option('acms_ai_site_url', home_url()),
            'site_name' => get_option('acms_ai_site_name', get_bloginfo('name')),
            'default_model' => get_option('acms_ai_default_model', 'google/gemini-3-flash-preview'),
            'monthly_budget' => (int) get_option('acms_ai_monthly_budget', 50),
            'enable_enhance_asin' => (bool) get_option('acms_ai_enhance_asin_enabled', false),
            'enable_optimize_review' => (bool) get_option('acms_ai_optimize_review_enabled', false),
            'enable_generate_category' => (bool) get_option('acms_ai_generate_category_enabled', false),
            'enable_seo_category' => (bool) get_option('acms_ai_seo_category_enabled', true),
            'enable_seo_brand' => (bool) get_option('acms_ai_seo_brand_enabled', true),
            'prompt_enhance_asin' => get_option('acms_ai_prompt_enhance_asin', ''),
            'prompt_optimize_review' => get_option('acms_ai_prompt_optimize_review', ''),
            'prompt_generate_category' => get_option('acms_ai_prompt_generate_category', ''),
            'prompt_standardize_categories' => get_option('acms_ai_prompt_standardize_categories', ''),
            'prompt_seo_category' => get_option('acms_ai_seo_category_prompt_template', ''),
            'prompt_seo_brand' => get_option('acms_ai_seo_brand_prompt_template', ''),
        ];
    }

    /**
     * Get usage stats
     */
    private function getStats(): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'acms_ai_usage';

        // Check if table exists
        $tableExists = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = %s AND table_name = %s",
            DB_NAME,
            $table
        ));

        if (!$tableExists) {
            return [
                'currentSpend' => 0.0,
                'totalTokens' => 0,
                'totalRequests' => 0,
            ];
        }

        $currentMonth = gmdate('Y-m-01');

        $stats = $wpdb->get_row($wpdb->prepare(
            "SELECT
                COALESCE(SUM(cost_total), 0) as total_cost,
                COALESCE(SUM(tokens_input + tokens_output), 0) as total_tokens,
                COALESCE(SUM(requests_count), 0) as total_requests
            FROM {$table}
            WHERE date >= %s",
            $currentMonth
        ));

        return [
            'currentSpend' => (float) ($stats->total_cost ?? 0),
            'totalTokens' => (int) ($stats->total_tokens ?? 0),
            'totalRequests' => (int) ($stats->total_requests ?? 0),
        ];
    }

    /**
     * Render CSS styles
     */
    private function renderStyles(): void
    {
        ?>
        /* CSS Variables - Dark Theme */
        :root {
            --primary: #3b82f6;
            --primary-hover: #2563eb;
            --primary-light: rgba(59, 130, 246, 0.1);
            --bg-base: #0a0a0b;
            --bg-surface: #111113;
            --bg-elevated: #18181b;
            --bg-hover: #1f1f23;
            --border: #27272a;
            --border-hover: #3f3f46;
            --text-primary: #fafafa;
            --text-secondary: #a1a1aa;
            --text-muted: #71717a;
            --success: #22c55e;
            --success-light: rgba(34, 197, 94, 0.1);
            --warning: #f59e0b;
            --warning-light: rgba(245, 158, 11, 0.1);
            --error: #ef4444;
            --error-light: rgba(239, 68, 68, 0.1);
            --radius-sm: 6px;
            --radius-md: 8px;
            --radius-lg: 12px;
            --shadow-lg: 0 10px 40px rgba(0, 0, 0, 0.5);
            --wp-admin-bar-height: 32px;
        }

        /* Reset */
        #adminmenuback, #adminmenuwrap { z-index: 1001 !important; }
        .acms-admin, .acms-admin *, .acms-admin *::before, .acms-admin *::after {
            box-sizing: border-box !important;
            max-width: none !important;
        }
        .acms-admin .card,
        .acms-admin .card-body,
        .acms-admin .form-group,
        .acms-admin .form-input,
        .acms-admin .model-tabs,
        .acms-admin .model-grid,
        .acms-admin .feature-list {
            width: 100% !important;
            max-width: 100% !important;
        }
        .acms-admin {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif !important;
            font-size: 14px !important;
            line-height: 1.5 !important;
            color: var(--text-primary) !important;
            -webkit-font-smoothing: antialiased;
        }
        [x-cloak] { display: none !important; }
        .sr-only { position: absolute; width: 1px; height: 1px; padding: 0; margin: -1px; overflow: hidden; clip: rect(0,0,0,0); border: 0; }

        /* Layout */
        html.wp-toolbar, body.wp-admin { overflow: hidden !important; height: 100vh !important; }
        .wrap:has(.acms-admin) { margin: 0 !important; padding: 0 !important; max-width: none !important; }
        .acms-admin {
            position: fixed;
            top: var(--wp-admin-bar-height);
            left: 160px;
            right: 0;
            bottom: 0;
            overflow-y: auto;
            background: var(--bg-base);
        }
        .folded .acms-admin { left: 36px; }
        @media (max-width: 960px) { .acms-admin { left: 36px; } }
        @media (max-width: 782px) { .acms-admin { left: 0; top: 46px; } }

        .app-container { max-width: 100%; padding: 32px 40px; }

        /* Page Header */
        .page-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
            margin-bottom: 32px;
        }
        .header-left { display: flex; align-items: center; gap: 12px; }
        .page-title {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .page-title i { font-size: 24px; color: var(--primary); }
        .page-title h1 { font-size: 24px; font-weight: 700; margin: 0; color: var(--text-primary); }
        .version-badge {
            padding: 4px 10px;
            background: var(--primary-light);
            color: var(--primary);
            font-size: 12px;
            font-weight: 600;
            border-radius: 20px;
        }
        .header-actions { display: flex; align-items: center; gap: 10px; }

        /* Content Grid */
        .content-grid {
            display: grid !important;
            grid-template-columns: 1fr 360px !important;
            gap: 32px !important;
            width: 100% !important;
        }
        @media (max-width: 1100px) {
            .content-grid { grid-template-columns: 1fr !important; }
            .sidebar-column { order: -1; }
        }
        .main-column {
            display: block !important;
            width: 100% !important;
            min-width: 0 !important;
        }
        .main-column .card { margin-bottom: 24px !important; }
        .main-column .card:last-child { margin-bottom: 0; }
        .sidebar-column { display: flex; flex-direction: column; gap: 20px; }

        /* Card */
        .card {
            display: block !important;
            width: 100% !important;
            max-width: none !important;
            min-width: 0 !important;
            padding: 0 !important;
            margin: 0 !important;
            background: var(--bg-surface) !important;
            border: 1px solid var(--border) !important;
            border-radius: var(--radius-lg) !important;
            box-shadow: none !important;
            overflow: hidden;
        }
        .card-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 18px 24px;
            border-bottom: 1px solid var(--border);
        }
        .card-header-collapsible {
            cursor: pointer;
            user-select: none;
            transition: background 0.15s ease;
        }
        .card-header-collapsible:hover {
            background: var(--bg-hover);
        }
        .collapse-icon {
            font-size: 16px;
            color: var(--text-muted);
            transition: transform 0.2s ease, color 0.15s ease;
        }
        .card-header-collapsible:hover .collapse-icon {
            color: var(--text-primary);
        }
        .card-title {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 15px;
            font-weight: 600;
            color: var(--text-primary);
            margin: 0;
        }
        .card-title i { color: var(--text-muted); font-size: 18px; }
        .card-body { padding: 24px; }
        .card-description { color: var(--text-muted); font-size: 13px; margin-bottom: 20px; }

        /* Connection Status */
        .connection-status {
            display: flex;
            align-items: center;
            gap: 6px;
            font-size: 12px;
            font-weight: 500;
            padding: 4px 10px;
            border-radius: 20px;
            background: var(--bg-elevated);
        }
        .connection-status .status-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: var(--text-muted);
        }
        .connection-status.connected .status-dot { background: var(--success); }
        .connection-status.connected { background: var(--success-light); color: var(--success); }
        .connection-status.error .status-dot { background: var(--error); }
        .connection-status.error { background: var(--error-light); color: var(--error); }

        /* Model Badge */
        .model-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            font-size: 12px;
            font-weight: 500;
            padding: 4px 12px;
            border-radius: 20px;
            background: var(--primary-light);
            color: var(--primary);
        }

        /* Buttons */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 10px 18px;
            font-size: 13px;
            font-weight: 500;
            border-radius: var(--radius-md);
            border: 1px solid transparent;
            cursor: pointer;
            transition: all 0.15s ease;
            white-space: nowrap;
        }
        .btn:disabled { opacity: 0.5; cursor: not-allowed; }
        .btn-primary { background: var(--primary); color: white; border-color: var(--primary); }
        .btn-primary:hover:not(:disabled) { background: var(--primary-hover); }
        .btn-secondary { background: var(--bg-elevated); color: var(--text-primary); border-color: var(--border); }
        .btn-secondary:hover:not(:disabled) { background: var(--bg-hover); border-color: var(--border-hover); }
        .btn-outline { background: transparent; color: var(--text-secondary); border-color: var(--border); }
        .btn-outline:hover:not(:disabled) { background: var(--bg-elevated); color: var(--text-primary); border-color: var(--border-hover); }
        .btn-sm { padding: 6px 12px; font-size: 12px; }
        .btn-icon-sm {
            padding: 6px;
            background: transparent;
            border: none;
            color: var(--text-muted);
            cursor: pointer;
            border-radius: var(--radius-sm);
        }
        .btn-icon-sm:hover { background: var(--bg-hover); color: var(--text-primary); }

        /* Form */
        .form-group { margin-bottom: 20px; }
        .form-group:last-child { margin-bottom: 0; }
        .form-label {
            display: block;
            margin-bottom: 8px;
            font-size: 13px;
            font-weight: 500;
            color: var(--text-primary);
        }
        .form-input, .form-textarea {
            width: 100%;
            padding: 10px 14px;
            font-size: 14px;
            color: var(--text-primary);
            background: var(--bg-base);
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
            transition: border-color 0.15s ease;
        }
        .form-input:focus, .form-textarea:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px var(--primary-light);
        }
        .form-input::placeholder, .form-textarea::placeholder { color: var(--text-muted); }
        .form-textarea { resize: vertical; min-height: 80px; }
        .form-hint { margin-top: 6px; font-size: 12px; color: var(--text-muted); }
        .form-hint a { color: var(--primary); text-decoration: none; }
        .form-hint a:hover { text-decoration: underline; }

        /* API Key Input */
        .api-key-input { position: relative; }
        .api-key-input .form-input { padding-right: 50px; font-family: monospace; }
        .key-toggle {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: var(--text-muted);
            cursor: pointer;
            padding: 4px;
        }
        .key-toggle:hover { color: var(--text-primary); }

        /* Model Tabs */
        .model-tabs {
            display: flex;
            gap: 8px;
            margin-bottom: 16px;
            padding: 4px;
            background: var(--bg-elevated);
            border-radius: var(--radius-md);
        }
        .model-tab {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            padding: 10px 16px;
            font-size: 13px;
            font-weight: 500;
            color: var(--text-muted);
            background: transparent;
            border: none;
            border-radius: var(--radius-sm);
            cursor: pointer;
            transition: all 0.15s ease;
        }
        .model-tab:hover { color: var(--text-primary); background: var(--bg-hover); }
        .model-tab.active { color: var(--text-primary); background: var(--bg-surface); box-shadow: 0 1px 3px rgba(0,0,0,0.3); }
        .model-tab i { font-size: 14px; }

        /* Model Grid */
        .model-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 16px;
        }
        .model-card {
            position: relative;
            display: flex;
            flex-direction: column;
            padding: 16px;
            background: var(--bg-elevated);
            border: 2px solid var(--border);
            border-radius: var(--radius-md);
            cursor: pointer;
            transition: all 0.15s ease;
        }
        .model-card:hover { border-color: var(--border-hover); }
        .model-card.selected { border-color: var(--primary); background: var(--primary-light); }
        .model-check {
            position: absolute;
            top: 8px;
            right: 8px;
            width: 20px;
            height: 20px;
            background: var(--primary);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 12px;
        }
        .model-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px; }
        .model-provider {
            font-size: 10px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            padding: 2px 6px;
            border-radius: 4px;
            background: var(--bg-hover);
            color: var(--text-muted);
        }
        .provider-openai { background: rgba(16, 163, 127, 0.15); color: #10a37f; }
        .provider-anthropic { background: rgba(212, 165, 116, 0.15); color: #d4a574; }
        .provider-google { background: rgba(66, 133, 244, 0.15); color: #4285f4; }
        .provider-meta { background: rgba(24, 119, 242, 0.15); color: #1877f2; }
        .provider-deepseek { background: rgba(99, 102, 241, 0.15); color: #6366f1; }
        .provider-xai { background: rgba(255, 255, 255, 0.1); color: #ffffff; }
        .model-badge {
            font-size: 9px;
            font-weight: 600;
            padding: 2px 6px;
            background: var(--success-light);
            color: var(--success);
            border-radius: 4px;
        }
        .model-name { font-size: 14px; font-weight: 600; color: var(--text-primary); margin-bottom: 8px; }
        .model-meta { display: flex; justify-content: space-between; font-size: 11px; color: var(--text-muted); }
        .model-price { color: var(--success); font-weight: 500; }

        /* Feature List */
        .feature-list { display: flex; flex-direction: column; gap: 16px; }
        .feature-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 20px;
            background: var(--bg-elevated);
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
            gap: 20px;
        }
        .feature-item-highlight {
            background: linear-gradient(135deg, rgba(245, 158, 11, 0.1) 0%, rgba(245, 158, 11, 0.05) 100%);
            border-color: rgba(245, 158, 11, 0.3);
        }
        .feature-item-highlight:hover {
            border-color: rgba(245, 158, 11, 0.5);
        }
        .feature-info { flex: 1; }
        .feature-label { font-size: 14px; font-weight: 500; color: var(--text-primary); margin-bottom: 4px; display: flex; align-items: center; }
        .feature-desc { font-size: 12px; color: var(--text-muted); }
        .feature-actions { display: flex; align-items: center; gap: 12px; }
        .btn-icon {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 36px;
            height: 36px;
            background: var(--bg-hover);
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
            color: var(--text-muted);
            cursor: pointer;
            transition: all 0.15s ease;
        }
        .btn-icon:hover { background: var(--bg-elevated); color: var(--text-primary); border-color: var(--border-hover); }
        .btn-icon i { font-size: 16px; }

        /* Toggle Switch */
        .acms-switch {
            position: relative;
            display: inline-block;
            width: 44px;
            height: 24px;
            flex-shrink: 0;
        }
        .acms-switch input[type="checkbox"] {
            position: absolute !important;
            opacity: 0 !important;
            width: 0 !important;
            height: 0 !important;
            margin: 0 !important;
            padding: 0 !important;
            border: none !important;
            pointer-events: none !important;
            clip: rect(0, 0, 0, 0) !important;
        }
        .acms-switch-slider {
            position: absolute;
            cursor: pointer;
            inset: 0;
            background: var(--bg-hover);
            border: 1px solid var(--border);
            border-radius: 24px;
            transition: all 0.2s ease;
        }
        .acms-switch-slider::before {
            position: absolute;
            content: "";
            height: 18px;
            width: 18px;
            left: 2px;
            bottom: 2px;
            background: var(--text-muted);
            border-radius: 50%;
            transition: all 0.2s ease;
        }
        .acms-switch input:checked + .acms-switch-slider { background: var(--primary); border-color: var(--primary); }
        .acms-switch input:checked + .acms-switch-slider::before { transform: translateX(20px); background: white; }

        /* Test Section */
        .test-actions { display: flex; align-items: center; gap: 16px; margin-top: 12px; }
        .test-meta { font-size: 12px; color: var(--text-muted); display: flex; align-items: center; gap: 8px; }
        .test-cost { color: var(--success); font-weight: 500; }
        .test-result {
            margin-top: 16px;
            background: var(--bg-elevated);
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
            overflow: hidden;
        }
        .result-header {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 14px;
            background: var(--bg-hover);
            border-bottom: 1px solid var(--border);
            font-size: 12px;
            font-weight: 600;
            color: var(--text-muted);
        }
        .result-header .btn-icon-sm { margin-left: auto; }
        .result-model {
            padding: 2px 8px;
            background: var(--primary-light);
            color: var(--primary);
            border-radius: 4px;
            font-size: 11px;
        }
        .result-content {
            padding: 14px;
            font-size: 13px;
            line-height: 1.6;
            color: var(--text-primary);
            white-space: pre-wrap;
            max-height: 200px;
            overflow-y: auto;
        }
        .test-error {
            margin-top: 12px;
            padding: 12px;
            background: var(--error-light);
            border: 1px solid var(--error);
            border-radius: var(--radius-md);
            color: var(--error);
            font-size: 13px;
        }

        /* Stats Mini */
        .stats-mini {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 12px;
            margin-bottom: 16px;
        }
        .stat-mini { text-align: center; }
        .stat-value { font-size: 20px; font-weight: 700; color: var(--text-primary); }
        .stat-label { font-size: 11px; color: var(--text-muted); margin-top: 2px; }

        /* Budget Section */
        .budget-section { padding-top: 16px; border-top: 1px solid var(--border); }
        .budget-header { display: flex; justify-content: space-between; font-size: 12px; color: var(--text-muted); margin-bottom: 8px; }
        .budget-bar { height: 8px; background: var(--bg-elevated); border-radius: 4px; overflow: hidden; }
        .budget-progress { height: 100%; background: var(--primary); border-radius: 4px; transition: width 0.3s ease; }
        .budget-progress.warning { background: var(--warning); }
        .budget-progress.danger { background: var(--error); }

        /* Cost Estimates */
        .cost-estimates {
            margin-top: 16px;
            padding: 14px;
            background: var(--bg-elevated);
            border-radius: var(--radius-md);
        }
        .cost-header { font-size: 12px; font-weight: 600; color: var(--text-muted); margin-bottom: 10px; }
        .cost-row {
            display: flex;
            justify-content: space-between;
            font-size: 13px;
            color: var(--text-secondary);
            padding: 4px 0;
        }

        /* Action Scheduler Status Badge */
        .as-status-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 4px 10px;
            font-size: 11px;
            font-weight: 600;
            border-radius: 20px;
        }
        .as-status-badge.as-active {
            background: var(--success-light);
            color: var(--success);
        }
        .as-status-badge.as-inactive {
            background: var(--warning-light);
            color: var(--warning);
        }

        /* Queue Stats Grid */
        .queue-stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 10px;
            margin-bottom: 16px;
        }
        .queue-stat-card {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 12px;
            background: var(--bg-elevated);
            border-radius: var(--radius-md);
        }
        .queue-stat-icon {
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: var(--radius-sm);
            font-size: 16px;
        }
        .queue-stat-icon.pending { background: var(--warning-light); color: var(--warning); }
        .queue-stat-icon.processing { background: var(--info-light); color: var(--info); }
        .queue-stat-icon.completed { background: var(--success-light); color: var(--success); }
        .queue-stat-icon.failed { background: var(--error-light); color: var(--error); }
        .queue-stat-info { display: flex; flex-direction: column; }
        .queue-stat-value { font-size: 18px; font-weight: 700; color: var(--text-primary); line-height: 1.2; }
        .queue-stat-label { font-size: 11px; color: var(--text-muted); }

        /* Server Cron Status Box */
        .cron-status-box {
            padding: 12px 14px;
            border-radius: var(--radius-md);
            margin-bottom: 16px;
        }
        .cron-status-box.cron-ok {
            background: var(--success-light);
            border: 1px solid rgba(34, 197, 94, 0.3);
        }
        .cron-status-box.cron-warning {
            background: var(--warning-light);
            border: 1px solid rgba(245, 158, 11, 0.3);
        }
        .cron-status-header {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 13px;
            font-weight: 600;
        }
        .cron-ok .cron-status-header { color: var(--success); }
        .cron-warning .cron-status-header { color: var(--warning); }
        .cron-status-detail {
            font-size: 11px;
            color: var(--text-muted);
            margin-top: 4px;
            margin-left: 24px;
        }

        /* Server Cron Setup Guide */
        .cron-setup-guide {
            background: var(--bg-elevated);
            border-radius: var(--radius-md);
            padding: 14px;
            margin-bottom: 16px;
            border: 1px dashed var(--border);
        }
        .guide-header {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 13px;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 12px;
        }
        .guide-steps { display: flex; flex-direction: column; gap: 14px; }
        .guide-step {
            display: flex;
            gap: 12px;
        }
        .step-num {
            width: 24px;
            height: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: var(--primary);
            color: white;
            font-size: 12px;
            font-weight: 600;
            border-radius: 50%;
            flex-shrink: 0;
        }
        .step-content { flex: 1; }
        .step-content strong { font-size: 13px; color: var(--text-primary); display: block; margin-bottom: 4px; }
        .step-content p { font-size: 12px; color: var(--text-secondary); margin: 4px 0; }
        .step-content code { font-size: 11px; }
        .code-block {
            display: block;
            padding: 8px 10px;
            background: var(--bg-base);
            border: 1px solid var(--border);
            border-radius: var(--radius-sm);
            font-family: 'SF Mono', Monaco, Consolas, monospace;
            font-size: 11px;
            color: var(--text-secondary);
            word-break: break-all;
            margin: 6px 0;
        }
        .guide-hint {
            font-size: 11px;
            color: var(--text-muted);
            font-style: italic;
        }

        /* Queue Actions */
        .queue-actions {
            display: flex;
            gap: 8px;
        }
        .queue-actions .btn { flex: 1; justify-content: center; }

        /* Legacy Queue Stats (keep for compatibility) */
        .queue-stats {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 8px;
            margin-top: 14px;
            padding-top: 14px;
            border-top: 1px solid var(--border);
        }
        .queue-stat {
            text-align: center;
            padding: 8px;
            background: var(--bg-elevated);
            border-radius: var(--radius-sm);
        }
        .queue-label {
            display: block;
            font-size: 10px;
            color: var(--text-muted);
            margin-bottom: 4px;
        }
        .queue-value {
            font-size: 18px;
            font-weight: 700;
            color: var(--text-primary);
        }

        /* Help Content */
        .help-content { font-size: 13px; }
        .help-section { margin-bottom: 16px; }
        .help-section:last-child { margin-bottom: 0; }
        .help-section h4 { font-size: 13px; font-weight: 600; color: var(--text-primary); margin: 0 0 8px; }
        .help-section ol, .help-section ul { margin: 0; padding-left: 18px; color: var(--text-secondary); }
        .help-section li { margin-bottom: 4px; }
        .help-section a { color: var(--primary); text-decoration: none; }
        .help-section a:hover { text-decoration: underline; }
        .help-links {
            display: flex;
            flex-direction: column;
            gap: 8px;
            margin-top: 16px;
            padding-top: 16px;
            border-top: 1px solid var(--border);
        }
        .help-link {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 10px 12px;
            background: var(--bg-elevated);
            border-radius: var(--radius-md);
            color: var(--text-secondary);
            text-decoration: none;
            font-size: 13px;
            transition: all 0.15s ease;
        }
        .help-link:hover { background: var(--bg-hover); color: var(--text-primary); }
        .help-link i { font-size: 16px; color: var(--primary); }

        /* Toast */
        .toast-container { position: fixed; bottom: 20px; right: 20px; z-index: 10001; }
        .toast {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 14px 18px;
            background: var(--bg-elevated);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-lg);
            font-size: 14px;
            color: var(--text-primary);
        }
        .toast-success i { color: var(--success); }
        .toast-warning i { color: var(--warning); }
        .toast-error i { color: var(--error); }
        .toast-info i { color: var(--primary); }

        /* =====================================================
           PROMPT MODAL - Completely isolated styles
           Prefix: acmsai-pm- (AffiliateCMS AI Prompt Modal)
           ===================================================== */
        .acmsai-pm-overlay {
            all: initial !important;
            position: fixed !important;
            top: 0 !important;
            left: 0 !important;
            right: 0 !important;
            bottom: 0 !important;
            background: rgba(0,0,0,0.8) !important;
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            z-index: 999999 !important;
            padding-left: 160px !important;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif !important;
            font-size: 14px !important;
            line-height: 1.5 !important;
            color: #f4f4f5 !important;
            -webkit-font-smoothing: antialiased !important;
        }
        @media (max-width: 960px) {
            .acmsai-pm-overlay { padding-left: 36px !important; }
        }
        body.folded .acmsai-pm-overlay { padding-left: 36px !important; }
        .acmsai-pm-box {
            all: initial !important;
            display: flex !important;
            flex-direction: column !important;
            width: 100% !important;
            max-width: 1200px !important;
            height: calc(100vh - 60px) !important;
            max-height: calc(100vh - 60px) !important;
            background: #09090b !important;
            border: 1px solid #27272a !important;
            border-radius: 16px !important;
            box-shadow: 0 25px 50px rgba(0,0,0,0.6) !important;
            overflow: hidden !important;
            font-family: inherit !important;
            font-size: inherit !important;
            line-height: inherit !important;
            color: inherit !important;
        }
        .acmsai-pm-head {
            all: initial !important;
            display: flex !important;
            align-items: center !important;
            justify-content: space-between !important;
            padding: 20px 24px !important;
            background: #09090b !important;
            border-bottom: 1px solid #27272a !important;
            font-family: inherit !important;
            color: inherit !important;
        }
        .acmsai-pm-headtitle {
            all: initial !important;
            display: flex !important;
            align-items: center !important;
            gap: 12px !important;
            font-family: inherit !important;
            font-size: 16px !important;
            font-weight: 600 !important;
            color: #f4f4f5 !important;
        }
        .acmsai-pm-headtitle i {
            color: #3b82f6 !important;
            font-size: 20px !important;
        }
        .acmsai-pm-close {
            all: initial !important;
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            width: 36px !important;
            height: 36px !important;
            background: #18181b !important;
            border-radius: 8px !important;
            cursor: pointer !important;
            color: #71717a !important;
            font-family: inherit !important;
        }
        .acmsai-pm-close:hover {
            background: #27272a !important;
            color: #f4f4f5 !important;
        }
        .acmsai-pm-headright {
            all: initial !important;
            display: flex !important;
            align-items: center !important;
            gap: 10px !important;
            font-family: inherit !important;
            color: inherit !important;
        }
        .acmsai-pm-btncompact {
            padding: 8px 14px !important;
            font-size: 12px !important;
        }
        .acmsai-pm-body {
            all: initial !important;
            display: flex !important;
            flex-direction: column !important;
            gap: 12px !important;
            padding: 16px 24px !important;
            background: #09090b !important;
            flex: 1 !important;
            min-height: 0 !important;
            font-family: inherit !important;
            color: inherit !important;
        }
        .acmsai-pm-editor {
            all: initial !important;
            display: flex !important;
            flex-direction: column !important;
            flex: 1 !important;
            min-height: 0 !important;
            font-family: inherit !important;
            color: inherit !important;
        }
        .acmsai-pm-label {
            all: initial !important;
            display: block !important;
            margin-bottom: 6px !important;
            font-family: inherit !important;
            font-size: 13px !important;
            font-weight: 500 !important;
            color: #a1a1aa !important;
        }
        /* Contenteditable code editor */
        .acmsai-pm-code {
            flex: 1 !important;
            min-height: 0 !important;
            padding: 14px 16px !important;
            margin: 0 !important;
            background: #111113 !important;
            color: #a1a1aa !important;
            border: 1px solid #3f3f46 !important;
            border-radius: 10px !important;
            font-family: 'SF Mono', Monaco, Consolas, 'Courier New', monospace !important;
            font-size: 13px !important;
            line-height: 1.7 !important;
            box-sizing: border-box !important;
            overflow: auto !important;
            white-space: pre-wrap !important;
            word-wrap: break-word !important;
            word-break: break-word !important;
            tab-size: 4 !important;
            outline: none !important;
            cursor: text !important;
            -webkit-user-modify: read-write-plaintext-only !important;
        }
        .acmsai-pm-code:focus {
            border-color: #3b82f6 !important;
            box-shadow: 0 0 0 3px rgba(59,130,246,0.15) !important;
        }
        .acmsai-pm-code::selection, .acmsai-pm-code *::selection {
            background: rgba(59,130,246,0.35) !important;
            color: #f4f4f5 !important;
        }
        .acmsai-pm-code span { all: unset !important; }
        /* Preview modal content */
        .acmsai-pm-preview {
            all: initial !important;
            display: block !important;
            flex: 1 !important;
            min-height: 0 !important;
            padding: 14px 16px !important;
            background: #111113 !important;
            border: 1px solid #3f3f46 !important;
            border-radius: 10px !important;
            font-family: 'SF Mono', Monaco, Consolas, 'Courier New', monospace !important;
            font-size: 13px !important;
            line-height: 1.7 !important;
            color: #a1a1aa !important;
            box-sizing: border-box !important;
            overflow: auto !important;
            white-space: pre-wrap !important;
            word-wrap: break-word !important;
        }
        /* Syntax highlight tokens */
        .acmsai-pm-code [data-t="var"], .acmsai-pm-preview [data-t="var"] { color: #60a5fa !important; background: rgba(96,165,250,0.12) !important; padding: 1px 4px !important; border-radius: 3px !important; font-weight: 600 !important; }
        .acmsai-pm-code [data-t="key"], .acmsai-pm-preview [data-t="key"] { color: #67e8f9 !important; }
        .acmsai-pm-code [data-t="str"], .acmsai-pm-preview [data-t="str"] { color: #86efac !important; }
        .acmsai-pm-code [data-t="lit"], .acmsai-pm-preview [data-t="lit"] { color: #c084fc !important; font-weight: 500 !important; }
        .acmsai-pm-code [data-t="num"], .acmsai-pm-preview [data-t="num"] { color: #fbbf24 !important; }
        .acmsai-pm-code [data-t="head"], .acmsai-pm-preview [data-t="head"] { color: #fb923c !important; font-weight: 700 !important; }
        .acmsai-pm-code [data-t="bold"], .acmsai-pm-preview [data-t="bold"] { color: #e4e4e7 !important; font-weight: 700 !important; }
        .acmsai-pm-code [data-t="sec"], .acmsai-pm-preview [data-t="sec"] { color: #f472b6 !important; font-weight: 700 !important; }
        .acmsai-pm-code [data-t="li"], .acmsai-pm-preview [data-t="li"] { color: #fbbf24 !important; }
        .acmsai-pm-code [data-t="note"], .acmsai-pm-preview [data-t="note"] { color: #f472b6 !important; font-weight: 600 !important; }
        .acmsai-pm-loading { opacity: 0.7 !important; pointer-events: none !important; }
        @keyframes acmsai-spin { to { transform: rotate(360deg); } }
        .acmsai-spin { animation: acmsai-spin 1s linear infinite !important; display: inline-block !important; }
        .acmsai-pm-vars {
            all: initial !important;
            display: block !important;
            padding: 16px !important;
            background: #18181b !important;
            border: 1px solid #27272a !important;
            border-radius: 10px !important;
            font-family: inherit !important;
            color: inherit !important;
        }
        .acmsai-pm-varstitle {
            all: initial !important;
            display: flex !important;
            align-items: center !important;
            gap: 8px !important;
            margin-bottom: 0 !important;
            font-family: inherit !important;
            font-size: 13px !important;
            font-weight: 600 !important;
            color: #f4f4f5 !important;
        }
        .acmsai-pm-varstitle i {
            color: #3b82f6 !important;
            font-size: 16px !important;
        }
        .acmsai-pm-varslist {
            all: initial !important;
            display: flex !important;
            flex-wrap: wrap !important;
            gap: 8px !important;
            margin-top: 14px !important;
            margin-bottom: 14px !important;
            font-family: inherit !important;
        }
        .acmsai-pm-tag {
            all: initial !important;
            display: inline-flex !important;
            align-items: center !important;
            padding: 7px 14px !important;
            background: #27272a !important;
            border: 1px solid #3f3f46 !important;
            border-radius: 20px !important;
            font-family: 'SF Mono', Monaco, Consolas, monospace !important;
            font-size: 12px !important;
            color: #60a5fa !important;
            cursor: pointer !important;
        }
        .acmsai-pm-tag:hover {
            background: rgba(59,130,246,0.15) !important;
            border-color: #3b82f6 !important;
            color: #93c5fd !important;
        }
        .acmsai-pm-varshelp {
            all: initial !important;
            display: block !important;
            padding-top: 14px !important;
            border-top: 1px solid #27272a !important;
            font-family: inherit !important;
            font-size: 12px !important;
            color: #71717a !important;
        }
        .acmsai-pm-foot {
            all: initial !important;
            display: flex !important;
            align-items: center !important;
            justify-content: space-between !important;
            padding: 16px 24px !important;
            background: #0a0a0b !important;
            border-top: 1px solid #27272a !important;
            font-family: inherit !important;
            color: inherit !important;
        }
        .acmsai-pm-footright {
            all: initial !important;
            display: flex !important;
            align-items: center !important;
            gap: 10px !important;
            font-family: inherit !important;
        }
        .acmsai-pm-btnmain {
            all: initial !important;
            display: inline-flex !important;
            align-items: center !important;
            gap: 8px !important;
            padding: 10px 20px !important;
            background: #3b82f6 !important;
            border-radius: 8px !important;
            font-family: inherit !important;
            font-size: 13px !important;
            font-weight: 500 !important;
            color: #fff !important;
            cursor: pointer !important;
        }
        .acmsai-pm-btnmain:hover {
            background: #2563eb !important;
        }
        .acmsai-pm-btnalt {
            all: initial !important;
            display: inline-flex !important;
            align-items: center !important;
            gap: 8px !important;
            padding: 10px 16px !important;
            background: #27272a !important;
            border: 1px solid #3f3f46 !important;
            border-radius: 8px !important;
            font-family: inherit !important;
            font-size: 13px !important;
            font-weight: 500 !important;
            color: #e4e4e7 !important;
            cursor: pointer !important;
        }
        .acmsai-pm-btnalt:hover {
            background: #3f3f46 !important;
            border-color: #52525b !important;
        }

        /* Animations */
        .animate-spin { animation: spin 1s linear infinite; }
        @keyframes spin { to { transform: rotate(360deg); } }
        <?php
    }
}
