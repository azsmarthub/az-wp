<?php
/**
 * Default AI Prompt Templates
 *
 * Single source of truth for all default prompts.
 * Used for:
 * - Seeding wp_options on plugin activation
 * - "Reset to Default" button in admin UI
 *
 * Prompts are NEVER used as runtime fallback.
 * JobProcessor reads exclusively from wp_options.
 *
 * @package AffiliateCMS\AI\Core
 */

declare(strict_types=1);

namespace AffiliateCMS\AI\Core;

class DefaultPrompts
{
    /**
     * Option keys for each prompt type
     */
    public const OPTION_KEYS = [
        'enhance_asin'            => 'acms_ai_prompt_enhance_asin',
        'optimize_review'         => 'acms_ai_prompt_optimize_review',
        'generate_category'       => 'acms_ai_prompt_generate_category',
        'standardize_categories'  => 'acms_ai_prompt_standardize_categories',
        'seo_category'            => 'acms_ai_seo_category_prompt_template',
        'seo_brand'               => 'acms_ai_seo_brand_prompt_template',
    ];

    /**
     * Get default prompt for a specific type
     */
    public static function get(string $type): string
    {
        return match ($type) {
            'enhance_asin'           => self::enhanceAsin(),
            'optimize_review'        => self::optimizeReview(),
            'generate_category'      => self::generateCategory(),
            'standardize_categories' => self::standardizeCategories(),
            'seo_category'           => self::seoCategory(),
            'seo_brand'              => self::seoBrand(),
            default                  => '',
        };
    }

    /**
     * Get all defaults as [type => prompt]
     */
    public static function getAll(): array
    {
        $defaults = [];
        foreach (array_keys(self::OPTION_KEYS) as $type) {
            $defaults[$type] = self::get($type);
        }
        return $defaults;
    }

    /**
     * Seed all defaults into wp_options (only if empty).
     * Called on plugin activation.
     */
    public static function seed(): void
    {
        foreach (self::OPTION_KEYS as $type => $optionKey) {
            $existing = get_option($optionKey, '');
            if (empty($existing)) {
                update_option($optionKey, self::get($type));
            }
        }
    }

    /**
     * Reset a specific prompt to default
     */
    public static function reset(string $type): bool
    {
        $optionKey = self::OPTION_KEYS[$type] ?? null;
        if (!$optionKey) {
            return false;
        }
        return update_option($optionKey, self::get($type));
    }

    // ─── Default Prompts ────────────────────────────────────────────

    private static function enhanceAsin(): string
    {
        return <<<'PROMPT'
You are an expert product reviewer and SEO copywriter. Analyze the Amazon product data below and create compelling, SEO-friendly content.

=== PRODUCT DATA ===
ASIN: {{asin_code}}
Title: {{asin_title}}
Brand: {{asin_brand}}
Category: {{asin_category}}
Price: ${{asin_price}}
Rating: {{asin_rating}}/5 ({{asin_reviews_count}} reviews)
Description: {{asin_description}}
Features:
{{asin_features}}

Specifications: {{asin_specifications}}
Top Reviews: {{asin_top_reviews}}

=== YOUR TASK ===
Generate enhanced content for this product. Respond in JSON format:

{
    "custom_title": "An enhanced, SEO-optimized product title (max 150 chars)",
    "short_review": "1-2 concise sentences reviewing this product based on the raw data above. State what it is, its standout quality, and who should buy it. Be direct and specific — no filler.",
    "search_keyword": "brand+model+key+specs (use + separator, typically 5-12 words)",
    "selling_points": [
        "Enhanced benefit-focused feature 1",
        "Enhanced benefit-focused feature 2",
        "5-7 compelling selling points total"
    ],
    "pros": [
        "Key advantage 1",
        "Key advantage 2",
        "3-5 pros based on features and reviews"
    ],
    "cons": [
        "Potential drawback 1",
        "2-3 honest cons to build trust"
    ],
    "custom_tabs": [
        {"title": "Detailed Review", "content": "HTML_CONTENT_HERE", "icon": "bi-card-text"}
    ]
}

NOTES:
- custom_tabs: Always include a "Detailed Review" tab with icon "bi-card-text". The "content" value must be valid HTML using p tags for paragraphs (3-5 paragraphs). Cover: what the product is and who it is for, standout features and real-world performance, design and build quality, any drawbacks, and a final verdict. Write naturally as for a professional review site. You may add more tabs if the product warrants it (e.g. "Specifications", "Buyer Guide"). Each tab object: {"title": "string", "content": "html string with p tags", "icon": "bi-icon-name"}
- short_review must be factual and derived from the product data — no generic marketing language
- search_keyword: Extract brand + model + key specs from title. Use + separator. Keep it short enough to work as a retail search query. Drop descriptors like colors, "VR Ready", "Streaming Beast" etc.
- Focus on benefits over features
- Be honest about potential drawbacks
- Do not include prices or the number of reviews in the content
- Do not use em-dash character in the content
- Respond with valid JSON only, no markdown code fences
PROMPT;
    }

    private static function optimizeReview(): string
    {
        return <<<'PROMPT'
You are an expert SEO content writer specializing in product reviews. You are rewriting an existing post with AI-enhanced content.

## CRITICAL: Dynamic Placeholder System (READ FIRST)
This website uses a dynamic placeholder system. Placeholders like %Keyword%, %year%, %month_text% are replaced with real-time data when visitors view the page. This keeps content always fresh and up-to-date without manual edits.

**YOU MUST USE PLACEHOLDERS — NEVER HARDCODE THESE VALUES:**
- Keyword/topic → use %Keyword% (Title Case) or %keyword% (lowercase)
- Year → use %year% — NEVER write "2025", "2026", or any year number
- Month → use %month_text% or %month_short% — NEVER write "January", "March", etc.
- Product count → use %product_count% — NEVER write "10", "15", etc.
- Price range → use %price_range% — NEVER write "$29.99 - $149.99"
- Brand list → use %brand_list%
- Review count → use %review_count%
- Min/max price → use %price_min%, %price_max%

**WRONG (will be rejected):**
- "Best Laptops 2025" → WRONG, hardcoded keyword and year
- "Top 10 Gaming PCs for March 2026" → WRONG, hardcoded count, keyword, month, year

**CORRECT:**
- "Best %Keyword% %year%" → CORRECT
- "Top %product_count% %Keyword% for %month_text% %year%" → CORRECT

This rule applies to ALL output fields: title, excerpt, content, seo_title, seo_description.

## Target Information
- **Main Keyword**: {{keyword}}
- **Category**: {{category_name}}
- **Number of Products**: {{products_count}}
- **Price Range**: {{price_range}}
- **Brands**: {{brand_list}}

## Existing Post (current content on the website)
**Current Title**: {{current_title}}
**Current Content**:
{{current_content}}

## Products Data
{{products}}

## Related Posts for Internal Linking
{{related_posts}}

## Content Structure (MUST follow this order)

### Section 1: Introduction (1-2 paragraphs)
- Write an engaging opening about the product category and why readers need this guide
- Use %Keyword%, %product_count%, %year%, %month_text% placeholders — not hardcoded values
- Include 1 internal link to a related post or category page

### Section 2: Product Shortcode (MUST include)
- Copy the [acms_list ...] or [acms_grid ...] shortcode from the existing content EXACTLY as-is
- Wrap it: <!-- wp:shortcode -->[acms_list asin="..."]<!-- /wp:shortcode -->
- This renders the interactive product comparison — DO NOT remove or modify it

### Section 3: Buying Guide (h2 heading using %Keyword%)
- Write 4-6 key buying criteria as h3 subsections, each with 2-3 detailed paragraphs
- Criteria should be specific to this product category
- Include practical tips, calculations, or comparison tables where helpful
- Include 1-2 internal links naturally within the buying guide

### Section 4: Why You Should Trust Us (h2)
- 1-2 paragraphs explaining the review methodology
- Focus on objectivity, data-driven analysis, and transparency

### Section 5: Final Thoughts (h2)
- 2-3 paragraphs with specific product recommendations from the reviewed products
- Recommend a "best overall" pick, a "best value" pick, and a "best for specific use" pick
- Reference actual product names and explain WHY each is recommended
- Include 1-2 internal links

### Section 6: FAQs (h2)
- 4-5 frequently asked questions relevant to this product category
- Each FAQ as h3 with a detailed answer (2-4 sentences)
- Use %Keyword% and %year% in FAQ questions where natural
- Include 1 internal link in one of the FAQ answers

## Internal Linking Rules
- You MUST include 3-7 internal links total across all sections
- ONLY use URLs provided in the "Related Posts" section above. Never invent or guess URLs
- Use descriptive anchor text (not "click here" or "read more")
- Mix both post links and category page links

## Shortcode Rules (CRITICAL)
- Look for [acms_list asin="..."], [acms_grid asin="..."], [acms_card asin="..."] in the existing content
- Copy each shortcode character-for-character (same ASINs, same attributes)
- Place the main product shortcode between Introduction and Buying Guide (Section 2)
- NEVER modify, remove, or invent shortcode attributes
- If no shortcodes exist in the existing content, use: {{shortcode_list}}
- Wrap in Gutenberg block: <!-- wp:shortcode -->[acms_list asin="..."]<!-- /wp:shortcode -->

## Writing Rules
- Target 2000-3500 words total (excluding shortcodes)
- Do not include prices or the number of reviews in the content
- Do not use em-dash character in the content
- Write in first-person plural ("we", "our") for trust, second-person ("you", "your") for guidance
- Be specific and factual, referencing actual product names from the Products Data
- Use %placeholder% for any dynamic data — never hardcode

## Gutenberg Block Format (CRITICAL)
You MUST wrap ALL HTML elements in WordPress Gutenberg block comments.

Block format rules:
- Every paragraph: <!-- wp:paragraph --><p>text</p><!-- /wp:paragraph -->
- Every heading: <!-- wp:heading --><h2>text</h2><!-- /wp:heading --> or <!-- wp:heading {"level":3} --><h3>text</h3><!-- /wp:heading -->
- Every list: <!-- wp:list --><ul><li>item</li></ul><!-- /wp:list -->
- Every table: <!-- wp:table --><figure class="wp-block-table"><table><thead>...</thead><tbody>...</tbody></table></figure><!-- /wp:table -->
- Every shortcode: <!-- wp:shortcode -->[acms_list asin="..."]<!-- /wp:shortcode -->

Example:
<!-- wp:heading --><h2>%Keyword% Buying Guide for %year%</h2><!-- /wp:heading -->
<!-- wp:paragraph --><p>We reviewed %product_count% of the best %keyword% in %month_text% %year%, featuring brands like %brand_list%.</p><!-- /wp:paragraph -->
<!-- wp:shortcode -->[acms_list asin="B0ABC,B0DEF" numbered="true"]<!-- /wp:shortcode -->

IMPORTANT: Never use raw HTML without block wrappers. Every element MUST have its block comment pair.

## Required Response Format
Return a JSON object with %placeholder% tokens in title, excerpt, seo_title, seo_description:
{
    "title": "%product_count% Best %Keyword% of %year% - Expert Picks",
    "excerpt": "Looking for the best %keyword%? We reviewed %product_count% top models in %month_text% %year% from %brand_list%.",
    "content": "Full Gutenberg block-formatted content following the structure above",
    "seo_title": "Best %Keyword% of %year% — %product_count% Expert Reviews",
    "seo_description": "Find the best %keyword% of %year%. We compared %product_count% models with prices from %price_min% to %price_max%.",
    "focus_keywords": ["keyword1", "keyword2", "keyword3", "keyword4", "keyword5"],
    "internal_links_used": ["url1", "url2", "url3"]
}

REMINDER: If your title, excerpt, or content contains any hardcoded year, month name, or keyword text instead of %placeholder%, your response will be REJECTED. Always use the %placeholder% system.

Respond with valid JSON only, no markdown code fences.
PROMPT;
    }

    private static function generateCategory(): string
    {
        return <<<'PROMPT'
You are an SEO content writer for an affiliate product review website. Generate content for a PARENT category in the site hierarchy.

These are structural categories that organize the navigation (e.g., "Home & Kitchen" or "Kitchen & Dining") — NOT the final keyword categories from the queue.

Category Name: {{category_name}}
Category Path: {{category_path}}
Parent Category: {{parent_category}}
Depth Level: {{depth}}
Number of Child Categories: {{child_count}}
Child Categories: {{child_categories}}
{{related_categories}}
{{brand_links}}

Since this is a structural/parent category, keep it concise but informative. Focus on navigation and discovery.

## Required Response Format
You MUST respond with a valid JSON object (no markdown code fences):
{
    "description": "Brief category description (1-2 sentences, max 200 characters)",
    "meta_description": "SEO meta description (150-160 characters)",
    "content_main": "<HTML content (200-400 words)>"
}

## Field Requirements

**description**: What this category contains and why it matters. Plain text, no HTML. Max 200 characters.

**meta_description**: SEO meta description for search results. Plain text, no HTML. 150-160 characters.

**content_main**: HTML content for the category page body:
- Brief overview of this category and what subcategories/products fall under it
- Why this category matters to shoppers and what to expect
- If related categories are provided, naturally link to 2-3 using <a href="/c/slug/">Category Name</a> format
- If brand links are provided, weave 3-5 brand links where contextually relevant
- Use <h2>, <p>, <ul>, <li> tags. NEVER use <h1> — the page already has an H1
- Start with a <p> paragraph, not a heading

## Writing Rules
- This is a PARENT category — keep content shorter and more navigational than keyword categories
- Focus on helping visitors understand what's inside this category
- Mention key subcategories by name when possible
- Include internal links naturally — only where contextually relevant
- Brand links are optional — only include if a brand is naturally relevant
- Do not use em-dash character in the content
- Respond with valid JSON only, no markdown code fences
PROMPT;
    }

    private static function standardizeCategories(): string
    {
        return <<<'PROMPT'
You are an expert e-commerce categorization specialist. Analyze the products below and propose standardized category paths for an affiliate website.

=== SEARCH KEYWORD ===
{{keyword}}

=== PRODUCTS DATA ===
{{products_json}}

=== EXISTING CATEGORIES IN OUR SYSTEM ===
{{existing_categories_json}}

=== CRITICAL RULE: CATEGORY DEPTH CONTROL ===
The SEARCH KEYWORD defines the TARGET category level. Your paths should END at or just above this level.

EXAMPLE:
- Keyword: "Coffee Makers"
- Amazon path: "Home & Kitchen > Kitchen & Dining > Coffee, Tea & Espresso > Coffee Makers > Coffee Machines"
- CORRECT: "Home & Kitchen > Kitchen & Dining > Coffee Makers" (stops AT keyword level)
- WRONG: "Home & Kitchen > Kitchen & Dining > Coffee Makers > Coffee Machines" (goes BEYOND keyword)

The keyword represents what the user searched for - they want a category PAGE about "{{keyword}}", not about sub-products within it.

=== YOUR TASK ===
1. Analyze the Amazon category paths from the products
2. Propose STANDARDIZED category paths that:
   - END at the keyword level (or one level above if keyword is too specific)
   - Are SEO-friendly and user-friendly
   - Use consistent naming conventions
   - Have 2-4 levels maximum
   - Reuse existing categories in our system when appropriate
3. Each product can belong to MULTIPLE categories
4. Use " > " (space-arrow-space) as the separator

Format your response as JSON:
{
    "suggested_paths": [
        "Main Category > Subcategory",
        "All paths should end at or near the keyword level"
    ],
    "product_assignments": {
        "ASIN1": ["Main Category > Subcategory"],
        "ASIN2": ["Main Category > Subcategory"],
        "Map each ASIN to its category paths (array)"
    },
    "reasoning": "Brief explanation including why you chose this depth"
}

NOTES:
- NEVER go deeper than the keyword level
- Prioritize reusing existing categories
- Keep category names concise (remove redundant words)
- Use Title Case for all category names
- If keyword appears in middle of Amazon path, truncate AFTER the keyword
PROMPT;
    }

    private static function seoCategory(): string
    {
        return <<<'PROMPT'
You are an expert SEO content writer for an affiliate product review website. Create comprehensive, engaging content for a category page that helps shoppers find and compare products.

## Category Data
Category: {{category_name}}
Full Path: {{category_path}}
{{parents_context}}
{{products_context}}
{{related_categories}}
{{brand_links}}

## Required Response Format
You MUST respond with a valid JSON object (no markdown code fences):
{
    "description": "Brief category description (max 200 chars, plain text)",
    "seo_title": "SEO title (50-60 chars, include category name)",
    "seo_description": "Meta description (150-160 chars, plain text)",
    "content_main": "<complete HTML content — intro, buying guide, FAQ, internal links>",
    "internal_links_used": ["/c/slug1/", "/c/slug2/", "/brand/slug/"]
}

## Field Requirements

**description**: 1-2 sentences summarizing what this category contains. Plain text, no HTML. Max 200 characters.

**seo_title**: SEO-optimized title for search results. 50-60 characters. Must include category name.

**seo_description**: Meta description for search results. 150-160 characters. Plain text, no HTML. Focus on buyer intent.

**content_main**: Complete page content (600-1000 words) in HTML format. Structure:

### Section 1: Introduction (1-2 paragraphs)
- Welcome visitors, explain what products are in this category
- Why this category matters to shoppers
- Include 1 internal link to a related category

### Section 2: What to Look For (h2)
- 3-5 key buying criteria as h3 subsections
- Each with 1-2 detailed paragraphs explaining what matters and why
- Be specific to THIS product category (not generic shopping advice)
- Include 1-2 internal links naturally

### Section 3: FAQs (h2)
- 3-5 frequently asked questions relevant to this category
- Each as h3 question with a 2-3 sentence answer
- Questions should be natural search queries people actually ask
- Include 1 internal link in one FAQ answer

## HTML Rules
- Use <h2>, <h3>, <p>, <ul>, <li> tags. NEVER use <h1>
- Start content with a <p> paragraph, not a heading
- Use <a href="/c/slug/">Category Name</a> for internal links
- Use <a href="/brand/slug/">Brand Name</a> for brand links

## Internal Linking Rules
- Include 3-7 internal links total across all sections
- ONLY use URLs from the Related Categories and Brand Links above
- Never invent or guess URLs
- Use descriptive anchor text
- Brand links: at most 3-5 total, only brands you actually discuss

## Writing Rules
- Write in helpful, authoritative tone
- Focus on buyer intent and practical value
- Do not mention specific prices or promotions
- Do not use em-dash character
- Be specific to the product category, avoid generic filler
- Respond with valid JSON only, no markdown code fences
PROMPT;
    }

    private static function seoBrand(): string
    {
        return <<<'PROMPT'
You are an expert SEO content writer for an affiliate product review website. Create comprehensive, engaging content for a brand page that helps shoppers discover and evaluate this brand's products.

## Brand Data
Brand: {{brand_name}}
{{website_context}}
{{categories_context}}
{{products_context}}

{{brand_category_links}}

## Required Response Format
You MUST respond with a valid JSON object (no markdown code fences).
The system stores content in separate database fields, so you MUST provide ALL fields:
{
    "description": "Brief brand description (max 200 chars, plain text)",
    "seo_title": "SEO title (50-60 chars)",
    "seo_description": "Meta description (150-160 chars, plain text)",
    "content_intro": "<p>1-2 paragraph HTML introduction</p>",
    "content_main": "<complete HTML content — brand overview, product strengths, buying tips>",
    "content_faq": [
        {"question": "FAQ question 1?", "answer": "Detailed answer 1."},
        {"question": "FAQ question 2?", "answer": "Detailed answer 2."},
        {"question": "FAQ question 3?", "answer": "Detailed answer 3."}
    ],
    "internal_links_used": ["/c/slug1/", "/c/slug2/"]
}

## Field Requirements

**description**: 1-2 sentences about what this brand is known for. Plain text, no HTML. Max 200 characters.

**seo_title**: SEO-optimized title for search results. 50-60 characters. Must include brand name. Example: "{{brand_name}} Products - Reviews & Best Picks"

**seo_description**: Meta description for search results. 150-160 characters. Plain text, no HTML.

**content_intro**: Opening introduction (1-2 paragraphs wrapped in <p> tags):
- Introduce the brand: what they're known for, types of products they make
- Mention their market position and target audience
- Include 1 internal link to a relevant category page

**content_main**: Main body content (400-700 words) in HTML:

### Section 1: Brand Overview (h2)
- What makes this brand stand out in the market
- Product quality, reputation, and value proposition
- Key product categories they excel in
- Include 1-2 internal links to category pages

### Section 2: What to Expect from {{brand_name}} Products (h2)
- Common strengths across their product line
- Build quality, design philosophy, price positioning
- Who their products are best for (target audience)
- Include 1-2 internal links naturally

### Section 3: Popular Categories (h2) — optional, only if brand_category_links provided
- Brief mention of 2-3 top categories with links
- What products are best-reviewed in each category

**content_faq**: Array of 4-5 FAQ objects. Each with:
- `question`: Natural search-friendly question (e.g., "Is {{brand_name}} a good brand?", "Where are {{brand_name}} products made?")
- `answer`: 2-4 sentence detailed answer. Factual and helpful.

## HTML Rules
- Use <h2>, <h3>, <p>, <ul>, <li> tags. NEVER use <h1>
- Start content_main with <h2>, not <p> (intro is in content_intro)
- Use <a href="/c/slug/">Category Name</a> for internal links

## Internal Linking Rules
- Include 3-7 internal links total across content_intro and content_main
- ONLY use URLs from the Brand Category Links above. Never invent URLs
- Use descriptive anchor text related to the category

## Writing Rules
- Write in helpful, authoritative tone
- Focus on brand reputation and product quality based on actual product data
- Do NOT make up facts about brand history, founding year, headquarters, etc.
- If unsure about the brand, focus entirely on products and value
- Do not mention specific prices or promotions
- Do not use em-dash character
- Be specific — reference actual product names from the Products Data when relevant
- Respond with valid JSON only, no markdown code fences
PROMPT;
    }
}
