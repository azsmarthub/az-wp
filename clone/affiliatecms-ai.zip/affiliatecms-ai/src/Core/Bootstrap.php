<?php
/**
 * AffiliateCMS AI - Bootstrap
 */

declare(strict_types=1);

namespace AffiliateCMS\AI\Core;

use AffiliateCMS\AI\Admin\SettingsPage;
use AffiliateCMS\AI\Api\JobController;
use AffiliateCMS\AI\Api\SettingsController;
use AffiliateCMS\AI\Api\StatsController;

class Bootstrap
{
    /**
     * Initialize the plugin
     */
    public function init(): void
    {
        // Register admin menu
        add_action('admin_menu', [$this, 'registerAdminMenu']);

        // Register REST API routes
        add_action('rest_api_init', [$this, 'registerRestRoutes']);

        // Enqueue admin assets
        add_action('admin_enqueue_scripts', [$this, 'enqueueAdminAssets']);

        // Register hooks for AI processing
        $this->registerHooks();

        // Initialize WP-Cron fallback for AI job processing
        // (Server cron is primary, WP-Cron is safety net)
        $this->initWpCronFallback();

        // One-time cleanup: unschedule all AS actions after disabling AS
        $this->cleanupAsOnce();
    }

    /**
     * Register admin menu
     */
    public function registerAdminMenu(): void
    {
        add_submenu_page(
            'acms-pro', // Parent slug from affiliatecms-pro
            __('AI Assistant', 'affiliatecms-ai'),
            __('AI Assistant', 'affiliatecms-ai'),
            'manage_options',
            'acms-ai',
            [new SettingsPage(), 'render']
        );
    }

    /**
     * Register REST API routes
     */
    public function registerRestRoutes(): void
    {
        $jobController = new JobController();
        $jobController->registerRoutes();

        $settingsController = new SettingsController();
        $settingsController->registerRoutes();

        $statsController = new StatsController();
        $statsController->registerRoutes();
    }

    /**
     * Enqueue admin assets
     */
    public function enqueueAdminAssets(string $hook): void
    {
        // Only load on our plugin pages
        if (!str_contains($hook, 'acms-ai')) {
            return;
        }

        // Alpine.js (use from parent plugin if available)
        // Note: affiliatecms-pro uses handle 'alpinejs', so we check for that first
        if (!wp_script_is('alpinejs', 'registered')) {
            wp_register_script(
                'alpinejs',
                ACMS_AI_URL . 'assets/js/vendor/alpine.min.js',
                [],
                '3.14.3',
                ['strategy' => 'defer']
            );
        }

        // Admin JS - depends on alpinejs (same handle as parent plugin)
        wp_enqueue_script(
            'acms-ai-admin',
            ACMS_AI_URL . 'assets/js/admin.js',
            ['alpinejs'],
            ACMS_AI_VERSION,
            ['strategy' => 'defer']
        );

        // Admin CSS
        wp_enqueue_style(
            'acms-ai-admin',
            ACMS_AI_URL . 'assets/css/admin.css',
            [],
            ACMS_AI_VERSION
        );

        // Bootstrap Icons (from parent plugin if available)
        if (!wp_style_is('bootstrap-icons', 'registered')) {
            wp_enqueue_style(
                'bootstrap-icons',
                'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css',
                [],
                '1.11.3'
            );
        } else {
            wp_enqueue_style('bootstrap-icons');
        }

        // Localize script
        wp_localize_script('acms-ai-admin', 'acmsAiConfig', [
            'restUrl' => rest_url('acms-ai/v1/'),
            'nonce' => wp_create_nonce('wp_rest'),
            'i18n' => [
                'success' => __('Success', 'affiliatecms-ai'),
                'error' => __('Error', 'affiliatecms-ai'),
                'loading' => __('Loading...', 'affiliatecms-ai'),
            ],
        ]);
    }

    /**
     * Register hooks for AI processing triggers
     */
    private function registerHooks(): void
    {
        // Hook into product scraped event
        add_action('acms_product_scraped', [$this, 'onProductScraped'], 10, 2);

        // Hook into post created event
        add_action('acms_post_created', [$this, 'onPostCreated'], 10, 2);

        // Hook into category created event
        add_action('acms_category_created', [$this, 'onCategoryCreated'], 10, 2);

        // Hook into category assigned event (from CategoryPathAssigner)
        // This triggers content generation immediately after category assignment
        add_action('acms_category_assigned', [$this, 'onCategoryAssigned'], 10, 3);

        // Hook into category AI content generated event
        // Triggers brand-category creation and spawns category AI workers for them
        add_action('acms_ai_seo_category_generated', [$this, 'onCategoryAiGenerated'], 10, 3);

        // Hook into post AI queued event (from ScrapeMonitorCron or QueueProcessor)
        // Triggers post AI generation immediately instead of waiting for next poll
        add_action('acms_post_ai_queued', [$this, 'onPostAiQueued'], 10, 1);

        // Hook into brand AI generated event
        // When brand AI completes, trigger next brand if any are queued
        add_action('acms_ai_seo_brand_generated', [$this, 'onBrandAiGenerated'], 10, 3);
    }

    /**
     * Handle product scraped event — spawn AI workers
     *
     * Called via 'acms_product_scraped' hook fired right after scrape completes.
     * The product is already marked ai_status='queued' by markAsScraped().
     * We just need to ensure AI workers are running to process it.
     *
     * Uses the parallel worker pattern: spawns N non-blocking HTTP workers
     * that each claim one product atomically, process it, and self-spawn the next.
     */
    public function onProductScraped(string $asin, array $productData): void
    {
        // Always sync category links from cat queue (regardless of AI settings).
        // This catches products that were re-scraped after initial CategoryPathAssigner run.
        $this->syncProductCategoryLinks($asin);

        if (!get_option('acms_ai_enhance_asin_enabled')) {
            return;
        }

        if (empty(get_option('acms_ai_api_key', ''))) {
            return;
        }

        if (!class_exists(\AffiliateCMS\Pro\Core\ProductAiCron::class)) {
            return;
        }

        try {
            $cron = \AffiliateCMS\Pro\Core\ProductAiCron::instance();
            $cron->spawnAiWorkers();
        } catch (\Throwable $e) {
            error_log("[ACMS AI] onProductScraped error for {$asin}: " . $e->getMessage());
        }

        // Also trigger brand AI if enabled (throttled to avoid excessive calls)
        $this->triggerBrandAiThrottled();
    }

    /**
     * Sync a just-scraped product's category links from cat queue data.
     *
     * When CategoryPathAssigner first links products to a category, it only
     * picks up products with status='scraped'. Products that failed scraping
     * and are later re-scraped miss that window. This method closes the gap
     * by checking if the ASIN belongs to any cat queue item with an assigned
     * category and linking it if not already linked.
     */
    private function syncProductCategoryLinks(string $asin): void
    {
        global $wpdb;

        $queueTable = $wpdb->prefix . 'acms_cat_queue';

        // Quick check: does the cat queue table exist?
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $queueTable)) !== $queueTable) {
            return;
        }

        // Find queue items that reference this ASIN and have an assigned category
        $items = $wpdb->get_results($wpdb->prepare(
            "SELECT id, linked_asins, assigned_category_id, custom_category_path
             FROM {$queueTable}
             WHERE assigned_category_id > 0
               AND linked_asins LIKE %s",
            '%' . $wpdb->esc_like($asin) . '%'
        ), ARRAY_A);

        if (empty($items)) {
            return;
        }

        // Verify product exists and is scraped
        $productsTable = $wpdb->prefix . 'acms_products';
        $productId = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$productsTable} WHERE asin = %s AND status = 'scraped'",
            $asin
        ));

        if ($productId <= 0) {
            return;
        }

        $categoryRepo = class_exists(\AffiliateCMS\Categories\Repositories\CategoryRepository::class)
            ? new \AffiliateCMS\Categories\Repositories\CategoryRepository()
            : null;
        $productRepo = class_exists(\AffiliateCMS\Pro\Repositories\ProductRepository::class)
            ? \AffiliateCMS\Pro\Repositories\ProductRepository::instance()
            : null;

        if (!$categoryRepo || !$productRepo) {
            return;
        }

        foreach ($items as $item) {
            $linkedAsins = is_array($item['linked_asins'])
                ? $item['linked_asins']
                : json_decode($item['linked_asins'], true);

            if (!is_array($linkedAsins) || !in_array($asin, $linkedAsins, true)) {
                continue;
            }

            $categoryId = (int) $item['assigned_category_id'];
            $categoryRepo->addProduct($categoryId, $productId, false);

            if (!empty($item['custom_category_path'])) {
                $productRepo->appendCategoryPaths($productId, [$item['custom_category_path']]);
            }
        }
    }

    /**
     * Handle post created event
     */
    public function onPostCreated(int $postId, array $queueItem): void
    {
        if (!get_option('acms_ai_optimize_review_enabled')) {
            return;
        }

        $post = get_post($postId);
        if (!$post) {
            return;
        }

        // Queue AI optimization job
        $this->queueJob('optimize_review', [
            'post_id' => $postId,
            'title' => $post->post_title,
            'content' => $post->post_content,
            'keyword' => $queueItem['keyword'] ?? '',
        ], 50);
    }

    /**
     * Handle category created event
     */
    public function onCategoryCreated(int $termId, array $categoryData): void
    {
        if (!get_option('acms_ai_generate_category_enabled')) {
            return;
        }

        // Queue AI job for category description generation
        $this->queueJob('generate_category', [
            'term_id' => $termId,
            'category_name' => $categoryData['name'] ?? '',
            'category_path' => $categoryData['amazon_path'] ?? '',
        ], 30);
    }

    /**
     * Handle category assigned event (from CategoryPathAssigner)
     *
     * This is fired AFTER a category is assigned to a queue item via majority voting.
     * Creates a content generation job immediately instead of waiting for CategoryAiCron.
     *
     * @param int $queueId Queue item ID
     * @param int $categoryId Assigned category ID
     * @param string $categoryPath Category path (e.g., "Electronics > Audio > Headphones")
     */
    public function onCategoryAssigned(int $queueId, int $categoryId, string $categoryPath): void
    {
        global $wpdb;

        if ($categoryId <= 0) {
            return;
        }

        // Check if AI plugin tables exist
        $jobsTable = $wpdb->prefix . 'acms_ai_jobs';
        $tableExists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $jobsTable));
        if ($tableExists !== $jobsTable) {
            return;
        }

        // Check if job already exists for this category
        $existingJob = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$jobsTable}
             WHERE type = 'generate_seo_category'
             AND target_type = 'seo_category'
             AND target_id = %s
             AND status IN ('pending', 'processing')",
            (string) $categoryId
        ));

        if ($existingJob) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("[ACMS AI Bootstrap] Content generation job already exists for category {$categoryId}");
            }
            return;
        }

        // Get category details
        $categoriesTable = $wpdb->prefix . 'acms_categories';
        $category = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$categoriesTable} WHERE id = %d",
            $categoryId
        ), ARRAY_A);

        if (!$category) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("[ACMS AI Bootstrap] Category {$categoryId} not found");
            }
            return;
        }

        // Skip if content already exists
        $contentStatus = $category['content_status'] ?? 'empty';
        if ($contentStatus !== 'empty') {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("[ACMS AI Bootstrap] Category {$categoryId} already has content status: {$contentStatus}");
            }
            return;
        }

        // Get products for context
        $junctionTable = $wpdb->prefix . 'acms_category_products';
        $productsTable = $wpdb->prefix . 'acms_products';
        $products = $wpdb->get_results($wpdb->prepare(
            "SELECT p.asin, p.title, p.brand, p.category_path, p.rating, p.reviews_count
             FROM {$productsTable} p
             INNER JOIN {$junctionTable} cp ON cp.product_id = p.id
             WHERE cp.category_id = %d AND p.status = 'scraped'
             ORDER BY cp.is_primary DESC, p.rating DESC
             LIMIT 15",
            $categoryId
        ), ARRAY_A) ?: [];

        // Parse category path for parent categories
        $parentCategories = array_filter(array_map('trim', explode('>', $categoryPath)));
        array_pop($parentCategories); // Remove current category from path

        // Gather related categories and brand link context for internal linking
        $relatedCategories = ['siblings' => [], 'children' => [], 'ancestors' => []];
        $brandLinks = [];
        if (class_exists(\AffiliateCMS\Categories\Repositories\CategoryRepository::class)) {
            $catRepo = new \AffiliateCMS\Categories\Repositories\CategoryRepository();
            $relatedCategories = $catRepo->getInternalLinkContext($categoryId);
            $brandLinks = $catRepo->getBrandLinkContext($categoryId, $products);
        }

        // Build input data
        $inputData = [
            'category_id' => $categoryId,
            'category_name' => $category['name'],
            'category_slug' => $category['slug'] ?? '',
            'category_path' => $categoryPath,
            'parent_categories' => $parentCategories,
            'products' => $products,
            'current_description' => $category['description'] ?? '',
            'queue_id' => $queueId,
            'related_categories' => $relatedCategories,
            'brand_links' => $brandLinks,
        ];

        // Create the job
        $wpdb->insert($jobsTable, [
            'type' => 'generate_seo_category',
            'status' => 'pending',
            'priority' => 40, // Higher priority for immediate trigger
            'target_type' => 'seo_category',
            'target_id' => (string) $categoryId,
            'input_data' => wp_json_encode($inputData),
            'created_at' => current_time('mysql'),
        ]);

        if ($wpdb->insert_id) {
            $jobId = (int) $wpdb->insert_id;

            // Update category status
            $wpdb->update(
                $categoriesTable,
                [
                    'content_status' => 'ai_generating',
                    'ai_generating_at' => current_time('mysql'),
                    'ai_error_message' => null,
                ],
                ['id' => $categoryId],
                ['%s', '%s', '%s'],
                ['%d']
            );

            // Update queue ai_status
            $queueTable = $wpdb->prefix . 'acms_cat_queue';
            $wpdb->update(
                $queueTable,
                ['ai_status' => 'generating_content'],
                ['id' => $queueId],
                ['%s'],
                ['%d']
            );

            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("[ACMS AI Bootstrap] Created content generation job #{$jobId} for category {$categoryId} (queue: {$queueId})");
            }
        }
    }

    /**
     * Handle category AI content generated event
     *
     * When a category's AI content is generated, check if it's a parent category
     * (brand_id IS NULL) and create brand sub-categories for it.
     * Then spawn category AI workers for the new brand-categories.
     *
     * @param int $categoryId Category ID that just had AI content generated
     * @param array $result AI generation result data
     * @param string $generationId OpenRouter generation ID
     */
    public function onCategoryAiGenerated(int $categoryId, array $result, ?string $generationId = null): void
    {
        // Only trigger brand-category creation if feature is enabled
        if (!get_option('acms_ai_seo_brand_category_enabled', true)) {
            return;
        }

        if (!class_exists(\AffiliateCMS\Categories\Core\BrandCategoryAiCron::class)) {
            return;
        }

        try {
            $brandCatCron = \AffiliateCMS\Categories\Core\BrandCategoryAiCron::instance();
            $createdIds = $brandCatCron->createBrandCategoriesForParent($categoryId);

            if (!empty($createdIds)) {
                error_log("[ACMS AI] Created " . count($createdIds) . " brand-categories after AI generated for category #{$categoryId}");

                // Spawn category AI workers for the new brand-categories
                if (class_exists(\AffiliateCMS\Categories\Core\CategoryAiCron::class)) {
                    $catCron = \AffiliateCMS\Categories\Core\CategoryAiCron::instance();
                    $catCron->spawnCategoryAiWorkers();
                }
            }
        } catch (\Throwable $e) {
            error_log("[ACMS AI] onCategoryAiGenerated error for #{$categoryId}: " . $e->getMessage());
        }
    }

    /**
     * Handle post AI queued event — trigger post generation immediately
     *
     * Called via 'acms_post_ai_queued' hook fired by ScrapeMonitorCron (when scrape
     * threshold reached) and QueueProcessor (when queue item finalized).
     * Eliminates the 60s polling delay by triggering PostAiCron immediately.
     *
     * @param int $queueId Queue item ID that was marked as queued
     */
    public function onPostAiQueued(int $queueId): void
    {
        if (!class_exists(\AffiliateCMS\Pro\Core\PostAiCron::class)) {
            return;
        }

        try {
            $cron = \AffiliateCMS\Pro\Core\PostAiCron::instance();
            $cron->generatePosts();
        } catch (\Throwable $e) {
            error_log("[ACMS AI] onPostAiQueued error for queue #{$queueId}: " . $e->getMessage());
        }
    }

    /**
     * Handle brand AI generated event — trigger next brand immediately
     *
     * Called via 'acms_ai_seo_brand_generated' hook fired by JobProcessor
     * when a brand's AI content is completed. Triggers the next brand
     * generation immediately instead of waiting for the next poll cycle.
     *
     * @param int $brandId Brand ID that just had AI content generated
     * @param array $result AI generation result data
     * @param string $generationId OpenRouter generation ID
     */
    public function onBrandAiGenerated(int $brandId, array $result, ?string $generationId = null): void
    {
        if (!get_option('acms_ai_seo_brand_enabled', true)) {
            return;
        }

        if (!class_exists(\AffiliateCMS\Pro\Core\BrandAiCron::class)) {
            return;
        }

        try {
            $cron = \AffiliateCMS\Pro\Core\BrandAiCron::instance();
            // Process 1 brand at a time to chain continuously (like worker pattern)
            $cron->generateContent(1);
        } catch (\Throwable $e) {
            error_log("[ACMS AI] onBrandAiGenerated error for brand #{$brandId}: " . $e->getMessage());
        }
    }

    /**
     * Trigger brand AI generation with throttling
     *
     * Called from onProductScraped() — fires for every product, so throttle
     * to once per 5 minutes to avoid excessive calls. Ensures brands get
     * AI content generated soon after their products are scraped.
     */
    private function triggerBrandAiThrottled(): void
    {
        if (!get_option('acms_ai_seo_brand_enabled', true)) {
            return;
        }

        // Throttle: only trigger once per 5 minutes
        $lastTrigger = get_transient('acms_brand_ai_event_trigger');
        if ($lastTrigger) {
            return;
        }
        set_transient('acms_brand_ai_event_trigger', time(), 300);

        if (!class_exists(\AffiliateCMS\Pro\Core\BrandAiCron::class)) {
            return;
        }

        try {
            $cron = \AffiliateCMS\Pro\Core\BrandAiCron::instance();
            $cron->generateContent(1);
        } catch (\Throwable $e) {
            error_log("[ACMS AI] triggerBrandAiThrottled error: " . $e->getMessage());
        }
    }

    /**
     * Queue an AI job
     * Checks for existing pending/processing jobs to prevent duplicates
     */
    private function queueJob(string $type, array $inputData, int $priority = 50): void
    {
        global $wpdb;

        $table = $wpdb->prefix . 'acms_ai_jobs';
        $targetId = (string) ($inputData['asin'] ?? $inputData['post_id'] ?? $inputData['term_id'] ?? '');

        // Prevent duplicate jobs for same type + target
        if (!empty($targetId)) {
            $existing = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$table}
                 WHERE type = %s AND target_id = %s AND status IN ('pending', 'processing')
                 LIMIT 1",
                $type,
                $targetId
            ));

            if ($existing) {
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log("[ACMS AI] Skipping duplicate {$type} job for target {$targetId} (existing job #{$existing})");
                }
                return;
            }
        }

        $wpdb->insert(
            $table,
            [
                'type' => $type,
                'target_type' => match ($type) {
                    'enhance_asin' => 'asin',
                    'optimize_review' => 'post',
                    'generate_category' => 'term',
                    default => 'unknown',
                },
                'target_id' => $targetId,
                'input_data' => wp_json_encode($inputData),
                'priority' => $priority,
                'status' => 'pending',
                'created_at' => current_time('mysql'),
            ],
            ['%s', '%s', '%s', '%s', '%d', '%s', '%s']
        );
    }

    /**
     * Initialize WP-Cron fallback for AI job processing
     */
    private function initWpCronFallback(): void
    {
        // Register custom interval
        add_filter('cron_schedules', function (array $schedules): array {
            $schedules['every_minute'] = [
                'interval' => 60,
                'display' => 'Every Minute',
            ];
            return $schedules;
        });

        // Register job processor handler
        add_action('acms_ai_process_queue', function () {
            // Process AI jobs
            $processor = new JobProcessor();
            $processor->processQueue();

            // Check for queue items ready for category AI standardization
            $categoryProcessor = new CategoryAiProcessor();
            $categoryProcessor->processReadyItems();
        });

        // Schedule the cron event
        if (!wp_next_scheduled('acms_ai_process_queue')) {
            wp_schedule_event(time(), 'every_minute', 'acms_ai_process_queue');
        }

    }

    /**
     * One-time cleanup: unschedule all ACMS AS actions after disabling AS
     *
     * Runs once per deploy (24h transient). Removes all pending/recurring
     * actions from the acms-ai group so AS stops dispatching them.
     */
    private function cleanupAsOnce(): void
    {
        if (get_transient('acms_as_disabled_cleanup_done')) {
            return;
        }

        // Unschedule all ACMS AS actions
        if (function_exists('as_unschedule_all_actions')) {
            $hooks = [
                'acms_as_dispatch_jobs',
                'acms_as_process_job',
                'acms_as_process_category_ai',
                'acms_as_process_cat_queue',
                'acms_as_monitor_cat_queue',
                'acms_as_process_product_queue',
                'acms_as_scrape_products',
                'acms_as_scrape_monitor',
                'acms_as_post_ai',
                'acms_as_brand_ai',
                'acms_as_category_ai_cron',
                'acms_as_brand_category_ai',
                'acms_as_quick_update',
                'acms_as_date_update',
            ];

            foreach ($hooks as $hook) {
                as_unschedule_all_actions($hook, [], ActionSchedulerManager::GROUP);
            }

            error_log('[ACMS AI] One-time cleanup: unscheduled all AS actions (AS disabled, using server cron)');
        }

        set_transient('acms_as_disabled_cleanup_done', true, 86400);
    }

}
