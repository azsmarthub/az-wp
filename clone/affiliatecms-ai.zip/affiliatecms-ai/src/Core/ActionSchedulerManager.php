<?php
/**
 * Action Scheduler Manager
 *
 * DISABLED: AS has been replaced by server cron + REST API endpoints.
 * Class kept for backward compatibility (getStats, unscheduleAll still work).
 *
 * @package AffiliateCMS\AI\Core
 */

declare(strict_types=1);

namespace AffiliateCMS\AI\Core;

class ActionSchedulerManager
{
    /**
     * Group name for all ACMS actions
     */
    public const GROUP = 'acms-ai';

    /**
     * Action hooks (kept for reference/cleanup)
     */
    public const ACTION_PROCESS_JOB = 'acms_as_process_job';
    public const ACTION_DISPATCH_JOBS = 'acms_as_dispatch_jobs';

    /**
     * Singleton instance
     */
    private static ?ActionSchedulerManager $instance = null;

    /**
     * Get singleton instance
     */
    public static function instance(): ActionSchedulerManager
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Private constructor
     */
    private function __construct()
    {
        // AS disabled — no availability check needed
    }

    /**
     * AS is permanently disabled — server cron handles all jobs
     */
    public function isAvailable(): bool
    {
        return false;
    }

    /**
     * No-op — AS disabled
     */
    public function init(): void
    {
        // AS disabled — all jobs processed via server cron + WP-Cron fallback
    }

    /**
     * No-op — AS disabled
     */
    public function scheduleJob(int $jobId, int $priority = 50): void
    {
        // AS disabled — jobs processed via WP-Cron fallback
    }

    /**
     * Get stats about scheduled actions (still works for diagnostics)
     */
    public function getStats(): array
    {
        return [
            'available' => false,
            'status' => 'disabled',
            'pending' => 0,
            'running' => 0,
            'complete' => 0,
            'failed' => 0,
        ];
    }

    /**
     * Unschedule all ACMS actions (cleanup)
     */
    public function unscheduleAll(): void
    {
        if (!function_exists('as_unschedule_all_actions')) {
            return;
        }

        as_unschedule_all_actions(self::ACTION_DISPATCH_JOBS, [], self::GROUP);
        as_unschedule_all_actions(self::ACTION_PROCESS_JOB, [], self::GROUP);
    }

    /**
     * Clear completed actions (cleanup)
     */
    public function clearCompleted(int $olderThanDays = 7): int
    {
        if (!function_exists('as_unschedule_all_actions')) {
            return 0;
        }

        global $wpdb;
        $table = $wpdb->prefix . 'actionscheduler_actions';

        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table)) !== $table) {
            return 0;
        }

        $deleted = $wpdb->query($wpdb->prepare("
            DELETE FROM {$table}
            WHERE status = 'complete'
            AND `group_id` IN (
                SELECT group_id FROM {$wpdb->prefix}actionscheduler_groups WHERE slug = %s
            )
            AND scheduled_date_gmt < DATE_SUB(NOW(), INTERVAL %d DAY)
        ", self::GROUP, $olderThanDays));

        return (int) $deleted;
    }
}
