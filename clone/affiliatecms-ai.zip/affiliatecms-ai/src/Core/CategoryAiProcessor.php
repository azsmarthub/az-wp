<?php
/**
 * AffiliateCMS AI - Category AI Processor
 *
 * Monitors queue items and triggers category standardization AI when
 * scrape progress reaches the threshold (default 50%).
 */

declare(strict_types=1);

namespace AffiliateCMS\AI\Core;

class CategoryAiProcessor
{
    private const SCRAPE_THRESHOLD = 50; // Trigger when 50% products are scraped
    private string $jobsTable;

    public function __construct()
    {
        global $wpdb;
        $this->jobsTable = $wpdb->prefix . 'acms_ai_jobs';
    }

    /**
     * Check and process queue items ready for category AI
     */
    public function processReadyItems(): int
    {
        // Check if feature is enabled
        if (!get_option('acms_ai_standardize_categories_enabled', false)) {
            return 0;
        }

        // Check if affiliatecms-cat plugin is available
        if (!class_exists(\AffiliateCMS\Categories\Repositories\QueueRepository::class)) {
            return 0;
        }

        $queueRepo = new \AffiliateCMS\Categories\Repositories\QueueRepository();
        $readyItems = $queueRepo->getReadyForCategoryAi(self::SCRAPE_THRESHOLD, 5);

        $processed = 0;
        foreach ($readyItems as $item) {
            if ($this->processQueueItem($item)) {
                $processed++;
            }
        }

        return $processed;
    }

    /**
     * Process a single queue item for category AI
     */
    private function processQueueItem(array $item): bool
    {
        $queueId = (int) $item['id'];
        $keyword = $item['keyword'] ?? '';
        $linkedAsins = json_decode($item['linked_asins'] ?? '[]', true);

        if (empty($linkedAsins)) {
            return false;
        }

        // Get product data for the linked ASINs
        $products = $this->getProductData($linkedAsins);
        if (empty($products)) {
            return false;
        }

        // Get existing categories from the system
        $existingCategories = $this->getExistingCategories();

        // Create AI job for category standardization
        return $this->createStandardizeJob($queueId, $keyword, $products, $existingCategories);
    }

    /**
     * Get product data for the given ASINs
     */
    private function getProductData(array $asins): array
    {
        if (!class_exists(\AffiliateCMS\Pro\Repositories\ProductRepository::class)) {
            return [];
        }

        $productRepo = \AffiliateCMS\Pro\Repositories\ProductRepository::instance();
        $products = [];

        foreach ($asins as $asin) {
            $product = $productRepo->findByAsin($asin);
            if ($product) {
                $products[] = [
                    'asin' => $product->asin,
                    'title' => $product->title ?? '',
                    'brand' => $product->brand ?? '',
                    'category_path' => $product->categoryPath ?? '',
                ];
            }
        }

        return $products;
    }

    /**
     * Get existing categories from the system
     */
    private function getExistingCategories(): array
    {
        if (!class_exists(\AffiliateCMS\Categories\Repositories\CategoryRepository::class)) {
            return [];
        }

        $categoryRepo = new \AffiliateCMS\Categories\Repositories\CategoryRepository();

        // Get all published categories
        $categories = $categoryRepo->getAll('publish');

        $paths = [];
        foreach ($categories as $category) {
            // Build readable path from category name and ancestors
            if (!empty($category['name'])) {
                $paths[] = $this->buildCategoryPath($categoryRepo, $category);
            }
        }

        return array_unique($paths);
    }

    /**
     * Build a readable category path (e.g., "Electronics > Audio > Headphones")
     */
    private function buildCategoryPath($categoryRepo, array $category): string
    {
        $ancestors = $categoryRepo->getAncestors((int) $category['id']);
        $pathParts = [];

        foreach ($ancestors as $ancestor) {
            $pathParts[] = $ancestor['name'];
        }

        $pathParts[] = $category['name'];

        return implode(' > ', $pathParts);
    }

    /**
     * Create a standardize_categories job in the AI queue
     */
    private function createStandardizeJob(int $queueId, string $keyword, array $products, array $existingCategories): bool
    {
        global $wpdb;

        // Check if job already exists for this queue item (pending or processing)
        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT id, status FROM {$this->jobsTable}
             WHERE type = 'standardize_categories'
             AND target_type = 'queue'
             AND target_id = %s
             AND status IN ('pending', 'processing')
             LIMIT 1",
            (string) $queueId
        ), ARRAY_A);

        if ($existing) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("[ACMS CategoryAiProcessor] Job already exists for queue {$queueId}: job ID {$existing['id']} ({$existing['status']})");
            }
            return false; // Job already exists
        }

        // Create the job
        $inputData = [
            'queue_id' => $queueId,
            'keyword' => $keyword,
            'products' => $products,
            'existing_categories' => $existingCategories,
        ];

        $wpdb->insert($this->jobsTable, [
            'type' => 'standardize_categories',
            'target_type' => 'queue',
            'target_id' => (string) $queueId,
            'input_data' => wp_json_encode($inputData),
            'priority' => 5, // Medium priority
            'status' => 'pending',
            'created_at' => current_time('mysql'),
        ]);

        if ($wpdb->insert_id) {
            // Update queue item to indicate AI is analyzing
            $queueRepo = new \AffiliateCMS\Categories\Repositories\QueueRepository();
            $queueRepo->update($queueId, [
                'ai_status' => 'analyzing_category',
            ]);

            return true;
        }

        return false;
    }

    /**
     * Manually trigger category AI for a specific queue item
     *
     * @param int $queueId Queue item ID
     * @param bool $force Skip checks and re-run even if already processed
     * @return array Result with success status and message
     */
    public function triggerForQueue(int $queueId, bool $force = false): array
    {
        try {
            // Check if feature is enabled
            if (!get_option('acms_ai_standardize_categories_enabled', false)) {
                return [
                    'success' => false,
                    'message' => 'Category standardization feature is not enabled. Please enable it in AI Assistant settings.',
                ];
            }

            // Check if affiliatecms-cat plugin is available
            if (!class_exists(\AffiliateCMS\Categories\Repositories\QueueRepository::class)) {
                return [
                    'success' => false,
                    'message' => 'AffiliateCMS Categories plugin is not active',
                ];
            }

            $queueRepo = new \AffiliateCMS\Categories\Repositories\QueueRepository();
            $item = $queueRepo->find($queueId);

            if (!$item) {
                return [
                    'success' => false,
                    'message' => 'Queue item not found',
                ];
            }

            // Check scrape progress (skip if force)
            $scrapeProgress = (int) ($item['scrape_progress'] ?? 0);
            if (!$force && $scrapeProgress < self::SCRAPE_THRESHOLD) {
                return [
                    'success' => false,
                    'message' => "Scrape progress ({$scrapeProgress}%) is below threshold (" . self::SCRAPE_THRESHOLD . "%)",
                ];
            }

            // Check if already processed (skip if force)
            if (!$force && !empty($item['suggested_categories'])) {
                return [
                    'success' => false,
                    'message' => 'Categories have already been standardized for this queue. Use force=true to re-run.',
                ];
            }

            // Check if linked_asins exists
            if (empty($item['linked_asins'])) {
                return [
                    'success' => false,
                    'message' => 'No linked ASINs found for this queue item',
                ];
            }

            // If force, clear previous results and cancel existing jobs
            if ($force) {
                $this->cleanupForRerun($queueId, $item);

                $queueRepo->update($queueId, [
                    'suggested_categories' => null,
                    'cat_ai_generation_id' => null,
                    'custom_category_path' => null,
                    'assigned_category_id' => null,
                    'ai_status' => 'analyzing_category',
                    'status' => 'ready_for_ai',  // Reset main status too
                ]);
            }

            // Get linked ASINs
            $linkedAsins = json_decode($item['linked_asins'] ?? '[]', true);
            if (empty($linkedAsins)) {
                return [
                    'success' => false,
                    'message' => 'No linked ASINs found in queue item',
                ];
            }

            // Get product data
            $products = $this->getProductData($linkedAsins);
            if (empty($products)) {
                return [
                    'success' => false,
                    'message' => 'No product data found for ' . count($linkedAsins) . ' ASINs. Products may not exist or not be scraped yet.',
                ];
            }

            // Check if a job already exists (pending/processing)
            global $wpdb;
            $existingJob = $wpdb->get_row($wpdb->prepare(
                "SELECT id, status FROM {$this->jobsTable}
                 WHERE type = 'standardize_categories'
                 AND target_type = 'queue'
                 AND target_id = %s
                 AND status IN ('pending', 'processing')
                 LIMIT 1",
                (string) $queueId
            ), ARRAY_A);

            if ($existingJob) {
                return [
                    'success' => false,
                    'message' => "A {$existingJob['status']} job (ID: {$existingJob['id']}) already exists for this queue item. Use Re-run (Force) to reset and start fresh.",
                ];
            }

            // Process the item
            if ($this->processQueueItem($item)) {
                return [
                    'success' => true,
                    'message' => 'Category AI job created successfully for ' . count($products) . ' products',
                ];
            }

            return [
                'success' => false,
                'message' => 'Failed to create AI job. Database insert failed.',
            ];
        } catch (\Throwable $e) {
            return [
                'success' => false,
                'message' => 'Error: ' . $e->getMessage(),
            ];
        }
    }

    /**
     * Cleanup existing jobs and category state for re-running
     *
     * @param int $queueId Queue item ID
     * @param array $item Queue item data
     */
    private function cleanupForRerun(int $queueId, array $item): void
    {
        global $wpdb;

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("[ACMS CategoryAiProcessor] cleanupForRerun starting for queue {$queueId}");
        }

        // 1. Delete ALL existing standardize_categories jobs for this queue (including completed)
        // When force re-running, we want to start completely fresh
        $deletedStandardize = $wpdb->query($wpdb->prepare(
            "DELETE FROM {$this->jobsTable}
             WHERE type = 'standardize_categories'
             AND target_type = 'queue'
             AND target_id = %s",
            (string) $queueId
        ));

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("[ACMS CategoryAiProcessor] Deleted {$deletedStandardize} standardize_categories jobs for queue {$queueId}");
        }

        // 2. If there's an assigned category, clean up its jobs and reset its status
        $assignedCategoryId = (int) ($item['assigned_category_id'] ?? 0);
        if ($assignedCategoryId > 0) {
            // Delete ALL content generation jobs for this category (including completed)
            $deletedContent = $wpdb->query($wpdb->prepare(
                "DELETE FROM {$this->jobsTable}
                 WHERE type = 'generate_seo_category'
                 AND target_type = 'seo_category'
                 AND target_id = %s",
                (string) $assignedCategoryId
            ));

            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("[ACMS CategoryAiProcessor] Deleted {$deletedContent} generate_seo_category jobs for category {$assignedCategoryId}");
            }

            // Reset category content status if it was generating
            $categoriesTable = $wpdb->prefix . 'acms_categories';
            $updated = $wpdb->update(
                $categoriesTable,
                [
                    'content_status' => 'empty',
                    'ai_generating_at' => null,
                    'ai_error_message' => null,
                ],
                [
                    'id' => $assignedCategoryId,
                    'content_status' => 'ai_generating',  // Only reset if it's stuck in generating
                ],
                ['%s', '%s', '%s'],
                ['%d', '%s']
            );

            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("[ACMS CategoryAiProcessor] Reset category {$assignedCategoryId} content_status: {$updated} rows affected");
            }
        }

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("[ACMS CategoryAiProcessor] cleanupForRerun completed for queue {$queueId}");
        }
    }
}
