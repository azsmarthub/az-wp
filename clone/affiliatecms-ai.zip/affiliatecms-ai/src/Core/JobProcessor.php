<?php
/**
 * AffiliateCMS AI - Job Processor
 */

declare(strict_types=1);

namespace AffiliateCMS\AI\Core;

class JobProcessor
{
    private string $apiKey;
    private string $apiUrl = 'https://openrouter.ai/api/v1/chat/completions';

    public function __construct()
    {
        $this->apiKey = get_option('acms_ai_api_key', '');
    }

    /**
     * Process pending jobs from the queue
     */
    public function processQueue(int $limit = 5): void
    {
        if (empty($this->apiKey)) {
            return;
        }

        global $wpdb;
        $table = $wpdb->prefix . 'acms_ai_jobs';

        // Get pending jobs with highest priority
        $jobs = $wpdb->get_results($wpdb->prepare("
            SELECT * FROM {$table}
            WHERE status = 'pending'
            AND attempts < max_attempts
            ORDER BY priority DESC, created_at ASC
            LIMIT %d
        ", $limit), ARRAY_A);

        foreach ($jobs as $job) {
            $this->processJob($job);
        }
    }

    /**
     * Process a single job (public wrapper for Action Scheduler)
     *
     * @param array $job Job data array
     */
    public function processSingleJob(array $job): void
    {
        $this->processJob($job);
    }

    /**
     * Process a single job
     */
    private function processJob(array $job): void
    {
        global $wpdb;
        $table = $wpdb->prefix . 'acms_ai_jobs';

        // Mark as processing
        $wpdb->update(
            $table,
            [
                'status' => 'processing',
                'processing_at' => current_time('mysql'),
                'attempts' => $job['attempts'] + 1,
            ],
            ['id' => $job['id']],
            ['%s', '%s', '%d'],
            ['%d']
        );

        try {
            $jobStartTime = microtime(true);

            // Check API key
            if (empty($this->apiKey)) {
                throw new \Exception('OpenRouter API key not configured');
            }

            // Safety: input_data may already be decoded by WordPress/PDO
            // Also handle null/empty input_data (wp_json_encode may have failed during job creation)
            $rawInput = $job['input_data'] ?? '';
            if (is_array($rawInput)) {
                $inputData = $rawInput;
            } elseif (is_string($rawInput) && $rawInput !== '') {
                $inputData = json_decode($rawInput, true);
            } else {
                $inputData = null;
            }

            if (empty($inputData) || !is_array($inputData)) {
                throw new \Exception('Job input_data is empty or invalid JSON. Raw length: ' . strlen((string) ($job['input_data'] ?? '')));
            }

            $model = get_option('acms_ai_default_model', 'openai/gpt-4o-mini');

            // Get prompt based on job type
            $prompt = $this->getPromptForJob($job['type'], $inputData);

            // Get timeout based on job type (longer content needs more time)
            $timeout = $this->getTimeoutForJobType($job['type']);

            // Call OpenRouter API with appropriate timeout
            $result = $this->callApi($model, $prompt, $timeout);

            if ($result['success']) {
                // Check if result has only 'raw' key (JSON parse failed)
                if (isset($result['data']['raw']) && count($result['data']) <= 2) {
                    error_log("[ACMS Job] #{$job['id']} WARNING: JSON parse failed, only raw data returned");
                }

                // Include generation_id in output data for reference
                $outputData = $result['data'];
                $outputData['_generation_id'] = $result['generation_id'] ?? null;

                // Update job with result
                $outputJson = wp_json_encode($outputData);

                $jobUpdated = $wpdb->update(
                    $table,
                    [
                        'status' => 'completed',
                        'output_data' => $outputJson,
                        'model' => $model,
                        'tokens_used' => $result['tokens'],
                        'tokens_input' => $result['tokens_input'] ?? 0,
                        'tokens_output' => $result['tokens_output'] ?? 0,
                        'cost' => $result['cost'],
                        'api_created_at' => $result['api_created_at'],
                        'completed_at' => current_time('mysql'),
                    ],
                    ['id' => $job['id']],
                    ['%s', '%s', '%s', '%d', '%d', '%d', '%f', '%s', '%s'],
                    ['%d']
                );

                if ($jobUpdated === false) {
                    error_log("[ACMS Job] #{$job['id']} FAILED to update status: " . $wpdb->last_error);
                }

                // Track usage
                $this->trackUsage($model, $result['tokens'], $result['cost']);

                // Apply result in separate try/catch — apply failures must NOT overwrite
                // the 'completed' job status above. The API call succeeded, data is saved
                // in output_data. If apply throws (hook error, DB error, etc.), the job
                // stays completed and content can be re-applied from saved output_data.
                try {
                    $this->applyJobResult($job['type'], $inputData, $result['data'], $result['generation_id'] ?? null);
                } catch (\Throwable $applyError) {
                    // Log error but job stays completed — prevents infinite retry loop
                    // where API is called repeatedly because apply keeps failing
                    error_log("[ACMS Job] #{$job['id']} APPLY ERROR (job stays completed): " . $applyError->getMessage());
                }
            } else {
                throw new \Exception($result['error']);
            }
        } catch (\Throwable $e) {
            // Mark job as failed — only reaches here if API call itself failed
            // (not apply errors, which are caught separately above)
            $wpdb->update(
                $table,
                [
                    'status' => 'failed',
                    'error_message' => $e->getMessage(),
                ],
                ['id' => $job['id']],
                ['%s', '%s'],
                ['%d']
            );

            // Reset target entity status to prevent stuck 'generating' states
            $this->resetTargetOnFailure($job, $e->getMessage());

            error_log("[ACMS Job] #{$job['id']} {$job['type']} FAILED: " . $e->getMessage());
        }
    }

    /**
     * Get prompt for job type
     */
    private function getPromptForJob(string $type, array $inputData): string
    {
        return match ($type) {
            'enhance_asin' => $this->getEnhanceAsinPrompt($inputData),
            'optimize_review' => $this->getOptimizeReviewPrompt($inputData),
            'generate_category' => $this->getGenerateCategoryPrompt($inputData),
            'standardize_categories' => $this->getStandardizeCategoriesPrompt($inputData),
            'generate_seo_category' => $this->getGenerateSeoCategoryPrompt($inputData),
            'generate_seo_brand' => $this->getGenerateSeoBrandPrompt($inputData),
            default => throw new \Exception("Unknown job type: {$type}"),
        };
    }

    /**
     * Get prompt for ASIN enhancement
     * Uses saved template from settings or falls back to default
     */
    private function getEnhanceAsinPrompt(array $data): string
    {
        // Prepare variable values with asin_ prefix
        $features = $data['features'] ?? [];
        $featuresText = !empty($features) ? "- " . implode("\n- ", $features) : '(no features available)';

        // Format JSON fields for readability
        $formatJson = function ($value) {
            if (empty($value)) {
                return '(not available)';
            }
            if (is_array($value)) {
                return wp_json_encode($value, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
            }
            return (string) $value;
        };

        $variables = [
            // Basic info
            'asin_code' => $data['asin'] ?? '',
            'asin_title' => $data['title'] ?? '',
            'asin_brand' => $data['brand'] ?? '',
            'asin_category' => $data['category'] ?? '',
            'asin_category_path' => $data['category_path'] ?? '',
            // Pricing
            'asin_price' => $data['price'] ?? '',
            'asin_original_price' => $data['original_price'] ?? '',
            'asin_currency' => $data['currency'] ?? 'USD',
            // Availability
            'asin_in_stock' => !empty($data['in_stock']) ? 'Yes' : 'No',
            'asin_is_prime' => !empty($data['is_prime']) ? 'Yes' : 'No',
            // Ratings
            'asin_rating' => $data['rating'] ?? '',
            'asin_reviews_count' => $data['reviews_count'] ?? '0',
            'asin_score' => $data['score'] ?? '',
            // Content
            'asin_description' => $data['description'] ?? '',
            'asin_features' => $featuresText,
            // Details
            'asin_specifications' => $formatJson($data['specifications'] ?? null),
            'asin_product_information' => $formatJson($data['product_information'] ?? null),
            'asin_best_sellers_rank' => $data['best_sellers_rank'] ?? '',
            // Reviews
            'asin_top_reviews' => $formatJson($data['top_reviews'] ?? null),
            'asin_reviews_summary' => $formatJson($data['reviews_summary'] ?? null),
            // Seller
            'asin_seller_info' => $formatJson($data['seller_info'] ?? null),
            // Media
            'asin_image_url' => $data['image_url'] ?? '',
            'asin_images_gallery' => $formatJson($data['images_gallery'] ?? null),
        ];

        // Read prompt from wp_options (seeded on activation, editable in admin)
        $template = get_option('acms_ai_prompt_enhance_asin', '');

        if (empty($template)) {
            throw new \Exception('Enhance ASIN prompt template is empty. Please configure it in AI Assistant settings or re-activate the plugin to restore defaults.');
        }

        // Replace variables in template
        foreach ($variables as $key => $value) {
            $template = str_replace('{{' . $key . '}}', (string) $value, $template);
        }

        return $template;
    }

    /**
     * Get prompt for review post generation
     *
     * Generates a complete review post from queue keyword and scraped products.
     * Uses rich product data (title, brand, price, features, pros, cons) and
     * related posts for internal linking suggestions.
     */
    private function getOptimizeReviewPrompt(array $data): string
    {
        $keyword = $data['keyword'] ?? '';
        $products = $data['products'] ?? [];
        $productsCount = $data['products_count'] ?? count($products);
        $relatedPosts = $data['related_posts'] ?? [];
        $categoryName = $data['category_name'] ?? '';
        $categoryPath = $data['category_path'] ?? '';

        // Current post content (from template)
        $currentTitle = $data['current_title'] ?? '';
        $currentContent = $data['current_content'] ?? '';
        $currentExcerpt = $data['current_excerpt'] ?? '';

        // Dynamic context variables (computed from products data)
        $brands = [];
        $prices = [];
        $totalReviews = 0;
        foreach ($products as $p) {
            if (!empty($p['brand'])) $brands[$p['brand']] = true;
            $price = (float) ($p['price'] ?? 0);
            if ($price > 0) $prices[] = $price;
            $totalReviews += (int) ($p['reviews_count'] ?? 0);
        }
        $brandList = implode(', ', array_keys($brands));
        $brandCount = count($brands);
        $priceMin = !empty($prices) ? '$' . number_format(min($prices), 2) : 'N/A';
        $priceMax = !empty($prices) ? '$' . number_format(max($prices), 2) : 'N/A';
        $year = date('Y');
        $monthText = date('F');
        $author = get_bloginfo('name');

        // Format products data for prompt
        $productsText = $this->formatProductsForPrompt($products);

        // Format related posts for internal linking
        $relatedPostsText = $this->formatRelatedPostsForPrompt($relatedPosts);

        // Read prompt from wp_options (seeded on activation, editable in admin)
        $template = get_option('acms_ai_prompt_optimize_review', '');

        if (empty($template)) {
            throw new \Exception('Optimize Review prompt template is empty. Please configure it in AI Assistant settings or re-activate the plugin to restore defaults.');
        }

        // Build price range
        $priceRange = ($priceMin !== 'N/A' && $priceMax !== 'N/A') ? "{$priceMin} - {$priceMax}" : 'N/A';

        // Extract shortcode from existing content
        $shortcodeList = '';
        if (preg_match('/\[acms_list[^\]]*\]/', $currentContent, $m)) {
            $shortcodeList = $m[0];
        }

        // Replace variables in template
        $replacements = [
            '{{keyword}}'          => $keyword,
            '{{keyword_title}}'    => ucwords($keyword),
            '{{current_title}}'    => $currentTitle,
            '{{existing_title}}'   => $currentTitle,
            '{{current_content}}'  => $currentContent,
            '{{existing_content}}' => $currentContent,
            '{{current_excerpt}}'  => $currentExcerpt,
            '{{products}}'         => $productsText,
            '{{products_count}}'   => (string) $productsCount,
            '{{related_posts}}'    => $relatedPostsText,
            '{{category_name}}'    => $categoryName,
            '{{category_path}}'    => $categoryPath,
            '{{shortcode_list}}'   => $shortcodeList,
            '{{year}}'             => $year,
            '{{month_text}}'       => $monthText,
            '{{author}}'           => $author,
            '{{brand_list}}'       => $brandList,
            '{{brand_count}}'      => (string) $brandCount,
            '{{price_min}}'        => $priceMin,
            '{{price_max}}'        => $priceMax,
            '{{price_range}}'      => $priceRange,
            '{{review_count}}'     => number_format($totalReviews),
        ];
        $template = str_replace(array_keys($replacements), array_values($replacements), $template);

        return $template;
    }

    /**
     * Format products array into readable text for AI prompt
     */
    private function formatProductsForPrompt(array $products): string
    {
        if (empty($products)) {
            return '(No product data available)';
        }

        $output = [];
        $index = 1;

        foreach ($products as $product) {
            $productText = "### Product {$index}: {$product['title']}\n";
            $productText .= "- **ASIN**: {$product['asin']}\n";
            $productText .= "- **Brand**: " . ($product['brand'] ?: 'N/A') . "\n";
            $productText .= "- **Price**: " . ($product['price'] ?: 'N/A') . "\n";
            $productText .= "- **Rating**: " . ($product['rating'] ?: 'N/A') . "/5";
            if (!empty($product['reviews_count'])) {
                $productText .= " ({$product['reviews_count']} reviews)";
            }
            $productText .= "\n";

            // Features
            if (!empty($product['features'])) {
                $productText .= "- **Key Features**:\n";
                foreach (array_slice($product['features'], 0, 5) as $feature) {
                    $productText .= "  - {$feature}\n";
                }
            }

            // Pros
            if (!empty($product['pros'])) {
                $productText .= "- **Pros**: " . implode(', ', $product['pros']) . "\n";
            }

            // Cons
            if (!empty($product['cons'])) {
                $productText .= "- **Cons**: " . implode(', ', $product['cons']) . "\n";
            }

            // Short review
            if (!empty($product['short_review'])) {
                $productText .= "- **AI Summary**: {$product['short_review']}\n";
            }

            $output[] = $productText;
            $index++;
        }

        return implode("\n", $output);
    }

    /**
     * Format related posts array into readable text for AI prompt
     */
    private function formatRelatedPostsForPrompt(array $posts): string
    {
        if (empty($posts)) {
            return '(No related posts available for internal linking)';
        }

        $output = "Use these related posts for internal linking where relevant:\n";
        foreach (array_slice($posts, 0, 30) as $post) {
            $output .= "- [{$post['title']}]({$post['url']})\n";
        }

        return $output;
    }

    /**
     * Format related categories for AI internal linking prompt
     */
    private function formatRelatedCategoriesForPrompt(array $relatedCategories): string
    {
        $hasData = !empty($relatedCategories['siblings'])
            || !empty($relatedCategories['children'])
            || !empty($relatedCategories['ancestors'])
            || !empty($relatedCategories['popular']);

        if (!$hasData) {
            return '';
        }

        $output = "## Related Categories for Internal Linking\n";
        $output .= "IMPORTANT: You MUST include 3-5 internal links in content_main HTML using the categories below.\n";
        $output .= "Use this exact HTML format: <a href=\"/c/{slug}/\">Category Name</a>\n";
        $output .= "Weave them naturally into sentences. Example: \"If you're looking for portable options, check our <a href=\"/c/portable-generators/\">Portable Generators</a> guide.\"\n\n";

        if (!empty($relatedCategories['ancestors'])) {
            $output .= "Parent categories (broader topics — good for \"back to\" or \"part of\" references):\n";
            foreach ($relatedCategories['ancestors'] as $cat) {
                $output .= "- {$cat['name']} → /c/{$cat['slug']}/";
                if (!empty($cat['product_count'])) {
                    $output .= " ({$cat['product_count']} products)";
                }
                $output .= "\n";
            }
            $output .= "\n";
        }

        if (!empty($relatedCategories['children'])) {
            $output .= "Subcategories (more specific topics — great for \"explore\" or \"see also\" links):\n";
            foreach ($relatedCategories['children'] as $cat) {
                $output .= "- {$cat['name']} → /c/{$cat['slug']}/";
                if (!empty($cat['product_count'])) {
                    $output .= " ({$cat['product_count']} products)";
                }
                $output .= "\n";
            }
            $output .= "\n";
        }

        if (!empty($relatedCategories['siblings'])) {
            $output .= "Related categories (same level — good for comparison or alternative references):\n";
            foreach ($relatedCategories['siblings'] as $cat) {
                $output .= "- {$cat['name']} → /c/{$cat['slug']}/";
                if (!empty($cat['product_count'])) {
                    $output .= " ({$cat['product_count']} products)";
                }
                $output .= "\n";
            }
            $output .= "\n";
        }

        if (!empty($relatedCategories['popular'])) {
            $output .= "Popular categories on this site (use where contextually relevant):\n";
            foreach ($relatedCategories['popular'] as $cat) {
                $output .= "- {$cat['name']} → /c/{$cat['slug']}/";
                if (!empty($cat['product_count'])) {
                    $output .= " ({$cat['product_count']} products)";
                }
                $output .= "\n";
            }
        }

        return $output;
    }

    /**
     * Format brand link data for AI prompt.
     *
     * Provides SEO brand pages (/brand/slug/) and brand sub-category pages (/c/slug/)
     * so the AI can weave brand links into the content naturally.
     */
    private function formatBrandLinksForPrompt(array $brandLinks): string
    {
        $seoBrands = $brandLinks['seo_brands'] ?? [];
        $brandCategories = $brandLinks['brand_categories'] ?? [];

        if (empty($seoBrands) && empty($brandCategories)) {
            return '';
        }

        $output = "\n## Brand Links for Internal Linking\n";
        $output .= "You may include 3-5 brand links where they fit naturally. Do NOT force all of them.\n";
        $output .= "Only link brands that are meaningfully discussed or compared in the content.\n\n";

        if (!empty($seoBrands)) {
            $output .= "Brand pages (dedicated brand hubs — good for \"learn more about [Brand]\" references):\n";
            foreach ($seoBrands as $b) {
                $output .= "- {$b['name']} → {$b['url']}";
                if (!empty($b['product_count'])) {
                    $output .= "  ({$b['product_count']} products)";
                }
                $output .= "\n";
            }
            $output .= "Use format: <a href=\"{url}\">{Brand Name}</a>\n\n";
        }

        if (!empty($brandCategories)) {
            $output .= "Brand-specific category pages (brand + category combos — good for \"see all [Brand] [Category]\" references):\n";
            foreach ($brandCategories as $bc) {
                $output .= "- {$bc['name']} → {$bc['url']}";
                if (!empty($bc['product_count'])) {
                    $output .= "  ({$bc['product_count']} products)";
                }
                $output .= "\n";
            }
            $output .= "Use format: <a href=\"{url}\">{Brand Category Name}</a>\n";
        }

        $output .= "\nIMPORTANT BRAND LINK RULES:\n";
        $output .= "- Include at most 3-5 brand links total (combining both types). Quality over quantity.\n";
        $output .= "- Only link brands that are relevant to what you're writing about in that paragraph.\n";
        $output .= "- Do NOT create a list of all brand links — weave them into sentences naturally.\n";
        $output .= "- Excessive brand links hurt SEO. Be selective and purposeful.\n";

        return $output;
    }

    /**
     * Get prompt for parent category generation (non-queue categories in the path)
     */
    private function getGenerateCategoryPrompt(array $data): string
    {
        $categoryName = $data['category_name'] ?? '';
        $categoryPath = $data['category_path'] ?? '';
        $parentCategory = $data['parent_category'] ?? '';
        $childCount = $data['child_count'] ?? 0;
        $childCategories = $data['child_categories'] ?? '';
        $depth = $data['depth'] ?? 0;
        $relatedCategories = $data['related_categories'] ?? [];
        $brandLinks = $data['brand_links'] ?? [];

        // Format related categories for context
        $relatedCategoriesContext = $this->formatRelatedCategoriesForPrompt($relatedCategories);
        $brandLinksContext = $this->formatBrandLinksForPrompt($brandLinks);

        // Read prompt from wp_options (seeded on activation, editable in admin)
        $template = get_option('acms_ai_prompt_generate_category', '');

        if (empty($template)) {
            throw new \Exception('Generate Category prompt template is empty. Please configure it in AI Assistant settings or re-activate the plugin to restore defaults.');
        }

        // Replace variables in template
        $template = str_replace('{{category_name}}', $categoryName, $template);
        $template = str_replace('{{category_path}}', $categoryPath, $template);
        $template = str_replace('{{parent_category}}', $parentCategory, $template);
        $template = str_replace('{{child_count}}', (string) $childCount, $template);
        $template = str_replace('{{child_categories}}', $childCategories, $template);
        $template = str_replace('{{depth}}', (string) $depth, $template);
        $template = str_replace('{{related_categories}}', $relatedCategoriesContext, $template);
        $template = str_replace('{{brand_links}}', $brandLinksContext, $template);

        return $template;
    }

    /**
     * Get prompt for category standardization
     * Analyzes products from a queue and proposes standardized category paths
     */
    private function getStandardizeCategoriesPrompt(array $data): string
    {
        $keyword = $data['keyword'] ?? '';
        $products = $data['products'] ?? [];
        $existingCategories = $data['existing_categories'] ?? [];

        // Build products summary for the prompt
        $productsSummary = [];
        foreach ($products as $product) {
            $productsSummary[] = [
                'asin' => $product['asin'] ?? '',
                'title' => $product['title'] ?? '',
                'brand' => $product['brand'] ?? '',
                'category_path' => $product['category_path'] ?? '',
            ];
        }

        $productsJson = wp_json_encode($productsSummary, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        $existingCategoriesJson = wp_json_encode($existingCategories, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

        // Read prompt from wp_options (seeded on activation, editable in admin)
        $template = get_option('acms_ai_prompt_standardize_categories', '');

        if (empty($template)) {
            throw new \Exception('Standardize Categories prompt template is empty. Please configure it in AI Assistant settings or re-activate the plugin to restore defaults.');
        }

        // Replace variables in template
        $template = str_replace('{{keyword}}', $keyword, $template);
        $template = str_replace('{{products_json}}', $productsJson, $template);
        $template = str_replace('{{existing_categories_json}}', $existingCategoriesJson, $template);

        return $template;
    }

    /**
     * Get prompt for SEO category content generation
     * Generates comprehensive content for a custom SEO category page
     */
    private function getGenerateSeoCategoryPrompt(array $data): string
    {
        $categoryName = $data['category_name'] ?? '';
        $categoryPath = $data['category_path'] ?? '';
        $parentCategories = $data['parent_categories'] ?? [];
        $products = $data['products'] ?? [];
        $productCount = count($products);
        $relatedCategories = $data['related_categories'] ?? [];
        $brandName = $data['brand_name'] ?? '';
        $isBrandCategory = !empty($brandName);
        $brandLinks = $data['brand_links'] ?? [];

        // Format products for context
        $productsContext = '';
        if (!empty($products)) {
            $productsContext = "Products in this category ({$productCount} items):\n";
            foreach (array_slice($products, 0, 10) as $product) {
                $productsContext .= "- {$product['title']}";
                // Skip brand label for brand-categories (all same brand)
                if (!$isBrandCategory && !empty($product['brand'])) {
                    $productsContext .= " (by {$product['brand']})";
                }
                $productsContext .= "\n";
            }
            if ($productCount > 10) {
                $productsContext .= "... and " . ($productCount - 10) . " more products\n";
            }
        }

        // Format parent categories
        $parentsContext = '';
        if (!empty($parentCategories)) {
            $parentsContext = "Parent categories: " . implode(' > ', $parentCategories) . "\n";
        }

        // Format related categories for internal linking
        $relatedCategoriesContext = $this->formatRelatedCategoriesForPrompt($relatedCategories);

        // Format brand links — skip for brand-category pages (would be self-referential)
        $brandLinksContext = $isBrandCategory ? '' : $this->formatBrandLinksForPrompt($brandLinks);

        // Read prompt from wp_options (seeded on activation, editable in admin)
        $template = get_option('acms_ai_seo_category_prompt_template', '');

        if (empty($template)) {
            throw new \Exception('SEO Category prompt template is empty. Please configure it in AI Assistant settings or re-activate the plugin to restore defaults.');
        }

        // Replace variables (with fallbacks for empty data)
        $replacements = [
            '{{category_name}}'       => $categoryName,
            '{{category_path}}'       => $categoryPath ?: $categoryName,
            '{{parents_context}}'     => $parentsContext ?: '',
            '{{products_context}}'    => $productsContext ?: '(no product data available yet)',
            '{{product_count}}'       => (string) $productCount,
            '{{related_categories}}'  => $relatedCategoriesContext ?: '(no related categories available)',
            '{{brand_links}}'         => $brandLinksContext ?: '',
        ];
        $template = str_replace(array_keys($replacements), array_values($replacements), $template);

        // Append brand-specific instructions for brand-category pages
        if ($isBrandCategory) {
            $template .= "\n\nBRAND-SPECIFIC PAGE INSTRUCTIONS:\n" .
                "This is a brand-specific category page for \"{$brandName}\". All products on this page are from {$brandName}.\n" .
                "- Focus on {$brandName} as a brand: reputation, quality, what makes their products stand out\n" .
                "- Compare different {$brandName} models/products within this category — help buyers choose between them\n" .
                "- Do NOT repeat the brand name for every product (readers already know this is a {$brandName} page)\n" .
                "- Include brand-relevant FAQs: warranty, customer support, {$brandName} vs competitors, which model to choose\n" .
                "- SEO title should include both the brand name and category (e.g., \"Best {$brandName} {$categoryName}\")";
        }

        return $template;
    }

    /**
     * Get prompt for SEO brand content generation
     * Generates comprehensive content for a brand page
     */
    private function getGenerateSeoBrandPrompt(array $data): string
    {
        $brandName = $data['brand_name'] ?? '';
        $brandSlug = $data['brand_slug'] ?? '';
        $websiteUrl = $data['website_url'] ?? '';
        $products = $data['products'] ?? [];
        $productCount = count($products);
        $totalProductCount = $data['total_product_count'] ?? $productCount;

        // Format products for context
        $productsContext = '';
        if (!empty($products)) {
            $productsContext = "Sample products from this brand ({$totalProductCount} total):\n";
            foreach (array_slice($products, 0, 15) as $product) {
                $productsContext .= "- {$product['title']}";
                if (!empty($product['rating'])) {
                    $productsContext .= " (Rating: {$product['rating']}/5)";
                }
                $productsContext .= "\n";
            }
            if ($totalProductCount > 15) {
                $productsContext .= "... and " . ($totalProductCount - 15) . " more products\n";
            }
        }

        // Get categories context from products
        $categories = [];
        foreach ($products as $product) {
            if (!empty($product['category_path'])) {
                $categories[] = $product['category_path'];
            }
        }
        $categories = array_unique($categories);
        $categoriesContext = !empty($categories)
            ? "Product categories: " . implode(', ', array_slice($categories, 0, 5))
            : '(no category data available)';

        // Ensure total_product_count is at least count of products we have
        if ($totalProductCount < $productCount) {
            $totalProductCount = $productCount;
        }

        // Format brand category links for internal linking
        $brandCategoryLinks = $data['brand_category_links'] ?? [];
        $brandCategoryLinksContext = $this->formatBrandCategoryLinksForPrompt($brandCategoryLinks);
        if (empty($brandCategoryLinksContext)) {
            $brandCategoryLinksContext = '(no category links available - skip internal linking instructions)';
        }

        // Read prompt from wp_options (seeded on activation, editable in admin)
        $template = get_option('acms_ai_seo_brand_prompt_template', '');

        if (empty($template)) {
            throw new \Exception('SEO Brand prompt template is empty. Please configure it in AI Assistant settings or re-activate the plugin to restore defaults.');
        }

        // Build website context
        $websiteContext = !empty($websiteUrl)
            ? "Official Website: {$websiteUrl}"
            : '(not available)';

        // Replace variables
        $replacements = [
            '{{brand_name}}'           => $brandName,
            '{{brand_slug}}'           => $brandSlug,
            '{{website_context}}'      => $websiteContext,
            '{{categories_context}}'   => $categoriesContext,
            '{{products_context}}'     => $productsContext ?: '(no product data available)',
            '{{product_count}}'        => (string) $totalProductCount,
            '{{brand_category_links}}' => $brandCategoryLinksContext,
        ];
        $template = str_replace(array_keys($replacements), array_values($replacements), $template);

        return $template;
    }

    /**
     * Format brand category links for prompt context
     *
     * @param array<array{name: string, slug: string, brand_product_count: int}> $categoryLinks
     */
    private function formatBrandCategoryLinksForPrompt(array $categoryLinks): string
    {
        if (empty($categoryLinks)) {
            return '';
        }

        $output = "## Related Category Pages for Internal Linking\n";
        $output .= "Naturally embed 3-5 internal links in content_main to these category pages where contextually relevant.\n";
        $output .= "Link format: <a href=\"/c/{slug}/\">{Category Name}</a>\n\n";
        $output .= "Categories this brand's products appear in:\n";

        foreach ($categoryLinks as $cat) {
            $output .= "- [{$cat['name']}](/c/{$cat['slug']}/)";
            if (!empty($cat['brand_product_count'])) {
                $output .= " ({$cat['brand_product_count']} products)";
            }
            $output .= "\n";
        }

        return $output;
    }

    /**
     * Get appropriate timeout for job type
     * Longer content generation (posts, categories, brands) needs more time
     */
    private function getTimeoutForJobType(string $type): int
    {
        return match ($type) {
            // Long content generation - needs 3 minutes for complex posts
            'optimize_review' => 180,
            'generate_seo_category' => 180,
            'generate_seo_brand' => 180,
            // Medium content - 2 minutes
            'generate_category' => 120,
            'standardize_categories' => 120,
            // Short content - 1 minute
            'enhance_asin' => 60,
            default => 90,
        };
    }

    /**
     * Call OpenRouter API
     *
     * @param string $model Model identifier
     * @param string $prompt The prompt to send
     * @param int $timeout Request timeout in seconds (default 60)
     */
    private function callApi(string $model, string $prompt, int $timeout = 60): array
    {
        $siteName = get_bloginfo('name') ?: 'AffiliateCMS';

        $requestBody = [
            'model' => $model,
            'messages' => [
                ['role' => 'system', 'content' => 'You are an expert SEO content writer. Always respond with valid JSON only, no markdown code fences or extra text.'],
                ['role' => 'user', 'content' => $prompt],
            ],
            'temperature' => 0.7,
            'max_tokens' => 4096,
        ];

        $encodedBody = wp_json_encode($requestBody);

        $response = wp_remote_post($this->apiUrl, [
            'headers' => [
                'Authorization' => 'Bearer ' . $this->apiKey,
                'Content-Type' => 'application/json',
                'HTTP-Referer' => get_site_url() ?: 'https://affiliatecms.com',
                'X-Title' => $siteName,
            ],
            'body' => $encodedBody,
            'timeout' => $timeout,
        ]);

        if (is_wp_error($response)) {
            return [
                'success' => false,
                'error' => $response->get_error_message(),
            ];
        }

        $httpCode = wp_remote_retrieve_response_code($response);
        $rawBody = wp_remote_retrieve_body($response);

        $body = json_decode($rawBody, true);

        if ($body === null) {
            return [
                'success' => false,
                'error' => "API response decode failed (HTTP {$httpCode}): " . json_last_error_msg(),
            ];
        }

        if (isset($body['error'])) {
            return [
                'success' => false,
                'error' => $body['error']['message'] ?? 'API error',
            ];
        }

        $content = $body['choices'][0]['message']['content'] ?? '';
        $usage = $body['usage'] ?? [];

        $finishReason = $body['choices'][0]['finish_reason'] ?? 'unknown';
        $inputTokens = $usage['prompt_tokens'] ?? 0;
        $outputTokens = $usage['completion_tokens'] ?? 0;
        $totalTokens = $inputTokens + $outputTokens;

        if (empty($content)) {
            return [
                'success' => false,
                'error' => "API returned empty content (HTTP {$httpCode}, finish_reason={$finishReason})",
            ];
        }

        // Extract generation_id and created timestamp from OpenRouter response
        $generationId = $body['id'] ?? null;
        $apiCreatedAt = isset($body['created']) ? gmdate('c', (int) $body['created']) : null;

        // Parse JSON from content
        $jsonMatch = [];
        if (preg_match('/\{[\s\S]*\}/', $content, $jsonMatch)) {
            $data = json_decode($jsonMatch[0], true);
            if ($data === null) {
                error_log("[ACMS Job] API JSON parse failed: " . json_last_error_msg());
                $data = ['raw' => $content];
            }
        } else {
            error_log("[ACMS Job] No JSON found in API response content");
            $data = ['raw' => $content];
        }

        // Estimate cost based on model (simplified)
        $cost = $this->estimateCost($model, $inputTokens, $outputTokens);

        return [
            'success' => true,
            'data' => $data,
            'tokens' => $totalTokens,
            'tokens_input' => $inputTokens,
            'tokens_output' => $outputTokens,
            'cost' => $cost,
            'generation_id' => $generationId,
            'api_created_at' => $apiCreatedAt,
        ];
    }

    /**
     * Estimate cost based on model and tokens
     */
    private function estimateCost(string $model, int $inputTokens, int $outputTokens): float
    {
        // Prices per million tokens (simplified)
        $prices = [
            'openai/gpt-4o-mini' => ['input' => 0.15, 'output' => 0.60],
            'openai/gpt-4o' => ['input' => 5.00, 'output' => 15.00],
            'anthropic/claude-3.5-sonnet' => ['input' => 3.00, 'output' => 15.00],
            'anthropic/claude-3-haiku' => ['input' => 0.25, 'output' => 1.25],
            'google/gemini-pro' => ['input' => 0.125, 'output' => 0.375],
            'google/gemini-flash-1.5' => ['input' => 0.075, 'output' => 0.30],
        ];

        $modelPrices = $prices[$model] ?? ['input' => 0.50, 'output' => 1.50];

        $inputCost = ($inputTokens / 1000000) * $modelPrices['input'];
        $outputCost = ($outputTokens / 1000000) * $modelPrices['output'];

        return round($inputCost + $outputCost, 6);
    }

    /**
     * Track usage in database
     */
    private function trackUsage(string $model, int $tokens, float $cost): void
    {
        global $wpdb;
        $table = $wpdb->prefix . 'acms_ai_usage';
        $date = current_time('Y-m-d');

        // Try to update existing record
        $updated = $wpdb->query($wpdb->prepare("
            INSERT INTO {$table} (date, model, requests_count, tokens_output, cost_total)
            VALUES (%s, %s, 1, %d, %f)
            ON DUPLICATE KEY UPDATE
                requests_count = requests_count + 1,
                tokens_output = tokens_output + %d,
                cost_total = cost_total + %f
        ", $date, $model, $tokens, $cost, $tokens, $cost));
    }

    /**
     * Apply job result to target
     */
    private function applyJobResult(string $type, array $inputData, array $result, ?string $generationId = null): void
    {
        switch ($type) {
            case 'enhance_asin':
                $this->applyEnhanceAsin($inputData['asin'], $result, $generationId);
                break;

            case 'optimize_review':
                $this->applyOptimizeReview($inputData, $result, $generationId);
                break;

            case 'generate_category':
                $this->applyGenerateCategory($inputData['term_id'], $result);
                break;

            case 'standardize_categories':
                $this->applyStandardizeCategories($inputData['queue_id'], $result, $generationId);
                break;

            case 'generate_seo_category':
                // Use handler that also updates queue status
                $this->handleSeoCategoryGenerated($inputData, $result, $generationId);
                break;

            case 'generate_seo_brand':
                $this->applyGenerateSeoBrand($inputData, $result, $generationId);
                break;
        }
    }

    /**
     * Apply ASIN enhancement
     */
    private function applyEnhanceAsin(string $asin, array $result, ?string $generationId = null): void
    {
        // Add generation_id to result for the action hook
        $result['_generation_id'] = $generationId;

        // Update ASIN data in affiliatecms-pro
        do_action('acms_ai_asin_enhanced', $asin, $result);
    }

    /**
     * Apply review post optimization
     *
     * Optimizes an EXISTING WordPress post that was created by the template system.
     * The post already exists (generated_post_id) - AI rewrites title, content, and SEO.
     *
     * Flow: Queue → Template creates post → ai_post_status='queued' → AI optimizes existing post
     *
     * @param array $inputData Input data containing queue_id, post_id, keyword, etc.
     * @param array $result AI-generated content (title, content, excerpt, seo fields)
     * @param string|null $generationId OpenRouter generation ID for tracking
     */
    private function applyOptimizeReview(array $inputData, array $result, ?string $generationId = null): void
    {
        global $wpdb;

        $queueId = $inputData['queue_id'] ?? 0;
        $postId = $inputData['post_id'] ?? 0; // Post already created by template
        $keyword = $inputData['keyword'] ?? '';
        $products = $inputData['products'] ?? [];

        if (empty($queueId)) {
            error_log('[ACMS Job] applyOptimizeReview: No queue_id provided');
            return;
        }

        if (empty($postId)) {
            error_log("[ACMS Job] applyOptimizeReview: No post_id for queue #{$queueId}");
            $this->updateQueueItemStatus($queueId, 'failed', 'No existing post to optimize');
            return;
        }

        // Verify post exists
        $post = get_post($postId);
        if (!$post) {
            error_log("[ACMS Job] applyOptimizeReview: Post #{$postId} not found");
            $this->updateQueueItemStatus($queueId, 'failed', "Post #{$postId} not found");
            return;
        }

        // Extract content from AI result
        $title = $result['title'] ?? '';
        $content = $result['content'] ?? '';
        $excerpt = $result['excerpt'] ?? '';
        $seoTitle = $result['seo_title'] ?? $title;
        $seoDescription = $result['seo_description'] ?? $excerpt;
        $focusKeywords = $result['focus_keywords'] ?? [$keyword];

        if (empty($content)) {
            $this->updateQueueItemStatus($queueId, 'failed', 'AI returned empty content');
            return;
        }

        // Update existing post with AI-optimized content
        $updateData = [
            'ID' => $postId,
            'post_content' => wp_kses_post($content),
        ];

        // Only update title if AI provided one
        if (!empty($title)) {
            $updateData['post_title'] = sanitize_text_field($title);
        }

        // Only update excerpt if AI provided one
        if (!empty($excerpt)) {
            $updateData['post_excerpt'] = sanitize_text_field($excerpt);
        }

        $updated = wp_update_post($updateData, true);

        if (is_wp_error($updated)) {
            error_log("[ACMS Job] Failed to update post #{$postId}: " . $updated->get_error_message());
            $this->updateQueueItemStatus($queueId, 'failed', $updated->get_error_message());
            return;
        }

        // Update SEO meta (compatible with Yoast SEO)
        if (!empty($seoTitle)) {
            update_post_meta($postId, '_yoast_wpseo_title', sanitize_text_field($seoTitle));
        }
        if (!empty($seoDescription)) {
            update_post_meta($postId, '_yoast_wpseo_metadesc', sanitize_text_field($seoDescription));
        }

        // Save focus keywords
        if (!empty($focusKeywords)) {
            $focusKeyword = is_array($focusKeywords) ? $focusKeywords[0] : $focusKeywords;
            update_post_meta($postId, '_yoast_wpseo_focuskw', sanitize_text_field($focusKeyword));
        }

        // Save ACMS-specific meta
        update_post_meta($postId, '_acms_ai_optimized', true);
        update_post_meta($postId, '_acms_ai_optimized_at', current_time('mysql'));
        update_post_meta($postId, '_acms_ai_generation_id', $generationId);

        // Save linked ASINs if provided
        if (!empty($products)) {
            $asins = array_column($products, 'asin');
            update_post_meta($postId, '_acms_linked_asins', $asins);
        }

        // Update queue item with success
        $queueTable = $wpdb->prefix . 'acms_queue';
        $wpdb->update(
            $queueTable,
            [
                'ai_post_status' => 'generated',
                'ai_post_id' => $postId,
                'ai_post_generated_at' => current_time('mysql'),
                'ai_post_error' => null,
            ],
            ['id' => $queueId],
            ['%s', '%d', '%s', '%s'],
            ['%d']
        );

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("[ACMS Job] Optimized review post #{$postId} for queue item #{$queueId} (keyword: {$keyword})");
        }

        // Fire action for other plugins to hook into
        do_action('acms_ai_review_optimized', $postId, $queueId, $result, $generationId);
    }

    /**
     * Update queue item status
     *
     * @param int $queueId Queue item ID
     * @param string $status Status (generating, generated, failed)
     * @param string|null $error Error message if failed
     */
    private function updateQueueItemStatus(int $queueId, string $status, ?string $error = null): void
    {
        global $wpdb;
        $queueTable = $wpdb->prefix . 'acms_queue';

        $data = [
            'ai_post_status' => $status,
        ];

        if ($status === 'generated') {
            $data['ai_post_generated_at'] = current_time('mysql');
            $data['ai_post_error'] = null;
        } elseif ($status === 'failed') {
            $data['ai_post_error'] = $error;
        }

        $wpdb->update($queueTable, $data, ['id' => $queueId]);
    }

    /**
     * Apply category generation
     */
    private function applyGenerateCategory(int $termId, array $result): void
    {
        // 1. Update WP taxonomy term description
        if (!empty($result['description'])) {
            wp_update_term($termId, 'category', [
                'description' => $result['description'],
            ]);
        }

        // 2. Save meta_description as term meta
        if (!empty($result['meta_description'])) {
            update_term_meta($termId, '_acms_seo_description', $result['meta_description']);
        }

        // 3. Try to update matching acms_categories entry if plugin available
        if (!empty($result['content_main']) || !empty($result['description']) || !empty($result['meta_description'])) {
            $this->syncParentCategoryToAcms($termId, $result);
        }

        do_action('acms_ai_category_generated', $termId, $result);
    }

    /**
     * Sync parent category AI result to acms_categories table
     * Finds matching category by name and updates content fields
     */
    private function syncParentCategoryToAcms(int $termId, array $result): void
    {
        if (!class_exists(\AffiliateCMS\Categories\Repositories\CategoryRepository::class)) {
            return;
        }

        $term = get_term($termId, 'category');
        if (!$term || is_wp_error($term)) {
            return;
        }

        global $wpdb;
        $table = $wpdb->prefix . 'acms_categories';

        // Find acms_categories entry matching this term name
        $categoryId = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$table} WHERE name = %s AND content_status IN ('empty', 'failed') LIMIT 1",
            $term->name
        ));

        if (!$categoryId) {
            return;
        }

        $updateData = [];

        if (!empty($result['description'])) {
            $updateData['description'] = wp_strip_all_tags($result['description']);
        }
        if (!empty($result['meta_description'])) {
            $updateData['seo_description'] = wp_strip_all_tags($result['meta_description']);
        }
        if (!empty($result['content_main'])) {
            $updateData['content_main'] = wp_kses_post($result['content_main']);
            $updateData['content_status'] = 'generated';
        }

        if (!empty($updateData)) {
            $wpdb->update($table, $updateData, ['id' => $categoryId]);

            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("[ACMS AI] Synced parent category AI to acms_categories #{$categoryId} ({$term->name})");
            }
        }
    }

    /**
     * Apply category standardization results
     * Updates queue item and products with AI-suggested category paths
     * Auto-creates categories and links products to them
     */
    private function applyStandardizeCategories(int $queueId, array $result, ?string $generationId = null): void
    {
        // Check if affiliatecms-cat plugin is available
        if (!class_exists(\AffiliateCMS\Categories\Repositories\QueueRepository::class)) {
            return;
        }
        if (!class_exists(\AffiliateCMS\Categories\Repositories\CategoryRepository::class)) {
            return;
        }

        $queueRepo = new \AffiliateCMS\Categories\Repositories\QueueRepository();
        $categoryRepo = new \AffiliateCMS\Categories\Repositories\CategoryRepository();

        $productAssignments = $result['product_assignments'] ?? [];
        $suggestedPaths = $result['suggested_paths'] ?? [];

        // Get the primary path (first suggested path for this queue/keyword)
        $primaryPath = !empty($suggestedPaths) ? $suggestedPaths[0] : '';

        // Create the primary category from path
        $primaryCategoryId = null;
        if (!empty($primaryPath)) {
            $primaryCategoryId = $this->createCategoryFromPath($categoryRepo, $primaryPath);
        }

        // Update queue item with suggested categories and assigned category
        // NOTE: Don't set status='completed' yet - content generation still needs to happen
        $queueRepo->update($queueId, [
            'suggested_categories' => wp_json_encode([
                'paths' => $suggestedPaths,
                'assignments' => $productAssignments,
                'reasoning' => $result['reasoning'] ?? '',
            ]),
            'cat_ai_generation_id' => $generationId,
            'ai_status' => 'category_assigned',  // Path assigned, content pending
            // status stays as 'ready_for_ai' - will be 'completed' after content generation
            'custom_category_path' => $primaryPath,
            'assigned_category_id' => $primaryCategoryId,
        ]);

        // Auto-trigger content generation for the primary category
        if ($primaryCategoryId) {
            $this->triggerCategoryContentGeneration($primaryCategoryId, $queueId);
        }

        // Update each product and link to categories
        if (!empty($productAssignments) && class_exists(\AffiliateCMS\Pro\Repositories\ProductRepository::class)) {
            $productRepo = \AffiliateCMS\Pro\Repositories\ProductRepository::instance();

            foreach ($productAssignments as $asin => $categoryPaths) {
                // Ensure categoryPaths is an array
                if (!is_array($categoryPaths)) {
                    $categoryPaths = [$categoryPaths];
                }

                // Find product by ASIN
                $product = $productRepo->findByAsin($asin);
                if (!$product) {
                    continue;
                }

                // APPEND paths (not replace) - product may belong to multiple queue items
                $productRepo->appendCategoryPaths($product->id, $categoryPaths);

                // Create categories and link product to each
                $isFirst = true;
                foreach ($categoryPaths as $path) {
                    $categoryId = $this->createCategoryFromPath($categoryRepo, $path);
                    if ($categoryId) {
                        // Add product to category, first one is primary
                        $categoryRepo->addProduct($categoryId, $product->id, $isFirst);
                        $isFirst = false;
                    }
                }
            }
        }

        // Fire action for further processing
        do_action('acms_ai_categories_standardized', $queueId, $result, $generationId);
    }

    /**
     * Apply SEO category content generation results
     * Updates the custom acms_categories table with AI-generated content
     * Also updates originating queue item status if queue_id is provided
     */
    private function applyGenerateSeoCategory(int $categoryId, array $result, ?string $generationId = null): void
    {
        // Check if affiliatecms-cat plugin is available
        if (!class_exists(\AffiliateCMS\Categories\Repositories\CategoryRepository::class)) {
            return;
        }

        $categoryRepo = new \AffiliateCMS\Categories\Repositories\CategoryRepository();

        // Prepare update data
        $updateData = [
            'content_status' => 'ai_generated',
            'content_updated_at' => current_time('mysql'),
            'ai_error_message' => null,
        ];

        // Description field (brief category description)
        if (!empty($result['description'])) {
            $updateData['description'] = sanitize_text_field($result['description']);
        }

        // SEO fields
        if (!empty($result['seo_title'])) {
            $updateData['seo_title'] = sanitize_text_field($result['seo_title']);
        }

        if (!empty($result['seo_description'])) {
            $updateData['seo_description'] = sanitize_textarea_field($result['seo_description']);
        }

        // Content fields
        if (!empty($result['content_intro'])) {
            $updateData['content_intro'] = wp_kses_post($result['content_intro']);
        }

        if (!empty($result['content_main'])) {
            $updateData['content_main'] = wp_kses_post($result['content_main']);
        }

        if (!empty($result['content_faq'])) {
            // Ensure FAQ is stored as JSON
            if (is_array($result['content_faq'])) {
                $updateData['content_faq'] = wp_json_encode($result['content_faq']);
            } else {
                $updateData['content_faq'] = $result['content_faq'];
            }
        }

        // Update the category
        $categoryRepo->update($categoryId, $updateData);

        // Fire action for further processing (brand-category creation, etc.)
        // Wrapped in try/catch so hook errors don't prevent queue completion
        try {
            do_action('acms_ai_seo_category_generated', $categoryId, $result, $generationId);
        } catch (\Throwable $hookError) {
            error_log("[ACMS Job] Hook error after category #{$categoryId} content saved (non-fatal): " . $hookError->getMessage());
        }
    }

    /**
     * Apply SEO category content generation results (with input data for queue tracking)
     * This is the actual handler that receives input_data with queue_id
     *
     * Note: This overloads applyGenerateSeoCategory to handle queue updates
     */
    private function handleSeoCategoryGenerated(array $inputData, array $result, ?string $generationId = null): void
    {
        $categoryId = (int) ($inputData['category_id'] ?? 0);
        if (!$categoryId) {
            return;
        }

        // Apply the content to the category
        $this->applyGenerateSeoCategory($categoryId, $result, $generationId);

        // Update the originating queue item
        global $wpdb;
        $queueTable = $wpdb->prefix . 'acms_cat_queue';
        $queueId = (int) ($inputData['queue_id'] ?? 0);

        // Fallback: if queue_id is missing, find it by category_id
        if ($queueId <= 0 && $categoryId > 0) {
            $queueId = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$queueTable}
                 WHERE assigned_category_id = %d
                 AND status != 'completed'
                 ORDER BY id DESC LIMIT 1",
                $categoryId
            ));
            if ($queueId > 0) {
                error_log("[ACMS Job] queue_id was 0, resolved to #{$queueId} via category #{$categoryId}");
            }
        }

        if ($queueId > 0) {
            // Mark queue item as fully completed
            $updated = $wpdb->update(
                $queueTable,
                [
                    'ai_status' => 'completed',
                    'status' => 'completed',
                    'completed_at' => current_time('mysql'),
                ],
                ['id' => $queueId],
                ['%s', '%s', '%s'],
                ['%d']
            );

            if ($updated === false) {
                error_log("[ACMS Job] FAILED to update queue #{$queueId} to completed: " . $wpdb->last_error);
            } else {
                error_log("[ACMS Job] Queue #{$queueId} marked completed (category #{$categoryId})");
            }
        } else {
            error_log("[ACMS Job] No queue item found for category #{$categoryId} — skipped queue status update");
        }
    }

    /**
     * Reset target entity status when job fails
     * Dispatches to the correct reset method based on job type
     */
    private function resetTargetOnFailure(array $job, string $errorMessage): void
    {
        $truncatedError = substr($errorMessage, 0, 500);

        switch ($job['type']) {
            case 'generate_seo_brand':
                if (!empty($job['target_id'])) {
                    $this->resetBrandOnFailure((int) $job['target_id'], $truncatedError);
                }
                break;

            case 'generate_seo_category':
                if (!empty($job['target_id'])) {
                    $this->resetCategoryOnFailure((int) $job['target_id'], $truncatedError);
                }
                break;

            case 'enhance_asin':
                if (!empty($job['target_id'])) {
                    $this->resetProductOnFailure($job['target_id'], $truncatedError);
                }
                break;
        }
    }

    /**
     * Reset category content_status when AI job fails
     */
    private function resetCategoryOnFailure(int $categoryId, string $errorMessage): void
    {
        global $wpdb;

        $categoriesTable = $wpdb->prefix . 'acms_categories';
        $wpdb->update(
            $categoriesTable,
            [
                'content_status' => 'empty',
                'ai_error_message' => $errorMessage,
            ],
            ['id' => $categoryId],
            ['%s', '%s'],
            ['%d']
        );

        // Reset queue item if stuck at 'generating_content'
        $queueTable = $wpdb->prefix . 'acms_cat_queue';
        $wpdb->query($wpdb->prepare(
            "UPDATE {$queueTable}
             SET ai_status = 'failed'
             WHERE assigned_category_id = %d AND ai_status = 'generating_content'",
            $categoryId
        ));

        error_log("[ACMS Job] Reset category #{$categoryId} to empty after job failure");
    }

    /**
     * Reset product ai_status when AI job fails
     */
    private function resetProductOnFailure(string $asin, string $errorMessage): void
    {
        if (!class_exists(\AffiliateCMS\Pro\Repositories\ProductRepository::class)) {
            return;
        }
        try {
            $repo = \AffiliateCMS\Pro\Repositories\ProductRepository::instance();
            $product = $repo->findByAsin($asin);
            if ($product) {
                $repo->update($product->id, [
                    'ai_status' => 'failed',
                    'ai_error_message' => $errorMessage,
                ]);
            }
        } catch (\Throwable $e) {
            error_log("[ACMS Job] Failed to reset product {$asin}: " . $e->getMessage());
        }
    }

    /**
     * Reset brand content_status when AI job fails
     */
    private function resetBrandOnFailure(int $brandId, string $errorMessage): void
    {
        $truncatedError = substr($errorMessage, 0, 500);

        if (class_exists(\AffiliateCMS\Pro\Repositories\BrandRepository::class)) {
            try {
                $brandRepo = \AffiliateCMS\Pro\Repositories\BrandRepository::instance();
                $brandRepo->update($brandId, [
                    'content_status' => 'empty',
                    'ai_error_message' => $truncatedError,
                ]);
                error_log("[ACMS Job] Reset brand #{$brandId} to empty after job failure");
                return;
            } catch (\Throwable $e) {
                error_log("[ACMS Job] BrandRepository reset failed for #{$brandId}: " . $e->getMessage());
            }
        }

        // Fallback: direct wpdb update
        global $wpdb;
        $table = $wpdb->prefix . 'acms_brands';
        $wpdb->update($table, [
            'content_status' => 'empty',
            'ai_error_message' => $truncatedError,
        ], ['id' => $brandId]);
        error_log("[ACMS Job] Reset brand #{$brandId} via direct wpdb after job failure");
    }

    /**
     * Apply SEO brand content generation results
     * Updates the acms_brands table with AI-generated content
     */
    private function applyGenerateSeoBrand(array $inputData, array $result, ?string $generationId = null): void
    {
        $brandId = (int) ($inputData['brand_id'] ?? 0);
        if (!$brandId) {
            error_log('[ACMS Job] applyGenerateSeoBrand: No brand_id in inputData. Keys: ' . implode(', ', array_keys($inputData)));
            return;
        }

        // Check if affiliatecms-pro plugin is available
        if (!class_exists(\AffiliateCMS\Pro\Repositories\BrandRepository::class)) {
            error_log('[ACMS Job] applyBrand: BrandRepository not found, using direct wpdb');
            $this->applyGenerateSeoBrandDirect($brandId, $result);
            return;
        }

        $brandRepo = \AffiliateCMS\Pro\Repositories\BrandRepository::instance();

        // Prepare update data
        // Auto-publish brand when AI content is generated
        $updateData = [
            'content_status' => 'ai_generated',
            'content_updated_at' => current_time('mysql'),
            'ai_generating_at' => null,
            'ai_error_message' => null,
            'status' => 'publish', // Auto-publish brand with AI content
        ];

        // Track which fields were populated from AI result
        $populatedFields = [];

        // Description field (brief brand description)
        if (!empty($result['description'])) {
            $updateData['description'] = sanitize_text_field($result['description']);
            $populatedFields[] = 'description';
        }

        // SEO fields
        if (!empty($result['seo_title'])) {
            $updateData['seo_title'] = sanitize_text_field($result['seo_title']);
            $populatedFields[] = 'seo_title';
        }

        if (!empty($result['seo_description'])) {
            $updateData['seo_description'] = sanitize_textarea_field($result['seo_description']);
            $populatedFields[] = 'seo_description';
        }

        // Content fields
        if (!empty($result['content_intro'])) {
            $updateData['content_intro'] = wp_kses_post($result['content_intro']);
            $populatedFields[] = 'content_intro';
        }

        if (!empty($result['content_main'])) {
            $updateData['content_main'] = wp_kses_post($result['content_main']);
            $populatedFields[] = 'content_main';
        }

        if (!empty($result['content_faq'])) {
            // Encode array to JSON string (consistent with category flow)
            // BrandRepository also handles this via JSON_COLUMNS, but be explicit
            if (is_array($result['content_faq'])) {
                $updateData['content_faq'] = wp_json_encode($result['content_faq']);
            } else {
                $updateData['content_faq'] = $result['content_faq'];
            }
            $populatedFields[] = 'content_faq';
        }

        if (empty($populatedFields)) {
            error_log("[ACMS Job] applyBrand #{$brandId}: WARNING - No content fields populated from AI result");
        }

        // Update the brand
        $updated = $brandRepo->update($brandId, $updateData);

        if (!$updated) {
            error_log("[ACMS Job] applyBrand #{$brandId}: FAILED to update! wpdb error: " . ($GLOBALS['wpdb']->last_error ?: 'none'));
        }

        // Fire action for further processing
        // Wrapped in try/catch so hook errors don't cascade back to processJob()
        try {
            do_action('acms_ai_seo_brand_generated', $brandId, $result, $generationId);
        } catch (\Throwable $hookError) {
            error_log("[ACMS Job] Hook error after brand #{$brandId} content saved (non-fatal): " . $hookError->getMessage());
        }
    }

    /**
     * Direct database fallback for brand update when BrandRepository is unavailable
     * This handles the edge case where affiliatecms-pro classes aren't autoloaded during AS processing
     */
    private function applyGenerateSeoBrandDirect(int $brandId, array $result): void
    {
        global $wpdb;
        $table = $wpdb->prefix . 'acms_brands';

        $updateData = [
            'content_status' => 'ai_generated',
            'content_updated_at' => current_time('mysql'),
            'ai_generating_at' => null,
            'ai_error_message' => null,
            'status' => 'publish',
        ];

        if (!empty($result['description'])) {
            $updateData['description'] = sanitize_text_field($result['description']);
        }
        if (!empty($result['seo_title'])) {
            $updateData['seo_title'] = sanitize_text_field($result['seo_title']);
        }
        if (!empty($result['seo_description'])) {
            $updateData['seo_description'] = sanitize_textarea_field($result['seo_description']);
        }
        if (!empty($result['content_intro'])) {
            $updateData['content_intro'] = wp_kses_post($result['content_intro']);
        }
        if (!empty($result['content_main'])) {
            $updateData['content_main'] = wp_kses_post($result['content_main']);
        }
        if (!empty($result['content_faq'])) {
            $updateData['content_faq'] = is_array($result['content_faq'])
                ? wp_json_encode($result['content_faq'])
                : $result['content_faq'];
        }

        $updated = $wpdb->update($table, $updateData, ['id' => $brandId]);

        if ($updated === false) {
            error_log("[ACMS Job] applyBrandDirect #{$brandId}: FAILED! wpdb error: " . $wpdb->last_error);
        }
    }

    /**
     * Create category hierarchy from path string
     * e.g., "Home & Kitchen > Kitchen & Dining > Coffee Makers"
     *
     * @param object $categoryRepo CategoryRepository instance
     * @param string $path Category path with " > " separator
     * @return int|null Created/found category ID or null on failure
     */
    private function createCategoryFromPath($categoryRepo, string $path): ?int
    {
        if (empty($path)) {
            return null;
        }

        // Split path into parts
        $parts = array_map('trim', explode(' > ', $path));
        if (empty($parts)) {
            return null;
        }

        global $wpdb;
        $table = $wpdb->prefix . 'acms_categories';

        $parentId = 0;
        $categoryId = null;

        foreach ($parts as $name) {
            if (empty($name)) {
                continue;
            }

            // Try to find existing category with this name and parent
            $slug = sanitize_title($name);

            $existing = $wpdb->get_row($wpdb->prepare(
                "SELECT id FROM {$table} WHERE (slug = %s OR name = %s) AND parent_id = %d LIMIT 1",
                $slug,
                $name,
                $parentId
            ), ARRAY_A);

            if ($existing) {
                $categoryId = (int) $existing['id'];
            } else {
                // Create new category
                $categoryId = $categoryRepo->create([
                    'name' => $name,
                    'slug' => $slug,
                    'parent_id' => $parentId,
                    'status' => 'publish',
                ]);
            }

            if (!$categoryId) {
                return null;
            }

            // Move to next level
            $parentId = $categoryId;
        }

        return $categoryId;
    }

    /**
     * Trigger content generation for a category
     * Creates a generate_seo_category job with queue_id for tracking
     *
     * @param int $categoryId The category to generate content for
     * @param int $queueId The originating queue item ID (for status update when done)
     */
    private function triggerCategoryContentGeneration(int $categoryId, int $queueId): void
    {
        global $wpdb;

        $jobsTable = $wpdb->prefix . 'acms_ai_jobs';
        $categoriesTable = $wpdb->prefix . 'acms_categories';

        // Get category details
        $category = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$categoriesTable} WHERE id = %d",
            $categoryId
        ), ARRAY_A);

        if (!$category) {
            error_log("[ACMS Job] Cannot trigger content gen - category {$categoryId} not found");
            return;
        }

        // Check if job already exists for this category
        $existingJob = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$jobsTable}
             WHERE type = 'generate_seo_category'
             AND target_type = 'seo_category'
             AND target_id = %s
             AND status IN ('pending', 'processing')",
            (string) $categoryId
        ));

        if ($existingJob) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("[ACMS Job] Content generation job already exists for category {$categoryId}");
            }
            return;
        }

        // Get products in this category for context
        $junctionTable = $wpdb->prefix . 'acms_category_products';
        $productsTable = $wpdb->prefix . 'acms_products';

        $products = $wpdb->get_results($wpdb->prepare(
            "SELECT p.asin, p.title, p.brand, p.category_path, p.rating, p.reviews_count
             FROM {$productsTable} p
             INNER JOIN {$junctionTable} cp ON cp.product_id = p.id
             WHERE cp.category_id = %d AND p.status = 'scraped'
             ORDER BY cp.is_primary DESC, p.rating DESC
             LIMIT 15",
            $categoryId
        ), ARRAY_A);

        // Get parent category names for context
        $parentCategories = [];
        if (!empty($category['path']) && $category['path'] !== '/') {
            $pathIds = array_filter(explode('/', trim($category['path'], '/')));
            if (!empty($pathIds)) {
                $placeholders = implode(',', array_fill(0, count($pathIds), '%d'));
                $names = $wpdb->get_results($wpdb->prepare(
                    "SELECT id, name FROM {$categoriesTable} WHERE id IN ({$placeholders}) ORDER BY depth ASC",
                    ...$pathIds
                ), ARRAY_A);

                $nameMap = [];
                foreach ($names as $cat) {
                    $nameMap[$cat['id']] = $cat['name'];
                }
                foreach ($pathIds as $id) {
                    if (isset($nameMap[$id])) {
                        $parentCategories[] = $nameMap[$id];
                    }
                }
            }
        }

        // Build category path
        $categoryPath = !empty($parentCategories)
            ? implode(' > ', $parentCategories) . ' > ' . $category['name']
            : $category['name'];

        // Gather related categories for internal linking
        $relatedCategories = ['siblings' => [], 'children' => [], 'ancestors' => []];
        if (class_exists(\AffiliateCMS\Categories\Repositories\CategoryRepository::class)) {
            $catRepo = new \AffiliateCMS\Categories\Repositories\CategoryRepository();
            $relatedCategories = $catRepo->getInternalLinkContext($categoryId);
        }

        // Prepare job input data - include queue_id so we can update queue when done
        $inputData = [
            'category_id' => $categoryId,
            'category_name' => $category['name'],
            'category_slug' => $category['slug'] ?? '',
            'category_path' => $categoryPath,
            'parent_categories' => $parentCategories,
            'products' => $products ?: [],
            'current_description' => $category['description'] ?? '',
            'queue_id' => $queueId,  // Track originating queue item
            'related_categories' => $relatedCategories,
        ];

        // Mark category as generating
        $wpdb->update(
            $categoriesTable,
            [
                'content_status' => 'ai_generating',
                'ai_generating_at' => current_time('mysql'),
                'ai_error_message' => null,
            ],
            ['id' => $categoryId],
            ['%s', '%s', '%s'],
            ['%d']
        );

        // Also update queue ai_status
        $queueTable = $wpdb->prefix . 'acms_cat_queue';
        $wpdb->update(
            $queueTable,
            ['ai_status' => 'generating_content'],
            ['id' => $queueId],
            ['%s'],
            ['%d']
        );

        // Create the job
        $inserted = $wpdb->insert($jobsTable, [
            'type' => 'generate_seo_category',
            'status' => 'pending',
            'priority' => 45,  // Slightly higher priority than cron-triggered jobs
            'target_type' => 'seo_category',
            'target_id' => (string) $categoryId,
            'input_data' => wp_json_encode($inputData),
            'created_at' => current_time('mysql'),
        ]);

        if ($inserted) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("[ACMS Job] Created content generation job for category {$category['name']} (ID: {$categoryId}), queue: {$queueId}");
            }
        } else {
            error_log("[ACMS Job] Failed to create content job for category {$categoryId}: " . $wpdb->last_error);
        }
    }
}
