<?php
/**
 * AffiliateCMS AI - Database Schema
 */

declare(strict_types=1);

namespace AffiliateCMS\AI\Database;

class Schema
{
    /**
     * Create database tables
     */
    public function createTables(): void
    {
        global $wpdb;

        $charset = $wpdb->get_charset_collate();

        // AI Jobs Table
        $jobsTable = $wpdb->prefix . 'acms_ai_jobs';
        $jobsSql = "CREATE TABLE IF NOT EXISTS {$jobsTable} (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

            type ENUM('enhance_asin', 'optimize_review', 'generate_category', 'standardize_categories', 'generate_seo_category', 'generate_seo_brand') NOT NULL,
            status ENUM('pending', 'processing', 'completed', 'failed') DEFAULT 'pending',
            priority TINYINT DEFAULT 50,

            target_type VARCHAR(50) NOT NULL,
            target_id VARCHAR(100) NOT NULL,

            input_data LONGTEXT NOT NULL,
            output_data LONGTEXT,

            model VARCHAR(100),
            tokens_used INT DEFAULT 0,
            tokens_input INT DEFAULT 0,
            tokens_output INT DEFAULT 0,
            cost DECIMAL(10,6) DEFAULT 0,

            attempts TINYINT DEFAULT 0,
            max_attempts TINYINT DEFAULT 3,
            error_message TEXT,

            api_created_at VARCHAR(50),

            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            processing_at DATETIME,
            completed_at DATETIME,

            INDEX idx_status_priority (status, priority DESC),
            INDEX idx_type_status (type, status),
            INDEX idx_target (target_type, target_id),
            INDEX idx_created (created_at)
        ) ENGINE=InnoDB {$charset};";

        // AI Usage Tracking Table
        $usageTable = $wpdb->prefix . 'acms_ai_usage';
        $usageSql = "CREATE TABLE IF NOT EXISTS {$usageTable} (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            date DATE NOT NULL,
            model VARCHAR(100) NOT NULL,

            requests_count INT DEFAULT 0,
            tokens_input INT DEFAULT 0,
            tokens_output INT DEFAULT 0,
            cost_total DECIMAL(10,4) DEFAULT 0,

            UNIQUE KEY idx_date_model (date, model)
        ) ENGINE=InnoDB {$charset};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        dbDelta($jobsSql);
        dbDelta($usageSql);
    }

    /**
     * Run migrations for existing tables
     */
    public function migrate(): void
    {
        global $wpdb;
        $jobsTable = $wpdb->prefix . 'acms_ai_jobs';

        // Add tokens_input/tokens_output columns if missing
        $hasTokensInput = $wpdb->get_var("SHOW COLUMNS FROM {$jobsTable} LIKE 'tokens_input'");
        if (!$hasTokensInput) {
            $wpdb->query("ALTER TABLE {$jobsTable} ADD COLUMN tokens_input INT DEFAULT 0 AFTER tokens_used");
            $wpdb->query("ALTER TABLE {$jobsTable} ADD COLUMN tokens_output INT DEFAULT 0 AFTER tokens_input");
        }

        // Add api_created_at column (OpenRouter's created timestamp)
        $hasApiCreatedAt = $wpdb->get_var("SHOW COLUMNS FROM {$jobsTable} LIKE 'api_created_at'");
        if (!$hasApiCreatedAt) {
            $wpdb->query("ALTER TABLE {$jobsTable} ADD COLUMN api_created_at VARCHAR(50) AFTER error_message");
        }
    }

    /**
     * Drop database tables
     */
    public function dropTables(): void
    {
        global $wpdb;

        $tables = [
            $wpdb->prefix . 'acms_ai_jobs',
            $wpdb->prefix . 'acms_ai_usage',
        ];

        foreach ($tables as $table) {
            $wpdb->query("DROP TABLE IF EXISTS {$table}");
        }
    }
}
