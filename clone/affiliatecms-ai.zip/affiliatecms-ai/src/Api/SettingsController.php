<?php
/**
 * AffiliateCMS AI - Settings Controller
 */

declare(strict_types=1);

namespace AffiliateCMS\AI\Api;

use WP_REST_Controller;
use WP_REST_Request;
use WP_REST_Response;
use WP_Error;

class SettingsController extends WP_REST_Controller
{
    protected $namespace = 'acms-ai/v1';

    /**
     * Register routes
     */
    public function registerRoutes(): void
    {
        register_rest_route($this->namespace, '/settings', [
            [
                'methods' => 'GET',
                'callback' => [$this, 'getSettings'],
                'permission_callback' => [$this, 'checkPermission'],
            ],
            [
                'methods' => 'POST',
                'callback' => [$this, 'saveSettings'],
                'permission_callback' => [$this, 'checkPermission'],
            ],
        ]);

        register_rest_route($this->namespace, '/validate-key', [
            [
                'methods' => 'POST',
                'callback' => [$this, 'validateApiKey'],
                'permission_callback' => [$this, 'checkPermission'],
            ],
        ]);

        // AI jobs queue stats
        register_rest_route($this->namespace, '/queue-stats', [
            [
                'methods' => 'GET',
                'callback' => [$this, 'getQueueStats'],
                'permission_callback' => [$this, 'checkPermission'],
            ],
        ]);

        // Trigger queue processing manually
        register_rest_route($this->namespace, '/queue-process', [
            [
                'methods' => 'POST',
                'callback' => [$this, 'triggerQueueProcess'],
                'permission_callback' => [$this, 'checkPermission'],
            ],
        ]);

        // Clean up completed/failed AI jobs
        register_rest_route($this->namespace, '/queue-cleanup', [
            [
                'methods' => 'POST',
                'callback' => [$this, 'cleanupQueue'],
                'permission_callback' => [$this, 'checkPermission'],
            ],
        ]);

        // Get pending AI jobs
        register_rest_route($this->namespace, '/pending-actions', [
            [
                'methods' => 'GET',
                'callback' => [$this, 'getPendingActions'],
                'permission_callback' => [$this, 'checkPermission'],
            ],
        ]);

        // Reset stuck AI jobs
        register_rest_route($this->namespace, '/reset-stuck-jobs', [
            [
                'methods' => 'POST',
                'callback' => [$this, 'resetStuckJobs'],
                'permission_callback' => [$this, 'checkPermission'],
            ],
        ]);

        // Legacy AS endpoint (disabled)
        register_rest_route($this->namespace, '/reschedule-as', [
            [
                'methods' => 'POST',
                'callback' => [$this, 'rescheduleAs'],
                'permission_callback' => [$this, 'checkPermission'],
            ],
        ]);

        // Debug queue items - check why items are stuck
        register_rest_route($this->namespace, '/debug-queue', [
            [
                'methods' => 'GET',
                'callback' => [$this, 'debugQueue'],
                'permission_callback' => [$this, 'checkPermission'],
            ],
        ]);

        // Manually trigger Post AI generation
        register_rest_route($this->namespace, '/run-post-ai', [
            [
                'methods' => 'POST',
                'callback' => [$this, 'runPostAi'],
                'permission_callback' => [$this, 'checkPermission'],
            ],
        ]);

        // Legacy AS queue endpoint (disabled)
        register_rest_route($this->namespace, '/run-as-queue', [
            [
                'methods' => 'POST',
                'callback' => [$this, 'runAsQueue'],
                'permission_callback' => [$this, 'checkPermission'],
            ],
        ]);

        // Recount product_count for all categories (subtree totals)
        register_rest_route($this->namespace, '/recount-category-products', [
            [
                'methods' => 'POST',
                'callback' => [$this, 'recountCategoryProducts'],
                'permission_callback' => [$this, 'checkPermission'],
            ],
        ]);

        // Prompt preview - get sample data for template variable replacement
        register_rest_route($this->namespace, '/prompt-preview', [
            [
                'methods' => 'GET',
                'callback' => [$this, 'getPromptPreviewData'],
                'permission_callback' => [$this, 'checkPermission'],
            ],
        ]);
    }

    /**
     * Get queue statistics (AI jobs)
     */
    public function getQueueStats(): WP_REST_Response
    {
        global $wpdb;

        // Get AI jobs stats from acms_ai_jobs table
        $jobsTable = $wpdb->prefix . 'acms_ai_jobs';
        $tableExists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $jobsTable));

        $aiJobs = [
            'pending' => 0,
            'processing' => 0,
            'completed_today' => 0,
            'failed_today' => 0,
        ];

        if ($tableExists === $jobsTable) {
            $counts = $wpdb->get_results(
                "SELECT status, COUNT(*) as cnt FROM {$jobsTable} GROUP BY status",
                OBJECT_K
            );
            $aiJobs['pending'] = (int) ($counts['pending']->cnt ?? 0);
            $aiJobs['processing'] = (int) ($counts['processing']->cnt ?? 0);
            $aiJobs['completed'] = (int) ($counts['completed']->cnt ?? 0);
            $aiJobs['failed'] = (int) ($counts['failed']->cnt ?? 0);
            $aiJobs['total'] = array_sum(array_column((array) $counts, 'cnt'));
        }

        return new WP_REST_Response([
            'ai_jobs' => $aiJobs,
        ]);
    }

    /**
     * Trigger queue processing manually
     */
    public function triggerQueueProcess(): WP_REST_Response
    {
        $processed = 0;
        $errors = [];

        update_option('acms_ai_last_cron_run', time());

        try {
            $processor = new \AffiliateCMS\AI\Core\JobProcessor();
            $result = $processor->processQueue();
            $processed = $result['processed'] ?? 0;
        } catch (\Exception $e) {
            $errors[] = $e->getMessage();
        }

        return new WP_REST_Response([
            'success' => true,
            'processed' => $processed,
            'errors' => $errors,
            'message' => $processed > 0
                ? "Processed {$processed} jobs"
                : 'No pending jobs to process',
        ]);
    }

    /**
     * Clean up AI jobs. Pass clear_all=true to TRUNCATE entire table.
     */
    public function cleanupQueue(WP_REST_Request $request): WP_REST_Response
    {
        global $wpdb;

        $jobsTable = $wpdb->prefix . 'acms_ai_jobs';
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $jobsTable)) !== $jobsTable) {
            return new WP_REST_Response(['success' => false, 'message' => 'Table not found']);
        }

        $clearAll = $request->get_param('clear_all');

        if ($clearAll) {
            $wpdb->query("TRUNCATE TABLE {$jobsTable}");
            return new WP_REST_Response([
                'success' => true,
                'message' => 'All AI jobs cleared (table truncated)',
            ]);
        }

        $aiJobsDeleted = (int) $wpdb->query(
            "DELETE FROM {$jobsTable} WHERE status IN ('completed', 'failed')"
        );

        return new WP_REST_Response([
            'success' => true,
            'ai_jobs_deleted' => $aiJobsDeleted,
            'message' => "Cleaned {$aiJobsDeleted} AI jobs",
        ]);
    }

    /**
     * Reset stuck AI jobs and retry stalled queue items
     */
    public function resetStuckJobs(): WP_REST_Response
    {
        global $wpdb;

        $results = [
            'stuck_jobs_reset' => 0,
        ];

        // 1. Reset AI jobs stuck in 'processing' for more than 10 minutes
        $jobsTable = $wpdb->prefix . 'acms_ai_jobs';
        $tableExists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $jobsTable));

        if ($tableExists === $jobsTable) {
            $results['stuck_jobs_reset'] = (int) $wpdb->query(
                "UPDATE {$jobsTable}
                 SET status = 'pending', processing_at = NULL
                 WHERE status = 'processing'
                 AND processing_at < DATE_SUB(NOW(), INTERVAL 10 MINUTE)"
            );
        }

        // 2. Retry queue items stuck at 'category_assigned' without content generation job
        $results['queue_items_retried'] = 0;
        $queueTable = $wpdb->prefix . 'acms_cat_queue';
        $queueTableExists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $queueTable));

        if ($queueTableExists === $queueTable && $tableExists === $jobsTable) {
            // Find queue items stuck at 'category_assigned' with no pending content job
            $stuckItems = $wpdb->get_results(
                "SELECT q.id, q.assigned_category_id, q.custom_category_path
                 FROM {$queueTable} q
                 WHERE q.ai_status = 'category_assigned'
                 AND q.assigned_category_id IS NOT NULL
                 AND NOT EXISTS (
                     SELECT 1 FROM {$jobsTable} j
                     WHERE j.type = 'generate_seo_category'
                     AND j.target_id = CAST(q.assigned_category_id AS CHAR)
                     AND j.status IN ('pending', 'processing')
                 )
                 LIMIT 20",
                ARRAY_A
            );

            foreach ($stuckItems as $item) {
                $queueId = (int) $item['id'];
                $categoryId = (int) $item['assigned_category_id'];
                $categoryPath = $item['custom_category_path'] ?? '';

                // Fire the hook to create content generation job
                do_action('acms_category_assigned', $queueId, $categoryId, $categoryPath);
                $results['queue_items_retried']++;
            }
        }

        // 4. Retry queue items stuck at 'ready_for_ai' + 'analyzing_category' status
        // These items had the hook fired but CategoryPathAssigner didn't process them
        $results['analyzing_items_retried'] = 0;

        if ($queueTableExists === $queueTable) {
            // Find items stuck at ready_for_ai + analyzing_category
            $stuckAnalyzing = $wpdb->get_results(
                "SELECT q.id, q.linked_asins
                 FROM {$queueTable} q
                 WHERE q.status = 'ready_for_ai'
                 AND q.ai_status = 'analyzing_category'
                 AND q.linked_asins IS NOT NULL
                 AND q.linked_asins != '[]'
                 LIMIT 20",
                ARRAY_A
            );

            foreach ($stuckAnalyzing as $item) {
                $queueId = (int) $item['id'];
                $linkedAsins = json_decode($item['linked_asins'] ?? '[]', true);

                if (!empty($linkedAsins)) {
                    // Re-fire the hook to let CategoryPathAssigner process it
                    do_action('acms_category_ready_for_ai', $queueId, $linkedAsins);
                    $results['analyzing_items_retried']++;

                    if (defined('WP_DEBUG') && WP_DEBUG) {
                        error_log("[ACMS Reset Stuck] Re-fired acms_category_ready_for_ai for queue {$queueId}");
                    }
                }
            }
        }

        return new WP_REST_Response([
            'success' => true,
            'data' => $results,
            'message' => sprintf(
                'Reset %d stuck jobs, retried %d assigned + %d analyzing items',
                $results['stuck_jobs_reset'],
                $results['queue_items_retried'],
                $results['analyzing_items_retried']
            ),
        ]);
    }

    /**
     * Reschedule AS actions (legacy — AS is now disabled)
     */
    public function rescheduleAs(): WP_REST_Response
    {
        return new WP_REST_Response([
            'success' => true,
            'message' => 'Action Scheduler is disabled. All jobs processed via server cron + WP-Cron.',
        ]);
    }

    /**
     * Debug queue items - check why items are stuck at 'queued' status
     *
     * Returns detailed info about queue items including:
     * - Scrape progress for linked products
     * - Whether generated_post_id exists
     */
    public function debugQueue(): WP_REST_Response
    {
        global $wpdb;

        $queueTable = $wpdb->prefix . 'acms_queue';
        $productsTable = $wpdb->prefix . 'acms_products';

        // Get queue items with ai_post_status = 'queued'
        $queueItems = $wpdb->get_results(
            "SELECT id, keyword, linked_asins, generated_post_id, ai_post_status, ai_post_error, status
             FROM {$queueTable}
             WHERE ai_post_status = 'queued'
             ORDER BY id ASC
             LIMIT 10",
            ARRAY_A
        );

        $items = [];
        foreach ($queueItems as $item) {
            // Parse linked_asins
            $linkedAsins = isset($item['linked_asins'])
                ? (is_array($item['linked_asins']) ? $item['linked_asins'] : json_decode($item['linked_asins'], true))
                : [];

            $totalAsins = count($linkedAsins);
            $scrapedCount = 0;

            if ($totalAsins > 0) {
                $asinPlaceholders = implode(',', array_fill(0, $totalAsins, '%s'));
                $scrapedCount = (int) $wpdb->get_var($wpdb->prepare(
                    "SELECT COUNT(*) FROM {$productsTable}
                     WHERE asin IN ({$asinPlaceholders})
                     AND status = 'scraped'",
                    ...$linkedAsins
                ));
            }

            $scrapeProgress = $totalAsins > 0 ? round(($scrapedCount / $totalAsins) * 100) : 0;
            $scrapeReady = $scrapeProgress >= 80;

            $items[] = [
                'id' => (int) $item['id'],
                'keyword' => $item['keyword'],
                'status' => $item['status'],
                'ai_post_status' => $item['ai_post_status'],
                'ai_post_error' => $item['ai_post_error'],
                'has_generated_post_id' => !empty($item['generated_post_id']),
                'generated_post_id' => $item['generated_post_id'],
                'total_asins' => $totalAsins,
                'scraped_count' => $scrapedCount,
                'scrape_progress' => $scrapeProgress . '%',
                'scrape_ready' => $scrapeReady,
                'issue' => $this->diagnoseQueueIssue($item, $scrapeReady),
            ];
        }

        // Get recent ACMS logs from debug.log (safe tail read - last 32KB only)
        $recentLogs = $this->getRecentLogs(['PostAiCron', 'ACMS']);

        return new WP_REST_Response([
            'success' => true,
            'data' => [
                'queued_items' => $items,
                'recent_logs' => $recentLogs,
                'hint' => 'Items need: 1) scrape_ready=true (80%), 2) has_generated_post_id=true, 3) Server cron running post-ai',
            ],
        ]);
    }

    /**
     * Diagnose why a queue item might be stuck
     */
    private function diagnoseQueueIssue(array $item, bool $scrapeReady): string
    {
        if (empty($item['generated_post_id'])) {
            return 'MISSING generated_post_id - QueueProcessor must create post first';
        }
        if (!$scrapeReady) {
            return 'WAITING for scrape - products not yet 80% scraped';
        }
        return 'READY - should be processed by next server cron post-ai run';
    }

    /**
     * Manually trigger Post AI generation (for testing)
     */
    public function runPostAi(): WP_REST_Response
    {
        // Capture ALL output (PHP errors, warnings, notices) to prevent HTML in JSON response
        ob_start();

        try {
            error_log('[ACMS API] run-post-ai triggered manually');

            // Step 1: Check class exists
            if (!class_exists(\AffiliateCMS\Pro\Core\PostAiCron::class)) {
                ob_end_clean();
                return new WP_REST_Response([
                    'success' => false,
                    'message' => 'PostAiCron class not found - is affiliatecms-pro active?',
                ]);
            }

            // Step 2: Get instance
            $cron = \AffiliateCMS\Pro\Core\PostAiCron::instance();
            error_log('[ACMS API] PostAiCron instance created');

            // Step 3: Run generatePosts
            $cron->generatePosts();
            error_log('[ACMS API] generatePosts() completed');

            // Capture any stray output (PHP errors/warnings)
            $strayOutput = ob_get_clean();

            // Step 4: Get recent logs (safe tail read)
            $recentLogs = $this->getRecentLogs(['ACMS', 'PostAiCron']);

            return new WP_REST_Response([
                'success' => true,
                'data' => [
                    'recent_logs' => $recentLogs,
                    'php_output' => $strayOutput ?: '(none)',
                ],
                'message' => 'Post AI generation completed. Check debug output for logs.',
            ]);
        } catch (\Throwable $e) {
            $strayOutput = ob_get_clean();
            error_log('[ACMS API] run-post-ai error: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
            return new WP_REST_Response([
                'success' => false,
                'message' => 'Error: ' . $e->getMessage() . ' (' . basename((string) $e->getFile()) . ':' . $e->getLine() . ')',
                'php_output' => $strayOutput ?: '(none)',
            ]);
        }
    }

    /**
     * Legacy AS Queue Runner endpoint (disabled)
     */
    public function runAsQueue(): WP_REST_Response
    {
        return new WP_REST_Response([
            'success' => true,
            'message' => 'Action Scheduler is disabled. All jobs processed via server cron + WP-Cron.',
        ]);
    }

    /**
     * Recount product_count for all categories (subtree totals).
     * Fixes parent categories that had product_count=0 because counts weren't propagated.
     */
    public function recountCategoryProducts(): WP_REST_Response
    {
        @set_time_limit(120);

        if (!class_exists(\AffiliateCMS\Categories\Repositories\CategoryRepository::class)) {
            return new WP_REST_Response([
                'success' => false,
                'message' => 'affiliatecms-cat plugin is not active',
            ]);
        }

        $categoryRepo = new \AffiliateCMS\Categories\Repositories\CategoryRepository();
        $updated = $categoryRepo->recountAllProductCounts();

        return new WP_REST_Response([
            'success' => true,
            'message' => "Recounted product_count for {$updated} categories (subtree totals)",
            'updated' => $updated,
        ]);
    }

    /**
     * Safely read recent lines from debug.log matching keywords (reads last 32KB only)
     */
    private function getRecentLogs(array $keywords, int $maxLines = 15): string
    {
        try {
            $logFile = WP_CONTENT_DIR . '/debug.log';
            if (!file_exists($logFile) || !is_readable($logFile)) {
                return '(no debug.log found)';
            }

            $fileSize = (int) filesize($logFile);
            if ($fileSize === 0) {
                return '(debug.log is empty)';
            }

            // Read only the last 32KB to avoid memory issues
            $readBytes = min($fileSize, 32768);
            $fp = fopen($logFile, 'r');
            if (!$fp) {
                return '(cannot read debug.log)';
            }

            fseek($fp, -$readBytes, SEEK_END);
            $tail = (string) fread($fp, $readBytes);
            fclose($fp);

            $lines = explode("\n", $tail);
            $matched = [];
            foreach ($lines as $line) {
                foreach ($keywords as $kw) {
                    if (strpos($line, (string) $kw) !== false) {
                        $matched[] = $line;
                        break;
                    }
                }
            }

            if (empty($matched)) {
                return '(no matching log entries in last 32KB)';
            }

            return implode("\n", array_slice($matched, -$maxLines));
        } catch (\Throwable $e) {
            return '(error reading logs: ' . $e->getMessage() . ')';
        }
    }

    /**
     * Check permission
     */
    public function checkPermission(): bool
    {
        return current_user_can('manage_options');
    }

    /**
     * Get settings
     */
    public function getSettings(): WP_REST_Response
    {
        $settings = [
            'api_key' => get_option('acms_ai_api_key', ''),
            'default_model' => get_option('acms_ai_default_model', 'google/gemini-3-flash-preview'),
            'monthly_budget' => (float) get_option('acms_ai_monthly_budget', 50),
            'enable_enhance_asin' => (bool) get_option('acms_ai_enhance_asin_enabled', true),
            'enable_optimize_review' => (bool) get_option('acms_ai_optimize_review_enabled', true),
            'enable_generate_category' => (bool) get_option('acms_ai_generate_category_enabled', false),
            'enable_seo_category' => (bool) get_option('acms_ai_seo_category_enabled', true),
            'enable_seo_brand' => (bool) get_option('acms_ai_seo_brand_enabled', true),
            // Prompt templates
            'prompt_enhance_asin' => get_option('acms_ai_prompt_enhance_asin', ''),
            'prompt_optimize_review' => get_option('acms_ai_prompt_optimize_review', ''),
            'prompt_generate_category' => get_option('acms_ai_prompt_generate_category', ''),
            'prompt_standardize_categories' => get_option('acms_ai_prompt_standardize_categories', ''),
            'prompt_seo_category' => get_option('acms_ai_seo_category_prompt_template', ''),
            'prompt_seo_brand' => get_option('acms_ai_seo_brand_prompt_template', ''),
        ];

        // Mask API key for security
        if (!empty($settings['api_key'])) {
            $key = $settings['api_key'];
            $settings['api_key_masked'] = substr($key, 0, 8) . '...' . substr($key, -4);
            $settings['api_key'] = ''; // Don't send actual key
        }

        return new WP_REST_Response($settings);
    }

    /**
     * Save settings
     */
    public function saveSettings(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $params = $request->get_json_params();

        // Save API key if provided
        if (isset($params['api_key']) && !empty($params['api_key'])) {
            update_option('acms_ai_api_key', sanitize_text_field($params['api_key']));
        }

        // Save other settings
        if (isset($params['default_model'])) {
            update_option('acms_ai_default_model', sanitize_text_field($params['default_model']));
        }

        if (isset($params['monthly_budget'])) {
            update_option('acms_ai_monthly_budget', (float) $params['monthly_budget']);
        }

        if (isset($params['enable_enhance_asin'])) {
            update_option('acms_ai_enhance_asin_enabled', (bool) $params['enable_enhance_asin']);
        }

        if (isset($params['enable_optimize_review'])) {
            update_option('acms_ai_optimize_review_enabled', (bool) $params['enable_optimize_review']);
        }

        if (isset($params['enable_generate_category'])) {
            update_option('acms_ai_generate_category_enabled', (bool) $params['enable_generate_category']);
        }

        if (isset($params['enable_seo_category'])) {
            update_option('acms_ai_seo_category_enabled', (bool) $params['enable_seo_category']);
        }

        if (isset($params['enable_seo_brand'])) {
            update_option('acms_ai_seo_brand_enabled', (bool) $params['enable_seo_brand']);
        }

        // Save prompt templates
        if (isset($params['prompt_enhance_asin'])) {
            update_option('acms_ai_prompt_enhance_asin', wp_kses_post($params['prompt_enhance_asin']));
        }

        if (isset($params['prompt_optimize_review'])) {
            update_option('acms_ai_prompt_optimize_review', wp_kses_post($params['prompt_optimize_review']));
        }

        if (isset($params['prompt_generate_category'])) {
            update_option('acms_ai_prompt_generate_category', wp_kses_post($params['prompt_generate_category']));
        }

        if (isset($params['prompt_standardize_categories'])) {
            update_option('acms_ai_prompt_standardize_categories', wp_kses_post($params['prompt_standardize_categories']));
        }

        if (isset($params['prompt_seo_category'])) {
            update_option('acms_ai_seo_category_prompt_template', wp_kses_post($params['prompt_seo_category']));
        }

        if (isset($params['prompt_seo_brand'])) {
            update_option('acms_ai_seo_brand_prompt_template', wp_kses_post($params['prompt_seo_brand']));
        }

        return new WP_REST_Response([
            'success' => true,
            'message' => 'Settings saved successfully',
        ]);
    }

    /**
     * Validate API key with OpenRouter
     */
    public function validateApiKey(WP_REST_Request $request): WP_REST_Response
    {
        $params = $request->get_json_params();
        $apiKey = $params['api_key'] ?? get_option('acms_ai_api_key', '');

        if (empty($apiKey)) {
            return new WP_REST_Response([
                'valid' => false,
                'message' => 'API key is required',
            ]);
        }

        // Test API key with OpenRouter
        $response = wp_remote_get('https://openrouter.ai/api/v1/auth/key', [
            'headers' => [
                'Authorization' => 'Bearer ' . $apiKey,
            ],
            'timeout' => 10,
        ]);

        if (is_wp_error($response)) {
            return new WP_REST_Response([
                'valid' => false,
                'message' => $response->get_error_message(),
            ]);
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);

        if ($code === 200) {
            return new WP_REST_Response([
                'valid' => true,
                'message' => 'API key is valid',
                'data' => $body['data'] ?? null,
            ]);
        }

        return new WP_REST_Response([
            'valid' => false,
            'message' => $body['error']['message'] ?? 'Invalid API key',
        ]);
    }

    /**
     * Get pending AI jobs
     */
    public function getPendingActions(): WP_REST_Response
    {
        global $wpdb;

        $nowGmt = gmdate('Y-m-d H:i:s');

        // Get pending/processing AI jobs from acms_ai_jobs
        $jobsTable = $wpdb->prefix . 'acms_ai_jobs';
        $jobsTableExists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $jobsTable));

        $aiJobs = [];
        if ($jobsTableExists === $jobsTable) {
            $jobs = $wpdb->get_results(
                "SELECT id, type, target_type, target_id, status, priority, created_at, processing_at
                 FROM {$jobsTable}
                 WHERE status IN ('pending', 'processing')
                 ORDER BY priority DESC, created_at ASC
                 LIMIT 20",
                ARRAY_A
            );

            foreach ($jobs as $job) {
                $aiJobs[] = [
                    'id' => (int) $job['id'],
                    'type' => $job['type'],
                    'name' => $this->formatJobType($job['type']),
                    'target' => $job['target_type'] . ':' . $job['target_id'],
                    'status' => $job['status'],
                    'priority' => (int) $job['priority'],
                    'created_at' => $job['created_at'],
                    'started_at' => $job['processing_at'],
                ];
            }
        }

        return new WP_REST_Response([
            'success' => true,
            'server_time' => current_time('Y-m-d H:i:s'),
            'server_time_gmt' => $nowGmt,
            'actions' => [], // AS disabled — no scheduled actions
            'ai_jobs' => $aiJobs,
        ]);
    }

    /**
     * Format AI job type for display
     */
    private function formatJobType(string $type): string
    {
        $types = [
            'generate_seo_category' => 'Generate SEO Category',
            'generate_seo_brand' => 'Generate SEO Brand',
            'enhance_asin' => 'Enhance Product',
            'optimize_review' => 'Optimize Review',
            'standardize_categories' => 'Standardize Categories',
        ];

        return $types[$type] ?? ucwords(str_replace('_', ' ', $type));
    }

    /**
     * Get sample data for prompt preview
     */
    public function getPromptPreviewData(WP_REST_Request $request): WP_REST_Response
    {
        global $wpdb;
        $type = sanitize_text_field($request->get_param('type') ?? '');
        $prefix = $wpdb->prefix;

        try {
            $data = match ($type) {
                'enhance_asin' => $this->getPreviewDataEnhanceAsin($wpdb, $prefix),
                'optimize_review' => $this->getPreviewDataOptimizeReview($wpdb, $prefix),
                'generate_category' => $this->getPreviewDataGenerateCategory($wpdb, $prefix),
                'standardize_categories' => $this->getPreviewDataStandardize($wpdb, $prefix),
                'seo_category' => $this->getPreviewDataSeoCategory($wpdb, $prefix),
                'seo_brand' => $this->getPreviewDataSeoBrand($wpdb, $prefix),
                default => null,
            };

            if (empty($data)) {
                return new WP_REST_Response([
                    'success' => false,
                    'message' => "No sample data found for '{$type}'. Add some products or categories first.",
                ]);
            }

            return new WP_REST_Response(['success' => true, 'data' => $data]);
        } catch (\Throwable $e) {
            return new WP_REST_Response([
                'success' => false,
                'message' => 'Error loading preview data: ' . $e->getMessage(),
            ]);
        }
    }

    private function getPreviewDataEnhanceAsin($wpdb, string $prefix): ?array
    {
        $product = $wpdb->get_row(
            "SELECT * FROM {$prefix}acms_products WHERE status = 'scraped' AND title != '' ORDER BY RAND() LIMIT 1",
            ARRAY_A
        );
        if (!$product) {
            return null;
        }

        $features = !empty($product['features']) ? json_decode($product['features'], true) : [];
        $featuresText = !empty($features) ? "- " . implode("\n- ", $features) : '(no features available)';
        $fmt = fn($v) => empty($v) ? '(not available)' : (is_string($v) ? (json_decode($v) !== null ? json_encode(json_decode($v, true), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) : $v) : wp_json_encode($v, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

        return [
            'asin_code' => $product['asin'] ?? '',
            'asin_title' => $product['title'] ?? '',
            'asin_brand' => $product['brand'] ?? '',
            'asin_category' => $product['category'] ?? '',
            'asin_category_path' => $product['category_path'] ?? '',
            'asin_price' => $product['price'] ?? '',
            'asin_original_price' => $product['original_price'] ?? '',
            'asin_currency' => $product['currency'] ?? 'USD',
            'asin_in_stock' => !empty($product['in_stock']) ? 'Yes' : 'No',
            'asin_is_prime' => !empty($product['is_prime']) ? 'Yes' : 'No',
            'asin_rating' => $product['rating'] ?? '',
            'asin_reviews_count' => $product['reviews_count'] ?? '0',
            'asin_score' => $product['score'] ?? '',
            'asin_description' => $product['description'] ?? '',
            'asin_features' => $featuresText,
            'asin_specifications' => $fmt($product['specifications'] ?? null),
            'asin_product_information' => $fmt($product['product_information'] ?? null),
            'asin_best_sellers_rank' => $product['best_sellers_rank'] ?? '',
            'asin_top_reviews' => $fmt($product['top_reviews'] ?? null),
            'asin_reviews_summary' => $fmt($product['reviews_summary'] ?? null),
            'asin_seller_info' => $fmt($product['seller_info'] ?? null),
            'asin_image_url' => $product['image_url'] ?? '',
            'asin_images_gallery' => $fmt($product['images_gallery'] ?? null),
        ];
    }

    private function getPreviewDataOptimizeReview($wpdb, string $prefix): ?array
    {
        $queue = $wpdb->get_row(
            "SELECT * FROM {$prefix}acms_queue WHERE status = 'completed' AND generated_post_id IS NOT NULL ORDER BY RAND() LIMIT 1",
            ARRAY_A
        );
        if (!$queue) {
            $queue = $wpdb->get_row("SELECT * FROM {$prefix}acms_queue WHERE keyword != '' ORDER BY RAND() LIMIT 1", ARRAY_A);
        }
        if (!$queue) {
            return null;
        }

        $keyword = $queue['keyword'] ?? 'Sample Keyword';
        $asins = json_decode($queue['linked_asins'] ?? '[]', true) ?: [];
        $productsCount = count($asins) ?: 10;
        $siteName = get_bloginfo('name');

        return [
            'keyword' => $keyword,
            'current_title' => $productsCount . ' Best ' . ucwords($keyword) . ' of ' . date('Y'),
            'current_content' => '(existing post content)',
            'current_excerpt' => 'Expert-picked ' . $keyword . ' reviewed and compared.',
            'products' => '(product data for ' . $productsCount . ' items)',
            'products_count' => (string) $productsCount,
            'related_posts' => '- /best-wireless-headphones/ - Best Wireless Headphones\n- /top-earbuds/ - Top Earbuds',
            'category_name' => 'Electronics',
            'category_path' => 'Electronics > Audio > ' . ucwords($keyword),
            'year' => date('Y'),
            'month_text' => date_i18n('F'),
            'author' => $siteName,
            'brand_list' => 'Sony, Bose, Apple',
            'brand_count' => '3',
            'price_min' => '$29.99',
            'price_max' => '$149.99',
            'review_count' => '2,847',
        ];
    }

    private function getPreviewDataGenerateCategory($wpdb, string $prefix): ?array
    {
        // Prefer categories with children for more realistic preview
        $cat = $wpdb->get_row(
            "SELECT * FROM {$prefix}acms_categories WHERE status = 'publish' AND brand_id IS NULL AND child_count > 0 ORDER BY RAND() LIMIT 1",
            ARRAY_A
        );
        if (!$cat) {
            $cat = $wpdb->get_row(
                "SELECT * FROM {$prefix}acms_categories WHERE status = 'publish' AND brand_id IS NULL ORDER BY RAND() LIMIT 1",
                ARRAY_A
            );
        }
        if (!$cat) {
            return ['category_name' => 'Electronics', 'category_path' => 'Electronics', 'parent_category' => '(root)', 'child_count' => '5', 'child_categories' => 'Audio, Computers, Smart Home, Wearables, Cameras', 'depth' => '0', 'related_categories' => "## Related Categories\n- <a href=\"/c/audio/\">Audio</a> (25 products)\n- <a href=\"/c/computers/\">Computers</a> (18 products)", 'brand_links' => ''];
        }

        $catId = (int) $cat['id'];

        $children = $wpdb->get_results($wpdb->prepare(
            "SELECT name, slug, product_count FROM {$prefix}acms_categories WHERE parent_id = %d AND brand_id IS NULL AND status = 'publish' LIMIT 10",
            $catId
        ), ARRAY_A);
        $childNames = array_column($children, 'name');
        $childCount = count($children);

        // Build related categories context
        $relatedContext = '';
        if (!empty($children)) {
            $relatedContext = "## Related Categories for Internal Linking\nChild categories:\n";
            foreach (array_slice($children, 0, 5) as $ch) {
                $relatedContext .= "- <a href=\"/c/{$ch['slug']}/\">{$ch['name']}</a> ({$ch['product_count']} products)\n";
            }
        }

        // Resolve materialized path IDs to readable names
        $readablePath = $this->resolveCategoryPath($wpdb, $prefix, $cat['path'] ?? '', $cat['name'] ?? '');

        return [
            'category_name' => $cat['name'] ?? '',
            'category_path' => $readablePath,
            'parent_category' => $cat['parent_id'] ? ($wpdb->get_var($wpdb->prepare("SELECT name FROM {$prefix}acms_categories WHERE id = %d", (int) $cat['parent_id'])) ?: '(root)') : '(root)',
            'child_count' => (string) $childCount,
            'child_categories' => implode(', ', $childNames) ?: '(none)',
            'depth' => (string) ($cat['depth'] ?? 0),
            'related_categories' => $relatedContext ?: '(no related categories)',
            'brand_links' => '',
        ];
    }

    private function getPreviewDataStandardize($wpdb, string $prefix): ?array
    {
        $queue = $wpdb->get_row(
            "SELECT keyword, linked_asins FROM {$prefix}acms_queue WHERE keyword != '' AND linked_asins IS NOT NULL ORDER BY RAND() LIMIT 1",
            ARRAY_A
        );
        $keyword = $queue['keyword'] ?? 'Wireless Headphones';
        $categories = $wpdb->get_col("SELECT DISTINCT name FROM {$prefix}acms_categories WHERE status = 'publish' LIMIT 10");

        return [
            'keyword' => $keyword,
            'products_json' => wp_json_encode([
                ['asin' => 'B0EXAMPLE1', 'title' => 'Sample Product 1 - ' . ucwords($keyword), 'brand' => 'Sony', 'category_path' => 'Electronics > Audio > Headphones'],
                ['asin' => 'B0EXAMPLE2', 'title' => 'Sample Product 2 - ' . ucwords($keyword), 'brand' => 'Bose', 'category_path' => 'Electronics > Audio > Headphones > Wireless'],
            ], JSON_PRETTY_PRINT),
            'existing_categories_json' => wp_json_encode($categories, JSON_PRETTY_PRINT),
        ];
    }

    private function getPreviewDataSeoCategory($wpdb, string $prefix): ?array
    {
        $cat = $wpdb->get_row(
            "SELECT * FROM {$prefix}acms_categories WHERE status = 'publish' AND product_count > 0 ORDER BY RAND() LIMIT 1",
            ARRAY_A
        );
        if (!$cat) {
            return ['category_name' => 'Coffee Makers', 'category_path' => 'Home & Kitchen > Kitchen & Dining > Coffee Makers', 'parents_context' => 'Parent categories: Home & Kitchen > Kitchen & Dining', 'products_context' => "Products in this category (5 items):\n- Keurig K-Elite Single Serve Coffee Maker (by Keurig)\n- Ninja Specialty Coffee Maker (by Ninja)\n- Breville Barista Express (by Breville)", 'product_count' => '5', 'related_categories' => "## Related Categories for Internal Linking\n- <a href=\"/c/espresso-machines/\">Espresso Machines</a> (12 products)\n- <a href=\"/c/coffee-grinders/\">Coffee Grinders</a> (8 products)", 'brand_links' => "## Brand Pages for Internal Linking\n- <a href=\"/brand/keurig/\">Keurig</a> (4 products)\n- <a href=\"/brand/ninja/\">Ninja</a> (3 products)"];
        }

        $catId = (int) $cat['id'];

        // Resolve materialized path IDs to readable names
        $readablePath = $this->resolveCategoryPath($wpdb, $prefix, $cat['path'] ?? '', $cat['name'] ?? '');

        // Build parent context from readable path
        $pathParts = explode(' > ', $readablePath);
        array_pop($pathParts); // Remove current category
        $parentsContext = !empty($pathParts) ? 'Parent categories: ' . implode(' > ', $pathParts) : '';

        // Get actual products
        $products = $wpdb->get_results($wpdb->prepare(
            "SELECT p.title, p.brand FROM {$prefix}acms_products p
             INNER JOIN {$prefix}acms_category_products cp ON cp.product_id = p.id
             WHERE cp.category_id = %d AND p.status = 'scraped'
             ORDER BY p.rating DESC LIMIT 10",
            $catId
        ), ARRAY_A);

        $productsContext = '';
        $productCount = (int) ($cat['product_count'] ?? 0);
        if (!empty($products)) {
            $productsContext = "Products in this category ({$productCount} items):\n";
            foreach ($products as $p) {
                $productsContext .= "- {$p['title']}";
                if (!empty($p['brand'])) $productsContext .= " (by {$p['brand']})";
                $productsContext .= "\n";
            }
        } else {
            $productsContext = "(no product data available yet)";
        }

        // Get related categories (siblings)
        $siblings = $wpdb->get_results($wpdb->prepare(
            "SELECT name, slug, product_count FROM {$prefix}acms_categories
             WHERE parent_id = %d AND id != %d AND status = 'publish' LIMIT 5",
            (int) ($cat['parent_id'] ?? 0), $catId
        ), ARRAY_A);
        $relatedContext = '';
        if (!empty($siblings)) {
            $relatedContext = "## Related Categories for Internal Linking\n";
            foreach ($siblings as $s) {
                $relatedContext .= "- <a href=\"/c/{$s['slug']}/\">{$s['name']}</a> ({$s['product_count']} products)\n";
            }
        }

        return [
            'category_name' => $cat['name'] ?? '',
            'category_path' => $readablePath,
            'parents_context' => $parentsContext,
            'products_context' => $productsContext,
            'product_count' => (string) $productCount,
            'related_categories' => $relatedContext ?: '(no related categories available)',
            'brand_links' => '',
        ];
    }

    private function getPreviewDataSeoBrand($wpdb, string $prefix): ?array
    {
        $brand = $wpdb->get_row(
            "SELECT * FROM {$prefix}acms_brands WHERE product_count > 0 ORDER BY RAND() LIMIT 1",
            ARRAY_A
        );
        if (!$brand) {
            return ['brand_name' => 'Sony', 'brand_slug' => 'sony', 'website_context' => 'Official Website: https://www.sony.com', 'categories_context' => 'Product categories: Electronics, Audio, Gaming', 'products_context' => "Sample products from this brand (25 total):\n- Sony WH-1000XM5 Wireless Headphones (Rating: 4.7/5)\n- Sony A7 IV Full-Frame Camera (Rating: 4.8/5)\n- Sony PlayStation 5 Console (Rating: 4.6/5)", 'product_count' => '25', 'brand_category_links' => "## Related Category Pages for Internal Linking\nCategories this brand's products appear in:\n- <a href=\"/c/headphones/\">Headphones</a> (8 products)\n- <a href=\"/c/cameras/\">Cameras</a> (5 products)"];
        }

        $brandName = $brand['name'] ?? '';
        $productCount = max((int) ($brand['product_count'] ?? 0), 1);

        // Get actual products
        $products = $wpdb->get_results($wpdb->prepare(
            "SELECT title, rating, category_path FROM {$prefix}acms_products
             WHERE brand = %s AND status = 'scraped'
             ORDER BY rating DESC LIMIT 15",
            $brandName
        ), ARRAY_A);

        $productsContext = '';
        if (!empty($products)) {
            $productsContext = "Sample products from this brand ({$productCount} total):\n";
            foreach ($products as $p) {
                $productsContext .= "- {$p['title']}";
                if (!empty($p['rating'])) $productsContext .= " (Rating: {$p['rating']}/5)";
                $productsContext .= "\n";
            }
        } else {
            $productsContext = '(no product data available)';
        }

        // Get categories from products
        $categories = [];
        foreach ($products as $p) {
            if (!empty($p['category_path'])) $categories[] = $p['category_path'];
        }
        $categories = array_unique($categories);
        $categoriesContext = !empty($categories)
            ? 'Product categories: ' . implode(', ', array_slice($categories, 0, 5))
            : '(no category data available)';

        // Get brand category links
        $catLinks = $wpdb->get_results($wpdb->prepare(
            "SELECT c.name, c.slug, COUNT(DISTINCT p.id) as brand_product_count
             FROM {$prefix}acms_categories c
             INNER JOIN {$prefix}acms_category_products cp ON c.id = cp.category_id
             INNER JOIN {$prefix}acms_products p ON cp.product_id = p.id
             WHERE p.brand = %s AND c.status = 'publish'
             GROUP BY c.id, c.name, c.slug
             ORDER BY brand_product_count DESC LIMIT 10",
            $brandName
        ), ARRAY_A);

        $brandCatLinksContext = '';
        if (!empty($catLinks)) {
            $brandCatLinksContext = "## Related Category Pages for Internal Linking\n";
            $brandCatLinksContext .= "Categories this brand's products appear in:\n";
            foreach ($catLinks as $cl) {
                $brandCatLinksContext .= "- <a href=\"/c/{$cl['slug']}/\">{$cl['name']}</a> ({$cl['brand_product_count']} products)\n";
            }
        } else {
            $brandCatLinksContext = '(no category links available - skip internal linking instructions)';
        }

        return [
            'brand_name' => $brandName,
            'brand_slug' => $brand['slug'] ?? '',
            'website_context' => !empty($brand['website_url']) ? 'Official Website: ' . $brand['website_url'] : '(not available)',
            'categories_context' => $categoriesContext,
            'products_context' => $productsContext,
            'product_count' => (string) $productCount,
            'brand_category_links' => $brandCatLinksContext,
        ];
    }

    /**
     * Resolve materialized path (e.g. /129608/129609/) to readable names (e.g. "Home & Kitchen > Kitchen & Dining")
     */
    private function resolveCategoryPath($wpdb, string $prefix, string $materializedPath, string $currentName): string
    {
        if (empty($materializedPath) || $materializedPath === '/') {
            return $currentName;
        }

        // Extract IDs from path like /129608/129609/129610/
        $ids = array_filter(explode('/', trim($materializedPath, '/')), 'is_numeric');
        if (empty($ids)) {
            return $currentName;
        }

        $placeholders = implode(',', array_fill(0, count($ids), '%d'));
        $names = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, name FROM {$prefix}acms_categories WHERE id IN ({$placeholders})",
                ...$ids
            ),
            OBJECT_K
        );

        // Build path in order of IDs
        $pathParts = [];
        foreach ($ids as $id) {
            if (isset($names[$id])) {
                $pathParts[] = $names[$id]->name;
            }
        }

        // Append current category name if not already last
        if (empty($pathParts) || end($pathParts) !== $currentName) {
            $pathParts[] = $currentName;
        }

        return implode(' > ', $pathParts);
    }

}
