<?php
/**
 * AffiliateCMS AI - Stats Controller
 */

declare(strict_types=1);

namespace AffiliateCMS\AI\Api;

use WP_REST_Controller;
use WP_REST_Request;
use WP_REST_Response;

class StatsController extends WP_REST_Controller
{
    protected $namespace = 'acms-ai/v1';

    /**
     * Register routes
     */
    public function registerRoutes(): void
    {
        register_rest_route($this->namespace, '/stats', [
            [
                'methods' => 'GET',
                'callback' => [$this, 'getStats'],
                'permission_callback' => [$this, 'checkPermission'],
            ],
        ]);

        register_rest_route($this->namespace, '/usage', [
            [
                'methods' => 'GET',
                'callback' => [$this, 'getUsage'],
                'permission_callback' => [$this, 'checkPermission'],
            ],
        ]);

        register_rest_route($this->namespace, '/usage/daily', [
            [
                'methods' => 'GET',
                'callback' => [$this, 'getDailyUsage'],
                'permission_callback' => [$this, 'checkPermission'],
                'args' => [
                    'period' => [
                        'default' => '7d',
                        'sanitize_callback' => 'sanitize_text_field',
                    ],
                ],
            ],
        ]);
    }

    /**
     * Check permission
     */
    public function checkPermission(): bool
    {
        return current_user_can('manage_options');
    }

    /**
     * Get dashboard stats
     */
    public function getStats(): WP_REST_Response
    {
        global $wpdb;

        $jobsTable = $wpdb->prefix . 'acms_ai_jobs';
        $usageTable = $wpdb->prefix . 'acms_ai_usage';

        // Get current month stats
        $currentMonth = gmdate('Y-m');
        $monthStart = $currentMonth . '-01';
        $monthEnd = gmdate('Y-m-t');

        // Get job counts
        $jobStats = $wpdb->get_row("
            SELECT
                COUNT(*) as total,
                SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
                SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
                SUM(CASE WHEN status = 'processing' THEN 1 ELSE 0 END) as processing,
                SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed,
                SUM(tokens_used) as tokens,
                SUM(cost) as cost
            FROM {$jobsTable}
        ", ARRAY_A);

        // Get monthly spend
        $monthlySpend = $wpdb->get_var($wpdb->prepare("
            SELECT SUM(cost_total)
            FROM {$usageTable}
            WHERE date BETWEEN %s AND %s
        ", $monthStart, $monthEnd)) ?? 0;

        // Get monthly budget
        $monthlyBudget = (float) get_option('acms_ai_monthly_budget', 50);

        return new WP_REST_Response([
            'monthlyBudget' => $monthlyBudget,
            'currentSpend' => (float) $monthlySpend,
            'totalJobs' => (int) ($jobStats['total'] ?? 0),
            'completedJobs' => (int) ($jobStats['completed'] ?? 0),
            'pendingJobs' => (int) ($jobStats['pending'] ?? 0),
            'processingJobs' => (int) ($jobStats['processing'] ?? 0),
            'failedJobs' => (int) ($jobStats['failed'] ?? 0),
            'tokensUsed' => (int) ($jobStats['tokens'] ?? 0),
            'totalCost' => (float) ($jobStats['cost'] ?? 0),
        ]);
    }

    /**
     * Get usage by provider/model
     */
    public function getUsage(): WP_REST_Response
    {
        global $wpdb;

        $usageTable = $wpdb->prefix . 'acms_ai_usage';

        // Get current month
        $currentMonth = gmdate('Y-m');
        $monthStart = $currentMonth . '-01';
        $monthEnd = gmdate('Y-m-t');

        $usage = $wpdb->get_results($wpdb->prepare("
            SELECT
                model,
                SUM(requests_count) as requests,
                SUM(tokens_input + tokens_output) as tokens,
                SUM(cost_total) as cost
            FROM {$usageTable}
            WHERE date BETWEEN %s AND %s
            GROUP BY model
            ORDER BY cost DESC
        ", $monthStart, $monthEnd), ARRAY_A);

        // Format usage data
        $formattedUsage = array_map(function ($item) {
            // Extract provider from model (e.g., openai/gpt-4o -> openai)
            $parts = explode('/', $item['model']);
            $provider = $parts[0] ?? 'unknown';

            return [
                'model' => $item['model'],
                'provider' => $provider,
                'requests' => (int) $item['requests'],
                'tokens' => (int) $item['tokens'],
                'cost' => (float) $item['cost'],
            ];
        }, $usage ?: []);

        return new WP_REST_Response($formattedUsage);
    }

    /**
     * Get daily usage for chart
     */
    public function getDailyUsage(WP_REST_Request $request): WP_REST_Response
    {
        global $wpdb;

        $period = $request->get_param('period');
        $usageTable = $wpdb->prefix . 'acms_ai_usage';

        // Calculate date range
        $days = match ($period) {
            '30d' => 30,
            '90d' => 90,
            default => 7,
        };

        $startDate = gmdate('Y-m-d', strtotime("-{$days} days"));
        $endDate = gmdate('Y-m-d');

        $usage = $wpdb->get_results($wpdb->prepare("
            SELECT
                date,
                SUM(requests_count) as requests,
                SUM(tokens_input + tokens_output) as tokens,
                SUM(cost_total) as cost
            FROM {$usageTable}
            WHERE date BETWEEN %s AND %s
            GROUP BY date
            ORDER BY date ASC
        ", $startDate, $endDate), ARRAY_A);

        // Fill in missing dates with zero values
        $dateMap = [];
        foreach ($usage ?: [] as $item) {
            $dateMap[$item['date']] = [
                'date' => $item['date'],
                'requests' => (int) $item['requests'],
                'tokens' => (int) $item['tokens'],
                'cost' => (float) $item['cost'],
            ];
        }

        $result = [];
        for ($i = $days; $i >= 0; $i--) {
            $date = gmdate('Y-m-d', strtotime("-{$i} days"));
            $result[] = $dateMap[$date] ?? [
                'date' => $date,
                'requests' => 0,
                'tokens' => 0,
                'cost' => 0,
            ];
        }

        return new WP_REST_Response($result);
    }
}
