<?php
/**
 * AffiliateCMS AI - Job Controller
 */

declare(strict_types=1);

namespace AffiliateCMS\AI\Api;

use WP_REST_Controller;
use WP_REST_Request;
use WP_REST_Response;
use WP_Error;

class JobController extends WP_REST_Controller
{
    protected $namespace = 'acms-ai/v1';
    protected $rest_base = 'jobs';

    /**
     * Register routes
     */
    public function registerRoutes(): void
    {
        register_rest_route($this->namespace, '/' . $this->rest_base, [
            [
                'methods' => 'GET',
                'callback' => [$this, 'getJobs'],
                'permission_callback' => [$this, 'checkPermission'],
                'args' => [
                    'page' => [
                        'default' => 1,
                        'sanitize_callback' => 'absint',
                    ],
                    'per_page' => [
                        'default' => 20,
                        'sanitize_callback' => 'absint',
                    ],
                    'status' => [
                        'default' => '',
                        'sanitize_callback' => 'sanitize_text_field',
                    ],
                    'type' => [
                        'default' => '',
                        'sanitize_callback' => 'sanitize_text_field',
                    ],
                    'search' => [
                        'default' => '',
                        'sanitize_callback' => 'sanitize_text_field',
                    ],
                    'orderby' => [
                        'default' => 'created_at',
                        'sanitize_callback' => 'sanitize_text_field',
                    ],
                    'order' => [
                        'default' => 'DESC',
                        'sanitize_callback' => 'sanitize_text_field',
                    ],
                ],
            ],
        ]);

        register_rest_route($this->namespace, '/' . $this->rest_base . '/(?P<id>\d+)/retry', [
            [
                'methods' => 'POST',
                'callback' => [$this, 'retryJob'],
                'permission_callback' => [$this, 'checkPermission'],
            ],
        ]);

        register_rest_route($this->namespace, '/' . $this->rest_base . '/(?P<id>\d+)/cancel', [
            [
                'methods' => 'POST',
                'callback' => [$this, 'cancelJob'],
                'permission_callback' => [$this, 'checkPermission'],
            ],
        ]);

        // Trigger category AI for a queue item
        register_rest_route($this->namespace, '/category-ai/queue/(?P<queue_id>\d+)', [
            [
                'methods' => 'POST',
                'callback' => [$this, 'triggerCategoryAi'],
                'permission_callback' => [$this, 'checkPermission'],
                'args' => [
                    'force' => [
                        'type' => 'boolean',
                        'default' => false,
                        'description' => 'Force re-run even if already processed',
                    ],
                ],
            ],
        ]);

        // API Activity Log - enriched job data with target names for monitoring
        register_rest_route($this->namespace, '/api-log', [
            [
                'methods' => 'GET',
                'callback' => [$this, 'getApiLog'],
                'permission_callback' => [$this, 'checkPermission'],
                'args' => [
                    'limit' => ['default' => 50, 'sanitize_callback' => 'absint'],
                    'type' => ['default' => '', 'sanitize_callback' => 'sanitize_text_field'],
                    'status' => ['default' => '', 'sanitize_callback' => 'sanitize_text_field'],
                ],
            ],
        ]);

        // Trigger content AI for a category
        register_rest_route($this->namespace, '/content-ai/category/(?P<category_id>\d+)', [
            [
                'methods' => 'POST',
                'callback' => [$this, 'triggerContentAi'],
                'permission_callback' => [$this, 'checkPermission'],
                'args' => [
                    'queue_id' => [
                        'type' => 'integer',
                        'default' => 0,
                        'description' => 'Originating queue item ID for status tracking',
                    ],
                    'force' => [
                        'type' => 'boolean',
                        'default' => false,
                        'description' => 'Force re-run even if content already generated',
                    ],
                ],
            ],
        ]);
    }

    /**
     * Check permission
     */
    public function checkPermission(): bool
    {
        return current_user_can('manage_options');
    }

    /**
     * Get jobs list
     */
    public function getJobs(WP_REST_Request $request): WP_REST_Response
    {
        global $wpdb;

        $page = $request->get_param('page');
        $perPage = min($request->get_param('per_page'), 100);
        $status = $request->get_param('status');
        $type = $request->get_param('type');
        $search = $request->get_param('search');

        $table = $wpdb->prefix . 'acms_ai_jobs';
        $where = ['1=1'];
        $params = [];

        if ($status) {
            $where[] = 'status = %s';
            $params[] = $status;
        }

        if ($type) {
            $where[] = 'type = %s';
            $params[] = $type;
        }

        if ($search) {
            $like = '%' . $wpdb->esc_like($search) . '%';
            $where[] = '(target_id LIKE %s OR type LIKE %s OR error_message LIKE %s OR model LIKE %s)';
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
        }

        $whereClause = implode(' AND ', $where);

        // Get total count
        $countQuery = "SELECT COUNT(*) FROM {$table} WHERE {$whereClause}";
        if (!empty($params)) {
            $countQuery = $wpdb->prepare($countQuery, ...$params);
        }
        $total = (int) $wpdb->get_var($countQuery);

        // Sorting
        $sortableColumns = ['id', 'type', 'status', 'created_at', 'completed_at', 'tokens_used', 'cost', 'model'];
        $orderby = in_array($request->get_param('orderby'), $sortableColumns, true)
            ? $request->get_param('orderby') : 'created_at';
        $order = strtoupper($request->get_param('order')) === 'ASC' ? 'ASC' : 'DESC';

        // Get jobs
        $offset = ($page - 1) * $perPage;
        $query = "SELECT * FROM {$table} WHERE {$whereClause} ORDER BY {$orderby} {$order} LIMIT %d OFFSET %d";
        $queryParams = array_merge($params, [$perPage, $offset]);
        $jobs = $wpdb->get_results($wpdb->prepare($query, ...$queryParams), ARRAY_A);

        // Format jobs
        $formattedJobs = array_map(function ($job) {
            return [
                'id' => (int) $job['id'],
                'type' => $job['type'],
                'status' => $job['status'],
                'target_type' => $job['target_type'],
                'target_id' => $job['target_id'],
                'model' => $job['model'],
                'tokens_used' => (int) $job['tokens_used'],
                'cost' => (float) $job['cost'],
                'attempts' => (int) $job['attempts'],
                'error_message' => $job['error_message'],
                'created_at' => $job['created_at'],
                'completed_at' => $job['completed_at'],
            ];
        }, $jobs ?: []);

        $response = new WP_REST_Response($formattedJobs);
        $response->header('X-WP-Total', $total);
        $response->header('X-WP-TotalPages', ceil($total / $perPage));

        return $response;
    }

    /**
     * Get API Activity Log — enriched job data with target names for monitoring
     *
     * Returns recent jobs with:
     * - Resolved target names (brand name, category name, product title)
     * - Duration calculation (processing_at → completed_at)
     * - Repeated target detection (same target called multiple times today)
     * - Today's summary stats
     */
    public function getApiLog(WP_REST_Request $request): WP_REST_Response
    {
        global $wpdb;

        $limit = min($request->get_param('limit'), 100);
        $typeFilter = $request->get_param('type');
        $statusFilter = $request->get_param('status');

        $jobsTable = $wpdb->prefix . 'acms_ai_jobs';

        // Build WHERE
        $where = ['1=1'];
        $params = [];

        if ($typeFilter) {
            $where[] = 'j.type = %s';
            $params[] = $typeFilter;
        }
        if ($statusFilter) {
            $where[] = 'j.status = %s';
            $params[] = $statusFilter;
        }

        $whereClause = implode(' AND ', $where);
        $params[] = $limit;

        $query = "SELECT j.* FROM {$jobsTable} j WHERE {$whereClause} ORDER BY j.id DESC LIMIT %d";
        $jobs = $wpdb->get_results($wpdb->prepare($query, ...$params), ARRAY_A);

        // Collect target IDs by type for batch name resolution
        $brandIds = [];
        $categoryIds = [];
        $productTargets = [];

        foreach ($jobs ?: [] as $job) {
            $targetId = $job['target_id'] ?? '';
            switch ($job['target_type'] ?? '') {
                case 'seo_brand':
                    if ($targetId) $brandIds[] = (int) $targetId;
                    break;
                case 'seo_category':
                    if ($targetId) $categoryIds[] = (int) $targetId;
                    break;
                case 'product':
                    if ($targetId) $productTargets[] = $targetId;
                    break;
            }
        }

        // Batch resolve names
        $brandNames = $this->resolveNames($wpdb->prefix . 'acms_brands', 'name', array_unique($brandIds));
        $categoryNames = $this->resolveNames($wpdb->prefix . 'acms_categories', 'name', array_unique($categoryIds));
        $productNames = $this->resolveProductNames(array_unique($productTargets));

        // Detect repeated targets today
        $todayStart = gmdate('Y-m-d 00:00:00');
        $repeatedTargets = $wpdb->get_results($wpdb->prepare(
            "SELECT target_type, target_id, COUNT(*) as call_count, SUM(tokens_used) as total_tokens
             FROM {$jobsTable}
             WHERE created_at >= %s AND status IN ('completed', 'failed', 'processing')
             GROUP BY target_type, target_id
             HAVING call_count > 2
             ORDER BY call_count DESC
             LIMIT 20",
            $todayStart
        ), ARRAY_A);

        // Format repeated targets with names
        $repeatedFormatted = [];
        foreach ($repeatedTargets ?: [] as $rt) {
            $name = $this->resolveTargetName($rt['target_type'], $rt['target_id'], $brandNames, $categoryNames, $productNames);
            $repeatedFormatted[] = [
                'target_type' => $rt['target_type'],
                'target_id' => $rt['target_id'],
                'target_name' => $name,
                'call_count' => (int) $rt['call_count'],
                'total_tokens' => (int) $rt['total_tokens'],
                'level' => (int) $rt['call_count'] > 5 ? 'danger' : 'warning',
            ];
        }

        // Today's summary
        $todayStats = $wpdb->get_row($wpdb->prepare(
            "SELECT
                COUNT(*) as total_calls,
                SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
                SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed,
                SUM(CASE WHEN status = 'processing' THEN 1 ELSE 0 END) as processing,
                COALESCE(SUM(tokens_used), 0) as total_tokens,
                COALESCE(SUM(cost), 0) as total_cost
             FROM {$jobsTable}
             WHERE created_at >= %s",
            $todayStart
        ), ARRAY_A);

        // Format jobs
        $items = [];
        foreach ($jobs ?: [] as $job) {
            $targetName = $this->resolveTargetName(
                $job['target_type'] ?? '',
                $job['target_id'] ?? '',
                $brandNames,
                $categoryNames,
                $productNames
            );

            // Calculate duration
            $duration = null;
            if ($job['processing_at'] && $job['completed_at']) {
                $start = strtotime($job['processing_at']);
                $end = strtotime($job['completed_at']);
                if ($start && $end) {
                    $duration = $end - $start;
                }
            }

            // Type label
            $typeLabels = [
                'generate_seo_category' => 'Category SEO',
                'generate_seo_brand' => 'Brand SEO',
                'enhance_asin' => 'ASIN Enhance',
                'optimize_review' => 'Review Optimize',
                'generate_category' => 'Category Gen',
                'standardize_categories' => 'Cat Standardize',
            ];

            $items[] = [
                'id' => (int) $job['id'],
                'type' => $job['type'],
                'type_label' => $typeLabels[$job['type']] ?? $job['type'],
                'status' => $job['status'],
                'target_type' => $job['target_type'],
                'target_id' => $job['target_id'],
                'target_name' => $targetName,
                'model' => $job['model'] ?: '-',
                'tokens_used' => (int) $job['tokens_used'],
                'tokens_input' => (int) ($job['tokens_input'] ?? 0),
                'tokens_output' => (int) ($job['tokens_output'] ?? 0),
                'cost' => (float) $job['cost'],
                'duration_seconds' => $duration,
                'attempts' => (int) $job['attempts'],
                'error_message' => $job['error_message'],
                'api_created_at' => $job['api_created_at'] ?? null,
                'created_at' => $job['created_at'],
                'processing_at' => $job['processing_at'],
                'completed_at' => $job['completed_at'],
            ];
        }

        return new WP_REST_Response([
            'items' => $items,
            'summary' => [
                'total_calls' => (int) ($todayStats['total_calls'] ?? 0),
                'completed' => (int) ($todayStats['completed'] ?? 0),
                'failed' => (int) ($todayStats['failed'] ?? 0),
                'processing' => (int) ($todayStats['processing'] ?? 0),
                'total_tokens' => (int) ($todayStats['total_tokens'] ?? 0),
                'total_cost' => (float) ($todayStats['total_cost'] ?? 0),
            ],
            'repeated_targets' => $repeatedFormatted,
        ]);
    }

    /**
     * Batch resolve entity names from a table
     */
    private function resolveNames(string $table, string $nameColumn, array $ids): array
    {
        if (empty($ids)) return [];
        global $wpdb;

        $tableExists = $wpdb->get_var("SHOW TABLES LIKE '{$table}'");
        if (!$tableExists) return [];

        $placeholders = implode(',', array_fill(0, count($ids), '%d'));
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT id, {$nameColumn} FROM {$table} WHERE id IN ({$placeholders})",
            ...$ids
        ), ARRAY_A);

        $map = [];
        foreach ($rows ?: [] as $row) {
            $map[(int) $row['id']] = $row[$nameColumn];
        }
        return $map;
    }

    /**
     * Resolve product names by ASIN or ID
     */
    private function resolveProductNames(array $targets): array
    {
        if (empty($targets)) return [];
        global $wpdb;
        $table = $wpdb->prefix . 'acms_products';

        $tableExists = $wpdb->get_var("SHOW TABLES LIKE '{$table}'");
        if (!$tableExists) return [];

        $placeholders = implode(',', array_fill(0, count($targets), '%s'));
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT id, asin, title FROM {$table} WHERE id IN ({$placeholders}) OR asin IN ({$placeholders})",
            ...array_merge($targets, $targets)
        ), ARRAY_A);

        $map = [];
        foreach ($rows ?: [] as $row) {
            $name = mb_substr($row['title'] ?: ('ASIN: ' . $row['asin']), 0, 60);
            $map[$row['asin']] = $name;
            $map[(string) $row['id']] = $name;
        }
        return $map;
    }

    /**
     * Resolve a single target name from pre-loaded maps
     */
    private function resolveTargetName(string $targetType, string $targetId, array $brands, array $categories, array $products): string
    {
        if (!$targetId) return '-';
        switch ($targetType) {
            case 'seo_brand':
                return $brands[(int) $targetId] ?? "Brand #{$targetId}";
            case 'seo_category':
                return $categories[(int) $targetId] ?? "Category #{$targetId}";
            case 'product':
                return $products[$targetId] ?? "Product #{$targetId}";
            default:
                return "{$targetType} #{$targetId}";
        }
    }

    /**
     * Retry a failed job
     */
    public function retryJob(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        global $wpdb;

        $jobId = (int) $request->get_param('id');
        $table = $wpdb->prefix . 'acms_ai_jobs';

        $job = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table} WHERE id = %d",
            $jobId
        ));

        if (!$job) {
            return new WP_Error('not_found', 'Job not found', ['status' => 404]);
        }

        if ($job->status !== 'failed') {
            return new WP_Error('invalid_status', 'Only failed jobs can be retried', ['status' => 400]);
        }

        $wpdb->update(
            $table,
            [
                'status' => 'pending',
                'error_message' => null,
                'attempts' => 0,
            ],
            ['id' => $jobId],
            ['%s', '%s', '%d'],
            ['%d']
        );

        return new WP_REST_Response(['success' => true, 'message' => 'Job queued for retry']);
    }

    /**
     * Cancel a pending job
     */
    public function cancelJob(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        global $wpdb;

        $jobId = (int) $request->get_param('id');
        $table = $wpdb->prefix . 'acms_ai_jobs';

        $job = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table} WHERE id = %d",
            $jobId
        ));

        if (!$job) {
            return new WP_Error('not_found', 'Job not found', ['status' => 404]);
        }

        if ($job->status !== 'pending') {
            return new WP_Error('invalid_status', 'Only pending jobs can be cancelled', ['status' => 400]);
        }

        $wpdb->delete($table, ['id' => $jobId], ['%d']);

        return new WP_REST_Response(['success' => true, 'message' => 'Job cancelled']);
    }

    /**
     * Trigger category AI standardization for a queue item
     */
    public function triggerCategoryAi(WP_REST_Request $request): WP_REST_Response
    {
        $queueId = (int) $request->get_param('queue_id');
        $force = (bool) $request->get_param('force');

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("[ACMS JobController] triggerCategoryAi called - queue: {$queueId}, force: " . ($force ? 'true' : 'false'));
        }

        $processor = new \AffiliateCMS\AI\Core\CategoryAiProcessor();
        $result = $processor->triggerForQueue($queueId, $force);

        // Include debug info in response
        $result['debug'] = [
            'force_received' => $force,
            'queue_id' => $queueId,
        ];

        return new WP_REST_Response($result);
    }

    /**
     * Trigger content AI generation for a category
     */
    public function triggerContentAi(WP_REST_Request $request): WP_REST_Response
    {
        global $wpdb;

        $categoryId = (int) $request->get_param('category_id');
        $queueId = (int) $request->get_param('queue_id');
        $force = (bool) $request->get_param('force');

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("[ACMS JobController] triggerContentAi called - category: {$categoryId}, queue: {$queueId}, force: " . ($force ? 'true' : 'false'));
        }

        $jobsTable = $wpdb->prefix . 'acms_ai_jobs';
        $categoriesTable = $wpdb->prefix . 'acms_categories';

        // Check if category exists
        $category = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$categoriesTable} WHERE id = %d",
            $categoryId
        ), ARRAY_A);

        if (!$category) {
            return new WP_REST_Response([
                'success' => false,
                'message' => 'Category not found',
            ]);
        }

        // Check if job already exists (unless force)
        if (!$force) {
            $existingJob = $wpdb->get_row($wpdb->prepare(
                "SELECT id, status FROM {$jobsTable}
                 WHERE type = 'generate_seo_category'
                 AND target_type = 'seo_category'
                 AND target_id = %s
                 AND status IN ('pending', 'processing')
                 LIMIT 1",
                (string) $categoryId
            ), ARRAY_A);

            if ($existingJob) {
                return new WP_REST_Response([
                    'success' => false,
                    'message' => "A {$existingJob['status']} job (ID: {$existingJob['id']}) already exists for this category.",
                ]);
            }
        }

        // If force, delete existing pending/processing/failed jobs
        if ($force) {
            $deleted = $wpdb->query($wpdb->prepare(
                "DELETE FROM {$jobsTable}
                 WHERE type = 'generate_seo_category'
                 AND target_type = 'seo_category'
                 AND target_id = %s
                 AND status IN ('pending', 'processing', 'failed')",
                (string) $categoryId
            ));

            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("[ACMS JobController] Deleted {$deleted} existing jobs for category {$categoryId}");
            }

            // Reset category content status
            $wpdb->update(
                $categoriesTable,
                [
                    'content_status' => 'empty',
                    'ai_generating_at' => null,
                    'ai_error_message' => null,
                ],
                ['id' => $categoryId],
                ['%s', '%s', '%s'],
                ['%d']
            );
        }

        // Get products in this category for context
        $junctionTable = $wpdb->prefix . 'acms_category_products';
        $productsTable = $wpdb->prefix . 'acms_products';

        $products = $wpdb->get_results($wpdb->prepare(
            "SELECT p.asin, p.title, p.brand, p.category_path, p.rating, p.reviews_count
             FROM {$productsTable} p
             INNER JOIN {$junctionTable} cp ON cp.product_id = p.id
             WHERE cp.category_id = %d AND p.status = 'scraped'
             ORDER BY cp.is_primary DESC, p.rating DESC
             LIMIT 15",
            $categoryId
        ), ARRAY_A);

        // Get parent category names for context
        $parentCategories = [];
        if (!empty($category['path']) && $category['path'] !== '/') {
            $pathIds = array_filter(explode('/', trim($category['path'], '/')));
            if (!empty($pathIds)) {
                $placeholders = implode(',', array_fill(0, count($pathIds), '%d'));
                $names = $wpdb->get_results($wpdb->prepare(
                    "SELECT id, name FROM {$categoriesTable} WHERE id IN ({$placeholders}) ORDER BY depth ASC",
                    ...$pathIds
                ), ARRAY_A);

                $nameMap = [];
                foreach ($names as $cat) {
                    $nameMap[$cat['id']] = $cat['name'];
                }
                foreach ($pathIds as $id) {
                    if (isset($nameMap[$id])) {
                        $parentCategories[] = $nameMap[$id];
                    }
                }
            }
        }

        // Build category path
        $categoryPath = !empty($parentCategories)
            ? implode(' > ', $parentCategories) . ' > ' . $category['name']
            : $category['name'];

        // Prepare job input data - include queue_id so we can update queue when done
        $inputData = [
            'category_id' => $categoryId,
            'category_name' => $category['name'],
            'category_slug' => $category['slug'] ?? '',
            'category_path' => $categoryPath,
            'parent_categories' => $parentCategories,
            'products' => $products ?: [],
            'current_description' => $category['description'] ?? '',
            'queue_id' => $queueId,  // Track originating queue item
        ];

        // Mark category as generating
        $wpdb->update(
            $categoriesTable,
            [
                'content_status' => 'ai_generating',
                'ai_generating_at' => current_time('mysql'),
                'ai_error_message' => null,
            ],
            ['id' => $categoryId],
            ['%s', '%s', '%s'],
            ['%d']
        );

        // Update queue ai_status if queue_id provided
        if ($queueId > 0) {
            $queueTable = $wpdb->prefix . 'acms_cat_queue';
            $wpdb->update(
                $queueTable,
                ['ai_status' => 'generating_content'],
                ['id' => $queueId],
                ['%s'],
                ['%d']
            );
        }

        // Create the job
        $inserted = $wpdb->insert($jobsTable, [
            'type' => 'generate_seo_category',
            'status' => 'pending',
            'priority' => 45,  // Higher priority for manual trigger
            'target_type' => 'seo_category',
            'target_id' => (string) $categoryId,
            'input_data' => wp_json_encode($inputData),
            'created_at' => current_time('mysql'),
        ]);

        if (!$inserted) {
            return new WP_REST_Response([
                'success' => false,
                'message' => 'Failed to create AI job: ' . $wpdb->last_error,
            ]);
        }

        return new WP_REST_Response([
            'success' => true,
            'message' => "Content AI job created for category '{$category['name']}'" . ($queueId > 0 ? " (queue: {$queueId})" : ""),
            'job_id' => $wpdb->insert_id,
            'debug' => [
                'category_id' => $categoryId,
                'queue_id' => $queueId,
                'force' => $force,
                'products_count' => count($products ?: []),
            ],
        ]);
    }
}
