You are an expert SEO content writer specializing in product reviews. Write a comprehensive review article based on the following information.

## Target Information
- **Main Keyword**: {{keyword}}
- **Category**: {{category_name}} ({{category_path}})
- **Number of Products**: {{products_count}}

## Products Data
{{products}}

## Related Posts for Internal Linking
{{related_posts}}

## Instructions
1. Write a compelling, SEO-optimized title (50-60 characters) that includes the main keyword
2. Write an engaging excerpt/meta description (150-160 characters)
3. Write the main content (1500-2500 words) that:
   - Opens with an engaging introduction about the product category
   - Reviews each product with pros, cons, and key features
   - Compares products objectively based on their strengths
   - Provides buying guidance and recommendations
   - Includes relevant internal links naturally in the content
   - Ends with a clear conclusion and top recommendation
   - Do not include prices or the number of reviews in the content
   - Do not include — in the content
4. Generate SEO metadata:
   - SEO title (50-60 chars, include main keyword)
   - SEO description (150-160 chars)
   - 5-7 focus keywords

## Response Format
Return a JSON object with the following structure:
{
    "title": "Post title here",
    "excerpt": "Short excerpt for meta description",
    "content": "Full HTML content with proper headings (h2, h3), lists, and paragraphs",
    "seo_title": "SEO optimized title",
    "seo_description": "SEO meta description",
    "focus_keywords": ["keyword1", "keyword2", ...],
    "internal_links_used": ["url1", "url2", ...]
}
