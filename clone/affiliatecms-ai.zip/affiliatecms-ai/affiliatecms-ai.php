<?php
/**
 * Plugin Name: AffiliateCMS AI
 * Plugin URI: https://affiliatecms.com/ai
 * Description: AI-powered content enhancement for AffiliateCMS Pro with OpenRouter integration
 * Version: 1.0.0
 * Requires at least: 6.0
 * Requires PHP: 8.1
 * Author: AffiliateCMS
 * Author URI: https://affiliatecms.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: affiliatecms-ai
 * Domain Path: /languages
 */

declare(strict_types=1);

namespace AffiliateCMS\AI;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Plugin constants
define('ACMS_AI_VERSION', '1.0.0');
define('ACMS_AI_FILE', __FILE__);
define('ACMS_AI_PATH', plugin_dir_path(__FILE__));
define('ACMS_AI_URL', plugin_dir_url(__FILE__));
define('ACMS_AI_BASENAME', plugin_basename(__FILE__));

/**
 * Check if AffiliateCMS Pro is active
 */
function acms_ai_check_dependencies(): bool
{
    if (!class_exists('AffiliateCMS\Pro\Core\Bootstrap')) {
        add_action('admin_notices', function () {
            echo '<div class="notice notice-error"><p>';
            echo '<strong>AffiliateCMS AI</strong> requires <strong>AffiliateCMS Pro</strong> plugin to be active.';
            echo '</p></div>';
        });
        return false;
    }
    return true;
}

/**
 * Initialize plugin
 */
function acms_ai_init(): void
{
    if (!acms_ai_check_dependencies()) {
        return;
    }

    // Load autoloader
    require_once ACMS_AI_PATH . 'autoload.php';

    // Bootstrap plugin
    $bootstrap = new Core\Bootstrap();
    $bootstrap->init();
}

// Initialize on plugins_loaded
add_action('plugins_loaded', __NAMESPACE__ . '\acms_ai_init', 20);

/**
 * Activation hook
 */
register_activation_hook(__FILE__, function () {
    if (!acms_ai_check_dependencies()) {
        deactivate_plugins(plugin_basename(__FILE__));
        wp_die('AffiliateCMS AI requires AffiliateCMS Pro plugin to be active.');
    }

    $bufferLevel = ob_get_level();
    ob_start();
    try {
        @ini_set('display_errors', '0');

        require_once ACMS_AI_PATH . 'autoload.php';

        // Create database tables + run migrations
        $schema = new Database\Schema();
        $schema->createTables();
        $schema->migrate();

        // Load and initialize Action Scheduler to create tables
        $asPath = ACMS_AI_PATH . 'libraries/action-scheduler/action-scheduler.php';
        if (file_exists($asPath)) {
            require_once $asPath;

            // Initialize AS - this triggers table creation via its internal hooks
            if (class_exists('ActionScheduler')) {
                // Force table creation by calling the data controller
                if (class_exists('ActionScheduler_DataController')) {
                    \ActionScheduler_DataController::init();
                }
                // Ensure store is initialized (creates tables)
                \ActionScheduler::store();
                \ActionScheduler::logger();
            }
        }

        // Set default options
        add_option('acms_ai_monthly_budget', 50);
        add_option('acms_ai_default_model', 'google/gemini-3-flash-preview');

        // Seed default prompt templates into wp_options
        Core\DefaultPrompts::seed();

        // Set version
        update_option('acms_ai_version', ACMS_AI_VERSION);
    } finally {
        while (ob_get_level() > $bufferLevel) {
            ob_end_clean();
        }
    }
});

/**
 * Deactivation hook
 */
register_deactivation_hook(__FILE__, function () {
    // Clean up scheduled events
    wp_clear_scheduled_hook('acms_ai_process_queue');
});
