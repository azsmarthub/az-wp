/**
 * AffiliateCMS AI - Admin JavaScript
 * Alpine.js components for AI Dashboard
 */

(function() {
    'use strict';

    // ===========================================
    // API CLIENT
    // ===========================================

    const api = {
        baseUrl: window.acmsAiConfig?.restUrl || '/wp-json/acms-ai/v1/',
        nonce: window.acmsAiConfig?.nonce || '',

        async request(method, endpoint, data = null) {
            const options = {
                method,
                headers: {
                    'X-WP-Nonce': this.nonce,
                    'Content-Type': 'application/json',
                },
            };

            if (data && ['POST', 'PUT', 'PATCH'].includes(method)) {
                options.body = JSON.stringify(data);
            }

            const url = new URL(this.baseUrl + endpoint, window.location.origin);

            if (data && method === 'GET') {
                Object.keys(data).forEach(key => {
                    if (data[key] !== null && data[key] !== undefined) {
                        url.searchParams.append(key, data[key]);
                    }
                });
            }

            const response = await fetch(url, options);

            const result = {
                data: await response.json(),
                headers: {
                    total: parseInt(response.headers.get('X-WP-Total') || '0'),
                    totalPages: parseInt(response.headers.get('X-WP-TotalPages') || '1'),
                },
                ok: response.ok,
            };

            if (!response.ok) {
                throw new Error(result.data?.message || 'Request failed');
            }

            return result;
        },

        get(endpoint, params) { return this.request('GET', endpoint, params); },
        post(endpoint, data) { return this.request('POST', endpoint, data); },
        patch(endpoint, data) { return this.request('PATCH', endpoint, data); },
        delete(endpoint) { return this.request('DELETE', endpoint); },
    };

    // ===========================================
    // AI DASHBOARD COMPONENT
    // ===========================================

    document.addEventListener('alpine:init', () => {
        Alpine.data('aiDashboard', () => ({
            // Stats
            stats: {
                monthlyBudget: 50,
                currentSpend: 0,
                totalJobs: 0,
                completedJobs: 0,
                pendingJobs: 0,
                failedJobs: 0,
                tokensUsed: 0,
            },

            // Usage by provider
            usageByProvider: [],

            // Loading states
            loading: false,
            statsLoading: false,

            // Initialize
            async init() {
                await Promise.all([
                    this.loadStats(),
                    this.loadUsage(),
                ]);
            },

            // Load stats
            async loadStats() {
                this.statsLoading = true;

                try {
                    const response = await api.get('stats');
                    this.stats = { ...this.stats, ...response.data };
                } catch (error) {
                    console.error('Failed to load stats:', error);
                } finally {
                    this.statsLoading = false;
                }
            },

            // Load usage breakdown
            async loadUsage() {
                try {
                    const response = await api.get('usage');
                    this.usageByProvider = response.data;
                } catch (error) {
                    console.error('Failed to load usage:', error);
                }
            },

            // Get budget percentage
            get budgetPercentage() {
                if (!this.stats.monthlyBudget) return 0;
                return Math.min(100, (this.stats.currentSpend / this.stats.monthlyBudget) * 100);
            },

            // Get progress bar class based on percentage
            get budgetProgressClass() {
                if (this.budgetPercentage >= 90) return 'acms-ai-usage__progress--danger';
                if (this.budgetPercentage >= 70) return 'acms-ai-usage__progress--warning';
                return '';
            },

            // Format currency
            formatCurrency(amount) {
                return new Intl.NumberFormat('en-US', {
                    style: 'currency',
                    currency: 'USD',
                }).format(amount);
            },

            // Format number
            formatNumber(num) {
                if (num >= 1000000) {
                    return (num / 1000000).toFixed(1) + 'M';
                }
                if (num >= 1000) {
                    return (num / 1000).toFixed(1) + 'K';
                }
                return num.toString();
            },

            // Quick action states
            resettingJobs: false,
            reschedulingAs: false,
            debugging: false,
            debugOutput: '',

            // Reset stuck jobs
            async resetStuckJobs() {
                this.resettingJobs = true;
                try {
                    const response = await api.post('reset-stuck-jobs');
                    if (response.data?.success) {
                        this.toast('success', response.data.message || 'Stuck jobs reset successfully');
                        await this.loadStats();
                    } else {
                        this.toast('error', response.data?.message || 'Failed to reset stuck jobs');
                    }
                } catch (error) {
                    console.error('Failed to reset stuck jobs:', error);
                    this.toast('error', 'Failed to reset stuck jobs');
                } finally {
                    this.resettingJobs = false;
                }
            },

            // Reschedule AS actions
            async rescheduleAs() {
                if (!confirm('This will cancel all scheduled AS actions and reschedule them with current intervals. Continue?')) {
                    return;
                }
                this.reschedulingAs = true;
                try {
                    const response = await api.post('reschedule-as');
                    if (response.data?.success) {
                        this.toast('success', response.data.message || 'AS actions rescheduled successfully');
                    } else {
                        this.toast('error', response.data?.message || 'Failed to reschedule AS actions');
                    }
                } catch (error) {
                    console.error('Failed to reschedule AS:', error);
                    this.toast('error', 'Failed to reschedule AS actions');
                } finally {
                    this.reschedulingAs = false;
                }
            },

            // Debug queue - show detailed info about stuck items
            async debugQueue() {
                this.debugging = true;
                this.debugOutput = '';
                try {
                    const response = await api.get('debug-queue');
                    if (response.data?.success) {
                        this.debugOutput = JSON.stringify(response.data.data, null, 2);
                    } else {
                        this.debugOutput = 'Error: ' + (response.data?.message || 'Failed to get debug info');
                    }
                } catch (error) {
                    console.error('Failed to debug queue:', error);
                    this.debugOutput = 'Error: ' + error.message;
                } finally {
                    this.debugging = false;
                }
            },

            // Simple toast notification
            toast(type, message) {
                // Use WordPress admin notices or a simple alert
                if (window.wp && window.wp.data && window.wp.data.dispatch) {
                    window.wp.data.dispatch('core/notices').createNotice(
                        type === 'success' ? 'success' : 'error',
                        message,
                        { type: 'snackbar', isDismissible: true }
                    );
                } else {
                    alert(message);
                }
            },
        }));

        // ===========================================
        // AI JOBS COMPONENT
        // ===========================================

        Alpine.data('aiJobs', () => ({
            jobs: [],
            loading: false,
            currentPage: 1,
            totalPages: 1,
            totalItems: 0,
            perPage: 20,

            // Filters
            statusFilter: '',
            typeFilter: '',
            searchQuery: '',
            sortColumn: 'created_at',
            sortDirection: 'DESC',
            _searchTimer: null,

            // Initialize
            async init() {
                await this.loadJobs();

                // Auto-refresh every 30 seconds
                setInterval(() => this.loadJobs(), 30000);
            },

            // Load jobs
            async loadJobs(append = false) {
                this.loading = true;

                try {
                    const params = {
                        page: this.currentPage,
                        per_page: this.perPage,
                        orderby: this.sortColumn,
                        order: this.sortDirection,
                    };

                    if (this.statusFilter) params.status = this.statusFilter;
                    if (this.typeFilter) params.type = this.typeFilter;
                    if (this.searchQuery) params.search = this.searchQuery;

                    const response = await api.get('jobs', params);

                    if (append) {
                        this.jobs = [...this.jobs, ...response.data];
                    } else {
                        this.jobs = response.data;
                    }

                    this.totalPages = response.headers.totalPages;
                    this.totalItems = parseInt(response.headers.total) || 0;

                } catch (error) {
                    console.error('Failed to load jobs:', error);
                } finally {
                    this.loading = false;
                }
            },

            // Filter by status
            async filterByStatus(status) {
                this.statusFilter = status;
                this.currentPage = 1;
                await this.loadJobs();
            },

            // Filter by type
            async filterByType(type) {
                this.typeFilter = type;
                this.currentPage = 1;
                await this.loadJobs();
            },

            // Search with debounce
            onSearchInput() {
                clearTimeout(this._searchTimer);
                this._searchTimer = setTimeout(() => {
                    this.currentPage = 1;
                    this.loadJobs();
                }, 300);
            },

            // Sort by column
            sortBy(column) {
                if (this.sortColumn === column) {
                    this.sortDirection = this.sortDirection === 'ASC' ? 'DESC' : 'ASC';
                } else {
                    this.sortColumn = column;
                    this.sortDirection = 'DESC';
                }
                this.currentPage = 1;
                this.loadJobs();
            },

            // Retry failed job
            async retryJob(jobId) {
                try {
                    await api.post(`jobs/${jobId}/retry`);
                    window.acms?.toast?.success('Job queued for retry');
                    await this.loadJobs();
                } catch (error) {
                    window.acms?.toast?.error('Failed to retry job');
                }
            },

            // Cancel job
            async cancelJob(jobId) {
                if (!confirm('Are you sure you want to cancel this job?')) return;

                try {
                    await api.post(`jobs/${jobId}/cancel`);
                    window.acms?.toast?.success('Job cancelled');
                    await this.loadJobs();
                } catch (error) {
                    window.acms?.toast?.error('Failed to cancel job');
                }
            },

            // Get job type label
            getTypeLabel(type) {
                const labels = {
                    enhance_asin: 'Enhance ASIN',
                    optimize_review: 'Optimize Review',
                    generate_category: 'Generate Category',
                };
                return labels[type] || type;
            },

            // Format tokens
            formatTokens(count) {
                if (count >= 1000) {
                    return (count / 1000).toFixed(1) + 'K';
                }
                return count.toString();
            },

            // Format time ago
            formatTimeAgo(dateStr) {
                const date = new Date(dateStr);
                const now = new Date();
                const seconds = Math.floor((now - date) / 1000);

                if (seconds < 60) return 'Just now';
                if (seconds < 3600) return Math.floor(seconds / 60) + 'm ago';
                if (seconds < 86400) return Math.floor(seconds / 3600) + 'h ago';
                return Math.floor(seconds / 86400) + 'd ago';
            },
        }));

        // ===========================================
        // AI SETTINGS COMPONENT
        // ===========================================

        Alpine.data('aiSettings', () => ({
            // Settings
            settings: {
                api_key: '',
                default_model: 'openai/gpt-4o-mini',
                monthly_budget: 50,
                enable_enhance_asin: true,
                enable_optimize_review: true,
                enable_generate_category: false,
            },

            // Available models
            models: [
                { id: 'openai/gpt-4o-mini', name: 'GPT-4o Mini', price: '$0.15/1M tokens', provider: 'openai' },
                { id: 'openai/gpt-4o', name: 'GPT-4o', price: '$5/1M tokens', provider: 'openai' },
                { id: 'anthropic/claude-3.5-sonnet', name: 'Claude 3.5 Sonnet', price: '$3/1M tokens', provider: 'anthropic' },
                { id: 'anthropic/claude-3-haiku', name: 'Claude 3 Haiku', price: '$0.25/1M tokens', provider: 'anthropic' },
                { id: 'google/gemini-pro', name: 'Gemini Pro', price: '$0.125/1M tokens', provider: 'google' },
            ],

            // UI State
            loading: false,
            saving: false,
            showApiKey: false,
            apiKeyValid: null,

            // Initialize
            async init() {
                await this.loadSettings();
            },

            // Load settings
            async loadSettings() {
                this.loading = true;

                try {
                    const response = await api.get('settings');
                    this.settings = { ...this.settings, ...response.data };

                    // Check if API key is valid
                    if (this.settings.api_key) {
                        await this.validateApiKey();
                    }
                } catch (error) {
                    console.error('Failed to load settings:', error);
                } finally {
                    this.loading = false;
                }
            },

            // Save settings
            async saveSettings() {
                this.saving = true;

                try {
                    await api.post('settings', this.settings);
                    window.acms?.toast?.success('Settings saved successfully');
                } catch (error) {
                    window.acms?.toast?.error(error.message || 'Failed to save settings');
                } finally {
                    this.saving = false;
                }
            },

            // Validate API key
            async validateApiKey() {
                try {
                    const response = await api.post('validate-key', {
                        api_key: this.settings.api_key,
                    });
                    this.apiKeyValid = response.data.valid;
                } catch (error) {
                    this.apiKeyValid = false;
                }
            },

            // Toggle API key visibility
            toggleApiKeyVisibility() {
                this.showApiKey = !this.showApiKey;
            },

            // Mask API key for display
            get maskedApiKey() {
                if (!this.settings.api_key) return '';
                const key = this.settings.api_key;
                if (key.length <= 8) return '****';
                return key.substring(0, 4) + '****' + key.substring(key.length - 4);
            },

            // Get model by ID
            getModel(modelId) {
                return this.models.find(m => m.id === modelId);
            },

            // Get provider icon class
            getProviderIconClass(provider) {
                const classes = {
                    openai: 'acms-ai-cost__icon--openai',
                    anthropic: 'acms-ai-cost__icon--anthropic',
                    google: 'acms-ai-cost__icon--gemini',
                };
                return classes[provider] || '';
            },
        }));

        // ===========================================
        // ENHANCE PREVIEW COMPONENT
        // ===========================================

        Alpine.data('enhancePreview', () => ({
            original: '',
            enhanced: '',
            loading: false,
            showPreview: false,

            // Test enhancement
            async testEnhance(type, content) {
                this.loading = true;
                this.showPreview = true;
                this.original = content;

                try {
                    const response = await api.post('preview', {
                        type,
                        content,
                    });

                    this.enhanced = response.data.enhanced;
                } catch (error) {
                    window.acms?.toast?.error('Failed to generate preview');
                    this.showPreview = false;
                } finally {
                    this.loading = false;
                }
            },

            // Close preview
            closePreview() {
                this.showPreview = false;
                this.original = '';
                this.enhanced = '';
            },
        }));

        // ===========================================
        // USAGE CHART COMPONENT
        // ===========================================

        Alpine.data('usageChart', () => ({
            data: [],
            loading: false,
            period: '7d',

            async init() {
                await this.loadData();
            },

            async loadData() {
                this.loading = true;

                try {
                    const response = await api.get('usage/daily', { period: this.period });
                    this.data = response.data;
                } catch (error) {
                    console.error('Failed to load usage data:', error);
                } finally {
                    this.loading = false;
                }
            },

            async changePeriod(period) {
                this.period = period;
                await this.loadData();
            },

            // Get max value for chart scaling
            get maxValue() {
                if (!this.data.length) return 1;
                return Math.max(...this.data.map(d => d.cost));
            },

            // Get bar height percentage
            getBarHeight(value) {
                return (value / this.maxValue) * 100;
            },
        }));
    });

    // ===========================================
    // UTILITIES
    // ===========================================

    const utils = {
        debounce(func, wait) {
            let timeout;
            return function executedFunction(...args) {
                const later = () => {
                    clearTimeout(timeout);
                    func(...args);
                };
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
            };
        },

        formatCurrency(amount) {
            return new Intl.NumberFormat('en-US', {
                style: 'currency',
                currency: 'USD',
            }).format(amount);
        },

        formatNumber(num) {
            if (num >= 1000000) {
                return (num / 1000000).toFixed(1) + 'M';
            }
            if (num >= 1000) {
                return (num / 1000).toFixed(1) + 'K';
            }
            return num.toString();
        },
    };

    // ===========================================
    // EXPOSE GLOBAL API
    // ===========================================

    window.acmsAi = {
        api,
        utils,
    };

})();
