<?php
/**
 * Search Results Template
 *
 * Searches across: SEO Categories, Brands, Products, and WP Posts
 *
 * @package AffiliateCMS
 * @since 4.0.0
 */

get_header();

$search_query = get_search_query();

// ── Search SEO Categories ──
$search_categories = [];
if ($search_query && class_exists(\AffiliateCMS\Categories\Repositories\CategoryRepository::class)) {
    $catRepo = new \AffiliateCMS\Categories\Repositories\CategoryRepository();
    $search_categories = $catRepo->search($search_query, 6);
}

// ── Search Brands ──
$search_brands = [];
if ($search_query && class_exists(\AffiliateCMS\Pro\Repositories\BrandRepository::class)) {
    $search_brands = \AffiliateCMS\Pro\Repositories\BrandRepository::instance()->search($search_query, 6);
}

// ── Search Products ──
$search_products = [];
if ($search_query && class_exists(\AffiliateCMS\Pro\Repositories\ProductRepository::class)) {
    $search_products = \AffiliateCMS\Pro\Repositories\ProductRepository::instance()->search($search_query, 8);
}

// ── WP Posts (default query) ──
global $wp_query;
$posts_count = $wp_query->found_posts;

// ── Total results ──
$total_results = count($search_categories) + count($search_brands) + count($search_products) + $posts_count;
$has_any_results = $total_results > 0;

// Affiliate link settings (same resolution as Shortcodes.php)
$acms_general = get_option('acms_general_settings', []);
$affiliate_tag = !empty($acms_general['affiliate_tag']) ? $acms_general['affiliate_tag'] : '';
if (!$affiliate_tag) {
    $affiliate_tag = get_option('acms_paapi_partner_tag', '');
}
if (!$affiliate_tag) {
    $affiliate_tag = get_option('acms_affiliate_tag', '');
}
$custom_url_params = !empty($acms_general['custom_url_params']) ? ltrim($acms_general['custom_url_params'], '&') : 'linkCode=ogi&th=1&psc=1';
?>

<main id="content" class="site-main">
    <!-- Search Results Header -->
    <section class="category-header category-header--minimal">
        <div class="container">
            <div class="category-header__content">
                <?php acms_breadcrumb(); ?>

                <h1 class="category-header__title">
                    <i class="bi bi-search"></i>
                    <?php
                    printf(
                        esc_html__('Search Results for "%s"', 'affiliatecms'),
                        get_search_query()
                    );
                    ?>
                </h1>
                <p class="category-header__count">
                    <?php
                    printf(
                        esc_html(_n('%d result found', '%d results found', $total_results, 'affiliatecms')),
                        $total_results
                    );
                    ?>
                </p>
            </div>
        </div>
    </section>

    <!-- Search Results -->
    <section class="category-content">
        <div class="container">
            <?php if ($has_any_results) : ?>

                <?php
                // ── Categories Section ──
                if (!empty($search_categories)) : ?>
                <div class="search-section">
                    <div class="search-section__header">
                        <h2 class="search-section__title">
                            <i class="bi bi-folder2-open"></i>
                            <?php esc_html_e('Categories', 'affiliatecms'); ?>
                        </h2>
                        <span class="search-section__count"><?php echo count($search_categories); ?></span>
                    </div>
                    <div class="search-chips">
                        <?php foreach ($search_categories as $cat) :
                            $cat_icon = !empty($cat['icon']) ? $cat['icon'] : 'bi-folder';
                            $cat_url = home_url('/c/' . $cat['slug'] . '/');
                            $cat_count = (int) ($cat['product_count'] ?? 0);
                        ?>
                        <a href="<?php echo esc_url($cat_url); ?>" class="search-chip search-chip--category">
                            <i class="bi <?php echo esc_attr($cat_icon); ?>"></i>
                            <span class="search-chip__name"><?php echo esc_html($cat['name']); ?></span>
                            <?php if ($cat_count > 0) : ?>
                            <span class="search-chip__meta"><?php echo esc_html($cat_count); ?></span>
                            <?php endif; ?>
                        </a>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>

                <?php
                // ── Brands Section ──
                if (!empty($search_brands)) : ?>
                <div class="search-section">
                    <div class="search-section__header">
                        <h2 class="search-section__title">
                            <i class="bi bi-award"></i>
                            <?php esc_html_e('Brands', 'affiliatecms'); ?>
                        </h2>
                        <span class="search-section__count"><?php echo count($search_brands); ?></span>
                    </div>
                    <div class="search-chips">
                        <?php foreach ($search_brands as $brand) :
                            $brand_url = home_url('/brand/' . $brand['slug'] . '/');
                            $brand_count = (int) ($brand['product_count'] ?? 0);
                        ?>
                        <a href="<?php echo esc_url($brand_url); ?>" class="search-chip search-chip--brand">
                            <?php if (!empty($brand['logo_url'])) : ?>
                            <img src="<?php echo esc_url($brand['logo_url']); ?>"
                                 alt="<?php echo esc_attr($brand['name']); ?>"
                                 class="search-chip__logo"
                                 loading="lazy">
                            <?php else : ?>
                            <i class="bi bi-building"></i>
                            <?php endif; ?>
                            <span class="search-chip__name"><?php echo esc_html($brand['name']); ?></span>
                            <?php if ($brand_count > 0) : ?>
                            <span class="search-chip__meta"><?php echo esc_html($brand_count); ?> products</span>
                            <?php endif; ?>
                        </a>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>

                <?php
                // ── Products Section ──
                if (!empty($search_products)) :
                    $currency_symbols = ['USD' => '$', 'EUR' => "\u{20AC}", 'GBP' => "\u{00A3}", 'JPY' => "\u{00A5}", 'CAD' => 'CA$', 'AUD' => 'A$'];
                ?>
                <div class="search-section">
                    <div class="search-section__header">
                        <h2 class="search-section__title">
                            <i class="bi bi-box-seam"></i>
                            <?php esc_html_e('Products', 'affiliatecms'); ?>
                        </h2>
                        <span class="search-section__count"><?php echo count($search_products); ?></span>
                    </div>
                    <div class="search-products">
                        <?php foreach ($search_products as $product) :
                            $p_title = $product->customTitle ?: $product->title;
                            $p_price = $product->price;
                            $p_original = $product->originalPrice;
                            $p_currency = $product->currency ?: 'USD';
                            $p_symbol = $currency_symbols[$p_currency] ?? '$';
                            $p_rating = $product->rating ? (float) $product->rating : 0;
                            $p_image = $product->imageUrl ?: '';
                            $p_brand = $product->brand ?: '';
                            $p_asin = $product->asin;
                            $p_prime = $product->isPrime;

                            // Discount
                            $p_discount = 0;
                            if ($p_original && $p_price && $p_original > $p_price) {
                                $p_discount = (int) round((1 - $p_price / $p_original) * 100);
                            }

                            // Affiliate URL (same format as category.php)
                            $p_url = 'https://www.amazon.com/dp/' . urlencode($p_asin) . '?tag=' . urlencode($affiliate_tag) . ($custom_url_params ? '&' . $custom_url_params : '');
                        ?>
                        <a href="<?php echo esc_url($p_url); ?>" class="search-product" target="_blank" rel="nofollow">
                            <div class="search-product__image">
                                <?php if ($p_image) : ?>
                                <img src="<?php echo esc_url($p_image); ?>"
                                     alt="<?php echo esc_attr($p_title); ?>"
                                     loading="lazy">
                                <?php else : ?>
                                <div class="search-product__no-image">
                                    <i class="bi bi-image"></i>
                                </div>
                                <?php endif; ?>
                                <?php if ($p_discount > 0) : ?>
                                <span class="search-product__badge">-<?php echo $p_discount; ?>%</span>
                                <?php endif; ?>
                            </div>
                            <div class="search-product__info">
                                <h3 class="search-product__title"><?php echo esc_html($p_title); ?></h3>
                                <?php if ($p_brand) : ?>
                                <span class="search-product__brand"><?php echo esc_html($p_brand); ?></span>
                                <?php endif; ?>
                                <div class="search-product__footer">
                                    <?php /* Amazon rating removed — violates policy
                                    if ($p_rating > 0) : ?>
                                    <div class="search-product__rating">
                                        <i class="bi bi-star-fill"></i>
                                        <span><?php echo number_format($p_rating, 1); ?></span>
                                    </div>
                                    <?php endif;
                                    */ ?>
                                    <?php if ($p_price) : ?>
                                    <div class="search-product__price">
                                        <span class="search-product__price-current"><?php echo esc_html($p_symbol . number_format($p_price, 2)); ?></span>
                                        <?php if ($p_original && $p_original > $p_price) : ?>
                                        <span class="search-product__price-original"><?php echo esc_html($p_symbol . number_format($p_original, 2)); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <?php endif; ?>
                                    <?php if ($p_prime) : ?>
                                    <span class="search-product__prime">Prime</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </a>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>

                <?php
                // ── Articles (WP Posts) Section ──
                if (have_posts()) :
                    $total_pages = $wp_query->max_num_pages;
                ?>
                <div class="search-section">
                    <div class="search-section__header">
                        <h2 class="search-section__title">
                            <i class="bi bi-newspaper"></i>
                            <?php esc_html_e('Articles', 'affiliatecms'); ?>
                        </h2>
                        <span class="search-section__count"><?php echo esc_html($posts_count); ?></span>
                    </div>
                    <div class="posts-grid-v2 posts-grid-v2--4col" id="posts-container"
                         data-archive-type="search"
                         data-archive-value="<?php echo esc_attr($search_query); ?>"
                         data-total-pages="<?php echo esc_attr($total_pages); ?>"
                         data-total-posts="<?php echo esc_attr($posts_count); ?>">
                        <?php
                        while (have_posts()) {
                            the_post();
                            get_template_part('template-parts/content/post-card', null, [
                                'variant'        => 'grid-v2',
                                'show_category'  => false,
                                'show_indicator' => false,
                                'show_rating'    => false,
                                'show_views'     => false,
                                'footer_cols'    => '2col',
                                'excerpt_words'  => 15,
                            ]);
                        }
                        ?>
                    </div>

                    <?php if ($total_pages > 1) : ?>
                    <div class="load-more">
                        <button type="button" class="load-more__btn" aria-label="<?php esc_attr_e('Load more posts', 'affiliatecms'); ?>">
                            <span class="load-more__text"><?php esc_html_e('Load More', 'affiliatecms'); ?></span>
                            <span class="load-more__loading"><?php esc_html_e('Loading...', 'affiliatecms'); ?></span>
                            <span class="load-more__complete"><?php esc_html_e('All Posts Loaded', 'affiliatecms'); ?></span>
                            <i class="bi bi-arrow-down-circle load-more__icon"></i>
                            <i class="bi bi-arrow-repeat load-more__spinner"></i>
                            <i class="bi bi-check-circle load-more__check"></i>
                        </button>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>

            <?php else : ?>
                <!-- No Results -->
                <div class="no-results">
                    <div class="no-results__icon">
                        <i class="bi bi-search"></i>
                    </div>
                    <h2 class="no-results__title"><?php esc_html_e('No results found', 'affiliatecms'); ?></h2>
                    <p class="no-results__description">
                        <?php esc_html_e('Sorry, no results were found for your search. Try different keywords or browse our categories.', 'affiliatecms'); ?>
                    </p>

                    <!-- Search Form -->
                    <div class="no-results__search">
                        <form class="ai-input" method="get" action="<?php echo esc_url(home_url('/')); ?>">
                            <div class="ai-input__wrapper">
                                <div class="ai-input__icon">
                                    <i class="bi bi-robot"></i>
                                </div>
                                <textarea class="ai-input__field" name="s" placeholder="<?php esc_attr_e('Try a different search...', 'affiliatecms'); ?>" rows="1"><?php echo esc_attr(get_search_query()); ?></textarea>
                                <button type="submit" class="ai-input__send" aria-label="<?php esc_attr_e('Search', 'affiliatecms'); ?>">
                                    <i class="bi bi-send-fill"></i>
                                </button>
                            </div>
                        </form>
                    </div>

                    <!-- Popular Categories (SEO Categories) -->
                    <div class="no-results__categories">
                        <h3><?php esc_html_e('Browse Popular Categories', 'affiliatecms'); ?></h3>
                        <div class="no-results__tags">
                            <?php
                            $popular_categories = [];
                            if (class_exists(\AffiliateCMS\Categories\Repositories\CategoryRepository::class)) {
                                $catRepo = new \AffiliateCMS\Categories\Repositories\CategoryRepository();
                                $popular_categories = $catRepo->getFeatured(6);
                            }

                            if (!empty($popular_categories)) {
                                foreach ($popular_categories as $cat) {
                                    $cat_icon = !empty($cat['icon']) ? $cat['icon'] : 'bi-folder';
                                    printf(
                                        '<a href="%s" class="no-results__tag"><i class="bi %s"></i> %s</a>',
                                        esc_url(home_url('/c/' . $cat['slug'] . '/')),
                                        esc_attr($cat_icon),
                                        esc_html($cat['name'])
                                    );
                                }
                            } else {
                                // Fallback to WP categories
                                $wp_cats = get_categories([
                                    'orderby' => 'count',
                                    'order' => 'DESC',
                                    'number' => 6,
                                ]);
                                foreach ($wp_cats as $cat) {
                                    printf(
                                        '<a href="%s" class="no-results__tag">%s</a>',
                                        esc_url(get_category_link($cat->term_id)),
                                        esc_html($cat->name)
                                    );
                                }
                            }
                            ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </section>
</main>

<?php
get_footer();
