/**
 * Category Live Search
 * Debounced autocomplete for 2500+ categories
 * Supports multiple search instances (header modal + hero section)
 * Features: skeleton loading, keyboard navigation, staggered animations
 */

class CategorySearchInstance {
    constructor(inputId, dropdownId, cssClass) {
        console.log('[ACMS Search] constructor called for:', inputId);
        this.input = document.getElementById(inputId);
        if (!this.input) {
            console.log('[ACMS Search] input not found:', inputId);
            return;
        }
        console.log('[ACMS Search] input found, binding events');

        this.dropdown = document.getElementById(dropdownId);
        this.cssClass = cssClass; // 'search-modal' or 'hero-search'
        this.loading = this.dropdown?.querySelector(`.${cssClass}__loading`);
        this.results = this.dropdown?.querySelector(`.${cssClass}__results`);
        this.noResults = this.dropdown?.querySelector(`.${cssClass}__no-results`);
        this.footer = this.dropdown?.querySelector(`.${cssClass}__footer`);
        this.searchTimeout = null;
        this.currentQuery = '';
        this.activeIndex = -1;
        this.MIN_QUERY_LENGTH = 2;
        this.DEBOUNCE_DELAY = 300;
        this.LIMIT = 10;

        this.bindEvents();
        this.bindPromptButtons();
    }

    bindEvents() {
        // Input event with debounce
        this.input.addEventListener('input', () => {
            clearTimeout(this.searchTimeout);
            this.searchTimeout = setTimeout(() => this.handleInput(), this.DEBOUNCE_DELAY);
        });

        // Keyboard navigation
        this.input.addEventListener('keydown', (e) => {
            const items = this.getResultItems();

            switch (e.key) {
                case 'ArrowDown':
                    e.preventDefault();
                    this.setActiveIndex(Math.min(this.activeIndex + 1, items.length - 1));
                    break;

                case 'ArrowUp':
                    e.preventDefault();
                    this.setActiveIndex(Math.max(this.activeIndex - 1, -1));
                    break;

                case 'Enter':
                    e.preventDefault();
                    if (this.activeIndex >= 0 && items[this.activeIndex]) {
                        window.location.href = items[this.activeIndex].href;
                    } else {
                        const firstLink = this.results?.querySelector('a');
                        if (firstLink) window.location.href = firstLink.href;
                    }
                    break;

                case 'Escape':
                    this.hideDropdown();
                    this.input.blur();
                    break;
            }
        });

        // Click outside to close
        document.addEventListener('click', (e) => {
            const container = this.cssClass === 'search-modal'
                ? e.target.closest('.search-modal__form')
                : e.target.closest('.hero-search');

            if (!container) {
                this.hideDropdown();
            }
        });
    }

    bindPromptButtons() {
        const container = this.cssClass === 'search-modal'
            ? document.querySelector('.search-modal')
            : document.querySelector('.hero-search');

        if (!container) return;

        const promptButtons = container.querySelectorAll('.ai-input__prompt');
        promptButtons.forEach(button => {
            button.addEventListener('click', () => {
                const promptText = button.textContent.trim();
                this.input.value = promptText;
                this.input.focus();
                this.handleInput();
            });
        });
    }

    handleInput() {
        const query = this.input.value.trim();

        if (query.length < this.MIN_QUERY_LENGTH) {
            this.hideDropdown();
            return;
        }

        if (query === this.currentQuery) return;
        this.currentQuery = query;

        this.search(query);
    }

    async search(query) {
        // Derive REST base: prefer restBase, else extract /wp-json/ from restUrl
        let restBase = window.acmsData?.restBase;
        if (!restBase) {
            const restUrl = window.acmsData?.restUrl || '';
            const idx = restUrl.indexOf('/wp-json/');
            restBase = idx !== -1 ? restUrl.substring(0, idx + 9) : '/wp-json/';
        }

        this.showLoading();

        try {
            const url = `${restBase}acms-cat/v1/categories/search?q=${encodeURIComponent(query)}&limit=${this.LIMIT}`;
            const response = await fetch(url);
            const data = await response.json();

            if (data.success && data.data && data.data.length > 0) {
                this.showResults(data.data);
            } else {
                this.showNoResults();
            }
        } catch (error) {
            console.error('Category search error:', error);
            this.hideDropdown();
        }
    }

    showLoading() {
        if (!this.dropdown) return;

        this.dropdown.style.display = 'block';
        if (this.loading) this.loading.style.display = 'flex';
        if (this.results) this.results.style.display = 'none';
        if (this.noResults) this.noResults.style.display = 'none';
        if (this.footer) this.footer.style.display = 'none';
        this.input.setAttribute('aria-expanded', 'true');
    }

    showResults(categories) {
        if (!this.results) return;

        const html = categories.map(cat => `
            <a href="${cat.url}" class="${this.cssClass}__result" role="option">
                <div class="${this.cssClass}__result-main">
                    <span class="${this.cssClass}__result-icon">
                        <i class="bi ${cat.icon || 'bi-folder2'}"></i>
                    </span>
                    <div class="${this.cssClass}__result-info">
                        <div class="${this.cssClass}__result-title">${this.escapeHtml(cat.name)}</div>
                        <div class="${this.cssClass}__result-breadcrumb">${this.escapeHtml(cat.breadcrumb_path)}</div>
                    </div>
                </div>
                <span class="${this.cssClass}__result-count">${cat.product_count}</span>
            </a>
        `).join('');

        this.results.innerHTML = html;
        this.activeIndex = -1;
        this.dropdown.style.display = 'block';
        if (this.loading) this.loading.style.display = 'none';
        this.results.style.display = 'block';
        if (this.noResults) this.noResults.style.display = 'none';
        if (this.footer) this.footer.style.display = 'flex';
        this.input.setAttribute('aria-expanded', 'true');

        // Bind hover to sync activeIndex
        this.getResultItems().forEach((item, i) => {
            item.addEventListener('mouseenter', () => this.setActiveIndex(i, false));
            item.addEventListener('mouseleave', () => this.setActiveIndex(-1, false));
        });
    }

    showNoResults() {
        if (!this.dropdown) return;

        this.dropdown.style.display = 'block';
        if (this.loading) this.loading.style.display = 'none';
        if (this.results) this.results.style.display = 'none';
        if (this.noResults) this.noResults.style.display = 'flex';
        if (this.footer) this.footer.style.display = 'none';
        this.input.setAttribute('aria-expanded', 'true');
    }

    hideDropdown() {
        if (!this.dropdown) return;

        this.dropdown.style.display = 'none';
        this.input.setAttribute('aria-expanded', 'false');
        this.currentQuery = '';
        this.activeIndex = -1;
    }

    getResultItems() {
        return this.results ? Array.from(this.results.querySelectorAll(`.${this.cssClass}__result`)) : [];
    }

    setActiveIndex(index, scroll = true) {
        const items = this.getResultItems();

        // Remove previous active
        items.forEach(item => item.classList.remove('is-active'));

        this.activeIndex = index;

        if (index >= 0 && items[index]) {
            items[index].classList.add('is-active');
            if (scroll) {
                items[index].scrollIntoView({ block: 'nearest' });
            }
        }
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

// Initialize both search instances when DOM is ready
const initCategorySearch = () => {
    console.log('[ACMS Search] initCategorySearch called');
    // Header modal search
    new CategorySearchInstance('category-search-input', 'search-results', 'search-modal');

    // Hero section search
    new CategorySearchInstance('hero-search-input', 'hero-search-results', 'hero-search');
    console.log('[ACMS Search] instances created');
};

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initCategorySearch);
} else {
    initCategorySearch();
}
