/**
 * Deals Page - Category Filtering & Load More
 * Uses WordPress REST API
 *
 * @package AffiliateCMS
 * @since 4.0.0
 */

// Alpine.js Store for deals page global state
document.addEventListener('alpine:init', () => {
    Alpine.store('dealsPage', {
        totalProducts: 0,
        selectedCategoryId: 0,
    });
});

/**
 * Alpine.js Component: dealsPage
 * Handles category filtering and load more functionality via REST API
 */
window.dealsPage = function () {
    const dealsData = window.acmsDealsData || {};
    // Cast IDs to integers for strict comparison
    const cats = (dealsData.categories || []).map(c => ({
        ...c,
        id: parseInt(c.id) || 0,
        deal_count: parseInt(c.deal_count) || 0,
    }));
    return {
        // Data
        categories: cats,
        selectedCategoryId: parseInt(dealsData.initialCategoryId) || 0,
        isLoading: false,
        totalProducts: 0,
        filterOpen: false,

        // DOM refs (will be set in init)
        container: null,
        button: null,
        offset: 0,
        perPage: 24,

        /**
         * Initialize component
         */
        init() {
            // Get DOM elements
            this.container = document.getElementById('dealsProductsList');
            this.button = document.getElementById('dealsLoadMore');

            if (!this.container) {
                console.error('Deals container not found');
                return;
            }

            // Read initial data
            this.offset = parseInt(this.container.dataset.offset) || 24;
            this.perPage = parseInt(this.container.dataset.perPage) || 24;
            this.totalProducts = parseInt(this.container.dataset.total) || 0;

            // Update Alpine store
            Alpine.store('dealsPage').totalProducts = this.totalProducts;
            Alpine.store('dealsPage').selectedCategoryId = this.selectedCategoryId;

            // Bind load more button
            if (this.button) {
                this.button.addEventListener('click', () => this.loadMore());
            }
        },

        /**
         * Get REST API URL
         */
        getApiUrl() {
            // Derive REST base for cross-namespace API calls
            if (window.acmsData?.restBase) return window.acmsData.restBase;
            const restUrl = window.acmsData?.restUrl || '';
            const idx = restUrl.indexOf('/wp-json/');
            return idx !== -1 ? restUrl.substring(0, idx + 9) : '/wp-json/';
        },

        /**
         * Filter by category
         * @param {number} categoryId - Category ID (0 for all)
         */
        async filterByCategory(categoryId) {
            if (this.selectedCategoryId === categoryId || this.isLoading) {
                return;
            }

            this.selectedCategoryId = categoryId;
            Alpine.store('dealsPage').selectedCategoryId = categoryId;

            // Reset pagination
            this.offset = 0;

            // Show loading
            this.isLoading = true;

            try {
                // Build REST API URL
                const apiUrl = this.getApiUrl();
                const params = new URLSearchParams({
                    category_id: categoryId,
                    offset: 0,
                    per_page: this.perPage,
                });

                const response = await fetch(`${apiUrl}acms/v1/deals?${params}`, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                });

                if (!response.ok) {
                    throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                }

                const data = await response.json();

                if (data.success) {
                    // Update total count
                    this.totalProducts = data.data.total_count || 0;
                    Alpine.store('dealsPage').totalProducts = this.totalProducts;

                    // Replace products HTML
                    if (this.container) {
                        this.container.innerHTML = data.data.html;
                        this.container.dataset.total = this.totalProducts;
                        this.container.dataset.category = categoryId;
                    }

                    // Update offset
                    this.offset = data.data.new_offset || this.perPage;
                    if (this.container) {
                        this.container.dataset.offset = this.offset;
                    }

                    // Update load more button
                    if (this.button) {
                        if (data.data.has_more) {
                            this.button.classList.remove('is-complete');
                            this.button.disabled = false;
                        } else {
                            this.button.classList.add('is-complete');
                            this.button.disabled = true;
                        }
                    }

                    // Scroll to top of products
                    this.container?.scrollIntoView({ behavior: 'smooth', block: 'start' });
                } else {
                    console.error('Filter error:', data.message);
                }
            } catch (error) {
                console.error('Filter failed:', error);
            } finally {
                this.isLoading = false;
            }
        },

        /**
         * Load more products (pagination)
         */
        async loadMore() {
            if (this.isLoading || !this.button) return;

            this.isLoading = true;
            this.button.classList.add('is-loading');

            try {
                // Build REST API URL
                const apiUrl = this.getApiUrl();
                const params = new URLSearchParams({
                    category_id: this.selectedCategoryId,
                    offset: this.offset,
                    per_page: this.perPage,
                });

                const response = await fetch(`${apiUrl}acms/v1/deals?${params}`, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                });

                if (!response.ok) {
                    throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                }

                const data = await response.json();

                if (data.success) {
                    // Insert new products HTML
                    if (data.data.html) {
                        // Get the list container (acms-list div)
                        const listContainer = this.container?.querySelector('.acms-list');
                        if (listContainer) {
                            // Create temporary div to parse new HTML
                            const tempDiv = document.createElement('div');
                            tempDiv.innerHTML = data.data.html;

                            // Get new product items
                            const newItems = tempDiv.querySelectorAll('.acms-list__item');

                            // Append each new item to the existing list
                            newItems.forEach(item => {
                                listContainer.appendChild(item);
                            });
                        }
                    }

                    // Update offset
                    this.offset = data.data.new_offset;
                    if (this.container) {
                        this.container.dataset.offset = this.offset;
                    }

                    // Check if there are more products
                    if (!data.data.has_more) {
                        this.button.classList.add('is-complete');
                        this.button.disabled = true;
                    }
                } else {
                    console.error('Load more error:', data.message);
                }
            } catch (error) {
                console.error('Load more failed:', error);
            } finally {
                this.isLoading = false;
                this.button.classList.remove('is-loading');
            }
        },
    };
};
