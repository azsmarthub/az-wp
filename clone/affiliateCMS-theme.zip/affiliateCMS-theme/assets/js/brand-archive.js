/**
 * Brand Archive - Load More Products (REST API)
 *
 * @package AffiliateCMS
 * @since 4.0.0
 */

(function() {
    'use strict';

    const brandLoadMore = {
        init() {
            this.container = document.getElementById('brandProductsList');
            this.button = document.getElementById('brandLoadMore');

            if (!this.container || !this.button) {
                return;
            }

            this.brand = this.container.dataset.brand;
            this.offset = parseInt(this.container.dataset.offset) || 12;
            this.perPage = parseInt(this.container.dataset.perPage) || 12;
            this.total = parseInt(this.container.dataset.total) || 0;
            this.loading = false;

            this.bindEvents();
        },

        bindEvents() {
            this.button.addEventListener('click', () => this.loadMore());
        },

        async loadMore() {
            if (this.loading) return;

            this.loading = true;
            this.button.classList.add('is-loading');

            try {
                const params = new URLSearchParams({
                    offset: this.offset,
                    per_page: this.perPage,
                });

                const response = await fetch(
                    acmsBrandConfig.restUrl + 'brands/' + encodeURIComponent(this.brand) + '/products?' + params,
                    {
                        method: 'GET',
                        headers: { 'X-WP-Nonce': acmsBrandConfig.nonce },
                    }
                );

                const data = await response.json();

                if (response.ok) {
                    // Insert new products HTML
                    if (data.html) {
                        const listContainer = this.container.querySelector('.acms-list');
                        if (listContainer) {
                            const tempDiv = document.createElement('div');
                            tempDiv.innerHTML = data.html;

                            const newItems = tempDiv.querySelectorAll('.acms-list__item');
                            newItems.forEach(item => {
                                listContainer.appendChild(item);
                            });
                        }
                    }

                    // Update offset
                    this.offset = data.new_offset;
                    this.container.dataset.offset = this.offset;

                    // Check if there are more products
                    if (!data.has_more) {
                        this.button.classList.add('is-complete');
                        this.button.disabled = true;
                    }
                } else {
                    console.error('Load more error:', data.message);
                }
            } catch (error) {
                console.error('Load more failed:', error);
            } finally {
                this.loading = false;
                this.button.classList.remove('is-loading');
            }
        },
    };

    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => brandLoadMore.init());
    } else {
        brandLoadMore.init();
    }
})();
