/**
 * Theme Toggle Module - AffiliateCMS
 * Dark/Light Mode Switching
 */

import { $$, on, storage } from './utils.js';

const STORAGE_KEY = 'acms-theme';
const DARK = 'dark';
const LIGHT = 'light';

/**
 * Set theme on document
 */
function setTheme(theme, save = true) {
    document.documentElement.setAttribute('data-theme', theme);
    if (save) {
        storage.set(STORAGE_KEY, theme);
    }
}

/**
 * Toggle between dark and light
 */
function toggle() {
    const current = document.documentElement.getAttribute('data-theme');
    const next = current === DARK ? LIGHT : DARK;
    setTheme(next, true);
}

/**
 * Initialize theme toggle
 */
export function init() {
    // Set initial theme
    const savedTheme = storage.get(STORAGE_KEY);
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    const theme = savedTheme || (prefersDark ? DARK : LIGHT);

    setTheme(theme, false);

    // Bind toggle buttons
    $$('[data-theme-toggle]').forEach(btn => {
        on(btn, 'click', () => toggle());
    });

    // Listen for system preference changes
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', e => {
        if (!storage.get(STORAGE_KEY)) {
            setTheme(e.matches ? DARK : LIGHT, false);
        }
    });
}

export default { init };
