<?php
/**
 * The header template
 *
 * @package AffiliateCMS
 * @since 4.0.0
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script>
    // Set theme early to prevent flash of wrong theme
    (function() {
        var theme = localStorage.getItem('acms-theme');
        if (!theme) {
            theme = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
        }
        document.documentElement.setAttribute('data-theme', theme);
    })();
    </script>
    <?php wp_head(); ?>
	    <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-54X8F3XC');</script>
<!-- End Google Tag Manager -->
</head>
<body <?php body_class(); ?>>
	    <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-54X8F3XC"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<!-- THEME: affiliateCMS v1.0 -->
<?php wp_body_open(); ?>

    <!-- Skip Link -->
    <a class="skip-link" href="#content"><?php esc_html_e('Skip to content', 'affiliatecms'); ?></a>

    <?php
    // Site Header (includes inline navigation)
    get_template_part('template-parts/header/site-header');

    // Mobile Navigation
    get_template_part('template-parts/header/nav-mobile');

    // Search Modal
    get_template_part('template-parts/header/search-modal');

    // Affiliate Disclosure (hardcoded from config.php, 0 queries)
    if (ACMS_DISCLOSURE_SHOW && ACMS_DISCLOSURE_TEXT) : ?>
        <style>
            @media (max-width: 768px) {
                .post-disclosure { padding: var(--space-2) var(--space-3) !important; }
                .post-disclosure__main { justify-content: center !important; text-align: center !important; }
                .post-disclosure__icon { display: none !important; }
                .post-disclosure__text { text-align: center !important; }
            }
        </style>
        <div class="post-disclosure">
            <div class="container">
                <div class="post-disclosure__main">
                    <svg class="post-disclosure__icon" width="16" height="16" fill="currentColor" viewBox="0 0 16 16" aria-hidden="true">
                        <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                        <path d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
                    </svg>
                    <p class="post-disclosure__text">
                        <?php echo esc_html(ACMS_DISCLOSURE_TEXT); ?>
                        <?php if (ACMS_DISCLOSURE_LINK_URL) : ?>
                            <a href="<?php echo esc_url(ACMS_DISCLOSURE_LINK_URL); ?>" class="post-disclosure__link" rel="nofollow"><?php echo esc_html(ACMS_DISCLOSURE_LINK_TEXT); ?> &rsaquo;</a>
                        <?php endif; ?>
                    </p>
                </div>
            </div>
        </div>
    <?php endif; ?>
