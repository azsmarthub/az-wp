<?php
/**
 * AffiliateCMS - Theme Functions
 *
 * A standalone WordPress theme for affiliate marketing.
 *
 * @package AffiliateCMS
 * @since 1.0.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Theme constants
if (!defined('ACMS_VERSION')) {
    define('ACMS_VERSION', '1.1.4');
}
if (!defined('ACMS_DIR')) {
    define('ACMS_DIR', get_template_directory());
}
if (!defined('ACMS_URI')) {
    define('ACMS_URI', get_template_directory_uri());
}

/**
 * Include required files
 */
require_once ACMS_DIR . '/inc/config.php'; // Hardcoded settings (no DB queries)
require_once ACMS_DIR . '/inc/setup.php';
require_once ACMS_DIR . '/inc/enqueue.php';
require_once ACMS_DIR . '/inc/template-functions.php';
require_once ACMS_DIR . '/inc/template-tags.php';
require_once ACMS_DIR . '/inc/walker-nav.php';
require_once ACMS_DIR . '/inc/widgets.php';
require_once ACMS_DIR . '/inc/customizer.php';
require_once ACMS_DIR . '/inc/rest-api.php';
require_once ACMS_DIR . '/inc/brand-ajax.php';
require_once ACMS_DIR . '/inc/deals-rest-api.php';
require_once ACMS_DIR . '/inc/link-tracking-filter.php'; // Settings now in Pro plugin modal

// Comments Module (OOP structure)
require_once ACMS_DIR . '/inc/comments/class-comments.php';

/**
 * Initialize Comments Module
 */
function acms_init_comments() {
    \AffiliateCMS\Comments\Comments::instance();
}
add_action('after_setup_theme', 'acms_init_comments');

// TOC Expandable Module
require_once ACMS_DIR . '/inc/toc-expandable/init.php';

// SEO Module (replaces SEO plugins - 0 external dependencies)
require_once ACMS_DIR . '/inc/seo/class-seo.php';

/**
 * Initialize SEO Module
 */
function acms_init_seo() {
    \AffiliateCMS\SEO\SEO::instance();
}
add_action('after_setup_theme', 'acms_init_seo');

/**
 * Flush rewrite rules for sitemap on theme activation
 */
function acms_activate_theme() {
    \AffiliateCMS\SEO\Sitemap::flushRules();
}
add_action('after_switch_theme', 'acms_activate_theme');

/**
 * Remove /category/ base from URLs
 *
 * Strategy: Keep default category_base ('category') for rewrite rules stability,
 * but strip '/category/' from output links and resolve clean URLs via request filter.
 */

// 1. Strip /category/ from all category links output
add_filter('category_link', function ($link) {
    return str_replace('/category/', '/', $link);
});

// 2. Rewrite query vars BEFORE parse_query — convert post-slug to category if matching
add_filter('request', function ($query_vars) {
    // Only act if WP resolved URL as a post name
    if (empty($query_vars['name']) || is_admin()) {
        return $query_vars;
    }

    $name = $query_vars['name'];

    // Check if this slug is a known category
    $term = get_term_by('slug', $name, 'category');
    if (!$term || is_wp_error($term)) {
        return $query_vars;
    }

    // Check if a real published post/page with this slug exists (posts take priority)
    global $wpdb;
    $post_exists = $wpdb->get_var($wpdb->prepare(
        "SELECT ID FROM {$wpdb->posts} WHERE post_name = %s AND post_status = 'publish' AND post_type IN ('post','page') LIMIT 1",
        $name
    ));
    if ($post_exists) {
        return $query_vars;
    }

    // Replace post query with category query (parse_query will set correct flags)
    unset($query_vars['name'], $query_vars['page']);
    $query_vars['category_name'] = $name;

    return $query_vars;
});

// 3. 301 redirect old /category/* URLs to clean URLs
add_action('template_redirect', function () {
    if (!is_category()) {
        return;
    }
    $uri = $_SERVER['REQUEST_URI'];
    if (strpos($uri, '/category/') === 0) {
        $new_url = preg_replace('#^/category/#', '/', $uri);
        wp_redirect(home_url($new_url), 301);
        exit;
    }
});

// User profile fields (needed for both admin and frontend helpers)
require_once ACMS_DIR . '/inc/admin-user-fields.php';

// Admin only
if (is_admin()) {
    require_once ACMS_DIR . '/inc/admin-menu-help.php';
    require_once ACMS_DIR . '/inc/admin-category-fields.php';
}
