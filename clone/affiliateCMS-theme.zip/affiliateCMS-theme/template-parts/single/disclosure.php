<?php
/**
 * Affiliate Disclosure Alert
 *
 * Displayed above post content. Configurable via Plugin Settings > Display > Post Disclosure.
 *
 * @package AffiliateCMS
 * @since 4.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

// Using hardcoded config (0 DB queries)
$disclosure_text = ACMS_DISCLOSURE_TEXT;
$link_url = ACMS_DISCLOSURE_LINK_URL;
$link_text = ACMS_DISCLOSURE_LINK_TEXT;

if (!$disclosure_text) {
    return;
}
?>

<div class="post-disclosure">
    <div class="container">
        <div class="post-disclosure__main">
            <i class="bi bi-info-circle post-disclosure__icon"></i>
            <p class="post-disclosure__text">
                <?php echo esc_html($disclosure_text); ?>
                <?php if ($link_url) : ?>
                    <a href="<?php echo esc_url($link_url); ?>" class="post-disclosure__link" rel="nofollow"><?php echo esc_html($link_text); ?> &rsaquo;</a>
                <?php endif; ?>
            </p>
        </div>
    </div>
</div>
