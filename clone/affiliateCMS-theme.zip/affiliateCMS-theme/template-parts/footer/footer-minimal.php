<?php
/**
 * Template Part: Footer (2-Column Layout)
 *
 * Fully hardcoded from config.php — 0 DB queries.
 *
 * @package AffiliateCMS
 * @since 4.0.0
 */

$footer_description = ACMS_FOOTER_DESCRIPTION;
$social_links = acms_get_social_links_config();
$site_name = ACMS_SITE_NAME;
$logo_url = defined('ACMS_HEADER_LOGO_URL') ? ACMS_HEADER_LOGO_URL : '';
?>

<footer class="site-footer">
    <div class="container">
        <!-- Main 2-Column Section -->
        <div class="footer__main">
            <!-- Left: Logo + Description -->
            <div class="footer__brand">
                <a href="<?php echo esc_url(home_url('/')); ?>" class="footer__logo" title="<?php echo esc_attr($site_name); ?>">
                    <?php if ($logo_url) : ?>
                        <img class="footer__logo-img" src="<?php echo esc_url($logo_url); ?>" width="152" height="37" alt="<?php echo esc_attr($site_name); ?>">
                    <?php else : ?>
                        <span class="footer__logo-text"><?php echo esc_html($site_name); ?></span>
                    <?php endif; ?>
                </a>
                <?php if ($footer_description) : ?>
                    <p class="footer__description"><?php echo esc_html($footer_description); ?></p>
                <?php endif; ?>
            </div>

            <!-- Right: Social -->
            <div class="footer__info">
                <?php if (!empty($social_links)) : ?>
                    <div class="footer__social">
                        <?php foreach ($social_links as $network => $data) : ?>
                            <a href="<?php echo esc_url($data['url']); ?>" class="footer__social-link" aria-label="<?php echo esc_attr($data['label']); ?>" target="_blank" rel="nofollow">
                                <i class="bi <?php echo esc_attr($data['icon']); ?>"></i>
                            </a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Bottom: Links + Copyright -->
        <div class="footer__bottom">
            <nav class="footer__links">
                <?php foreach (ACMS_FOOTER_POLICY_LINKS as $link) : ?>
                    <a href="<?php echo esc_url(home_url($link['url'])); ?>" class="footer__link"><?php echo esc_html($link['text']); ?></a>
                <?php endforeach; ?>
            </nav>
            <p class="footer__copyright"><?php echo wp_kses_post(acms_get_copyright_config()); ?></p>
        </div>
    </div>
</footer>
