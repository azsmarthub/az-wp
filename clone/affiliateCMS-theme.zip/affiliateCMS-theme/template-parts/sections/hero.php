<?php
/**
 * Template Part: Hero Section
 *
 * Hardcoded content from config.php for maximum performance (0 queries).
 *
 * @package AffiliateCMS
 * @since 4.0.0
 */

$hero_badge       = ACMS_HERO_BADGE;
$hero_title       = ACMS_HERO_TITLE;
$hero_description = ACMS_HERO_DESCRIPTION;
$hero_placeholder = ACMS_HERO_PLACEHOLDER;
$hero_tags_label  = ACMS_HERO_TAGS_LABEL;
$hero_tags        = ACMS_HERO_TAGS;
$hero_stats       = ACMS_HERO_STATS;

// Auto-count posts if stat number is empty
foreach ($hero_stats as &$stat) {
    if ($stat['number'] === '') {
        $stat['number'] = wp_count_posts()->publish . '+';
    }
}
unset($stat);

// Popular categories for quick-search suggestions (1 cached query)
$popular_categories = [];
if (class_exists(\AffiliateCMS\Categories\Repositories\CategoryRepository::class)) {
    $popular_categories = wp_cache_get('acms_popular_cats_hero', 'acms_categories');
    if ($popular_categories === false) {
        global $wpdb;
        $cat_table = $wpdb->prefix . 'acms_categories';
        $popular_categories = $wpdb->get_results(
            "SELECT name, slug, icon, product_count
             FROM {$cat_table}
             WHERE status = 'publish' AND product_count > 0 AND parent_id > 0
             ORDER BY product_count DESC
             LIMIT 6",
            ARRAY_A
        ) ?: [];
        wp_cache_set('acms_popular_cats_hero', $popular_categories, 'acms_categories', 3600);
    }
}
?>

<section class="hero">
    <div class="hero__background">
        <div class="hero__gradient"></div>
        <div class="hero__pattern"></div>
    </div>
    <div class="container">
        <div class="hero__content">
            <!-- Trust Badge -->
            <?php if ($hero_badge) : ?>
                <div class="hero__badge">
                    <i class="bi bi-patch-check-fill"></i>
                    <span><?php echo esc_html($hero_badge); ?></span>
                </div>
            <?php endif; ?>

            <!-- Main Title -->
            <h1 class="hero__title">
                <?php echo wp_kses_post($hero_title); ?>
            </h1>

            <!-- Description -->
            <?php if ($hero_description) : ?>
                <p class="hero__description">
                    <?php echo esc_html($hero_description); ?>
                </p>
            <?php endif; ?>

            <!-- Top Rated Categories -->
            <?php if (!empty($hero_tags)) : ?>
            <div class="hero__categories">
                <?php if ($hero_tags_label) : ?>
                    <span class="hero__categories-label"><?php echo esc_html($hero_tags_label); ?></span>
                <?php endif; ?>
                <div class="hero__categories-list">
                    <?php foreach ($hero_tags as $tag) : ?>
                        <a href="<?php echo esc_url(home_url($tag['url'])); ?>" class="hero__category-tag"><?php echo esc_html($tag['name']); ?></a>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

            <!-- Category Search -->
            <div class="hero__ai-search">
                <div class="hero-search">
                    <div class="ai-input__wrapper">
                        <div class="ai-input__icon">
                            <i class="bi bi-search"></i>
                        </div>
                        <input
                            type="search"
                            class="ai-input__field"
                            id="hero-search-input"
                            placeholder="<?php echo esc_attr($hero_placeholder); ?>"
                            aria-label="<?php esc_attr_e('Search categories', 'affiliatecms'); ?>"
                            autocomplete="off"
                            spellcheck="false"
                            aria-expanded="false"
                            aria-controls="hero-search-results"
                        >
                        <kbd class="ai-input__shortcut">ESC</kbd>
                    </div>

                    <!-- Dropdown Results -->
                    <div class="hero-search__dropdown" id="hero-search-results" role="listbox" style="display: none;">
                        <!-- Loading State — Skeleton shimmer -->
                        <div class="hero-search__loading" style="display: none;">
                            <div class="hero-search__loading-item">
                                <div class="hero-search__loading-icon"></div>
                                <div class="hero-search__loading-lines">
                                    <div class="hero-search__loading-line"></div>
                                    <div class="hero-search__loading-line hero-search__loading-line--short"></div>
                                </div>
                            </div>
                            <div class="hero-search__loading-item">
                                <div class="hero-search__loading-icon"></div>
                                <div class="hero-search__loading-lines">
                                    <div class="hero-search__loading-line"></div>
                                    <div class="hero-search__loading-line hero-search__loading-line--short"></div>
                                </div>
                            </div>
                            <div class="hero-search__loading-item">
                                <div class="hero-search__loading-icon"></div>
                                <div class="hero-search__loading-lines">
                                    <div class="hero-search__loading-line"></div>
                                    <div class="hero-search__loading-line hero-search__loading-line--short"></div>
                                </div>
                            </div>
                        </div>

                        <!-- Results List -->
                        <div class="hero-search__results" style="display: none;">
                            <!-- Populated by JS -->
                        </div>

                        <!-- No Results -->
                        <div class="hero-search__no-results" style="display: none;">
                            <i class="bi bi-search"></i>
                            <p><?php esc_html_e('No categories found for your search', 'affiliatecms'); ?></p>
                        </div>

                        <!-- Footer hints -->
                        <div class="hero-search__footer">
                            <span class="hero-search__footer-item"><kbd><i class="bi bi-arrow-return-left"></i></kbd> open</span>
                            <span class="hero-search__footer-item"><kbd><i class="bi bi-arrow-up"></i></kbd><kbd><i class="bi bi-arrow-down"></i></kbd> navigate</span>
                            <span class="hero-search__footer-item"><kbd>esc</kbd> close</span>
                        </div>
                    </div>

                    <!-- Popular categories as quick suggestions -->
                    <?php if (!empty($popular_categories)) : ?>
                    <div class="ai-input__prompts">
                        <span class="ai-input__prompts-label"><?php esc_html_e('Popular:', 'affiliatecms'); ?></span>
                        <?php foreach ($popular_categories as $pcat) : ?>
                            <a href="<?php echo esc_url(home_url('/c/' . $pcat['slug'] . '/')); ?>" class="ai-input__prompt">
                                <i class="bi <?php echo esc_attr($pcat['icon'] ?: 'bi-folder2'); ?>"></i>
                                <?php echo esc_html($pcat['name']); ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>
