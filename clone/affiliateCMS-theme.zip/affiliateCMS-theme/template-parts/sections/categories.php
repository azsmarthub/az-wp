<?php
/**
 * Template Part: Categories Section
 *
 * Displays featured SEO categories from acms_categories table.
 * Falls back to hardcoded config if plugin not active.
 *
 * @package AffiliateCMS
 * @since 4.0.0
 */

$cat_badge    = ACMS_CAT_BADGE;
$cat_title    = ACMS_CAT_TITLE;
$cat_subtitle = ACMS_CAT_SUBTITLE;
$cat_cta_text = ACMS_CAT_CTA_TEXT;
$cat_cta_url  = ACMS_CAT_CTA_URL;

// Load featured categories from DB, fallback to hardcoded config
$cat_items = [];
if (class_exists(\AffiliateCMS\Categories\Repositories\CategoryRepository::class)) {
    $catRepo = new \AffiliateCMS\Categories\Repositories\CategoryRepository();
    $featured = $catRepo->getFeatured((int) ACMS_CAT_COUNT);

    foreach ($featured as $fc) {
        $cat_items[] = [
            'name'  => $fc['name'],
            'icon'  => $fc['icon'] ?: 'bi-folder',
            'count' => (int) ($fc['product_count'] ?? 0),
            'url'   => '/c/' . $fc['slug'] . '/',
        ];
    }
}

// Fallback to hardcoded config if no featured categories
if (empty($cat_items)) {
    $cat_items = ACMS_CAT_ITEMS;
}
?>

<section class="section categories-section">
    <div class="container">
        <div class="section__header section__header--center">
            <?php if ($cat_badge) : ?>
                <span class="section__badge"><?php echo esc_html($cat_badge); ?></span>
            <?php endif; ?>
            <?php if ($cat_title) : ?>
                <h2 class="section__title"><?php echo esc_html($cat_title); ?></h2>
            <?php endif; ?>
            <?php if ($cat_subtitle) : ?>
                <p class="section__subtitle"><?php echo esc_html($cat_subtitle); ?></p>
            <?php endif; ?>
        </div>

        <div class="categories-grid">
            <?php foreach ($cat_items as $cat) : ?>
                <a href="<?php echo esc_url(home_url($cat['url'])); ?>" class="category-card">
                    <div class="category-card__image">
                        <div class="category-card__placeholder">
                            <i class="bi <?php echo esc_attr($cat['icon']); ?>"></i>
                        </div>
                    </div>
                    <div class="category-card__content">
                        <h3 class="category-card__title"><?php echo esc_html($cat['name']); ?></h3>
                        <span class="category-card__count"><?php echo esc_html($cat['count']); ?> Products</span>
                    </div>
                    <div class="category-card__arrow">
                        <i class="bi bi-arrow-right"></i>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>

        <?php if ($cat_cta_text && $cat_cta_url) : ?>
        <div class="categories-section__footer">
            <a href="<?php echo esc_url(home_url($cat_cta_url)); ?>" class="btn btn--outline btn--lg">
                <i class="bi bi-tags-fill"></i>
                <?php echo esc_html($cat_cta_text); ?>
            </a>
        </div>
        <?php endif; ?>
    </div>
</section>
