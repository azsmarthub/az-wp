<?php
/**
 * Template Part: About Section (Hero Style)
 *
 * Hardcoded content from config.php for maximum performance (0 queries).
 *
 * @package AffiliateCMS
 * @since 4.0.0
 */

$about_badge        = ACMS_ABOUT_BADGE;
$about_title_prefix = ACMS_ABOUT_TITLE_PREFIX;
$about_tagline      = ACMS_ABOUT_TAGLINE;
$about_description  = ACMS_ABOUT_DESCRIPTION;
$about_cta1_text    = ACMS_ABOUT_CTA1_TEXT;
$about_cta1_url     = ACMS_ABOUT_CTA1_URL;
$about_cta2_text    = ACMS_ABOUT_CTA2_TEXT;
$about_cta2_url     = ACMS_ABOUT_CTA2_URL;
$about_trust_items  = ACMS_ABOUT_TRUST_ITEMS;
$about_stats        = ACMS_ABOUT_STATS;

// Auto-count if stat number is empty
foreach ($about_stats as &$stat) {
    if ($stat['number'] === '' && $stat['label'] === 'Expert Reviews') {
        $stat['number'] = wp_count_posts()->publish . '+';
    } elseif ($stat['number'] === '' && $stat['label'] === 'Categories') {
        $stat['number'] = wp_count_terms('category') . '+';
    }
}
unset($stat);
?>

<section class="about-section">
    <div class="about-section__background">
        <div class="about-section__pattern"></div>
        <div class="about-section__pattern about-section__pattern--left"></div>
    </div>
    <div class="container">
        <div class="about-section__content">
            <?php if ($about_badge) : ?>
            <div class="about-section__badge">
                <i class="bi bi-patch-check-fill"></i>
                <?php echo esc_html($about_badge); ?>
            </div>
            <?php endif; ?>

            <h2 class="about-section__title">
                <?php if ($about_title_prefix) : ?>
                    <?php echo esc_html($about_title_prefix); ?>
                <?php endif; ?>
                <span class="about-section__brand"><?php echo esc_html(ACMS_SITE_NAME); ?></span>
            </h2>

            <?php if ($about_tagline) : ?>
            <p class="about-section__tagline">
                <?php echo esc_html($about_tagline); ?>
            </p>
            <?php endif; ?>

            <div class="about-section__divider"><span></span></div>

            <?php if ($about_description) : ?>
            <p class="about-section__description">
                <?php echo esc_html($about_description); ?>
            </p>
            <?php endif; ?>

            <div class="about-section__cta">
                <?php if ($about_cta1_text && $about_cta1_url) : ?>
                <a href="<?php echo esc_url(home_url($about_cta1_url)); ?>" class="about-section__btn about-section__btn--primary">
                    <i class="bi bi-arrow-right-circle"></i>
                    <?php echo esc_html($about_cta1_text); ?>
                </a>
                <?php endif; ?>
                <?php if ($about_cta2_text && $about_cta2_url) : ?>
                <a href="<?php echo esc_url(home_url($about_cta2_url)); ?>" class="about-section__btn about-section__btn--secondary">
                    <i class="bi bi-play-circle"></i>
                    <?php echo esc_html($about_cta2_text); ?>
                </a>
                <?php endif; ?>
            </div>

            <?php if (!empty($about_trust_items)) : ?>
            <div class="about-section__trust">
                <?php foreach ($about_trust_items as $item) : ?>
                <div class="about-section__trust-item">
                    <i class="bi <?php echo esc_attr($item['icon']); ?>"></i>
                    <span><?php echo esc_html($item['text']); ?></span>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <!-- Stats -->
            <?php if (!empty($about_stats)) : ?>
            <div class="about-section__stats">
                <?php foreach ($about_stats as $stat) : ?>
                    <?php if ($stat['number'] && $stat['label']) : ?>
                    <div class="about-section__stat">
                        <span class="about-section__stat-number"><?php echo esc_html($stat['number']); ?></span>
                        <span class="about-section__stat-label"><?php echo esc_html($stat['label']); ?></span>
                    </div>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>
