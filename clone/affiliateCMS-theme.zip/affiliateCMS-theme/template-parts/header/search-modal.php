<?php
/**
 * Template Part: Search Modal (Simple)
 *
 * @package AffiliateCMS
 * @since 4.0.0
 */
?>

<div class="search-modal" id="search-modal" role="dialog" aria-modal="true" aria-label="<?php esc_attr_e('Search Categories', 'affiliatecms'); ?>">
    <div class="search-modal__backdrop" data-search-close></div>
    <div class="search-modal__content">
        <div class="search-modal__form">
            <div class="search-modal__input-wrap">
                <i class="bi bi-search search-modal__icon"></i>
                <input
                    type="search"
                    class="search-modal__input"
                    id="category-search-input"
                    placeholder="<?php esc_attr_e('Search categories...', 'affiliatecms'); ?>"
                    aria-label="<?php esc_attr_e('Search categories', 'affiliatecms'); ?>"
                    autocomplete="off"
                    spellcheck="false"
                    aria-expanded="false"
                    aria-controls="search-results"
                >
                <kbd class="search-modal__shortcut">ESC</kbd>
            </div>

            <!-- Dropdown Results -->
            <div class="search-modal__dropdown" id="search-results" role="listbox" style="display: none;">
                <!-- Loading State — Skeleton shimmer -->
                <div class="search-modal__loading" style="display: none;">
                    <div class="search-modal__loading-item">
                        <div class="search-modal__loading-icon"></div>
                        <div class="search-modal__loading-lines">
                            <div class="search-modal__loading-line"></div>
                            <div class="search-modal__loading-line search-modal__loading-line--short"></div>
                        </div>
                    </div>
                    <div class="search-modal__loading-item">
                        <div class="search-modal__loading-icon"></div>
                        <div class="search-modal__loading-lines">
                            <div class="search-modal__loading-line"></div>
                            <div class="search-modal__loading-line search-modal__loading-line--short"></div>
                        </div>
                    </div>
                    <div class="search-modal__loading-item">
                        <div class="search-modal__loading-icon"></div>
                        <div class="search-modal__loading-lines">
                            <div class="search-modal__loading-line"></div>
                            <div class="search-modal__loading-line search-modal__loading-line--short"></div>
                        </div>
                    </div>
                </div>

                <!-- Results List -->
                <div class="search-modal__results" style="display: none;">
                    <!-- Populated by JS -->
                </div>

                <!-- No Results -->
                <div class="search-modal__no-results" style="display: none;">
                    <i class="bi bi-search"></i>
                    <p><?php esc_html_e('No categories found for your search', 'affiliatecms'); ?></p>
                </div>

                <!-- Footer hints -->
                <div class="search-modal__footer">
                    <span class="search-modal__footer-item"><kbd><i class="bi bi-arrow-return-left"></i></kbd> open</span>
                    <span class="search-modal__footer-item"><kbd><i class="bi bi-arrow-up"></i></kbd><kbd><i class="bi bi-arrow-down"></i></kbd> navigate</span>
                    <span class="search-modal__footer-item"><kbd>esc</kbd> close</span>
                </div>
            </div>
        </div>
    </div>
</div>
