<?php
/**
 * Template Part: Site Header
 *
 * @package AffiliateCMS
 * @since 1.0.0
 */

// Using hardcoded config (0 DB queries)
$cta_text = ACMS_HEADER_CTA_TEXT;
$cta_url = ACMS_HEADER_CTA_URL;
?>

<header class="site-header" id="masthead">
    <div class="container">
        <div class="header__inner">
            <!-- Logo -->
            <div class="header__logo">
                <?php acms_site_logo(); ?>
            </div>

            <!-- Desktop Navigation (hardcoded from config.php, 0 queries) -->
            <nav class="header__nav" id="site-navigation" aria-label="Main navigation">
                <ul class="header__menu" data-priority-nav>
                    <?php foreach (ACMS_HEADER_MENU as $item) : ?>
                        <li class="menu-item"><a href="<?php echo esc_url(home_url($item['url'])); ?>"><?php echo esc_html($item['text']); ?></a></li>
                    <?php endforeach; ?>
                    <li class="menu-item menu-item--more">
                        <button type="button" aria-expanded="false" aria-haspopup="true">
                            <i class="bi bi-three-dots"></i>
                            <span class="screen-reader-text">More</span>
                        </button>
                        <ul class="more-menu__dropdown"></ul>
                    </li>
                </ul>
            </nav>

            <!-- Mobile Icons -->
            <div class="header__mobile-icons">
                <button class="header__icon-btn" aria-label="<?php esc_attr_e('Search', 'affiliatecms'); ?>" data-search-toggle>
                    <i class="bi bi-search"></i>
                </button>
                <button class="header__icon-btn mobile-menu-toggle" aria-label="<?php esc_attr_e('Menu', 'affiliatecms'); ?>" aria-expanded="false" data-mobile-menu-toggle>
                    <i class="bi bi-list icon-menu"></i>
                    <i class="bi bi-x-lg icon-close"></i>
                </button>
            </div>

            <!-- Header Actions (Desktop) -->
            <div class="header__actions">
                <!-- Search Icon -->
                <button class="header__action-btn" aria-label="<?php esc_attr_e('Search', 'affiliatecms'); ?>" data-search-toggle>
                    <i class="bi bi-search"></i>
                </button>

                <!-- Theme Toggle -->
                <button class="header__action-btn theme-toggle" aria-label="<?php esc_attr_e('Toggle theme', 'affiliatecms'); ?>" data-theme-toggle>
                    <i class="bi bi-moon-fill theme-toggle__icon theme-toggle__icon--moon"></i>
                    <i class="bi bi-sun-fill theme-toggle__icon theme-toggle__icon--sun"></i>
                </button>

                <!-- CTA Button -->
                <?php if ($cta_text && $cta_url) : ?>
                    <a href="<?php echo esc_url($cta_url); ?>" class="btn btn--primary btn--sm header__cta">
                        <i class="bi bi-tag-fill"></i>
                        <?php echo esc_html($cta_text); ?>
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</header>
