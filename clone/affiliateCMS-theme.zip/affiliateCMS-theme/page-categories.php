<?php
/**
 * Template Name: Categories Directory
 *
 * Displays all SEO categories from acms_categories table
 * in a hierarchical tree structure with search and filter.
 *
 * SSR renders L1 + L2 + L3 (~1,776 items). L4+ and A-Z load via AJAX.
 *
 * @package AffiliateCMS
 * @since 4.0.0
 */

get_header();

// Build the SEO category tree from acms_categories table
$category_tree = [];
$total_categories = 0;
$total_products = 0;
$root_categories = [];
$az_letters = [];
$using_cache = false;

// Try loading from pre-generated JSON cache first
if (class_exists(\AffiliateCMS\Categories\Core\CategoryDirectoryCache::class)) {
    $cached = \AffiliateCMS\Categories\Core\CategoryDirectoryCache::load();
    if ($cached !== null) {
        $category_tree    = $cached['tree'] ?? [];
        $total_categories = $cached['stats']['total_categories'] ?? 0;
        $total_products   = $cached['stats']['total_products'] ?? 0;
        $root_categories  = $cached['root_categories'] ?? [];
        $az_letters       = array_keys($cached['az_grouped'] ?? []);
        $using_cache      = true;
    }
}

// Fallback: dynamic loading if cache unavailable
if (!$using_cache && class_exists(\AffiliateCMS\Categories\Repositories\CategoryRepository::class)) {
    $catRepo = new \AffiliateCMS\Categories\Repositories\CategoryRepository();
    $category_tree = $catRepo->getTree('publish');

    global $wpdb;
    $tables = \AffiliateCMS\Categories\Database\Schema::tables();
    $total_categories = (int) $wpdb->get_var(
        $wpdb->prepare("SELECT COUNT(*) FROM {$tables['categories']} WHERE status = %s", 'publish')
    );
    $total_products = (int) $wpdb->get_var("SELECT COUNT(DISTINCT product_id) FROM {$tables['category_products']}");
    $root_categories = $catRepo->getRoots('publish');
}
?>

<main id="content" class="site-main">

    <!-- Hero Minimal -->
    <section class="hero-minimal">
        <div class="container">
            <div class="hero-minimal__icon">
                <i class="bi bi-folder2-open"></i>
            </div>
            <h1 class="hero-minimal__title">Browse All Categories</h1>
            <?php acms_breadcrumb(); ?>
            <p class="hero-minimal__subtitle">
                <?php
                printf(
                    'Explore %d categories with %s products',
                    $total_categories,
                    number_format($total_products)
                );
                ?>
            </p>
        </div>
    </section>

    <!-- Main Content -->
    <section class="section categories-directory">
        <div class="container">
            <div class="content-layout">
                <!-- Main Column -->
                <div class="content-layout__main">

                    <!-- Search & Filters -->
                    <div class="cat-dir__controls">
                        <!-- Search -->
                        <div class="cat-dir__search">
                            <i class="bi bi-search"></i>
                            <input type="text"
                                   id="cat-search"
                                   class="cat-dir__search-input"
                                   placeholder="Search categories..."
                                   autocomplete="off">
                            <button type="button" class="cat-dir__search-clear" id="cat-search-clear" aria-label="Clear search">
                                <i class="bi bi-x-lg"></i>
                            </button>
                        </div>

                        <!-- Filters -->
                        <div class="cat-dir__filters">
                            <button type="button" class="cat-dir__filter-btn is-active" data-filter="all">
                                <i class="bi bi-grid-3x3-gap"></i>
                                All
                            </button>
                            <button type="button" class="cat-dir__filter-btn" data-filter="az">
                                <i class="bi bi-sort-alpha-down"></i>
                                A-Z
                            </button>
                            <?php if (!empty($root_categories)) : ?>
                            <div class="cat-dir__filter-dropdown">
                                <button type="button" class="cat-dir__filter-btn" id="parent-filter-btn">
                                    <i class="bi bi-funnel"></i>
                                    By Group
                                    <i class="bi bi-chevron-down"></i>
                                </button>
                                <div class="cat-dir__filter-menu" id="parent-filter-menu">
                                    <button type="button" class="cat-dir__filter-option is-active" data-parent="all">
                                        All Groups
                                    </button>
                                    <?php foreach ($root_categories as $root) :
                                        $root_icon = $root['icon'] ?: 'bi-folder';
                                    ?>
                                    <button type="button" class="cat-dir__filter-option" data-parent="<?php echo esc_attr($root['id']); ?>">
                                        <i class="bi <?php echo esc_attr($root_icon); ?>"></i>
                                        <?php echo esc_html($root['name']); ?>
                                    </button>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Results Count -->
                    <div class="cat-dir__results">
                        <span id="cat-results-count">
                            <?php
                            printf(
                                _n('%d category', '%d categories', $total_categories, 'affiliatecms'),
                                $total_categories
                            );
                            ?>
                        </span>
                    </div>

                    <!-- Category Tree (Default View) — SSR L1 + L2 + L3 -->
                    <div class="cat-dir__tree" id="cat-tree-view">
                        <?php foreach ($category_tree as $parent) :
                            $parent_icon = $parent['icon'] ?: 'bi-folder';
                            $parent_count = (int) ($parent['product_count'] ?? 0);
                            $parent_url = home_url('/c/' . $parent['slug'] . '/');
                        ?>
                        <div class="cat-tree__group" data-parent-id="<?php echo esc_attr($parent['id']); ?>">
                            <!-- L1: Parent Category -->
                            <div class="cat-tree__parent">
                                <a href="<?php echo esc_url($parent_url); ?>" class="cat-tree__parent-link">
                                    <span class="cat-tree__icon cat-tree__icon--parent">
                                        <i class="bi <?php echo esc_attr($parent_icon); ?>"></i>
                                    </span>
                                    <span class="cat-tree__name"><?php echo esc_html($parent['name']); ?></span>
                                    <span class="cat-tree__count">(<?php echo esc_html($parent_count); ?>)</span>
                                    <i class="bi bi-arrow-right cat-tree__arrow"></i>
                                </a>
                            </div>

                            <?php if (!empty($parent['children'])) : ?>
                            <!-- L2: Children -->
                            <div class="cat-tree__children">
                                <?php foreach ($parent['children'] as $child) :
                                    $child_icon = $child['icon'] ?: 'bi-folder';
                                    $child_count = (int) ($child['product_count'] ?? 0);
                                    $child_url = home_url('/c/' . $child['slug'] . '/');
                                    $has_grandchildren = !empty($child['children']);
                                ?>
                                <div class="cat-tree__child" data-cat-id="<?php echo esc_attr($child['id']); ?>">
                                    <div class="cat-tree__child-row">
                                        <a href="<?php echo esc_url($child_url); ?>" class="cat-tree__child-link">
                                            <span class="cat-tree__icon">
                                                <i class="bi <?php echo esc_attr($child_icon); ?>"></i>
                                            </span>
                                            <span class="cat-tree__name"><?php echo esc_html($child['name']); ?></span>
                                            <span class="cat-tree__count">(<?php echo esc_html($child_count); ?>)</span>
                                        </a>
                                        <?php if ($has_grandchildren) : ?>
                                        <button type="button" class="cat-tree__expand" aria-label="Expand subcategories">
                                            <i class="bi bi-chevron-right"></i>
                                            <span class="cat-tree__expand-text"><?php echo count($child['children']); ?> sub</span>
                                        </button>
                                        <?php endif; ?>
                                    </div>

                                    <?php if ($has_grandchildren) : ?>
                                    <!-- L3: Grandchildren (SSR) -->
                                    <div class="cat-tree__grandchildren" style="display:none;">
                                        <?php foreach ($child['children'] as $gc) :
                                            $gc_icon = $gc['icon'] ?: 'bi-folder';
                                            $gc_count = (int) ($gc['product_count'] ?? 0);
                                            $gc_url = home_url('/c/' . $gc['slug'] . '/');
                                            $has_l4 = !empty($gc['children']);
                                        ?>
                                        <div class="cat-tree__grandchild" data-cat-id="<?php echo esc_attr($gc['id']); ?>">
                                            <div class="cat-tree__grandchild-row">
                                                <a href="<?php echo esc_url($gc_url); ?>" class="cat-tree__grandchild-link">
                                                    <span class="cat-tree__icon cat-tree__icon--small">
                                                        <i class="bi <?php echo esc_attr($gc_icon); ?>"></i>
                                                    </span>
                                                    <span class="cat-tree__name"><?php echo esc_html($gc['name']); ?></span>
                                                    <span class="cat-tree__count">(<?php echo esc_html($gc_count); ?>)</span>
                                                </a>
                                                <?php if ($has_l4) : ?>
                                                <button type="button" class="cat-tree__expand cat-tree__expand--small" aria-label="Expand">
                                                    <i class="bi bi-chevron-right"></i>
                                                    <span class="cat-tree__expand-text"><?php echo count($gc['children']); ?> sub</span>
                                                </button>
                                                <?php endif; ?>
                                            </div>
                                            <?php if ($has_l4) : ?>
                                            <!-- L4+ container: filled by AJAX -->
                                            <div class="cat-tree__level4" data-loaded="0" style="display:none;"></div>
                                            <?php endif; ?>
                                        </div>
                                        <?php endforeach; ?>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                <?php endforeach; ?>
                            </div>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; ?>
                    </div>

                    <!-- A-Z List View (Hidden, lazy loaded) -->
                    <div class="cat-dir__az-list" id="cat-az-view" style="display: none;">
                        <?php
                        // Filter to A-Z + 0-9 only (skip special chars, CJK, empty keys)
                        $az_display_letters = array_filter($az_letters, function($l) {
                            return preg_match('/^[A-Z0-9]$/', $l);
                        });
                        ?>
                        <?php if (!empty($az_display_letters)) : ?>
                        <div class="cat-az__letters" id="cat-az-letters">
                            <?php foreach ($az_display_letters as $letter) : ?>
                            <button type="button" class="cat-az__letter-btn" data-letter="<?php echo esc_attr($letter); ?>">
                                <?php echo esc_html($letter); ?>
                            </button>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                        <div class="cat-az__content" id="cat-az-content"></div>
                    </div>

                    <!-- Search Results (Hidden, shown during search) -->
                    <div class="cat-dir__search-results" id="cat-search-results" style="display: none;"></div>

                    <!-- No Results -->
                    <div class="cat-dir__no-results" id="cat-no-results" style="display: none;">
                        <div class="cat-dir__no-results-icon">
                            <i class="bi bi-search"></i>
                        </div>
                        <h3>No categories found</h3>
                        <p>Try adjusting your search or filter to find what you're looking for.</p>
                    </div>

                </div>

                <!-- Sidebar -->
                <?php get_sidebar(); ?>
            </div>
        </div>
    </section>

</main>

<script>
window.acmsCatDir = {
    restUrl: '<?php echo esc_url(rest_url('acms-cat/v1/')); ?>',
    homeUrl: '<?php echo esc_url(home_url('/')); ?>',
    nonce: '<?php echo wp_create_nonce('wp_rest'); ?>'
};
</script>

<?php
get_footer();
