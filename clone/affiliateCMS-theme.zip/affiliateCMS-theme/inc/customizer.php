<?php
/**
 * Theme Dynamic CSS
 *
 * Generates CSS variables from hardcoded config (config.php).
 * All Customizer UI has been removed — edit config.php directly.
 *
 * @package AffiliateCMS
 * @since 4.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Output custom CSS variables from config constants.
 * Only outputs overrides when values differ from the CSS defaults (tokens.css).
 */
function acms_customizer_css() {
    // Resolve colors: preset or individual
    $preset = defined('ACMS_COLOR_PRESET') ? ACMS_COLOR_PRESET : 'teal';

    // Teal defaults (must match tokens.css)
    $defaults = [
        'primary'        => '#0D7377',
        'primary_hover'  => '#0A5C5F',
        'accent'         => '#E07A5F',
        'surface'        => '#FFFFFF',
        'background'     => '#FDFBF7',
        'bg_alt'         => '#F7F5F0',
        'text'           => '#1A1D21',
        'text_secondary' => '#4A5056',
        'text_muted'     => '#6B7280',
        'border'         => '#E5E2DC',
    ];

    // Get active colors
    if ($preset !== 'custom' && $preset !== 'teal') {
        // Use preset values
        $preset_colors = acms_get_color_preset($preset);
        $colors = [];
        foreach ($defaults as $key => $default) {
            $colors[$key] = [
                'value'   => $preset_colors[$key] ?? $default,
                'default' => $default,
            ];
        }
    } else {
        // Use individual constants (custom or teal)
        $colors = [
            'primary'        => ['value' => ACMS_COLOR_PRIMARY, 'default' => $defaults['primary']],
            'primary_hover'  => ['value' => ACMS_COLOR_PRIMARY_HOVER, 'default' => $defaults['primary_hover']],
            'accent'         => ['value' => ACMS_COLOR_ACCENT, 'default' => $defaults['accent']],
            'surface'        => ['value' => ACMS_COLOR_SURFACE, 'default' => $defaults['surface']],
            'background'     => ['value' => ACMS_COLOR_BACKGROUND, 'default' => $defaults['background']],
            'bg_alt'         => ['value' => ACMS_COLOR_BG_ALT, 'default' => $defaults['bg_alt']],
            'text'           => ['value' => ACMS_COLOR_TEXT, 'default' => $defaults['text']],
            'text_secondary' => ['value' => ACMS_COLOR_TEXT_SECONDARY, 'default' => $defaults['text_secondary']],
            'text_muted'     => ['value' => ACMS_COLOR_TEXT_MUTED, 'default' => $defaults['text_muted']],
            'border'         => ['value' => ACMS_COLOR_BORDER, 'default' => $defaults['border']],
        ];
    }

    // Layout settings
    $container_width = defined('ACMS_CONTAINER_WIDTH') ? (string) ACMS_CONTAINER_WIDTH : '1280';
    $border_radius   = defined('ACMS_BORDER_RADIUS') ? ACMS_BORDER_RADIUS : 'medium';
    $card_style      = defined('ACMS_CARD_STYLE') ? ACMS_CARD_STYLE : 'shadow';
    $card_hover      = defined('ACMS_CARD_HOVER') ? ACMS_CARD_HOVER : 'lift';

    // Border radius values
    $radius_map = [
        'none'   => '0',
        'small'  => '4px',
        'medium' => '8px',
        'large'  => '12px',
        'xl'     => '16px',
    ];
    $radius_value = $radius_map[$border_radius] ?? '8px';

    // Check if any colors are different from defaults
    $has_custom = false;
    foreach ($colors as $color) {
        if (strtoupper($color['value']) !== strtoupper($color['default'])) {
            $has_custom = true;
            break;
        }
    }
    $has_custom = $has_custom || $container_width !== '1280' || $border_radius !== 'medium';

    // Only output if there are custom settings
    if (!$has_custom && $card_style === 'shadow' && $card_hover === 'lift') {
        return;
    }

    $css = ':root {';

    // Primary color and variants
    if (strtoupper($colors['primary']['value']) !== strtoupper($colors['primary']['default'])) {
        $primary = $colors['primary']['value'];
        $css .= '--color-primary: ' . esc_attr($primary) . ';';
        $css .= '--color-primary-rgb: ' . acms_hex_to_rgb($primary) . ';';
        $css .= '--color-primary-dark: ' . acms_adjust_brightness($primary, -20) . ';';
        $css .= '--color-primary-light: ' . acms_adjust_brightness($primary, 85, 0.15) . ';';
        $css .= '--shadow-primary: 0 4px 14px rgba(' . acms_hex_to_rgb($primary) . ', 0.2);';
    }

    // Primary hover
    if (strtoupper($colors['primary_hover']['value']) !== strtoupper($colors['primary_hover']['default'])) {
        $css .= '--color-primary-hover: ' . esc_attr($colors['primary_hover']['value']) . ';';
    }

    // Accent color and variants
    if (strtoupper($colors['accent']['value']) !== strtoupper($colors['accent']['default'])) {
        $accent = $colors['accent']['value'];
        $css .= '--color-accent: ' . esc_attr($accent) . ';';
        $css .= '--color-accent-rgb: ' . acms_hex_to_rgb($accent) . ';';
        $css .= '--color-accent-hover: ' . acms_adjust_brightness($accent, -15) . ';';
        $css .= '--color-accent-light: ' . acms_adjust_brightness($accent, 85, 0.12) . ';';
        $css .= '--shadow-accent: 0 4px 14px rgba(' . acms_hex_to_rgb($accent) . ', 0.2);';
    }

    // Surface colors
    if (strtoupper($colors['surface']['value']) !== strtoupper($colors['surface']['default'])) {
        $surface = $colors['surface']['value'];
        $css .= '--color-surface: ' . esc_attr($surface) . ';';
        $css .= '--color-surface-raised: ' . esc_attr($surface) . ';';
        $css .= '--color-surface-hover: ' . acms_adjust_brightness($surface, -3) . ';';
    }

    // Background colors
    if (strtoupper($colors['background']['value']) !== strtoupper($colors['background']['default'])) {
        $css .= '--color-bg: ' . esc_attr($colors['background']['value']) . ';';
    }
    if (strtoupper($colors['bg_alt']['value']) !== strtoupper($colors['bg_alt']['default'])) {
        $css .= '--color-bg-alt: ' . esc_attr($colors['bg_alt']['value']) . ';';
    }

    // Text colors
    if (strtoupper($colors['text']['value']) !== strtoupper($colors['text']['default'])) {
        $css .= '--color-text: ' . esc_attr($colors['text']['value']) . ';';
    }
    if (strtoupper($colors['text_secondary']['value']) !== strtoupper($colors['text_secondary']['default'])) {
        $css .= '--color-text-secondary: ' . esc_attr($colors['text_secondary']['value']) . ';';
    }
    if (strtoupper($colors['text_muted']['value']) !== strtoupper($colors['text_muted']['default'])) {
        $css .= '--color-text-muted: ' . esc_attr($colors['text_muted']['value']) . ';';
    }

    // Border colors
    if (strtoupper($colors['border']['value']) !== strtoupper($colors['border']['default'])) {
        $border = $colors['border']['value'];
        $css .= '--color-border: ' . esc_attr($border) . ';';
        $css .= '--color-border-subtle: ' . acms_adjust_brightness($border, 5) . ';';
        $css .= '--color-border-strong: ' . acms_adjust_brightness($border, -10) . ';';
    }

    // Layout
    if ($container_width !== '1280') {
        $css .= '--container-max: ' . esc_attr($container_width) . 'px;';
    }
    if ($border_radius !== 'medium') {
        $css .= '--radius-md: ' . esc_attr($radius_value) . ';';
    }

    $css .= '}';

    // Card styles
    if ($card_style !== 'shadow') {
        if ($card_style === 'border') {
            $css .= '.post-card { box-shadow: none; border: 1px solid var(--color-border); }';
        } elseif ($card_style === 'minimal') {
            $css .= '.post-card { box-shadow: none; border: none; }';
        }
    }

    // Card hover effects
    if ($card_hover !== 'lift') {
        if ($card_hover === 'shadow') {
            $css .= '.post-card:hover { transform: none; box-shadow: var(--shadow-lg); }';
        } elseif ($card_hover === 'glow') {
            $css .= '.post-card:hover { transform: none; box-shadow: 0 0 0 3px var(--color-primary); }';
        } elseif ($card_hover === 'none') {
            $css .= '.post-card:hover { transform: none; box-shadow: var(--shadow-sm); }';
        }
    }

    // Generate dark mode CSS when custom colors are used
    if ($has_custom) {
        $primary = $colors['primary']['value'];
        $accent = $colors['accent']['value'];

        $css .= '[data-theme="dark"] {';

        // Primary - lighter/brighter for dark backgrounds
        $primary_dark = acms_adjust_brightness($primary, 35);
        $css .= '--color-primary: ' . esc_attr($primary_dark) . ';';
        $css .= '--color-primary-rgb: ' . acms_hex_to_rgb($primary_dark) . ';';
        $css .= '--color-primary-hover: ' . acms_adjust_brightness($primary, 20) . ';';
        $css .= '--color-primary-dark: ' . esc_attr($primary) . ';';
        $css .= '--color-primary-light: rgba(' . acms_hex_to_rgb($primary_dark) . ', 0.15);';
        $css .= '--shadow-primary: 0 4px 14px rgba(' . acms_hex_to_rgb($primary_dark) . ', 0.25);';

        // Accent - slightly lighter for dark mode
        $accent_dark = acms_adjust_brightness($accent, 25);
        $css .= '--color-accent: ' . esc_attr($accent_dark) . ';';
        $css .= '--color-accent-rgb: ' . acms_hex_to_rgb($accent_dark) . ';';
        $css .= '--color-accent-hover: ' . esc_attr($accent) . ';';
        $css .= '--color-accent-light: rgba(' . acms_hex_to_rgb($accent_dark) . ', 0.15);';
        $css .= '--shadow-accent: 0 4px 14px rgba(' . acms_hex_to_rgb($accent_dark) . ', 0.25);';

        // Dark surfaces and backgrounds
        $css .= '--color-bg: #0C0E12;';
        $css .= '--color-bg-alt: #12151A;';
        $css .= '--color-surface: #1A1D24;';
        $css .= '--color-surface-raised: #22262F;';
        $css .= '--color-surface-hover: #252A34;';

        // Light text for dark backgrounds
        $css .= '--color-text: #F5F5F5;';
        $css .= '--color-text-secondary: #D4D4D8;';
        $css .= '--color-text-muted: #A1A1AA;';
        $css .= '--color-text-subtle: #71717A;';

        // Dark borders
        $css .= '--color-border: #2D323C;';
        $css .= '--color-border-subtle: #23272F;';
        $css .= '--color-border-strong: #3D4450;';

        // Overlay
        $css .= '--color-overlay: rgba(0, 0, 0, 0.6);';

        $css .= '}';
    }

    echo '<style id="acms-customizer-css">' . $css . '</style>';
}
add_action('wp_head', 'acms_customizer_css', 100);

/**
 * Convert hex color to RGB values
 *
 * @param string $hex Hex color code
 * @return string RGB values (e.g., "20, 184, 166")
 */
function acms_hex_to_rgb($hex) {
    $hex = ltrim($hex, '#');

    if (strlen($hex) === 3) {
        $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
    }

    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));

    return "{$r}, {$g}, {$b}";
}

/**
 * Adjust color brightness/lightness
 *
 * @param string $hex Hex color code
 * @param int $percent Percentage to adjust (-100 to 100, negative = darker)
 * @param float $blend_white Optional: blend with white for light variants (0-1)
 * @return string Adjusted hex color
 */
function acms_adjust_brightness($hex, $percent, $blend_white = 0) {
    $hex = ltrim($hex, '#');

    if (strlen($hex) === 3) {
        $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
    }

    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));

    // Blend with white for light variants
    if ($blend_white > 0) {
        $r = round($r + (255 - $r) * $blend_white);
        $g = round($g + (255 - $g) * $blend_white);
        $b = round($b + (255 - $b) * $blend_white);
    }

    // Adjust brightness
    $r = max(0, min(255, $r + round($r * $percent / 100)));
    $g = max(0, min(255, $g + round($g * $percent / 100)));
    $b = max(0, min(255, $b + round($b * $percent / 100)));

    return sprintf('#%02x%02x%02x', $r, $g, $b);
}

/**
 * Get color preset values
 *
 * @param string $preset Preset name
 * @return array Color values
 */
function acms_get_color_preset($preset) {
    $presets = [
        'teal' => [
            'primary'        => '#0D7377',
            'primary_hover'  => '#0A5C5F',
            'accent'         => '#E07A5F',
            'surface'        => '#FFFFFF',
            'background'     => '#FDFBF7',
            'bg_alt'         => '#F7F5F0',
            'text'           => '#1A1D21',
            'text_secondary' => '#4A5056',
            'text_muted'     => '#6B7280',
            'border'         => '#E5E2DC',
        ],
        'blue' => [
            'primary'        => '#3B82F6',
            'primary_hover'  => '#2563EB',
            'accent'         => '#F59E0B',
            'surface'        => '#FFFFFF',
            'background'     => '#F8FAFC',
            'bg_alt'         => '#F1F5F9',
            'text'           => '#0F172A',
            'text_secondary' => '#334155',
            'text_muted'     => '#64748B',
            'border'         => '#E2E8F0',
        ],
        'purple' => [
            'primary'        => '#8B5CF6',
            'primary_hover'  => '#7C3AED',
            'accent'         => '#EC4899',
            'surface'        => '#FFFFFF',
            'background'     => '#FAF5FF',
            'bg_alt'         => '#F3E8FF',
            'text'           => '#1E1B4B',
            'text_secondary' => '#4C1D95',
            'text_muted'     => '#7C3AED',
            'border'         => '#E9D5FF',
        ],
        'green' => [
            'primary'        => '#22C55E',
            'primary_hover'  => '#16A34A',
            'accent'         => '#F97316',
            'surface'        => '#FFFFFF',
            'background'     => '#F0FDF4',
            'bg_alt'         => '#DCFCE7',
            'text'           => '#14532D',
            'text_secondary' => '#166534',
            'text_muted'     => '#4ADE80',
            'border'         => '#BBF7D0',
        ],
        'red' => [
            'primary'        => '#EF4444',
            'primary_hover'  => '#DC2626',
            'accent'         => '#F59E0B',
            'surface'        => '#FFFFFF',
            'background'     => '#FEF2F2',
            'bg_alt'         => '#FEE2E2',
            'text'           => '#450A0A',
            'text_secondary' => '#7F1D1D',
            'text_muted'     => '#B91C1C',
            'border'         => '#FECACA',
        ],
        'orange' => [
            'primary'        => '#F97316',
            'primary_hover'  => '#EA580C',
            'accent'         => '#14B8A6',
            'surface'        => '#FFFFFF',
            'background'     => '#FFF7ED',
            'bg_alt'         => '#FFEDD5',
            'text'           => '#431407',
            'text_secondary' => '#7C2D12',
            'text_muted'     => '#C2410C',
            'border'         => '#FED7AA',
        ],
        'pink' => [
            'primary'        => '#EC4899',
            'primary_hover'  => '#DB2777',
            'accent'         => '#8B5CF6',
            'surface'        => '#FFFFFF',
            'background'     => '#FDF2F8',
            'bg_alt'         => '#FCE7F3',
            'text'           => '#500724',
            'text_secondary' => '#831843',
            'text_muted'     => '#BE185D',
            'border'         => '#FBCFE8',
        ],
        'dark' => [
            'primary'        => '#3B82F6',
            'primary_hover'  => '#60A5FA',
            'accent'         => '#F59E0B',
            'surface'        => '#1E293B',
            'background'     => '#0F172A',
            'bg_alt'         => '#1E293B',
            'text'           => '#F1F5F9',
            'text_secondary' => '#CBD5E1',
            'text_muted'     => '#94A3B8',
            'border'         => '#334155',
        ],
    ];

    return $presets[$preset] ?? $presets['teal'];
}
