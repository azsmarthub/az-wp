<?php
/**
 * Theme Configuration - Default Settings
 *
 * This file contains all theme configuration that would normally
 * be stored in the Customizer. For private themes, hardcoding these
 * values provides better performance (0 database queries).
 *
 * All constants use defined() checks so child themes can override
 * by defining the constant before this file loads.
 *
 * To change values: Define the constant in your child theme's
 * functions.php or config.php, or edit this file directly.
 *
 * @package AffiliateCMS
 * @since 4.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Site Identity
 */
if (!defined('ACMS_SITE_NAME')) {
    define('ACMS_SITE_NAME', 'ProductReviews.org');
}
if (!defined('ACMS_SITE_TAGLINE')) {
    define('ACMS_SITE_TAGLINE', 'Smart Shopping. Smart Savings.');
}

/**
 * Header Settings
 */
if (!defined('ACMS_HEADER_CTA_TEXT')) {
    define('ACMS_HEADER_CTA_TEXT', "Sign-in");
}
if (!defined('ACMS_HEADER_CTA_URL')) {
    define('ACMS_HEADER_CTA_URL', '/#');
}
if (!defined('ACMS_HEADER_LOGO_URL')) {
    define('ACMS_HEADER_LOGO_URL', '/wp-content/uploads/2026/02/logo.png');
}
if (!defined('ACMS_HEADER_LOGO_TEXT')) {
    define('ACMS_HEADER_LOGO_TEXT', 'AZ');
}
if (!defined('ACMS_HEADER_MENU')) {
    define('ACMS_HEADER_MENU', [
        ['text' => 'Categories', 'url' => '/categories/'],
        ['text' => 'Blog', 'url' => '/blog/'],
        ['text' => 'About', 'url' => '/about-us/'],
        ['text' => 'Contact', 'url' => '/contact/'],
        ['text' => 'Log in', 'url' => '/wp-login.php'],
        ['text' => 'Register', 'url' => '/wp-login.php?action=register'],
    ]);
}

/**
 * Disclosure Bar Settings (shown site-wide above content)
 */
if (!defined('ACMS_DISCLOSURE_SHOW')) {
    define('ACMS_DISCLOSURE_SHOW', true);
}
if (!defined('ACMS_DISCLOSURE_TEXT')) {
    define('ACMS_DISCLOSURE_TEXT', 'We independently review everything we recommend. When you buy through our links, we may earn a commission at no additional cost to you.');
}
if (!defined('ACMS_DISCLOSURE_LINK_TEXT')) {
    define('ACMS_DISCLOSURE_LINK_TEXT', 'Learn more');
}
if (!defined('ACMS_DISCLOSURE_LINK_URL')) {
    define('ACMS_DISCLOSURE_LINK_URL', '/affiliate-disclosure/');
}

/**
 * Product List Disclosure (shown near affiliate product links in shortcodes)
 */
if (!defined('ACMS_LIST_DISCLOSURE_SHOW')) {
    define('ACMS_LIST_DISCLOSURE_SHOW', true);
}
if (!defined('ACMS_LIST_DISCLOSURE_TEXT')) {
    define('ACMS_LIST_DISCLOSURE_TEXT', 'As an Amazon Associate I earn from qualifying purchases.');
}

/**
 * Score Display Settings (product list & category pages)
 */
if (!defined('ACMS_SCORE_LABEL')) {
    define('ACMS_SCORE_LABEL', 'Score');
}
if (!defined('ACMS_SCORE_TOOLTIP')) {
    define('ACMS_SCORE_TOOLTIP', "ProductReviews.org score rating is a scoring system developed by our experts. The score is from 0 to 10 based on the data collected by the ProductReviews.org tool. This score doesn't impact from any manufacturer or sales agent websites. We encourage you to write a review of your experiences with these products.");
}
if (!defined('ACMS_SCORE_TOOLTIP_LINK_TEXT')) {
    define('ACMS_SCORE_TOOLTIP_LINK_TEXT', 'Learn more');
}
if (!defined('ACMS_SCORE_TOOLTIP_LINK_URL')) {
    define('ACMS_SCORE_TOOLTIP_LINK_URL', '/about-us/');
}

/**
 * Update Info Settings (product list timestamp display)
 */
if (!defined('ACMS_SHOW_UPDATE')) {
    define('ACMS_SHOW_UPDATE', true);
}
if (!defined('ACMS_UPDATE_TOOLTIP')) {
    define('ACMS_UPDATE_TOOLTIP', 'Last update on {date}. Affiliate links, prices, images, product titles, and highlights from Amazon Product Advertising API.');
}

/**
 * Footer Settings
 */
if (!defined('ACMS_FAVICON_URL')) {
    define('ACMS_FAVICON_URL', '/wp-content/uploads/2026/02/favicon.png');
}
if (!defined('ACMS_FOOTER_LOGO_ID')) {
    define('ACMS_FOOTER_LOGO_ID', 0);
}
if (!defined('ACMS_FOOTER_LOGO_ICON')) {
    define('ACMS_FOOTER_LOGO_ICON', 'bi-bag-check');
}
if (!defined('ACMS_FOOTER_DESCRIPTION')) {
    define('ACMS_FOOTER_DESCRIPTION', 'Get product reviews at ProductReviews.org: expert insights + real American user ratings. Unbiased pros/cons, verified feedback, and smart U.S. shopping guides.');
}
if (!defined('ACMS_FOOTER_DISCLOSURE')) {
    define('ACMS_FOOTER_DISCLOSURE', 'As Amazon Associates, we earn from qualifying purchases. This means we may receive a small commission at no extra cost to you if you click through and make a purchase.');
}
if (!defined('ACMS_FOOTER_DISCLOSURE_LINK_TEXT')) {
    define('ACMS_FOOTER_DISCLOSURE_LINK_TEXT', 'Affiliate Disclosure');
}
if (!defined('ACMS_FOOTER_DISCLOSURE_LINK_URL')) {
    define('ACMS_FOOTER_DISCLOSURE_LINK_URL', '/affiliate-disclosure/');
}
if (!defined('ACMS_FOOTER_COPYRIGHT')) {
    define('ACMS_FOOTER_COPYRIGHT', '');
}
if (!defined('ACMS_FOOTER_POLICY_LINKS')) {
    define('ACMS_FOOTER_POLICY_LINKS', [
        ['text' => 'About', 'url' => '/about-us/'],
        ['text' => 'Categories', 'url' => 'categories/'],
        ['text' => 'Privacy Policy', 'url' => '/privacy-policy/'],
        ['text' => 'Terms of Service', 'url' => '/terms-of-service/'],
        ['text' => 'Guidelines for Reviewers', 'url' => 'guidelines-for-reviewers/'],
        ['text' => 'Affiliate Disclosure', 'url' => '/affiliate-disclosure/'],
        ['text' => 'DMCA', 'url' => '/dmca/'],
        ['text' => 'Contact', 'url' => '/contact/'],
    ]);
}

/**
 * Contact Information
 */
if (!defined('ACMS_CONTACT_EMAIL')) {
    define('ACMS_CONTACT_EMAIL', 'contact@affiliatecms.com');
}

/**
 * Social Media URLs
 * Leave empty string '' to hide a social network
 */
if (!defined('ACMS_SOCIAL_FACEBOOK')) {
    define('ACMS_SOCIAL_FACEBOOK', 'https://www.facebook.com/productreviewsr');
}
if (!defined('ACMS_SOCIAL_TWITTER')) {
    define('ACMS_SOCIAL_TWITTER', 'https://x.com/productreviewsr');
}
if (!defined('ACMS_SOCIAL_INSTAGRAM')) {
    define('ACMS_SOCIAL_INSTAGRAM', '');
}
if (!defined('ACMS_SOCIAL_YOUTUBE')) {
    define('ACMS_SOCIAL_YOUTUBE', '');
}
if (!defined('ACMS_SOCIAL_PINTEREST')) {
    define('ACMS_SOCIAL_PINTEREST', '');
}
if (!defined('ACMS_SOCIAL_LINKEDIN')) {
    define('ACMS_SOCIAL_LINKEDIN', 'https://www.linkedin.com/company/productreviewsr/');
}
if (!defined('ACMS_SOCIAL_TIKTOK')) {
    define('ACMS_SOCIAL_TIKTOK', '');
}

/**
 * Hero Section Settings (Homepage)
 */
if (!defined('ACMS_HERO_BADGE')) {
    define('ACMS_HERO_BADGE', 'Over 3 million products analyzed daily across 5,000 category comparison pages.');
}
if (!defined('ACMS_HERO_TITLE')) {
    define('ACMS_HERO_TITLE', 'ProductReviews.org<br><span class="hero__title-highlight">Best Reviews and Ratings</span>');
}
if (!defined('ACMS_HERO_DESCRIPTION')) {
    define('ACMS_HERO_DESCRIPTION', 'Research. Compare. Buy with Confidence.');
}
if (!defined('ACMS_HERO_PLACEHOLDER')) {
    define('ACMS_HERO_PLACEHOLDER', 'Search for a product or category...');
}
if (!defined('ACMS_HERO_PROMPTS')) {
    define('ACMS_HERO_PROMPTS', [
        '"Best walking pad for small apartments"',
        '"Compare top air purifiers"',
        '"Budget-friendly soundbars"',
    ]);
}
if (!defined('ACMS_HERO_TAGS_LABEL')) {
    define('ACMS_HERO_TAGS_LABEL', 'Top Rated:');
}
if (!defined('ACMS_HERO_TAGS')) {
    define('ACMS_HERO_TAGS', [
        ['name' => 'Air Fryers', 'url' => '/c/air-fryers/'],
        ['name' => 'Electric Toothbrushes', 'url' => '/c/electric-toothbrushes/'],
        ['name' => 'Mattresses', 'url' => '/c/mattresses/'],
        ['name' => 'Espresso Machines', 'url' => '/c/espresso-machines/'],
        ['name' => 'Pillows', 'url' => '/c/pillows/'],
        ['name' => 'Running Shoes', 'url' => '/c/running-shoes/'],
    ]);
}
if (!defined('ACMS_HERO_STATS')) {
    define('ACMS_HERO_STATS', [
        ['number' => '', 'label' => 'Product Reviews'],
        ['number' => '2.5M+', 'label' => 'Visitors'],
        ['number' => '$50M+', 'label' => 'Saved for Users'],
    ]);
}

/**
 * Categories Section Settings (Homepage)
 */
if (!defined('ACMS_CAT_BADGE')) {
    define('ACMS_CAT_BADGE', 'Browse Categories');
}
if (!defined('ACMS_CAT_TITLE')) {
    define('ACMS_CAT_TITLE', 'Find the Best. Skip the Rest.');
}
if (!defined('ACMS_CAT_SUBTITLE')) {
    define('ACMS_CAT_SUBTITLE', 'Explore products by top categories - to find, read, and choose what truly fits you.');
}
if (!defined('ACMS_CAT_COUNT')) {
    define('ACMS_CAT_COUNT', 12);
}
if (!defined('ACMS_CAT_CTA_TEXT')) {
    define('ACMS_CAT_CTA_TEXT', 'All Products A-Z');
}
if (!defined('ACMS_CAT_CTA_URL')) {
    define('ACMS_CAT_CTA_URL', '/categories/');
}
if (!defined('ACMS_CAT_ITEMS')) {
    define('ACMS_CAT_ITEMS', [
        ['name' => 'Electronics', 'icon' => 'bi-cpu-fill', 'count' => 245, 'url' => '/c/electronics/'],
        ['name' => 'Home & Kitchen', 'icon' => 'bi-house-fill', 'count' => 189, 'url' => '/c/home-kitchen/'],
        ['name' => 'Health & Beauty', 'icon' => 'bi-heart-fill', 'count' => 156, 'url' => '/c/health-beauty/'],
        ['name' => 'Sports & Outdoors', 'icon' => 'bi-bicycle', 'count' => 134, 'url' => '/c/sports-outdoors/'],
        ['name' => 'Baby & Kids', 'icon' => 'bi-balloon-fill', 'count' => 98, 'url' => '/c/baby-kids/'],
        ['name' => 'Office Supplies', 'icon' => 'bi-briefcase-fill', 'count' => 87, 'url' => '/c/office-supplies/'],
        ['name' => 'Kitchen Appliances', 'icon' => 'bi-cup-hot-fill', 'count' => 112, 'url' => '/c/kitchen-appliances/'],
        ['name' => 'Security & Smart Home', 'icon' => 'bi-shield-fill-check', 'count' => 76, 'url' => '/c/smart-home/'],
    ]);
}

/**
 * About Section Settings (Homepage)
 */
if (!defined('ACMS_ABOUT_BADGE')) {
    define('ACMS_ABOUT_BADGE', 'Trusted Since 2022');
}
if (!defined('ACMS_ABOUT_TITLE_PREFIX')) {
    define('ACMS_ABOUT_TITLE_PREFIX', 'About');
}
if (!defined('ACMS_ABOUT_TAGLINE')) {
    define('ACMS_ABOUT_TAGLINE', 'Get product reviews at ProductReviews.org: expert insights + real American user ratings. Unbiased pros/cons, verified feedback, and smart U.S. shopping guides.');
}
if (!defined('ACMS_ABOUT_DESCRIPTION')) {
    define('ACMS_ABOUT_DESCRIPTION', 'We offer expert reviews and guides on Electronics, Home Improvement, Kitchen Appliances, Lawn & Garden, Automotive, and Daily Deals. Our goal is to simplify your buying decisions with clear, reliable insights.');
}
if (!defined('ACMS_ABOUT_CTA1_TEXT')) {
    define('ACMS_ABOUT_CTA1_TEXT', 'All Categories');
}
if (!defined('ACMS_ABOUT_CTA1_URL')) {
    define('ACMS_ABOUT_CTA1_URL', '/categories/');
}
if (!defined('ACMS_ABOUT_CTA2_TEXT')) {
    define('ACMS_ABOUT_CTA2_TEXT', 'How We Review');
}
if (!defined('ACMS_ABOUT_CTA2_URL')) {
    define('ACMS_ABOUT_CTA2_URL', '/about-us/');
}
if (!defined('ACMS_ABOUT_TRUST_ITEMS')) {
    define('ACMS_ABOUT_TRUST_ITEMS', [
        ['icon' => 'bi-shield-check', 'text' => 'Unbiased Reviews'],
        ['icon' => 'bi-cash-coin', 'text' => 'Best Value Picks'],
        ['icon' => 'bi-clock-history', 'text' => 'Updated Weekly'],
    ]);
}
if (!defined('ACMS_ABOUT_STATS')) {
    define('ACMS_ABOUT_STATS', [
        ['number' => '', 'label' => 'Expert Reviews'],
        ['number' => '2.5M+', 'label' => 'Monthly Readers'],
        ['number' => '', 'label' => 'Categories'],
        ['number' => 'Daily', 'label' => 'Updates'],
    ]);
}

/**
 * Latest Posts Section Settings (Homepage)
 */
if (!defined('ACMS_LATEST_ICON')) {
    define('ACMS_LATEST_ICON', 'bi-lightning-fill');
}
if (!defined('ACMS_LATEST_TITLE')) {
    define('ACMS_LATEST_TITLE', 'Latest');
}
if (!defined('ACMS_LATEST_SUBTITLE')) {
    define('ACMS_LATEST_SUBTITLE', 'Expert opinions on the newest products');
}
if (!defined('ACMS_LATEST_VIEWALL_TEXT')) {
    define('ACMS_LATEST_VIEWALL_TEXT', 'View All');
}
if (!defined('ACMS_LATEST_VIEWALL_URL')) {
    define('ACMS_LATEST_VIEWALL_URL', '/categories/');
}
if (!defined('ACMS_LATEST_COUNT')) {
    define('ACMS_LATEST_COUNT', 6);
}
if (!defined('ACMS_LATEST_LOAD_MORE')) {
    define('ACMS_LATEST_LOAD_MORE', true);
}
if (!defined('ACMS_LATEST_LAYOUT')) {
    define('ACMS_LATEST_LAYOUT', 'grid');
}
if (!defined('ACMS_LATEST_POST_TYPES')) {
    define('ACMS_LATEST_POST_TYPES', 'post');
}

/**
 * Layout Settings
 */
if (!defined('ACMS_SIDEBAR_POSITION')) {
    define('ACMS_SIDEBAR_POSITION', 'right');
}
if (!defined('ACMS_SINGLE_LAYOUT')) {
    define('ACMS_SINGLE_LAYOUT', 'full');
}
if (!defined('ACMS_ARCHIVE_LAYOUT')) {
    define('ACMS_ARCHIVE_LAYOUT', 'grid');
}
if (!defined('ACMS_POSTS_PER_PAGE')) {
    define('ACMS_POSTS_PER_PAGE', 12);
}
if (!defined('ACMS_CONTAINER_WIDTH')) {
    define('ACMS_CONTAINER_WIDTH', 1280);
}
if (!defined('ACMS_BORDER_RADIUS')) {
    define('ACMS_BORDER_RADIUS', 'medium');
}
if (!defined('ACMS_CARD_STYLE')) {
    define('ACMS_CARD_STYLE', 'shadow');
}
if (!defined('ACMS_CARD_HOVER')) {
    define('ACMS_CARD_HOVER', 'lift');
}

/**
 * Color Settings
 *
 * Default: "teal" preset. To change, either:
 * 1. Set ACMS_COLOR_PRESET to a preset name (overrides all individual colors)
 * 2. Set ACMS_COLOR_PRESET to 'custom' and edit individual colors below
 *
 * Available presets: teal, blue, purple, green, red, orange, pink, dark
 */
if (!defined('ACMS_COLOR_PRESET')) {
    define('ACMS_COLOR_PRESET', 'teal');
}

// Individual colors (only used when ACMS_COLOR_PRESET = 'custom')
if (!defined('ACMS_COLOR_PRIMARY')) {
    define('ACMS_COLOR_PRIMARY', '#0D7377');
}
if (!defined('ACMS_COLOR_PRIMARY_HOVER')) {
    define('ACMS_COLOR_PRIMARY_HOVER', '#0A5C5F');
}
if (!defined('ACMS_COLOR_ACCENT')) {
    define('ACMS_COLOR_ACCENT', '#E07A5F');
}
if (!defined('ACMS_COLOR_SURFACE')) {
    define('ACMS_COLOR_SURFACE', '#FFFFFF');
}
if (!defined('ACMS_COLOR_BACKGROUND')) {
    define('ACMS_COLOR_BACKGROUND', '#FDFBF7');
}
if (!defined('ACMS_COLOR_BG_ALT')) {
    define('ACMS_COLOR_BG_ALT', '#F7F5F0');
}
if (!defined('ACMS_COLOR_TEXT')) {
    define('ACMS_COLOR_TEXT', '#1A1D21');
}
if (!defined('ACMS_COLOR_TEXT_SECONDARY')) {
    define('ACMS_COLOR_TEXT_SECONDARY', '#4A5056');
}
if (!defined('ACMS_COLOR_TEXT_MUTED')) {
    define('ACMS_COLOR_TEXT_MUTED', '#6B7280');
}
if (!defined('ACMS_COLOR_BORDER')) {
    define('ACMS_COLOR_BORDER', '#E5E2DC');
}

/**
 * Get social links array (hardcoded, 0 DB queries)
 *
 * @return array Social links with url, icon, and label
 */
function acms_get_social_links_config() {
    static $links = null;

    if ($links !== null) {
        return $links;
    }

    $networks = [
        'facebook'  => ['icon' => 'bi-facebook', 'label' => 'Facebook', 'url' => ACMS_SOCIAL_FACEBOOK],
        'twitter'   => ['icon' => 'bi-twitter-x', 'label' => 'Twitter', 'url' => ACMS_SOCIAL_TWITTER],
        'instagram' => ['icon' => 'bi-instagram', 'label' => 'Instagram', 'url' => ACMS_SOCIAL_INSTAGRAM],
        'youtube'   => ['icon' => 'bi-youtube', 'label' => 'YouTube', 'url' => ACMS_SOCIAL_YOUTUBE],
        'pinterest' => ['icon' => 'bi-pinterest', 'label' => 'Pinterest', 'url' => ACMS_SOCIAL_PINTEREST],
        'linkedin'  => ['icon' => 'bi-linkedin', 'label' => 'LinkedIn', 'url' => ACMS_SOCIAL_LINKEDIN],
        'tiktok'    => ['icon' => 'bi-tiktok', 'label' => 'TikTok', 'url' => ACMS_SOCIAL_TIKTOK],
    ];

    $links = [];
    foreach ($networks as $key => $data) {
        if (!empty($data['url'])) {
            $links[$key] = $data;
        }
    }

    return $links;
}

/**
 * Get copyright text (replaces acms_get_copyright function logic)
 *
 * @return string Copyright HTML
 */
function acms_get_copyright_config() {
    if (!empty(ACMS_FOOTER_COPYRIGHT)) {
        return ACMS_FOOTER_COPYRIGHT;
    }

    // Auto-generate copyright
    $year = date('Y');
    $site_name = ACMS_SITE_NAME;

    return sprintf(
        '&copy; %d %s. All rights reserved.',
        $year,
        $site_name
    );
}
