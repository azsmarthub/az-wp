<?php
/**
 * REST API Endpoints
 *
 * @package AffiliateCMS
 * @since 4.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Register REST API routes
 */
function acms_register_rest_routes() {
    $namespace = 'azs/v1';

    // Posts endpoint for Load More
    register_rest_route($namespace, '/posts', [
        'methods'             => WP_REST_Server::READABLE,
        'callback'            => 'acms_rest_get_posts',
        'permission_callback' => '__return_true',
        'args'                => [
            'page' => [
                'default'           => 1,
                'sanitize_callback' => 'absint',
            ],
            'per_page' => [
                'default'           => 12,
                'sanitize_callback' => 'absint',
            ],
            'category' => [
                'default'           => '',
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'tag' => [
                'default'           => '',
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'author' => [
                'default'           => '',
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'search' => [
                'default'           => '',
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'year' => [
                'default'           => '',
                'sanitize_callback' => 'absint',
            ],
            'month' => [
                'default'           => '',
                'sanitize_callback' => 'absint',
            ],
            'layout' => [
                'default'           => 'grid',
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'post_types' => [
                'default'           => 'post',
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'taxonomy' => [
                'default'           => '',
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'term' => [
                'default'           => '',
                'sanitize_callback' => 'sanitize_text_field',
            ],
        ],
    ]);

    // Post view tracking
    register_rest_route($namespace, '/posts/(?P<id>\d+)/view', [
        'methods'             => WP_REST_Server::CREATABLE,
        'callback'            => 'acms_rest_track_view',
        'permission_callback' => '__return_true',
        'args'                => [
            'id' => [
                'required'          => true,
                'validate_callback' => function($param) {
                    return is_numeric($param);
                },
            ],
        ],
    ]);

    // GET /comments - List comments (sorted, paginated)
    register_rest_route($namespace, '/comments', [
        'methods'             => WP_REST_Server::READABLE,
        'callback'            => 'acms_rest_get_comments',
        'permission_callback' => '__return_true',
        'args'                => [
            'post_id' => [
                'required'          => true,
                'sanitize_callback' => 'absint',
            ],
            'page' => [
                'default'           => 1,
                'sanitize_callback' => 'absint',
            ],
            'per_page' => [
                'default'           => 10,
                'sanitize_callback' => 'absint',
            ],
            'orderby' => [
                'default'           => 'newest',
                'sanitize_callback' => 'sanitize_text_field',
            ],
        ],
    ]);

    // POST /comments - Submit a comment with rating
    register_rest_route($namespace, '/comments', [
        'methods'             => WP_REST_Server::CREATABLE,
        'callback'            => 'acms_rest_post_comment',
        'permission_callback' => '__return_true',
        'args'                => [
            'post_id' => [
                'required'          => true,
                'sanitize_callback' => 'absint',
            ],
            'content' => [
                'required'          => true,
                'sanitize_callback' => 'sanitize_textarea_field',
            ],
            'author_name' => [
                'default'           => '',
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'author_email' => [
                'default'           => '',
                'sanitize_callback' => 'sanitize_email',
            ],
            'rating' => [
                'default'           => 0,
                'sanitize_callback' => 'absint',
            ],
            'parent' => [
                'default'           => 0,
                'sanitize_callback' => 'absint',
            ],
        ],
    ]);

    // Post heart/like
    register_rest_route($namespace, '/posts/(?P<id>\d+)/heart', [
        'methods'             => [WP_REST_Server::READABLE, WP_REST_Server::CREATABLE],
        'callback'            => 'acms_rest_post_heart',
        'permission_callback' => '__return_true',
        'args'                => [
            'id' => [
                'required'          => true,
                'validate_callback' => function($param) {
                    return is_numeric($param);
                },
            ],
        ],
    ]);
}
add_action('rest_api_init', 'acms_register_rest_routes');

/**
 * Get posts for Load More
 *
 * @param WP_REST_Request $request
 * @return WP_REST_Response
 */
function acms_rest_get_posts($request) {
    $page       = $request->get_param('page');
    $per_page   = min($request->get_param('per_page'), 24); // Max 24 per request
    $category   = $request->get_param('category');
    $tag        = $request->get_param('tag');
    $author     = $request->get_param('author');
    $search     = $request->get_param('search');
    $year       = $request->get_param('year');
    $month      = $request->get_param('month');
    $layout     = $request->get_param('layout');
    $post_types = $request->get_param('post_types');
    $taxonomy   = $request->get_param('taxonomy');
    $term       = $request->get_param('term');

    // Determine card variant based on layout
    $is_list_layout = ($layout === 'list');
    $card_variant = $is_list_layout ? 'list' : 'grid-v2';

    // Determine which post types to query
    $allowed_types = ['post', 'acms_reviews', 'acms_deals', 'acms_guides'];
    switch ($post_types) {
        case 'acms_reviews':
            $query_post_types = 'acms_reviews';
            break;
        case 'both':
            $query_post_types = ['post', 'acms_reviews'];
            break;
        case 'all':
            $query_post_types = $allowed_types;
            break;
        case 'post':
        default:
            $query_post_types = 'post';
            break;
    }

    // Build query args
    $args = [
        'post_type'      => $query_post_types,
        'post_status'    => 'publish',
        'posts_per_page' => $per_page,
        'paged'          => $page,
        'orderby'        => 'date',
        'order'          => 'DESC',
    ];

    // Category filter (by slug or ID)
    if (!empty($category)) {
        if (is_numeric($category)) {
            $args['cat'] = absint($category);
        } else {
            $args['category_name'] = $category;
        }
    }

    // Tag filter (by slug or ID)
    if (!empty($tag)) {
        if (is_numeric($tag)) {
            $args['tag_id'] = absint($tag);
        } else {
            $args['tag'] = $tag;
        }
    }

    // Custom taxonomy filter
    if (!empty($taxonomy) && !empty($term)) {
        $allowed_taxonomies = [
            'category', 'post_tag',
            'acms_reviews_category', 'acms_reviews_tag',
            'acms_deals_category', 'acms_deals_tag',
            'acms_guides_category', 'acms_guides_tag',
        ];
        if (in_array($taxonomy, $allowed_taxonomies, true)) {
            $args['tax_query'] = [
                [
                    'taxonomy' => $taxonomy,
                    'field'    => 'slug',
                    'terms'    => $term,
                ],
            ];
            // Auto-detect post type from taxonomy
            $taxonomy_post_type_map = [
                'acms_reviews_category' => 'acms_reviews',
                'acms_reviews_tag'      => 'acms_reviews',
                'acms_deals_category'   => 'acms_deals',
                'acms_deals_tag'        => 'acms_deals',
                'acms_guides_category'  => 'acms_guides',
                'acms_guides_tag'       => 'acms_guides',
            ];
            if (isset($taxonomy_post_type_map[$taxonomy])) {
                $args['post_type'] = $taxonomy_post_type_map[$taxonomy];
            }
        }
    }

    // Author filter (by ID or nicename)
    if (!empty($author)) {
        if (is_numeric($author)) {
            $args['author'] = absint($author);
        } else {
            $args['author_name'] = $author;
        }
    }

    // Search
    if (!empty($search)) {
        $args['s'] = $search;
    }

    // Date filters
    if (!empty($year)) {
        $args['year'] = $year;
    }
    if (!empty($month)) {
        $args['monthnum'] = $month;
    }

    $query = new WP_Query($args);
    $posts = [];

    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();

            // Capture the post card HTML
            ob_start();
            get_template_part('template-parts/content/post-card', null, [
                'variant'        => $card_variant,
                'show_category'  => $is_list_layout,
                'show_indicator' => $is_list_layout,
                'show_rating'    => false,
                'show_views'     => false,
                'footer_cols'    => $is_list_layout ? '3col' : '2col',
                'excerpt_words'  => $is_list_layout ? 25 : 15,
            ]);
            $html = ob_get_clean();

            $posts[] = [
                'id'    => get_the_ID(),
                'title' => get_the_title(),
                'html'  => $html,
            ];
        }
        wp_reset_postdata();
    }

    return rest_ensure_response([
        'success'     => true,
        'posts'       => $posts,
        'total'       => $query->found_posts,
        'total_pages' => $query->max_num_pages,
        'current_page' => $page,
    ]);
}

/**
 * Track post view
 *
 * @param WP_REST_Request $request
 * @return WP_REST_Response
 */
function acms_rest_track_view($request) {
    $post_id = absint($request->get_param('id'));

    if (!$post_id || !get_post($post_id)) {
        return new WP_Error('invalid_post', 'Invalid post ID', ['status' => 404]);
    }

    // Increment view count
    $views = (int) get_post_meta($post_id, '_acms_views', true);
    $views++;
    update_post_meta($post_id, '_acms_views', $views);

    return rest_ensure_response([
        'success'         => true,
        'views'           => $views,
        'views_formatted' => acms_format_number($views),
    ]);
}

/**
 * Get comments for a post (sorted, paginated)
 *
 * @param WP_REST_Request $request
 * @return WP_REST_Response
 */
function acms_rest_get_comments($request) {
    $post_id  = $request->get_param('post_id');
    $page     = max(1, $request->get_param('page'));
    $per_page = min($request->get_param('per_page'), 50);
    $orderby  = $request->get_param('orderby');

    if (!$post_id || !get_post($post_id)) {
        return new WP_Error('invalid_post', 'Invalid post ID', ['status' => 404]);
    }

    $args = [
        'post_id' => $post_id,
        'status'  => 'approve',
        'number'  => $per_page,
        'offset'  => ($page - 1) * $per_page,
        'parent'  => 0,
        'type'    => 'comment',
    ];

    switch ($orderby) {
        case 'oldest':
            $args['orderby'] = 'comment_date';
            $args['order']   = 'ASC';
            break;
        case 'rating':
            $args['meta_key'] = '_acms_rating';
            $args['orderby']  = 'meta_value_num';
            $args['order']    = 'DESC';
            break;
        default: // newest
            $args['orderby'] = 'comment_date';
            $args['order']   = 'DESC';
            break;
    }

    $comments = get_comments($args);

    // Total count for pagination
    $total = get_comments([
        'post_id' => $post_id,
        'status'  => 'approve',
        'parent'  => 0,
        'type'    => 'comment',
        'count'   => true,
    ]);
    $pages = max(1, (int) ceil($total / $per_page));

    $result = array_map('acms_rest_format_comment', $comments);

    return rest_ensure_response([
        'success'  => true,
        'comments' => $result,
        'total'    => $total,
        'pages'    => $pages,
        'page'     => $page,
    ]);
}

/**
 * Submit a new comment with rating
 *
 * @param WP_REST_Request $request
 * @return WP_REST_Response
 */
function acms_rest_post_comment($request) {
    $post_id      = $request->get_param('post_id');
    $content      = $request->get_param('content');
    $author_name  = $request->get_param('author_name');
    $author_email = $request->get_param('author_email');
    $rating       = $request->get_param('rating');
    $parent       = $request->get_param('parent');

    // Validate post
    $post = get_post($post_id);
    if (!$post || !comments_open($post_id)) {
        return rest_ensure_response([
            'success' => false,
            'message' => __('Comments are closed for this post.', 'affiliatecms'),
        ]);
    }

    // Validate content
    if (empty(trim($content))) {
        return rest_ensure_response([
            'success' => false,
            'message' => __('Comment content is required.', 'affiliatecms'),
        ]);
    }

    // Build comment data
    $commentdata = [
        'comment_post_ID' => $post_id,
        'comment_content'  => wp_kses_post($content),
        'comment_parent'   => $parent,
        'comment_type'     => 'comment',
    ];

    if (is_user_logged_in()) {
        $user = wp_get_current_user();
        $commentdata['user_id']              = $user->ID;
        $commentdata['comment_author']       = $user->display_name;
        $commentdata['comment_author_email'] = $user->user_email;
        $commentdata['comment_author_url']   = $user->user_url;
    } else {
        if (empty($author_name) || empty($author_email)) {
            return rest_ensure_response([
                'success' => false,
                'message' => __('Name and email are required.', 'affiliatecms'),
            ]);
        }
        $commentdata['comment_author']       = $author_name;
        $commentdata['comment_author_email'] = $author_email;
    }

    // Spam check - let WordPress decide (approved/spam/0)
    $commentdata['comment_approved'] = wp_allow_comment($commentdata);

    $comment_id = wp_insert_comment($commentdata);
    if (!$comment_id || is_wp_error($comment_id)) {
        return rest_ensure_response([
            'success' => false,
            'message' => __('Failed to submit comment. Please try again.', 'affiliatecms'),
        ]);
    }

    // Save rating if provided
    if ($rating >= 1 && $rating <= 5) {
        if (function_exists('acms_comments')) {
            acms_comments()->rating->save_rating_api($comment_id, $rating, $post_id);
        }
    }

    // Fire WP hooks for notifications etc.
    do_action('comment_post', $comment_id, $commentdata['comment_approved'], $commentdata);

    $comment = get_comment($comment_id);

    if ($commentdata['comment_approved'] === 'spam' || $commentdata['comment_approved'] === 0) {
        return rest_ensure_response([
            'success' => true,
            'message' => __('Your comment is awaiting moderation.', 'affiliatecms'),
            'comment' => null,
        ]);
    }

    return rest_ensure_response([
        'success' => true,
        'message' => __('Your comment has been posted!', 'affiliatecms'),
        'comment' => acms_rest_format_comment($comment),
    ]);
}

/**
 * Format a WP_Comment into the structure expected by frontend JS
 *
 * @param WP_Comment $comment
 * @return array
 */
function acms_rest_format_comment($comment) {
    $rating    = get_comment_meta($comment->comment_ID, '_acms_rating', true);
    $sentiment = null;

    if ($rating && function_exists('acms_get_rating_sentiment')) {
        $sentiment = acms_get_rating_sentiment((int) $rating);
    }

    $email       = $comment->comment_author_email;
    $avatar_color = function_exists('acms_get_avatar_color')
        ? acms_get_avatar_color($email)
        : '#3D405B';

    // Get replies
    $replies_raw = get_comments([
        'parent'  => $comment->comment_ID,
        'status'  => 'approve',
        'orderby' => 'comment_date',
        'order'   => 'ASC',
    ]);

    $replies = array_map(function ($reply) {
        $r_email = $reply->comment_author_email;
        return [
            'id'      => (int) $reply->comment_ID,
            'content' => wpautop($reply->comment_content),
            'date'    => human_time_diff(strtotime($reply->comment_date), current_time('timestamp')) . ' ago',
            'date_iso' => $reply->comment_date,
            'author'  => [
                'name'         => $reply->comment_author,
                'initial'      => mb_strtoupper(mb_substr($reply->comment_author, 0, 1)),
                'avatar_color' => function_exists('acms_get_avatar_color')
                    ? acms_get_avatar_color($r_email) : '#3D405B',
                'is_verified'  => (int) $reply->user_id > 0,
            ],
        ];
    }, $replies_raw);

    return [
        'id'       => (int) $comment->comment_ID,
        'content'  => wpautop($comment->comment_content),
        'date'     => human_time_diff(strtotime($comment->comment_date), current_time('timestamp')) . ' ago',
        'date_iso' => $comment->comment_date,
        'rating'   => $rating ? (int) $rating : null,
        'sentiment' => $sentiment,
        'author'   => [
            'name'         => $comment->comment_author,
            'initial'      => mb_strtoupper(mb_substr($comment->comment_author, 0, 1)),
            'avatar_color' => $avatar_color,
            'is_verified'  => (int) $comment->user_id > 0,
        ],
        'replies'  => $replies,
    ];
}

/**
 * Get or toggle post heart/like
 *
 * @param WP_REST_Request $request
 * @return WP_REST_Response
 */
function acms_rest_post_heart($request) {
    $post_id = absint($request->get_param('id'));

    if (!$post_id || !get_post($post_id)) {
        return new WP_Error('invalid_post', 'Invalid post ID', ['status' => 404]);
    }

    $hearts = (int) get_post_meta($post_id, '_acms_hearts', true);

    // GET - just return current count
    if ($request->get_method() === 'GET') {
        return rest_ensure_response([
            'success' => true,
            'hearts'  => $hearts,
        ]);
    }

    // POST - toggle heart (increment)
    // In a real app, you'd track user's heart state via cookie/user meta
    $hearts++;
    update_post_meta($post_id, '_acms_hearts', $hearts);

    return rest_ensure_response([
        'success' => true,
        'hearts'  => $hearts,
        'hearted' => true,
    ]);
}
