<?php
/**
 * Link Tracking Filter
 * Auto-process external links with UTM, affiliate tags, and redirect
 *
 * @package AffiliateCMS
 * @since 4.0.0
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Process all external links in HTML content — wraps redirect, adds affiliate tag, UTM, nofollow, target
 *
 * Can be called directly: echo acms_wrap_external_links($html);
 * Also hooked to the_content filter for posts/pages.
 *
 * @param string $content HTML content
 * @return string Processed HTML
 */
function acms_wrap_external_links($content) {
    if (empty($content)) {
        return $content;
    }

    // Get settings from pro plugin's general settings
    $settings = get_option('acms_general_settings', []);

    $utm_enabled = $settings['enable_utm'] ?? false;
    $utm_apply_to_amazon = $settings['utm_apply_to_amazon'] ?? false;
    $utm_source = !empty($settings['utm_source']) ? $settings['utm_source'] : get_bloginfo('name');
    $utm_medium = !empty($settings['utm_medium']) ? $settings['utm_medium'] : get_bloginfo('name');
    // No campaign field - it's auto-generated per post
    $utm_campaign = get_bloginfo('name');
    $redirect_enabled = $settings['redirect_enabled'] ?? true;
    $redirect_slug = $settings['redirect_slug'] ?? 'go';
    $amazon_tag = $settings['affiliate_tag'] ?? '';
    $add_nofollow = $settings['nofollow_links'] ?? true;
    $add_target_blank = $settings['open_new_tab'] ?? true;
    $cf_param = $settings['cf_param'] ?? '';

    return preg_replace_callback(
        '/<a\s+[^>]*href=["\']([^"\']+)["\'][^>]*>/i',
        function ($matches) use ($utm_enabled, $utm_apply_to_amazon, $utm_source, $utm_medium, $utm_campaign, $redirect_enabled, $redirect_slug, $amazon_tag, $add_nofollow, $add_target_blank, $cf_param) {
            $original_tag = $matches[0];

            // Decode HTML entities (&amp; → &)
            $url = html_entity_decode($matches[1], ENT_QUOTES, 'UTF-8');

            // Skip anchor links, relative paths, and non-http(s) protocols
            if ($url[0] === '#' || $url[0] === '/' || !preg_match('#^https?://#i', $url)) {
                return $original_tag;
            }

            // Skip internal links (same domain)
            if (strpos($url, home_url()) === 0) {
                return $original_tag;
            }

            // Determine if this is an Amazon link
            $is_amazon = (strpos($url, 'amazon.') !== false);

            // Process based on link type
            if ($is_amazon) {
                // ===== AMAZON LINK =====

                // Add affiliate tag if configured and not already present
                if (!empty($amazon_tag) && strpos($url, 'tag=') === false) {
                    $url .= (parse_url($url, PHP_URL_QUERY) ? '&' : '?') . 'tag=' . $amazon_tag . '&linkCode=ogi&th=1&psc=1';
                }

                // Add UTM if enabled for Amazon
                if ($utm_enabled && $utm_apply_to_amazon) {
                    $url = acms_add_utm_params($url, $utm_source, $utm_medium, $utm_campaign);
                }
            } else {
                // ===== EXTERNAL NON-AMAZON LINK =====

                // Add UTM if enabled (default for external links)
                if ($utm_enabled) {
                    $url = acms_add_utm_params($url, $utm_source, $utm_medium, $utm_campaign);
                }
            }

            // Wrap through redirect if enabled
            if ($redirect_enabled) {
                $redirect_url = home_url('/' . $redirect_slug . '/?url=' . urlencode($url));

                // Add Cloudflare parameter if configured
                if (!empty($cf_param)) {
                    $redirect_url .= '&' . $cf_param;
                }

                $url = $redirect_url;
            }

            // Replace href in the tag
            $new_tag = preg_replace(
                '/href=["\'][^"\']+["\']/',
                'href="' . esc_url($url) . '"',
                $original_tag
            );

            // Add rel="nofollow" if enabled
            if ($add_nofollow) {
                if (strpos($new_tag, 'rel=') === false) {
                    $new_tag = str_replace('<a ', '<a rel="nofollow" ', $new_tag);
                } else {
                    // Append to existing rel
                    $new_tag = preg_replace('/rel=["\']([^"\']*)["\']/', 'rel="$1 nofollow"', $new_tag);
                }
            }

            // Add target="_blank" if enabled
            if ($add_target_blank && strpos($new_tag, 'target=') === false) {
                $new_tag = str_replace('<a ', '<a target="_blank" ', $new_tag);
            }

            return $new_tag;
        },
        $content
    );
}
/**
 * Filter for the_content — only on singular pages (posts/pages)
 * Category pages call acms_wrap_external_links() directly
 */
function acms_process_content_links($content) {
    if (!is_singular()) {
        return $content;
    }
    return acms_wrap_external_links($content);
}
add_filter('the_content', 'acms_process_content_links', 99);

/**
 * Helper: Add UTM parameters to URL
 */
function acms_add_utm_params($url, $source, $medium, $campaign) {
    $params = [
        'utm_source'   => $source,
        'utm_medium'   => $medium,
        'utm_campaign' => $campaign,
    ];

    $query = parse_url($url, PHP_URL_QUERY);
    parse_str($query ?? '', $existing);

    // Merge UTM params (don't override if already exist)
    $final_query = array_merge($params, $existing);

    $base_url = strtok($url, '?');
    return $base_url . '?' . http_build_query($final_query);
}

/**
 * Handle redirect requests — fires on init, checks URI directly
 *
 * No rewrite rules needed — just matches the request path against the
 * configured redirect slug. Works immediately without flush_rewrite_rules().
 *
 * URL format: /go/?url=https://encoded-target-url
 */
function acms_handle_redirect_request() {
    // Quick bail: no url param = not a redirect request
    if (!isset($_GET['url'])) {
        return;
    }

    $settings = get_option('acms_general_settings', []);

    // Check if redirect is enabled
    if (empty($settings['redirect_enabled'])) {
        return;
    }

    $redirect_slug = $settings['redirect_slug'] ?? 'go';

    // Parse current request path (strip site subdirectory if any)
    $request_uri = $_SERVER['REQUEST_URI'] ?? '';
    $path = trim(parse_url($request_uri, PHP_URL_PATH), '/');

    // Remove WordPress subdirectory prefix (e.g., /wordpress/go → go)
    $home_path = trim(parse_url(home_url(), PHP_URL_PATH) ?? '', '/');
    if ($home_path && strpos($path, $home_path . '/') === 0) {
        $path = trim(substr($path, strlen($home_path)), '/');
    }

    // Check if path matches redirect slug
    if ($path !== $redirect_slug) {
        return;
    }

    $redirect_url = $_GET['url'];

    // Security: Validate URL
    if (!filter_var($redirect_url, FILTER_VALIDATE_URL)) {
        wp_die(
            __('Invalid URL parameter.', 'affiliatecms'),
            __('Error', 'affiliatecms'),
            ['response' => 400]
        );
    }

    // Security: Block redirect to own site (open redirect prevention)
    $target_host = parse_url($redirect_url, PHP_URL_HOST);
    $site_host = parse_url(home_url(), PHP_URL_HOST);
    if ($target_host === $site_host) {
        wp_die(
            __('Cannot redirect to own site.', 'affiliatecms'),
            __('Error', 'affiliatecms'),
            ['response' => 400]
        );
    }

    // Ensure Amazon tag for Amazon links (double-check)
    $amazon_tag = $settings['affiliate_tag'] ?? '';
    if (!empty($amazon_tag) && strpos($redirect_url, 'amazon.') !== false && strpos($redirect_url, 'tag=') === false) {
        $redirect_url .= (parse_url($redirect_url, PHP_URL_QUERY) ? '&' : '?') . 'tag=' . $amazon_tag;
    }

    // Track click (extensible via action hook)
    do_action('acms_redirect_click', $redirect_url, $_GET);

    // Use 302 (temporary) — 301 gets cached by browsers and can't be changed later
    wp_redirect($redirect_url, 302);
    exit;
}
add_action('init', 'acms_handle_redirect_request', 1);
