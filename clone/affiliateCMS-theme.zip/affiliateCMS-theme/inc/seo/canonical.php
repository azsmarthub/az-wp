<?php
/**
 * SEO Module - Canonical URLs
 *
 * Handles canonical URL output to prevent duplicate content.
 *
 * @package AffiliateCMS
 * @since 4.0.0
 */

namespace AffiliateCMS\SEO;

if (!defined('ABSPATH')) {
    exit;
}

class Canonical
{
    /**
     * Output canonical URL
     */
    public static function output(): void
    {
        // Remove WordPress default canonical
        remove_action('wp_head', 'rel_canonical');

        $canonical = self::getCanonical();

        if ($canonical) {
            echo '<link rel="canonical" href="' . esc_url($canonical) . '">' . "\n";
        }

        // Output prev/next for paginated content
        self::outputPaginationLinks();
    }

    /**
     * Get canonical URL for current page
     */
    public static function getCanonical(): string
    {
        // SEO Category page (/c/{slug}/)
        $acms_category = $GLOBALS['acms_current_category'] ?? null;
        if ($acms_category) {
            return home_url('/c/' . ($acms_category['slug'] ?? '') . '/');
        }

        // Brand page (/brand/{slug}/)
        $acms_brand = $GLOBALS['acms_current_brand'] ?? null;
        if ($acms_brand) {
            return home_url('/brand/' . ($acms_brand['slug'] ?? '') . '/');
        }

        // Single post/page
        if (is_singular()) {
            $post_id = get_the_ID();

            // Check for custom canonical
            $custom_canonical = SEO::getMeta($post_id, 'canonical');
            if ($custom_canonical) {
                return $custom_canonical;
            }

            // Handle paginated posts (<!--nextpage-->)
            $page = get_query_var('page', 0);
            if ($page > 1) {
                return get_permalink($post_id);
            }

            return get_permalink($post_id);
        }

        // Homepage
        if (is_front_page()) {
            return home_url('/');
        }

        // Blog page (if different from front page)
        if (is_home()) {
            $blog_page_id = get_option('page_for_posts');
            if ($blog_page_id) {
                return get_permalink($blog_page_id);
            }
            return home_url('/');
        }

        // Category/Tag/Taxonomy - canonical to first page
        if (is_category() || is_tag() || is_tax()) {
            $term = get_queried_object();
            if ($term) {
                $link = get_term_link($term);
                if (!is_wp_error($link)) {
                    return $link;
                }
            }
        }

        // Author archive
        if (is_author()) {
            $author = get_queried_object();
            if ($author) {
                return get_author_posts_url($author->ID);
            }
        }

        // Post type archive
        if (is_post_type_archive()) {
            $post_type = get_queried_object();
            if ($post_type) {
                return get_post_type_archive_link($post_type->name);
            }
        }

        // Date archives - canonical to main archive (optional, might want to remove)
        if (is_date()) {
            if (is_day()) {
                return get_day_link(get_query_var('year'), get_query_var('monthnum'), get_query_var('day'));
            }
            if (is_month()) {
                return get_month_link(get_query_var('year'), get_query_var('monthnum'));
            }
            if (is_year()) {
                return get_year_link(get_query_var('year'));
            }
        }

        // Search - no canonical (noindex anyway)
        if (is_search()) {
            return '';
        }

        // 404 - no canonical
        if (is_404()) {
            return '';
        }

        return '';
    }

    /**
     * Output prev/next links for paginated archives
     */
    private static function outputPaginationLinks(): void
    {
        // Only for archives, not single posts
        if (is_singular()) {
            return;
        }

        global $wp_query;

        $paged = get_query_var('paged', 1);
        if ($paged < 1) {
            $paged = 1;
        }

        $max_pages = $wp_query->max_num_pages;

        if ($max_pages <= 1) {
            return;
        }

        // Get base URL
        $base_url = self::getCanonical();
        if (!$base_url) {
            return;
        }

        // Previous page
        if ($paged > 1) {
            $prev_page = $paged - 1;
            $prev_url = ($prev_page === 1)
                ? $base_url
                : self::getPaginatedUrl($base_url, $prev_page);
            echo '<link rel="prev" href="' . esc_url($prev_url) . '">' . "\n";
        }

        // Next page
        if ($paged < $max_pages) {
            $next_url = self::getPaginatedUrl($base_url, $paged + 1);
            echo '<link rel="next" href="' . esc_url($next_url) . '">' . "\n";
        }
    }

    /**
     * Get paginated URL
     */
    private static function getPaginatedUrl(string $base_url, int $page): string
    {
        global $wp_rewrite;

        if ($wp_rewrite->using_permalinks()) {
            // Pretty permalinks: /category/page/2/
            return trailingslashit($base_url) . 'page/' . $page . '/';
        }

        // Default permalinks: ?paged=2
        return add_query_arg('paged', $page, $base_url);
    }
}
