<?php
/**
 * SEO Module - 404 Monitor
 *
 * Tracks 404 errors for analysis and redirect creation.
 * Creates custom table for logging 404 hits.
 *
 * @package AffiliateCMS
 * @since 4.0.0
 */

namespace AffiliateCMS\SEO;

if (!defined('ABSPATH')) {
    exit;
}

class Monitor404
{
    private static ?Monitor404 $instance = null;

    /**
     * Database table name (without prefix)
     */
    public const TABLE_NAME = 'acms_404_log';

    /**
     * Database version for migrations
     */
    private const DB_VERSION = '1.0';

    /**
     * Option name for DB version tracking
     */
    private const DB_VERSION_OPTION = 'acms_404_log_db_version';

    /**
     * Max log entries to keep (to prevent bloat)
     */
    private const MAX_LOG_ENTRIES = 100000;

    /**
     * Log retention days (90 days ~ 3 months)
     */
    private const RETENTION_DAYS = 90;

    public static function instance(): Monitor404
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct()
    {
        $this->maybeCreateTable();
        $this->registerHooks();
    }

    /**
     * Register hooks
     */
    private function registerHooks(): void
    {
        // Log 404 errors
        add_action('template_redirect', [$this, 'log404'], 99);

        // Schedule cleanup (daily)
        if (!wp_next_scheduled('acms_404_log_cleanup')) {
            wp_schedule_event(time(), 'daily', 'acms_404_log_cleanup');
        }
        add_action('acms_404_log_cleanup', [$this, 'cleanup']);
    }

    /**
     * Create database table if needed
     */
    private function maybeCreateTable(): void
    {
        $installed_version = get_option(self::DB_VERSION_OPTION, '0');

        if (version_compare($installed_version, self::DB_VERSION, '<')) {
            $this->createTable();
            update_option(self::DB_VERSION_OPTION, self::DB_VERSION);
        }
    }

    /**
     * Create the 404 log table
     */
    private function createTable(): void
    {
        global $wpdb;

        $table_name = $wpdb->prefix . self::TABLE_NAME;
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE {$table_name} (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            url varchar(2048) NOT NULL,
            url_hash char(32) NOT NULL,
            referrer varchar(2048) DEFAULT NULL,
            user_agent varchar(512) DEFAULT NULL,
            ip_address varchar(45) DEFAULT NULL,
            hit_count bigint(20) UNSIGNED NOT NULL DEFAULT 1,
            first_hit datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            last_hit datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            is_ignored tinyint(1) NOT NULL DEFAULT 0,
            redirect_created tinyint(1) NOT NULL DEFAULT 0,
            PRIMARY KEY (id),
            UNIQUE KEY url_hash (url_hash),
            KEY hit_count (hit_count),
            KEY last_hit (last_hit),
            KEY is_ignored (is_ignored)
        ) {$charset_collate};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * Log a 404 error
     */
    public function log404(): void
    {
        if (!is_404()) {
            return;
        }

        // Skip bots and common probe patterns
        $url = $this->getCurrentUrl();
        if ($this->shouldSkip($url)) {
            return;
        }

        global $wpdb;
        $table_name = $wpdb->prefix . self::TABLE_NAME;

        $url_hash = md5($url);
        $referrer = isset($_SERVER['HTTP_REFERER']) ? esc_url_raw(wp_unslash($_SERVER['HTTP_REFERER'])) : null;
        $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? substr(sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'])), 0, 512) : null;
        $ip_address = $this->getClientIp();

        // Try to update existing entry first (increment hit count)
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $exists = $wpdb->get_var(
            $wpdb->prepare("SELECT id FROM {$table_name} WHERE url_hash = %s", $url_hash)
        );

        if ($exists) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery
            $wpdb->query(
                $wpdb->prepare(
                    "UPDATE {$table_name} SET
                        hit_count = hit_count + 1,
                        last_hit = %s,
                        referrer = COALESCE(%s, referrer),
                        user_agent = COALESCE(%s, user_agent),
                        ip_address = COALESCE(%s, ip_address)
                    WHERE url_hash = %s",
                    current_time('mysql'),
                    $referrer,
                    $user_agent,
                    $ip_address,
                    $url_hash
                )
            );
        } else {
            // Insert new entry
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery
            $wpdb->insert(
                $table_name,
                [
                    'url' => $url,
                    'url_hash' => $url_hash,
                    'referrer' => $referrer,
                    'user_agent' => $user_agent,
                    'ip_address' => $ip_address,
                    'first_hit' => current_time('mysql'),
                    'last_hit' => current_time('mysql'),
                ],
                ['%s', '%s', '%s', '%s', '%s', '%s', '%s']
            );
        }
    }

    /**
     * Get current URL path
     */
    private function getCurrentUrl(): string
    {
        $request_uri = isset($_SERVER['REQUEST_URI']) ? sanitize_text_field(wp_unslash($_SERVER['REQUEST_URI'])) : '/';
        return '/' . ltrim($request_uri, '/');
    }

    /**
     * Get client IP address
     */
    private function getClientIp(): ?string
    {
        $ip = null;

        // Check for proxy headers
        $headers = [
            'HTTP_CF_CONNECTING_IP', // Cloudflare
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_REAL_IP',
            'REMOTE_ADDR',
        ];

        foreach ($headers as $header) {
            if (!empty($_SERVER[$header])) {
                $ip = sanitize_text_field(wp_unslash($_SERVER[$header]));
                // X-Forwarded-For can contain multiple IPs, get the first one
                if (strpos($ip, ',') !== false) {
                    $ip = trim(explode(',', $ip)[0]);
                }
                break;
            }
        }

        // Validate IP
        if ($ip && filter_var($ip, FILTER_VALIDATE_IP)) {
            return $ip;
        }

        return null;
    }

    /**
     * Check if URL should be skipped from logging
     */
    private function shouldSkip(string $url): bool
    {
        // Skip common probe patterns
        $skip_patterns = [
            '/wp-login.php',
            '/xmlrpc.php',
            '/wp-admin',
            '/.env',
            '/.git',
            '/wp-config',
            '/wp-includes',
            '/vendor/',
            '/node_modules/',
            '.php~',
            '.bak',
            '.sql',
            '/phpmyadmin',
            '/pma/',
            '/mysql/',
            '/admin/config',
            '/wp-json/',
            '/favicon.ico',
            '/apple-touch-icon',
            '/robots.txt',
            '/sitemap',
            '/feed/',
            '/rss/',
            '/ads.txt',
            '/app-ads.txt',
        ];

        $url_lower = strtolower($url);
        foreach ($skip_patterns as $pattern) {
            if (strpos($url_lower, strtolower($pattern)) !== false) {
                return true;
            }
        }

        // Skip common file extensions that aren't pages
        $skip_extensions = ['.map', '.woff', '.woff2', '.ttf', '.eot', '.ico'];
        foreach ($skip_extensions as $ext) {
            if (substr($url_lower, -strlen($ext)) === $ext) {
                return true;
            }
        }

        return false;
    }

    /**
     * Get all 404 logs for admin
     */
    public static function getAll(array $args = []): array
    {
        global $wpdb;
        $table_name = $wpdb->prefix . self::TABLE_NAME;

        $defaults = [
            'orderby' => 'hit_count',
            'order' => 'DESC',
            'limit' => 50,
            'offset' => 0,
            'search' => '',
            'show_ignored' => false,
        ];
        $args = wp_parse_args($args, $defaults);

        $orderby = sanitize_sql_orderby($args['orderby'] . ' ' . $args['order']) ?: 'hit_count DESC';
        $limit = absint($args['limit']);
        $offset = absint($args['offset']);

        $where = $args['show_ignored'] ? '1=1' : 'is_ignored = 0';
        $prepare_args = [];

        if (!empty($args['search'])) {
            $where .= ' AND (url LIKE %s OR referrer LIKE %s)';
            $search_term = '%' . $wpdb->esc_like($args['search']) . '%';
            $prepare_args[] = $search_term;
            $prepare_args[] = $search_term;
        }

        $sql = "SELECT * FROM {$table_name} WHERE {$where} ORDER BY {$orderby} LIMIT {$limit} OFFSET {$offset}";

        if (!empty($prepare_args)) {
            // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
            $sql = $wpdb->prepare($sql, ...$prepare_args);
        }

        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        return $wpdb->get_results($sql, ARRAY_A) ?: [];
    }

    /**
     * Get total count of 404 logs
     */
    public static function getCount(string $search = '', bool $show_ignored = false): int
    {
        global $wpdb;
        $table_name = $wpdb->prefix . self::TABLE_NAME;

        $where = $show_ignored ? '1=1' : 'is_ignored = 0';

        if (empty($search)) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            return (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table_name} WHERE {$where}");
        }

        $search_term = '%' . $wpdb->esc_like($search) . '%';
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        return (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$table_name} WHERE {$where} AND (url LIKE %s OR referrer LIKE %s)",
                $search_term,
                $search_term
            )
        );
    }

    /**
     * Get a single 404 entry by ID
     */
    public static function get(int $id): ?array
    {
        global $wpdb;
        $table_name = $wpdb->prefix . self::TABLE_NAME;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $result = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$table_name} WHERE id = %d", $id),
            ARRAY_A
        );

        return $result ?: null;
    }

    /**
     * Mark a 404 entry as ignored
     */
    public static function ignore(int $id): bool
    {
        global $wpdb;
        $table_name = $wpdb->prefix . self::TABLE_NAME;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        return (bool) $wpdb->update(
            $table_name,
            ['is_ignored' => 1],
            ['id' => $id],
            ['%d'],
            ['%d']
        );
    }

    /**
     * Mark multiple 404 entries as ignored
     */
    public static function ignoreMultiple(array $ids): int
    {
        global $wpdb;
        $table_name = $wpdb->prefix . self::TABLE_NAME;

        $ids = array_map('absint', $ids);
        $ids = array_filter($ids);

        if (empty($ids)) {
            return 0;
        }

        $placeholders = implode(',', array_fill(0, count($ids), '%d'));

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        return (int) $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$table_name} SET is_ignored = 1 WHERE id IN ({$placeholders})",
                ...$ids
            )
        );
    }

    /**
     * Delete a 404 entry
     */
    public static function delete(int $id): bool
    {
        global $wpdb;
        $table_name = $wpdb->prefix . self::TABLE_NAME;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        return (bool) $wpdb->delete($table_name, ['id' => $id], ['%d']);
    }

    /**
     * Delete multiple 404 entries
     */
    public static function deleteMultiple(array $ids): int
    {
        global $wpdb;
        $table_name = $wpdb->prefix . self::TABLE_NAME;

        $ids = array_map('absint', $ids);
        $ids = array_filter($ids);

        if (empty($ids)) {
            return 0;
        }

        $placeholders = implode(',', array_fill(0, count($ids), '%d'));

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        return (int) $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$table_name} WHERE id IN ({$placeholders})",
                ...$ids
            )
        );
    }

    /**
     * Mark a 404 entry as having a redirect created
     */
    public static function markRedirectCreated(int $id): bool
    {
        global $wpdb;
        $table_name = $wpdb->prefix . self::TABLE_NAME;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        return (bool) $wpdb->update(
            $table_name,
            ['redirect_created' => 1],
            ['id' => $id],
            ['%d'],
            ['%d']
        );
    }

    /**
     * Create redirect from a 404 entry
     */
    public static function createRedirectFrom(int $id, string $target_url, int $type = 301): int|false
    {
        $entry = self::get($id);
        if (!$entry) {
            return false;
        }

        $redirect_id = Redirects::add([
            'source_url' => $entry['url'],
            'target_url' => $target_url,
            'redirect_type' => $type,
            'notes' => sprintf(__('Created from 404 log (hits: %d)', 'affiliatecms'), $entry['hit_count']),
        ]);

        if ($redirect_id) {
            self::markRedirectCreated($id);
        }

        return $redirect_id;
    }

    /**
     * Cleanup old entries
     */
    public function cleanup(): void
    {
        global $wpdb;
        $table_name = $wpdb->prefix . self::TABLE_NAME;

        // Delete entries older than retention period
        $cutoff_date = gmdate('Y-m-d H:i:s', strtotime('-' . self::RETENTION_DAYS . ' days'));

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$table_name} WHERE last_hit < %s AND is_ignored = 0",
                $cutoff_date
            )
        );

        // If still over max entries, delete oldest ignored entries first
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $count = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table_name}");

        if ($count > self::MAX_LOG_ENTRIES) {
            $to_delete = $count - self::MAX_LOG_ENTRIES;

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery
            $wpdb->query(
                $wpdb->prepare(
                    "DELETE FROM {$table_name} WHERE is_ignored = 1 ORDER BY last_hit ASC LIMIT %d",
                    $to_delete
                )
            );
        }

        // Check again and delete oldest non-ignored if still over
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $count = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table_name}");

        if ($count > self::MAX_LOG_ENTRIES) {
            $to_delete = $count - self::MAX_LOG_ENTRIES;

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery
            $wpdb->query(
                $wpdb->prepare(
                    "DELETE FROM {$table_name} ORDER BY hit_count ASC, last_hit ASC LIMIT %d",
                    $to_delete
                )
            );
        }
    }

    /**
     * Get statistics for dashboard
     */
    public static function getStats(): array
    {
        global $wpdb;
        $table_name = $wpdb->prefix . self::TABLE_NAME;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $total = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table_name} WHERE is_ignored = 0");

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $total_hits = (int) $wpdb->get_var("SELECT SUM(hit_count) FROM {$table_name} WHERE is_ignored = 0");

        // Last 24 hours
        $yesterday = gmdate('Y-m-d H:i:s', strtotime('-24 hours'));
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $recent = (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$table_name} WHERE last_hit >= %s AND is_ignored = 0",
                $yesterday
            )
        );

        // Top 5 404s by hit count
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $top_urls = $wpdb->get_results(
            "SELECT url, hit_count FROM {$table_name} WHERE is_ignored = 0 ORDER BY hit_count DESC LIMIT 5",
            ARRAY_A
        );

        return [
            'total_urls' => $total,
            'total_hits' => $total_hits,
            'recent_24h' => $recent,
            'top_urls' => $top_urls ?: [],
        ];
    }

    /**
     * Clear all 404 logs
     */
    public static function clearAll(): bool
    {
        global $wpdb;
        $table_name = $wpdb->prefix . self::TABLE_NAME;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        return (bool) $wpdb->query("TRUNCATE TABLE {$table_name}");
    }

    // Prevent cloning
    private function __clone() {}
}
