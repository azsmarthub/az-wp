<?php
/**
 * SEO Module - Open Graph & Twitter Cards
 *
 * Handles Facebook Open Graph and Twitter Card meta tags.
 *
 * @package AffiliateCMS
 * @since 4.0.0
 */

namespace AffiliateCMS\SEO;

if (!defined('ABSPATH')) {
    exit;
}

class OpenGraph
{
    /**
     * Output Open Graph and Twitter Card meta tags
     */
    public static function output(): void
    {
        $data = self::getData();

        if (empty($data)) {
            return;
        }

        // Open Graph tags
        echo "\n<!-- Open Graph -->\n";
        self::outputTag('og:type', $data['type']);
        self::outputTag('og:title', $data['title']);
        self::outputTag('og:description', $data['description']);
        self::outputTag('og:url', $data['url']);
        self::outputTag('og:site_name', $data['site_name']);
        self::outputTag('og:locale', $data['locale']);

        if (!empty($data['image'])) {
            self::outputTag('og:image', $data['image']['url']);
            if (!empty($data['image']['width'])) {
                self::outputTag('og:image:width', $data['image']['width']);
            }
            if (!empty($data['image']['height'])) {
                self::outputTag('og:image:height', $data['image']['height']);
            }
            self::outputTag('og:image:alt', $data['image']['alt'] ?? $data['title']);
        }

        // Article specific
        if ($data['type'] === 'article') {
            if (!empty($data['published_time'])) {
                self::outputTag('article:published_time', $data['published_time']);
            }
            if (!empty($data['modified_time'])) {
                self::outputTag('article:modified_time', $data['modified_time']);
            }
            if (!empty($data['author'])) {
                self::outputTag('article:author', $data['author']);
            }
            if (!empty($data['section'])) {
                self::outputTag('article:section', $data['section']);
            }
        }

        // Twitter Card tags
        echo "\n<!-- Twitter Card -->\n";
        self::outputTag('twitter:card', $data['twitter_card']);
        self::outputTag('twitter:title', $data['title']);
        self::outputTag('twitter:description', $data['description']);

        if (!empty($data['image'])) {
            self::outputTag('twitter:image', $data['image']['url']);
            self::outputTag('twitter:image:alt', $data['image']['alt'] ?? $data['title']);
        }

        // Twitter site handle (from config)
        $twitter_url = defined('ACMS_SOCIAL_TWITTER') ? ACMS_SOCIAL_TWITTER : '';
        if ($twitter_url) {
            $handle = self::extractTwitterHandle($twitter_url);
            if ($handle) {
                self::outputTag('twitter:site', $handle);
            }
        }

        echo "\n";
    }

    /**
     * Get Open Graph data for current page
     */
    private static function getData(): array
    {
        $data = [
            'type'         => 'website',
            'title'        => MetaTags::getTitle(),
            'description'  => MetaTags::getDescription(),
            'url'          => self::getCurrentUrl(),
            'site_name'    => get_bloginfo('name'),
            'locale'       => get_locale(),
            'twitter_card' => 'summary_large_image',
            'image'        => null,
        ];

        // SEO Category page (/c/{slug}/)
        $acms_category = $GLOBALS['acms_current_category'] ?? null;
        if ($acms_category) {
            $data['type'] = 'website';
            $data['url'] = home_url('/c/' . ($acms_category['slug'] ?? '') . '/');
            $data['image'] = self::getCategoryImage($acms_category);
            return $data;
        }

        // Brand page (/brand/{slug}/)
        $acms_brand = $GLOBALS['acms_current_brand'] ?? null;
        if ($acms_brand) {
            $data['type'] = 'website';
            $data['url'] = home_url('/brand/' . ($acms_brand['slug'] ?? '') . '/');
            $data['image'] = self::getBrandImage($acms_brand);
            return $data;
        }

        // Single post/page - use article type
        if (is_singular()) {
            $post_id = get_the_ID();
            $post = get_post($post_id);

            $data['type'] = 'article';
            $data['published_time'] = get_the_date('c', $post);
            $data['modified_time'] = get_the_modified_date('c', $post);
            $data['author'] = get_the_author_meta('display_name', $post->post_author);

            // Get primary category
            $categories = get_the_category($post_id);
            if (!empty($categories)) {
                $data['section'] = $categories[0]->name;
            }

            // Image fallback: custom OG → featured image → first content image → product CDN
            $custom_image = SEO::getMeta($post_id, 'og_image');
            if ($custom_image) {
                $data['image'] = self::getImageData($custom_image);
            } elseif (has_post_thumbnail($post_id)) {
                $data['image'] = self::getFeaturedImageData($post_id);
            } else {
                // Try first image from post content
                $content_image = self::getFirstContentImage($post);
                $data['image'] = $content_image ?: self::getDefaultImage();
            }
        } else {
            // Archives, homepage, etc. - try to use site icon or default image
            $data['image'] = self::getDefaultImage();
        }

        return $data;
    }

    /**
     * Output a single meta tag
     */
    private static function outputTag(string $property, $content): void
    {
        if (empty($content)) {
            return;
        }

        // Determine if property or name attribute
        $attr = (strpos($property, 'og:') === 0 || strpos($property, 'article:') === 0)
            ? 'property'
            : 'name';

        printf(
            '<meta %s="%s" content="%s">' . "\n",
            $attr,
            esc_attr($property),
            esc_attr($content)
        );
    }

    /**
     * Get current page URL (clean, without query strings)
     */
    private static function getCurrentUrl(): string
    {
        if (is_singular()) {
            return get_permalink();
        }

        if (is_front_page() || is_home()) {
            return home_url('/');
        }

        if (is_category() || is_tag() || is_tax()) {
            $term = get_queried_object();
            if ($term) {
                return get_term_link($term);
            }
        }

        if (is_author()) {
            $author = get_queried_object();
            if ($author) {
                return get_author_posts_url($author->ID);
            }
        }

        if (is_post_type_archive()) {
            return get_post_type_archive_link(get_queried_object()->name);
        }

        // Fallback
        global $wp;
        return home_url(add_query_arg([], $wp->request));
    }

    /**
     * Get featured image data
     */
    private static function getFeaturedImageData(int $post_id): ?array
    {
        $image_id = get_post_thumbnail_id($post_id);
        if (!$image_id) {
            return null;
        }

        // Use large size for OG (1200x630 is ideal, but large is usually sufficient)
        $image = wp_get_attachment_image_src($image_id, 'large');
        if (!$image) {
            return null;
        }

        return [
            'url'    => $image[0],
            'width'  => $image[1],
            'height' => $image[2],
            'alt'    => get_post_meta($image_id, '_wp_attachment_image_alt', true) ?: get_the_title($post_id),
        ];
    }

    /**
     * Get image data from URL or attachment ID
     */
    private static function getImageData($image): ?array
    {
        // If it's a URL
        if (filter_var($image, FILTER_VALIDATE_URL)) {
            return [
                'url'    => $image,
                'width'  => null,
                'height' => null,
                'alt'    => '',
            ];
        }

        // If it's an attachment ID
        if (is_numeric($image)) {
            $src = wp_get_attachment_image_src((int) $image, 'large');
            if ($src) {
                return [
                    'url'    => $src[0],
                    'width'  => $src[1],
                    'height' => $src[2],
                    'alt'    => get_post_meta((int) $image, '_wp_attachment_image_alt', true),
                ];
            }
        }

        return null;
    }

    /**
     * Get OG image for SEO Category page
     * Fallback: featured_image_id → first product image → default
     */
    private static function getCategoryImage(array $category): ?array
    {
        // 1. Featured image (WP attachment ID)
        if (!empty($category['featured_image_id'])) {
            $img = self::getImageData($category['featured_image_id']);
            if ($img) {
                return $img;
            }
        }

        // 2. First product image from linked products
        $product_image = self::getFirstProductImage($category['id'] ?? 0, 'category');
        if ($product_image) {
            return $product_image;
        }

        // 3. Default site image
        return self::getDefaultImage();
    }

    /**
     * Get OG image for Brand page
     * Fallback: logo_url → banner_url → first product image → default
     */
    private static function getBrandImage(array $brand): ?array
    {
        // 1. Brand logo
        if (!empty($brand['logo_url'])) {
            return self::getImageData($brand['logo_url']);
        }

        // 2. Brand banner
        if (!empty($brand['banner_url'])) {
            return self::getImageData($brand['banner_url']);
        }

        // 3. First product image from brand's products
        if (!empty($brand['name'])) {
            $product_image = self::getFirstProductImage($brand['name'], 'brand');
            if ($product_image) {
                return $product_image;
            }
        }

        // 4. Default site image
        return self::getDefaultImage();
    }

    /**
     * Get first product image_url for a category or brand
     */
    private static function getFirstProductImage($identifier, string $type = 'category'): ?array
    {
        global $wpdb;
        $products_table = $wpdb->prefix . 'acms_products';
        $image_url = null;

        if ($type === 'category' && is_numeric($identifier)) {
            $cat_products_table = $wpdb->prefix . 'acms_category_products';
            $image_url = $wpdb->get_var($wpdb->prepare(
                "SELECT p.image_url FROM {$products_table} p
                 INNER JOIN {$cat_products_table} cp ON p.id = cp.product_id
                 WHERE cp.category_id = %d AND p.image_url IS NOT NULL AND p.image_url != ''
                 ORDER BY cp.position ASC LIMIT 1",
                (int) $identifier
            ));
        } elseif ($type === 'brand' && is_string($identifier)) {
            $image_url = $wpdb->get_var($wpdb->prepare(
                "SELECT image_url FROM {$products_table}
                 WHERE brand = %s AND image_url IS NOT NULL AND image_url != ''
                 AND status IN ('scraped', 'processing', 'scheduled')
                 ORDER BY rating DESC LIMIT 1",
                $identifier
            ));
        }

        if ($image_url) {
            return [
                'url'    => $image_url,
                'width'  => null,
                'height' => null,
                'alt'    => '',
            ];
        }

        return null;
    }

    /**
     * Extract first image from post content
     */
    private static function getFirstContentImage($post): ?array
    {
        if (!$post || empty($post->post_content)) {
            return null;
        }

        // Match <img src="..."> in content
        if (preg_match('/<img[^>]+src=["\']([^"\']+)["\'][^>]*>/i', $post->post_content, $matches)) {
            $url = $matches[1];
            if (filter_var($url, FILTER_VALIDATE_URL)) {
                return [
                    'url'    => $url,
                    'width'  => null,
                    'height' => null,
                    'alt'    => '',
                ];
            }
        }

        return null;
    }

    /**
     * Get default image (site icon or fallback)
     */
    private static function getDefaultImage(): ?array
    {
        // Try site icon
        if (has_site_icon()) {
            return [
                'url'    => get_site_icon_url(512),
                'width'  => 512,
                'height' => 512,
                'alt'    => get_bloginfo('name'),
            ];
        }

        // Try custom logo
        $custom_logo_id = get_theme_mod('custom_logo');
        if ($custom_logo_id) {
            $src = wp_get_attachment_image_src($custom_logo_id, 'full');
            if ($src) {
                return [
                    'url'    => $src[0],
                    'width'  => $src[1],
                    'height' => $src[2],
                    'alt'    => get_bloginfo('name'),
                ];
            }
        }

        return null;
    }

    /**
     * Extract Twitter handle from URL
     */
    private static function extractTwitterHandle(string $url): string
    {
        // Handle both twitter.com and x.com
        if (preg_match('#(?:twitter\.com|x\.com)/([a-zA-Z0-9_]+)#i', $url, $matches)) {
            return '@' . $matches[1];
        }
        return '';
    }
}
