<?php
/**
 * SEO REST API Endpoints
 *
 * Replaces legacy wp_ajax_ handlers for sitemap, redirects, and 404 management.
 *
 * @package AffiliateCMS
 * @since 4.1.0
 */

if (!defined('ABSPATH')) {
    exit;
}

use AffiliateCMS\SEO\Sitemap;
use AffiliateCMS\SEO\Redirects;
use AffiliateCMS\SEO\Monitor404;

/**
 * Register SEO REST API routes
 */
function acms_seo_register_rest_routes() {
    $namespace = 'acms/v1';

    // Sitemap
    register_rest_route($namespace, '/seo/sitemap/clear-cache', [
        'methods' => 'POST',
        'callback' => 'acms_seo_rest_clear_sitemap_cache',
        'permission_callback' => function () {
            return current_user_can('manage_options');
        },
    ]);

    // Redirects
    register_rest_route($namespace, '/seo/redirects', [
        'methods' => 'POST',
        'callback' => 'acms_seo_rest_add_redirect',
        'permission_callback' => function () {
            return current_user_can('manage_options');
        },
        'args' => [
            'source' => ['required' => true, 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field'],
            'target' => ['required' => true, 'type' => 'string', 'sanitize_callback' => 'esc_url_raw'],
            'type' => ['type' => 'integer', 'default' => 301, 'sanitize_callback' => 'absint'],
        ],
    ]);

    register_rest_route($namespace, '/seo/redirects/(?P<id>\d+)', [
        'methods' => 'DELETE',
        'callback' => 'acms_seo_rest_delete_redirect',
        'permission_callback' => function () {
            return current_user_can('manage_options');
        },
        'args' => [
            'id' => ['required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint'],
        ],
    ]);

    // 404 Monitor
    register_rest_route($namespace, '/seo/404s/(?P<id>\d+)/redirect', [
        'methods' => 'POST',
        'callback' => 'acms_seo_rest_create_redirect_from_404',
        'permission_callback' => function () {
            return current_user_can('manage_options');
        },
        'args' => [
            'id' => ['required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint'],
            'target' => ['required' => true, 'type' => 'string', 'sanitize_callback' => 'esc_url_raw'],
        ],
    ]);

    register_rest_route($namespace, '/seo/404s/(?P<id>\d+)/ignore', [
        'methods' => 'POST',
        'callback' => 'acms_seo_rest_ignore_404',
        'permission_callback' => function () {
            return current_user_can('manage_options');
        },
        'args' => [
            'id' => ['required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint'],
        ],
    ]);

    register_rest_route($namespace, '/seo/404s/(?P<id>\d+)', [
        'methods' => 'DELETE',
        'callback' => 'acms_seo_rest_delete_404',
        'permission_callback' => function () {
            return current_user_can('manage_options');
        },
        'args' => [
            'id' => ['required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint'],
        ],
    ]);

    register_rest_route($namespace, '/seo/404s', [
        'methods' => 'DELETE',
        'callback' => 'acms_seo_rest_clear_404_logs',
        'permission_callback' => function () {
            return current_user_can('manage_options');
        },
    ]);
}
add_action('rest_api_init', 'acms_seo_register_rest_routes');

// --- Callbacks ---

function acms_seo_rest_clear_sitemap_cache() {
    Sitemap::clearCache();
    delete_transient('acms_global_schema');
    return new WP_REST_Response(['success' => true]);
}

function acms_seo_rest_add_redirect($request) {
    $source = $request->get_param('source');
    $target = $request->get_param('target');
    $type = $request->get_param('type');

    if (Redirects::sourceExists($source)) {
        return new WP_Error('duplicate', __('A redirect for this source URL already exists', 'affiliatecms'), ['status' => 409]);
    }

    $result = Redirects::add([
        'source_url' => $source,
        'target_url' => $target,
        'redirect_type' => $type,
    ]);

    if ($result) {
        return new WP_REST_Response(['success' => true, 'id' => $result]);
    }

    return new WP_Error('failed', __('Failed to add redirect', 'affiliatecms'), ['status' => 500]);
}

function acms_seo_rest_delete_redirect($request) {
    $id = $request->get_param('id');
    if (Redirects::delete($id)) {
        return new WP_REST_Response(['success' => true]);
    }
    return new WP_Error('failed', __('Failed to delete redirect', 'affiliatecms'), ['status' => 500]);
}

function acms_seo_rest_create_redirect_from_404($request) {
    $id = $request->get_param('id');
    $target = $request->get_param('target');

    $result = Monitor404::createRedirectFrom($id, $target);
    if ($result) {
        return new WP_REST_Response(['success' => true, 'redirect_id' => $result]);
    }

    return new WP_Error('failed', __('Failed to create redirect', 'affiliatecms'), ['status' => 500]);
}

function acms_seo_rest_ignore_404($request) {
    $id = $request->get_param('id');
    if (Monitor404::ignore($id)) {
        return new WP_REST_Response(['success' => true]);
    }
    return new WP_Error('failed', __('Failed to ignore entry', 'affiliatecms'), ['status' => 500]);
}

function acms_seo_rest_delete_404($request) {
    $id = $request->get_param('id');
    if (Monitor404::delete($id)) {
        return new WP_REST_Response(['success' => true]);
    }
    return new WP_Error('failed', __('Failed to delete entry', 'affiliatecms'), ['status' => 500]);
}

function acms_seo_rest_clear_404_logs() {
    if (Monitor404::clearAll()) {
        return new WP_REST_Response(['success' => true]);
    }
    return new WP_Error('failed', __('Failed to clear logs', 'affiliatecms'), ['status' => 500]);
}
