<?php
/**
 * SEO Module - Meta Tags
 *
 * Handles title, description, and robots meta tags.
 *
 * @package AffiliateCMS
 * @since 4.0.0
 */

namespace AffiliateCMS\SEO;

if (!defined('ABSPATH')) {
    exit;
}

class MetaTags
{
    /**
     * Output all meta tags
     */
    public static function output(): void
    {
        echo '<title>' . esc_html(self::getTitle()) . '</title>' . "\n";

        $description = self::getDescription();
        if ($description) {
            echo '<meta name="description" content="' . esc_attr($description) . '">' . "\n";
        }

        $robots = self::getRobots();
        if ($robots) {
            echo '<meta name="robots" content="' . esc_attr($robots) . '">' . "\n";
        }
    }

    /**
     * Get SEO title for current page
     */
    public static function getTitle(): string
    {
        $site_name = get_bloginfo('name');
        // sanitize_text_field() strips leading/trailing spaces, so re-pad
        $separator = ' ' . trim(AdminPage::get('title_separator', '|')) . ' ';

        // SEO Category page (/c/{slug}/)
        $acms_category = $GLOBALS['acms_current_category'] ?? null;
        if ($acms_category) {
            $is_brand_cat = !empty($acms_category['brand_id']);

            if ($is_brand_cat) {
                // Brand-category: fixed format — "{count} Best {Brand} {Keyword} of {year} - Site"
                // Ignore seo_title from AI — always use fixed format
                $brand_name = '';
                if (class_exists(\AffiliateCMS\Pro\Repositories\BrandRepository::class)) {
                    $brand_data = \AffiliateCMS\Pro\Repositories\BrandRepository::instance()->find((int) $acms_category['brand_id']);
                    $brand_name = $brand_data['name'] ?? '';
                }
                // Parent = keyword (e.g., "Gaming PCs")
                $parent_keyword = '';
                if (!empty($acms_category['parent_id']) && class_exists(\AffiliateCMS\Categories\Repositories\CategoryRepository::class)) {
                    $parent_cat = (new \AffiliateCMS\Categories\Repositories\CategoryRepository())->find((int) $acms_category['parent_id']);
                    $parent_keyword = $parent_cat['name'] ?? '';
                }
                if (!$parent_keyword && $brand_name) {
                    $parent_keyword = trim(str_ireplace($brand_name, '', $acms_category['name'] ?? ''));
                }
                $count = (int) ($acms_category['product_count'] ?? 0);
                return $count . ' Best ' . $brand_name . ' ' . $parent_keyword . ' of ' . date('Y') . $separator . $site_name;
            }

            // Queue keyword = has products + no regular (non-brand) children
            // Parent path = has regular children (e.g., "Headphones" contains "Gaming Headphones")
            global $wpdb;
            $cat_name = $acms_category['name'] ?? '';
            $count = (int) ($acms_category['product_count'] ?? 0);
            $cat_table = $wpdb->prefix . 'acms_categories';
            $has_regular_children = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$cat_table} WHERE parent_id = %d AND brand_id IS NULL AND status = 'publish'",
                (int) $acms_category['id']
            ));
            $is_queue_keyword = $count > 0 && $has_regular_children === 0;

            if ($is_queue_keyword) {
                // Queue keyword: "{count} Best {Name} of {year} - SiteName"
                return $count . ' Best ' . $cat_name . ' of ' . date('Y') . $separator . $site_name;
            }

            // Parent category: "SiteName: Category of {year}"
            return $site_name . ': ' . $cat_name . ' of ' . date('Y');
        }

        // Brand page (/brand/{slug}/) — fixed format: "SiteName: {Brand} Reviews of {year}"
        $acms_brand = $GLOBALS['acms_current_brand'] ?? null;
        if ($acms_brand) {
            $brand_name = $acms_brand['name'] ?? '';
            return $site_name . ': ' . $brand_name . ' Reviews of ' . date('Y');
        }

        // Single post/page - check custom meta first
        if (is_singular()) {
            $post_id = get_the_ID();
            $post = get_post($post_id);

            // Priority 1: Custom SEO title from post meta
            $custom_title = SEO::getMeta($post_id, 'title');
            if ($custom_title) {
                return Placeholders::replace($custom_title);
            }

            // Priority 2: Template from settings (CPT-specific)
            $template_map = [
                'page'          => 'tpl_page_title',
                'acms_reviews'  => 'tpl_review_title',
                'acms_deals'    => 'tpl_deal_title',
                'acms_guides'   => 'tpl_guide_title',
            ];
            $template_key = $template_map[$post->post_type] ?? 'tpl_post_title';
            $template = AdminPage::get($template_key, '');
            if ($template) {
                return Placeholders::replace($template);
            }

            // Default: Post Title | Site Name
            return get_the_title() . $separator . $site_name;
        }

        // Homepage
        if (is_front_page() || is_home()) {
            $homepage_title = AdminPage::get('homepage_title', '');
            if ($homepage_title) {
                return Placeholders::replace($homepage_title);
            }

            $tagline = get_bloginfo('description');
            if ($tagline) {
                return $site_name . $separator . $tagline;
            }
            return $site_name;
        }

        // Category archive
        if (is_category()) {
            $template = AdminPage::get('tpl_category_title', '');
            if ($template) {
                return Placeholders::replace($template);
            }
            $term = get_queried_object();
            return ($term ? $term->name : '') . $separator . $site_name;
        }

        // Tag archive
        if (is_tag()) {
            $term = get_queried_object();
            return ($term ? $term->name : '') . $separator . $site_name;
        }

        // Custom taxonomy archive (brand, etc.)
        if (is_tax()) {
            $template = AdminPage::get('tpl_category_title', '');
            if ($template) {
                return Placeholders::replace($template);
            }
            $term = get_queried_object();
            return ($term ? $term->name : '') . $separator . $site_name;
        }

        // Author archive
        if (is_author()) {
            $author = get_queried_object();
            if ($author && isset($author->display_name)) {
                return sprintf(__('Posts by %s', 'affiliatecms'), $author->display_name) . $separator . $site_name;
            }
        }

        // Date archives
        if (is_date()) {
            if (is_day()) {
                return get_the_date() . $separator . $site_name;
            }
            if (is_month()) {
                return get_the_date('F Y') . $separator . $site_name;
            }
            if (is_year()) {
                return get_the_date('Y') . $separator . $site_name;
            }
        }

        // Search results
        if (is_search()) {
            $template = AdminPage::get('tpl_search_title', '');
            if ($template) {
                return Placeholders::replace($template);
            }
            return sprintf(__('Search: %s', 'affiliatecms'), get_search_query()) . $separator . $site_name;
        }

        // 404
        if (is_404()) {
            $template = AdminPage::get('tpl_404_title', '');
            if ($template) {
                return Placeholders::replace($template);
            }
            return __('Page Not Found', 'affiliatecms') . $separator . $site_name;
        }

        // Post type archive
        if (is_post_type_archive()) {
            $post_type = get_queried_object();
            if ($post_type && isset($post_type->label)) {
                return $post_type->label . $separator . $site_name;
            }
        }

        // Fallback
        return $site_name;
    }

    /**
     * Get SEO description for current page
     */
    public static function getDescription(): string
    {
        // SEO Category page (/c/{slug}/)
        $acms_category = $GLOBALS['acms_current_category'] ?? null;
        if ($acms_category) {
            if (!empty($acms_category['seo_description'])) {
                return self::truncateDescription(Placeholders::replace($acms_category['seo_description']));
            }
            if (!empty($acms_category['description'])) {
                return self::truncateDescription(Placeholders::replace($acms_category['description']));
            }
            return '';
        }

        // Brand page (/brand/{slug}/)
        $acms_brand = $GLOBALS['acms_current_brand'] ?? null;
        if ($acms_brand) {
            if (!empty($acms_brand['seo_description'])) {
                return self::truncateDescription(Placeholders::replace($acms_brand['seo_description']));
            }
            if (!empty($acms_brand['description'])) {
                return self::truncateDescription(Placeholders::replace($acms_brand['description']));
            }
            return '';
        }

        // Single post/page
        if (is_singular()) {
            $post_id = get_the_ID();
            $post = get_post($post_id);

            // Priority 1: Custom SEO description from post meta
            $custom_desc = SEO::getMeta($post_id, 'description');
            if ($custom_desc) {
                return Placeholders::replace($custom_desc);
            }

            // Priority 2: Template from settings (CPT-specific)
            $desc_map = [
                'page'          => 'tpl_page_desc',
                'acms_reviews'  => 'tpl_review_desc',
                'acms_deals'    => 'tpl_deal_desc',
                'acms_guides'   => 'tpl_guide_desc',
            ];
            $desc_key = $desc_map[$post->post_type ?? ''] ?? 'tpl_post_desc';
            $template = AdminPage::get($desc_key, '');
            if ($template) {
                return self::truncateDescription(Placeholders::replace($template));
            }

            // Use excerpt if available
            $excerpt = get_the_excerpt();
            if ($excerpt) {
                return self::truncateDescription($excerpt);
            }

            // Fallback to content
            if ($post) {
                $content = wp_strip_all_tags($post->post_content);
                return self::truncateDescription($content);
            }

            return '';
        }

        // Homepage
        if (is_front_page() || is_home()) {
            $homepage_desc = AdminPage::get('homepage_description', '');
            if ($homepage_desc) {
                return Placeholders::replace($homepage_desc);
            }
            return get_bloginfo('description') ?: '';
        }

        // Category/Tag/Taxonomy
        if (is_category() || is_tag() || is_tax()) {
            // Priority 1: Template from settings
            $template = AdminPage::get('tpl_category_desc', '');
            if ($template) {
                return self::truncateDescription(Placeholders::replace($template));
            }

            // Priority 2: Term description
            $term = get_queried_object();
            if ($term && !empty($term->description)) {
                return self::truncateDescription($term->description);
            }
            if ($term && isset($term->name)) {
                return sprintf(__('Browse all posts in %s category.', 'affiliatecms'), $term->name);
            }
        }

        // Author archive
        if (is_author()) {
            $author = get_queried_object();
            if ($author) {
                $bio = get_the_author_meta('description', $author->ID);
                if ($bio) {
                    return self::truncateDescription($bio);
                }
                return sprintf(
                    __('View all posts by %s.', 'affiliatecms'),
                    $author->display_name
                );
            }
        }

        // Search results
        if (is_search()) {
            $template = AdminPage::get('tpl_search_desc', '');
            if ($template) {
                return self::truncateDescription(Placeholders::replace($template));
            }
            global $wp_query;
            return sprintf(
                __('Found %d results for "%s".', 'affiliatecms'),
                $wp_query->found_posts,
                get_search_query()
            );
        }

        // Post type archive
        if (is_post_type_archive()) {
            $post_type = get_queried_object();
            if ($post_type && isset($post_type->description) && $post_type->description) {
                return self::truncateDescription($post_type->description);
            }
        }

        return '';
    }

    /**
     * Get robots meta tag value
     */
    public static function getRobots(): string
    {
        $robots = [];

        // Check for custom robots on singular
        if (is_singular()) {
            $post_id = get_the_ID();
            $custom_robots = SEO::getMeta($post_id, 'robots');
            if ($custom_robots) {
                return $custom_robots;
            }
        }

        // Noindex pagination (page 2+)
        if (is_paged() && AdminPage::get('noindex_pagination', 1)) {
            $robots[] = 'noindex';
            $robots[] = 'follow';
        }

        // Noindex search results
        if (is_search() && AdminPage::get('noindex_search', 1)) {
            $robots[] = 'noindex';
            $robots[] = 'follow';
        }

        // Noindex 404 (always)
        if (is_404()) {
            $robots[] = 'noindex';
            $robots[] = 'nofollow';
        }

        // Noindex date archives
        if (is_date() && AdminPage::get('noindex_archives', 1)) {
            $robots[] = 'noindex';
            $robots[] = 'follow';
        }

        // Noindex author archives with no posts
        if (is_author() && AdminPage::get('noindex_author', 1)) {
            global $wp_query;
            if ($wp_query->found_posts === 0) {
                $robots[] = 'noindex';
                $robots[] = 'follow';
            }
        }

        // Empty means index,follow (browser default)
        return implode(', ', $robots);
    }

    /**
     * Truncate description to optimal length for SEO (120-160 chars)
     */
    private static function truncateDescription(string $text, int $length = 155): string
    {
        // Strip shortcodes and tags
        $text = strip_shortcodes($text);
        $text = wp_strip_all_tags($text);

        // Normalize whitespace
        $text = preg_replace('/\s+/', ' ', $text);
        $text = trim($text);

        if (mb_strlen($text) <= $length) {
            return $text;
        }

        // Truncate to length, but try to end at a word boundary
        $text = mb_substr($text, 0, $length);
        $last_space = mb_strrpos($text, ' ');

        if ($last_space !== false && $last_space > $length - 30) {
            $text = mb_substr($text, 0, $last_space);
        }

        return $text . '...';
    }
}
