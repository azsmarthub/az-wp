<?php
/**
 * SEO Module - Link Filters
 *
 * Handles automatic link attribute modifications:
 * - External links: nofollow, noopener, target="_blank"
 * - Internal links: nofollow for tags, attachments, author, login
 *
 * @package AffiliateCMS
 * @since 4.0.0
 */

namespace AffiliateCMS\SEO;

if (!defined('ABSPATH')) {
    exit;
}

class LinkFilters
{
    private static ?LinkFilters $instance = null;

    /**
     * Site host for comparing external vs internal links
     */
    private string $site_host;

    /**
     * Excluded domains from nofollow (lowercased)
     */
    private array $excluded_domains = [];

    public static function instance(): LinkFilters
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct()
    {
        // Get site host
        $this->site_host = strtolower((string) wp_parse_url(home_url(), PHP_URL_HOST));

        // Parse excluded domains
        $exclude_setting = AdminPage::get('external_exclude', '');
        if (!empty($exclude_setting)) {
            $domains = array_filter(array_map('trim', explode("\n", $exclude_setting)));
            $this->excluded_domains = array_map('strtolower', $domains);
        }

        $this->registerHooks();
    }

    /**
     * Register hooks
     */
    private function registerHooks(): void
    {
        // Filter post content
        add_filter('the_content', [$this, 'processContent'], 99);

        // Filter comment text
        add_filter('comment_text', [$this, 'processContent'], 99);

        // Filter widget text
        add_filter('widget_text_content', [$this, 'processContent'], 99);

        // Filter excerpt (optional, usually no links but just in case)
        add_filter('the_excerpt', [$this, 'processContent'], 99);

        // Tag links
        if (AdminPage::get('nofollow_tags', 0)) {
            add_filter('term_links-post_tag', [$this, 'addNofollowToTermLinks'], 10);
        }

        // Author link
        if (AdminPage::get('nofollow_author', 0)) {
            add_filter('the_author_posts_link', [$this, 'addNofollowToLink'], 10);
            add_filter('author_link', [$this, 'modifyAuthorLink'], 10, 3);
        }

        // Attachment links
        if (AdminPage::get('nofollow_attachments', 0)) {
            add_filter('wp_get_attachment_link', [$this, 'addNofollowToLink'], 10);
        }

        // Login/Register links
        if (AdminPage::get('nofollow_login', 0)) {
            add_filter('login_url', [$this, 'markLoginUrl'], 10);
            add_filter('register_url', [$this, 'markLoginUrl'], 10);
            add_filter('lostpassword_url', [$this, 'markLoginUrl'], 10);
        }
    }

    /**
     * Process content and modify links
     */
    public function processContent(string $content): string
    {
        if (empty($content) || strpos($content, '<a') === false) {
            return $content;
        }

        // Check if any link modifications are enabled
        $external_nofollow = AdminPage::get('external_nofollow', 0);
        $external_noopener = AdminPage::get('external_noopener', 0);
        $external_blank = AdminPage::get('external_blank', 0);

        if (!$external_nofollow && !$external_noopener && !$external_blank) {
            return $content;
        }

        // Use regex to find and modify links
        $pattern = '/<a\s+([^>]*)>/i';

        return preg_replace_callback($pattern, function ($matches) use ($external_nofollow, $external_noopener, $external_blank) {
            $attributes = $matches[1];

            // Extract href
            if (!preg_match('/href\s*=\s*["\']([^"\']+)["\']/i', $attributes, $href_match)) {
                return $matches[0]; // No href, return unchanged
            }

            $url = $href_match[1];

            // Skip non-http links (mailto, tel, javascript, #anchor)
            if (preg_match('/^(mailto:|tel:|javascript:|#)/i', $url)) {
                return $matches[0];
            }

            // Check if external
            $is_external = $this->isExternalUrl($url);

            if (!$is_external) {
                return $matches[0]; // Internal link, skip
            }

            // Check if domain is excluded
            if ($this->isDomainExcluded($url)) {
                return $matches[0];
            }

            // Build new rel attribute
            $new_rel_parts = [];

            // Get existing rel
            if (preg_match('/rel\s*=\s*["\']([^"\']+)["\']/i', $attributes, $rel_match)) {
                $existing_rel = array_filter(array_map('trim', explode(' ', $rel_match[1])));
                $new_rel_parts = $existing_rel;
            }

            // Add nofollow
            if ($external_nofollow && !in_array('nofollow', $new_rel_parts)) {
                $new_rel_parts[] = 'nofollow';
            }

            // Add noopener noreferrer
            if ($external_noopener) {
                if (!in_array('noopener', $new_rel_parts)) {
                    $new_rel_parts[] = 'noopener';
                }
                if (!in_array('noreferrer', $new_rel_parts)) {
                    $new_rel_parts[] = 'noreferrer';
                }
            }

            // Update or add rel attribute
            $new_rel = implode(' ', array_unique($new_rel_parts));
            if (preg_match('/rel\s*=\s*["\'][^"\']*["\']/i', $attributes)) {
                $attributes = preg_replace('/rel\s*=\s*["\'][^"\']*["\']/i', 'rel="' . esc_attr($new_rel) . '"', $attributes);
            } elseif (!empty($new_rel)) {
                $attributes .= ' rel="' . esc_attr($new_rel) . '"';
            }

            // Add target="_blank"
            if ($external_blank && !preg_match('/target\s*=/i', $attributes)) {
                $attributes .= ' target="_blank"';
            }

            return '<a ' . $attributes . '>';
        }, $content);
    }

    /**
     * Check if URL is external
     */
    private function isExternalUrl(string $url): bool
    {
        // Relative URLs are internal
        if (strpos($url, '//') === false && strpos($url, '/') === 0) {
            return false;
        }

        $parsed = wp_parse_url($url);
        if (!isset($parsed['host'])) {
            return false; // Relative URL
        }

        $link_host = strtolower($parsed['host']);

        // Compare hosts
        return $link_host !== $this->site_host && !str_ends_with($link_host, '.' . $this->site_host);
    }

    /**
     * Check if URL domain is in excluded list
     */
    private function isDomainExcluded(string $url): bool
    {
        if (empty($this->excluded_domains)) {
            return false;
        }

        $parsed = wp_parse_url($url);
        if (!isset($parsed['host'])) {
            return false;
        }

        $link_host = strtolower($parsed['host']);

        foreach ($this->excluded_domains as $domain) {
            if ($link_host === $domain || str_ends_with($link_host, '.' . $domain)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Add nofollow to a link HTML string
     */
    public function addNofollowToLink(string $link): string
    {
        if (empty($link) || strpos($link, '<a') === false) {
            return $link;
        }

        // Check if already has nofollow
        if (stripos($link, 'nofollow') !== false) {
            return $link;
        }

        // Check if has rel attribute
        if (preg_match('/rel\s*=\s*["\']([^"\']+)["\']/i', $link, $match)) {
            $new_rel = trim($match[1]) . ' nofollow';
            return preg_replace('/rel\s*=\s*["\'][^"\']*["\']/i', 'rel="' . esc_attr($new_rel) . '"', $link);
        }

        // Add rel="nofollow"
        return preg_replace('/<a\s+/i', '<a rel="nofollow" ', $link);
    }

    /**
     * Add nofollow to term links array (tags)
     */
    public function addNofollowToTermLinks(array $links): array
    {
        return array_map([$this, 'addNofollowToLink'], $links);
    }

    /**
     * Modify author link to add nofollow (used with get_author_posts_url)
     */
    public function modifyAuthorLink(string $link, int $author_id, string $author_nicename): string
    {
        return $link; // URL only, actual modification happens in addNofollowToLink
    }

    /**
     * Mark login URLs for potential nofollow (if output in links)
     * Note: This doesn't add nofollow directly but the URL can be tracked
     */
    public function markLoginUrl(string $url): string
    {
        return $url;
    }

    /**
     * Add nofollow to login/register form links
     * This is called via the_content filter if login links appear in content
     * Most login links are in templates, so we also provide a helper
     */
    public static function getLoginLinkWithNofollow(string $text, string $url = ''): string
    {
        if (empty($url)) {
            $url = wp_login_url();
        }
        return '<a href="' . esc_url($url) . '" rel="nofollow">' . esc_html($text) . '</a>';
    }

    /**
     * Get register link with nofollow
     */
    public static function getRegisterLinkWithNofollow(string $text): string
    {
        if (!get_option('users_can_register')) {
            return '';
        }
        return '<a href="' . esc_url(wp_registration_url()) . '" rel="nofollow">' . esc_html($text) . '</a>';
    }

    // Prevent cloning
    private function __clone() {}
}
