<?php
/**
 * SEO Module - Redirects Manager
 *
 * Handles 301/302 redirects with database storage.
 * Creates custom table for storing redirect rules.
 *
 * @package AffiliateCMS
 * @since 4.0.0
 */

namespace AffiliateCMS\SEO;

if (!defined('ABSPATH')) {
    exit;
}

class Redirects
{
    private static ?Redirects $instance = null;

    /**
     * Database table name (without prefix)
     */
    public const TABLE_NAME = 'acms_redirects';

    /**
     * Database version for migrations
     */
    private const DB_VERSION = '1.0';

    /**
     * Option name for DB version tracking
     */
    private const DB_VERSION_OPTION = 'acms_redirects_db_version';

    /**
     * Cached redirects for performance
     */
    private static ?array $redirects_cache = null;

    public static function instance(): Redirects
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct()
    {
        $this->maybeCreateTable();
        $this->registerHooks();
    }

    /**
     * Register redirect hooks
     */
    private function registerHooks(): void
    {
        // Check for redirects early (priority 1)
        add_action('template_redirect', [$this, 'checkRedirect'], 1);
    }

    /**
     * Create database table if needed
     */
    private function maybeCreateTable(): void
    {
        $installed_version = get_option(self::DB_VERSION_OPTION, '0');

        if (version_compare($installed_version, self::DB_VERSION, '<')) {
            $this->createTable();
            update_option(self::DB_VERSION_OPTION, self::DB_VERSION);
        }
    }

    /**
     * Create the redirects table
     */
    private function createTable(): void
    {
        global $wpdb;

        $table_name = $wpdb->prefix . self::TABLE_NAME;
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE {$table_name} (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            source_url varchar(2048) NOT NULL,
            source_url_hash char(32) NOT NULL,
            target_url varchar(2048) NOT NULL,
            redirect_type smallint(3) NOT NULL DEFAULT 301,
            hit_count bigint(20) UNSIGNED NOT NULL DEFAULT 0,
            last_hit datetime DEFAULT NULL,
            is_regex tinyint(1) NOT NULL DEFAULT 0,
            is_active tinyint(1) NOT NULL DEFAULT 1,
            notes text DEFAULT NULL,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY source_url_hash (source_url_hash),
            KEY is_active (is_active),
            KEY redirect_type (redirect_type)
        ) {$charset_collate};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * Check if current URL has a redirect
     */
    public function checkRedirect(): void
    {
        // Skip admin and AJAX
        if (is_admin() || wp_doing_ajax()) {
            return;
        }

        $current_url = $this->getCurrentUrl();
        $redirect = $this->findRedirect($current_url);

        if ($redirect) {
            // Update hit count
            $this->incrementHitCount($redirect['id']);

            // Perform redirect
            wp_redirect($redirect['target_url'], $redirect['redirect_type']);
            exit;
        }
    }

    /**
     * Get current URL path (without domain)
     */
    private function getCurrentUrl(): string
    {
        $request_uri = isset($_SERVER['REQUEST_URI']) ? sanitize_text_field(wp_unslash($_SERVER['REQUEST_URI'])) : '/';

        // Normalize: ensure leading slash, remove trailing slash (except for root)
        $url = '/' . ltrim($request_uri, '/');
        if ($url !== '/' && substr($url, -1) === '/') {
            $url = rtrim($url, '/');
        }

        return $url;
    }

    /**
     * Find a matching redirect for the given URL
     */
    private function findRedirect(string $url): ?array
    {
        $redirects = $this->getAllActive();

        // First, try exact match (faster)
        $url_hash = md5($url);
        foreach ($redirects as $redirect) {
            if (!$redirect['is_regex'] && $redirect['source_url_hash'] === $url_hash) {
                return $redirect;
            }
        }

        // Also try with/without trailing slash
        $url_alt = (substr($url, -1) === '/') ? rtrim($url, '/') : $url . '/';
        $url_alt_hash = md5($url_alt);
        foreach ($redirects as $redirect) {
            if (!$redirect['is_regex'] && $redirect['source_url_hash'] === $url_alt_hash) {
                return $redirect;
            }
        }

        // Then try regex matches
        foreach ($redirects as $redirect) {
            if ($redirect['is_regex']) {
                $pattern = '@^' . $redirect['source_url'] . '$@i';
                if (@preg_match($pattern, $url)) {
                    // For regex, we may need to do replacement
                    $target = @preg_replace($pattern, $redirect['target_url'], $url);
                    if ($target && $target !== $url) {
                        $redirect['target_url'] = $target;
                        return $redirect;
                    }
                }
            }
        }

        return null;
    }

    /**
     * Get all active redirects (cached)
     */
    public function getAllActive(): array
    {
        if (self::$redirects_cache !== null) {
            return self::$redirects_cache;
        }

        global $wpdb;
        $table_name = $wpdb->prefix . self::TABLE_NAME;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $results = $wpdb->get_results(
            "SELECT * FROM {$table_name} WHERE is_active = 1 ORDER BY is_regex ASC, id ASC",
            ARRAY_A
        );

        self::$redirects_cache = $results ?: [];

        return self::$redirects_cache;
    }

    /**
     * Get all redirects (for admin)
     */
    public static function getAll(array $args = []): array
    {
        global $wpdb;
        $table_name = $wpdb->prefix . self::TABLE_NAME;

        $defaults = [
            'orderby' => 'created_at',
            'order' => 'DESC',
            'limit' => 50,
            'offset' => 0,
            'search' => '',
        ];
        $args = wp_parse_args($args, $defaults);

        $orderby = sanitize_sql_orderby($args['orderby'] . ' ' . $args['order']) ?: 'created_at DESC';
        $limit = absint($args['limit']);
        $offset = absint($args['offset']);

        $where = '1=1';
        $prepare_args = [];

        if (!empty($args['search'])) {
            $where .= ' AND (source_url LIKE %s OR target_url LIKE %s OR notes LIKE %s)';
            $search_term = '%' . $wpdb->esc_like($args['search']) . '%';
            $prepare_args[] = $search_term;
            $prepare_args[] = $search_term;
            $prepare_args[] = $search_term;
        }

        $sql = "SELECT * FROM {$table_name} WHERE {$where} ORDER BY {$orderby} LIMIT {$limit} OFFSET {$offset}";

        if (!empty($prepare_args)) {
            // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
            $sql = $wpdb->prepare($sql, ...$prepare_args);
        }

        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        return $wpdb->get_results($sql, ARRAY_A) ?: [];
    }

    /**
     * Get total count of redirects
     */
    public static function getCount(string $search = ''): int
    {
        global $wpdb;
        $table_name = $wpdb->prefix . self::TABLE_NAME;

        if (empty($search)) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery
            return (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table_name}");
        }

        $search_term = '%' . $wpdb->esc_like($search) . '%';
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        return (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$table_name} WHERE source_url LIKE %s OR target_url LIKE %s OR notes LIKE %s",
                $search_term,
                $search_term,
                $search_term
            )
        );
    }

    /**
     * Add a new redirect
     */
    public static function add(array $data): int|false
    {
        global $wpdb;
        $table_name = $wpdb->prefix . self::TABLE_NAME;

        // Validate required fields
        if (empty($data['source_url']) || empty($data['target_url'])) {
            return false;
        }

        // Normalize source URL
        $source_url = '/' . ltrim($data['source_url'], '/');
        if ($source_url !== '/' && substr($source_url, -1) === '/') {
            $source_url = rtrim($source_url, '/');
        }

        $insert_data = [
            'source_url' => $source_url,
            'source_url_hash' => md5($source_url),
            'target_url' => esc_url_raw($data['target_url']),
            'redirect_type' => isset($data['redirect_type']) ? absint($data['redirect_type']) : 301,
            'is_regex' => !empty($data['is_regex']) ? 1 : 0,
            'is_active' => isset($data['is_active']) ? absint($data['is_active']) : 1,
            'notes' => isset($data['notes']) ? sanitize_textarea_field($data['notes']) : '',
        ];

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $result = $wpdb->insert($table_name, $insert_data, [
            '%s', '%s', '%s', '%d', '%d', '%d', '%s'
        ]);

        if ($result) {
            self::clearCache();
            return $wpdb->insert_id;
        }

        return false;
    }

    /**
     * Update a redirect
     */
    public static function update(int $id, array $data): bool
    {
        global $wpdb;
        $table_name = $wpdb->prefix . self::TABLE_NAME;

        $update_data = [];
        $format = [];

        if (isset($data['source_url'])) {
            $source_url = '/' . ltrim($data['source_url'], '/');
            if ($source_url !== '/' && substr($source_url, -1) === '/') {
                $source_url = rtrim($source_url, '/');
            }
            $update_data['source_url'] = $source_url;
            $update_data['source_url_hash'] = md5($source_url);
            $format[] = '%s';
            $format[] = '%s';
        }

        if (isset($data['target_url'])) {
            $update_data['target_url'] = esc_url_raw($data['target_url']);
            $format[] = '%s';
        }

        if (isset($data['redirect_type'])) {
            $update_data['redirect_type'] = absint($data['redirect_type']);
            $format[] = '%d';
        }

        if (isset($data['is_regex'])) {
            $update_data['is_regex'] = $data['is_regex'] ? 1 : 0;
            $format[] = '%d';
        }

        if (isset($data['is_active'])) {
            $update_data['is_active'] = $data['is_active'] ? 1 : 0;
            $format[] = '%d';
        }

        if (isset($data['notes'])) {
            $update_data['notes'] = sanitize_textarea_field($data['notes']);
            $format[] = '%s';
        }

        if (empty($update_data)) {
            return false;
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $result = $wpdb->update($table_name, $update_data, ['id' => $id], $format, ['%d']);

        if ($result !== false) {
            self::clearCache();
            return true;
        }

        return false;
    }

    /**
     * Delete a redirect
     */
    public static function delete(int $id): bool
    {
        global $wpdb;
        $table_name = $wpdb->prefix . self::TABLE_NAME;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $result = $wpdb->delete($table_name, ['id' => $id], ['%d']);

        if ($result) {
            self::clearCache();
            return true;
        }

        return false;
    }

    /**
     * Delete multiple redirects
     */
    public static function deleteMultiple(array $ids): int
    {
        global $wpdb;
        $table_name = $wpdb->prefix . self::TABLE_NAME;

        $ids = array_map('absint', $ids);
        $ids = array_filter($ids);

        if (empty($ids)) {
            return 0;
        }

        $placeholders = implode(',', array_fill(0, count($ids), '%d'));

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $result = $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$table_name} WHERE id IN ({$placeholders})",
                ...$ids
            )
        );

        if ($result > 0) {
            self::clearCache();
        }

        return $result ?: 0;
    }

    /**
     * Increment hit count for a redirect
     */
    private function incrementHitCount(int $id): void
    {
        global $wpdb;
        $table_name = $wpdb->prefix . self::TABLE_NAME;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$table_name} SET hit_count = hit_count + 1, last_hit = %s WHERE id = %d",
                current_time('mysql'),
                $id
            )
        );
    }

    /**
     * Get a single redirect by ID
     */
    public static function get(int $id): ?array
    {
        global $wpdb;
        $table_name = $wpdb->prefix . self::TABLE_NAME;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $result = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$table_name} WHERE id = %d", $id),
            ARRAY_A
        );

        return $result ?: null;
    }

    /**
     * Check if a source URL already exists
     */
    public static function sourceExists(string $source_url, ?int $exclude_id = null): bool
    {
        global $wpdb;
        $table_name = $wpdb->prefix . self::TABLE_NAME;

        $source_url = '/' . ltrim($source_url, '/');
        if ($source_url !== '/' && substr($source_url, -1) === '/') {
            $source_url = rtrim($source_url, '/');
        }
        $hash = md5($source_url);

        if ($exclude_id) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery
            return (bool) $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$table_name} WHERE source_url_hash = %s AND id != %d",
                    $hash,
                    $exclude_id
                )
            );
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        return (bool) $wpdb->get_var(
            $wpdb->prepare("SELECT COUNT(*) FROM {$table_name} WHERE source_url_hash = %s", $hash)
        );
    }

    /**
     * Clear redirects cache
     */
    public static function clearCache(): void
    {
        self::$redirects_cache = null;
    }

    /**
     * Import redirects from array
     */
    public static function import(array $redirects): array
    {
        $imported = 0;
        $skipped = 0;
        $errors = [];

        foreach ($redirects as $index => $redirect) {
            if (empty($redirect['source_url']) || empty($redirect['target_url'])) {
                $errors[] = sprintf(__('Row %d: Missing source or target URL', 'affiliatecms'), $index + 1);
                $skipped++;
                continue;
            }

            if (self::sourceExists($redirect['source_url'])) {
                $skipped++;
                continue;
            }

            $result = self::add($redirect);
            if ($result) {
                $imported++;
            } else {
                $errors[] = sprintf(__('Row %d: Failed to import', 'affiliatecms'), $index + 1);
                $skipped++;
            }
        }

        return [
            'imported' => $imported,
            'skipped' => $skipped,
            'errors' => $errors,
        ];
    }

    /**
     * Export all redirects
     */
    public static function export(): array
    {
        return self::getAll(['limit' => 10000, 'orderby' => 'id', 'order' => 'ASC']);
    }

    // Prevent cloning
    private function __clone() {}
}
