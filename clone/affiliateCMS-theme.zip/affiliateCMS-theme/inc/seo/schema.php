<?php
/**
 * SEO Module - Schema.org JSON-LD
 *
 * Generates structured data for search engines.
 * Includes Organization, WebSite, Article, and Breadcrumbs schemas.
 *
 * @package AffiliateCMS
 * @since 4.0.0
 */

namespace AffiliateCMS\SEO;

if (!defined('ABSPATH')) {
    exit;
}

class Schema
{
    /**
     * Output global schemas (Organization, WebSite)
     * Cached for 24 hours
     */
    public static function outputGlobal(): void
    {
        static $output = false;
        if ($output) {
            return;
        }
        $output = true;

        $cache_key = 'acms_global_schema';
        $cached = get_transient($cache_key);

        if ($cached !== false) {
            echo $cached;
            return;
        }

        $home = home_url('/');
        $site_name = AdminPage::get('organization_name', '') ?: get_bloginfo('name');

        // WebSite Schema
        $website_schema = [
            '@context' => 'https://schema.org',
            '@type' => 'WebSite',
            '@id' => $home . '#website',
            'name' => get_bloginfo('name'),
            'url' => $home,
            'publisher' => ['@id' => $home . '#organization'],
        ];

        // SearchAction (sitelinks searchbox)
        if (AdminPage::get('schema_search', 1)) {
            $website_schema['potentialAction'] = [
                '@type' => 'SearchAction',
                'target' => [
                    '@type' => 'EntryPoint',
                    'urlTemplate' => $home . '?s={search_term_string}',
                ],
                'query-input' => 'required name=search_term_string',
            ];
        }

        $description = get_bloginfo('description');
        if ($description) {
            $website_schema['description'] = $description;
        }

        // Organization Schema
        $org_type = AdminPage::get('organization_type', 'Organization');
        $org_schema = [
            '@context' => 'https://schema.org',
            '@type' => $org_type,
            '@id' => $home . '#organization',
            'name' => $site_name,
            'url' => $home,
        ];

        // Logo
        if (has_site_icon()) {
            $icon_url = get_site_icon_url(512);
            $org_schema['logo'] = [
                '@type' => 'ImageObject',
                '@id' => $home . '#logo',
                'url' => $icon_url,
                'width' => 512,
                'height' => 512,
                'caption' => $site_name,
            ];
            $org_schema['image'] = ['@id' => $home . '#logo'];
        }

        // Social profiles from admin settings
        $social_links = AdminPage::getSocialLinks();
        if (!empty($social_links)) {
            $org_schema['sameAs'] = array_column($social_links, 'url');
        }

        // Contact email from admin settings
        $contact_email = AdminPage::get('contact_email', '');
        if (!empty($contact_email)) {
            $org_schema['email'] = $contact_email;
        }

        // Minified output
        $result = '<script type="application/ld+json">' .
                  wp_json_encode($website_schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) .
                  '</script>' . "\n" .
                  '<script type="application/ld+json">' .
                  wp_json_encode($org_schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) .
                  '</script>' . "\n";

        set_transient($cache_key, $result, DAY_IN_SECONDS);

        echo $result;
    }

    /**
     * Output post schema (Article with ratings)
     * Cached for 7 days per post
     */
    public static function outputPost(): void
    {
        if (!is_singular(SEO::SUPPORTED_POST_TYPES)) {
            return;
        }

        $post_id = get_the_ID();
        $cache_key = 'acms_schema_' . $post_id;

        $cached = get_transient($cache_key);
        if ($cached !== false) {
            echo $cached;
            return;
        }

        $schema = self::buildPostSchema($post_id);

        $output = '<script type="application/ld+json">' .
                  wp_json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) .
                  '</script>' . "\n";

        // Replace any remaining placeholders (%year%, etc.) before caching
        $output = Placeholders::replace($output);

        set_transient($cache_key, $output, 7 * DAY_IN_SECONDS);

        echo $output;
    }

    /**
     * Build post schema array
     */
    private static function buildPostSchema(int $post_id): array
    {
        $post = get_post($post_id);
        $home = home_url('/');

        // Get description
        $description = get_the_excerpt($post);
        if (empty($description)) {
            $description = wp_trim_words(wp_strip_all_tags($post->post_content), 30, '...');
        }

        $schema = [
            '@context' => 'https://schema.org',
            '@type' => 'Article',
            'headline' => get_the_title($post),
            'description' => $description,
            'url' => get_permalink($post),
            'mainEntityOfPage' => [
                '@type' => 'WebPage',
                '@id' => get_permalink($post),
            ],
            'datePublished' => get_the_date('c', $post),
            'dateModified' => get_the_modified_date('c', $post),
            'author' => [
                '@type' => 'Person',
                'name' => get_the_author_meta('display_name', $post->post_author),
                'url' => get_author_posts_url($post->post_author),
            ],
            'publisher' => [
                '@type' => 'Organization',
                '@id' => $home . '#organization',
                'name' => get_bloginfo('name'),
                'url' => $home,
            ],
        ];

        // Featured image
        if (has_post_thumbnail($post_id)) {
            $image_id = get_post_thumbnail_id($post_id);
            $image_data = wp_get_attachment_image_src($image_id, 'full');
            if ($image_data) {
                $schema['image'] = [
                    '@type' => 'ImageObject',
                    'url' => $image_data[0],
                    'width' => $image_data[1],
                    'height' => $image_data[2],
                ];
            }
        }

        // Publisher logo
        if (has_site_icon()) {
            $schema['publisher']['logo'] = [
                '@type' => 'ImageObject',
                'url' => get_site_icon_url(512),
            ];
        }

        // Aggregate Rating (if comments module provides ratings)
        if (function_exists('acms_get_post_rating')) {
            $rating_data = acms_get_post_rating($post_id);
            if ($rating_data && $rating_data['count'] > 0) {
                $schema['aggregateRating'] = [
                    '@type' => 'AggregateRating',
                    'ratingValue' => number_format($rating_data['average'], 1),
                    'bestRating' => '5',
                    'worstRating' => '1',
                    'ratingCount' => $rating_data['count'],
                ];
            }
        }

        // Article section (primary category)
        $categories = get_the_category($post_id);
        if (!empty($categories)) {
            $schema['articleSection'] = $categories[0]->name;
        }

        // Word count
        $word_count = str_word_count(wp_strip_all_tags($post->post_content));
        if ($word_count > 0) {
            $schema['wordCount'] = $word_count;
        }

        return $schema;
    }

    /**
     * Output breadcrumbs schema
     */
    public static function outputBreadcrumbs(): void
    {
        // Skip on homepage
        if (is_front_page()) {
            return;
        }

        $breadcrumbs = self::getBreadcrumbsData();

        if (empty($breadcrumbs) || count($breadcrumbs) < 2) {
            return;
        }

        $items = [];
        $position = 1;

        foreach ($breadcrumbs as $crumb) {
            $items[] = [
                '@type' => 'ListItem',
                'position' => $position,
                'name' => $crumb['name'],
                'item' => $crumb['url'],
            ];
            $position++;
        }

        $schema = [
            '@context' => 'https://schema.org',
            '@type' => 'BreadcrumbList',
            'itemListElement' => $items,
        ];

        $output = '<script type="application/ld+json">' .
                  wp_json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) .
                  '</script>' . "\n";

        // Replace any remaining placeholders (%year%, etc.)
        echo Placeholders::replace($output);
    }

    /**
     * Get breadcrumbs data for current page
     */
    private static function getBreadcrumbsData(): array
    {
        $breadcrumbs = [];
        $home_url = home_url('/');

        // Always start with Home
        $breadcrumbs[] = [
            'name' => __('Home', 'affiliatecms'),
            'url' => $home_url,
        ];

        // Single post/page
        if (is_singular()) {
            $post = get_queried_object();

            // Add post type archive for CPTs
            if ($post->post_type !== 'post' && $post->post_type !== 'page') {
                $post_type_obj = get_post_type_object($post->post_type);
                if ($post_type_obj && $post_type_obj->has_archive) {
                    $breadcrumbs[] = [
                        'name' => $post_type_obj->labels->name,
                        'url' => get_post_type_archive_link($post->post_type),
                    ];
                }
            }

            // Add primary category for posts
            if ($post->post_type === 'post') {
                $categories = get_the_category($post->ID);
                if (!empty($categories)) {
                    // Get primary/first category
                    $primary_cat = $categories[0];

                    // Add parent categories
                    $parents = get_ancestors($primary_cat->term_id, 'category');
                    $parents = array_reverse($parents);

                    foreach ($parents as $parent_id) {
                        $parent = get_term($parent_id, 'category');
                        if ($parent && !is_wp_error($parent)) {
                            $breadcrumbs[] = [
                                'name' => $parent->name,
                                'url' => get_term_link($parent),
                            ];
                        }
                    }

                    $breadcrumbs[] = [
                        'name' => $primary_cat->name,
                        'url' => get_term_link($primary_cat),
                    ];
                }
            }

            // Add parent pages for hierarchical post types
            if (is_post_type_hierarchical($post->post_type) && $post->post_parent) {
                $parents = get_post_ancestors($post->ID);
                $parents = array_reverse($parents);

                foreach ($parents as $parent_id) {
                    $parent = get_post($parent_id);
                    if ($parent) {
                        $breadcrumbs[] = [
                            'name' => get_the_title($parent),
                            'url' => get_permalink($parent),
                        ];
                    }
                }
            }

            // Add current post
            $breadcrumbs[] = [
                'name' => get_the_title($post),
                'url' => get_permalink($post),
            ];
        }

        // Category/Tag/Taxonomy archive
        elseif (is_category() || is_tag() || is_tax()) {
            $term = get_queried_object();

            // Add parent terms
            if ($term->parent) {
                $parents = get_ancestors($term->term_id, $term->taxonomy);
                $parents = array_reverse($parents);

                foreach ($parents as $parent_id) {
                    $parent = get_term($parent_id, $term->taxonomy);
                    if ($parent && !is_wp_error($parent)) {
                        $link = get_term_link($parent);
                        if (!is_wp_error($link)) {
                            $breadcrumbs[] = [
                                'name' => $parent->name,
                                'url' => $link,
                            ];
                        }
                    }
                }
            }

            $breadcrumbs[] = [
                'name' => $term->name,
                'url' => get_term_link($term),
            ];
        }

        // Author archive
        elseif (is_author()) {
            $author = get_queried_object();
            $breadcrumbs[] = [
                'name' => sprintf(__('Posts by %s', 'affiliatecms'), $author->display_name),
                'url' => get_author_posts_url($author->ID),
            ];
        }

        // Date archive
        elseif (is_date()) {
            if (is_year()) {
                $breadcrumbs[] = [
                    'name' => get_the_date('Y'),
                    'url' => get_year_link(get_query_var('year')),
                ];
            } elseif (is_month()) {
                $breadcrumbs[] = [
                    'name' => get_the_date('Y'),
                    'url' => get_year_link(get_query_var('year')),
                ];
                $breadcrumbs[] = [
                    'name' => get_the_date('F Y'),
                    'url' => get_month_link(get_query_var('year'), get_query_var('monthnum')),
                ];
            } elseif (is_day()) {
                $breadcrumbs[] = [
                    'name' => get_the_date('Y'),
                    'url' => get_year_link(get_query_var('year')),
                ];
                $breadcrumbs[] = [
                    'name' => get_the_date('F Y'),
                    'url' => get_month_link(get_query_var('year'), get_query_var('monthnum')),
                ];
                $breadcrumbs[] = [
                    'name' => get_the_date(),
                    'url' => get_day_link(get_query_var('year'), get_query_var('monthnum'), get_query_var('day')),
                ];
            }
        }

        // Post type archive
        elseif (is_post_type_archive()) {
            $post_type = get_queried_object();
            $breadcrumbs[] = [
                'name' => $post_type->labels->name,
                'url' => get_post_type_archive_link($post_type->name),
            ];
        }

        // Search
        elseif (is_search()) {
            $breadcrumbs[] = [
                'name' => sprintf(__('Search: %s', 'affiliatecms'), get_search_query()),
                'url' => get_search_link(),
            ];
        }

        // 404
        elseif (is_404()) {
            $breadcrumbs[] = [
                'name' => __('Page Not Found', 'affiliatecms'),
                'url' => '',
            ];
        }

        return $breadcrumbs;
    }

    /**
     * Clear global schema cache (on customizer save, etc.)
     */
    public static function clearGlobalCache(): void
    {
        delete_transient('acms_global_schema');
    }
}
