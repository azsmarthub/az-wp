<?php
/**
 * SEO Module - Placeholder System
 *
 * Handles template placeholders for SEO titles and descriptions.
 * Uses single % syntax for compatibility with AffiliateCMS Pro plugin.
 *
 * Supported placeholders:
 * - %title% / %post_title% - Post/page title
 * - %sitename% / %site_name% - Site name
 * - %tagline% - Site tagline
 * - %sep% / %separator% - Title separator
 * - %excerpt% - Post excerpt (truncated)
 * - %category% / %primary_category% - Primary category name
 * - %categories% - All categories (comma-separated)
 * - %tag% / %primary_tag% - Primary tag name
 * - %tags% - All tags (comma-separated)
 * - %author% / %author_name% - Author display name
 * - %date% / %publish_date% - Publish date
 * - %modified% / %modified_date% - Modified date
 * - %year% - Current year
 * - %month% / %month_text% - Current month name (full)
 * - %month_short% - Current month name (abbreviated)
 * - %month_number% - Current month number (01-12)
 * - %day% - Current day
 * - %date_full% - Full date per WP settings
 * - %keyword% - Queue keyword or post title
 * - %Keyword% / %KEYWORD% - Keyword in title case
 * - %keyword_title% - Keyword in title case
 * - %keyword_upper% - Keyword in uppercase
 * - %term_title% - Term name (for archives)
 * - %term_description% - Term description (for archives)
 * - %search_query% - Search query
 * - %page% / %page_number% - Current page number
 * - %pt_single% - Post type singular name
 * - %pt_plural% - Post type plural name
 * - %archive_title% - Archive title
 *
 * @package AffiliateCMS
 * @since 4.0.0
 */

namespace AffiliateCMS\SEO;

if (!defined('ABSPATH')) {
    exit;
}

class Placeholders
{
    /**
     * Get all available placeholders for current context
     */
    public static function getAll(): array
    {
        $placeholders = [];

        // Site info (always available)
        $placeholders['sitename'] = get_bloginfo('name');
        $placeholders['site_name'] = $placeholders['sitename'];
        $placeholders['tagline'] = get_bloginfo('description');
        $placeholders['sep'] = ' ' . trim(AdminPage::get('title_separator', '|')) . ' ';
        $placeholders['separator'] = $placeholders['sep'];

        // Date/time (always available)
        $placeholders['year'] = date('Y');
        $placeholders['month'] = date_i18n('F');
        $placeholders['month_text'] = $placeholders['month']; // Alias for Pro plugin compatibility
        $placeholders['month_short'] = date_i18n('M');
        $placeholders['month_number'] = date('m');
        $placeholders['day'] = date('j');
        $placeholders['date_full'] = date_i18n(get_option('date_format'));

        // Pagination
        $paged = get_query_var('paged', 1);
        $placeholders['page'] = $paged > 1 ? $paged : '';
        $placeholders['page_number'] = $placeholders['page'];

        // Search
        $placeholders['search_query'] = get_search_query();

        // Post context
        if (is_singular()) {
            $post_id = get_the_ID();
            $post = get_post($post_id);

            if ($post) {
                $placeholders = array_merge($placeholders, self::getPostPlaceholders($post));

                // Pro plugin keyword placeholders (from queue keyword or post title)
                $keyword = get_post_meta($post_id, '_acms_queue_keyword', true);
                if (empty($keyword)) {
                    $keyword = get_post_field('post_title', $post_id);
                }
                if ($keyword) {
                    $placeholders['keyword'] = $keyword;
                    $placeholders['keyword_title'] = ucwords($keyword);
                    $placeholders['keyword_upper'] = strtoupper($keyword);
                }
            }
        }

        // Archive context
        if (is_category() || is_tag() || is_tax()) {
            $term = get_queried_object();
            if ($term) {
                $placeholders = array_merge($placeholders, self::getTermPlaceholders($term));
            }
        }

        // Author context
        if (is_author()) {
            $author = get_queried_object();
            if ($author) {
                $placeholders['author'] = $author->display_name;
                $placeholders['author_name'] = $author->display_name;
            }
        }

        // Post type archive
        if (is_post_type_archive()) {
            $post_type = get_queried_object();
            if ($post_type) {
                $placeholders['archive_title'] = $post_type->label;
                $placeholders['pt_single'] = $post_type->labels->singular_name;
                $placeholders['pt_plural'] = $post_type->labels->name;
            }
        }

        // Date archive
        if (is_date()) {
            if (is_day()) {
                $placeholders['archive_title'] = get_the_date();
            } elseif (is_month()) {
                $placeholders['archive_title'] = get_the_date('F Y');
            } elseif (is_year()) {
                $placeholders['archive_title'] = get_the_date('Y');
            }
        }

        return $placeholders;
    }

    /**
     * Get placeholders for a post
     */
    private static function getPostPlaceholders(\WP_Post $post): array
    {
        $placeholders = [];

        // Title
        $placeholders['title'] = get_the_title($post);
        $placeholders['post_title'] = $placeholders['title'];

        // Excerpt
        $excerpt = get_the_excerpt($post);
        if (empty($excerpt)) {
            $excerpt = wp_trim_words(wp_strip_all_tags($post->post_content), 25, '...');
        }
        $placeholders['excerpt'] = $excerpt;

        // Dates
        $placeholders['date'] = get_the_date('', $post);
        $placeholders['publish_date'] = $placeholders['date'];
        $placeholders['modified'] = get_the_modified_date('', $post);
        $placeholders['modified_date'] = $placeholders['modified'];

        // Author
        $placeholders['author'] = get_the_author_meta('display_name', $post->post_author);
        $placeholders['author_name'] = $placeholders['author'];

        // Categories (for posts)
        $categories = get_the_category($post->ID);
        if (!empty($categories)) {
            $placeholders['category'] = $categories[0]->name;
            $placeholders['primary_category'] = $categories[0]->name;
            $placeholders['categories'] = implode(', ', wp_list_pluck($categories, 'name'));
        } else {
            $placeholders['category'] = '';
            $placeholders['primary_category'] = '';
            $placeholders['categories'] = '';
        }

        // Tags
        $tags = get_the_tags($post->ID);
        if (!empty($tags) && !is_wp_error($tags)) {
            $placeholders['tag'] = $tags[0]->name;
            $placeholders['primary_tag'] = $tags[0]->name;
            $placeholders['tags'] = implode(', ', wp_list_pluck($tags, 'name'));
        } else {
            $placeholders['tag'] = '';
            $placeholders['primary_tag'] = '';
            $placeholders['tags'] = '';
        }

        // Post type
        $post_type_obj = get_post_type_object($post->post_type);
        if ($post_type_obj) {
            $placeholders['pt_single'] = $post_type_obj->labels->singular_name;
            $placeholders['pt_plural'] = $post_type_obj->labels->name;
        }

        // Custom taxonomy categories for CPTs
        $cpt_taxonomies = [
            'acms_reviews' => 'acms_reviews_category',
            'acms_deals'   => 'acms_deals_category',
            'acms_guides'  => 'acms_guides_category',
        ];

        if (isset($cpt_taxonomies[$post->post_type])) {
            $tax = $cpt_taxonomies[$post->post_type];
            $terms = get_the_terms($post->ID, $tax);
            if (!empty($terms) && !is_wp_error($terms)) {
                $placeholders['category'] = $terms[0]->name;
                $placeholders['primary_category'] = $terms[0]->name;
                $placeholders['categories'] = implode(', ', wp_list_pluck($terms, 'name'));
            }
        }

        return $placeholders;
    }

    /**
     * Get placeholders for a term (category, tag, taxonomy)
     */
    private static function getTermPlaceholders(\WP_Term $term): array
    {
        $placeholders = [];

        $placeholders['term_title'] = $term->name;
        $placeholders['term_description'] = $term->description;
        $placeholders['archive_title'] = $term->name;

        // Also populate title for consistency
        $placeholders['title'] = $term->name;

        // Get taxonomy labels
        $taxonomy = get_taxonomy($term->taxonomy);
        if ($taxonomy) {
            $placeholders['pt_single'] = $taxonomy->labels->singular_name;
            $placeholders['pt_plural'] = $taxonomy->labels->name;
        }

        return $placeholders;
    }

    /**
     * Replace placeholders in a string
     */
    public static function replace(string $template): string
    {
        if (empty($template) || strpos($template, '%') === false) {
            return $template;
        }

        $placeholders = self::getAll();

        // Build search/replace arrays — double-delimiters first to prevent
        // %year% from matching inside %%year%% and leaving stray %2026%
        $search = [];
        $replace = [];

        // Pro plugin double-delimiter variants (must come before single %)
        foreach ($placeholders as $key => $value) {
            $search[] = '%%' . $key . '%%';
            $replace[] = (string) $value;
        }

        // Standard single-delimiter
        foreach ($placeholders as $key => $value) {
            $search[] = '%' . $key . '%';
            $replace[] = (string) $value;
        }

        // Pro plugin case variants: %Keyword%, %KEYWORD%
        if (isset($placeholders['keyword_title'])) {
            $search[] = '%Keyword%';
            $replace[] = (string) $placeholders['keyword_title'];
            $search[] = '%KEYWORD%';
            $replace[] = (string) $placeholders['keyword_title'];
        }

        $result = str_replace($search, $replace, $template);

        // Clean up unreplaced placeholders (lowercase and mixed-case)
        $result = preg_replace('/%{1,2}[a-zA-Z_]+%{1,2}/', '', $result);

        // Clean up extra spaces/separators
        $result = preg_replace('/\s+/', ' ', $result);
        $result = trim($result);

        // Clean up hanging separators at start/end
        $sep = trim(AdminPage::get('title_separator', '|'));
        $result = trim($result, " {$sep}");

        return $result;
    }

    /**
     * Get placeholder reference for admin UI
     */
    public static function getReference(): array
    {
        return [
            'basic' => [
                'label' => __('Basic', 'affiliatecms'),
                'items' => [
                    '%title%' => __('Post/Page title', 'affiliatecms'),
                    '%sitename%' => __('Site name', 'affiliatecms'),
                    '%tagline%' => __('Site tagline', 'affiliatecms'),
                    '%sep%' => __('Separator', 'affiliatecms'),
                ],
            ],
            'post' => [
                'label' => __('Post/Page', 'affiliatecms'),
                'items' => [
                    '%excerpt%' => __('Post excerpt', 'affiliatecms'),
                    '%category%' => __('Primary category', 'affiliatecms'),
                    '%categories%' => __('All categories', 'affiliatecms'),
                    '%tag%' => __('Primary tag', 'affiliatecms'),
                    '%tags%' => __('All tags', 'affiliatecms'),
                    '%author%' => __('Author name', 'affiliatecms'),
                    '%pt_single%' => __('Post type (singular)', 'affiliatecms'),
                    '%pt_plural%' => __('Post type (plural)', 'affiliatecms'),
                ],
            ],
            'date' => [
                'label' => __('Date & Time', 'affiliatecms'),
                'items' => [
                    '%date%' => __('Publish date', 'affiliatecms'),
                    '%modified%' => __('Modified date', 'affiliatecms'),
                    '%year%' => __('Current year', 'affiliatecms'),
                    '%month%' => __('Current month (full name)', 'affiliatecms'),
                    '%month_text%' => __('Current month (alias)', 'affiliatecms'),
                    '%month_short%' => __('Current month (abbreviated)', 'affiliatecms'),
                    '%month_number%' => __('Current month (number)', 'affiliatecms'),
                    '%day%' => __('Current day', 'affiliatecms'),
                    '%date_full%' => __('Full date', 'affiliatecms'),
                ],
            ],
            'keyword' => [
                'label' => __('Keyword', 'affiliatecms'),
                'items' => [
                    '%keyword%' => __('Queue keyword or post title', 'affiliatecms'),
                    '%Keyword%' => __('Keyword (title case)', 'affiliatecms'),
                    '%keyword_upper%' => __('Keyword (uppercase)', 'affiliatecms'),
                ],
            ],
            'archive' => [
                'label' => __('Archives', 'affiliatecms'),
                'items' => [
                    '%term_title%' => __('Category/Tag name', 'affiliatecms'),
                    '%term_description%' => __('Category/Tag description', 'affiliatecms'),
                    '%archive_title%' => __('Archive title', 'affiliatecms'),
                    '%search_query%' => __('Search query', 'affiliatecms'),
                    '%page%' => __('Page number', 'affiliatecms'),
                ],
            ],
        ];
    }

    /**
     * Check if a template contains placeholders
     */
    public static function hasPlaceholders(string $template): bool
    {
        return (bool) preg_match('/%{1,2}[a-zA-Z_]+%{1,2}/', $template);
    }
}
