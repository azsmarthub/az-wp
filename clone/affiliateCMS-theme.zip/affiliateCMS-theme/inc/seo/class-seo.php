<?php
/**
 * SEO Module - Main Class
 *
 * Handles all SEO functionality without external plugins.
 * Optimized for performance with minimal database queries.
 *
 * @package AffiliateCMS
 * @since 4.0.0
 */

namespace AffiliateCMS\SEO;

if (!defined('ABSPATH')) {
    exit;
}

class SEO
{
    private static ?SEO $instance = null;

    /**
     * Supported post types for SEO
     */
    public const SUPPORTED_POST_TYPES = ['post', 'page', 'acms_reviews', 'acms_deals', 'acms_guides'];

    /**
     * Supported taxonomies for SEO
     */
    public const SUPPORTED_TAXONOMIES = [
        'category',
        'post_tag',
        'acms_reviews_category',
        'acms_reviews_tag',
        'acms_reviews_brand',
        'acms_deals_category',
        'acms_deals_tag',
        'acms_guides_category',
        'acms_guides_tag',
    ];

    public static function instance(): SEO
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct()
    {
        $this->loadModules();
        $this->registerHooks();
    }

    /**
     * Load all SEO sub-modules
     */
    private function loadModules(): void
    {
        $dir = __DIR__;

        // Always load admin page for settings access
        require_once $dir . '/admin-page.php';
        require_once $dir . '/placeholders.php';

        require_once $dir . '/meta-tags.php';
        require_once $dir . '/open-graph.php';
        require_once $dir . '/canonical.php';
        require_once $dir . '/schema.php';
        require_once $dir . '/sitemap.php';
        require_once $dir . '/redirects.php';
        require_once $dir . '/monitor-404.php';
        require_once $dir . '/link-filters.php';
        require_once $dir . '/rest-api.php';

        // Admin only
        if (is_admin()) {
            require_once $dir . '/meta-box.php';
            AdminPage::instance();
        }
    }

    /**
     * Register hooks
     */
    private function registerHooks(): void
    {
        // Remove WordPress default title tag (we handle it ourselves)
        remove_theme_support('title-tag');

        // Meta tags in head
        add_action('wp_head', [MetaTags::class, 'output'], 1);

        // Open Graph & Twitter Cards
        add_action('wp_head', [OpenGraph::class, 'output'], 2);

        // Canonical URL
        add_action('wp_head', [Canonical::class, 'output'], 3);

        // Schema.org JSON-LD (conditional based on settings)
        add_action('wp_head', [Schema::class, 'outputGlobal'], 5);

        if (AdminPage::get('schema_article', 1)) {
            add_action('wp_head', [Schema::class, 'outputPost'], 20);
        }

        if (AdminPage::get('schema_breadcrumbs', 1)) {
            add_action('wp_head', [Schema::class, 'outputBreadcrumbs'], 21);
        }

        // XML Sitemap
        Sitemap::register();

        // Redirects Manager (checks for redirects on every request)
        Redirects::instance();

        // 404 Monitor (logs 404 errors)
        Monitor404::instance();

        // Link filters (nofollow, noopener, target blank)
        LinkFilters::instance();

        // Admin meta box
        if (is_admin()) {
            MetaBox::register();
        }

        // Clear caches on post save
        add_action('save_post', [$this, 'clearPostCaches'], 20);
        add_action('edit_post', [$this, 'clearPostCaches'], 20);

        // Clear sitemap cache when SEO categories change
        add_action('acms_cat_created', [Sitemap::class, 'clearSeoCategoryCache']);
        add_action('acms_cat_updated', [Sitemap::class, 'clearSeoCategoryCache']);
        add_action('acms_cat_deleted', [Sitemap::class, 'clearSeoCategoryCache']);

        // Clean wp_head based on settings
        $this->cleanWpHead();
    }

    /**
     * Remove unnecessary tags from wp_head
     */
    private function cleanWpHead(): void
    {
        if (AdminPage::get('remove_shortlink', 1)) {
            remove_action('wp_head', 'wp_shortlink_wp_head', 10);
            remove_action('template_redirect', 'wp_shortlink_header', 11);
        }

        if (AdminPage::get('remove_rsd', 1)) {
            remove_action('wp_head', 'rsd_link');
        }

        if (AdminPage::get('remove_wlwmanifest', 1)) {
            remove_action('wp_head', 'wlwmanifest_link');
        }

        if (AdminPage::get('remove_generator', 1)) {
            remove_action('wp_head', 'wp_generator');
            add_filter('the_generator', '__return_empty_string');
        }
    }

    /**
     * Clear SEO-related caches when post is saved
     */
    public function clearPostCaches(int $post_id): void
    {
        // Skip revisions and autosaves
        if (wp_is_post_revision($post_id) || wp_is_post_autosave($post_id)) {
            return;
        }

        // Clear schema cache
        delete_transient('acms_schema_' . $post_id);

        // Clear sitemap cache
        delete_transient('acms_sitemap_index');
        delete_transient('acms_sitemap_posts');
        delete_transient('acms_sitemap_pages');

        $post_type = get_post_type($post_id);
        if ($post_type) {
            delete_transient('acms_sitemap_' . $post_type);
        }
    }

    /**
     * Get SEO meta value for a post
     */
    public static function getMeta(int $post_id, string $key, string $default = ''): string
    {
        $value = get_post_meta($post_id, '_acms_seo_' . $key, true);
        return $value !== '' ? $value : $default;
    }

    /**
     * Get SEO title for current page
     */
    public static function getTitle(): string
    {
        return MetaTags::getTitle();
    }

    /**
     * Get SEO description for current page
     */
    public static function getDescription(): string
    {
        return MetaTags::getDescription();
    }

    // Prevent cloning
    private function __clone() {}
}
