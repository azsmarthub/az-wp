<?php
/**
 * SEO Module - XML Sitemap
 *
 * Generates dynamic XML sitemaps for search engines.
 * Sitemaps are cached for performance and auto-cleared on post save.
 *
 * URLs:
 * - /sitemap.xml (index)
 * - /sitemap-posts.xml
 * - /sitemap-pages.xml
 * - /sitemap-{post_type}.xml (custom post types)
 * - /sitemap-categories.xml
 * - /sitemap-tags.xml
 * - /sitemap-acms-categories.xml (SEO category pages /c/{slug}/)
 * - /sitemap-acms-categories-2.xml (paginated if >1000)
 *
 * @package AffiliateCMS
 * @since 4.0.0
 */

namespace AffiliateCMS\SEO;

if (!defined('ABSPATH')) {
    exit;
}

class Sitemap
{
    private const CACHE_DURATION = DAY_IN_SECONDS;

    /**
     * Get max URLs per sitemap from settings (default 1000)
     */
    private static function getMaxUrls(): int
    {
        $settings = get_option('acms_seo_settings', []);
        return (int) ($settings['sitemap_max_urls'] ?? 1000);
    }

    /**
     * Register sitemap routes
     */
    public static function register(): void
    {
        add_action('init', [self::class, 'addRewriteRules']);
        add_filter('query_vars', [self::class, 'addQueryVars']);
        add_action('template_redirect', [self::class, 'render']);

        // Prevent WordPress from appending trailing slash to sitemap URLs
        add_filter('redirect_canonical', [self::class, 'preventSitemapRedirect']);

        // Add sitemap link to robots.txt
        add_filter('robots_txt', [self::class, 'addToRobotsTxt'], 10, 2);
    }

    /**
     * Add rewrite rules for sitemap URLs
     */
    public static function addRewriteRules(): void
    {
        // Sitemap index
        add_rewrite_rule(
            'sitemap\.xml$',
            'index.php?acms_sitemap=index',
            'top'
        );

        // Individual sitemaps
        add_rewrite_rule(
            'sitemap-([a-z0-9_-]+)\.xml$',
            'index.php?acms_sitemap=$matches[1]',
            'top'
        );
    }

    /**
     * Add query vars
     */
    public static function addQueryVars(array $vars): array
    {
        $vars[] = 'acms_sitemap';
        return $vars;
    }

    /**
     * Prevent WordPress from adding trailing slash to sitemap URLs
     */
    public static function preventSitemapRedirect($redirect_url)
    {
        if (get_query_var('acms_sitemap')) {
            return false;
        }
        return $redirect_url;
    }

    /**
     * Render sitemap
     */
    public static function render(): void
    {
        $sitemap = get_query_var('acms_sitemap');

        if (empty($sitemap)) {
            return;
        }

        // Set XML headers
        header('Content-Type: application/xml; charset=utf-8');
        header('X-Robots-Tag: noindex, follow');

        // Cache control
        header('Cache-Control: public, max-age=3600');

        if ($sitemap === 'index') {
            echo self::generateIndex();
        } else {
            echo self::generateSitemap($sitemap);
        }

        exit;
    }

    /**
     * Generate sitemap index
     */
    private static function generateIndex(): string
    {
        $cache_key = 'acms_sitemap_index';
        $cached = get_transient($cache_key);

        if ($cached !== false) {
            return $cached;
        }

        $home = home_url('/');
        $sitemaps = [];

        // Posts sitemap
        $post_count = wp_count_posts('post');
        if ($post_count->publish > 0) {
            $sitemaps[] = [
                'loc'     => $home . 'sitemap-posts.xml',
                'lastmod' => self::getLastModified('post'),
            ];
        }

        // Pages sitemap
        $page_count = wp_count_posts('page');
        if ($page_count->publish > 0) {
            $sitemaps[] = [
                'loc'     => $home . 'sitemap-pages.xml',
                'lastmod' => self::getLastModified('page'),
            ];
        }

        // Custom post types
        foreach (SEO::SUPPORTED_POST_TYPES as $post_type) {
            if (in_array($post_type, ['post', 'page'], true)) {
                continue;
            }

            if (!post_type_exists($post_type)) {
                continue;
            }

            $count = wp_count_posts($post_type);
            if (isset($count->publish) && $count->publish > 0) {
                $sitemaps[] = [
                    'loc'     => $home . 'sitemap-' . $post_type . '.xml',
                    'lastmod' => self::getLastModified($post_type),
                ];
            }
        }

        // Categories sitemap
        $cat_count = wp_count_terms(['taxonomy' => 'category', 'hide_empty' => true]);
        if ($cat_count > 0) {
            $sitemaps[] = [
                'loc'     => $home . 'sitemap-categories.xml',
                'lastmod' => date('c'),
            ];
        }

        // Tags sitemap (optional - can be large)
        $tag_count = wp_count_terms(['taxonomy' => 'post_tag', 'hide_empty' => true]);
        if ($tag_count > 0 && $tag_count < 500) {
            $sitemaps[] = [
                'loc'     => $home . 'sitemap-tags.xml',
                'lastmod' => date('c'),
            ];
        }

        // Custom taxonomy sitemaps
        $custom_taxonomies = ['acms_reviews_category', 'acms_deals_category', 'acms_guides_category', 'acms_reviews_brand'];
        foreach ($custom_taxonomies as $taxonomy) {
            if (!taxonomy_exists($taxonomy)) {
                continue;
            }

            $count = wp_count_terms(['taxonomy' => $taxonomy, 'hide_empty' => true]);
            if ($count > 0) {
                $sitemaps[] = [
                    'loc'     => $home . 'sitemap-' . $taxonomy . '.xml',
                    'lastmod' => date('c'),
                ];
            }
        }

        // SEO Categories (acms_categories custom table — /c/{slug}/ pages)
        $seo_settings = get_option('acms_seo_settings', []);
        $seo_cat_enabled = $seo_settings['sitemap_seo_categories'] ?? 1;
        $seo_cat_count = $seo_cat_enabled ? self::getSeoCategoryCount() : 0;
        if ($seo_cat_count > 0) {
            $pages = ceil($seo_cat_count / self::getMaxUrls());
            $lastmod = self::getSeoCategoryLastModified();
            if ($pages === 1) {
                $sitemaps[] = [
                    'loc'     => $home . 'sitemap-acms-categories.xml',
                    'lastmod' => $lastmod,
                ];
            } else {
                for ($i = 1; $i <= $pages; $i++) {
                    $sitemaps[] = [
                        'loc'     => $home . 'sitemap-acms-categories-' . $i . '.xml',
                        'lastmod' => $lastmod,
                    ];
                }
            }
        }

        $output = self::buildIndexXml($sitemaps);

        set_transient($cache_key, $output, self::CACHE_DURATION);

        return $output;
    }

    /**
     * Generate individual sitemap
     */
    private static function generateSitemap(string $type): string
    {
        $cache_key = 'acms_sitemap_' . $type;
        $cached = get_transient($cache_key);

        if ($cached !== false) {
            return $cached;
        }

        $urls = [];

        switch ($type) {
            case 'posts':
                $urls = self::getPostUrls('post');
                break;

            case 'pages':
                $urls = self::getPostUrls('page');
                break;

            case 'categories':
                $urls = self::getTaxonomyUrls('category');
                break;

            case 'tags':
                $urls = self::getTaxonomyUrls('post_tag');
                break;

            default:
                // SEO categories (acms-categories or acms-categories-N for paginated)
                if ($type === 'acms-categories' || preg_match('/^acms-categories-(\d+)$/', $type, $m)) {
                    $page = isset($m[1]) ? (int) $m[1] : 1;
                    $urls = self::getSeoCategoryUrls($page);
                }
                // Check if it's a custom post type
                elseif (post_type_exists($type)) {
                    $urls = self::getPostUrls($type);
                }
                // Check if it's a custom taxonomy
                elseif (taxonomy_exists($type)) {
                    $urls = self::getTaxonomyUrls($type);
                }
                break;
        }

        $output = self::buildUrlsetXml($urls);

        set_transient($cache_key, $output, self::CACHE_DURATION);

        return $output;
    }

    /**
     * Get URLs for a post type
     */
    private static function getPostUrls(string $post_type): array
    {
        $urls = [];

        $posts = get_posts([
            'post_type'      => $post_type,
            'post_status'    => 'publish',
            'posts_per_page' => self::getMaxUrls(),
            'orderby'        => 'modified',
            'order'          => 'DESC',
            'no_found_rows'  => true,
            'fields'         => 'ids',
        ]);

        foreach ($posts as $post_id) {
            // Check if noindex
            $robots = SEO::getMeta($post_id, 'robots');
            if (strpos($robots, 'noindex') !== false) {
                continue;
            }

            $urls[] = [
                'loc'        => get_permalink($post_id),
                'lastmod'    => get_post_modified_time('c', false, $post_id),
                'changefreq' => self::getChangeFreq($post_type),
                'priority'   => self::getPriority($post_type, $post_id),
            ];
        }

        return $urls;
    }

    /**
     * Get URLs for a taxonomy
     */
    private static function getTaxonomyUrls(string $taxonomy): array
    {
        $urls = [];

        $terms = get_terms([
            'taxonomy'   => $taxonomy,
            'hide_empty' => true,
            'number'     => self::getMaxUrls(),
        ]);

        if (is_wp_error($terms)) {
            return $urls;
        }

        foreach ($terms as $term) {
            $link = get_term_link($term);
            if (is_wp_error($link)) {
                continue;
            }

            $urls[] = [
                'loc'        => $link,
                'changefreq' => 'weekly',
                'priority'   => '0.6',
            ];
        }

        return $urls;
    }

    /**
     * Get last modified date for a post type
     */
    private static function getLastModified(string $post_type): string
    {
        $post = get_posts([
            'post_type'      => $post_type,
            'post_status'    => 'publish',
            'posts_per_page' => 1,
            'orderby'        => 'modified',
            'order'          => 'DESC',
            'no_found_rows'  => true,
        ]);

        if (!empty($post)) {
            return get_post_modified_time('c', false, $post[0]);
        }

        return date('c');
    }

    /**
     * Get change frequency based on post type
     */
    private static function getChangeFreq(string $post_type): string
    {
        $frequencies = [
            'post'         => 'weekly',
            'page'         => 'monthly',
            'acms_reviews' => 'weekly',
            'acms_deals'   => 'daily',
            'acms_guides'  => 'monthly',
        ];

        return $frequencies[$post_type] ?? 'weekly';
    }

    /**
     * Get priority based on post type
     */
    private static function getPriority(string $post_type, int $post_id = 0): string
    {
        // Homepage gets highest priority
        if ($post_id && $post_id === (int) get_option('page_on_front')) {
            return '1.0';
        }

        $priorities = [
            'post'         => '0.7',
            'page'         => '0.6',
            'acms_reviews' => '0.8',
            'acms_deals'   => '0.8',
            'acms_guides'  => '0.7',
        ];

        return $priorities[$post_type] ?? '0.5';
    }

    /**
     * Get total count of published SEO categories
     */
    private static function getSeoCategoryCount(): int
    {
        global $wpdb;
        $table = $wpdb->prefix . 'acms_categories';

        return (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE status = 'publish'");
    }

    /**
     * Get last modified date for SEO categories
     */
    private static function getSeoCategoryLastModified(): string
    {
        global $wpdb;
        $table = $wpdb->prefix . 'acms_categories';

        $date = $wpdb->get_var(
            "SELECT updated_at FROM {$table} WHERE status = 'publish' ORDER BY updated_at DESC LIMIT 1"
        );

        return $date ? (new \DateTime($date, wp_timezone()))->format('c') : date('c');
    }

    /**
     * Get SEO category URLs for sitemap (paginated)
     */
    private static function getSeoCategoryUrls(int $page = 1): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'acms_categories';
        $limit = self::getMaxUrls();
        $offset = ($page - 1) * $limit;
        $home = home_url('/c/');

        $categories = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT slug, updated_at, product_count, depth
                 FROM {$table}
                 WHERE status = 'publish'
                 ORDER BY updated_at DESC
                 LIMIT %d OFFSET %d",
                $limit,
                $offset
            )
        );

        $urls = [];
        foreach ($categories as $cat) {
            // Priority: root categories 0.8, depth 1-2 = 0.7, deeper = 0.6
            $depth = (int) $cat->depth;
            $priority = $depth === 0 ? '0.8' : ($depth <= 2 ? '0.7' : '0.6');

            // Categories with products update more frequently
            $freq = (int) $cat->product_count > 0 ? 'weekly' : 'monthly';

            $lastmod = $cat->updated_at
                ? (new \DateTime($cat->updated_at, wp_timezone()))->format('c')
                : null;

            $urls[] = [
                'loc'        => $home . $cat->slug . '/',
                'lastmod'    => $lastmod,
                'changefreq' => $freq,
                'priority'   => $priority,
            ];
        }

        return $urls;
    }

    /**
     * Build sitemap index XML
     */
    private static function buildIndexXml(array $sitemaps): string
    {
        $xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        $xml .= '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";

        foreach ($sitemaps as $sitemap) {
            $xml .= '  <sitemap>' . "\n";
            $xml .= '    <loc>' . esc_url($sitemap['loc']) . '</loc>' . "\n";
            if (!empty($sitemap['lastmod'])) {
                $xml .= '    <lastmod>' . esc_html($sitemap['lastmod']) . '</lastmod>' . "\n";
            }
            $xml .= '  </sitemap>' . "\n";
        }

        $xml .= '</sitemapindex>';

        return $xml;
    }

    /**
     * Build URL set XML
     */
    private static function buildUrlsetXml(array $urls): string
    {
        $xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        $xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";

        foreach ($urls as $url) {
            $xml .= '  <url>' . "\n";
            $xml .= '    <loc>' . esc_url($url['loc']) . '</loc>' . "\n";

            if (!empty($url['lastmod'])) {
                $xml .= '    <lastmod>' . esc_html($url['lastmod']) . '</lastmod>' . "\n";
            }
            if (!empty($url['changefreq'])) {
                $xml .= '    <changefreq>' . esc_html($url['changefreq']) . '</changefreq>' . "\n";
            }
            if (!empty($url['priority'])) {
                $xml .= '    <priority>' . esc_html($url['priority']) . '</priority>' . "\n";
            }

            $xml .= '  </url>' . "\n";
        }

        $xml .= '</urlset>';

        return $xml;
    }

    /**
     * Add sitemap to robots.txt
     */
    public static function addToRobotsTxt(string $output, bool $public): string
    {
        if (!$public) {
            return $output;
        }

        $sitemap_url = home_url('/sitemap.xml');
        $output .= "\nSitemap: " . $sitemap_url . "\n";

        return $output;
    }

    /**
     * Flush rewrite rules (call after theme activation)
     */
    public static function flushRules(): void
    {
        self::addRewriteRules();
        flush_rewrite_rules();
    }

    /**
     * Clear all sitemap caches
     */
    public static function clearCache(): void
    {
        global $wpdb;

        $wpdb->query(
            "DELETE FROM {$wpdb->options}
             WHERE option_name LIKE '_transient_acms_sitemap_%'
             OR option_name LIKE '_transient_timeout_acms_sitemap_%'"
        );
    }

    /**
     * Clear SEO category sitemap caches (called on acms_cat_created/updated/deleted hooks)
     */
    public static function clearSeoCategoryCache(): void
    {
        global $wpdb;

        delete_transient('acms_sitemap_index');

        // Clear all acms-categories sitemap transients (including paginated)
        $wpdb->query(
            "DELETE FROM {$wpdb->options}
             WHERE option_name LIKE '_transient_acms_sitemap_acms-categories%'
             OR option_name LIKE '_transient_timeout_acms_sitemap_acms-categories%'"
        );
    }
}
