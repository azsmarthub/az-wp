<?php
/**
 * SEO Module - Admin Settings Page
 *
 * Provides admin UI for managing SEO settings under Appearance menu.
 * Settings stored in single option for performance (1 DB query).
 *
 * @package AffiliateCMS
 * @since 4.0.0
 */

namespace AffiliateCMS\SEO;

if (!defined('ABSPATH')) {
    exit;
}

class AdminPage
{
    private const OPTION_NAME = 'acms_seo_settings';
    private const CAPABILITY = 'manage_options';

    private static ?AdminPage $instance = null;
    private static ?array $settings = null;

    public static function instance(): AdminPage
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct()
    {
        add_action('admin_menu', [$this, 'addMenuPage']);
        add_action('admin_init', [$this, 'registerSettings']);
        add_action('admin_enqueue_scripts', [$this, 'enqueueAssets']);
    }

    /**
     * Add submenu page under Appearance
     */
    public function addMenuPage(): void
    {
        add_theme_page(
            __('SEO Settings', 'affiliatecms'),
            __('SEO Settings', 'affiliatecms'),
            self::CAPABILITY,
            'acms-seo-settings',
            [$this, 'renderPage']
        );
    }

    /**
     * Register settings
     */
    public function registerSettings(): void
    {
        register_setting(
            'acms_seo_settings_group',
            self::OPTION_NAME,
            [
                'type' => 'array',
                'sanitize_callback' => [$this, 'sanitizeSettings'],
                'default' => self::getDefaults(),
            ]
        );
    }

    /**
     * Enqueue admin assets
     */
    public function enqueueAssets(string $hook): void
    {
        if ($hook !== 'appearance_page_acms-seo-settings') {
            return;
        }

        // Inline CSS
        $css = '
            .acms-seo-admin { max-width: 1100px; }
            .acms-seo-admin .nav-tab-wrapper { margin-bottom: 20px; }
            .acms-seo-admin .tab-content { display: none; background: #fff; padding: 20px; border: 1px solid #ccd0d4; border-top: none; }
            .acms-seo-admin .tab-content.active { display: block; }
            .acms-seo-admin .form-table th { width: 180px; padding: 15px 10px 15px 0; }
            .acms-seo-admin .form-table td { padding: 15px 10px; }
            .acms-seo-admin .form-table input[type="text"],
            .acms-seo-admin .form-table input[type="url"],
            .acms-seo-admin .form-table input[type="email"],
            .acms-seo-admin .form-table textarea,
            .acms-seo-admin .form-table select { width: 100%; max-width: 400px; }
            .acms-seo-admin .form-table textarea { min-height: 80px; }
            .acms-seo-admin .description { color: #666; font-style: italic; margin-top: 5px; }
            .acms-seo-admin .section-title { font-size: 14px; font-weight: 600; margin: 20px 0 10px; padding-bottom: 10px; border-bottom: 1px solid #eee; }
            .acms-seo-admin .section-title:first-child { margin-top: 0; }
            .acms-seo-admin .social-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; }
            .acms-seo-admin .social-item label { display: flex; align-items: center; gap: 8px; margin-bottom: 5px; }
            .acms-seo-admin .social-item input { width: 100%; }
            .acms-seo-admin code { background: #f0f0f0; padding: 2px 6px; border-radius: 3px; font-size: 12px; }

            /* Redirects Tab */
            .acms-seo-admin .redirects-subtabs { margin-bottom: 15px; border-bottom: 1px solid #ddd; padding-bottom: 10px; }
            .acms-seo-admin .redirects-subtabs a { display: inline-block; padding: 5px 15px; text-decoration: none; color: #555; border: 1px solid transparent; margin-bottom: -1px; }
            .acms-seo-admin .redirects-subtabs a.active { background: #fff; border: 1px solid #ddd; border-bottom-color: #fff; color: #0073aa; font-weight: 500; }
            .acms-seo-admin .redirects-subtab { display: none; }
            .acms-seo-admin .redirects-subtab.active { display: block; }
            .acms-seo-admin .redirects-table { width: 100%; border-collapse: collapse; margin-top: 10px; }
            .acms-seo-admin .redirects-table th,
            .acms-seo-admin .redirects-table td { padding: 10px; text-align: left; border-bottom: 1px solid #eee; }
            .acms-seo-admin .redirects-table th { background: #f9f9f9; font-weight: 600; font-size: 13px; }
            .acms-seo-admin .redirects-table tr:hover { background: #f9f9f9; }
            .acms-seo-admin .redirects-table .url-cell { max-width: 300px; word-break: break-all; font-size: 12px; }
            .acms-seo-admin .redirects-table .actions { white-space: nowrap; }
            .acms-seo-admin .redirects-table .actions a { margin-right: 8px; text-decoration: none; font-size: 12px; }
            .acms-seo-admin .redirects-table .actions a.delete { color: #dc3545; }
            .acms-seo-admin .redirects-table .badge { display: inline-block; padding: 2px 8px; border-radius: 3px; font-size: 11px; font-weight: 500; }
            .acms-seo-admin .redirects-table .badge-301 { background: #d4edda; color: #155724; }
            .acms-seo-admin .redirects-table .badge-302 { background: #fff3cd; color: #856404; }
            .acms-seo-admin .redirects-table .hit-count { font-weight: 600; color: #666; }
            .acms-seo-admin .redirect-form { background: #f9f9f9; padding: 15px; border-radius: 4px; margin-bottom: 20px; }
            .acms-seo-admin .redirect-form .form-row { display: flex; gap: 15px; margin-bottom: 10px; flex-wrap: wrap; }
            .acms-seo-admin .redirect-form .form-row > div { flex: 1; min-width: 200px; }
            .acms-seo-admin .redirect-form label { display: block; font-weight: 500; margin-bottom: 5px; font-size: 13px; }
            .acms-seo-admin .redirect-form input[type="text"],
            .acms-seo-admin .redirect-form select { width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 3px; }
            .acms-seo-admin .empty-state { text-align: center; padding: 40px; color: #666; }
            .acms-seo-admin .stats-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; margin-bottom: 20px; }
            .acms-seo-admin .stat-box { background: #f9f9f9; padding: 15px; border-radius: 4px; text-align: center; }
            .acms-seo-admin .stat-box .number { font-size: 28px; font-weight: 700; color: #0073aa; }
            .acms-seo-admin .stat-box .label { font-size: 12px; color: #666; margin-top: 5px; }

            /* Templates Layout */
            .acms-seo-admin .templates-layout { display: grid; grid-template-columns: 1fr 280px; gap: 20px; }
            .acms-seo-admin .templates-main .form-table input.widefat { max-width: 100%; }

            /* Placeholder Panel */
            .acms-seo-admin .placeholder-panel { background: #f9f9f9; border: 1px solid #ddd; border-radius: 4px; padding: 15px; position: sticky; top: 40px; }
            .acms-seo-admin .placeholder-panel h4 { margin: 0 0 15px; font-size: 13px; color: #1d2327; }
            .acms-seo-admin .placeholder-group { margin-bottom: 15px; }
            .acms-seo-admin .placeholder-group:last-child { margin-bottom: 0; }
            .acms-seo-admin .placeholder-group h5 { font-size: 11px; text-transform: uppercase; color: #666; margin: 0 0 8px; letter-spacing: 0.5px; }
            .acms-seo-admin .placeholder-group ul { margin: 0; padding: 0; list-style: none; }
            .acms-seo-admin .placeholder-group li { display: flex; align-items: flex-start; gap: 8px; margin-bottom: 6px; font-size: 12px; line-height: 1.4; }
            .acms-seo-admin .placeholder-group li code { cursor: pointer; transition: all 0.15s; flex-shrink: 0; }
            .acms-seo-admin .placeholder-group li code:hover { background: #0073aa; color: #fff; }
            .acms-seo-admin .placeholder-group li span { color: #666; }

            @media (max-width: 960px) {
                .acms-seo-admin .templates-layout { grid-template-columns: 1fr; }
                .acms-seo-admin .placeholder-panel { position: static; }
            }
        ';
        wp_add_inline_style('common', $css);

        // Inline JS for tabs
        $js = '
            document.addEventListener("DOMContentLoaded", function() {
                var tabs = document.querySelectorAll(".acms-seo-admin .nav-tab");
                var contents = document.querySelectorAll(".acms-seo-admin .tab-content");

                tabs.forEach(function(tab) {
                    tab.addEventListener("click", function(e) {
                        e.preventDefault();
                        var target = this.getAttribute("href").substring(1);

                        tabs.forEach(function(t) { t.classList.remove("nav-tab-active"); });
                        contents.forEach(function(c) { c.classList.remove("active"); });

                        this.classList.add("nav-tab-active");
                        document.getElementById(target).classList.add("active");

                        // Save to localStorage
                        localStorage.setItem("acms_seo_tab", target);
                    });
                });

                // Restore last tab
                var lastTab = localStorage.getItem("acms_seo_tab");
                if (lastTab && document.getElementById(lastTab)) {
                    document.querySelector(".nav-tab[href=\"#" + lastTab + "\"]").click();
                }

                // Copy placeholder to clipboard
                document.querySelectorAll(".placeholder-copy").forEach(function(code) {
                    code.addEventListener("click", function() {
                        var text = this.textContent;
                        navigator.clipboard.writeText(text).then(function() {
                            var original = code.textContent;
                            code.textContent = "Copied!";
                            code.style.background = "#46b450";
                            setTimeout(function() {
                                code.textContent = original;
                                code.style.background = "";
                            }, 1000);
                        });
                    });
                });
            });
        ';
        wp_add_inline_script('jquery', $js);
    }

    /**
     * Render admin page
     */
    public function renderPage(): void
    {
        if (!current_user_can(self::CAPABILITY)) {
            return;
        }

        $settings = self::get();
        ?>
        <div class="wrap acms-seo-admin">
            <h1><?php esc_html_e('SEO Settings', 'affiliatecms'); ?></h1>

            <?php settings_errors('acms_seo_settings'); ?>

            <nav class="nav-tab-wrapper">
                <a href="#general" class="nav-tab nav-tab-active"><?php esc_html_e('General', 'affiliatecms'); ?></a>
                <a href="#templates" class="nav-tab"><?php esc_html_e('Title & Meta Description', 'affiliatecms'); ?></a>
                <a href="#social" class="nav-tab"><?php esc_html_e('Social Profiles', 'affiliatecms'); ?></a>
                <a href="#schema" class="nav-tab"><?php esc_html_e('Schema', 'affiliatecms'); ?></a>
                <a href="#sitemap" class="nav-tab"><?php esc_html_e('Sitemap', 'affiliatecms'); ?></a>
                <a href="#redirects" class="nav-tab"><?php esc_html_e('Redirects', 'affiliatecms'); ?></a>
                <a href="#advanced" class="nav-tab"><?php esc_html_e('Advanced', 'affiliatecms'); ?></a>
            </nav>

            <form method="post" action="options.php">
                <?php settings_fields('acms_seo_settings_group'); ?>

                <!-- General Tab -->
                <div id="general" class="tab-content active">
                    <h3 class="section-title"><?php esc_html_e('Title Settings', 'affiliatecms'); ?></h3>
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="title_separator"><?php esc_html_e('Title Separator', 'affiliatecms'); ?></label>
                            </th>
                            <td>
                                <select name="<?php echo self::OPTION_NAME; ?>[title_separator]" id="title_separator">
                                    <?php
                                    $separators = [' | ' => '|', ' - ' => '-', ' — ' => '—', ' · ' => '·', ' » ' => '»'];
                                    foreach ($separators as $value => $label) :
                                    ?>
                                        <option value="<?php echo esc_attr($value); ?>" <?php selected($settings['title_separator'], $value); ?>>
                                            <?php echo esc_html($label); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <p class="description"><?php esc_html_e('Character between title parts.', 'affiliatecms'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="homepage_title"><?php esc_html_e('Homepage Title', 'affiliatecms'); ?></label>
                            </th>
                            <td>
                                <input type="text" name="<?php echo self::OPTION_NAME; ?>[homepage_title]" id="homepage_title"
                                       value="<?php echo esc_attr($settings['homepage_title']); ?>"
                                       placeholder="<?php echo esc_attr(get_bloginfo('name') . ' | ' . get_bloginfo('description')); ?>" />
                                <p class="description"><?php esc_html_e('Leave empty to use Site Title | Tagline.', 'affiliatecms'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="homepage_description"><?php esc_html_e('Homepage Description', 'affiliatecms'); ?></label>
                            </th>
                            <td>
                                <textarea name="<?php echo self::OPTION_NAME; ?>[homepage_description]" id="homepage_description"
                                          placeholder="<?php echo esc_attr(get_bloginfo('description')); ?>"><?php echo esc_textarea($settings['homepage_description']); ?></textarea>
                                <p class="description"><?php esc_html_e('Leave empty to use site tagline.', 'affiliatecms'); ?></p>
                            </td>
                        </tr>
                    </table>

                    <h3 class="section-title"><?php esc_html_e('Default Images', 'affiliatecms'); ?></h3>
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="default_og_image"><?php esc_html_e('Default Share Image', 'affiliatecms'); ?></label>
                            </th>
                            <td>
                                <input type="url" name="<?php echo self::OPTION_NAME; ?>[default_og_image]" id="default_og_image"
                                       value="<?php echo esc_url($settings['default_og_image']); ?>"
                                       placeholder="https://example.com/default-share.jpg" />
                                <p class="description"><?php esc_html_e('Used when posts have no featured image. Recommended: 1200x630px.', 'affiliatecms'); ?></p>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- Templates Tab -->
                <div id="templates" class="tab-content">
                    <div class="templates-layout">
                        <div class="templates-main">
                            <h3 class="section-title"><?php esc_html_e('Posts & Pages', 'affiliatecms'); ?></h3>
                            <table class="form-table">
                                <tr>
                                    <th scope="row">
                                        <label for="tpl_post_title"><?php esc_html_e('Post — Title', 'affiliatecms'); ?></label>
                                    </th>
                                    <td>
                                        <input type="text" name="<?php echo self::OPTION_NAME; ?>[tpl_post_title]" id="tpl_post_title"
                                               value="<?php echo esc_attr($settings['tpl_post_title'] ?? ''); ?>"
                                               placeholder="%title% %sep% %sitename%" class="widefat" />
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">
                                        <label for="tpl_post_desc"><?php esc_html_e('Post — Description', 'affiliatecms'); ?></label>
                                    </th>
                                    <td>
                                        <input type="text" name="<?php echo self::OPTION_NAME; ?>[tpl_post_desc]" id="tpl_post_desc"
                                               value="<?php echo esc_attr($settings['tpl_post_desc'] ?? ''); ?>"
                                               placeholder="<?php esc_attr_e('Leave empty to use excerpt', 'affiliatecms'); ?>" class="widefat" />
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">
                                        <label for="tpl_page_title"><?php esc_html_e('Page — Title', 'affiliatecms'); ?></label>
                                    </th>
                                    <td>
                                        <input type="text" name="<?php echo self::OPTION_NAME; ?>[tpl_page_title]" id="tpl_page_title"
                                               value="<?php echo esc_attr($settings['tpl_page_title'] ?? ''); ?>"
                                               placeholder="%title% %sep% %sitename%" class="widefat" />
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">
                                        <label for="tpl_page_desc"><?php esc_html_e('Page — Description', 'affiliatecms'); ?></label>
                                    </th>
                                    <td>
                                        <input type="text" name="<?php echo self::OPTION_NAME; ?>[tpl_page_desc]" id="tpl_page_desc"
                                               value="<?php echo esc_attr($settings['tpl_page_desc'] ?? ''); ?>"
                                               placeholder="<?php esc_attr_e('Leave empty to use excerpt', 'affiliatecms'); ?>" class="widefat" />
                                    </td>
                                </tr>
                            </table>

                            <h3 class="section-title"><?php esc_html_e('Custom Post Types', 'affiliatecms'); ?></h3>
                            <table class="form-table">
                                <tr>
                                    <th scope="row">
                                        <label for="tpl_review_title"><?php esc_html_e('Review — Title', 'affiliatecms'); ?></label>
                                    </th>
                                    <td>
                                        <input type="text" name="<?php echo self::OPTION_NAME; ?>[tpl_review_title]" id="tpl_review_title"
                                               value="<?php echo esc_attr($settings['tpl_review_title'] ?? ''); ?>"
                                               placeholder="%title% %sep% %sitename%" class="widefat" />
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">
                                        <label for="tpl_review_desc"><?php esc_html_e('Review — Description', 'affiliatecms'); ?></label>
                                    </th>
                                    <td>
                                        <input type="text" name="<?php echo self::OPTION_NAME; ?>[tpl_review_desc]" id="tpl_review_desc"
                                               value="<?php echo esc_attr($settings['tpl_review_desc'] ?? ''); ?>"
                                               placeholder="<?php esc_attr_e('Leave empty to use excerpt', 'affiliatecms'); ?>" class="widefat" />
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">
                                        <label for="tpl_deal_title"><?php esc_html_e('Deal — Title', 'affiliatecms'); ?></label>
                                    </th>
                                    <td>
                                        <input type="text" name="<?php echo self::OPTION_NAME; ?>[tpl_deal_title]" id="tpl_deal_title"
                                               value="<?php echo esc_attr($settings['tpl_deal_title'] ?? ''); ?>"
                                               placeholder="%title% %sep% %sitename%" class="widefat" />
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">
                                        <label for="tpl_deal_desc"><?php esc_html_e('Deal — Description', 'affiliatecms'); ?></label>
                                    </th>
                                    <td>
                                        <input type="text" name="<?php echo self::OPTION_NAME; ?>[tpl_deal_desc]" id="tpl_deal_desc"
                                               value="<?php echo esc_attr($settings['tpl_deal_desc'] ?? ''); ?>"
                                               placeholder="<?php esc_attr_e('Leave empty to use excerpt', 'affiliatecms'); ?>" class="widefat" />
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">
                                        <label for="tpl_guide_title"><?php esc_html_e('Guide — Title', 'affiliatecms'); ?></label>
                                    </th>
                                    <td>
                                        <input type="text" name="<?php echo self::OPTION_NAME; ?>[tpl_guide_title]" id="tpl_guide_title"
                                               value="<?php echo esc_attr($settings['tpl_guide_title'] ?? ''); ?>"
                                               placeholder="%title% %sep% %sitename%" class="widefat" />
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">
                                        <label for="tpl_guide_desc"><?php esc_html_e('Guide — Description', 'affiliatecms'); ?></label>
                                    </th>
                                    <td>
                                        <input type="text" name="<?php echo self::OPTION_NAME; ?>[tpl_guide_desc]" id="tpl_guide_desc"
                                               value="<?php echo esc_attr($settings['tpl_guide_desc'] ?? ''); ?>"
                                               placeholder="<?php esc_attr_e('Leave empty to use excerpt', 'affiliatecms'); ?>" class="widefat" />
                                    </td>
                                </tr>
                            </table>

                            <h3 class="section-title"><?php esc_html_e('Archives & Other Pages', 'affiliatecms'); ?></h3>
                            <table class="form-table">
                                <tr>
                                    <th scope="row">
                                        <label for="tpl_category_title"><?php esc_html_e('Category — Title', 'affiliatecms'); ?></label>
                                    </th>
                                    <td>
                                        <input type="text" name="<?php echo self::OPTION_NAME; ?>[tpl_category_title]" id="tpl_category_title"
                                               value="<?php echo esc_attr($settings['tpl_category_title'] ?? ''); ?>"
                                               placeholder="%term_title% %sep% %sitename%" class="widefat" />
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">
                                        <label for="tpl_category_desc"><?php esc_html_e('Category — Description', 'affiliatecms'); ?></label>
                                    </th>
                                    <td>
                                        <input type="text" name="<?php echo self::OPTION_NAME; ?>[tpl_category_desc]" id="tpl_category_desc"
                                               value="<?php echo esc_attr($settings['tpl_category_desc'] ?? ''); ?>"
                                               placeholder="<?php esc_attr_e('Leave empty to use category description', 'affiliatecms'); ?>" class="widefat" />
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">
                                        <label for="tpl_search_title"><?php esc_html_e('Search — Title', 'affiliatecms'); ?></label>
                                    </th>
                                    <td>
                                        <input type="text" name="<?php echo self::OPTION_NAME; ?>[tpl_search_title]" id="tpl_search_title"
                                               value="<?php echo esc_attr($settings['tpl_search_title'] ?? ''); ?>"
                                               placeholder="Search: %search_query% %sep% %sitename%" class="widefat" />
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">
                                        <label for="tpl_search_desc"><?php esc_html_e('Search — Description', 'affiliatecms'); ?></label>
                                    </th>
                                    <td>
                                        <input type="text" name="<?php echo self::OPTION_NAME; ?>[tpl_search_desc]" id="tpl_search_desc"
                                               value="<?php echo esc_attr($settings['tpl_search_desc'] ?? ''); ?>"
                                               placeholder="<?php esc_attr_e('Leave empty for auto-generated', 'affiliatecms'); ?>" class="widefat" />
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">
                                        <label for="tpl_404_title"><?php esc_html_e('404 — Title', 'affiliatecms'); ?></label>
                                    </th>
                                    <td>
                                        <input type="text" name="<?php echo self::OPTION_NAME; ?>[tpl_404_title]" id="tpl_404_title"
                                               value="<?php echo esc_attr($settings['tpl_404_title'] ?? ''); ?>"
                                               placeholder="Page Not Found %sep% %sitename%" class="widefat" />
                                    </td>
                                </tr>
                            </table>
                        </div>

                        <!-- Placeholder Reference Panel -->
                        <div class="templates-sidebar">
                            <div class="placeholder-panel">
                                <h4><?php esc_html_e('Available Placeholders', 'affiliatecms'); ?></h4>
                                <?php
                                $reference = Placeholders::getReference();
                                foreach ($reference as $group_key => $group) :
                                ?>
                                    <div class="placeholder-group">
                                        <h5><?php echo esc_html($group['label']); ?></h5>
                                        <ul>
                                            <?php foreach ($group['items'] as $placeholder => $desc) : ?>
                                                <li>
                                                    <code class="placeholder-copy" title="<?php esc_attr_e('Click to copy', 'affiliatecms'); ?>"><?php echo esc_html($placeholder); ?></code>
                                                    <span><?php echo esc_html($desc); ?></span>
                                                </li>
                                            <?php endforeach; ?>
                                        </ul>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Social Tab -->
                <div id="social" class="tab-content">
                    <h3 class="section-title"><?php esc_html_e('Social Profiles', 'affiliatecms'); ?></h3>
                    <p class="description"><?php esc_html_e('Used for Schema.org Organization and Open Graph tags.', 'affiliatecms'); ?></p>

                    <div class="social-grid" style="margin-top: 20px;">
                        <?php
                        $social_networks = [
                            'facebook'  => ['label' => 'Facebook', 'placeholder' => 'https://facebook.com/yourpage'],
                            'twitter'   => ['label' => 'Twitter/X', 'placeholder' => 'https://twitter.com/yourhandle'],
                            'instagram' => ['label' => 'Instagram', 'placeholder' => 'https://instagram.com/yourprofile'],
                            'youtube'   => ['label' => 'YouTube', 'placeholder' => 'https://youtube.com/@yourchannel'],
                            'linkedin'  => ['label' => 'LinkedIn', 'placeholder' => 'https://linkedin.com/company/yourcompany'],
                            'pinterest' => ['label' => 'Pinterest', 'placeholder' => 'https://pinterest.com/yourprofile'],
                            'tiktok'    => ['label' => 'TikTok', 'placeholder' => 'https://tiktok.com/@yourprofile'],
                        ];
                        foreach ($social_networks as $key => $data) :
                        ?>
                            <div class="social-item">
                                <label for="social_<?php echo $key; ?>"><?php echo esc_html($data['label']); ?></label>
                                <input type="url" name="<?php echo self::OPTION_NAME; ?>[social][<?php echo $key; ?>]" id="social_<?php echo $key; ?>"
                                       value="<?php echo esc_url($settings['social'][$key] ?? ''); ?>"
                                       placeholder="<?php echo esc_attr($data['placeholder']); ?>" />
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <h3 class="section-title" style="margin-top: 30px;"><?php esc_html_e('Contact Information', 'affiliatecms'); ?></h3>
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="contact_email"><?php esc_html_e('Contact Email', 'affiliatecms'); ?></label>
                            </th>
                            <td>
                                <input type="email" name="<?php echo self::OPTION_NAME; ?>[contact_email]" id="contact_email"
                                       value="<?php echo esc_attr($settings['contact_email']); ?>"
                                       placeholder="contact@example.com" />
                                <p class="description"><?php esc_html_e('Used in Organization schema.', 'affiliatecms'); ?></p>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- Schema Tab -->
                <div id="schema" class="tab-content">
                    <h3 class="section-title"><?php esc_html_e('Organization Schema', 'affiliatecms'); ?></h3>
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="organization_type"><?php esc_html_e('Organization Type', 'affiliatecms'); ?></label>
                            </th>
                            <td>
                                <select name="<?php echo self::OPTION_NAME; ?>[organization_type]" id="organization_type">
                                    <?php
                                    $org_types = [
                                        'Organization' => 'Organization (General)',
                                        'Corporation' => 'Corporation',
                                        'LocalBusiness' => 'Local Business',
                                        'OnlineBusiness' => 'Online Business',
                                        'NewsMediaOrganization' => 'News/Media',
                                    ];
                                    foreach ($org_types as $value => $label) :
                                    ?>
                                        <option value="<?php echo esc_attr($value); ?>" <?php selected($settings['organization_type'], $value); ?>>
                                            <?php echo esc_html($label); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="organization_name"><?php esc_html_e('Organization Name', 'affiliatecms'); ?></label>
                            </th>
                            <td>
                                <input type="text" name="<?php echo self::OPTION_NAME; ?>[organization_name]" id="organization_name"
                                       value="<?php echo esc_attr($settings['organization_name']); ?>"
                                       placeholder="<?php echo esc_attr(get_bloginfo('name')); ?>" />
                                <p class="description"><?php esc_html_e('Leave empty to use site name.', 'affiliatecms'); ?></p>
                            </td>
                        </tr>
                    </table>

                    <h3 class="section-title"><?php esc_html_e('Schema Features', 'affiliatecms'); ?></h3>
                    <table class="form-table">
                        <tr>
                            <th scope="row"><?php esc_html_e('Enable Schemas', 'affiliatecms'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="<?php echo self::OPTION_NAME; ?>[schema_article]" value="1"
                                           <?php checked($settings['schema_article'], 1); ?> />
                                    <?php esc_html_e('Article schema for posts', 'affiliatecms'); ?>
                                </label><br>
                                <label>
                                    <input type="checkbox" name="<?php echo self::OPTION_NAME; ?>[schema_breadcrumbs]" value="1"
                                           <?php checked($settings['schema_breadcrumbs'], 1); ?> />
                                    <?php esc_html_e('Breadcrumbs schema', 'affiliatecms'); ?>
                                </label><br>
                                <label>
                                    <input type="checkbox" name="<?php echo self::OPTION_NAME; ?>[schema_search]" value="1"
                                           <?php checked($settings['schema_search'], 1); ?> />
                                    <?php esc_html_e('SearchAction schema (sitelinks searchbox)', 'affiliatecms'); ?>
                                </label>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- Sitemap Tab -->
                <div id="sitemap" class="tab-content">
                    <h3 class="section-title"><?php esc_html_e('XML Sitemap', 'affiliatecms'); ?></h3>
                    <table class="form-table">
                        <tr>
                            <th scope="row"><?php esc_html_e('Sitemap URL', 'affiliatecms'); ?></th>
                            <td>
                                <code><?php echo esc_url(home_url('/sitemap.xml')); ?></code>
                                <a href="<?php echo esc_url(home_url('/sitemap.xml')); ?>" target="_blank" class="button button-small" style="margin-left: 10px;">
                                    <?php esc_html_e('View Sitemap', 'affiliatecms'); ?>
                                </a>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e('Include in Sitemap', 'affiliatecms'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="<?php echo self::OPTION_NAME; ?>[sitemap_posts]" value="1"
                                           <?php checked($settings['sitemap_posts'], 1); ?> />
                                    <?php esc_html_e('Posts', 'affiliatecms'); ?>
                                </label><br>
                                <label>
                                    <input type="checkbox" name="<?php echo self::OPTION_NAME; ?>[sitemap_pages]" value="1"
                                           <?php checked($settings['sitemap_pages'], 1); ?> />
                                    <?php esc_html_e('Pages', 'affiliatecms'); ?>
                                </label><br>
                                <label>
                                    <input type="checkbox" name="<?php echo self::OPTION_NAME; ?>[sitemap_categories]" value="1"
                                           <?php checked($settings['sitemap_categories'], 1); ?> />
                                    <?php esc_html_e('Categories', 'affiliatecms'); ?>
                                </label><br>
                                <label>
                                    <input type="checkbox" name="<?php echo self::OPTION_NAME; ?>[sitemap_tags]" value="1"
                                           <?php checked($settings['sitemap_tags'], 1); ?> />
                                    <?php esc_html_e('Tags', 'affiliatecms'); ?>
                                </label><br>
                                <label>
                                    <input type="checkbox" name="<?php echo self::OPTION_NAME; ?>[sitemap_cpt]" value="1"
                                           <?php checked($settings['sitemap_cpt'], 1); ?> />
                                    <?php esc_html_e('Custom Post Types (Reviews, Deals, Guides)', 'affiliatecms'); ?>
                                </label><br>
                                <label>
                                    <input type="checkbox" name="<?php echo self::OPTION_NAME; ?>[sitemap_seo_categories]" value="1"
                                           <?php checked($settings['sitemap_seo_categories'] ?? 1, 1); ?> />
                                    <?php esc_html_e('SEO Categories (/c/ pages)', 'affiliatecms'); ?>
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="sitemap_max_urls"><?php esc_html_e('Max URLs per Sitemap', 'affiliatecms'); ?></label>
                            </th>
                            <td>
                                <select name="<?php echo self::OPTION_NAME; ?>[sitemap_max_urls]" id="sitemap_max_urls">
                                    <?php
                                    $limits = [500, 1000, 2000, 5000, 10000];
                                    foreach ($limits as $limit) :
                                    ?>
                                        <option value="<?php echo $limit; ?>" <?php selected($settings['sitemap_max_urls'], $limit); ?>>
                                            <?php echo number_format($limit); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                        </tr>
                    </table>

                    <h3 class="section-title"><?php esc_html_e('Cache', 'affiliatecms'); ?></h3>
                    <table class="form-table">
                        <tr>
                            <th scope="row"><?php esc_html_e('Clear Sitemap Cache', 'affiliatecms'); ?></th>
                            <td>
                                <button type="button" class="button" id="clear-sitemap-cache">
                                    <?php esc_html_e('Clear Cache', 'affiliatecms'); ?>
                                </button>
                                <span id="cache-cleared-msg" style="display: none; color: green; margin-left: 10px;">
                                    <?php esc_html_e('Cache cleared!', 'affiliatecms'); ?>
                                </span>
                                <p class="description"><?php esc_html_e('Sitemap is cached for 24 hours. Clear if you need immediate updates.', 'affiliatecms'); ?></p>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- Redirects Tab -->
                <div id="redirects" class="tab-content">
                    <?php $this->renderRedirectsTab(); ?>
                </div>

                <!-- Advanced Tab -->
                <div id="advanced" class="tab-content">
                    <h3 class="section-title"><?php esc_html_e('Robots Meta', 'affiliatecms'); ?></h3>
                    <table class="form-table">
                        <tr>
                            <th scope="row"><?php esc_html_e('Auto Noindex', 'affiliatecms'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="<?php echo self::OPTION_NAME; ?>[noindex_search]" value="1"
                                           <?php checked($settings['noindex_search'], 1); ?> />
                                    <?php esc_html_e('Search results pages', 'affiliatecms'); ?>
                                </label><br>
                                <label>
                                    <input type="checkbox" name="<?php echo self::OPTION_NAME; ?>[noindex_archives]" value="1"
                                           <?php checked($settings['noindex_archives'], 1); ?> />
                                    <?php esc_html_e('Date archives', 'affiliatecms'); ?>
                                </label><br>
                                <label>
                                    <input type="checkbox" name="<?php echo self::OPTION_NAME; ?>[noindex_pagination]" value="1"
                                           <?php checked($settings['noindex_pagination'], 1); ?> />
                                    <?php esc_html_e('Paginated pages (page 2+)', 'affiliatecms'); ?>
                                </label><br>
                                <label>
                                    <input type="checkbox" name="<?php echo self::OPTION_NAME; ?>[noindex_author]" value="1"
                                           <?php checked($settings['noindex_author'], 1); ?> />
                                    <?php esc_html_e('Author archives (when empty)', 'affiliatecms'); ?>
                                </label>
                            </td>
                        </tr>
                    </table>

                    <h3 class="section-title"><?php esc_html_e('External Links', 'affiliatecms'); ?></h3>
                    <table class="form-table">
                        <tr>
                            <th scope="row"><?php esc_html_e('Link Attributes', 'affiliatecms'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="<?php echo self::OPTION_NAME; ?>[external_nofollow]" value="1"
                                           <?php checked($settings['external_nofollow'], 1); ?> />
                                    <?php esc_html_e('Add nofollow to external links', 'affiliatecms'); ?>
                                </label><br>
                                <label>
                                    <input type="checkbox" name="<?php echo self::OPTION_NAME; ?>[external_noopener]" value="1"
                                           <?php checked($settings['external_noopener'], 1); ?> />
                                    <?php esc_html_e('Add noopener noreferrer to external links (security)', 'affiliatecms'); ?>
                                </label><br>
                                <label>
                                    <input type="checkbox" name="<?php echo self::OPTION_NAME; ?>[external_blank]" value="1"
                                           <?php checked($settings['external_blank'], 1); ?> />
                                    <?php esc_html_e('Open external links in new tab', 'affiliatecms'); ?>
                                </label>
                                <p class="description"><?php esc_html_e('Applied to links in post content pointing to external domains.', 'affiliatecms'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e('Exclude Domains', 'affiliatecms'); ?></th>
                            <td>
                                <textarea name="<?php echo self::OPTION_NAME; ?>[external_exclude]" rows="3" style="width: 100%; max-width: 400px;"
                                          placeholder="amazon.com&#10;facebook.com"><?php echo esc_textarea($settings['external_exclude'] ?? ''); ?></textarea>
                                <p class="description"><?php esc_html_e('One domain per line. These domains will not have nofollow added.', 'affiliatecms'); ?></p>
                            </td>
                        </tr>
                    </table>

                    <h3 class="section-title"><?php esc_html_e('Internal Links', 'affiliatecms'); ?></h3>
                    <table class="form-table">
                        <tr>
                            <th scope="row"><?php esc_html_e('Nofollow Internal', 'affiliatecms'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="<?php echo self::OPTION_NAME; ?>[nofollow_tags]" value="1"
                                           <?php checked($settings['nofollow_tags'], 1); ?> />
                                    <?php esc_html_e('Tag archive links', 'affiliatecms'); ?>
                                </label><br>
                                <label>
                                    <input type="checkbox" name="<?php echo self::OPTION_NAME; ?>[nofollow_attachments]" value="1"
                                           <?php checked($settings['nofollow_attachments'], 1); ?> />
                                    <?php esc_html_e('Attachment/Media links', 'affiliatecms'); ?>
                                </label><br>
                                <label>
                                    <input type="checkbox" name="<?php echo self::OPTION_NAME; ?>[nofollow_author]" value="1"
                                           <?php checked($settings['nofollow_author'], 1); ?> />
                                    <?php esc_html_e('Author archive links', 'affiliatecms'); ?>
                                </label><br>
                                <label>
                                    <input type="checkbox" name="<?php echo self::OPTION_NAME; ?>[nofollow_login]" value="1"
                                           <?php checked($settings['nofollow_login'], 1); ?> />
                                    <?php esc_html_e('Login/Register links', 'affiliatecms'); ?>
                                </label>
                            </td>
                        </tr>
                    </table>

                    <h3 class="section-title"><?php esc_html_e('Output Cleaning', 'affiliatecms'); ?></h3>
                    <table class="form-table">
                        <tr>
                            <th scope="row"><?php esc_html_e('Remove from Head', 'affiliatecms'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="<?php echo self::OPTION_NAME; ?>[remove_shortlink]" value="1"
                                           <?php checked($settings['remove_shortlink'], 1); ?> />
                                    <?php esc_html_e('Shortlink tag', 'affiliatecms'); ?>
                                </label><br>
                                <label>
                                    <input type="checkbox" name="<?php echo self::OPTION_NAME; ?>[remove_rsd]" value="1"
                                           <?php checked($settings['remove_rsd'], 1); ?> />
                                    <?php esc_html_e('RSD link', 'affiliatecms'); ?>
                                </label><br>
                                <label>
                                    <input type="checkbox" name="<?php echo self::OPTION_NAME; ?>[remove_wlwmanifest]" value="1"
                                           <?php checked($settings['remove_wlwmanifest'], 1); ?> />
                                    <?php esc_html_e('WLW Manifest link', 'affiliatecms'); ?>
                                </label><br>
                                <label>
                                    <input type="checkbox" name="<?php echo self::OPTION_NAME; ?>[remove_generator]" value="1"
                                           <?php checked($settings['remove_generator'], 1); ?> />
                                    <?php esc_html_e('WordPress version', 'affiliatecms'); ?>
                                </label>
                            </td>
                        </tr>
                    </table>
                </div>

                <?php submit_button(); ?>
            </form>
        </div>

        <script>
        document.getElementById('clear-sitemap-cache').addEventListener('click', function() {
            var btn = this;
            btn.disabled = true;
            btn.textContent = '<?php esc_html_e('Clearing...', 'affiliatecms'); ?>';

            fetch('<?php echo esc_js(rest_url('acms/v1/seo/sitemap/clear-cache')); ?>', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': '<?php echo wp_create_nonce('wp_rest'); ?>' }
            })
            .then(function(response) { return response.json(); })
            .then(function(data) {
                btn.disabled = false;
                btn.textContent = '<?php esc_html_e('Clear Cache', 'affiliatecms'); ?>';
                if (data.success) {
                    document.getElementById('cache-cleared-msg').style.display = 'inline';
                    setTimeout(function() {
                        document.getElementById('cache-cleared-msg').style.display = 'none';
                    }, 3000);
                }
            });
        });
        </script>
        <?php
    }

    /**
     * Render Redirects & 404 Monitor tab content
     */
    private function renderRedirectsTab(): void
    {
        // Get data
        $redirects = Redirects::getAll(['limit' => 50]);
        $redirects_count = Redirects::getCount();
        $logs_404 = Monitor404::getAll(['limit' => 50]);
        $logs_404_count = Monitor404::getCount();
        $stats_404 = Monitor404::getStats();
        ?>
        <div class="redirects-subtabs">
            <a href="#redirects-list" class="active" data-subtab="redirects-list"><?php esc_html_e('Redirects', 'affiliatecms'); ?> (<?php echo $redirects_count; ?>)</a>
            <a href="#monitor-404" data-subtab="monitor-404"><?php esc_html_e('404 Monitor', 'affiliatecms'); ?> (<?php echo $logs_404_count; ?>)</a>
        </div>

        <!-- Redirects List -->
        <div id="redirects-list" class="redirects-subtab active">
            <h3 class="section-title"><?php esc_html_e('Add New Redirect', 'affiliatecms'); ?></h3>
            <div class="redirect-form">
                <div class="form-row">
                    <div>
                        <label for="redirect_source"><?php esc_html_e('Source URL (path)', 'affiliatecms'); ?></label>
                        <input type="text" id="redirect_source" placeholder="/old-page" />
                    </div>
                    <div>
                        <label for="redirect_target"><?php esc_html_e('Target URL', 'affiliatecms'); ?></label>
                        <input type="text" id="redirect_target" placeholder="<?php echo esc_url(home_url('/new-page')); ?>" />
                    </div>
                    <div style="flex: 0 0 120px;">
                        <label for="redirect_type"><?php esc_html_e('Type', 'affiliatecms'); ?></label>
                        <select id="redirect_type">
                            <option value="301">301 (Permanent)</option>
                            <option value="302">302 (Temporary)</option>
                        </select>
                    </div>
                </div>
                <button type="button" class="button button-primary" id="add-redirect">
                    <?php esc_html_e('Add Redirect', 'affiliatecms'); ?>
                </button>
                <span id="redirect-message" style="margin-left: 10px; display: none;"></span>
            </div>

            <h3 class="section-title"><?php esc_html_e('Existing Redirects', 'affiliatecms'); ?></h3>
            <?php if (empty($redirects)) : ?>
                <div class="empty-state">
                    <p><?php esc_html_e('No redirects configured yet.', 'affiliatecms'); ?></p>
                </div>
            <?php else : ?>
                <table class="redirects-table" id="redirects-table">
                    <thead>
                        <tr>
                            <th><?php esc_html_e('Source', 'affiliatecms'); ?></th>
                            <th><?php esc_html_e('Target', 'affiliatecms'); ?></th>
                            <th><?php esc_html_e('Type', 'affiliatecms'); ?></th>
                            <th><?php esc_html_e('Hits', 'affiliatecms'); ?></th>
                            <th><?php esc_html_e('Actions', 'affiliatecms'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($redirects as $redirect) : ?>
                            <tr data-id="<?php echo esc_attr($redirect['id']); ?>">
                                <td class="url-cell"><?php echo esc_html($redirect['source_url']); ?></td>
                                <td class="url-cell"><?php echo esc_html($redirect['target_url']); ?></td>
                                <td>
                                    <span class="badge badge-<?php echo esc_attr($redirect['redirect_type']); ?>">
                                        <?php echo esc_html($redirect['redirect_type']); ?>
                                    </span>
                                </td>
                                <td class="hit-count"><?php echo number_format($redirect['hit_count']); ?></td>
                                <td class="actions">
                                    <a href="#" class="delete-redirect delete" data-id="<?php echo esc_attr($redirect['id']); ?>">
                                        <?php esc_html_e('Delete', 'affiliatecms'); ?>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        <!-- 404 Monitor -->
        <div id="monitor-404" class="redirects-subtab">
            <div class="stats-grid">
                <div class="stat-box">
                    <div class="number"><?php echo number_format($stats_404['total_urls']); ?></div>
                    <div class="label"><?php esc_html_e('Unique 404 URLs', 'affiliatecms'); ?></div>
                </div>
                <div class="stat-box">
                    <div class="number"><?php echo number_format($stats_404['total_hits']); ?></div>
                    <div class="label"><?php esc_html_e('Total 404 Hits', 'affiliatecms'); ?></div>
                </div>
                <div class="stat-box">
                    <div class="number"><?php echo number_format($stats_404['recent_24h']); ?></div>
                    <div class="label"><?php esc_html_e('Last 24 Hours', 'affiliatecms'); ?></div>
                </div>
            </div>

            <h3 class="section-title">
                <?php esc_html_e('404 Errors', 'affiliatecms'); ?>
                <button type="button" class="button button-small" id="clear-404-logs" style="margin-left: 10px;">
                    <?php esc_html_e('Clear All', 'affiliatecms'); ?>
                </button>
            </h3>

            <?php if (empty($logs_404)) : ?>
                <div class="empty-state">
                    <p><?php esc_html_e('No 404 errors recorded yet.', 'affiliatecms'); ?></p>
                </div>
            <?php else : ?>
                <table class="redirects-table" id="logs-404-table">
                    <thead>
                        <tr>
                            <th><?php esc_html_e('URL', 'affiliatecms'); ?></th>
                            <th><?php esc_html_e('Hits', 'affiliatecms'); ?></th>
                            <th><?php esc_html_e('Last Hit', 'affiliatecms'); ?></th>
                            <th><?php esc_html_e('Referrer', 'affiliatecms'); ?></th>
                            <th><?php esc_html_e('Actions', 'affiliatecms'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($logs_404 as $log) : ?>
                            <tr data-id="<?php echo esc_attr($log['id']); ?>">
                                <td class="url-cell"><?php echo esc_html($log['url']); ?></td>
                                <td class="hit-count"><?php echo number_format($log['hit_count']); ?></td>
                                <td><?php echo esc_html(human_time_diff(strtotime($log['last_hit'])) . ' ago'); ?></td>
                                <td class="url-cell">
                                    <?php if ($log['referrer']) : ?>
                                        <?php echo esc_html(wp_parse_url($log['referrer'], PHP_URL_HOST) ?: $log['referrer']); ?>
                                    <?php else : ?>
                                        <em><?php esc_html_e('Direct', 'affiliatecms'); ?></em>
                                    <?php endif; ?>
                                </td>
                                <td class="actions">
                                    <a href="#" class="create-redirect-from-404" data-id="<?php echo esc_attr($log['id']); ?>" data-url="<?php echo esc_attr($log['url']); ?>">
                                        <?php esc_html_e('Redirect', 'affiliatecms'); ?>
                                    </a>
                                    <a href="#" class="ignore-404" data-id="<?php echo esc_attr($log['id']); ?>">
                                        <?php esc_html_e('Ignore', 'affiliatecms'); ?>
                                    </a>
                                    <a href="#" class="delete-404 delete" data-id="<?php echo esc_attr($log['id']); ?>">
                                        <?php esc_html_e('Delete', 'affiliatecms'); ?>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        <!-- Redirect Modal -->
        <div id="redirect-modal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 100000;">
            <div style="background: #fff; max-width: 400px; margin: 100px auto; padding: 20px; border-radius: 4px;">
                <h3 style="margin-top: 0;"><?php esc_html_e('Create Redirect', 'affiliatecms'); ?></h3>
                <p><strong><?php esc_html_e('Source:', 'affiliatecms'); ?></strong> <span id="modal-source"></span></p>
                <p>
                    <label for="modal-target"><strong><?php esc_html_e('Target URL:', 'affiliatecms'); ?></strong></label>
                    <input type="text" id="modal-target" style="width: 100%; margin-top: 5px;" placeholder="<?php echo esc_url(home_url('/')); ?>" />
                </p>
                <input type="hidden" id="modal-log-id" />
                <p style="text-align: right; margin-bottom: 0;">
                    <button type="button" class="button" id="modal-cancel"><?php esc_html_e('Cancel', 'affiliatecms'); ?></button>
                    <button type="button" class="button button-primary" id="modal-save"><?php esc_html_e('Create Redirect', 'affiliatecms'); ?></button>
                </p>
            </div>
        </div>

        <script>
        (function() {
            var restUrl = '<?php echo esc_js(rest_url('acms/v1/seo/')); ?>';
            var nonce = '<?php echo wp_create_nonce('wp_rest'); ?>';
            var headers = { 'Content-Type': 'application/json', 'X-WP-Nonce': nonce };

            // Subtabs
            document.querySelectorAll('.redirects-subtabs a').forEach(function(tab) {
                tab.addEventListener('click', function(e) {
                    e.preventDefault();
                    var target = this.getAttribute('data-subtab');
                    document.querySelectorAll('.redirects-subtabs a').forEach(function(t) { t.classList.remove('active'); });
                    document.querySelectorAll('.redirects-subtab').forEach(function(c) { c.classList.remove('active'); });
                    this.classList.add('active');
                    document.getElementById(target).classList.add('active');
                });
            });

            // Add redirect
            document.getElementById('add-redirect').addEventListener('click', function() {
                var source = document.getElementById('redirect_source').value;
                var target = document.getElementById('redirect_target').value;
                var type = document.getElementById('redirect_type').value;
                var msg = document.getElementById('redirect-message');

                if (!source || !target) {
                    msg.textContent = '<?php esc_html_e('Please fill in both fields', 'affiliatecms'); ?>';
                    msg.style.color = 'red';
                    msg.style.display = 'inline';
                    return;
                }

                fetch(restUrl + 'redirects', {
                    method: 'POST',
                    headers: headers,
                    body: JSON.stringify({ source: source, target: target, type: parseInt(type) })
                })
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    if (data.success) {
                        msg.textContent = '<?php esc_html_e('Redirect added!', 'affiliatecms'); ?>';
                        msg.style.color = 'green';
                        msg.style.display = 'inline';
                        document.getElementById('redirect_source').value = '';
                        document.getElementById('redirect_target').value = '';
                        setTimeout(function() { location.reload(); }, 1000);
                    } else {
                        msg.textContent = data.message || '<?php esc_html_e('Error adding redirect', 'affiliatecms'); ?>';
                        msg.style.color = 'red';
                        msg.style.display = 'inline';
                    }
                });
            });

            // Delete redirect
            document.querySelectorAll('.delete-redirect').forEach(function(link) {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    if (!confirm('<?php esc_html_e('Delete this redirect?', 'affiliatecms'); ?>')) return;
                    var id = this.getAttribute('data-id');
                    var row = this.closest('tr');
                    fetch(restUrl + 'redirects/' + id, {
                        method: 'DELETE',
                        headers: headers
                    })
                    .then(function(r) { return r.json(); })
                    .then(function(data) {
                        if (data.success) row.remove();
                    });
                });
            });

            // Create redirect from 404
            document.querySelectorAll('.create-redirect-from-404').forEach(function(link) {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    document.getElementById('modal-source').textContent = this.getAttribute('data-url');
                    document.getElementById('modal-log-id').value = this.getAttribute('data-id');
                    document.getElementById('modal-target').value = '';
                    document.getElementById('redirect-modal').style.display = 'block';
                });
            });

            // Modal cancel
            document.getElementById('modal-cancel').addEventListener('click', function() {
                document.getElementById('redirect-modal').style.display = 'none';
            });

            // Modal save
            document.getElementById('modal-save').addEventListener('click', function() {
                var logId = document.getElementById('modal-log-id').value;
                var target = document.getElementById('modal-target').value;
                if (!target) {
                    alert('<?php esc_html_e('Please enter target URL', 'affiliatecms'); ?>');
                    return;
                }
                fetch(restUrl + '404s/' + logId + '/redirect', {
                    method: 'POST',
                    headers: headers,
                    body: JSON.stringify({ target: target })
                })
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    if (data.success) {
                        document.getElementById('redirect-modal').style.display = 'none';
                        document.querySelector('tr[data-id="' + logId + '"]').style.opacity = '0.5';
                        alert('<?php esc_html_e('Redirect created!', 'affiliatecms'); ?>');
                    } else {
                        alert(data.message || '<?php esc_html_e('Error', 'affiliatecms'); ?>');
                    }
                });
            });

            // Ignore 404
            document.querySelectorAll('.ignore-404').forEach(function(link) {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    var id = this.getAttribute('data-id');
                    var row = this.closest('tr');
                    fetch(restUrl + '404s/' + id + '/ignore', {
                        method: 'POST',
                        headers: headers
                    })
                    .then(function(r) { return r.json(); })
                    .then(function(data) {
                        if (data.success) row.remove();
                    });
                });
            });

            // Delete 404
            document.querySelectorAll('.delete-404').forEach(function(link) {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    var id = this.getAttribute('data-id');
                    var row = this.closest('tr');
                    fetch(restUrl + '404s/' + id, {
                        method: 'DELETE',
                        headers: headers
                    })
                    .then(function(r) { return r.json(); })
                    .then(function(data) {
                        if (data.success) row.remove();
                    });
                });
            });

            // Clear all 404 logs
            document.getElementById('clear-404-logs').addEventListener('click', function() {
                if (!confirm('<?php esc_html_e('Clear all 404 logs? This cannot be undone.', 'affiliatecms'); ?>')) return;
                fetch(restUrl + '404s', {
                    method: 'DELETE',
                    headers: headers
                })
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    if (data.success) location.reload();
                });
            });
        })();
        </script>
        <?php
    }

    /**
     * Sanitize settings
     */
    public function sanitizeSettings(array $input): array
    {
        $sanitized = [];
        $defaults = self::getDefaults();

        // Text fields
        $sanitized['title_separator'] = sanitize_text_field($input['title_separator'] ?? $defaults['title_separator']);
        $sanitized['homepage_title'] = sanitize_text_field($input['homepage_title'] ?? '');
        $sanitized['homepage_description'] = sanitize_textarea_field($input['homepage_description'] ?? '');
        $sanitized['default_og_image'] = esc_url_raw($input['default_og_image'] ?? '');
        $sanitized['contact_email'] = sanitize_email($input['contact_email'] ?? '');
        $sanitized['organization_type'] = sanitize_text_field($input['organization_type'] ?? 'Organization');
        $sanitized['organization_name'] = sanitize_text_field($input['organization_name'] ?? '');

        // Template fields (allow %placeholder% syntax)
        $template_fields = [
            'tpl_post_title', 'tpl_post_desc',
            'tpl_page_title', 'tpl_page_desc',
            'tpl_review_title', 'tpl_review_desc',
            'tpl_deal_title', 'tpl_deal_desc',
            'tpl_guide_title', 'tpl_guide_desc',
            'tpl_category_title', 'tpl_category_desc',
            'tpl_search_title', 'tpl_search_desc',
            'tpl_404_title',
        ];
        foreach ($template_fields as $field) {
            $sanitized[$field] = sanitize_text_field($input[$field] ?? '');
        }

        // Social profiles
        $sanitized['social'] = [];
        if (isset($input['social']) && is_array($input['social'])) {
            foreach ($input['social'] as $key => $url) {
                $sanitized['social'][sanitize_key($key)] = esc_url_raw($url);
            }
        }

        // Checkboxes
        $checkbox_fields = [
            'schema_article', 'schema_breadcrumbs', 'schema_search',
            'sitemap_posts', 'sitemap_pages', 'sitemap_categories', 'sitemap_tags', 'sitemap_cpt',
            'noindex_search', 'noindex_archives', 'noindex_pagination', 'noindex_author',
            'remove_shortlink', 'remove_rsd', 'remove_wlwmanifest', 'remove_generator',
            // Link settings
            'external_nofollow', 'external_noopener', 'external_blank',
            'nofollow_tags', 'nofollow_attachments', 'nofollow_author', 'nofollow_login',
        ];
        foreach ($checkbox_fields as $field) {
            $sanitized[$field] = !empty($input[$field]) ? 1 : 0;
        }

        // Textarea fields
        $sanitized['external_exclude'] = sanitize_textarea_field($input['external_exclude'] ?? '');

        // Numbers
        $sanitized['sitemap_max_urls'] = absint($input['sitemap_max_urls'] ?? 1000);

        // Clear caches when settings change
        delete_transient('acms_global_schema');
        Sitemap::clearCache();

        return $sanitized;
    }

    /**
     * Get default settings
     */
    public static function getDefaults(): array
    {
        return [
            'title_separator' => ' | ',
            'homepage_title' => '',
            'homepage_description' => '',
            'default_og_image' => '',
            'contact_email' => '',
            'organization_type' => 'Organization',
            'organization_name' => '',
            'social' => [
                'facebook' => '',
                'twitter' => '',
                'instagram' => '',
                'youtube' => '',
                'linkedin' => '',
                'pinterest' => '',
                'tiktok' => '',
            ],
            'schema_article' => 1,
            'schema_breadcrumbs' => 1,
            'schema_search' => 1,
            'sitemap_posts' => 1,
            'sitemap_pages' => 1,
            'sitemap_categories' => 1,
            'sitemap_tags' => 0,
            'sitemap_cpt' => 1,
            'sitemap_seo_categories' => 1,
            'sitemap_max_urls' => 1000,
            'noindex_search' => 1,
            'noindex_archives' => 1,
            'noindex_pagination' => 1,
            'noindex_author' => 1,
            'remove_shortlink' => 1,
            'remove_rsd' => 1,
            'remove_wlwmanifest' => 1,
            'remove_generator' => 1,
            // External link settings
            'external_nofollow' => 1,
            'external_noopener' => 1,
            'external_blank' => 0,
            'external_exclude' => '',
            // Internal link nofollow
            'nofollow_tags' => 0,
            'nofollow_attachments' => 1,
            'nofollow_author' => 0,
            'nofollow_login' => 1,
            // Title & Description templates (empty = use default logic)
            'tpl_post_title' => '',
            'tpl_post_desc' => '',
            'tpl_page_title' => '',
            'tpl_page_desc' => '',
            'tpl_review_title' => '',
            'tpl_review_desc' => '',
            'tpl_deal_title' => '',
            'tpl_deal_desc' => '',
            'tpl_guide_title' => '',
            'tpl_guide_desc' => '',
            'tpl_category_title' => '',
            'tpl_category_desc' => '',
            'tpl_search_title' => '',
            'tpl_search_desc' => '',
            'tpl_404_title' => '',
        ];
    }

    /**
     * Get all settings (cached)
     */
    public static function get(?string $key = null, $default = null)
    {
        if (self::$settings === null) {
            self::$settings = wp_parse_args(
                get_option(self::OPTION_NAME, []),
                self::getDefaults()
            );
        }

        if ($key === null) {
            return self::$settings;
        }

        return self::$settings[$key] ?? $default;
    }

    /**
     * Get social links array (for schema/OG)
     */
    public static function getSocialLinks(): array
    {
        $social = self::get('social', []);
        $links = [];

        $icons = [
            'facebook'  => 'bi-facebook',
            'twitter'   => 'bi-twitter-x',
            'instagram' => 'bi-instagram',
            'youtube'   => 'bi-youtube',
            'linkedin'  => 'bi-linkedin',
            'pinterest' => 'bi-pinterest',
            'tiktok'    => 'bi-tiktok',
        ];

        foreach ($social as $network => $url) {
            if (!empty($url)) {
                $links[$network] = [
                    'url' => $url,
                    'icon' => $icons[$network] ?? 'bi-link',
                    'label' => ucfirst($network),
                ];
            }
        }

        return $links;
    }

    // Prevent cloning
    private function __clone() {}
}
