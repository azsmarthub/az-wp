<?php
/**
 * SEO Module - Meta Box
 *
 * Adds SEO meta box to post editor for custom title, description, etc.
 *
 * @package AffiliateCMS
 * @since 4.0.0
 */

namespace AffiliateCMS\SEO;

if (!defined('ABSPATH')) {
    exit;
}

class MetaBox
{
    /**
     * Register meta box hooks
     */
    public static function register(): void
    {
        add_action('add_meta_boxes', [self::class, 'addMetaBox']);
        add_action('save_post', [self::class, 'save'], 10, 2);

        // Enqueue admin styles
        add_action('admin_enqueue_scripts', [self::class, 'enqueueStyles']);
    }

    /**
     * Add meta box to supported post types
     */
    public static function addMetaBox(): void
    {
        foreach (SEO::SUPPORTED_POST_TYPES as $post_type) {
            add_meta_box(
                'acms_seo_meta_box',
                __('SEO Settings', 'affiliatecms'),
                [self::class, 'render'],
                $post_type,
                'normal',
                'high'
            );
        }
    }

    /**
     * Render meta box
     */
    public static function render(\WP_Post $post): void
    {
        wp_nonce_field('acms_seo_meta_box', 'acms_seo_nonce');

        $title = get_post_meta($post->ID, '_acms_seo_title', true);
        $description = get_post_meta($post->ID, '_acms_seo_description', true);
        $canonical = get_post_meta($post->ID, '_acms_seo_canonical', true);
        $robots = get_post_meta($post->ID, '_acms_seo_robots', true);
        $og_image = get_post_meta($post->ID, '_acms_seo_og_image', true);

        // Get defaults for placeholders
        $default_title = get_the_title($post) . ' | ' . get_bloginfo('name');
        $default_desc = wp_trim_words(wp_strip_all_tags($post->post_content), 25, '...');
        ?>
        <div class="acms-seo-meta-box">
            <!-- SEO Title -->
            <div class="acms-seo-field">
                <label for="acms_seo_title">
                    <strong><?php esc_html_e('SEO Title', 'affiliatecms'); ?></strong>
                </label>
                <input
                    type="text"
                    id="acms_seo_title"
                    name="acms_seo_title"
                    value="<?php echo esc_attr($title); ?>"
                    placeholder="<?php echo esc_attr($default_title); ?>"
                    class="widefat"
                />
                <p class="description">
                    <?php esc_html_e('Recommended: 50-60 characters. Leave empty to use default.', 'affiliatecms'); ?>
                    <span class="acms-seo-counter" data-target="acms_seo_title" data-max="60"></span>
                </p>
            </div>

            <!-- Meta Description -->
            <div class="acms-seo-field">
                <label for="acms_seo_description">
                    <strong><?php esc_html_e('Meta Description', 'affiliatecms'); ?></strong>
                </label>
                <textarea
                    id="acms_seo_description"
                    name="acms_seo_description"
                    placeholder="<?php echo esc_attr($default_desc); ?>"
                    class="widefat"
                    rows="3"
                ><?php echo esc_textarea($description); ?></textarea>
                <p class="description">
                    <?php esc_html_e('Recommended: 120-155 characters. Leave empty to use excerpt.', 'affiliatecms'); ?>
                    <span class="acms-seo-counter" data-target="acms_seo_description" data-max="155"></span>
                </p>
            </div>

            <!-- SEO Preview -->
            <div class="acms-seo-preview">
                <h4><?php esc_html_e('Search Preview', 'affiliatecms'); ?></h4>
                <div class="acms-seo-preview__container">
                    <div class="acms-seo-preview__title" id="seo-preview-title">
                        <?php echo esc_html($title ?: $default_title); ?>
                    </div>
                    <div class="acms-seo-preview__url">
                        <?php echo esc_url(get_permalink($post)); ?>
                    </div>
                    <div class="acms-seo-preview__desc" id="seo-preview-desc">
                        <?php echo esc_html($description ?: $default_desc); ?>
                    </div>
                </div>
            </div>

            <!-- Advanced Settings (Collapsible) -->
            <details class="acms-seo-advanced">
                <summary><?php esc_html_e('Advanced Settings', 'affiliatecms'); ?></summary>

                <!-- Canonical URL -->
                <div class="acms-seo-field">
                    <label for="acms_seo_canonical">
                        <strong><?php esc_html_e('Canonical URL', 'affiliatecms'); ?></strong>
                    </label>
                    <input
                        type="url"
                        id="acms_seo_canonical"
                        name="acms_seo_canonical"
                        value="<?php echo esc_url($canonical); ?>"
                        placeholder="<?php echo esc_url(get_permalink($post)); ?>"
                        class="widefat"
                    />
                    <p class="description">
                        <?php esc_html_e('Only set if this content exists elsewhere and you want to point to the original.', 'affiliatecms'); ?>
                    </p>
                </div>

                <!-- Robots -->
                <div class="acms-seo-field">
                    <label for="acms_seo_robots">
                        <strong><?php esc_html_e('Robots Meta', 'affiliatecms'); ?></strong>
                    </label>
                    <select id="acms_seo_robots" name="acms_seo_robots" class="widefat">
                        <option value="" <?php selected($robots, ''); ?>>
                            <?php esc_html_e('Default (index, follow)', 'affiliatecms'); ?>
                        </option>
                        <option value="noindex, follow" <?php selected($robots, 'noindex, follow'); ?>>
                            <?php esc_html_e('No Index, Follow', 'affiliatecms'); ?>
                        </option>
                        <option value="index, nofollow" <?php selected($robots, 'index, nofollow'); ?>>
                            <?php esc_html_e('Index, No Follow', 'affiliatecms'); ?>
                        </option>
                        <option value="noindex, nofollow" <?php selected($robots, 'noindex, nofollow'); ?>>
                            <?php esc_html_e('No Index, No Follow', 'affiliatecms'); ?>
                        </option>
                    </select>
                </div>

                <!-- OG Image -->
                <div class="acms-seo-field">
                    <label for="acms_seo_og_image">
                        <strong><?php esc_html_e('Social Share Image', 'affiliatecms'); ?></strong>
                    </label>
                    <div class="acms-seo-image-field">
                        <input
                            type="hidden"
                            id="acms_seo_og_image"
                            name="acms_seo_og_image"
                            value="<?php echo esc_attr($og_image); ?>"
                        />
                        <div class="acms-seo-image-preview" id="og-image-preview">
                            <?php if ($og_image) : ?>
                                <?php echo wp_get_attachment_image($og_image, 'medium'); ?>
                            <?php endif; ?>
                        </div>
                        <button type="button" class="button" id="acms-seo-upload-image">
                            <?php esc_html_e('Select Image', 'affiliatecms'); ?>
                        </button>
                        <button type="button" class="button" id="acms-seo-remove-image" <?php echo $og_image ? '' : 'style="display:none;"'; ?>>
                            <?php esc_html_e('Remove', 'affiliatecms'); ?>
                        </button>
                    </div>
                    <p class="description">
                        <?php esc_html_e('Recommended: 1200x630 pixels. Leave empty to use featured image.', 'affiliatecms'); ?>
                    </p>
                </div>
            </details>
        </div>

        <script>
        jQuery(document).ready(function($) {
            // Character counter
            function updateCounter(input, max) {
                var length = $(input).val().length;
                var counter = $('[data-target="' + $(input).attr('id') + '"]');
                counter.text(length + '/' + max);
                if (length > max) {
                    counter.css('color', '#dc3545');
                } else if (length > max * 0.9) {
                    counter.css('color', '#ffc107');
                } else {
                    counter.css('color', '#28a745');
                }
            }

            // Update preview
            function updatePreview() {
                var title = $('#acms_seo_title').val() || $('#acms_seo_title').attr('placeholder');
                var desc = $('#acms_seo_description').val() || $('#acms_seo_description').attr('placeholder');
                $('#seo-preview-title').text(title);
                $('#seo-preview-desc').text(desc);
            }

            // Initialize counters
            $('[data-target]').each(function() {
                var target = $('#' + $(this).data('target'));
                var max = $(this).data('max');
                updateCounter(target, max);
                target.on('input', function() {
                    updateCounter(this, max);
                    updatePreview();
                });
            });

            // Media uploader for OG image
            var mediaUploader;
            $('#acms-seo-upload-image').on('click', function(e) {
                e.preventDefault();
                if (mediaUploader) {
                    mediaUploader.open();
                    return;
                }
                mediaUploader = wp.media({
                    title: '<?php esc_html_e('Select Social Share Image', 'affiliatecms'); ?>',
                    button: { text: '<?php esc_html_e('Use this image', 'affiliatecms'); ?>' },
                    multiple: false
                });
                mediaUploader.on('select', function() {
                    var attachment = mediaUploader.state().get('selection').first().toJSON();
                    $('#acms_seo_og_image').val(attachment.id);
                    $('#og-image-preview').html('<img src="' + attachment.sizes.medium.url + '" />');
                    $('#acms-seo-remove-image').show();
                });
                mediaUploader.open();
            });

            $('#acms-seo-remove-image').on('click', function(e) {
                e.preventDefault();
                $('#acms_seo_og_image').val('');
                $('#og-image-preview').html('');
                $(this).hide();
            });
        });
        </script>
        <?php
    }

    /**
     * Save meta box data
     */
    public static function save(int $post_id, \WP_Post $post): void
    {
        // Verify nonce
        if (!isset($_POST['acms_seo_nonce']) || !wp_verify_nonce($_POST['acms_seo_nonce'], 'acms_seo_meta_box')) {
            return;
        }

        // Check autosave
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        // Check permissions
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }

        // Check post type
        if (!in_array($post->post_type, SEO::SUPPORTED_POST_TYPES, true)) {
            return;
        }

        // Fields to save
        $fields = [
            'acms_seo_title'       => 'sanitize_text_field',
            'acms_seo_description' => 'sanitize_textarea_field',
            'acms_seo_canonical'   => 'esc_url_raw',
            'acms_seo_robots'      => 'sanitize_text_field',
            'acms_seo_og_image'    => 'absint',
        ];

        foreach ($fields as $field => $sanitize) {
            $meta_key = '_' . $field;
            $value = isset($_POST[$field]) ? call_user_func($sanitize, $_POST[$field]) : '';

            if ($value) {
                update_post_meta($post_id, $meta_key, $value);
            } else {
                delete_post_meta($post_id, $meta_key);
            }
        }
    }

    /**
     * Enqueue admin styles for meta box
     */
    public static function enqueueStyles(string $hook): void
    {
        if (!in_array($hook, ['post.php', 'post-new.php'], true)) {
            return;
        }

        // Enqueue media uploader
        wp_enqueue_media();

        // Inline CSS for meta box
        $css = '
            .acms-seo-meta-box { padding: 10px 0; }
            .acms-seo-field { margin-bottom: 20px; }
            .acms-seo-field label { display: block; margin-bottom: 5px; }
            .acms-seo-field textarea { resize: vertical; }
            .acms-seo-counter { float: right; font-size: 12px; }

            .acms-seo-preview { background: #fff; border: 1px solid #ddd; border-radius: 4px; padding: 15px; margin: 20px 0; }
            .acms-seo-preview h4 { margin: 0 0 10px; font-size: 12px; color: #666; text-transform: uppercase; }
            .acms-seo-preview__container { font-family: Arial, sans-serif; }
            .acms-seo-preview__title { color: #1a0dab; font-size: 18px; line-height: 1.3; margin-bottom: 2px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
            .acms-seo-preview__url { color: #006621; font-size: 13px; margin-bottom: 2px; }
            .acms-seo-preview__desc { color: #545454; font-size: 13px; line-height: 1.4; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }

            .acms-seo-advanced { margin-top: 20px; border: 1px solid #ddd; border-radius: 4px; }
            .acms-seo-advanced summary { padding: 10px 15px; cursor: pointer; background: #f9f9f9; font-weight: 600; }
            .acms-seo-advanced > div { padding: 15px; }

            .acms-seo-image-field { display: flex; align-items: flex-start; gap: 10px; flex-wrap: wrap; }
            .acms-seo-image-preview { flex: 0 0 150px; }
            .acms-seo-image-preview img { max-width: 150px; height: auto; border: 1px solid #ddd; border-radius: 4px; }
        ';

        wp_add_inline_style('common', $css);
    }
}
