<?php
/**
 * Deals REST API Endpoints
 *
 * @package AffiliateCMS
 * @since 4.0.0
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Get category ID and all descendant IDs using materialized path
 *
 * @param int $category_id Root category ID
 * @return array Array of category IDs (root + all descendants)
 */
function acms_get_category_descendant_ids(int $category_id): array {
    global $wpdb;
    $table = $wpdb->prefix . 'acms_categories';

    $ids = $wpdb->get_col($wpdb->prepare(
        "SELECT id FROM {$table}
         WHERE (id = %d OR path LIKE %s)
         AND status = 'publish'",
        $category_id,
        '%/' . $category_id . '/%'
    ));

    return array_map('intval', $ids);
}

/**
 * Deals condition for products with active discounts
 */
function acms_deals_where_clause(): string {
    return "status = 'scraped'
        AND original_price IS NOT NULL
        AND original_price > 0
        AND price IS NOT NULL
        AND price > 0
        AND original_price > price";
}

/**
 * Register REST API routes for deals
 */
function acms_register_deals_rest_routes() {
    register_rest_route('acms/v1', '/deals', [
        'methods' => 'GET',
        'callback' => 'acms_rest_get_deals',
        'permission_callback' => '__return_true', // Public endpoint
        'args' => [
            'category_id' => [
                'description' => 'Category ID to filter deals (0 for all)',
                'type' => 'integer',
                'default' => 0,
                'sanitize_callback' => 'absint',
            ],
            'offset' => [
                'description' => 'Number of items to skip',
                'type' => 'integer',
                'default' => 0,
                'sanitize_callback' => 'absint',
            ],
            'per_page' => [
                'description' => 'Number of items per page',
                'type' => 'integer',
                'default' => 24,
                'sanitize_callback' => 'absint',
            ],
        ],
    ]);
}
add_action('rest_api_init', 'acms_register_deals_rest_routes');

/**
 * REST API: Get deals with optional category filtering
 *
 * @param WP_REST_Request $request REST request object
 * @return WP_REST_Response REST response
 */
function acms_rest_get_deals($request) {
    // Get parameters
    $category_id = $request->get_param('category_id');
    $offset = $request->get_param('offset');
    $per_page = min($request->get_param('per_page'), 100); // Max 100 per request

    global $wpdb;
    $products_table = $wpdb->prefix . 'acms_products';
    $category_products_table = $wpdb->prefix . 'acms_category_products';

    $deals_where = acms_deals_where_clause();

    // Build query based on category filter
    if ($category_id > 0) {
        // Get this category + all descendant IDs
        $cat_ids = acms_get_category_descendant_ids($category_id);

        if (empty($cat_ids)) {
            $products = [];
            $total_products = 0;
        } else {
            $placeholders = implode(',', array_fill(0, count($cat_ids), '%d'));

            $products = $wpdb->get_results($wpdb->prepare(
                "SELECT DISTINCT p.asin,
                        p.price,
                        p.original_price,
                        ROUND(((p.original_price - p.price) / p.original_price) * 100, 0) as discount_percent
                 FROM {$products_table} p
                 INNER JOIN {$category_products_table} cp ON p.id = cp.product_id
                 WHERE cp.category_id IN ({$placeholders})
                 AND p.{$deals_where}
                 ORDER BY discount_percent DESC, p.created_at DESC
                 LIMIT %d OFFSET %d",
                ...array_merge($cat_ids, [$per_page, $offset])
            ), ARRAY_A);

            $total_products = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(DISTINCT p.id)
                 FROM {$products_table} p
                 INNER JOIN {$category_products_table} cp ON p.id = cp.product_id
                 WHERE cp.category_id IN ({$placeholders})
                 AND p.{$deals_where}",
                ...$cat_ids
            ));
        }
    } else {
        // No filter - all deals
        $products = $wpdb->get_results($wpdb->prepare(
            "SELECT asin, price, original_price,
                    ROUND(((original_price - price) / original_price) * 100, 0) as discount_percent
             FROM {$products_table}
             WHERE {$deals_where}
             ORDER BY discount_percent DESC, created_at DESC
             LIMIT %d OFFSET %d",
            $per_page,
            $offset
        ), ARRAY_A);

        $total_products = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$products_table} WHERE {$deals_where}"
        );
    }

    // Get ASINs
    $asins = array_column($products, 'asin');

    // Render products using shortcode
    $html = '';
    if (!empty($asins)) {
        $html = do_shortcode('[acms_list asin="' . implode(',', $asins) . '" numbered="true"]');
    }

    // Calculate pagination info
    $new_offset = $offset + count($products);
    $has_more = $new_offset < $total_products;

    // Return response
    return new WP_REST_Response([
        'success' => true,
        'data' => [
            'html' => $html,
            'has_more' => $has_more,
            'new_offset' => $new_offset,
            'loaded_count' => count($products),
            'total_count' => (int) $total_products,
        ],
    ], 200);
}
