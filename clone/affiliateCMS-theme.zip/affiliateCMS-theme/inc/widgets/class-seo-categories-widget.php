<?php
/**
 * ACMS SEO Categories Widget
 *
 * Displays root-level categories from the acms_categories table (Cat Queue system).
 *
 * @package AffiliateCMS
 * @since 4.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class ACMS_SEO_Categories_Widget extends WP_Widget {

    private $default_icons = [
        'electronics'      => 'bi-cpu-fill',
        'home-kitchen'     => 'bi-house-fill',
        'health-beauty'    => 'bi-heart-fill',
        'sports-outdoors'  => 'bi-bicycle',
        'baby-kids'        => 'bi-balloon-fill',
        'fashion'          => 'bi-bag-fill',
        'automotive'       => 'bi-car-front-fill',
        'books'            => 'bi-book-fill',
        'toys-games'       => 'bi-controller',
        'garden'           => 'bi-flower1',
    ];

    public function __construct() {
        parent::__construct(
            'acms_seo_categories',
            __('[AffiliateCMS] SEO Categories', 'affiliatecms'),
            [
                'description' => __('Display root SEO categories from the category queue system.', 'affiliatecms'),
                'classname'   => 'sidebar-widget acms-categories-widget',
            ]
        );
    }

    public function widget($args, $instance) {
        global $wpdb;

        $table = $wpdb->prefix . 'acms_categories';

        // Check table exists
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table)) !== $table) {
            return;
        }

        $title = !empty($instance['title']) ? $instance['title'] : __('Top Categories', 'affiliatecms');
        $number = !empty($instance['number']) ? absint($instance['number']) : 8;
        $show_count = isset($instance['show_count']) ? (bool) $instance['show_count'] : true;
        $show_icon = isset($instance['show_icon']) ? (bool) $instance['show_icon'] : true;
        $orderby = !empty($instance['orderby']) ? $instance['orderby'] : 'product_count';

        $allowed_orderby = ['product_count', 'name', 'id', 'child_count'];
        if (!in_array($orderby, $allowed_orderby, true)) {
            $orderby = 'product_count';
        }

        $order = ($orderby === 'name') ? 'ASC' : 'DESC';

        $categories = $wpdb->get_results($wpdb->prepare(
            "SELECT id, name, slug, icon, product_count, child_count
             FROM {$table}
             WHERE parent_id = 0 AND status = 'publish' AND brand_id IS NULL
             ORDER BY {$orderby} {$order}
             LIMIT %d",
            $number
        ), ARRAY_A) ?: [];

        echo $args['before_widget'];
        ?>
        <div class="sidebar-widget__header">
            <h3 class="sidebar-widget__title">
                <i class="bi bi-grid-fill"></i>
                <?php echo esc_html($title); ?>
            </h3>
        </div>
        <div class="sidebar-categories">
            <?php
            if (!empty($categories)) {
                foreach ($categories as $cat) {
                    $icon = !empty($cat['icon']) ? $cat['icon'] : (isset($this->default_icons[$cat['slug']]) ? $this->default_icons[$cat['slug']] : 'bi-folder-fill');
                    $url = home_url('/c/' . $cat['slug'] . '/');
                    $count = (int) $cat['product_count'];
                    ?>
                    <a href="<?php echo esc_url($url); ?>" class="sidebar-category">
                        <span class="sidebar-category__name">
                            <?php if ($show_icon) : ?>
                                <i class="bi <?php echo esc_attr($icon); ?>"></i>
                            <?php endif; ?>
                            <?php echo esc_html($cat['name']); ?>
                        </span>
                        <?php if ($show_count) : ?>
                            <span class="sidebar-category__count"><?php echo esc_html($count); ?></span>
                        <?php endif; ?>
                    </a>
                    <?php
                }
            } else {
                ?>
                <p class="sidebar-categories__empty"><?php esc_html_e('No categories yet.', 'affiliatecms'); ?></p>
                <?php
            }
            ?>
        </div>
        <?php
        echo $args['after_widget'];
    }

    public function form($instance) {
        $title = !empty($instance['title']) ? $instance['title'] : __('Top Categories', 'affiliatecms');
        $number = !empty($instance['number']) ? absint($instance['number']) : 8;
        $show_count = isset($instance['show_count']) ? (bool) $instance['show_count'] : true;
        $show_icon = isset($instance['show_icon']) ? (bool) $instance['show_icon'] : true;
        $orderby = !empty($instance['orderby']) ? $instance['orderby'] : 'product_count';
        ?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title:', 'affiliatecms'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('number')); ?>"><?php esc_html_e('Number of categories:', 'affiliatecms'); ?></label>
            <input class="tiny-text" id="<?php echo esc_attr($this->get_field_id('number')); ?>" name="<?php echo esc_attr($this->get_field_name('number')); ?>" type="number" step="1" min="1" max="30" value="<?php echo esc_attr($number); ?>" size="3">
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('orderby')); ?>"><?php esc_html_e('Order by:', 'affiliatecms'); ?></label>
            <select class="widefat" id="<?php echo esc_attr($this->get_field_id('orderby')); ?>" name="<?php echo esc_attr($this->get_field_name('orderby')); ?>">
                <option value="product_count" <?php selected($orderby, 'product_count'); ?>><?php esc_html_e('Product Count', 'affiliatecms'); ?></option>
                <option value="child_count" <?php selected($orderby, 'child_count'); ?>><?php esc_html_e('Subcategory Count', 'affiliatecms'); ?></option>
                <option value="name" <?php selected($orderby, 'name'); ?>><?php esc_html_e('Name', 'affiliatecms'); ?></option>
                <option value="id" <?php selected($orderby, 'id'); ?>><?php esc_html_e('Newest', 'affiliatecms'); ?></option>
            </select>
        </p>
        <p>
            <input class="checkbox" type="checkbox" <?php checked($show_icon); ?> id="<?php echo esc_attr($this->get_field_id('show_icon')); ?>" name="<?php echo esc_attr($this->get_field_name('show_icon')); ?>">
            <label for="<?php echo esc_attr($this->get_field_id('show_icon')); ?>"><?php esc_html_e('Show icons', 'affiliatecms'); ?></label>
        </p>
        <p>
            <input class="checkbox" type="checkbox" <?php checked($show_count); ?> id="<?php echo esc_attr($this->get_field_id('show_count')); ?>" name="<?php echo esc_attr($this->get_field_name('show_count')); ?>">
            <label for="<?php echo esc_attr($this->get_field_id('show_count')); ?>"><?php esc_html_e('Show product count', 'affiliatecms'); ?></label>
        </p>
        <?php
    }

    public function update($new_instance, $old_instance) {
        $instance = [];
        $instance['title'] = (!empty($new_instance['title'])) ? sanitize_text_field($new_instance['title']) : '';
        $instance['number'] = (!empty($new_instance['number'])) ? absint($new_instance['number']) : 8;
        $allowed_orderby = ['product_count', 'name', 'id', 'child_count'];
        $instance['orderby'] = (!empty($new_instance['orderby']) && in_array($new_instance['orderby'], $allowed_orderby, true)) ? $new_instance['orderby'] : 'product_count';
        $instance['show_icon'] = (!empty($new_instance['show_icon'])) ? true : false;
        $instance['show_count'] = (!empty($new_instance['show_count'])) ? true : false;
        return $instance;
    }
}
