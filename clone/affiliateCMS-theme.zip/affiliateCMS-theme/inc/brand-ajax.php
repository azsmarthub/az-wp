<?php
/**
 * Brand Archive REST API - Load more products
 *
 * @package AffiliateCMS
 * @since 4.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Register REST API route for brand products
 */
function acms_register_brand_rest_routes() {
    register_rest_route('acms/v1', '/brands/(?P<slug>[a-zA-Z0-9_-]+)/products', [
        'methods' => 'GET',
        'callback' => 'acms_rest_get_brand_products',
        'permission_callback' => '__return_true', // Public endpoint
        'args' => [
            'slug' => [
                'required' => true,
                'type' => 'string',
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'offset' => [
                'type' => 'integer',
                'default' => 0,
                'sanitize_callback' => 'absint',
            ],
            'per_page' => [
                'type' => 'integer',
                'default' => 12,
                'sanitize_callback' => 'absint',
            ],
        ],
    ]);
}
add_action('rest_api_init', 'acms_register_brand_rest_routes');

/**
 * REST handler for loading brand products
 *
 * @param WP_REST_Request $request REST request object
 * @return WP_REST_Response
 */
function acms_rest_get_brand_products($request) {
    $brand_slug = $request->get_param('slug');
    $offset = $request->get_param('offset');
    $per_page = $request->get_param('per_page');

    // Get brand term
    $brand_term = get_term_by('slug', $brand_slug, 'acms_reviews_brand');
    if (!$brand_term) {
        return new WP_Error('brand_not_found', __('Brand not found', 'affiliatecms'), ['status' => 404]);
    }

    $brand_name = $brand_term->name;

    // Query products from database
    global $wpdb;
    $products_table = $wpdb->prefix . 'acms_products';

    $products = $wpdb->get_results($wpdb->prepare(
        "SELECT asin FROM {$products_table}
         WHERE brand = %s AND status = 'scraped'
         ORDER BY score DESC, created_at DESC
         LIMIT %d OFFSET %d",
        $brand_name,
        $per_page,
        $offset
    ), ARRAY_A);

    if (empty($products)) {
        return new WP_REST_Response([
            'html' => '',
            'has_more' => false,
            'new_offset' => $offset,
        ]);
    }

    // Get ASINs and render via shortcode
    $asins = array_column($products, 'asin');
    $html = do_shortcode('[acms_list asin="' . implode(',', $asins) . '" numbered="true"]');

    // Calculate pagination
    $new_offset = $offset + count($products);
    $total_products = (int) $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$products_table} WHERE brand = %s AND status = 'scraped'",
        $brand_name
    ));

    return new WP_REST_Response([
        'html' => $html,
        'has_more' => $new_offset < $total_products,
        'new_offset' => $new_offset,
        'loaded_count' => count($products),
        'total_count' => $total_products,
    ]);
}
