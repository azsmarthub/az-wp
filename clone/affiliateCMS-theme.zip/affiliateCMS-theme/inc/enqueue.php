<?php
/**
 * Enqueue Scripts and Styles
 *
 * @package AffiliateCMS
 * @since 4.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Check if we should use minified assets (production mode)
 */
function acms_use_minified_assets() {
    $minified_css = get_template_directory() . '/assets/dist/theme.min.css';

    // File must exist
    if (!file_exists($minified_css)) {
        return false;
    }

    // Force minified if ACMS_USE_MINIFIED is true
    if (defined('ACMS_USE_MINIFIED') && ACMS_USE_MINIFIED) {
        return true;
    }

    // Otherwise, use minified only when WP_DEBUG is false
    return !defined('WP_DEBUG') || !WP_DEBUG;
}

/**
 * Enqueue styles
 */
function acms_enqueue_styles() {
    // Inter Font - Self-hosted (faster than Google Fonts CDN)
    wp_enqueue_style(
        'acms-inter-font',
        ACMS_URI . '/assets/fonts/inter/inter.css',
        [],
        ACMS_VERSION
    );

    // Bootstrap Icons - Self-hosted (shared with plugin)
    // Plugin checks for this handle before loading its own
    wp_enqueue_style(
        'bootstrap-icons',
        ACMS_URI . '/assets/fonts/bootstrap-icons/bootstrap-icons.min.css',
        [],
        '1.11.3'
    );

    // Main theme styles - use minified in production
    if (acms_use_minified_assets()) {
        wp_enqueue_style(
            'acms-main',
            ACMS_URI . '/assets/dist/theme.min.css',
            ['acms-inter-font', 'bootstrap-icons'],
            ACMS_VERSION
        );
    } else {
        // Dev mode: bust cache when ANY CSS file changes
        // CSS @import files have no ?ver= query string, so main.css version
        // must change whenever any imported module changes
        $css_all = array_merge(
            glob(ACMS_DIR . '/assets/css/pages/*.css') ?: [],
            glob(ACMS_DIR . '/assets/css/sections/*.css') ?: [],
            glob(ACMS_DIR . '/assets/css/components/*.css') ?: [],
            glob(ACMS_DIR . '/assets/css/core/*.css') ?: [],
            glob(ACMS_DIR . '/assets/css/layout/*.css') ?: [],
            glob(ACMS_DIR . '/assets/css/content/*.css') ?: [],
            [ACMS_DIR . '/assets/css/main.css']
        );
        $css_ver = $css_all ? max(array_map('filemtime', $css_all)) : ACMS_VERSION;
        wp_enqueue_style(
            'acms-main',
            ACMS_URI . '/assets/css/main.css',
            ['acms-inter-font', 'bootstrap-icons'],
            $css_ver
        );
    }
}
add_action('wp_enqueue_scripts', 'acms_enqueue_styles');

/**
 * Defer Bootstrap Icons CSS for better performance
 * Loads non-critical icon font after page render
 */
function acms_defer_bootstrap_icons($html, $handle) {
    if ($handle === 'bootstrap-icons') {
        // Use media="print" trick to defer CSS loading
        $html = str_replace("media='all'", "media='print' onload=\"this.media='all'\"", $html);
        $html = str_replace('media="all"', 'media="print" onload="this.media=\'all\'"', $html);
        // Add noscript fallback
        $noscript = '<noscript>' . str_replace(' onload="this.media=\'all\'"', '', $html) . '</noscript>';
        $html .= $noscript;
    }
    return $html;
}
add_filter('style_loader_tag', 'acms_defer_bootstrap_icons', 10, 2);

/**
 * Enqueue page-specific CSS as separate stylesheets (not @import)
 *
 * CSS @import inside main.css has no version query string, causing
 * server-side caches (LiteSpeed, CDN) to serve stale files indefinitely.
 * Enqueuing separately gives each file its own ?ver= cache-buster.
 */
function acms_enqueue_page_styles() {
    // Search Modal CSS - global component (loaded on all pages via header)
    $search_modal_css = ACMS_DIR . '/assets/css/components/search-modal.css';
    if (file_exists($search_modal_css)) {
        wp_enqueue_style(
            'acms-search-modal',
            ACMS_URI . '/assets/css/components/search-modal.css',
            ['acms-main'],
            filemtime($search_modal_css)
        );
    }

    // Hero section CSS - homepage (enqueued for cache-busting, @import serves stale)
    if (is_front_page() || is_home()) {
        $hero_css = ACMS_DIR . '/assets/css/sections/hero.css';
        if (file_exists($hero_css)) {
            wp_enqueue_style(
                'acms-hero',
                ACMS_URI . '/assets/css/sections/hero.css',
                ['acms-main'],
                filemtime($hero_css)
            );
        }
    }

    // Footer CSS - enqueued separately for cache-busting (loaded on all pages)
    $footer_css = ACMS_DIR . '/assets/css/sections/footer.css';
    if (file_exists($footer_css)) {
        wp_enqueue_style(
            'acms-footer',
            ACMS_URI . '/assets/css/sections/footer.css',
            ['acms-main'],
            filemtime($footer_css)
        );
    }

    // ACMS SEO Category Product page (/c/{slug}/)
    if (get_query_var('acms_category')) {
        $cat_css = ACMS_DIR . '/assets/css/pages/acms-cat-product.css';
        if (file_exists($cat_css)) {
            wp_enqueue_style(
                'acms-cat-product',
                ACMS_URI . '/assets/css/pages/acms-cat-product.css',
                ['acms-main'],
                filemtime($cat_css)
            );
        }
    }

    // ACMS SEO Brand page (only on /brand/{slug}/ pages)
    if (get_query_var('acms_brand')) {
        $brand_css = ACMS_DIR . '/assets/css/pages/acms-brand.css';
        if (file_exists($brand_css)) {
            wp_enqueue_style(
                'acms-brand',
                ACMS_URI . '/assets/css/pages/acms-brand.css',
                ['acms-main'],
                filemtime($brand_css)
            );
        }
    }

    // Search results page
    if (is_search()) {
        $search_css = ACMS_DIR . '/assets/css/pages/search.css';
        if (file_exists($search_css)) {
            wp_enqueue_style(
                'acms-search',
                ACMS_URI . '/assets/css/pages/search.css',
                ['acms-main'],
                filemtime($search_css)
            );
        }
    }

    // Categories Directory page (page template: Categories Directory)
    if (is_page_template('page-categories.php')) {
        $catdir_css = ACMS_DIR . '/assets/css/pages/categories-directory.css';
        if (file_exists($catdir_css)) {
            wp_enqueue_style(
                'acms-categories-directory',
                ACMS_URI . '/assets/css/pages/categories-directory.css',
                ['acms-main'],
                filemtime($catdir_css)
            );
        }
    }

    // Post/Single page - enqueued separately for cache-busting
    if (is_singular('post')) {
        $post_css = ACMS_DIR . '/assets/css/pages/post.css';
        if (file_exists($post_css)) {
            wp_enqueue_style(
                'acms-post',
                ACMS_URI . '/assets/css/pages/post.css',
                ['acms-main'],
                filemtime($post_css)
            );
        }
    }
}
add_action('wp_enqueue_scripts', 'acms_enqueue_page_styles');

/**
 * Enqueue scripts
 */
function acms_enqueue_scripts() {
    // Main theme script - use minified in production, defer to avoid render-blocking
    if (acms_use_minified_assets()) {
        wp_enqueue_script(
            'acms-theme',
            ACMS_URI . '/assets/dist/theme.min.js',
            [],
            ACMS_VERSION,
            ['in_footer' => true, 'strategy' => 'defer']
        );
    } else {
        wp_enqueue_script(
            'acms-theme',
            ACMS_URI . '/assets/js/theme.js',
            [],
            filemtime(ACMS_DIR . '/assets/js/theme.js'),
            ['in_footer' => true, 'strategy' => 'defer']
        );

        // Priority Navigation (responsive menu overflow) - only in dev mode
        wp_enqueue_script(
            'acms-priority-nav',
            ACMS_URI . '/assets/js/modules/priority-nav.js',
            [],
            ACMS_VERSION . '.1',
            ['in_footer' => true, 'strategy' => 'defer']
        );

        // Category Live Search - debounced autocomplete
        wp_enqueue_script(
            'acms-category-search',
            ACMS_URI . '/assets/js/category-search.js',
            [],
            filemtime(ACMS_DIR . '/assets/js/category-search.js'),
            ['in_footer' => true, 'strategy' => 'defer']
        );
    }

    // Localize script for REST API and dynamic data
    $gs = get_option('acms_general_settings', []);
    $localize_data = [
        'restUrl'  => rest_url('azs/v1/'), // Theme REST namespace (azs/v1/)
        'restBase' => rest_url(),           // WordPress REST base (/wp-json/)
        'nonce'    => wp_create_nonce('wp_rest'),
        'homeUrl'  => home_url('/'),
        'themeUrl' => ACMS_URI,
        'goSlug'   => !empty($gs['redirect_enabled']) ? ($gs['redirect_slug'] ?? 'go') : '',
    ];

    // Add post ID for single posts and custom post types (for view tracking)
    if (is_singular(['post', 'acms_reviews', 'acms_deals', 'acms_guides'])) {
        $localize_data['postId'] = get_the_ID();
        $localize_data['trackViews'] = true;
    }

    wp_localize_script('acms-theme', 'acmsData', $localize_data);

    // Comment reply script
    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}
add_action('wp_enqueue_scripts', 'acms_enqueue_scripts');

/**
 * Enqueue brand archive script for brand taxonomy pages
 */
function acms_enqueue_brand_archive_script() {
    // Only load on brand taxonomy pages
    if (!is_tax('acms_reviews_brand')) {
        return;
    }

    wp_enqueue_script(
        'acms-brand-archive',
        ACMS_URI . '/assets/js/brand-archive.js',
        [],
        ACMS_VERSION,
        ['in_footer' => true, 'strategy' => 'defer']
    );

    // Localize script for REST API
    wp_localize_script('acms-brand-archive', 'acmsBrandConfig', [
        'restUrl' => rest_url('acms/v1/'),
        'nonce'   => wp_create_nonce('wp_rest'),
    ]);
}
add_action('wp_enqueue_scripts', 'acms_enqueue_brand_archive_script');

/**
 * Enqueue deals page script for deals page template
 */
function acms_enqueue_deals_page_script() {
    // Only load on deals page template
    if (!is_page_template('template-deals.php')) {
        return;
    }

    // Deals page CSS (enqueued separately with ?ver= for cache-busting)
    wp_enqueue_style(
        'acms-deals-page',
        ACMS_URI . '/assets/css/pages/deals.css',
        ['acms-main'],
        filemtime(ACMS_DIR . '/assets/css/pages/deals.css')
    );

    // Deals page component (must load BEFORE Alpine.js)
    wp_enqueue_script(
        'acms-deals-page',
        ACMS_URI . '/assets/js/deals-page.js',
        [],
        filemtime(ACMS_DIR . '/assets/js/deals-page.js'),
        ['in_footer' => true, 'strategy' => 'defer']
    );

    // Alpine.js - loads AFTER deals-page.js (depends on it)
    wp_enqueue_script(
        'alpinejs',
        'https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js',
        ['acms-deals-page'],
        '3.14.9',
        ['in_footer' => true, 'strategy' => 'defer']
    );

    // Localize script for REST API
    wp_localize_script('acms-deals-page', 'acmsDealsConfig', [
        'restUrl' => rest_url('acms/v1/'),
        'nonce'   => wp_create_nonce('wp_rest'),
    ]);
}
add_action('wp_enqueue_scripts', 'acms_enqueue_deals_page_script');

/**
 * Add preload hints for critical font files
 */
function acms_preload_fonts() {
    // Preload Inter Regular (most used weight)
    echo '<link rel="preload" href="' . esc_url(ACMS_URI . '/assets/fonts/inter/Inter-Regular.woff2') . '" as="font" type="font/woff2" crossorigin>' . "\n";
    // Preload Bootstrap Icons
    echo '<link rel="preload" href="' . esc_url(ACMS_URI . '/assets/fonts/bootstrap-icons/bootstrap-icons.woff2') . '" as="font" type="font/woff2" crossorigin>' . "\n";
}
add_action('wp_head', 'acms_preload_fonts', 1);

/**
 * Add theme color meta tag
 */
function acms_theme_color_meta() {
    echo '<meta name="theme-color" content="#14b8a6">' . "\n";
}
add_action('wp_head', 'acms_theme_color_meta', 1);

/**
 * Enqueue admin styles for widgets page
 */
function acms_admin_widgets_styles($hook) {
    if ('widgets.php' !== $hook) {
        return;
    }

    // Inline CSS to highlight AffiliateCMS widgets
    $css = '
        /* AffiliateCMS Widgets Highlight */
        .widget[id*="acms_"] .widget-title h3,
        #available-widgets .widget[id*="acms_"] .widget-title {
            background: linear-gradient(135deg, #14b8a6 0%, #0d9488 100%) !important;
            color: #fff !important;
        }
        #available-widgets .widget[id*="acms_"] .widget-title::before {
            content: "";
            display: inline-block;
            width: 8px;
            height: 8px;
            background: #fff;
            border-radius: 50%;
            margin-right: 8px;
            animation: acms-pulse 2s infinite;
        }
        @keyframes acms-pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }
        #available-widgets .widget[id*="acms_"] {
            border-left: 3px solid #14b8a6;
        }
        .widget[id*="acms_"] .widget-inside {
            border-top: 2px solid #14b8a6;
        }
    ';

    wp_add_inline_style('widgets', $css);
}
add_action('admin_enqueue_scripts', 'acms_admin_widgets_styles');

/**
 * Fallback favicon if not set in Customizer
 */
function acms_fallback_favicon() {
    // Use config favicon if set
    $config_favicon = defined('ACMS_FAVICON_URL') ? ACMS_FAVICON_URL : '';

    if ($config_favicon) {
        $type = str_ends_with($config_favicon, '.svg') ? 'image/svg+xml' : 'image/png';
        ?>
        <link rel="icon" href="<?php echo esc_url($config_favicon); ?>" type="<?php echo esc_attr($type); ?>">
        <link rel="apple-touch-icon" href="<?php echo esc_url($config_favicon); ?>">
        <?php
        return;
    }

    // Check if site icon is set in Customizer
    if (has_site_icon()) {
        return;
    }

    // Theme fallback
    $favicon_url = ACMS_URI . '/assets/images/favicon.svg';
    ?>
    <link rel="icon" href="<?php echo esc_url($favicon_url); ?>" type="image/svg+xml">
    <link rel="apple-touch-icon" href="<?php echo esc_url($favicon_url); ?>">
    <?php
}
add_action('wp_head', 'acms_fallback_favicon', 5);

/**
 * Clear related posts cache when post is updated
 * Also clears cache for posts that might include this post as related
 */
function acms_clear_related_cache($post_id) {
    // Clear this post's related cache
    delete_transient('acms_related_' . $post_id);

    // Clear related cache for posts in same categories (they might include this post)
    $post_type = get_post_type($post_id);
    $cat_taxonomies = [
        'post'         => 'category',
        'acms_reviews' => 'acms_reviews_category',
        'acms_deals'   => 'acms_deals_category',
        'acms_guides'  => 'acms_guides_category',
    ];

    $cat_taxonomy = $cat_taxonomies[$post_type] ?? 'category';
    $categories = get_the_terms($post_id, $cat_taxonomy);

    if ($categories && !is_wp_error($categories)) {
        $cat_ids = wp_list_pluck($categories, 'term_id');

        // Get recent posts in same category and clear their related cache
        $related_query = new WP_Query([
            'post_type'      => $post_type,
            'posts_per_page' => 20,
            'post__not_in'   => [$post_id],
            'fields'         => 'ids',
            'tax_query'      => [
                [
                    'taxonomy' => $cat_taxonomy,
                    'field'    => 'term_id',
                    'terms'    => $cat_ids,
                ],
            ],
            'no_found_rows'  => true,
        ]);

        foreach ($related_query->posts as $related_id) {
            delete_transient('acms_related_' . $related_id);
        }
    }
}
add_action('save_post', 'acms_clear_related_cache');
add_action('delete_post', 'acms_clear_related_cache');
