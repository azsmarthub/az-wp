<?php
/**
 * Front Page Template (Homepage)
 *
 * @package AffiliateCMS
 * @since 4.0.0
 */

get_header();
?>

<main id="content" class="site-main">

    <?php
    // Hero Section (AI search, stats)
    get_template_part('template-parts/sections/hero');

    // Categories Section (grid cards)
    get_template_part('template-parts/sections/categories');

    // Latest Posts Section (with sidebar)
    get_template_part('template-parts/sections/latest-posts');

    // About Section — removed (not needed on homepage)
    ?>

</main>

<?php
get_footer();
