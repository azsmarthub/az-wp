<?php
/**
 * Template Name: Deals Page
 * Template Post Type: page
 *
 * Displays all products with active discounts
 * With category filtering (L0 categories only)
 *
 * @package AffiliateCMS
 * @since 4.0.0
 */

get_header();

global $wpdb;
$categories_table = $wpdb->prefix . 'acms_categories';
$products_table = $wpdb->prefix . 'acms_products';
$category_products_table = $wpdb->prefix . 'acms_category_products';

$deals_where = acms_deals_where_clause();
$per_page = 24;
$selected_category_id = isset($_GET['category']) ? absint($_GET['category']) : 0;

// Check if categories table exists
$table_exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $categories_table)) === $categories_table;

// Get L0 categories with DEAL counts (not total product_count)
$l0_categories = [];
if ($table_exists) {
    $l0_categories = $wpdb->get_results(
        "SELECT c_root.id, c_root.name, c_root.slug, c_root.icon,
                COUNT(DISTINCT p.id) as deal_count
         FROM {$categories_table} c_root
         INNER JOIN {$categories_table} c_desc
             ON (c_desc.id = c_root.id OR c_desc.path LIKE CONCAT('/', c_root.id, '/%'))
         INNER JOIN {$category_products_table} cp ON cp.category_id = c_desc.id
         INNER JOIN {$products_table} p ON p.id = cp.product_id
         WHERE c_root.depth = 0
         AND c_root.status = 'publish'
         AND c_root.brand_id IS NULL
         AND p.{$deals_where}
         GROUP BY c_root.id
         HAVING deal_count > 0
         ORDER BY deal_count DESC, c_root.name ASC",
        ARRAY_A
    ) ?: [];
}

// Query deal products
if ($selected_category_id > 0 && $table_exists) {
    $cat_ids = acms_get_category_descendant_ids($selected_category_id);

    if (empty($cat_ids)) {
        $total_products = 0;
        $products = [];
    } else {
        $placeholders = implode(',', array_fill(0, count($cat_ids), '%d'));

        $total_products = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(DISTINCT p.id)
             FROM {$products_table} p
             INNER JOIN {$category_products_table} cp ON p.id = cp.product_id
             WHERE cp.category_id IN ({$placeholders})
             AND p.{$deals_where}",
            ...$cat_ids
        ));

        $products = $wpdb->get_results($wpdb->prepare(
            "SELECT DISTINCT p.asin, p.price, p.original_price,
                    ROUND(((p.original_price - p.price) / p.original_price) * 100, 0) as discount_percent
             FROM {$products_table} p
             INNER JOIN {$category_products_table} cp ON p.id = cp.product_id
             WHERE cp.category_id IN ({$placeholders})
             AND p.{$deals_where}
             ORDER BY discount_percent DESC, p.created_at DESC
             LIMIT %d",
            ...array_merge($cat_ids, [$per_page])
        ), ARRAY_A);
    }
} else {
    $total_products = (int) $wpdb->get_var(
        "SELECT COUNT(*) FROM {$products_table} WHERE {$deals_where}"
    );

    $products = $wpdb->get_results($wpdb->prepare(
        "SELECT asin, price, original_price,
                ROUND(((original_price - price) / original_price) * 100, 0) as discount_percent
         FROM {$products_table}
         WHERE {$deals_where}
         ORDER BY discount_percent DESC, created_at DESC
         LIMIT %d",
        $per_page
    ), ARRAY_A);
}

$asins = array_column($products, 'asin');
$has_more = $total_products > $per_page;
$categories_json = wp_json_encode($l0_categories);
?>

<script>
    window.acmsDealsData = {
        categories: <?php echo $categories_json; ?>,
        initialCategoryId: <?php echo absint($selected_category_id); ?>
    };
</script>

<main id="content" class="site-main">

    <!-- Deals Header - Centered Style -->
    <section class="cat-header--centered">
        <div class="container">
            <!-- Icon -->
            <div class="cat-header__icon">
                <i class="bi bi-tag-fill"></i>
            </div>

            <!-- Title -->
            <h1 class="cat-header__title">
                <?php esc_html_e('Hot Deals', 'affiliatecms'); ?>
            </h1>

            <!-- Breadcrumb -->
            <?php acms_breadcrumb(); ?>

            <!-- Description -->
            <p class="cat-header__description">
                <?php esc_html_e('Discover the best deals and discounts on top-rated products. Updated daily with the latest price drops!', 'affiliatecms'); ?>
            </p>

            <!-- Meta -->
            <div class="cat-header__meta">
                <div class="cat-header__meta-item">
                    <i class="bi bi-percent"></i>
                    <span x-data x-text="`${$store.dealsPage?.totalProducts || <?php echo absint($total_products); ?>} Deal${($store.dealsPage?.totalProducts || <?php echo absint($total_products); ?>) === 1 ? '' : 's'}`"></span>
                </div>
                <div class="cat-header__meta-item">
                    <i class="bi bi-clock"></i>
                    <?php esc_html_e('Updated hourly', 'affiliatecms'); ?>
                </div>
            </div>
        </div>
    </section>

    <!-- Content Layout: Sidebar (LEFT) + Main -->
    <section class="posts-section">
        <div class="container">
            <div class="content-layout content-layout--sidebar-left" x-data="dealsPage()" x-init="init()">

                <!-- LEFT SIDEBAR: Category Filter -->
                <aside class="content-layout__sidebar deals-filter-col">
                    <div class="deals-filter" :class="{ 'is-open': filterOpen }">
                        <!-- Mobile toggle -->
                        <button type="button" class="deals-filter__toggle" @click="filterOpen = !filterOpen">
                            <i class="bi bi-funnel-fill"></i>
                            <span><?php esc_html_e('Filter by Category', 'affiliatecms'); ?></span>
                            <span class="deals-filter__active-name" x-show="selectedCategoryId > 0" x-text="categories.find(c => c.id === selectedCategoryId)?.name || ''"></span>
                            <i class="bi bi-chevron-down deals-filter__chevron"></i>
                        </button>

                        <!-- Desktop header -->
                        <div class="deals-filter__header">
                            <h3 class="sidebar-widget__title">
                                <i class="bi bi-funnel-fill"></i>
                                <?php esc_html_e('Filter by Category', 'affiliatecms'); ?>
                            </h3>
                        </div>

                        <div class="deals-filter__body">
                            <div class="deals-category-menu">
                                <!-- All Categories (Default) -->
                                <button
                                    type="button"
                                    class="deals-category-item"
                                    :class="{ 'is-active': selectedCategoryId === 0 }"
                                    @click="filterByCategory(0); filterOpen = false"
                                >
                                    <i class="bi bi-grid-fill"></i>
                                    <span class="deals-category-name"><?php esc_html_e('All Categories', 'affiliatecms'); ?></span>
                                    <span class="deals-category-count" x-text="totalProducts"></span>
                                </button>

                                <!-- Categories -->
                                <template x-for="cat in categories" :key="cat.id">
                                    <button
                                        type="button"
                                        class="deals-category-item"
                                        :class="{ 'is-active': selectedCategoryId === cat.id }"
                                        @click="filterByCategory(cat.id); filterOpen = false"
                                    >
                                        <i class="bi bi-folder-fill" x-show="cat.icon === '' || !cat.icon"></i>
                                        <i :class="cat.icon" x-show="cat.icon && cat.icon !== ''"></i>
                                        <span class="deals-category-name" x-text="cat.name"></span>
                                        <span class="deals-category-count" x-text="cat.deal_count || 0"></span>
                                    </button>
                                </template>
                            </div>
                        </div>
                    </div>
                </aside>

                <!-- MAIN CONTENT -->
                <div class="content-layout__main">

                    <!-- Loading Overlay -->
                    <div class="deals-loading-overlay" x-show="isLoading" x-cloak>
                        <div class="deals-loading-spinner">
                            <i class="bi bi-arrow-repeat"></i>
                            <span><?php esc_html_e('Loading deals...', 'affiliatecms'); ?></span>
                        </div>
                    </div>

                    <?php if (!empty($asins)) : ?>
                        <!-- Products List -->
                        <div class="deals-products-list" id="dealsProductsList"
                             data-offset="<?php echo esc_attr($per_page); ?>"
                             data-per-page="<?php echo esc_attr($per_page); ?>"
                             data-total="<?php echo esc_attr($total_products); ?>"
                             data-category="<?php echo esc_attr($selected_category_id); ?>">
                            <?php
                            // Render products using acms_list shortcode
                            echo do_shortcode('[acms_list asin="' . implode(',', $asins) . '" numbered="true"]');
                            ?>
                        </div>

                        <!-- Load More Button -->
                        <?php if ($has_more) : ?>
                        <div class="load-more">
                            <button type="button" class="load-more__btn" id="dealsLoadMore" aria-label="<?php esc_attr_e('Load more deals', 'affiliatecms'); ?>">
                                <span class="load-more__text"><?php esc_html_e('Load More Deals', 'affiliatecms'); ?></span>
                                <span class="load-more__loading"><?php esc_html_e('Loading...', 'affiliatecms'); ?></span>
                                <span class="load-more__complete"><?php esc_html_e('All Deals Loaded', 'affiliatecms'); ?></span>
                                <i class="bi bi-arrow-down-circle load-more__icon"></i>
                                <i class="bi bi-arrow-repeat load-more__spinner"></i>
                                <i class="bi bi-check-circle load-more__check"></i>
                            </button>
                        </div>
                        <?php endif; ?>

                    <?php else : ?>
                        <!-- No Deals -->
                        <div class="no-results">
                            <div class="no-results__icon">
                                <i class="bi bi-inbox"></i>
                            </div>
                            <h2 class="no-results__title">
                                <?php esc_html_e('No active deals found', 'affiliatecms'); ?>
                            </h2>
                            <p class="no-results__description">
                                <?php esc_html_e('Check back soon for amazing discounts on top products!', 'affiliatecms'); ?>
                            </p>
                        </div>
                    <?php endif; ?>

                </div>

            </div>
        </div>
    </section>


</main>

<?php
get_footer();
