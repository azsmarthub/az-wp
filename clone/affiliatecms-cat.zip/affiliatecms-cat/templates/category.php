<?php
/**
 * SEO Category Product Template
 *
 * Master-Detail UI with product list sidebar and detail panel
 * Layout: Sidebar (sticky) | Main (scrollable with all content)
 *
 * @package AffiliateCMS\Categories
 */

defined('ABSPATH') || exit;

/**
 * Helper: Resize Amazon images for performance
 * Replaces high-res image URLs (1500px) with optimized sizes (200-400px)
 *
 * @param string $url Amazon image URL
 * @param int $size Desired width (200, 300, 400)
 * @return string Optimized image URL
 */
if (!function_exists('acms_resize_amazon_image')) {
    function acms_resize_amazon_image($url, $size = 300) {
        if (empty($url)) return $url;
        if (strpos($url, 'media-amazon.com') !== false || strpos($url, 'ssl-images-amazon.com') !== false) {
            // Replace ._AC_SL1500_. with ._AC_SLxxx_. where xxx is the size
            return preg_replace('/\._[A-Z]{2}_SL\d+_/', '._AC_SL' . $size . '_', $url);
        }
        return $url;
    }
}

// Get category from global (set in Bootstrap::handleCategoryTemplate)
$category = $GLOBALS['acms_current_category'] ?? null;

if (!$category) {
    wp_safe_redirect(home_url('/'));
    exit;
}

// Detect brand-category mode: categories with brand_id set are brand-filtered
$is_brand_category = !empty($category['brand_id']);
$brand_name_filter = '';
if ($is_brand_category && class_exists(\AffiliateCMS\Pro\Repositories\BrandRepository::class)) {
    $brand_data = \AffiliateCMS\Pro\Repositories\BrandRepository::instance()->find((int) $category['brand_id']);
    $brand_name_filter = $brand_data['name'] ?? '';
}

$query_category_id = (int) $category['id'];

// Get affiliate link settings (same resolution as Shortcodes.php)
$acms_general = get_option('acms_general_settings', []);
$affiliate_tag = !empty($acms_general['affiliate_tag']) ? $acms_general['affiliate_tag'] : '';
if (!$affiliate_tag) {
    $affiliate_tag = get_option('acms_paapi_partner_tag', '');
}
if (!$affiliate_tag) {
    $affiliate_tag = get_option('acms_affiliate_tag', '');
}
$custom_url_params = !empty($acms_general['custom_url_params']) ? ltrim($acms_general['custom_url_params'], '&') : 'linkCode=ogi&th=1&psc=1';
$redirect_enabled = !empty($acms_general['redirect_enabled']);
$redirect_slug = $acms_general['redirect_slug'] ?? 'go';
$cf_param = $acms_general['cf_param'] ?? '';

// Display settings from Visible Elements (Settings > Display)
$show_price = $acms_general['show_price'] ?? true;
$show_rating = $acms_general['show_rating'] ?? true;
$show_prime = $acms_general['show_prime_badge'] ?? true;
$show_stock = $acms_general['show_stock_status'] ?? true;
$show_update = $acms_general['show_update'] ?? true;

// Get products for this category AND all descendant categories (Materialized Path)
global $wpdb;
$products_table = $wpdb->prefix . 'acms_products';
$cat_products_table = $wpdb->prefix . 'acms_category_products';
$categories_table = $wpdb->prefix . 'acms_categories';
$queue_table = $wpdb->prefix . 'acms_cat_queue';

// Build descendant path pattern
$current_path = rtrim($category['path'], '/');
$descendant_pattern = $current_path . '/' . $query_category_id . '/%';

// Step 1: Get descendant category IDs via Materialized Path (fast index lookup)
$descendant_ids = $wpdb->get_col($wpdb->prepare(
    "SELECT id FROM {$categories_table} WHERE path LIKE %s",
    $descendant_pattern
));
$all_cat_ids = array_merge([(int) $query_category_id], array_map('intval', $descendant_ids));
$cat_placeholders = implode(',', array_fill(0, count($all_cat_ids), '%d'));

// Step 2: Get product IDs from junction table (lightweight, uses covering index)
$product_rows = $wpdb->get_results($wpdb->prepare(
    "SELECT product_id, MIN(position) as position, MIN(category_id) as source_category_id
     FROM {$cat_products_table}
     WHERE category_id IN ({$cat_placeholders})
     GROUP BY product_id
     ORDER BY product_id DESC
     LIMIT 50",
    ...$all_cat_ids
));

// Step 3: Fetch only needed columns from products (skip LONGTEXT blobs)
$products = [];
if (!empty($product_rows)) {
    $pid_map = [];
    foreach ($product_rows as $row) {
        $pid_map[(int) $row->product_id] = $row;
    }
    $product_ids = array_keys($pid_map);
    $pid_placeholders = implode(',', array_fill(0, count($product_ids), '%d'));

    $products = $wpdb->get_results($wpdb->prepare(
        "SELECT id, asin, title, brand, price, original_price, currency, rating, reviews_count,
                score, in_stock, is_prime, image_url, best_sellers_rank, updated_at,
                custom_title, ai_short_review, description, features,
                ai_features, custom_features, custom_pros, custom_cons
         FROM {$products_table}
         WHERE id IN ({$pid_placeholders})
         ORDER BY id DESC",
        ...$product_ids
    ));

    // Attach position & source_category_id from junction query
    foreach ($products as $p) {
        $meta = $pid_map[(int) $p->id] ?? null;
        $p->position = $meta ? $meta->position : 0;
        $p->source_category_id = $meta ? $meta->source_category_id : 0;
    }
}

// Count total products (reuse $all_cat_ids from Step 1 — no subquery needed)
$total_products = (int) $wpdb->get_var($wpdb->prepare(
    "SELECT COUNT(DISTINCT product_id) FROM {$cat_products_table}
     WHERE category_id IN ({$cat_placeholders})",
    ...$all_cat_ids
));
$per_page = 50;

// User info for review form
$current_user = wp_get_current_user();
$is_logged_in = is_user_logged_in();
$user_display_name = $is_logged_in ? $current_user->display_name : '';
$user_email = $is_logged_in ? $current_user->user_email : '';
$user_avatar = $is_logged_in ? get_avatar_url($current_user->ID, ['size' => 32]) : '';

// If no products found via category_products, try queue's linked_asins from all descendants
if (empty($products)) {
    // Reuse $all_cat_ids from Step 1 (already has current + descendant IDs)
    $id_placeholders = implode(',', array_fill(0, count($all_cat_ids), '%d'));

    $linked_asins = [];

    // Get all linked_asins from queue for all descendant categories
    $queue_results = $wpdb->get_col(
        $wpdb->prepare(
            "SELECT linked_asins FROM {$queue_table}
            WHERE assigned_category_id IN ({$id_placeholders})
            AND linked_asins IS NOT NULL",
            ...$all_cat_ids
        )
    );

    foreach ($queue_results as $json) {
        $asins = json_decode($json, true);
        if (!empty($asins)) {
            $linked_asins = array_merge($linked_asins, $asins);
        }
    }

    // Remove duplicates and get products
    $linked_asins = array_unique($linked_asins);
    if (!empty($linked_asins)) {
        $asin_placeholders = implode(',', array_fill(0, count($linked_asins), '%s'));
        $products = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$products_table} WHERE asin IN ({$asin_placeholders}) LIMIT 50",
                ...$linked_asins
            )
        );
    }
}

// Get sibling categories (same parent) for Related Categories section
$sibling_categories = [];
if (!empty($category['parent_id'])) {
    $catRepo = new \AffiliateCMS\Categories\Repositories\CategoryRepository();
    $siblings_raw = $wpdb->get_results($wpdb->prepare(
        "SELECT name, slug, product_count FROM {$wpdb->prefix}acms_categories
         WHERE parent_id = %d AND id != %d AND status = 'publish'
         ORDER BY product_count DESC LIMIT 12",
        (int) $category['parent_id'],
        (int) $category['id']
    ), ARRAY_A);
    $sibling_categories = $siblings_raw ?: [];
}

// Extract filter data from products
$filter_brands = [];
$filter_price_min = PHP_INT_MAX;
$filter_price_max = 0;
$filter_ratings = [];

foreach ($products as $p) {
    // Brands
    if (!empty($p->brand)) {
        $filter_brands[$p->brand] = ($filter_brands[$p->brand] ?? 0) + 1;
    }
    // Price range
    if (!empty($p->price) && $p->price > 0) {
        $filter_price_min = min($filter_price_min, (float) $p->price);
        $filter_price_max = max($filter_price_max, (float) $p->price);
    }
    // Ratings (group by integer)
    if (!empty($p->rating)) {
        $rating_int = (int) floor((float) $p->rating);
        $filter_ratings[$rating_int] = ($filter_ratings[$rating_int] ?? 0) + 1;
    }
}

// Sort brands alphabetically, ratings descending
ksort($filter_brands);
krsort($filter_ratings);

// Build brand name → slug lookup for brand page links
$brand_slugs = [];
$brand_names = array_keys($filter_brands);
if (!empty($brand_names)) {
    $brands_table = $wpdb->prefix . 'acms_brands';
    $name_placeholders = implode(',', array_fill(0, count($brand_names), '%s'));
    $brand_rows = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT name, slug FROM {$brands_table} WHERE name IN ({$name_placeholders}) AND status = 'publish'",
            ...$brand_names
        )
    );
    foreach ($brand_rows as $br) {
        $brand_slugs[$br->name] = $br->slug;
    }
}

// Brand-category navigation: find brand sub-categories for the filter bar
// On brand-category pages: siblings (under parent); otherwise: children (under current)
$brand_nav_parent_id = $is_brand_category ? (int) $category['parent_id'] : (int) $category['id'];
$brand_category_nav = [];
$bc_rows = $wpdb->get_results($wpdb->prepare(
    "SELECT c.slug, b.name as brand_name, c.product_count
     FROM {$categories_table} c
     JOIN {$wpdb->prefix}acms_brands b ON c.brand_id = b.id
     WHERE c.parent_id = %d AND c.brand_id IS NOT NULL AND c.status = 'publish'
     ORDER BY c.product_count DESC, b.name ASC",
    $brand_nav_parent_id
));
foreach ($bc_rows as $bcr) {
    $brand_category_nav[] = [
        'name' => $bcr->brand_name,
        'slug' => $bcr->slug,
        'count' => (int) $bcr->product_count,
    ];
}
$has_brand_nav = !empty($brand_category_nav);

// Reset price if no valid prices
if ($filter_price_min === PHP_INT_MAX) $filter_price_min = 0;
if ($filter_price_max === 0) $filter_price_max = 1000;

// Build category tree + breadcrumbs (single query for both)
$current_cat_id = (int) $category['id'];
$ancestor_ids = [];
$path_ids = [];
if (!empty($category['path']) && $category['path'] !== '/') {
    $path_ids = array_filter(explode('/', trim($category['path'], '/')));
    $ancestor_ids = array_map('intval', $path_ids);
}

// Parent IDs needed for tree: root(0) + ancestors + current
$parent_ids_needed = array_unique(array_merge([0], $ancestor_ids, [$current_cat_id]));
// All IDs needed: breadcrumb IDs (path_ids) + tree parent IDs
$all_nav_ids = array_unique(array_merge(array_map('intval', $path_ids), $parent_ids_needed));
$nav_placeholders = implode(',', array_fill(0, count($all_nav_ids), '%d'));

// Single query: breadcrumb categories (by id) + tree children (by parent_id)
// Exclude brand-categories (brand_id IS NOT NULL) from tree — brand filter handles those
$all_nav_categories = $wpdb->get_results(
    $wpdb->prepare(
        "SELECT id, name, slug, parent_id, product_count, child_count, depth
         FROM {$categories_table}
         WHERE id IN ({$nav_placeholders})
            OR (parent_id IN ({$nav_placeholders}) AND status = 'publish' AND brand_id IS NULL)
         ORDER BY depth ASC, name ASC",
        ...array_merge($all_nav_ids, $all_nav_ids)
    ),
    ARRAY_A
);

// Split results into breadcrumbs and tree
$breadcrumbs = [];
$tree_by_parent = [];
$path_ids_int = array_map('intval', $path_ids);
foreach ($all_nav_categories as $cat) {
    $cid = (int) $cat['id'];
    // Breadcrumb: categories whose ID is in the path
    if (in_array($cid, $path_ids_int, true)) {
        $breadcrumbs[] = $cat;
    }
    // Tree: group all results by parent_id (for children lookup)
    $pid = (int) $cat['parent_id'];
    $tree_by_parent[$pid][] = $cat;
}

// Set of IDs to expand (ancestors + current)
$expanded_ids = array_merge($ancestor_ids, [$current_cat_id]);

// Build nested tree for filter bar Alpine.js component
if (!function_exists('acms_build_nested_tree')) {
    function acms_build_nested_tree(array $tree_by_parent, int $parent_id = 0): array {
    $nodes = [];
    if (!isset($tree_by_parent[$parent_id])) {
        return $nodes;
    }
    foreach ($tree_by_parent[$parent_id] as $node) {
        $nid = (int) $node['id'];
        $built_children = acms_build_nested_tree($tree_by_parent, $nid);
        $nodes[] = [
            'id' => (string) $nid,
            'name' => $node['name'],
            'slug' => $node['slug'],
            'product_count' => (int) $node['product_count'],
            'child_count' => max((int) ($node['child_count'] ?? 0), count($built_children)),
            'children' => $built_children,
        ];
    }
    return $nodes;
    }
}
$cat_tree_nested = !empty($tree_by_parent) ? acms_build_nested_tree($tree_by_parent) : [];

// Prepare SSR data for first 10 products (SEO-visible content)
$ssr_limit = 10;
$ssr_products = array_slice($products, 0, $ssr_limit);

// Batch-load affiliate links for all SSR products in one query
$ssr_affiliate_links = [];
if (class_exists(\AffiliateCMS\Pro\Repositories\ProductLinkRepository::class) && !empty($ssr_products)) {
    $ssr_product_ids = array_map(fn($p) => (int) $p->id, $ssr_products);
    $links_by_product = \AffiliateCMS\Pro\Repositories\ProductLinkRepository::instance()->getByProductIds($ssr_product_ids);
    foreach ($links_by_product as $pid => $links) {
        $link_arrays = array_map(fn($link) => $link->toArray(), $links);
        // Wrap affiliate_url through redirect (same as REST API endpoint)
        if ($redirect_enabled) {
            foreach ($link_arrays as &$al) {
                if (!empty($al['affiliate_url'])) {
                    $al['affiliate_url'] = home_url('/' . $redirect_slug . '/?url=' . urlencode($al['affiliate_url']));
                    if (!empty($cf_param)) {
                        $al['affiliate_url'] .= '&' . $cf_param;
                    }
                }
            }
            unset($al);
        }
        $ssr_affiliate_links[$pid] = $link_arrays;
    }
}

$ssr_details = [];
foreach ($ssr_products as $p) {
    $ssr_title = !empty($p->custom_title) ? $p->custom_title : $p->title;
    $ssr_features = [];
    if (!empty($p->ai_features)) $ssr_features = json_decode($p->ai_features, true) ?: [];
    elseif (!empty($p->custom_features)) $ssr_features = json_decode($p->custom_features, true) ?: [];
    elseif (!empty($p->features)) $ssr_features = json_decode($p->features, true) ?: [];
    $ssr_pros = !empty($p->custom_pros) ? (json_decode($p->custom_pros, true) ?: []) : [];
    $ssr_cons = !empty($p->custom_cons) ? (json_decode($p->custom_cons, true) ?: []) : [];

    $ssr_details[] = [
        'p' => $p,
        'title' => $ssr_title,
        'features' => array_slice($ssr_features, 0, 5),
        'pros' => array_slice($ssr_pros, 0, 3),
        'cons' => array_slice($ssr_cons, 0, 3),
        'short_review' => $p->ai_short_review ?? '',
        'affiliate_links' => $ssr_affiliate_links[(int) $p->id] ?? [],
    ];
}

// Extract FAQ items for structured data (FAQPage schema)
// Primary: parse <h3>Question</h3><p>Answer</p> pairs from content_main
// Fallback: content_faq JSON column (if manually populated)
$faq_items = [];
if (!empty($category['content_faq'])) {
    $faq_items = is_array($category['content_faq'])
        ? $category['content_faq']
        : (json_decode($category['content_faq'], true) ?: []);
}
if (empty($faq_items) && !empty($category['content_main'])) {
    // Parse FAQ from content_main: find <h3>question?</h3> followed by <p>answer</p>
    if (preg_match_all('/<h3[^>]*>\s*(.+?)\s*<\/h3>\s*<p[^>]*>([\s\S]*?)<\/p>/i', $category['content_main'], $matches, PREG_SET_ORDER)) {
        foreach ($matches as $m) {
            $q = wp_strip_all_tags($m[1]);
            $a = wp_strip_all_tags($m[2]);
            // Only include entries that look like FAQ (question ends with ?)
            if (str_contains($q, '?') && strlen($a) > 20) {
                $faq_items[] = ['question' => $q, 'answer' => $a];
            }
        }
    }
}

// Placeholder replacement for %year%, %sitename% etc.
$replacePlaceholders = class_exists(\AffiliateCMS\SEO\Placeholders::class)
    ? [\AffiliateCMS\SEO\Placeholders::class, 'replace']
    : fn(string $s) => str_replace('%year%', date('Y'), $s);

// Build display title and SEO title
$site_name_for_title = get_bloginfo('name');
$product_count_display = $total_products > 0 ? $total_products : ((int) ($category['product_count'] ?? 0) ?: count($products));

if ($is_brand_category && !empty($brand_name_filter)) {
    // Brand-category: fixed format — "{count} Best {Brand} {ParentKeyword} of {year}"
    // Parent name = the keyword (e.g., "Gaming PCs"), brand is the filter (e.g., "Sony")
    $parent_keyword = '';
    if (!empty($breadcrumbs)) {
        $last_crumb = end($breadcrumbs);
        $parent_keyword = $last_crumb['name'] ?? '';
    }
    if (!$parent_keyword) {
        // Fallback: strip brand name from category name
        $parent_keyword = trim(str_ireplace($brand_name_filter, '', $category['name']));
    }

    // Brand-category: H1 = "Best {Brand} {Keyword}", SEO = "{count} Best {Brand} {Keyword} of {year} - Site"
    $display_title = 'Best ' . $brand_name_filter . ' ' . $parent_keyword;
    $page_title = $product_count_display . ' Best ' . $brand_name_filter . ' ' . $parent_keyword . ' of ' . date('Y');
} else {
    // Queue keyword = has products + no regular (non-brand) children
    // Parent path = has regular children (e.g., "Headphones" contains "Gaming Headphones")
    $has_products = ((int) ($category['product_count'] ?? 0)) > 0;
    $has_regular_children = (int) $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$categories_table} WHERE parent_id = %d AND brand_id IS NULL AND status = 'publish'",
        (int) $category['id']
    ));
    $is_queue_keyword = $has_products && $has_regular_children === 0;

    if ($is_queue_keyword) {
        // Queue keyword category: H1 = "Best {Name}", SEO = "{count} Best {Name} of {year} - Site"
        $cat_name = $category['name'];
        $display_title = preg_match('/^best\s/i', $cat_name) ? $cat_name : 'Best ' . $cat_name;
        $page_title = $product_count_display . ' Best ' . $cat_name . ' of ' . date('Y');
    } else {
        // Parent category: H1 = "Category Name", SEO = "SiteName: Category of {year}"
        $display_title = $category['name'];
        $page_title = $site_name_for_title . ': ' . $category['name'] . ' of ' . date('Y');
    }
}

$page_description = !empty($category['seo_description'])
    ? $replacePlaceholders($category['seo_description'])
    : ($category['description'] ? $replacePlaceholders($category['description']) : '');

// Theme header
get_header();
?>

<main id="content" class="acms-cat-page">

    <!-- Hero Section -->
    <section class="acms-cat-hero">
        <div class="container">

            <!-- Breadcrumb -->
            <nav class="breadcrumb acms-cat-hero__breadcrumb" aria-label="<?php esc_attr_e('Breadcrumb', 'affiliatecms-cat'); ?>">
                <ol class="breadcrumb__list">
                    <li class="breadcrumb__item">
                        <a href="<?php echo esc_url(home_url('/')); ?>" class="breadcrumb__link">
                            <i class="bi bi-house-fill"></i>
                            <span><?php esc_html_e('Home', 'affiliatecms-cat'); ?></span>
                        </a>
                        <span class="breadcrumb__separator"><i class="bi bi-chevron-right"></i></span>
                    </li>
                    <?php foreach ($breadcrumbs as $i => $crumb) : ?>
                        <li class="breadcrumb__item">
                            <a href="<?php echo esc_url(home_url('/c/' . $crumb['slug'] . '/')); ?>" class="breadcrumb__link">
                                <?php echo esc_html($crumb['name']); ?>
                            </a>
                            <span class="breadcrumb__separator"><i class="bi bi-chevron-right"></i></span>
                        </li>
                    <?php endforeach; ?>
                    <li class="breadcrumb__item">
                        <span class="breadcrumb__current"><?php echo esc_html($category['name']); ?></span>
                    </li>
                </ol>
            </nav>

            <!-- Category Title -->
            <h1 class="acms-cat-hero__title"><?php echo esc_html($display_title); ?></h1>

            <!-- Description -->
            <?php if (!empty($category['description'])) : ?>
            <p class="acms-cat-hero__description"><?php echo esc_html($replacePlaceholders($category['description'])); ?></p>
            <?php endif; ?>

            <!-- Stats -->
            <div class="acms-cat-hero__stats">
                <span class="acms-cat-hero__stat">
                    <i class="bi bi-box-seam"></i>
                    <?php
                    $product_count = $total_products > 0 ? $total_products : ((int) $category['product_count'] ?: count($products));
                    printf(
                        esc_html(_n('%d product', '%d products', $product_count, 'affiliatecms-cat')),
                        $product_count
                    ); ?>
                </span>
                <?php if ($category['child_count'] > 0) : ?>
                <span class="acms-cat-hero__stat">
                    <i class="bi bi-diagram-3"></i>
                    <?php printf(
                        esc_html(_n('%d subcategory', '%d subcategories', $category['child_count'], 'affiliatecms-cat')),
                        $category['child_count']
                    ); ?>
                </span>

                <?php endif; ?>
            </div>

        </div>
    </section>

    <!-- Master-Detail Content (2-column layout) -->
    <section class="acms-cat-content">
        <div class="container" x-data="acmsCategoryPage(<?php echo esc_attr(wp_json_encode([
                'categoryId' => $category['id'],
                'products' => array_map(function($p, $idx) use ($affiliate_tag, $custom_url_params, $brand_slugs, $ssr_details, $redirect_enabled, $redirect_slug, $cf_param) {
                    $title = !empty($p->custom_title) ? $p->custom_title : $p->title;

                    // Check if best seller (from best_sellers_rank)
                    $is_best_seller = false;
                    if (!empty($p->best_sellers_rank)) {
                        $bsr = $p->best_sellers_rank;
                        if (is_string($bsr) && preg_match('/#(\d+)/', $bsr, $m)) {
                            $is_best_seller = (int) $m[1] <= 100;
                        }
                    }

                    $buy_url = 'https://www.amazon.com/dp/' . $p->asin . '?tag=' . urlencode($affiliate_tag) . ($custom_url_params ? '&' . $custom_url_params : '');
                    if ($redirect_enabled) {
                        $buy_url = home_url('/' . $redirect_slug . '/?url=' . urlencode($buy_url));
                        if (!empty($cf_param)) {
                            $buy_url .= '&' . $cf_param;
                        }
                    }

                    // Minimal fields for filter/sort/display
                    $item = [
                        'id' => (int) $p->id,
                        'asin' => $p->asin,
                        'title' => $title,
                        'price' => (float) ($p->price ?? 0),
                        'original_price' => (float) ($p->original_price ?? 0),
                        'currency' => $p->currency ?? 'USD',
                        'rating' => (float) ($p->rating ?? 0),
                        'reviews_count' => (int) ($p->reviews_count ?? 0),
                        'main_image' => $p->image_url ?? null,
                        'buy_url' => $buy_url,
                        'brand' => $p->brand ?? '',
                        'brand_url' => isset($brand_slugs[$p->brand ?? '']) ? home_url('/brand/' . $brand_slugs[$p->brand] . '/') : '',
                        'source_category_id' => (int) ($p->source_category_id ?? 0),
                        'is_prime' => (bool) ($p->is_prime ?? false),
                        'in_stock' => (bool) ($p->in_stock ?? true),
                        'score' => (int) ($p->score ?? 70),
                        'is_best_seller' => $is_best_seller,
                        'updated_at' => $p->updated_at ?? null,
                        // Detail fields — defaults empty, loaded via REST API on click
                        'features' => [],
                        'pros' => [],
                        'cons' => [],
                        'short_review' => '',
                        'affiliate_links' => [],
                        '_detailLoaded' => false,
                        '_ssr' => true,
                    ];

                    // SSR products: include detail data inline (no API call needed on click)
                    if (isset($ssr_details[$idx])) {
                        $d = $ssr_details[$idx];
                        $item['features'] = $d['features'];
                        $item['pros'] = $d['pros'];
                        $item['cons'] = $d['cons'];
                        $item['short_review'] = $d['short_review'];
                        $item['affiliate_links'] = $d['affiliate_links'];
                        $item['_detailLoaded'] = true;
                    }

                    return $item;
                }, $products, array_keys($products)),
                'filters' => [
                    'priceMin' => (float) $filter_price_min,
                    'priceMax' => (float) $filter_price_max,
                    'ratings' => $filter_ratings,
                ],
                'catTree' => $cat_tree_nested,
                'currentCatId' => (string) $current_cat_id,
                'currentCatName' => $category['name'],
                'catExpanded' => array_map('strval', $expanded_ids),
                'totalProducts' => (int) $total_products,
                'perPage' => $per_page,
                'isBrandCategory' => $is_brand_category,
                'brandName' => $brand_name_filter,
                'brandCategoryNav' => $brand_category_nav,
                'display' => [
                    'showPrice' => (bool) $show_price,
                    'showRating' => (bool) $show_rating,
                    'showPrime' => (bool) $show_prime,
                    'showStock' => (bool) $show_stock,
                    'showUpdate' => (bool) $show_update,
                ],
            ])); ?>)"
             @keydown.escape.window="if (detailModalOpen) { history.back(); }">

                <!-- Quick Filter Bar (acms-fbar) -->
                <div class="acms-fbar">
                    <!-- Row 1: Filter Grid -->
                    <div class="acms-fbar__grid<?php echo $has_brand_nav ? '' : ' acms-fbar__grid--no-brand'; ?>">

                        <!-- Col 1: Category (navigation menu, not a filter) -->
                        <div class="acms-fbar__col acms-fbar__col--cat" @click.outside="catOpen = false">
                            <button type="button" class="acms-fbar__trigger is-active"
                                    @click="catOpen = !catOpen">
                                <i class="bi bi-diagram-3 acms-fbar__icon"></i>
                                <span class="acms-fbar__label" x-text="currentCatName"></span>
                                <i class="bi bi-chevron-down acms-fbar__chevron" :class="{ 'is-open': catOpen }"></i>
                            </button>
                            <div class="acms-fbar__panel" x-show="catOpen" x-cloak x-transition.scale.origin.top
                                 style="min-width:340px">
                                <div class="acms-fbar__search">
                                    <i class="bi bi-search"></i>
                                    <input type="text" placeholder="<?php echo esc_attr__('Search categories...', 'affiliatecms-cat'); ?>" x-model="catSearch">
                                </div>
                                <div class="acms-fbar__scroll">
                                    <ul class="acms-fbar__tree">
                                        <!-- Level 0 -->
                                        <template x-for="n0 in catTree.filter(n => catMatchesSearch(n))" :key="n0.id">
                                            <li class="acms-fbar__tree-item">
                                                <div class="acms-fbar__tree-row" :class="{ 'is-current': n0.id === currentCatId }">
                                                    <template x-if="n0.children.length > 0 || n0.child_count > 0">
                                                        <button type="button" class="acms-fbar__tree-arrow"
                                                              :class="{ 'is-open': catExpanded.includes(n0.id) || catSearch, 'is-loading': catLoading.includes(n0.id) }"
                                                              @click="toggleCatExpand(n0.id)">
                                                            <i class="bi" :class="catLoading.includes(n0.id) ? 'bi-arrow-repeat acms-fbar__spin' : 'bi-chevron-right'"></i>
                                                        </button>
                                                    </template>
                                                    <template x-if="n0.children.length === 0 && !n0.child_count">
                                                        <span class="acms-fbar__tree-dot"></span>
                                                    </template>
                                                    <a :href="'<?php echo esc_url(home_url('/c/')); ?>' + n0.slug + '/'" class="acms-fbar__tree-link">
                                                        <span class="acms-fbar__tree-name" x-text="n0.name"></span>
                                                        <span class="acms-fbar__tree-count" x-text="n0.product_count"></span>
                                                    </a>
                                                </div>
                                                <!-- Level 1 -->
                                                <ul class="acms-fbar__tree"
                                                    x-show="(catExpanded.includes(n0.id) || catSearch) && n0.children.length > 0">
                                                    <template x-for="n1 in n0.children.filter(c => catMatchesSearch(c))" :key="n1.id">
                                                        <li class="acms-fbar__tree-item">
                                                            <div class="acms-fbar__tree-row" :class="{ 'is-current': n1.id === currentCatId }">
                                                                <template x-if="n1.children.length > 0 || n1.child_count > 0">
                                                                    <button type="button" class="acms-fbar__tree-arrow"
                                                                          :class="{ 'is-open': catExpanded.includes(n1.id) || catSearch, 'is-loading': catLoading.includes(n1.id) }"
                                                                          @click="toggleCatExpand(n1.id)">
                                                                        <i class="bi" :class="catLoading.includes(n1.id) ? 'bi-arrow-repeat acms-fbar__spin' : 'bi-chevron-right'"></i>
                                                                    </button>
                                                                </template>
                                                                <template x-if="n1.children.length === 0 && !n1.child_count">
                                                                    <span class="acms-fbar__tree-dot"></span>
                                                                </template>
                                                                <a :href="'<?php echo esc_url(home_url('/c/')); ?>' + n1.slug + '/'" class="acms-fbar__tree-link">
                                                                    <span class="acms-fbar__tree-name" x-text="n1.name"></span>
                                                                    <span class="acms-fbar__tree-count" x-text="n1.product_count"></span>
                                                                </a>
                                                            </div>
                                                            <!-- Level 2 -->
                                                            <ul class="acms-fbar__tree"
                                                                x-show="(catExpanded.includes(n1.id) || catSearch) && n1.children.length > 0">
                                                                <template x-for="n2 in n1.children.filter(c => catMatchesSearch(c))" :key="n2.id">
                                                                    <li class="acms-fbar__tree-item">
                                                                        <div class="acms-fbar__tree-row" :class="{ 'is-current': n2.id === currentCatId }">
                                                                            <template x-if="n2.children.length > 0 || n2.child_count > 0">
                                                                                <button type="button" class="acms-fbar__tree-arrow"
                                                                                      :class="{ 'is-open': catExpanded.includes(n2.id) || catSearch, 'is-loading': catLoading.includes(n2.id) }"
                                                                                      @click="toggleCatExpand(n2.id)">
                                                                                    <i class="bi" :class="catLoading.includes(n2.id) ? 'bi-arrow-repeat acms-fbar__spin' : 'bi-chevron-right'"></i>
                                                                                </button>
                                                                            </template>
                                                                            <template x-if="n2.children.length === 0 && !n2.child_count">
                                                                                <span class="acms-fbar__tree-dot"></span>
                                                                            </template>
                                                                            <a :href="'<?php echo esc_url(home_url('/c/')); ?>' + n2.slug + '/'" class="acms-fbar__tree-link">
                                                                                <span class="acms-fbar__tree-name" x-text="n2.name"></span>
                                                                                <span class="acms-fbar__tree-count" x-text="n2.product_count"></span>
                                                                            </a>
                                                                        </div>
                                                                        <!-- Level 3 -->
                                                                        <ul class="acms-fbar__tree"
                                                                            x-show="(catExpanded.includes(n2.id) || catSearch) && n2.children.length > 0">
                                                                            <template x-for="n3 in n2.children.filter(c => catMatchesSearch(c))" :key="n3.id">
                                                                                <li class="acms-fbar__tree-item">
                                                                                    <div class="acms-fbar__tree-row" :class="{ 'is-current': n3.id === currentCatId }">
                                                                                        <template x-if="n3.children.length > 0 || n3.child_count > 0">
                                                                                            <button type="button" class="acms-fbar__tree-arrow"
                                                                                                  :class="{ 'is-open': catExpanded.includes(n3.id) || catSearch, 'is-loading': catLoading.includes(n3.id) }"
                                                                                                  @click="toggleCatExpand(n3.id)">
                                                                                                <i class="bi" :class="catLoading.includes(n3.id) ? 'bi-arrow-repeat acms-fbar__spin' : 'bi-chevron-right'"></i>
                                                                                            </button>
                                                                                        </template>
                                                                                        <template x-if="n3.children.length === 0 && !n3.child_count">
                                                                                            <span class="acms-fbar__tree-dot"></span>
                                                                                        </template>
                                                                                        <a :href="'<?php echo esc_url(home_url('/c/')); ?>' + n3.slug + '/'" class="acms-fbar__tree-link">
                                                                                            <span class="acms-fbar__tree-name" x-text="n3.name"></span>
                                                                                            <span class="acms-fbar__tree-count" x-text="n3.product_count"></span>
                                                                                        </a>
                                                                                    </div>
                                                                                    <!-- Level 4 -->
                                                                                    <ul class="acms-fbar__tree"
                                                                                        x-show="(catExpanded.includes(n3.id) || catSearch) && n3.children.length > 0">
                                                                                        <template x-for="n4 in n3.children.filter(c => catMatchesSearch(c))" :key="n4.id">
                                                                                            <li class="acms-fbar__tree-item">
                                                                                                <div class="acms-fbar__tree-row" :class="{ 'is-current': n4.id === currentCatId }">
                                                                                                    <span class="acms-fbar__tree-dot"></span>
                                                                                                    <a :href="'<?php echo esc_url(home_url('/c/')); ?>' + n4.slug + '/'" class="acms-fbar__tree-link">
                                                                                                        <span class="acms-fbar__tree-name" x-text="n4.name"></span>
                                                                                                        <span class="acms-fbar__tree-count" x-text="n4.product_count"></span>
                                                                                                    </a>
                                                                                                </div>
                                                                                            </li>
                                                                                        </template>
                                                                                    </ul>
                                                                                </li>
                                                                            </template>
                                                                        </ul>
                                                                    </li>
                                                                </template>
                                                            </ul>
                                                        </li>
                                                    </template>
                                                </ul>
                                            </li>
                                        </template>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <?php if ($has_brand_nav) : ?>
                        <!-- Col 2: Brand (navigation to brand sub-category pages) -->
                        <div class="acms-fbar__col acms-fbar__col--brand" @click.outside="brandOpen = false">
                            <button type="button" class="acms-fbar__trigger"
                                    :class="{ 'is-active': isBrandCategory }"
                                    @click="brandOpen = !brandOpen">
                                <i class="bi bi-tag acms-fbar__icon"></i>
                                <span class="acms-fbar__label"
                                      x-text="isBrandCategory ? brandName : '<?php echo esc_js(__('Brand', 'affiliatecms-cat')); ?>'"></span>
                                <i class="bi bi-chevron-down acms-fbar__chevron" :class="{ 'is-open': brandOpen }"></i>
                            </button>
                            <div class="acms-fbar__panel" x-show="brandOpen" x-cloak x-transition.scale.origin.top>
                                <div class="acms-fbar__scroll">
                                    <template x-for="bc in brandCategoryNav" :key="bc.slug">
                                        <a :href="'<?php echo esc_url(home_url('/c/')); ?>' + bc.slug + '/'"
                                           class="acms-fbar__brand-link"
                                           :class="{ 'is-current': isBrandCategory && brandName === bc.name }">
                                            <span class="acms-fbar__option-text" x-text="bc.name"></span>
                                            <span class="acms-fbar__option-num" x-text="bc.count"></span>
                                        </a>
                                    </template>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php /* Col 3: Rating — hidden, may re-enable later
                        <div class="acms-fbar__col acms-fbar__col--rating" @click.outside="ratingOpen = false">
                            <button type="button" class="acms-fbar__trigger"
                                    :class="{ 'is-active': activeFilters.minRating > 0 }"
                                    @click="ratingOpen = !ratingOpen">
                                <i class="bi bi-star-fill acms-fbar__icon acms-fbar__icon--star"></i>
                                <span class="acms-fbar__label"
                                      x-text="activeFilters.minRating > 0
                                          ? activeFilters.minRating + '+ Stars'
                                          : 'Rating'"></span>
                                <i class="bi bi-chevron-down acms-fbar__chevron" :class="{ 'is-open': ratingOpen }"></i>
                            </button>
                            <div class="acms-fbar__panel" x-show="ratingOpen" x-cloak x-transition.scale.origin.top>
                                <button type="button" class="acms-fbar__btn-option"
                                        :class="{ 'is-selected': activeFilters.minRating === 0 }"
                                        @click="activeFilters.minRating = 0; ratingOpen = false">
                                    All Ratings
                                </button>
                                <template x-for="r in [4, 3, 2, 1]" :key="r">
                                    <button type="button" class="acms-fbar__btn-option"
                                            :class="{ 'is-selected': activeFilters.minRating === r }"
                                            @click="activeFilters.minRating = r; ratingOpen = false">
                                        <span class="acms-fbar__stars">
                                            <template x-for="s in 5" :key="s">
                                                <i class="bi" :class="s <= r ? 'bi-star-fill' : 'bi-star'"></i>
                                            </template>
                                        </span>
                                        <span x-text="r + '+ Stars'"></span>
                                    </button>
                                </template>
                            </div>
                        </div>
                        */ ?>

                        <!-- Col 3: Price (inline slider, no dropdown) -->
                        <div class="acms-fbar__col acms-fbar__col--price"
                             x-data="{
                                 min: Math.floor(filters.priceMin || 0),
                                 max: Math.ceil(filters.priceMax || 1000),
                                 get lo() { return activeFilters.priceMin ?? this.min; },
                                 set lo(v) { activeFilters.priceMin = (v <= this.min) ? null : v; },
                                 get hi() { return activeFilters.priceMax ?? this.max; },
                                 set hi(v) { activeFilters.priceMax = (v >= this.max) ? null : v; },
                                 get loPct() { return ((this.lo - this.min) / (this.max - this.min)) * 100; },
                                 get hiPct() { return ((this.hi - this.min) / (this.max - this.min)) * 100; },
                                 get isFiltering() { return activeFilters.priceMin !== null || activeFilters.priceMax !== null; }
                             }">
                            <span class="acms-fbar__price-bound" x-text="'$' + min"></span>
                            <div class="acms-fbar__slider-inline">
                                <div class="acms-fbar__slider-track">
                                    <div class="acms-fbar__slider-range" :style="'left: calc(8px + (100% - 16px) * ' + loPct + ' / 100); right: calc(8px + (100% - 16px) * ' + (100 - hiPct) + ' / 100)'"></div>
                                    <span class="acms-fbar__slider-tip" x-show="isFiltering" x-cloak
                                          :style="'left: calc(8px + (100% - 16px) * ' + loPct + ' / 100)'" x-text="'$' + lo"></span>
                                    <span class="acms-fbar__slider-tip" x-show="isFiltering" x-cloak
                                          :style="'left: calc(8px + (100% - 16px) * ' + hiPct + ' / 100)'" x-text="'$' + hi"></span>
                                    <input type="range" class="acms-fbar__slider-input"
                                           aria-label="<?php esc_attr_e('Minimum price', 'affiliatecms'); ?>"
                                           :min="min" :max="max" x-model.number="lo"
                                           @input="if(lo > hi - 1) lo = hi - 1">
                                    <input type="range" class="acms-fbar__slider-input"
                                           aria-label="<?php esc_attr_e('Maximum price', 'affiliatecms'); ?>"
                                           :min="min" :max="max" x-model.number="hi"
                                           @input="if(hi < lo + 1) hi = lo + 1">
                                </div>
                            </div>
                            <span class="acms-fbar__price-bound" x-text="'$' + max"></span>
                        </div>

                    </div>

                    <!-- Row 2: Status (count + tags + sort) — only visible when filters active -->
                    <div class="acms-fbar__status" x-show="hasActiveFilters()" x-transition x-cloak>
                        <span class="acms-fbar__count">
                            <i class="bi bi-box-seam"></i>
                            <span x-text="filteredProducts.length === products.length
                                ? filteredProducts.length + ' products'
                                : filteredProducts.length + ' of ' + products.length"></span>
                        </span>

                        <template x-if="hasActiveFilters()">
                            <div class="acms-fbar__tags" style="display:contents">
                                <span class="acms-fbar__divider"></span>

                                <?php /* Rating tag — hidden with rating filter
                                <template x-if="activeFilters.minRating > 0">
                                    <span class="acms-fbar__tag acms-fbar__tag--star">
                                        <i class="bi bi-star-fill"></i>
                                        <span x-text="activeFilters.minRating + '+'"></span>
                                        <button type="button" @click="activeFilters.minRating = 0"><i class="bi bi-x"></i></button>
                                    </span>
                                </template>
                                */ ?>

                                <template x-if="activeFilters.priceMin !== null || activeFilters.priceMax !== null">
                                    <span class="acms-fbar__tag acms-fbar__tag--price">
                                        <i class="bi bi-currency-dollar"></i>
                                        <span x-text="'$' + (activeFilters.priceMin ?? filters.priceMin) + ' – $' + (activeFilters.priceMax ?? filters.priceMax)"></span>
                                        <button type="button" @click="activeFilters.priceMin = null; activeFilters.priceMax = null"><i class="bi bi-x"></i></button>
                                    </span>
                                </template>

                                <button type="button" class="acms-fbar__clear" @click="clearAllFilters()">
                                    <i class="bi bi-x-circle"></i> <?php esc_html_e('Clear all', 'affiliatecms-cat'); ?>
                                </button>
                            </div>
                        </template>

                        <!-- Sort (right-aligned) -->
                        <div class="acms-fbar__sort" @click.outside="sortOpen = false">
                            <button type="button" class="acms-fbar__sort-btn" @click="sortOpen = !sortOpen">
                                <i class="bi bi-sort-down"></i>
                                <span x-text="sortLabels[sortBy]"></span>
                                <i class="bi bi-chevron-down acms-fbar__chevron" :class="{ 'is-open': sortOpen }"></i>
                            </button>
                            <div class="acms-fbar__panel acms-fbar__panel--sort" x-show="sortOpen" x-cloak x-transition.scale.origin.top>
                                <template x-for="(label, key) in sortLabels" :key="key">
                                    <button type="button" class="acms-fbar__btn-option"
                                            :class="{ 'is-selected': sortBy === key }"
                                            @click="sortBy = key; sortOpen = false">
                                        <i class="bi" :class="sortIcons[key]"></i>
                                        <span x-text="label"></span>
                                    </button>
                                </template>
                            </div>
                        </div>
                    </div>
                </div>

            <div class="acms-cat-layout">
                <!-- Sidebar: Product List (Sticky) -->
                <aside class="acms-cat-sidebar">
                    <div class="acms-cat-sidebar__inner">

                        <!-- Products Header -->
                        <div class="acms-cat-sidebar__header">
                            <h2 class="acms-cat-sidebar__title">
                                <i class="bi bi-list-ul"></i>
                                <?php esc_html_e('Products', 'affiliatecms-cat'); ?>
                            </h2>
                            <span class="acms-cat-sidebar__count" x-text="filteredProducts.length + (hasMore ? '+' : '') + ' items'"></span>
                        </div>

                        <div class="acms-cat-products">
                            <?php
                            // SSR Product List with Schema.org microdata (SEO-friendly)
                            $placeholder_img = esc_url(get_template_directory_uri() . '/assets/images/placeholder.svg');
                            foreach ($products as $index => $p) :
                                $title = !empty($p->custom_title) ? $p->custom_title : $p->title;
                                $price = (float) ($p->price ?? 0);
                                $currency = $p->currency ?? 'USD';
                                $rating = (float) ($p->rating ?? 0);
                                $image = acms_resize_amazon_image($p->image_url ?? $placeholder_img, 200);
                                $brand = $p->brand ?? '';
                                $in_stock = (bool) ($p->in_stock ?? true);
                            ?>
                            <article
                                class="acms-cat-product-card"
                                itemscope
                                itemtype="https://schema.org/Product"
                                data-product-id="<?php echo (int) $p->id; ?>"
                                data-asin="<?php echo esc_attr($p->asin); ?>"
                                data-brand="<?php echo esc_attr($brand); ?>"
                                data-price="<?php echo esc_attr($price); ?>"
                                data-rating="<?php echo esc_attr($rating); ?>"
                                data-category-id="<?php echo (int) ($p->source_category_id ?? 0); ?>"
                                :class="{ 'acms-cat-product-card--active': selectedProduct && selectedProduct.id === <?php echo (int) $p->id; ?> }"
                                :style="'order:' + getProductSortOrder(<?php echo (int) $p->id; ?>)"
                                x-show="isProductVisible(<?php echo (int) $p->id; ?>)"
                                @click="selectProductById(<?php echo (int) $p->id; ?>)"
                            >
                                <div class="acms-cat-product-card__image">
                                    <img
                                        src="<?php echo esc_url($image); ?>"
                                        alt="<?php echo esc_attr($title); ?>"
                                        loading="lazy"
                                        itemprop="image"
                                        onerror="this.onerror=null;this.src='<?php echo $placeholder_img; ?>';"
                                    >
                                </div>
                                <div class="acms-cat-product-card__content">
                                    <h3 class="acms-cat-product-card__title" itemprop="name"><?php echo esc_html($title); ?></h3>
                                    <?php if ($brand) : ?>
                                    <meta itemprop="brand" content="<?php echo esc_attr($brand); ?>">
                                    <?php endif; ?>
                                    <div class="acms-cat-product-card__meta">
                                        <?php if ($show_price) : ?>
                                        <span class="acms-cat-product-card__price" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
                                            <meta itemprop="priceCurrency" content="<?php echo esc_attr($currency); ?>">
                                            <meta itemprop="availability" content="<?php echo $in_stock ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock'; ?>">
                                            <?php if ($price > 0) : ?>
                                            <meta itemprop="price" content="<?php echo esc_attr($price); ?>">
                                            <?php echo esc_html($currency === 'USD' ? '$' : $currency); ?><?php echo esc_html(number_format($price, 2)); ?>
                                            <?php endif; ?>
                                        </span>
                                        <?php endif; ?>
                                        <?php
                                        $score = (int) ($p->score ?? 0);
                                        if ($show_rating && $score > 0) : ?>
                                        <span class="acms-cat-product-card__score">
                                            <i class="bi bi-bar-chart-fill"></i>
                                            <span><?php echo number_format($score / 10, 1); ?></span>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="acms-cat-product-card__indicator">
                                    <i class="bi bi-chevron-right"></i>
                                </div>
                            </article>
                            <?php endforeach; ?>

                            <!-- Dynamically loaded products (via Load More) -->
                            <template x-for="product in filteredProducts.filter(p => !p._ssr)" :key="product.id">
                                <article
                                    class="acms-cat-product-card"
                                    :class="{ 'acms-cat-product-card--active': selectedProduct && selectedProduct.id === product.id }"
                                    @click="selectProduct(product)"
                                >
                                    <div class="acms-cat-product-card__image">
                                        <img
                                            :src="product.main_image || '<?php echo esc_url(get_template_directory_uri() . '/assets/images/placeholder.svg'); ?>'"
                                            :alt="product.title"
                                            loading="lazy"
                                            onerror="this.onerror=null;this.src='<?php echo esc_url(get_template_directory_uri() . '/assets/images/placeholder.svg'); ?>';"
                                        >
                                    </div>
                                    <div class="acms-cat-product-card__content">
                                        <h3 class="acms-cat-product-card__title" x-text="product.title"></h3>
                                        <div class="acms-cat-product-card__meta">
                                            <span class="acms-cat-product-card__price" x-show="display.showPrice && product.price > 0" x-text="formatPrice(product.price, product.currency)"></span>
                                            <template x-if="display.showRating && product.score > 0">
                                                <span class="acms-cat-product-card__score">
                                                    <i class="bi bi-bar-chart-fill"></i>
                                                    <span x-text="(product.score / 10).toFixed(1)"></span>
                                                </span>
                                            </template>
                                        </div>
                                    </div>
                                    <div class="acms-cat-product-card__indicator">
                                        <i class="bi bi-chevron-right"></i>
                                    </div>
                                </article>
                            </template>

                            <?php if (empty($products)) : ?>
                            <!-- Empty State (no products in category) -->
                            <div class="acms-cat-products__empty">
                                <i class="bi bi-inbox"></i>
                                <p><?php esc_html_e('No products in this category yet.', 'affiliatecms-cat'); ?></p>
                            </div>
                            <?php endif; ?>

                            <!-- Empty State (filtered - shown by Alpine.js) -->
                            <div class="acms-cat-products__empty" x-show="products.length > 0 && filteredProducts.length === 0" x-cloak>
                                <i class="bi bi-funnel"></i>
                                <p><?php esc_html_e('No products match your filters.', 'affiliatecms-cat'); ?></p>
                            </div>
                        </div>

                        <!-- Load More Button -->
                        <div class="acms-cat-sidebar__load-more" x-show="hasMore" x-cloak>
                            <button
                                type="button"
                                class="acms-cat-load-more"
                                @click="loadMore()"
                                :disabled="loadingMore"
                            >
                                <template x-if="!loadingMore">
                                    <span>
                                        <i class="bi bi-plus-circle"></i>
                                        <?php esc_html_e('Load More Products', 'affiliatecms-cat'); ?>
                                        <span class="acms-cat-load-more__count" x-text="'(' + products.length + ' / ' + totalProducts + ')'"></span>
                                    </span>
                                </template>
                                <template x-if="loadingMore">
                                    <span>
                                        <i class="bi bi-arrow-repeat acms-cat-tree__spin"></i>
                                        <?php esc_html_e('Loading...', 'affiliatecms-cat'); ?>
                                    </span>
                                </template>
                            </button>
                        </div>

                        <!-- Category Tree Navigation -->
                        <?php if (!empty($tree_by_parent)) : ?>
                        <div class="acms-cat-tree">
                            <div class="acms-cat-tree__header">
                                <i class="bi bi-diagram-3"></i>
                                <span><?php esc_html_e('Categories', 'affiliatecms-cat'); ?></span>
                            </div>
                            <nav class="acms-cat-tree__nav">
                                <?php
                                // Recursive tree renderer with expand/collapse support
                                function acms_render_cat_tree(array $tree_by_parent, int $parent_id, int $current_cat_id, array $expanded_ids, int $max_depth = 4): void {
                                    if (!isset($tree_by_parent[$parent_id]) || $max_depth <= 0) {
                                        return;
                                    }
                                    echo '<ul class="acms-cat-tree__list">';
                                    foreach ($tree_by_parent[$parent_id] as $node) {
                                        $nid = (int) $node['id'];
                                        $is_current = ($nid === $current_cat_id);
                                        $is_ancestor = in_array($nid, $expanded_ids, true);
                                        $has_loaded_children = isset($tree_by_parent[$nid]);
                                        $has_any_children = $has_loaded_children || (int) $node['child_count'] > 0;
                                        $is_expanded = $has_loaded_children && ($is_ancestor || $is_current);

                                        $classes = 'acms-cat-tree__item';
                                        if ($is_current) $classes .= ' is-current';
                                        if ($is_ancestor && !$is_current) $classes .= ' is-ancestor';
                                        if ($is_expanded) $classes .= ' is-expanded';

                                        echo '<li class="' . esc_attr($classes) . '">';
                                        echo '<div class="acms-cat-tree__row">';

                                        // Toggle button (expand/collapse) or leaf dot
                                        if ($has_any_children) {
                                            echo '<button type="button" class="acms-cat-tree__toggle" data-cat-id="' . $nid . '" aria-expanded="' . ($is_expanded ? 'true' : 'false') . '">';
                                            echo '<i class="bi ' . ($is_expanded ? 'bi-chevron-down' : 'bi-chevron-right') . '"></i>';
                                            echo '</button>';
                                        } else {
                                            echo '<span class="acms-cat-tree__dot"></span>';
                                        }

                                        // Category link (name + count)
                                        echo '<a href="' . esc_url(home_url('/c/' . $node['slug'] . '/')) . '" class="acms-cat-tree__link">';
                                        echo '<span class="acms-cat-tree__name">' . esc_html($node['name']) . '</span>';
                                        if ((int) $node['product_count'] > 0) {
                                            echo '<span class="acms-cat-tree__count">' . (int) $node['product_count'] . '</span>';
                                        }
                                        echo '</a>';

                                        echo '</div>';

                                        // Always render children if loaded (hidden by default, expanded for ancestors)
                                        if ($has_loaded_children) {
                                            acms_render_cat_tree($tree_by_parent, $nid, $current_cat_id, $expanded_ids, $max_depth - 1);
                                        }

                                        echo '</li>';
                                    }
                                    echo '</ul>';
                                }
                                acms_render_cat_tree($tree_by_parent, 0, $current_cat_id, $expanded_ids);
                                ?>
                            </nav>
                        </div>
                        <?php endif; ?>

                    </div>
                </aside>

                <!-- Main: Product Detail + AI Content + Keywords -->
                <div class="acms-cat-main">

                    <!-- Detail Modal (fullscreen on mobile <1024px, normal flow on desktop) -->
                    <div class="acms-cat-detail-modal" :class="{ 'is-open': detailModalOpen }">

                        <!-- Mobile Modal Header (visible only <1024px via CSS) -->
                        <div class="acms-cat-modal-header">
                            <button type="button" class="acms-cat-modal-header__back" @click="history.back()">
                                <i class="bi bi-arrow-left"></i>
                                <span><?php esc_html_e('Back', 'affiliatecms-cat'); ?></span>
                            </button>
                            <span class="acms-cat-modal-header__title" x-text="selectedProduct?.title || ''"></span>
                        </div>

                        <!-- Product Detail Card -->
                        <div class="acms-cat-detail">

                        <!-- Empty State (no product selected) -->
                        <div class="acms-cat-detail__empty" x-show="!selectedProduct">
                            <div class="acms-cat-detail__empty-icon">
                                <i class="bi bi-hand-index"></i>
                            </div>
                            <h3><?php esc_html_e('Select a Product', 'affiliatecms-cat'); ?></h3>
                            <p><?php esc_html_e('Click on a product from the list to view its details.', 'affiliatecms-cat'); ?></p>
                        </div>

                        <!-- Product Detail Content -->
                        <div class="acms-cat-detail__content" x-show="selectedProduct" x-cloak>

                            <!-- Product Header (Rich Card Layout) -->
                            <div class="acms-cat-detail__header">
                                <!-- Image with Ranking Badge -->
                                <div class="acms-cat-detail__image-wrap">
                                    <div class="acms-cat-detail__rank" x-text="getProductRank(selectedProduct)"></div>
                                    <a :href="selectedProduct?.buy_url || '#'" class="acms-cat-detail__image" target="_blank" rel="nofollow">
                                        <img
                                            :src="selectedProduct?.main_image || '<?php echo esc_url(get_template_directory_uri() . '/assets/images/placeholder.svg'); ?>'"
                                            :alt="selectedProduct?.title"
                                            onerror="this.onerror=null;this.src='<?php echo esc_url(get_template_directory_uri() . '/assets/images/placeholder.svg'); ?>';"
                                        >
                                    </a>
                                </div>

                                <div class="acms-cat-detail__info">
                                    <!-- Title with Prime Badge -->
                                    <h2 class="acms-cat-detail__title">
                                        <span class="acms-cat-detail__badge acms-cat-detail__badge--prime" x-show="display.showPrime && selectedProduct?.is_prime" x-cloak>
                                            <i class="bi bi-check-circle-fill"></i> PRIME
                                        </span>
                                        <a :href="selectedProduct?.buy_url || '#'" target="_blank" rel="nofollow">
                                            <span x-text="selectedProduct?.title"></span>
                                        </a>
                                    </h2>

                                    <!-- Info + CTA Grid (65/35) -->
                                    <div class="acms-cat-detail__info-grid">
                                        <!-- Col 1: Meta + Price -->
                                        <div class="acms-cat-detail__info-col">
                                            <div class="acms-cat-detail__meta">
                                                <!-- Brand with Verified -->
                                                <template x-if="selectedProduct?.brand_url">
                                                    <a :href="selectedProduct.brand_url" class="acms-cat-detail__meta-item acms-cat-detail__brand acms-cat-detail__brand--link" x-show="selectedProduct?.brand">
                                                        <i class="bi bi-patch-check-fill"></i>
                                                        <span x-text="selectedProduct?.brand"></span>
                                                    </a>
                                                </template>
                                                <template x-if="!selectedProduct?.brand_url">
                                                    <span class="acms-cat-detail__meta-item acms-cat-detail__brand" x-show="selectedProduct?.brand">
                                                        <i class="bi bi-patch-check-fill"></i>
                                                        <span x-text="selectedProduct?.brand"></span>
                                                    </span>
                                                </template>

                                                <!-- Score with Tooltip (compact: no "Score" label) -->
                                                <span class="acms-cat-detail__meta-item acms-cat-detail__score-wrap" x-show="display.showRating && selectedProduct?.score" x-data="{ showTooltip: false }" @mouseenter="showTooltip = true" @mouseleave="showTooltip = false" @click.away="showTooltip = false">
                                                    <i class="bi bi-bar-chart-fill"></i>
                                                    <strong x-text="(selectedProduct?.score / 10).toFixed(1)"></strong>
                                                    <i class="bi bi-info-circle acms-cat-detail__info-icon" @click.stop="showTooltip = !showTooltip"></i>
                                                    <div class="acms-cat-detail__tooltip" x-show="showTooltip" x-transition @click.stop>
                                                        <?php
                                                        echo esc_html(defined('ACMS_SCORE_TOOLTIP') ? ACMS_SCORE_TOOLTIP : __('Score is calculated based on product ratings, reviews, and sales performance to help you make informed purchasing decisions.', 'affiliatecms-cat'));
                                                        $score_link_text = defined('ACMS_SCORE_TOOLTIP_LINK_TEXT') ? ACMS_SCORE_TOOLTIP_LINK_TEXT : '';
                                                        $score_link_url = defined('ACMS_SCORE_TOOLTIP_LINK_URL') ? ACMS_SCORE_TOOLTIP_LINK_URL : '';
                                                        if ($score_link_text && $score_link_url) :
                                                        ?> <a href="<?php echo esc_url($score_link_url); ?>"><?php echo esc_html($score_link_text); ?> &raquo;</a><?php
                                                        endif;
                                                        ?>
                                                    </div>
                                                </span>

                                                <!-- Stock Status -->
                                                <span class="acms-cat-detail__meta-item acms-cat-detail__stock" x-show="display.showStock" :class="{ 'in-stock': selectedProduct?.in_stock, 'out-of-stock': !selectedProduct?.in_stock }">
                                                    <i class="bi" :class="selectedProduct?.in_stock ? 'bi-check-circle-fill' : 'bi-x-circle-fill'"></i>
                                                    <span x-text="selectedProduct?.in_stock ? '<?php echo esc_js(__('In Stock', 'affiliatecms-cat')); ?>' : '<?php echo esc_js(__('Out of Stock', 'affiliatecms-cat')); ?>'"></span>
                                                </span>

                                                <!-- Updated Date with Tooltip -->
                                                <span class="acms-cat-detail__meta-item acms-cat-detail__updated" x-show="display.showUpdate && selectedProduct?.updated_at" x-data="{ showTooltip: false }" @mouseenter="showTooltip = true" @mouseleave="showTooltip = false" @click.away="showTooltip = false">
                                                    <i class="bi bi-clock"></i>
                                                    <span x-text="formatDate(selectedProduct?.updated_at)"></span>
                                                    <i class="bi bi-info-circle acms-cat-detail__info-icon" @click.stop="showTooltip = !showTooltip"></i>
                                                    <div class="acms-cat-detail__tooltip acms-cat-detail__tooltip--right" x-show="showTooltip" x-transition @click.stop>
                                                        <?php
                                                        $update_tooltip = defined('ACMS_UPDATE_TOOLTIP') ? ACMS_UPDATE_TOOLTIP : 'Last update on {date}. Affiliate links, prices, images, product titles, and highlights from Amazon Product Advertising API.';
                                                        // Split on {date} placeholder to inject dynamic Alpine.js element
                                                        $tooltip_parts = explode('{date}', $update_tooltip, 2);
                                                        echo esc_html($tooltip_parts[0]);
                                                        ?><strong x-text="formatDate(selectedProduct?.updated_at)"></strong><?php
                                                        if (isset($tooltip_parts[1])) echo esc_html($tooltip_parts[1]);
                                                        ?>
                                                    </div>
                                                </span>
                                            </div>

                                            <div class="acms-cat-detail__price-wrap" x-show="display.showPrice && selectedProduct?.price > 0">
                                                <span class="acms-cat-detail__price" x-text="formatPrice(selectedProduct?.price, selectedProduct?.currency)"></span>
                                                <span class="acms-cat-detail__price-original" x-show="selectedProduct?.original_price && selectedProduct?.original_price > selectedProduct?.price" x-text="formatPrice(selectedProduct?.original_price, selectedProduct?.currency)"></span>
                                            </div>
                                        </div>

                                        <!-- Col 2: CTA Buttons -->
                                        <div class="acms-cat-detail__cta-col">
                                            <a
                                                :href="selectedProduct?.buy_url || '#'"
                                                class="btn btn--accent acms-cat-detail__cta"
                                                target="_blank"
                                                rel="nofollow"
                                            >
                                                <i class="bi bi-cart-fill"></i>
                                                <?php esc_html_e('View on Amazon', 'affiliatecms-cat'); ?>
                                            </a>
                                            <template x-for="link in (selectedProduct?.affiliate_links || []).filter(l => l.affiliate_url)" :key="link.id">
                                                <a
                                                    :href="link.affiliate_url"
                                                    class="btn btn--outline acms-cat-detail__cta-alt"
                                                    target="_blank"
                                                    rel="nofollow"
                                                >
                                                    <i class="bi bi-bag-fill"></i>
                                                    <span x-text="'View on ' + (link.provider_name || link.provider)"></span>
                                                    <template x-if="link.price">
                                                        <span class="acms-cat-detail__cta-price" x-text="formatPrice(link.price, link.currency || 'USD')"></span>
                                                    </template>
                                                </a>
                                            </template>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Detailed Review -->
                            <div class="acms-cat-detail__section" x-show="selectedProduct?.short_review">
                                <h3 class="acms-cat-detail__section-title">
                                    <i class="bi bi-chat-square-quote"></i>
                                    <?php esc_html_e('Detailed Review', 'affiliatecms-cat'); ?>
                                </h3>
                                <p class="acms-cat-detail__summary" x-text="selectedProduct?.short_review"></p>
                            </div>

                            <!-- Pros & Cons -->
                            <div class="acms-cat-detail__section acms-cat-detail__pros-cons" x-show="(selectedProduct?.pros && selectedProduct.pros.length > 0) || (selectedProduct?.cons && selectedProduct.cons.length > 0)">
                                <div class="acms-cat-detail__pros" x-show="selectedProduct?.pros && selectedProduct.pros.length > 0">
                                    <h4 class="acms-cat-detail__pros-title">
                                        <i class="bi bi-hand-thumbs-up-fill"></i>
                                        <?php esc_html_e('Pros', 'affiliatecms-cat'); ?>
                                    </h4>
                                    <ul class="acms-cat-detail__pros-list">
                                        <template x-for="(pro, idx) in (selectedProduct?.pros || [])" :key="idx">
                                            <li x-text="pro"></li>
                                        </template>
                                    </ul>
                                </div>
                                <div class="acms-cat-detail__cons" x-show="selectedProduct?.cons && selectedProduct.cons.length > 0">
                                    <h4 class="acms-cat-detail__cons-title">
                                        <i class="bi bi-hand-thumbs-down-fill"></i>
                                        <?php esc_html_e('Cons', 'affiliatecms-cat'); ?>
                                    </h4>
                                    <ul class="acms-cat-detail__cons-list">
                                        <template x-for="(con, idx) in (selectedProduct?.cons || [])" :key="idx">
                                            <li x-text="con"></li>
                                        </template>
                                    </ul>
                                </div>
                            </div>

                            <!-- Features -->
                            <div class="acms-cat-detail__section" x-show="selectedProduct?.features && selectedProduct.features.length > 0">
                                <h3 class="acms-cat-detail__section-title">
                                    <i class="bi bi-check2-circle"></i>
                                    <?php esc_html_e('Key Features', 'affiliatecms-cat'); ?>
                                </h3>
                                <ul class="acms-cat-detail__features">
                                    <template x-for="(feature, idx) in (selectedProduct?.features || []).slice(0, 5)" :key="idx">
                                        <li x-text="feature"></li>
                                    </template>
                                </ul>
                            </div>

                            <!-- User Reviews Section -->
                            <div
                                class="acms-cat-detail__section acms-cat-reviews"
                                x-data="productReviews()"
                                x-show="selectedProduct"
                                @product-changed.window="loadReviews($event.detail.asin)"
                            >
                                <div class="acms-cat-reviews__header">
                                    <h3 class="acms-cat-detail__section-title">
                                        <i class="bi bi-chat-square-text"></i>
                                        <?php esc_html_e('User Reviews', 'affiliatecms-cat'); ?>
                                        <span class="acms-cat-reviews__count" x-show="stats.review_count > 0" x-text="'(' + stats.review_count + ')'"></span>
                                    </h3>
                                    <button
                                        type="button"
                                        class="btn btn--sm btn--outline acms-cat-reviews__write-btn"
                                        @click="showForm = !showForm"
                                    >
                                        <i class="bi bi-pencil"></i>
                                        <?php esc_html_e('Write a Review', 'affiliatecms-cat'); ?>
                                    </button>
                                </div>

                                <!-- Review Stats Summary -->
                                <div class="acms-cat-reviews__stats" x-show="stats.review_count > 0">
                                    <div class="acms-cat-reviews__avg">
                                        <span class="acms-cat-reviews__avg-value" x-text="stats.avg_rating.toFixed(1)"></span>
                                        <div class="acms-cat-reviews__avg-stars">
                                            <template x-for="star in 5" :key="star">
                                                <i class="bi" :class="star <= Math.round(stats.avg_rating) ? 'bi-star-fill' : 'bi-star'"></i>
                                            </template>
                                        </div>
                                        <span class="acms-cat-reviews__avg-count" x-text="stats.review_count + ' reviews'"></span>
                                    </div>
                                    <div class="acms-cat-reviews__distribution">
                                        <template x-for="rating in [5, 4, 3, 2, 1]" :key="rating">
                                            <div class="acms-cat-reviews__bar">
                                                <span class="acms-cat-reviews__bar-label" x-text="rating + '★'"></span>
                                                <div class="acms-cat-reviews__bar-track">
                                                    <div class="acms-cat-reviews__bar-fill" :style="'width: ' + getDistributionPercent(rating) + '%'"></div>
                                                </div>
                                                <span class="acms-cat-reviews__bar-count" x-text="stats.distribution[rating] || 0"></span>
                                            </div>
                                        </template>
                                    </div>
                                </div>

                                <!-- Write Review Form (Simplified like theme comments) -->
                                <div class="acms-cat-reviews__form" x-show="showForm" x-transition x-cloak>
                                    <form @submit.prevent="submitReview()">
                                        <!-- Rating -->
                                        <div class="acms-cat-reviews__form-group">
                                            <label><?php esc_html_e('Your Rating', 'affiliatecms-cat'); ?> *</label>
                                            <div class="acms-cat-reviews__rating-input">
                                                <template x-for="star in 5" :key="star">
                                                    <button
                                                        type="button"
                                                        class="acms-cat-reviews__star-btn"
                                                        :class="{ 'active': star <= form.rating }"
                                                        @click="form.rating = star"
                                                        @mouseenter="hoverRating = star"
                                                        @mouseleave="hoverRating = 0"
                                                    >
                                                        <i class="bi" :class="star <= (hoverRating || form.rating) ? 'bi-star-fill' : 'bi-star'"></i>
                                                    </button>
                                                </template>
                                            </div>
                                        </div>

                                        <!-- User Info: Logged in vs Guest -->
                                        <?php if ($is_logged_in) : ?>
                                        <div class="acms-cat-reviews__user-info">
                                            <img src="<?php echo esc_url($user_avatar); ?>" alt="" class="acms-cat-reviews__user-avatar">
                                            <span class="acms-cat-reviews__user-name"><?php echo esc_html($user_display_name); ?></span>
                                            <a href="<?php echo esc_url(wp_logout_url(get_permalink())); ?>" class="acms-cat-reviews__logout"><?php esc_html_e('Log out', 'affiliatecms-cat'); ?></a>
                                        </div>
                                        <?php else : ?>
                                        <div class="acms-cat-reviews__form-row">
                                            <div class="acms-cat-reviews__form-group">
                                                <label for="review-name"><?php esc_html_e('Your Name', 'affiliatecms-cat'); ?> *</label>
                                                <input type="text" id="review-name" x-model="form.author_name" required minlength="2" maxlength="100">
                                            </div>
                                            <div class="acms-cat-reviews__form-group">
                                                <label for="review-email"><?php esc_html_e('Email', 'affiliatecms-cat'); ?></label>
                                                <input type="email" id="review-email" x-model="form.author_email">
                                            </div>
                                        </div>
                                        <?php endif; ?>

                                        <!-- Review Content -->
                                        <div class="acms-cat-reviews__form-group">
                                            <label for="review-content"><?php esc_html_e('Your Review', 'affiliatecms-cat'); ?> *</label>
                                            <textarea id="review-content" x-model="form.content" required minlength="20" maxlength="5000" rows="4" placeholder="<?php esc_attr_e('Share your experience with this product...', 'affiliatecms-cat'); ?>"></textarea>
                                        </div>

                                        <!-- Actions -->
                                        <div class="acms-cat-reviews__form-actions">
                                            <button type="button" class="btn btn--sm btn--ghost" @click="showForm = false"><?php esc_html_e('Cancel', 'affiliatecms-cat'); ?></button>
                                            <button type="submit" class="btn btn--sm btn--primary" :disabled="submitting">
                                                <span x-show="!submitting"><?php esc_html_e('Submit Review', 'affiliatecms-cat'); ?></span>
                                                <span x-show="submitting"><i class="bi bi-arrow-repeat spin"></i> <?php esc_html_e('Submitting...', 'affiliatecms-cat'); ?></span>
                                            </button>
                                        </div>
                                        <p class="acms-cat-reviews__form-note">
                                            <i class="bi bi-info-circle"></i>
                                            <?php esc_html_e('Your review will be visible after approval.', 'affiliatecms-cat'); ?>
                                        </p>
                                        <div class="acms-cat-reviews__form-message" x-show="message" x-text="message" :class="{ 'success': messageType === 'success', 'error': messageType === 'error' }"></div>
                                    </form>
                                </div>

                                <!-- Reviews List -->
                                <div class="acms-cat-reviews__list" x-show="reviews.length > 0">
                                    <template x-for="review in displayedReviews" :key="review.id">
                                        <div class="acms-cat-reviews__item">
                                            <div class="acms-cat-reviews__item-header">
                                                <div class="acms-cat-reviews__item-author">
                                                    <span class="acms-cat-reviews__item-name" x-text="review.author_name"></span>
                                                    <span class="acms-cat-reviews__item-verified" x-show="review.verified_purchase">
                                                        <i class="bi bi-patch-check-fill"></i>
                                                        <?php esc_html_e('Verified', 'affiliatecms-cat'); ?>
                                                    </span>
                                                </div>
                                                <div class="acms-cat-reviews__item-rating">
                                                    <template x-for="star in 5" :key="star">
                                                        <i class="bi" :class="star <= review.rating ? 'bi-star-fill' : 'bi-star'"></i>
                                                    </template>
                                                </div>
                                            </div>
                                            <h4 class="acms-cat-reviews__item-title" x-show="review.title" x-text="review.title"></h4>
                                            <p class="acms-cat-reviews__item-content" x-text="review.content"></p>
                                            <div class="acms-cat-reviews__item-pros-cons" x-show="(review.pros && review.pros.length) || (review.cons && review.cons.length)">
                                                <div class="acms-cat-reviews__item-pros" x-show="review.pros && review.pros.length">
                                                    <strong><i class="bi bi-hand-thumbs-up"></i> <?php esc_html_e('Pros:', 'affiliatecms-cat'); ?></strong>
                                                    <span x-text="review.pros.join(', ')"></span>
                                                </div>
                                                <div class="acms-cat-reviews__item-cons" x-show="review.cons && review.cons.length">
                                                    <strong><i class="bi bi-hand-thumbs-down"></i> <?php esc_html_e('Cons:', 'affiliatecms-cat'); ?></strong>
                                                    <span x-text="review.cons.join(', ')"></span>
                                                </div>
                                            </div>
                                            <div class="acms-cat-reviews__item-footer">
                                                <span class="acms-cat-reviews__item-date" x-text="formatReviewDate(review.created_at)"></span>
                                                <div class="acms-cat-reviews__item-helpful">
                                                    <span><?php esc_html_e('Helpful?', 'affiliatecms-cat'); ?></span>
                                                    <button type="button" @click="markHelpful(review.id, true)" :disabled="review.voted">
                                                        <i class="bi bi-hand-thumbs-up"></i>
                                                        <span x-text="review.helpful_count"></span>
                                                    </button>
                                                    <button type="button" @click="markHelpful(review.id, false)" :disabled="review.voted">
                                                        <i class="bi bi-hand-thumbs-down"></i>
                                                        <span x-text="review.unhelpful_count"></span>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </template>

                                    <!-- Load More -->
                                    <button
                                        type="button"
                                        class="btn btn--sm btn--outline acms-cat-reviews__load-more"
                                        x-show="reviews.length > displayLimit"
                                        @click="displayLimit += 3"
                                    >
                                        <i class="bi bi-arrow-down-circle"></i>
                                        <?php esc_html_e('Load more reviews', 'affiliatecms-cat'); ?>
                                        (<span x-text="reviews.length - displayLimit"></span> <?php esc_html_e('remaining', 'affiliatecms-cat'); ?>)
                                    </button>
                                </div>

                                <!-- Loading -->
                                <div class="acms-cat-reviews__loading" x-show="loading">
                                    <i class="bi bi-arrow-repeat spin"></i>
                                    <?php esc_html_e('Loading reviews...', 'affiliatecms-cat'); ?>
                                </div>
                            </div>

                        </div>
                    </div>
                    </div><!-- /.acms-cat-detail-modal -->

                    <!-- SSR Product Details (hidden, SEO-only — crawlable HTML for 10 products) -->
                    <?php if (!empty($ssr_details)) : ?>
                    <div class="acms-sr-only">
                        <?php foreach ($ssr_details as $idx => $detail) :
                            $sp = $detail['p'];
                            $sp_price = (float) ($sp->price ?? 0);
                            $sp_currency = $sp->currency ?? 'USD';
                            $sp_rating = (float) ($sp->rating ?? 0);
                            $sp_buy_url = 'https://www.amazon.com/dp/' . $sp->asin . '?tag=' . urlencode($affiliate_tag) . ($custom_url_params ? '&' . $custom_url_params : '');
                        ?>
                        <div itemscope itemtype="https://schema.org/Product">
                            <span itemprop="name"><?php echo esc_html($detail['title']); ?></span>
                            <?php if (!empty($sp->brand)) : ?>
                            <span itemprop="brand" itemscope itemtype="https://schema.org/Brand">
                                <meta itemprop="name" content="<?php echo esc_attr($sp->brand); ?>">
                            </span>
                            <?php endif; ?>
                            <?php if ($detail['short_review']) : ?>
                            <p itemprop="description"><?php echo esc_html($detail['short_review']); ?></p>
                            <?php endif; ?>
                            <?php if (!empty($detail['features'])) : ?>
                            <ul><?php foreach ($detail['features'] as $f) : ?><li><?php echo esc_html($f); ?></li><?php endforeach; ?></ul>
                            <?php endif; ?>
                            <?php if (!empty($detail['pros'])) : ?>
                            <p><?php foreach ($detail['pros'] as $pro) : ?><?php echo esc_html($pro); ?>. <?php endforeach; ?></p>
                            <?php endif; ?>
                            <?php if (!empty($detail['cons'])) : ?>
                            <p><?php foreach ($detail['cons'] as $con) : ?><?php echo esc_html($con); ?>. <?php endforeach; ?></p>
                            <?php endif; ?>
                            <span itemprop="offers" itemscope itemtype="https://schema.org/Offer">
                                <meta itemprop="priceCurrency" content="<?php echo esc_attr($sp_currency); ?>">
                                <meta itemprop="price" content="<?php echo esc_attr($sp_price); ?>">
                                <meta itemprop="availability" content="<?php echo ($sp->in_stock ?? true) ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock'; ?>">
                                <a href="<?php echo esc_url($sp_buy_url); ?>" itemprop="url" rel="nofollow"><?php echo esc_html($detail['title']); ?></a>
                            </span>
                            <?php /* Amazon rating Schema.org removed — violates policy
                            if ($sp_rating > 0) : ?>
                            <span itemprop="aggregateRating" itemscope itemtype="https://schema.org/AggregateRating">
                                <meta itemprop="ratingValue" content="<?php echo esc_attr($sp_rating); ?>">
                                <meta itemprop="bestRating" content="5">
                                <meta itemprop="reviewCount" content="<?php echo (int) ($sp->reviews_count ?? 1); ?>">
                            </span>
                            <?php endif;
                            */ ?>
                            <meta itemprop="image" content="<?php echo esc_url($sp->image_url ?? ''); ?>">
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>

                    <!-- Category Content (AI-generated) - Inside Main Column -->
                    <?php if (!empty($category['content_main'])) : ?>
                    <div class="acms-cat-ai-content" x-data="{ contentExpanded: false }">
                        <div class="acms-cat-ai-content__wrapper" :class="{ 'is-expanded': contentExpanded }">
                            <div class="acms-cat-ai-content__body prose">
                                <?php
                                $content_html = wp_kses_post($replacePlaceholders($category['content_main']));
                                echo function_exists('acms_wrap_external_links')
                                    ? acms_wrap_external_links($content_html)
                                    : $content_html;
                                ?>
                            </div>
                            <!-- Gradient Fade Overlay (visible when collapsed) -->
                            <div class="acms-cat-ai-content__fade" x-show="!contentExpanded"></div>
                        </div>
                        <!-- Read More / Show Less Button -->
                        <button
                            type="button"
                            class="acms-cat-ai-content__toggle"
                            @click="contentExpanded = !contentExpanded"
                        >
                            <span x-text="contentExpanded ? '<?php echo esc_js(__('Show less', 'affiliatecms-cat')); ?>' : '<?php echo esc_js(__('Read more', 'affiliatecms-cat')); ?>'"></span>
                            <i class="bi" :class="contentExpanded ? 'bi-chevron-up' : 'bi-chevron-down'"></i>
                        </button>
                    </div>
                    <?php endif; ?>

                    <!-- FAQ is rendered inside content_main (parsed for FAQPage schema in JSON-LD) -->

                    <!-- Related Categories (sibling categories with same parent) -->
                    <?php if (!empty($sibling_categories)) : ?>
                    <div class="acms-cat-keywords">
                        <span class="acms-cat-keywords__label">
                            <i class="bi bi-grid"></i>
                            <?php esc_html_e('Related Categories', 'affiliatecms-cat'); ?>
                        </span>
                        <div class="acms-cat-keywords__tags">
                            <?php foreach ($sibling_categories as $sib) : ?>
                            <a href="<?php echo esc_url(home_url('/c/' . $sib['slug'] . '/')); ?>" class="acms-cat-keywords__tag">
                                <?php echo esc_html($sib['name']); ?>
                                <?php if (!empty($sib['product_count'])) : ?>
                                <span class="acms-cat-keywords__count"><?php echo (int) $sib['product_count']; ?></span>
                                <?php endif; ?>
                            </a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>

                </div>

            </div>
        </div>
    </section>

    <!-- SSR Product Details (crawlable by search engines, hidden from visual users) -->
    <?php if (!empty($ssr_details)) : ?>
    <section class="acms-cat-ssr-products" aria-hidden="true" style="position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0;">
        <h2><?php printf(esc_html__('Product Reviews: %s', 'affiliatecms-cat'), esc_html($category['name'])); ?></h2>
        <?php foreach ($ssr_details as $d) :
            $p = $d['p'];
            $brand = $p->brand ?? '';
        ?>
        <article>
            <h3><?php echo esc_html($d['title']); ?></h3>
            <?php if (!empty($brand)) : ?>
            <p>Brand: <a href="<?php echo esc_url(home_url('/brand/' . sanitize_title($brand) . '/')); ?>"><?php echo esc_html($brand); ?></a></p>
            <?php endif; ?>
            <?php if (!empty($d['short_review'])) : ?>
            <p><?php echo esc_html($d['short_review']); ?></p>
            <?php endif; ?>
            <?php if (!empty($d['features'])) : ?>
            <h4>Key Features</h4>
            <ul>
                <?php foreach ($d['features'] as $f) : ?>
                <li><?php echo esc_html($f); ?></li>
                <?php endforeach; ?>
            </ul>
            <?php endif; ?>
            <?php if (!empty($d['pros'])) : ?>
            <h4>Pros</h4>
            <ul>
                <?php foreach ($d['pros'] as $pro) : ?>
                <li><?php echo esc_html($pro); ?></li>
                <?php endforeach; ?>
            </ul>
            <?php endif; ?>
            <?php if (!empty($d['cons'])) : ?>
            <h4>Cons</h4>
            <ul>
                <?php foreach ($d['cons'] as $con) : ?>
                <li><?php echo esc_html($con); ?></li>
                <?php endforeach; ?>
            </ul>
            <?php endif; ?>
        </article>
        <?php endforeach; ?>
    </section>
    <?php endif; ?>

</main>

<?php
// ========================================
// JSON-LD Structured Data (SEO)
// ========================================
$site_name = get_bloginfo('name');
$site_url = home_url('/');
$category_url = home_url('/c/' . $category['slug'] . '/');
$category_image = $category['featured_image_id']
    ? wp_get_attachment_url($category['featured_image_id'])
    : get_template_directory_uri() . '/assets/images/placeholder.svg';

// BreadcrumbList Schema
$breadcrumb_items = [
    [
        '@type' => 'ListItem',
        'position' => 1,
        'name' => __('Home', 'affiliatecms-cat'),
        'item' => $site_url,
    ]
];
$position = 2;
foreach ($breadcrumbs as $crumb) {
    $breadcrumb_items[] = [
        '@type' => 'ListItem',
        'position' => $position++,
        'name' => $crumb['name'],
        'item' => home_url('/c/' . $crumb['slug'] . '/'),
    ];
}
$breadcrumb_items[] = [
    '@type' => 'ListItem',
    'position' => $position,
    'name' => $category['name'],
    'item' => $category_url,
];

// ItemList Schema (Product listing)
$item_list_elements = [];
foreach ($products as $idx => $p) {
    $title = !empty($p->custom_title) ? $p->custom_title : $p->title;
    $price = (float) ($p->price ?? 0);
    $currency = $p->currency ?? 'USD';
    $rating = (float) ($p->rating ?? 0);
    $reviews_count = (int) ($p->reviews_count ?? 0);
    $image = acms_resize_amazon_image($p->image_url ?? '', 400); // Larger for schema/SEO
    $brand = $p->brand ?? '';
    $in_stock = (bool) ($p->in_stock ?? true);
    $product_url = 'https://www.amazon.com/dp/' . $p->asin . '?tag=' . urlencode($affiliate_tag) . ($custom_url_params ? '&' . $custom_url_params : '');

    $product_schema = [
        '@type' => 'Product',
        'position' => $idx + 1,
        'name' => $title,
        'url' => $category_url . '#' . $p->asin,
        'offers' => [
            '@type' => 'Offer',
            'price' => $price,
            'priceCurrency' => $currency,
            'availability' => $in_stock ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock',
            'url' => $product_url,
        ],
    ];

    if ($image) {
        $product_schema['image'] = $image;
    }
    if ($brand) {
        $product_schema['brand'] = [
            '@type' => 'Brand',
            'name' => $brand,
        ];
    }
    /* Amazon rating Schema.org removed — violates policy
    if ($rating > 0 && $reviews_count > 0) {
        $product_schema['aggregateRating'] = [
            '@type' => 'AggregateRating',
            'ratingValue' => $rating,
            'bestRating' => 5,
            'reviewCount' => $reviews_count,
        ];
    }
    */

    // Add description snippet for SEO (use short_review as concise product summary)
    if (!empty($p->ai_short_review)) {
        $product_schema['description'] = wp_strip_all_tags($p->ai_short_review);
    } elseif (!empty($p->description)) {
        $product_schema['description'] = wp_trim_words(wp_strip_all_tags($p->description), 30);
    }

    $item_list_elements[] = [
        '@type' => 'ListItem',
        'position' => $idx + 1,
        'item' => $product_schema,
    ];
}

// Combined JSON-LD
$json_ld = [
    '@context' => 'https://schema.org',
    '@graph' => [
        // BreadcrumbList
        [
            '@type' => 'BreadcrumbList',
            'itemListElement' => $breadcrumb_items,
        ],
        // CollectionPage (Category)
        [
            '@type' => 'CollectionPage',
            'name' => $page_title,
            'description' => $page_description,
            'url' => $category_url,
            'image' => $category_image,
            'isPartOf' => [
                '@type' => 'WebSite',
                'name' => $site_name,
                'url' => $site_url,
            ],
            'mainEntity' => [
                '@type' => 'ItemList',
                'name' => sprintf(__('Best %s', 'affiliatecms-cat'), $category['name']),
                'numberOfItems' => count($products),
                'itemListElement' => $item_list_elements,
            ],
        ],
    ],
];

// Add FAQPage schema if FAQ exists
if (!empty($faq_items)) {
    $faq_schema_items = [];
    foreach ($faq_items as $faq) {
        if (!empty($faq['question']) && !empty($faq['answer'])) {
            $faq_schema_items[] = [
                '@type' => 'Question',
                'name' => $faq['question'],
                'acceptedAnswer' => [
                    '@type' => 'Answer',
                    'text' => wp_strip_all_tags($faq['answer']),
                ],
            ];
        }
    }
    if (!empty($faq_schema_items)) {
        $json_ld['@graph'][] = [
            '@type' => 'FAQPage',
            'mainEntity' => $faq_schema_items,
        ];
    }
}
?>
<script type="application/ld+json">
<?php echo wp_json_encode($json_ld, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>
</script>

<!-- ACMS Category Page JS -->
<script data-no-optimize="1">
document.addEventListener('alpine:init', () => {
    Alpine.data('acmsCategoryPage', (config) => ({
        products: config.products || [],
        selectedProduct: null,
        detailModalOpen: false,
        categoryId: config.categoryId,
        filters: config.filters || { priceMin: 0, priceMax: 1000, ratings: {} },

        // Sort state
        sortBy: 'newest',
        sortLabels: {
            newest: '<?php echo esc_js(__('Newest', 'affiliatecms-cat')); ?>',
            price_asc: '<?php echo esc_js(__('Price: Low → High', 'affiliatecms-cat')); ?>',
            price_desc: '<?php echo esc_js(__('Price: High → Low', 'affiliatecms-cat')); ?>',
            rating: '<?php echo esc_js(__('Top Rated', 'affiliatecms-cat')); ?>',
            reviews: '<?php echo esc_js(__('Most Reviews', 'affiliatecms-cat')); ?>'
        },
        sortIcons: {
            newest: 'bi-clock-history',
            price_asc: 'bi-sort-numeric-up',
            price_desc: 'bi-sort-numeric-down',
            rating: 'bi-star-fill',
            reviews: 'bi-chat-square-text'
        },

        // Active filter state
        activeFilters: {
            priceMin: null,
            priceMax: null,
            minRating: 0
        },

        // Dropdown open states
        catOpen: false,
        brandOpen: false,
        ratingOpen: false,
        sortOpen: false,

        // Category tree navigation state
        // Load More state
        totalProducts: config.totalProducts || 0,
        perPage: config.perPage || 50,
        loadingMore: false,

        catSearch: '',
        catTree: config.catTree || [],
        currentCatId: config.currentCatId || '',
        currentCatName: config.currentCatName || 'Category',
        catExpanded: config.catExpanded || [],
        isBrandCategory: config.isBrandCategory || false,
        brandName: config.brandName || '',

        // Display settings from Settings > Display > Visible Elements
        display: config.display || { showPrice: true, showRating: true, showPrime: true, showStock: true, showUpdate: true },
        brandCategoryNav: config.brandCategoryNav || [],

        init() {
            const isMobile = window.innerWidth < 1024;

            // JS-powered sticky filter bar on mobile (CSS sticky unreliable)
            if (isMobile) {
                const fbar = this.$root.querySelector('.acms-fbar');
                if (fbar) {
                    const sentinel = document.createElement('div');
                    sentinel.className = 'acms-fbar-sentinel';
                    fbar.parentNode.insertBefore(sentinel, fbar);

                    const spacer = document.createElement('div');
                    spacer.style.display = 'none';
                    fbar.parentNode.insertBefore(spacer, fbar.nextSibling);

                    const headerH = window.innerWidth >= 768 ? 57 : 53;
                    const observer = new IntersectionObserver(([e]) => {
                        const stuck = !e.isIntersecting;
                        fbar.classList.toggle('is-stuck', stuck);
                        spacer.style.display = stuck ? 'block' : 'none';
                        spacer.style.height = stuck ? fbar.offsetHeight + 'px' : '0';
                    }, { rootMargin: `-${headerH}px 0px 0px 0px` });
                    observer.observe(sentinel);
                }
            }

            // Auto-select first product (desktop only; mobile waits for user click)
            if (this.filteredProducts.length > 0 && !isMobile) {
                this.selectedProduct = this.filteredProducts[0];
                this.$nextTick(() => {
                    this.$dispatch('product-changed', {
                        asin: this.selectedProduct.asin,
                        productId: this.selectedProduct.id
                    });
                });
            }

            // Handle URL hash for deep linking
            if (window.location.hash) {
                const asin = window.location.hash.replace('#', '');
                const product = this.products.find(p => p.asin === asin);
                if (product) {
                    // Call selectProduct() to trigger API fetch and detail load
                    this.selectProduct(product);
                    // On mobile with hash: auto-open the detail modal
                    if (isMobile) {
                        this.detailModalOpen = true;
                        this._lockBody();
                        window.history.pushState({ acmsModal: true }, '');
                    }
                }
            }

            // Listen for back button / swipe-back to close modal
            window.addEventListener('popstate', () => {
                if (this.detailModalOpen) {
                    this.closeDetailModal(true);
                }
            });

            // Watch for filter changes to update selection
            this.$watch('filteredProducts', (products) => {
                const selId = this.selectedProduct?.id;
                const stillVisible = selId && products.some(p => p.id === selId);
                if (products.length > 0 && !stillVisible) {
                    // Selected product filtered out — pick first visible
                    if (window.innerWidth >= 1024) {
                        this.selectProduct(products[0]);
                    } else {
                        this.selectedProduct = null;
                        this.closeDetailModal();
                    }
                } else if (products.length === 0) {
                    this.selectedProduct = null;
                    if (this.detailModalOpen) this.closeDetailModal();
                }
            });

            // Watch sort changes: auto-select first product in new order
            this.$watch('sortBy', () => {
                if (this.filteredProducts.length > 0 && window.innerWidth >= 1024) {
                    this.selectProduct(this.filteredProducts[0]);
                }
            });

            // Auto-scroll to current category when dropdown opens
            this.$watch('catOpen', (open) => {
                if (!open) return;
                this.$nextTick(() => {
                    const scroll = this.$root.querySelector('.acms-fbar__col--cat .acms-fbar__scroll');
                    const current = scroll?.querySelector('.acms-fbar__tree-row.is-current');
                    if (scroll && current) {
                        const top = current.offsetTop - scroll.offsetTop - 60;
                        scroll.scrollTo({ top: Math.max(0, top), behavior: 'smooth' });
                    }
                });
            });
        },

        // Computed: filtered + sorted products
        get filteredProducts() {
            let results = this.products.filter(p => {
                // Price filter
                const minPrice = this.activeFilters.priceMin ?? 0;
                const maxPrice = this.activeFilters.priceMax ?? Infinity;
                if (p.price < minPrice || p.price > maxPrice) return false;

                // Rating filter
                if (this.activeFilters.minRating > 0) {
                    if (!p.rating || p.rating < this.activeFilters.minRating) return false;
                }

                return true;
            });

            // Sort
            const sort = this.sortBy;
            if (sort === 'price_asc') {
                results.sort((a, b) => (a.price || 0) - (b.price || 0));
            } else if (sort === 'price_desc') {
                results.sort((a, b) => (b.price || 0) - (a.price || 0));
            } else if (sort === 'rating') {
                results.sort((a, b) => (b.rating || 0) - (a.rating || 0));
            } else if (sort === 'reviews') {
                results.sort((a, b) => (b.reviews_count || 0) - (a.reviews_count || 0));
            }

            return results;
        },

        // Body scroll lock helpers (iOS-safe)
        _scrollY: 0,
        _lockBody() {
            this._scrollY = window.scrollY;
            document.body.style.position = 'fixed';
            document.body.style.top = `-${this._scrollY}px`;
            document.body.style.left = '0';
            document.body.style.right = '0';
        },
        _unlockBody() {
            document.body.style.position = '';
            document.body.style.top = '';
            document.body.style.left = '';
            document.body.style.right = '';
            window.scrollTo(0, this._scrollY);
        },

        async selectProduct(product) {
            this.selectedProduct = product;

            // Update URL hash for deep linking
            window.history.replaceState(null, '', '#' + product.asin);

            // Dispatch event for child components (reviews, etc.)
            this.$dispatch('product-changed', { asin: product.asin, productId: product.id });

            if (window.innerWidth < 1024) {
                // Mobile: open fullscreen modal
                this.detailModalOpen = true;
                this._lockBody();
                // Push history state so back button/swipe closes modal
                window.history.pushState({ acmsModal: true }, '');
            } else {
                // Desktop: scroll detail into view (anchor-like)
                this.$nextTick(() => {
                    document.querySelector('.acms-cat-detail')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
                });
            }

            // Lazy-load detail fields (features, pros, cons, short_review) via REST API
            if (!product._detailLoaded) {
                try {
                    const res = await fetch('/wp-json/acms-cat/v1/product-detail/' + product.id);
                    if (res.ok) {
                        const detail = await res.json();
                        // Merge detail into product (keeps cache for future clicks)
                        product.features = detail.features || [];
                        product.pros = detail.pros || [];
                        product.cons = detail.cons || [];
                        product.short_review = detail.short_review || '';
                        product.affiliate_links = detail.affiliate_links || [];
                        product._detailLoaded = true;
                        // Force Alpine reactivity: replace selectedProduct with new reference
                        this.selectedProduct = Object.assign({}, product);
                    }
                } catch (e) { /* fail silently, detail panel shows empty sections */ }
            }
        },

        closeDetailModal(fromPopstate = false) {
            if (!this.detailModalOpen) return;
            this.detailModalOpen = false;
            this._unlockBody();
            // If closed programmatically (not from back button), pop the history entry
            if (!fromPopstate) {
                window.history.back();
            }
        },

        // SSR helpers for progressive enhancement
        selectProductById(id) {
            const product = this.products.find(p => p.id === id);
            if (product) {
                this.selectProduct(product);
            }
        },

        isProductVisible(id) {
            return this.filteredProducts.some(p => p.id === id);
        },

        getProductSortOrder(id) {
            const idx = this.filteredProducts.findIndex(p => p.id === id);
            return idx >= 0 ? idx : 9999;
        },

        // Filter helpers
        hasActiveFilters() {
            return this.activeFilters.priceMin !== null ||
                   this.activeFilters.priceMax !== null ||
                   this.activeFilters.minRating > 0;
        },

        clearAllFilters() {
            this.activeFilters.priceMin = null;
            this.activeFilters.priceMax = null;
            this.activeFilters.minRating = 0;
        },

        // Category tree navigation helpers
        navigateToCat(node) {
            window.location.href = '<?php echo esc_url(home_url('/c/')); ?>' + node.slug + '/';
        },

        catLoading: [],

        toggleCatExpand(id) {
            const i = this.catExpanded.indexOf(id);
            // Collapsing — always instant
            if (i >= 0) {
                this.catExpanded.splice(i, 1);
                return;
            }

            // Find node in tree
            const node = this.findInTree(this.catTree, id);
            if (!node) return;

            // Children already loaded — just expand
            if (node.children.length > 0) {
                this.catExpanded.push(id);
                return;
            }

            // Has children in DB but not loaded yet — lazy fetch
            if (node.child_count > 0 && !this.catLoading.includes(id)) {
                this.catLoading.push(id);
                fetch('/wp-json/acms-cat/v1/categories/' + id + '/children?exclude_brands=1&fields=nav')
                    .then(r => r.json())
                    .then(res => {
                        const children = res.data || res;
                        if (children.length) {
                            node.children = children.map(c => ({
                                id: String(c.id),
                                name: c.name,
                                slug: c.slug,
                                product_count: parseInt(c.product_count) || 0,
                                child_count: parseInt(c.child_count) || 0,
                                children: [],
                            }));
                        }
                        this.catExpanded.push(id);
                        this.catLoading = this.catLoading.filter(x => x !== id);
                    })
                    .catch(() => {
                        this.catLoading = this.catLoading.filter(x => x !== id);
                    });
                return;
            }

            // Leaf node (no children) — do nothing
        },

        catMatchesSearch(node) {
            if (!this.catSearch) return true;
            const q = this.catSearch.toLowerCase();
            if (node.name.toLowerCase().includes(q)) return true;
            return node.children.some(c => this.catMatchesSearch(c));
        },

        findInTree(nodes, id) {
            for (const n of nodes) {
                if (String(n.id) === String(id)) return n;
                if (n.children.length) {
                    const f = this.findInTree(n.children, id);
                    if (f) return f;
                }
            }
            return null;
        },

        formatPrice(price, currency = 'USD') {
            if (!price) return '';
            const formatter = new Intl.NumberFormat('en-US', {
                style: 'currency',
                currency: currency,
                minimumFractionDigits: 2
            });
            return formatter.format(price);
        },

        formatNumber(num) {
            if (!num) return '0';
            return new Intl.NumberFormat('en-US').format(num);
        },

        formatDate(dateStr) {
            if (!dateStr) return '';
            const date = new Date(dateStr);
            return date.toLocaleDateString('en-US', {
                month: 'short',
                day: 'numeric',
                year: 'numeric'
            });
        },

        getProductRank(product) {
            if (!product) return '';
            const index = this.filteredProducts.findIndex(p => p.id === product.id);
            return index >= 0 ? index + 1 : '';
        },

        get hasMore() {
            return this.products.length < this.totalProducts;
        },

        async loadMore() {
            if (this.loadingMore || !this.hasMore) return;
            this.loadingMore = true;
            try {
                const res = await fetch('/wp-json/acms-cat/v1/categories/' + this.categoryId + '/products-page?limit=' + this.perPage + '&offset=' + this.products.length);
                if (res.ok) {
                    const data = await res.json();
                    if (data.data && data.data.length > 0) {
                        this.products.push(...data.data);
                        this.totalProducts = data.total;
                    }
                }
            } catch (e) { /* fail silently */ }
            this.loadingMore = false;
        }
    }));

    // Product Reviews Component (Simplified like theme comments)
    Alpine.data('productReviews', () => ({
        reviews: [],
        displayLimit: 3,
        stats: { review_count: 0, avg_rating: 0, distribution: { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 } },
        loading: false,
        showForm: false,
        submitting: false,
        message: '',
        messageType: '',
        hoverRating: 0,
        currentAsin: null,
        isLoggedIn: <?php echo $is_logged_in ? 'true' : 'false'; ?>,
        form: {
            rating: 5,
            author_name: '<?php echo esc_js($user_display_name); ?>',
            author_email: '<?php echo esc_js($user_email); ?>',
            content: ''
        },

        init() {
            // Load reviews for initially selected product (if any)
            const parentData = Alpine.$data(this.$root);
            if (parentData && parentData.selectedProduct) {
                this.loadReviews(parentData.selectedProduct.asin, parentData.selectedProduct.id);
            }

            // Watch for product changes in parent component
            this.$watch('$root.selectedProduct', (product) => {
                if (product && product.asin !== this.currentAsin) {
                    this.loadReviews(product.asin, product.id);
                }
            });
        },

        get displayedReviews() {
            return this.reviews.slice(0, this.displayLimit);
        },

        async loadReviews(asin, productId) {
            if (!asin) return;

            this.currentAsin = asin;
            this.loading = true;
            this.reviews = [];
            this.displayLimit = 3;

            try {
                const response = await fetch(`<?php echo esc_url(rest_url('acms-cat/v1/reviews/asin/')); ?>${asin}`);
                if (response.ok) {
                    const data = await response.json();
                    this.reviews = (data.reviews || []).map(r => ({ ...r, voted: false }));
                    this.stats = data.stats || this.stats;
                }
            } catch (error) {
                console.error('Failed to load reviews:', error);
            } finally {
                this.loading = false;
            }
        },

        async submitReview() {
            if (this.submitting) return;

            const parentData = Alpine.$data(this.$root);
            if (!parentData.selectedProduct) return;

            this.submitting = true;
            this.message = '';

            try {
                const response = await fetch('<?php echo esc_url(rest_url('acms-cat/v1/reviews')); ?>', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': '<?php echo wp_create_nonce('wp_rest'); ?>'
                    },
                    body: JSON.stringify({
                        product_id: parentData.selectedProduct.id,
                        asin: parentData.selectedProduct.asin,
                        ...this.form
                    })
                });

                const data = await response.json();

                if (response.ok) {
                    this.message = data.message || '<?php echo esc_js(__('Review submitted successfully!', 'affiliatecms-cat')); ?>';
                    this.messageType = 'success';
                    this.resetForm();
                    setTimeout(() => { this.showForm = false; }, 2000);
                } else {
                    this.message = data.message || '<?php echo esc_js(__('Failed to submit review.', 'affiliatecms-cat')); ?>';
                    this.messageType = 'error';
                }
            } catch (error) {
                this.message = '<?php echo esc_js(__('An error occurred. Please try again.', 'affiliatecms-cat')); ?>';
                this.messageType = 'error';
            } finally {
                this.submitting = false;
            }
        },

        resetForm() {
            this.form = {
                rating: 5,
                author_name: this.isLoggedIn ? '<?php echo esc_js($user_display_name); ?>' : '',
                author_email: this.isLoggedIn ? '<?php echo esc_js($user_email); ?>' : '',
                content: ''
            };
            this.hoverRating = 0;
        },

        async markHelpful(reviewId, helpful) {
            const review = this.reviews.find(r => r.id === reviewId);
            if (!review || review.voted) return;

            try {
                const response = await fetch(`<?php echo esc_url(rest_url('acms-cat/v1/reviews/')); ?>${reviewId}/helpful`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ helpful })
                });

                if (response.ok) {
                    review.voted = true;
                    if (helpful) {
                        review.helpful_count = (review.helpful_count || 0) + 1;
                    } else {
                        review.unhelpful_count = (review.unhelpful_count || 0) + 1;
                    }
                } else {
                    const data = await response.json().catch(() => ({}));
                    if (data.code === 'already_voted') {
                        review.voted = true;
                    }
                }
            } catch (error) {
                console.error('Failed to mark helpful:', error);
            }
        },

        getDistributionPercent(rating) {
            if (this.stats.review_count === 0) return 0;
            return ((this.stats.distribution[rating] || 0) / this.stats.review_count * 100).toFixed(0);
        },

        formatReviewDate(dateStr) {
            if (!dateStr) return '';
            const date = new Date(dateStr);
            return date.toLocaleDateString('en-US', {
                month: 'short',
                day: 'numeric',
                year: 'numeric'
            });
        }
    }));
});
</script>

<!-- Category Tree Expand/Collapse -->
<script data-no-optimize="1">
(function() {
    function toggleNode(btn) {
        var item = btn.closest('.acms-cat-tree__item');
        var expanded = item.classList.toggle('is-expanded');
        btn.setAttribute('aria-expanded', expanded ? 'true' : 'false');
        var icon = btn.querySelector('i');
        if (icon) {
            icon.className = expanded ? 'bi bi-chevron-down' : 'bi bi-chevron-right';
        }
    }

    function buildChildrenHtml(children) {
        if (!children || !children.length) return '';
        var html = '<ul class="acms-cat-tree__list">';
        children.forEach(function(c) {
            var hasChildren = (parseInt(c.child_count) || 0) > 0;
            var count = parseInt(c.product_count) || 0;
            html += '<li class="acms-cat-tree__item">';
            html += '<div class="acms-cat-tree__row">';
            if (hasChildren) {
                html += '<button type="button" class="acms-cat-tree__toggle" data-cat-id="' + c.id + '" aria-expanded="false"><i class="bi bi-chevron-right"></i></button>';
            } else {
                html += '<span class="acms-cat-tree__dot"></span>';
            }
            html += '<a href="/c/' + c.slug + '/" class="acms-cat-tree__link">';
            html += '<span class="acms-cat-tree__name">' + c.name + '</span>';
            if (count > 0) {
                html += '<span class="acms-cat-tree__count">' + count + '</span>';
            }
            html += '</a></div></li>';
        });
        html += '</ul>';
        return html;
    }

    document.querySelector('.acms-cat-tree__nav')?.addEventListener('click', function(e) {
        var btn = e.target.closest('.acms-cat-tree__toggle');
        if (!btn) return;
        e.preventDefault();

        var item = btn.closest('.acms-cat-tree__item');
        var childList = item.querySelector(':scope > .acms-cat-tree__list');

        // Children already in DOM — just toggle
        if (childList) {
            toggleNode(btn);
            return;
        }

        // Fetch children via API
        var catId = btn.dataset.catId;
        if (!catId || btn.classList.contains('is-loading')) return;

        btn.classList.add('is-loading');
        var icon = btn.querySelector('i');
        if (icon) icon.className = 'bi bi-arrow-repeat acms-cat-tree__spin';

        fetch('/wp-json/acms-cat/v1/categories/' + catId + '/children?exclude_brands=1')
            .then(function(r) { return r.json(); })
            .then(function(res) {
                btn.classList.remove('is-loading');
                var children = res.data || res;
                if (children.length) {
                    item.insertAdjacentHTML('beforeend', buildChildrenHtml(children));
                } else {
                    // No children — replace toggle with dot
                    btn.outerHTML = '<span class="acms-cat-tree__dot"></span>';
                    return;
                }
                toggleNode(btn);
            })
            .catch(function() {
                btn.classList.remove('is-loading');
                if (icon) icon.className = 'bi bi-chevron-right';
            });
    });
})();
</script>

<?php
// Theme footer
get_footer();
?>
