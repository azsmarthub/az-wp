<?php
/**
 * Plugin Name: AffiliateCMS Categories
 * Plugin URI: https://affiliatecms.com
 * Description: High-performance SEO category system with Materialized Path hierarchy
 * Version: 1.0.1
 * Author: AffiliateCMS
 * Author URI: https://affiliatecms.com
 * Text Domain: affiliatecms-cat
 * Domain Path: /languages
 * Requires at least: 6.0
 * Requires PHP: 8.2
 *
 * @package AffiliateCMS\Categories
 */

declare(strict_types=1);

namespace AffiliateCMS\Categories;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Plugin constants
defined('ACMS_CAT_VERSION') || define('ACMS_CAT_VERSION', '1.0.1');
defined('ACMS_CAT_FILE') || define('ACMS_CAT_FILE', __FILE__);
defined('ACMS_CAT_PATH') || define('ACMS_CAT_PATH', plugin_dir_path(__FILE__));
defined('ACMS_CAT_URL') || define('ACMS_CAT_URL', plugin_dir_url(__FILE__));

// Autoloader
spl_autoload_register(function (string $class): void {
    $prefix = 'AffiliateCMS\\Categories\\';
    $base_dir = ACMS_CAT_PATH . 'src/';

    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }

    $relative_class = substr($class, $len);
    $file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';

    if (file_exists($file)) {
        require $file;
    }
});

// Initialize plugin
add_action('plugins_loaded', function (): void {
    // Check dependencies
    if (!class_exists('AffiliateCMS\\Pro\\Core\\Bootstrap')) {
        add_action('admin_notices', function (): void {
            echo '<div class="notice notice-error"><p>';
            echo esc_html__('AffiliateCMS Categories requires AffiliateCMS Pro plugin to be active.', 'affiliatecms-cat');
            echo '</p></div>';
        });
        return;
    }

    // Auto-upgrade database schema if needed
    $current_version = get_option(Database\Schema::OPTION_KEY, '0.0.0');
    if (version_compare($current_version, Database\Schema::VERSION, '<')) {
        Database\Schema::install();
    }

    // Boot the plugin
    Core\Bootstrap::init();
}, 20);

// Activation hook
register_activation_hook(__FILE__, function (): void {
    $bufferLevel = ob_get_level();
    ob_start();
    try {
        @ini_set('display_errors', '0');
        require_once ACMS_CAT_PATH . 'src/Database/Schema.php';
        Database\Schema::install();
    } finally {
        while (ob_get_level() > $bufferLevel) {
            ob_end_clean();
        }
    }
});

// Deactivation hook
register_deactivation_hook(__FILE__, function (): void {
    // Clean up scheduled events if any
    wp_clear_scheduled_hook('acms_cat_daily_maintenance');
});
