/**
 * AffiliateCMS Categories - Admin JavaScript
 * Alpine.js components for Category Manager
 */

(function() {
    'use strict';

    // ===========================================
    // API CLIENT
    // ===========================================

    const api = {
        baseUrl: window.acmsCatConfig?.restUrl || '/wp-json/acms-cat/v1/',
        nonce: window.acmsCatConfig?.nonce || '',

        async request(method, endpoint, data = null) {
            const options = {
                method,
                headers: {
                    'X-WP-Nonce': this.nonce,
                    'Content-Type': 'application/json',
                },
            };

            if (data && ['POST', 'PUT', 'PATCH'].includes(method)) {
                options.body = JSON.stringify(data);
            }

            const url = new URL(this.baseUrl + endpoint, window.location.origin);

            if (data && method === 'GET') {
                Object.keys(data).forEach(key => {
                    if (data[key] !== null && data[key] !== undefined) {
                        url.searchParams.append(key, data[key]);
                    }
                });
            }

            const response = await fetch(url, options);

            const result = {
                data: await response.json(),
                headers: {
                    total: parseInt(response.headers.get('X-WP-Total') || '0'),
                    totalPages: parseInt(response.headers.get('X-WP-TotalPages') || '1'),
                },
                ok: response.ok,
            };

            if (!response.ok) {
                throw new Error(result.data?.message || 'Request failed');
            }

            return result;
        },

        get(endpoint, params) { return this.request('GET', endpoint, params); },
        post(endpoint, data) { return this.request('POST', endpoint, data); },
        patch(endpoint, data) { return this.request('PATCH', endpoint, data); },
        delete(endpoint) { return this.request('DELETE', endpoint); },
    };

    // ===========================================
    // CATEGORY TREE COMPONENT
    // ===========================================

    document.addEventListener('alpine:init', () => {
        Alpine.data('categoryTree', () => ({
            // State
            categories: [],
            breadcrumb: [],
            selectedCategory: null,
            currentParent: 0,
            currentPage: 1,
            totalPages: 1,
            totalItems: 0,
            perPage: 50,

            // UI State
            loading: false,
            searchQuery: '',
            sortBy: 'name',
            sortOrder: 'asc',

            // Initialize
            async init() {
                await this.loadCategories(0);
            },

            // Load categories for a parent
            async loadCategories(parentId, append = false) {
                if (this.loading) return;

                this.loading = true;

                try {
                    const params = {
                        parent: parentId,
                        page: this.currentPage,
                        per_page: this.perPage,
                        orderby: this.sortBy,
                        order: this.sortOrder,
                    };

                    if (this.searchQuery) {
                        params.search = this.searchQuery;
                    }

                    const response = await api.get('categories', params);

                    if (append) {
                        this.categories = [...this.categories, ...response.data];
                    } else {
                        this.categories = response.data;
                    }

                    this.totalItems = response.headers.total;
                    this.totalPages = response.headers.totalPages;
                    this.currentParent = parentId;

                } catch (error) {
                    console.error('Failed to load categories:', error);
                    window.acms?.toast?.error(error.message || 'Failed to load categories');
                } finally {
                    this.loading = false;
                }
            },

            // Load more (pagination)
            async loadMore() {
                if (this.currentPage >= this.totalPages || this.loading) return;

                this.currentPage++;
                await this.loadCategories(this.currentParent, true);
            },

            // Check if has more items
            get hasMore() {
                return this.currentPage < this.totalPages;
            },

            // Navigate into a category
            async navigateInto(category) {
                // Load breadcrumb
                await this.loadBreadcrumb(category.term_id);

                // Reset pagination and load children
                this.currentPage = 1;
                await this.loadCategories(category.term_id);
            },

            // Load breadcrumb path
            async loadBreadcrumb(categoryId) {
                try {
                    const response = await api.get(`categories/${categoryId}/breadcrumb`);
                    this.breadcrumb = response.data;
                } catch (error) {
                    console.error('Failed to load breadcrumb:', error);
                }
            },

            // Navigate back one level
            async navigateBack() {
                if (this.breadcrumb.length < 2) {
                    // Go to root
                    this.breadcrumb = [];
                    this.currentPage = 1;
                    await this.loadCategories(0);
                } else {
                    // Go to parent
                    const parent = this.breadcrumb[this.breadcrumb.length - 2];
                    await this.navigateInto(parent);
                }
            },

            // Navigate to specific breadcrumb item
            async navigateTo(category, index) {
                if (index === this.breadcrumb.length - 1) return;

                this.breadcrumb = this.breadcrumb.slice(0, index + 1);
                this.currentPage = 1;
                await this.loadCategories(category.term_id);
            },

            // Go to root
            async navigateToRoot() {
                this.breadcrumb = [];
                this.currentPage = 1;
                await this.loadCategories(0);
            },

            // Search handler (debounced in template)
            async search() {
                this.currentPage = 1;
                await this.loadCategories(this.currentParent);
            },

            // Clear search
            async clearSearch() {
                this.searchQuery = '';
                await this.search();
            },

            // Select a category
            selectCategory(category) {
                this.selectedCategory = category;
            },

            // Sort by column
            async sortByColumn(column) {
                if (this.sortBy === column) {
                    this.sortOrder = this.sortOrder === 'asc' ? 'desc' : 'asc';
                } else {
                    this.sortBy = column;
                    this.sortOrder = 'asc';
                }

                this.currentPage = 1;
                await this.loadCategories(this.currentParent);
            },

            // Refresh current view
            async refresh() {
                this.currentPage = 1;
                await this.loadCategories(this.currentParent);
            },
        }));

        // ===========================================
        // CATEGORY DETAIL COMPONENT
        // ===========================================

        Alpine.data('categoryDetail', () => ({
            category: null,
            loading: false,
            editing: false,

            formData: {
                name: '',
                slug: '',
                seo_title: '',
                seo_description: '',
            },

            // Watch for category changes
            init() {
                this.$watch('category', (value) => {
                    if (value) {
                        this.formData = {
                            name: value.name || '',
                            slug: value.slug || '',
                            seo_title: value.seo_title || '',
                            seo_description: value.seo_description || '',
                        };
                    }
                });
            },

            // Load category details
            async loadDetails(categoryId) {
                this.loading = true;

                try {
                    const response = await api.get(`categories/${categoryId}`);
                    this.category = response.data;
                } catch (error) {
                    console.error('Failed to load category details:', error);
                } finally {
                    this.loading = false;
                }
            },

            // Save changes
            async save() {
                if (!this.category) return;

                this.loading = true;

                try {
                    await api.patch(`categories/${this.category.term_id}`, this.formData);

                    window.acms?.toast?.success('Category updated successfully');
                    this.editing = false;

                    // Refresh the list
                    this.$dispatch('category-updated');

                } catch (error) {
                    window.acms?.toast?.error(error.message || 'Failed to update category');
                } finally {
                    this.loading = false;
                }
            },

            // Cancel editing
            cancelEdit() {
                this.editing = false;
                if (this.category) {
                    this.formData = {
                        name: this.category.name || '',
                        slug: this.category.slug || '',
                        seo_title: this.category.seo_title || '',
                        seo_description: this.category.seo_description || '',
                    };
                }
            },
        }));

        // ===========================================
        // QUEUE MANAGER COMPONENT
        // ===========================================

        Alpine.data('queueManager', () => ({
            items: [],
            loading: false,
            currentPage: 1,
            totalPages: 1,
            perPage: 20,

            // Filter state
            statusFilter: '',

            // Dialog state
            showAddDialog: false,
            newKeyword: '',
            addLoading: false,

            // Initialize
            async init() {
                await this.loadQueue();
            },

            // Load queue items
            async loadQueue(append = false) {
                this.loading = true;

                try {
                    const params = {
                        page: this.currentPage,
                        per_page: this.perPage,
                    };

                    if (this.statusFilter) {
                        params.status = this.statusFilter;
                    }

                    const response = await api.get('queue', params);

                    if (append) {
                        this.items = [...this.items, ...response.data];
                    } else {
                        this.items = response.data;
                    }

                    this.totalPages = response.headers.totalPages;

                } catch (error) {
                    console.error('Failed to load queue:', error);
                    window.acms?.toast?.error('Failed to load queue');
                } finally {
                    this.loading = false;
                }
            },

            // Add keyword to queue
            async addKeyword() {
                if (!this.newKeyword.trim()) return;

                this.addLoading = true;

                try {
                    await api.post('queue', {
                        keyword: this.newKeyword.trim(),
                    });

                    window.acms?.toast?.success('Keyword added to queue');
                    this.newKeyword = '';
                    this.showAddDialog = false;

                    await this.loadQueue();

                } catch (error) {
                    window.acms?.toast?.error(error.message || 'Failed to add keyword');
                } finally {
                    this.addLoading = false;
                }
            },

            // Filter by status
            async filterByStatus(status) {
                this.statusFilter = status;
                this.currentPage = 1;
                await this.loadQueue();
            },

            // Retry failed item
            async retryItem(itemId) {
                try {
                    await api.post(`queue/${itemId}/retry`);
                    window.acms?.toast?.success('Item queued for retry');
                    await this.loadQueue();
                } catch (error) {
                    window.acms?.toast?.error('Failed to retry item');
                }
            },

            // Delete item
            async deleteItem(itemId) {
                if (!confirm('Are you sure you want to delete this item?')) return;

                try {
                    await api.delete(`queue/${itemId}`);
                    window.acms?.toast?.success('Item deleted');
                    await this.loadQueue();
                } catch (error) {
                    window.acms?.toast?.error('Failed to delete item');
                }
            },

            // Get status badge class
            getStatusClass(status) {
                const classes = {
                    pending: 'acms-badge--default',
                    processing: 'acms-badge--warning',
                    completed: 'acms-badge--success',
                    failed: 'acms-badge--error',
                };
                return classes[status] || 'acms-badge--default';
            },
        }));

        // ===========================================
        // STATS COMPONENT
        // ===========================================

        Alpine.data('categoryStats', () => ({
            stats: {
                totalCategories: 0,
                totalProducts: 0,
                queuePending: 0,
                queueFailed: 0,
            },
            loading: false,

            async init() {
                await this.loadStats();
            },

            async loadStats() {
                this.loading = true;

                try {
                    const response = await api.get('stats');
                    this.stats = response.data;
                } catch (error) {
                    console.error('Failed to load stats:', error);
                } finally {
                    this.loading = false;
                }
            },
        }));
    });

    // ===========================================
    // UTILITIES
    // ===========================================

    const utils = {
        debounce(func, wait) {
            let timeout;
            return function executedFunction(...args) {
                const later = () => {
                    clearTimeout(timeout);
                    func(...args);
                };
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
            };
        },

        formatNumber(num) {
            if (num >= 1000000) {
                return (num / 1000000).toFixed(1) + 'M';
            }
            if (num >= 1000) {
                return (num / 1000).toFixed(1) + 'K';
            }
            return num.toString();
        },
    };

    // ===========================================
    // EXPOSE GLOBAL API
    // ===========================================

    window.acmsCat = {
        api,
        utils,
    };

})();
