<?php
/**
 * Queue REST API Controller
 *
 * Endpoints for managing category keyword queue
 *
 * @package AffiliateCMS\Categories
 */

declare(strict_types=1);

namespace AffiliateCMS\Categories\Api;

use AffiliateCMS\Categories\Repositories\QueueRepository;
use AffiliateCMS\Categories\Core\QueueProcessor;
use AffiliateCMS\Categories\Core\CategoryQueueMonitor;
use AffiliateCMS\Categories\Core\CategoryPathAssigner;
use WP_REST_Controller;
use WP_REST_Request;
use WP_REST_Response;
use WP_Error;

class QueueController extends WP_REST_Controller
{
    protected $namespace = 'acms-cat/v1';
    protected $rest_base = 'queue';

    private QueueRepository $repo;

    public function __construct()
    {
        $this->repo = new QueueRepository();
    }

    /**
     * Register routes
     */
    public function register_routes(): void
    {
        // GET /queue - List items
        register_rest_route($this->namespace, '/' . $this->rest_base, [
            [
                'methods' => 'GET',
                'callback' => [$this, 'get_items'],
                'permission_callback' => [$this, 'admin_permission'],
                'args' => [
                    'status' => [
                        'type' => 'string',
                        'enum' => ['pending', 'processing', 'searched', 'ready_for_ai', 'completed', 'failed'],
                    ],
                    'search' => [
                        'type' => 'string',
                        'default' => '',
                    ],
                    'orderby' => [
                        'type' => 'string',
                        'default' => 'created_at',
                        'enum' => ['id', 'keyword', 'status', 'created_at', 'scrape_progress', 'ai_status', 'products_found', 'search_status'],
                    ],
                    'order' => [
                        'type' => 'string',
                        'default' => 'DESC',
                        'enum' => ['ASC', 'DESC'],
                    ],
                    'page' => [
                        'type' => 'integer',
                        'default' => 1,
                        'minimum' => 1,
                    ],
                    'per_page' => [
                        'type' => 'integer',
                        'default' => 20,
                        'minimum' => 1,
                        'maximum' => 1000,
                    ],
                ],
            ],
            // POST /queue - Add keywords
            [
                'methods' => 'POST',
                'callback' => [$this, 'create_item'],
                'permission_callback' => [$this, 'admin_permission'],
                'args' => [
                    'keywords' => [
                        'required' => true,
                        'type' => 'array',
                        'items' => ['type' => 'string'],
                        'description' => 'Array of keywords to add',
                    ],
                    'search_limit' => [
                        'type' => 'integer',
                        'default' => 20,
                        'minimum' => 1,
                        'maximum' => 100,
                    ],
                    'search_pages' => [
                        'type' => 'integer',
                        'default' => 1,
                        'minimum' => 1,
                        'maximum' => 5,
                        'description' => 'Max pages to search (1-5)',
                    ],
                    'linked_asins' => [
                        'type' => 'array',
                        'required' => false,
                        'items' => ['type' => 'string'],
                        'description' => 'Optional: Pre-defined ASINs (skips auto-search)',
                    ],
                    'custom_category_path' => [
                        'type' => ['string', 'null'],
                        'required' => false,
                        'description' => 'Optional: Pre-assigned category path',
                    ],
                    'process_now' => [
                        'type' => 'boolean',
                        'default' => false,
                        'description' => 'Whether to start processing immediately',
                    ],
                ],
            ],
        ]);

        // POST /queue/process - Process next item
        register_rest_route($this->namespace, '/' . $this->rest_base . '/process', [
            'methods' => 'POST',
            'callback' => [$this, 'process_next'],
            'permission_callback' => [$this, 'admin_permission'],
        ]);

        // POST /queue/process-batch - Process multiple items
        register_rest_route($this->namespace, '/' . $this->rest_base . '/process-batch', [
            'methods' => 'POST',
            'callback' => [$this, 'process_batch'],
            'permission_callback' => [$this, 'admin_permission'],
            'args' => [
                'limit' => [
                    'type' => 'integer',
                    'default' => 5,
                    'minimum' => 1,
                    'maximum' => 20,
                ],
            ],
        ]);

        // GET /queue/stats - Statistics
        register_rest_route($this->namespace, '/' . $this->rest_base . '/stats', [
            'methods' => 'GET',
            'callback' => [$this, 'get_stats'],
            'permission_callback' => [$this, 'admin_permission'],
        ]);

        // GET /queue/{id} - Get single item
        register_rest_route($this->namespace, '/' . $this->rest_base . '/(?P<id>\d+)', [
            [
                'methods' => 'GET',
                'callback' => [$this, 'get_item'],
                'permission_callback' => [$this, 'admin_permission'],
            ],
            // PUT /queue/{id} - Update item
            [
                'methods' => 'PUT',
                'callback' => [$this, 'update_item'],
                'permission_callback' => [$this, 'admin_permission'],
                'args' => [
                    'keyword' => [
                        'type' => 'string',
                        'required' => false,
                    ],
                    'search_pages' => [
                        'type' => 'integer',
                        'required' => false,
                        'minimum' => 1,
                        'maximum' => 3,
                    ],
                    'search_limit' => [
                        'type' => 'integer',
                        'required' => false,
                        'minimum' => 1,
                        'maximum' => 100,
                    ],
                    'linked_asins' => [
                        'type' => 'array',
                        'required' => false,
                        'items' => ['type' => 'string'],
                        'description' => 'Array of ASINs',
                    ],
                    'custom_category_path' => [
                        'type' => ['string', 'null'],
                        'required' => false,
                    ],
                    'ai_status' => [
                        'type' => 'string',
                        'required' => false,
                        'enum' => ['not_started', 'waiting_scrape', 'analyzing_category', 'category_assigned', 'generating_content', 'completed', 'failed'],
                    ],
                    'status' => [
                        'type' => 'string',
                        'required' => false,
                        'enum' => ['pending', 'processing', 'searched', 'ready_for_ai', 'completed', 'failed'],
                    ],
                    'assigned_category_id' => [
                        'type' => ['integer', 'null'],
                        'required' => false,
                    ],
                    'suggested_categories' => [
                        'type' => ['array', 'null'],
                        'required' => false,
                    ],
                    'cat_ai_generation_id' => [
                        'type' => ['string', 'null'],
                        'required' => false,
                    ],
                ],
            ],
            // DELETE /queue/{id}
            [
                'methods' => 'DELETE',
                'callback' => [$this, 'delete_item'],
                'permission_callback' => [$this, 'admin_permission'],
            ],
        ]);

        // POST /queue/{id}/retry - Retry failed item
        register_rest_route($this->namespace, '/' . $this->rest_base . '/(?P<id>\d+)/retry', [
            'methods' => 'POST',
            'callback' => [$this, 'retry_item'],
            'permission_callback' => [$this, 'admin_permission'],
        ]);

        // POST /queue/{id}/process - Process specific item
        register_rest_route($this->namespace, '/' . $this->rest_base . '/(?P<id>\d+)/process', [
            'methods' => 'POST',
            'callback' => [$this, 'process_item'],
            'permission_callback' => [$this, 'admin_permission'],
        ]);

        // POST /queue/clear - Clear completed items
        register_rest_route($this->namespace, '/' . $this->rest_base . '/clear', [
            'methods' => 'POST',
            'callback' => [$this, 'clear_completed'],
            'permission_callback' => [$this, 'admin_permission'],
        ]);

        // POST /queue/reset-failed - Reset all failed items
        register_rest_route($this->namespace, '/' . $this->rest_base . '/reset-failed', [
            'methods' => 'POST',
            'callback' => [$this, 'reset_failed'],
            'permission_callback' => [$this, 'admin_permission'],
        ]);

        // POST /queue/reset-stuck - Reset stuck processing items
        register_rest_route($this->namespace, '/' . $this->rest_base . '/reset-stuck', [
            'methods' => 'POST',
            'callback' => [$this, 'reset_stuck'],
            'permission_callback' => [$this, 'admin_permission'],
        ]);

        // POST /queue/{id}/force-reset - Force reset specific item
        register_rest_route($this->namespace, '/' . $this->rest_base . '/(?P<id>\d+)/force-reset', [
            'methods' => 'POST',
            'callback' => [$this, 'force_reset_item'],
            'permission_callback' => [$this, 'admin_permission'],
        ]);

        // DELETE /queue/{id}/force - Force delete specific item
        register_rest_route($this->namespace, '/' . $this->rest_base . '/(?P<id>\d+)/force', [
            'methods' => 'DELETE',
            'callback' => [$this, 'force_delete_item'],
            'permission_callback' => [$this, 'admin_permission'],
        ]);

        // POST /queue/{id}/delete-advanced - Advanced delete with options
        register_rest_route($this->namespace, '/' . $this->rest_base . '/(?P<id>\d+)/delete-advanced', [
            'methods' => 'POST',
            'callback' => [$this, 'delete_advanced'],
            'permission_callback' => [$this, 'admin_permission'],
            'args' => [
                'mode' => [
                    'type' => 'string',
                    'required' => true,
                    'enum' => ['keyword_only', 'with_orphan_asins', 'full'],
                    'description' => 'Delete mode: keyword_only, with_orphan_asins (+ orphan products), full (+ orphan categories)',
                ],
            ],
        ]);

        // GET /queue/{id}/log - Get processing log
        register_rest_route($this->namespace, '/' . $this->rest_base . '/(?P<id>\d+)/log', [
            'methods' => 'GET',
            'callback' => [$this, 'get_processing_log'],
            'permission_callback' => [$this, 'admin_permission'],
        ]);

        // POST /queue/monitor - Run queue monitor (check scrape progress)
        register_rest_route($this->namespace, '/' . $this->rest_base . '/monitor', [
            'methods' => 'POST',
            'callback' => [$this, 'run_monitor'],
            'permission_callback' => [$this, 'admin_permission'],
        ]);

        // POST /queue/{id}/assign-category - Assign category using majority voting
        register_rest_route($this->namespace, '/' . $this->rest_base . '/(?P<id>\d+)/assign-category', [
            'methods' => 'POST',
            'callback' => [$this, 'assign_category'],
            'permission_callback' => [$this, 'admin_permission'],
            'args' => [
                'force' => [
                    'type' => 'boolean',
                    'default' => false,
                    'description' => 'Force re-run even if already assigned',
                ],
            ],
        ]);

        // POST /queue/{id}/update-asins - Re-run search and update ASINs
        register_rest_route($this->namespace, '/' . $this->rest_base . '/(?P<id>\d+)/update-asins', [
            'methods' => 'POST',
            'callback' => [$this, 'update_asins'],
            'permission_callback' => [$this, 'admin_permission'],
            'args' => [
                'mode' => [
                    'type' => 'string',
                    'required' => true,
                    'enum' => ['append', 'append_with_brands', 'replace'],
                    'description' => 'Update mode: append (add new only), append_with_brands (add new + create brand pages), replace (remove old, add fresh)',
                ],
                'search_pages' => [
                    'type' => 'integer',
                    'required' => false,
                    'default' => 0,
                    'minimum' => 0,
                    'maximum' => 5,
                    'description' => 'Override search pages (0 = use key default, max 5)',
                ],
                'search_limit' => [
                    'type' => 'integer',
                    'required' => false,
                    'default' => 0,
                    'minimum' => 0,
                    'maximum' => 200,
                    'description' => 'Override ASINs limit (0 = use key default)',
                ],
            ],
        ]);

        // POST /queue/{id}/link-products - Re-link products to assigned category
        register_rest_route($this->namespace, '/' . $this->rest_base . '/(?P<id>\d+)/link-products', [
            'methods' => 'POST',
            'callback' => [$this, 'link_products'],
            'permission_callback' => [$this, 'admin_permission'],
        ]);

        // POST /queue/{id}/generate-content - Trigger Category AI content generation
        register_rest_route($this->namespace, '/' . $this->rest_base . '/(?P<id>\d+)/generate-content', [
            'methods' => 'POST',
            'callback' => [$this, 'generate_content'],
            'permission_callback' => [$this, 'admin_permission'],
        ]);

        // GET /queue/{id}/diagnose - Get diagnostic info about queue item state
        register_rest_route($this->namespace, '/' . $this->rest_base . '/(?P<id>\d+)/diagnose', [
            'methods' => 'GET',
            'callback' => [$this, 'diagnose_item'],
            'permission_callback' => [$this, 'admin_permission'],
        ]);

        // GET /queue/waiting - Get items waiting for scrape
        register_rest_route($this->namespace, '/' . $this->rest_base . '/waiting', [
            'methods' => 'GET',
            'callback' => [$this, 'get_waiting_items'],
            'permission_callback' => [$this, 'admin_permission'],
        ]);

        // POST /queue/bulk-sync-links - Re-link all scraped products to their assigned categories
        register_rest_route($this->namespace, '/' . $this->rest_base . '/bulk-sync-links', [
            'methods' => 'POST',
            'callback' => [$this, 'bulk_sync_links'],
            'permission_callback' => [$this, 'admin_permission'],
            'args' => [
                'ids' => [
                    'type' => 'array',
                    'required' => false,
                    'description' => 'Specific queue item IDs to sync (empty = all with assigned category)',
                    'items' => ['type' => 'integer'],
                ],
            ],
        ]);

        // POST /queue/bulk-update-asins - Start background bulk update
        register_rest_route($this->namespace, '/' . $this->rest_base . '/bulk-update-asins', [
            'methods' => 'POST',
            'callback' => [$this, 'bulk_update_asins_start'],
            'permission_callback' => [$this, 'admin_permission'],
            'args' => [
                'ids' => [
                    'type' => 'array',
                    'required' => true,
                    'items' => ['type' => 'integer'],
                ],
                'mode' => [
                    'type' => 'string',
                    'required' => true,
                    'enum' => ['append', 'append_with_brands', 'replace'],
                ],
                'search_pages' => [
                    'type' => 'integer',
                    'default' => 0,
                    'minimum' => 0,
                    'maximum' => 5,
                ],
                'search_limit' => [
                    'type' => 'integer',
                    'default' => 0,
                    'minimum' => 0,
                    'maximum' => 200,
                ],
            ],
        ]);

        // GET /queue/bulk-update-status - Poll batch progress
        register_rest_route($this->namespace, '/' . $this->rest_base . '/bulk-update-status', [
            'methods' => 'GET',
            'callback' => [$this, 'bulk_update_asins_status'],
            'permission_callback' => [$this, 'admin_permission'],
            'args' => [
                'batch_id' => [
                    'type' => 'string',
                    'required' => true,
                ],
            ],
        ]);

        // POST /queue/bulk-update-cancel - Cancel running batch
        register_rest_route($this->namespace, '/' . $this->rest_base . '/bulk-update-cancel', [
            'methods' => 'POST',
            'callback' => [$this, 'bulk_update_asins_cancel'],
            'permission_callback' => [$this, 'admin_permission'],
            'args' => [
                'batch_id' => [
                    'type' => 'string',
                    'required' => true,
                ],
            ],
        ]);
    }

    /**
     * Admin permission check
     */
    public function admin_permission(): bool
    {
        return current_user_can('manage_options');
    }

    /**
     * GET /queue - List queue items
     */
    public function get_items($request): WP_REST_Response
    {
        $result = $this->repo->getAll([
            'status' => $request->get_param('status') ?? '',
            'search' => $request->get_param('search') ?? '',
            'page' => (int) $request->get_param('page'),
            'per_page' => (int) $request->get_param('per_page'),
            'orderby' => $request->get_param('orderby') ?? 'created_at',
            'order' => $request->get_param('order') ?? 'DESC',
        ]);

        $stats = $this->repo->getStats();

        return new WP_REST_Response([
            'success' => true,
            'data' => [
                'items' => $result['items'] ?? [],
                'stats' => $stats,
                'total' => $result['total'] ?? 0,
                'page' => $result['page'] ?? 1,
                'per_page' => $result['per_page'] ?? 20,
                'total_pages' => $result['total_pages'] ?? 0,
            ],
        ]);
    }

    /**
     * POST /queue - Add keywords to queue
     */
    public function create_item($request): WP_REST_Response|WP_Error
    {
        $keywords = $request->get_param('keywords');
        $searchLimit = (int) $request->get_param('search_limit');
        $searchPages = (int) $request->get_param('search_pages');
        $linkedAsins = $request->get_param('linked_asins');
        $customCategoryPath = $request->get_param('custom_category_path');
        $processNow = (bool) $request->get_param('process_now');

        if (empty($keywords)) {
            return new WP_Error(
                'empty_keywords',
                'At least one keyword is required',
                ['status' => 400]
            );
        }

        // Filter empty keywords
        $keywords = array_filter(array_map('trim', $keywords));

        if (empty($keywords)) {
            return new WP_Error(
                'empty_keywords',
                'No valid keywords provided',
                ['status' => 400]
            );
        }

        // Build options for bulk create
        $options = [
            'search_limit' => $searchLimit,
            'max_search_pages' => $searchPages ?: 1,
        ];

        // If custom ASINs provided, mark as searched and skip auto-search
        if (!empty($linkedAsins) && is_array($linkedAsins)) {
            $options['linked_asins'] = array_values(array_filter(array_map('trim', $linkedAsins)));
            $options['search_status'] = 'completed';  // Mark as already searched
            $options['status'] = 'ready_for_ai';      // Ready for AI processing
            $options['products_found'] = count($options['linked_asins']);
        }

        // If category path provided, pre-assign it
        if (!empty($customCategoryPath)) {
            $options['custom_category_path'] = trim($customCategoryPath);
        }

        $total = count($keywords);
        $created = $this->repo->bulkCreate($keywords, $options);
        $skipped = $total - $created;

        // If processNow and items were created, trigger processing
        if ($processNow && $created > 0) {
            $processor = new QueueProcessor();
            $processor->processNext();
        }

        $message = "{$created} keyword(s) added to queue";
        if ($skipped > 0) {
            $message .= ", {$skipped} skipped (already in queue)";
        }

        return new WP_REST_Response([
            'success' => true,
            'created' => $created,
            'skipped' => $skipped,
            'message' => $message,
        ], 201);
    }

    /**
     * GET /queue/{id} - Get single item
     */
    public function get_item($request): WP_REST_Response|WP_Error
    {
        $id = (int) $request->get_param('id');
        $item = $this->repo->find($id);

        if (!$item) {
            return new WP_Error(
                'not_found',
                'Queue item not found',
                ['status' => 404]
            );
        }

        return new WP_REST_Response($item);
    }

    /**
     * PUT /queue/{id} - Update queue item
     */
    public function update_item($request): WP_REST_Response|WP_Error
    {
        $id = (int) $request->get_param('id');

        // Debug: Log all incoming params
        if (defined('WP_DEBUG') && WP_DEBUG) {
            $params = $request->get_params();
            error_log("[ACMS QueueController] update_item called for queue {$id}");
            error_log("[ACMS QueueController] Params received: " . wp_json_encode($params));
        }

        $item = $this->repo->find($id);

        if (!$item) {
            return new WP_Error(
                'not_found',
                'Queue item not found',
                ['status' => 404]
            );
        }

        // Don't update processing items
        if ($item['status'] === 'processing') {
            return new WP_Error(
                'item_processing',
                'Cannot update item that is currently processing',
                ['status' => 400]
            );
        }

        $updateData = [];

        if ($request->has_param('keyword')) {
            $keyword = trim($request->get_param('keyword'));
            if (empty($keyword)) {
                return new WP_Error(
                    'empty_keyword',
                    'Keyword cannot be empty',
                    ['status' => 400]
                );
            }
            $updateData['keyword'] = $keyword;
        }

        if ($request->has_param('search_limit')) {
            $updateData['search_limit'] = (int) $request->get_param('search_limit');
        }

        if ($request->has_param('search_pages')) {
            $updateData['max_search_pages'] = (int) $request->get_param('search_pages');
        }

        $productsSaved = 0;
        $productsSkipped = 0;

        if ($request->has_param('linked_asins')) {
            $asins = $request->get_param('linked_asins');
            if (is_array($asins)) {
                $updateData['linked_asins'] = wp_json_encode($asins);
                $updateData['products_found'] = count($asins);

                // If ASINs are manually provided and item hasn't been searched yet,
                // mark it as searched (allows manual ASIN entry workflow)
                if (!empty($asins) && in_array($item['status'], ['pending', 'failed'], true)) {
                    $updateData['status'] = 'searched';
                    $updateData['search_status'] = 'completed';
                    $updateData['ai_status'] = 'waiting_scrape';
                }

                // Save ASINs to products table (same as QueueProcessor::stepSaveProducts)
                if (!empty($asins) && class_exists('AffiliateCMS\\Pro\\Repositories\\ProductRepository')) {
                    $productRepo = \AffiliateCMS\Pro\Repositories\ProductRepository::instance();
                    $domain = $item['search_domain'] ?? 'amazon.com';

                    foreach ($asins as $asin) {
                        $asin = trim($asin);
                        if (empty($asin)) continue;

                        // Check if product already exists
                        $existing = $productRepo->findByAsin($asin);
                        if ($existing) {
                            $productsSkipped++;
                            continue;
                        }

                        // Create product with pending status
                        $productId = $productRepo->create([
                            'asin' => $asin,
                            'status' => 'pending',
                            'title' => 'Pending scrape...',
                            'domain' => $domain
                        ]);

                        if ($productId) {
                            $productsSaved++;
                        }
                    }
                }
            }
        }

        // Handle custom category path (single path for this keyword)
        if ($request->has_param('custom_category_path')) {
            $customPath = $request->get_param('custom_category_path');
            if ($customPath === null || $customPath === '') {
                $updateData['custom_category_path'] = null;
            } else {
                $customPath = trim($customPath);
                if (!empty($customPath)) {
                    $updateData['custom_category_path'] = $customPath;
                    $updateData['ai_status'] = 'category_assigned';
                }
            }
        }

        // Handle AI status reset (for bulk actions)
        if ($request->has_param('ai_status')) {
            $aiStatus = $request->get_param('ai_status');
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("[ACMS QueueController] ai_status param found: '{$aiStatus}'");
            }
            $validStatuses = ['not_started', 'waiting_scrape', 'analyzing_category', 'category_assigned', 'generating_content', 'completed', 'failed'];
            if (in_array($aiStatus, $validStatuses, true)) {
                $updateData['ai_status'] = $aiStatus;

                // If resetting to 'not_started', also cleanup related AI jobs
                if ($aiStatus === 'not_started') {
                    if (defined('WP_DEBUG') && WP_DEBUG) {
                        error_log("[ACMS QueueController] ai_status is 'not_started', calling cleanupAiJobsForQueue");
                    }
                    $this->cleanupAiJobsForQueue($id, $item);
                }
            }
        }

        // Handle assigned_category_id reset
        if ($request->has_param('assigned_category_id')) {
            $catId = $request->get_param('assigned_category_id');
            $updateData['assigned_category_id'] = $catId === null ? null : (int) $catId;
        }

        // Handle suggested_categories reset
        if ($request->has_param('suggested_categories')) {
            $suggested = $request->get_param('suggested_categories');
            $updateData['suggested_categories'] = $suggested === null ? null : wp_json_encode($suggested);
        }

        // Handle cat_ai_generation_id reset
        if ($request->has_param('cat_ai_generation_id')) {
            $genId = $request->get_param('cat_ai_generation_id');
            $updateData['cat_ai_generation_id'] = $genId === null ? null : (string) $genId;
        }

        // Handle status reset (for bulk actions - allows re-processing)
        if ($request->has_param('status')) {
            $status = $request->get_param('status');
            $validStatuses = ['pending', 'processing', 'searched', 'ready_for_ai', 'completed', 'failed'];
            if (in_array($status, $validStatuses, true)) {
                $updateData['status'] = $status;
                // Also reset completed_at when setting back to non-completed status
                if ($status !== 'completed') {
                    $updateData['completed_at'] = null;
                }
            }
        }

        if (empty($updateData)) {
            return new WP_Error(
                'no_data',
                'No data to update',
                ['status' => 400]
            );
        }

        $updated = $this->repo->update($id, $updateData);

        if (!$updated) {
            return new WP_Error(
                'update_failed',
                'Failed to update queue item',
                ['status' => 500]
            );
        }

        $response = [
            'success' => true,
            'message' => 'Queue item updated successfully',
        ];

        // Include product save stats if ASINs were processed
        if ($productsSaved > 0 || $productsSkipped > 0) {
            $response['products_saved'] = $productsSaved;
            $response['products_skipped'] = $productsSkipped;
            $response['message'] .= ". {$productsSaved} product(s) added, {$productsSkipped} skipped (existing)";
        }

        return new WP_REST_Response($response);
    }

    /**
     * DELETE /queue/{id} - Delete item
     */
    public function delete_item($request): WP_REST_Response|WP_Error
    {
        $id = (int) $request->get_param('id');
        $item = $this->repo->find($id);

        if (!$item) {
            return new WP_Error(
                'not_found',
                'Queue item not found',
                ['status' => 404]
            );
        }

        // Don't delete processing items
        if ($item['status'] === 'processing') {
            return new WP_Error(
                'item_processing',
                'Cannot delete item that is currently processing',
                ['status' => 400]
            );
        }

        $this->repo->delete($id);

        return new WP_REST_Response([
            'success' => true,
            'message' => 'Queue item deleted',
        ]);
    }

    /**
     * POST /queue/process - Process next pending item
     */
    public function process_next(): WP_REST_Response
    {
        $processor = new QueueProcessor();
        $result = $processor->processNext();

        return new WP_REST_Response($result);
    }

    /**
     * POST /queue/process-batch - Process multiple items
     */
    public function process_batch($request): WP_REST_Response
    {
        $limit = (int) $request->get_param('limit');
        $processor = new QueueProcessor();
        $results = [];

        for ($i = 0; $i < $limit; $i++) {
            $result = $processor->processNext();
            $results[] = $result;

            // Stop if no more pending items
            if ($result['queue_id'] === null) {
                break;
            }
        }

        $processed = count(array_filter($results, fn($r) => $r['queue_id'] !== null));

        return new WP_REST_Response([
            'success' => true,
            'processed' => $processed,
            'results' => $results,
        ]);
    }

    /**
     * GET /queue/stats - Get queue statistics
     */
    public function get_stats(): WP_REST_Response
    {
        $stats = $this->repo->getStats();

        return new WP_REST_Response($stats);
    }

    /**
     * POST /queue/{id}/retry - Retry failed item
     */
    public function retry_item($request): WP_REST_Response|WP_Error
    {
        $id = (int) $request->get_param('id');
        $item = $this->repo->find($id);

        if (!$item) {
            return new WP_Error(
                'not_found',
                'Queue item not found',
                ['status' => 404]
            );
        }

        if ($item['status'] !== 'failed') {
            return new WP_Error(
                'invalid_status',
                'Only failed items can be retried',
                ['status' => 400]
            );
        }

        // Reset to pending (also reset search_status and ai_status)
        $this->repo->update($id, [
            'status' => 'pending',
            'search_status' => 'not_searched',
            'ai_status' => 'not_started',
            'scrape_progress' => 0,
            'error_message' => null,
            'started_at' => null,
            'completed_at' => null,
        ]);

        return new WP_REST_Response([
            'success' => true,
            'message' => 'Item queued for retry',
        ]);
    }

    /**
     * POST /queue/{id}/process - Process specific queue item
     */
    public function process_item($request): WP_REST_Response|WP_Error
    {
        $id = (int) $request->get_param('id');
        $item = $this->repo->find($id);

        if (!$item) {
            return new WP_Error(
                'not_found',
                'Queue item not found',
                ['status' => 404]
            );
        }

        try {
            // Process the specific item
            $processor = new QueueProcessor();
            $result = $processor->processItem($id);

            // If processing succeeded, schedule immediate monitor check
            // This avoids waiting for the 5-minute cron interval
            if ($result['success']) {
                $this->scheduleImmediateMonitorCheck();
            }

            return new WP_REST_Response($result);
        } catch (\Exception $e) {
            return new WP_Error(
                'processing_error',
                'Failed to process queue item: ' . $e->getMessage(),
                [
                    'status' => 500,
                    'error' => $e->getMessage(),
                    'file' => $e->getFile(),
                    'line' => $e->getLine()
                ]
            );
        }
    }

    /**
     * Schedule immediate monitor check for scrape progress
     *
     * Uses WP single event to run CategoryQueueMonitor as soon as possible.
     * This avoids waiting for the regular 5-minute cron interval.
     */
    private function scheduleImmediateMonitorCheck(): void
    {
        // Schedule CategoryQueueMonitor to run in 30 seconds
        // This gives time for scraping to start before checking progress
        $hookName = CategoryQueueMonitor::CRON_HOOK;

        // Only schedule if not already scheduled within next 2 minutes
        $nextScheduled = wp_next_scheduled($hookName);
        if (!$nextScheduled || $nextScheduled > time() + 120) {
            wp_schedule_single_event(time() + 30, $hookName);

            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('[ACMS Cat Queue] Scheduled immediate monitor check in 30 seconds');
            }
        }
    }

    /**
     * POST /queue/clear - Clear completed items
     */
    public function clear_completed(): WP_REST_Response
    {
        $cleared = $this->repo->clearCompleted();

        return new WP_REST_Response([
            'success' => true,
            'cleared' => $cleared,
            'message' => "{$cleared} completed item(s) cleared",
        ]);
    }

    /**
     * POST /queue/reset-failed - Reset all failed items to pending
     */
    public function reset_failed(): WP_REST_Response
    {
        $reset = $this->repo->resetFailed();

        return new WP_REST_Response([
            'success' => true,
            'reset' => $reset,
            'message' => "{$reset} failed item(s) reset to pending",
        ]);
    }

    /**
     * POST /queue/reset-stuck - Reset stuck processing + analyzing + generating items
     */
    public function reset_stuck(): WP_REST_Response
    {
        // 1. Reset items stuck in processing for more than 5 minutes
        $resetProcessing = $this->repo->resetStuckProcessing(5);

        // 2. Re-fire hook for items stuck at analyzing_category (> 5 min)
        $retriedAnalyzing = $this->retryStuckAnalyzing();

        // 3. Reset items stuck at generating_content (> 10 min) — sync with AI job status
        $resetGenerating = $this->resetStuckGenerating();

        $total = $resetProcessing + $retriedAnalyzing + $resetGenerating;
        $parts = [];
        if ($resetProcessing > 0) {
            $parts[] = "{$resetProcessing} processing";
        }
        if ($retriedAnalyzing > 0) {
            $parts[] = "{$retriedAnalyzing} analyzing";
        }
        if ($resetGenerating > 0) {
            $parts[] = "{$resetGenerating} generating";
        }

        return new WP_REST_Response([
            'success' => true,
            'reset' => $total,
            'message' => $total > 0
                ? "Reset: " . implode(', ', $parts) . " item(s)"
                : "No stuck items found",
        ]);
    }

    /**
     * Re-fire hook for items stuck at analyzing_category status
     */
    private function retryStuckAnalyzing(): int
    {
        global $wpdb;
        $table = $wpdb->prefix . 'acms_cat_queue';
        $localTs = current_time('timestamp');
        $threshold = date('Y-m-d H:i:s', $localTs - 300); // 5 min

        $stuckItems = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, linked_asins
                 FROM {$table}
                 WHERE status = 'ready_for_ai'
                 AND ai_status = 'analyzing_category'
                 AND (updated_at < %s OR updated_at IS NULL)
                 AND linked_asins IS NOT NULL
                 AND linked_asins != '[]'
                 LIMIT 50",
                $threshold
            ),
            ARRAY_A
        );

        $retried = 0;
        foreach ($stuckItems as $item) {
            $queueId = (int) $item['id'];
            $linkedAsins = is_array($item['linked_asins'])
                ? $item['linked_asins']
                : json_decode($item['linked_asins'] ?? '[]', true);

            if (!empty($linkedAsins)) {
                do_action('acms_category_ready_for_ai', $queueId, $linkedAsins);
                $retried++;
            }
        }

        return $retried;
    }

    /**
     * Reset items stuck at generating_content by syncing with AI job status
     *
     * Checks acms_ai_jobs table for actual job outcome:
     * - Job completed → sync queue to completed
     * - Job failed → sync queue to failed
     * - Job stale or missing → reset to category_assigned for re-queue
     */
    private function resetStuckGenerating(): int
    {
        global $wpdb;
        $table = $wpdb->prefix . 'acms_cat_queue';
        $jobsTable = $wpdb->prefix . 'acms_ai_jobs';
        $categoriesTable = $wpdb->prefix . 'acms_categories';
        $threshold = date('Y-m-d H:i:s', current_time('timestamp') - 600); // 10 min

        $stuckItems = $wpdb->get_results($wpdb->prepare(
            "SELECT id, keyword, assigned_category_id
             FROM {$table}
             WHERE ai_status = 'generating_content'
             AND (updated_at < %s OR updated_at IS NULL)
             LIMIT 50",
            $threshold
        ), ARRAY_A);

        $count = 0;
        foreach ($stuckItems as $item) {
            $queueId = (int) $item['id'];
            $categoryId = (int) ($item['assigned_category_id'] ?? 0);

            if (!$categoryId) {
                $wpdb->update($table, [
                    'ai_status' => 'category_assigned',
                    'error_message' => 'Reset: no assigned_category_id',
                ], ['id' => $queueId]);
                $count++;
                continue;
            }

            // Check latest AI job for this category
            $job = $wpdb->get_row($wpdb->prepare(
                "SELECT id, status, completed_at, error_message
                 FROM {$jobsTable}
                 WHERE type = 'generate_seo_category' AND target_id = %s
                 ORDER BY id DESC LIMIT 1",
                (string) $categoryId
            ), ARRAY_A);

            if (!$job) {
                // No job → reset to category_assigned
                $wpdb->update($table, ['ai_status' => 'category_assigned', 'error_message' => 'Reset: no AI job found'], ['id' => $queueId]);
                $wpdb->update($categoriesTable, ['content_status' => 'empty'], ['id' => $categoryId]);
                $count++;
            } elseif ($job['status'] === 'completed') {
                // Job completed but queue not synced
                $wpdb->update($table, ['ai_status' => 'completed', 'status' => 'completed', 'completed_at' => $job['completed_at'] ?: current_time('mysql')], ['id' => $queueId]);
                $count++;
            } elseif ($job['status'] === 'failed') {
                // Job failed but queue not synced
                $wpdb->update($table, ['ai_status' => 'failed', 'error_message' => $job['error_message'] ?: 'AI job failed'], ['id' => $queueId]);
                $wpdb->update($categoriesTable, ['content_status' => 'empty', 'ai_error_message' => $job['error_message'] ?: 'AI job failed'], ['id' => $categoryId]);
                $count++;
            } else {
                // Job pending/processing but stale → reset all
                $wpdb->update($table, ['ai_status' => 'category_assigned', 'error_message' => "Reset: job #{$job['id']} stuck at {$job['status']}"], ['id' => $queueId]);
                $wpdb->update($categoriesTable, ['content_status' => 'empty', 'ai_error_message' => null], ['id' => $categoryId]);
                $wpdb->update($jobsTable, ['status' => 'failed', 'error_message' => 'Reset: stuck too long, will retry'], ['id' => $job['id']]);
                $count++;
            }
        }

        if ($count > 0) {
            error_log("[ACMS QueueController] Reset {$count} stuck generating_content items");
        }

        return $count;
    }

    /**
     * POST /queue/{id}/force-reset - Force reset specific item
     */
    public function force_reset_item($request): WP_REST_Response|WP_Error
    {
        $id = (int) $request->get_param('id');
        $item = $this->repo->find($id);

        if (!$item) {
            return new WP_Error(
                'not_found',
                'Queue item not found',
                ['status' => 404]
            );
        }

        $this->repo->forceReset($id);

        return new WP_REST_Response([
            'success' => true,
            'message' => 'Item force reset to pending',
        ]);
    }

    /**
     * DELETE /queue/{id}/force - Force delete specific item
     */
    public function force_delete_item($request): WP_REST_Response|WP_Error
    {
        $id = (int) $request->get_param('id');
        $item = $this->repo->find($id);

        if (!$item) {
            return new WP_Error(
                'not_found',
                'Queue item not found',
                ['status' => 404]
            );
        }

        $this->repo->forceDelete($id);

        return new WP_REST_Response([
            'success' => true,
            'message' => 'Item force deleted',
        ]);
    }

    /**
     * POST /queue/{id}/delete-advanced - Advanced delete with options
     *
     * Modes:
     * - keyword_only: Delete only the queue item
     * - with_orphan_asins: Delete queue item + orphan products + cleanup junction entries
     * - full: Delete queue item + orphan products + category cascade (children + empty ancestors) + orphan brands + AI jobs
     */
    public function delete_advanced($request): WP_REST_Response|WP_Error
    {
        global $wpdb;

        $id = (int) $request->get_param('id');
        $mode = $request->get_param('mode');
        $item = $this->repo->find($id);

        if (!$item) {
            return new WP_Error(
                'not_found',
                'Queue item not found',
                ['status' => 404]
            );
        }

        $result = [
            'success' => true,
            'keyword_deleted' => true,
            'products_deleted' => 0,
            'products_skipped' => 0,
            'categories_deleted' => 0,
            'categories_skipped' => 0,
            'ancestors_deleted' => 0,
            'brands_deleted' => 0,
            'junction_cleaned' => 0,
            'jobs_cleaned' => 0,
            'details' => [],
        ];

        // Get linked ASINs (handle already-decoded JSON)
        $asins = [];
        if (!empty($item['linked_asins'])) {
            $rawAsins = $item['linked_asins'];
            $asins = is_array($rawAsins) ? $rawAsins : (json_decode($rawAsins, true) ?: []);
        }

        $assignedCategoryId = (int) ($item['assigned_category_id'] ?? 0);
        $junctionTable = $wpdb->prefix . 'acms_category_products';
        $productsTable = $wpdb->prefix . 'acms_products';

        // Pre-fetch data needed for full cascade (before any deletions)
        $assignedCategoryParentId = 0;
        $affectedBrandNames = [];

        if ($mode === 'full') {
            // Get assigned category's parent_id for upward cascade
            if ($assignedCategoryId > 0) {
                $catTable = $wpdb->prefix . 'acms_categories';
                $assignedCategoryParentId = (int) $wpdb->get_var($wpdb->prepare(
                    "SELECT parent_id FROM {$catTable} WHERE id = %d",
                    $assignedCategoryId
                ));
            }

            // Collect brand names from linked products before they are deleted
            if (!empty($asins)) {
                $asinPlaceholders = implode(',', array_fill(0, count($asins), '%s'));
                $upperAsins = array_map('strtoupper', $asins);
                $affectedBrandNames = $wpdb->get_col($wpdb->prepare(
                    "SELECT DISTINCT brand FROM {$productsTable}
                     WHERE asin IN ({$asinPlaceholders})
                     AND brand IS NOT NULL AND brand != ''",
                    ...$upperAsins
                ));
            }
        }

        // Delete orphan products if requested
        if (in_array($mode, ['with_orphan_asins', 'full']) && !empty($asins)) {
            if (class_exists('AffiliateCMS\\Pro\\Repositories\\ProductRepository')) {
                $productRepo = \AffiliateCMS\Pro\Repositories\ProductRepository::instance();
                $deleteResult = $productRepo->deleteOrphansByAsins($asins);

                $result['products_deleted'] = $deleteResult['deleted'];
                $result['products_skipped'] = $deleteResult['skipped'];
                $result['details']['deleted_asins'] = $deleteResult['deleted_asins'] ?? [];
                $result['details']['skipped_asins'] = $deleteResult['skipped_asins'] ?? [];

                // Clean up junction entries for deleted products
                if (!empty($deleteResult['deleted_asins'])) {
                    // Products already deleted, so remove orphaned junction entries
                    if ($assignedCategoryId > 0) {
                        $result['junction_cleaned'] = (int) $wpdb->query($wpdb->prepare(
                            "DELETE FROM {$junctionTable}
                             WHERE category_id = %d
                             AND product_id NOT IN (SELECT id FROM {$productsTable})",
                            $assignedCategoryId
                        ));
                    }
                }
            }
        }

        // Full mode: cascade delete categories + ancestors + orphan brands + AI jobs
        if ($mode === 'full') {
            $jobsTable = $wpdb->prefix . 'acms_ai_jobs';
            $jobsTableExists = ($wpdb->get_var("SHOW TABLES LIKE '{$jobsTable}'") === $jobsTable);
            $deletedCategoryIds = [];
            $catRepo = null;

            // Phase A: Delete assigned category + all children (brand sub-cats)
            if ($assignedCategoryId > 0) {
                $otherQueueCount = (int) $wpdb->get_var($wpdb->prepare(
                    "SELECT COUNT(*) FROM {$wpdb->prefix}acms_cat_queue
                     WHERE assigned_category_id = %d AND id != %d",
                    $assignedCategoryId,
                    $id
                ));

                if ($otherQueueCount === 0) {
                    if (class_exists('AffiliateCMS\\Categories\\Repositories\\CategoryRepository')) {
                        $catRepo = new \AffiliateCMS\Categories\Repositories\CategoryRepository();

                        // Collect descendant IDs before deletion (for AI job cleanup)
                        $descendants = $catRepo->getDescendants($assignedCategoryId, 'all');
                        $deletedCategoryIds[] = $assignedCategoryId;
                        foreach ($descendants as $desc) {
                            $deletedCategoryIds[] = (int) $desc['id'];
                        }

                        // CASCADE delete: false = recursively delete children (not reassign)
                        $catRepo->delete($assignedCategoryId, false);
                        $result['categories_deleted'] = count($deletedCategoryIds);
                    }
                } else {
                    $result['categories_skipped'] = 1;
                    $result['details']['category_skip_reason'] = "Used by {$otherQueueCount} other queue item(s)";
                }
            }

            // Phase B: Cascade upward — delete empty ancestor categories
            if ($assignedCategoryParentId > 0 && $result['categories_deleted'] > 0) {
                if (class_exists('AffiliateCMS\\Categories\\Repositories\\CategoryRepository')) {
                    $catRepo = $catRepo ?? new \AffiliateCMS\Categories\Repositories\CategoryRepository();
                    $catTable = $wpdb->prefix . 'acms_categories';
                    $queueTable = $wpdb->prefix . 'acms_cat_queue';
                    $currentParentId = $assignedCategoryParentId;

                    while ($currentParentId > 0) {
                        $parentCategory = $catRepo->find($currentParentId);
                        if (!$parentCategory) {
                            break;
                        }

                        // Recount children (cache may be stale after cascade delete)
                        $actualChildCount = (int) $wpdb->get_var($wpdb->prepare(
                            "SELECT COUNT(*) FROM {$catTable} WHERE parent_id = %d",
                            $currentParentId
                        ));
                        if ($actualChildCount > 0) {
                            break;
                        }

                        // Stop if referenced by any queue item
                        $parentQueueCount = (int) $wpdb->get_var($wpdb->prepare(
                            "SELECT COUNT(*) FROM {$queueTable} WHERE assigned_category_id = %d",
                            $currentParentId
                        ));
                        if ($parentQueueCount > 0) {
                            break;
                        }

                        // Stop if category still has products assigned
                        $parentProductCount = (int) $wpdb->get_var($wpdb->prepare(
                            "SELECT COUNT(*) FROM {$junctionTable} WHERE category_id = %d",
                            $currentParentId
                        ));
                        if ($parentProductCount > 0) {
                            break;
                        }

                        // Safe to delete this ancestor
                        $nextParentId = (int) $parentCategory['parent_id'];
                        $deletedCategoryIds[] = $currentParentId;
                        $catRepo->delete($currentParentId, false);
                        $result['ancestors_deleted']++;

                        $currentParentId = $nextParentId;
                    }
                }
            }

            // Phase C: Delete orphan brands (brands with 0 products after deletion)
            if (!empty($affectedBrandNames) && class_exists('AffiliateCMS\\Pro\\Repositories\\BrandRepository')) {
                $brandRepo = \AffiliateCMS\Pro\Repositories\BrandRepository::instance();

                foreach ($affectedBrandNames as $brandName) {
                    $brand = $brandRepo->findByName($brandName);
                    if (!$brand) {
                        continue;
                    }

                    $brandId = (int) $brand['id'];
                    $brandRepo->updateProductCount($brandId);

                    // Re-fetch to get updated count
                    $brand = $brandRepo->find($brandId);
                    if (!$brand || (int) $brand['product_count'] > 0) {
                        continue;
                    }

                    // Brand has 0 products — delete it
                    $brandRepo->delete($brandId);
                    $result['brands_deleted']++;

                    if ($jobsTableExists) {
                        $result['jobs_cleaned'] += (int) $wpdb->query($wpdb->prepare(
                            "DELETE FROM {$jobsTable}
                             WHERE target_type = 'seo_brand' AND target_id = %s",
                            (string) $brandId
                        ));
                    }
                }

                $result['details']['brands_checked'] = count($affectedBrandNames);
            }

            // Phase D: Clean up AI jobs for queue item + all deleted categories
            if ($jobsTableExists) {
                $result['jobs_cleaned'] += (int) $wpdb->query($wpdb->prepare(
                    "DELETE FROM {$jobsTable}
                     WHERE target_type = 'queue' AND target_id = %s",
                    (string) $id
                ));

                if (!empty($deletedCategoryIds)) {
                    $catIdPlaceholders = implode(',', array_fill(0, count($deletedCategoryIds), '%s'));
                    $catIdStrings = array_map('strval', $deletedCategoryIds);
                    $result['jobs_cleaned'] += (int) $wpdb->query($wpdb->prepare(
                        "DELETE FROM {$jobsTable}
                         WHERE target_type = 'seo_category' AND target_id IN ({$catIdPlaceholders})",
                        ...$catIdStrings
                    ));
                }
            }
        }

        // Delete the queue item
        $this->repo->forceDelete($id);

        // Update category product_count if category still exists (for with_orphan_asins mode)
        if ($assignedCategoryId > 0 && $mode === 'with_orphan_asins') {
            if (class_exists('AffiliateCMS\\Categories\\Repositories\\CategoryRepository')) {
                $catTable = $wpdb->prefix . 'acms_categories';
                $catExists = $wpdb->get_var($wpdb->prepare(
                    "SELECT id FROM {$catTable} WHERE id = %d",
                    $assignedCategoryId
                ));
                if ($catExists) {
                    $repo = new \AffiliateCMS\Categories\Repositories\CategoryRepository();
                    $repo->updateProductCount($assignedCategoryId);
                }
            }
        }

        // Build message
        $messages = ['Keyword deleted'];
        if ($result['products_deleted'] > 0) {
            $messages[] = "{$result['products_deleted']} orphan product(s) deleted";
        }
        if ($result['products_skipped'] > 0) {
            $messages[] = "{$result['products_skipped']} product(s) skipped (in use)";
        }
        if ($result['categories_deleted'] > 0) {
            $catLabel = $result['categories_deleted'] === 1 ? 'category' : 'categories';
            $messages[] = "{$result['categories_deleted']} {$catLabel} deleted";
        }
        if ($result['ancestors_deleted'] > 0) {
            $ancLabel = $result['ancestors_deleted'] === 1 ? 'empty parent' : 'empty parents';
            $messages[] = "{$result['ancestors_deleted']} {$ancLabel} removed";
        }
        if ($result['categories_skipped'] > 0) {
            $messages[] = "Category skipped (in use by other keywords)";
        }
        if ($result['brands_deleted'] > 0) {
            $brandLabel = $result['brands_deleted'] === 1 ? 'orphan brand' : 'orphan brands';
            $messages[] = "{$result['brands_deleted']} {$brandLabel} deleted";
        }
        if ($result['junction_cleaned'] > 0) {
            $messages[] = "{$result['junction_cleaned']} junction entries cleaned";
        }
        if ($result['jobs_cleaned'] > 0) {
            $messages[] = "{$result['jobs_cleaned']} AI job(s) cleaned";
        }

        $result['message'] = implode(', ', $messages);

        return new WP_REST_Response($result);
    }

    /**
     * GET /queue/{id}/log - Get processing log for queue item
     */
    public function get_processing_log($request): WP_REST_Response
    {
        $id = (int) $request->get_param('id');
        $log = QueueProcessor::getProcessingLog($id);

        return new WP_REST_Response([
            'success' => true,
            'log' => $log
        ]);
    }

    /**
     * POST /queue/monitor - Run queue monitor to check scrape progress
     *
     * This checks items waiting for scrape and marks them ready for AI
     * when scrape progress reaches threshold (default 50%).
     */
    public function run_monitor(): WP_REST_Response
    {
        $monitor = CategoryQueueMonitor::instance();
        $result = $monitor->runManually();

        return new WP_REST_Response($result);
    }

    /**
     * POST /queue/{id}/assign-category - Assign category using majority voting
     *
     * This bypasses AI and uses product category_path majority voting
     */
    public function assign_category(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $id = (int) $request->get_param('id');

        $assigner = CategoryPathAssigner::instance();
        $result = $assigner->triggerManually($id);

        if (!$result['success']) {
            return new WP_Error(
                'assignment_failed',
                $result['message'],
                ['status' => 400]
            );
        }

        return new WP_REST_Response([
            'success' => true,
            'message' => $result['message'],
            'data' => [
                'category_id' => $result['category_id'] ?? null,
                'category_path' => $result['category_path'] ?? null,
            ],
        ]);
    }

    /**
     * GET /queue/waiting - Get items waiting for scrape with progress info
     */
    public function get_waiting_items(): WP_REST_Response
    {
        $monitor = CategoryQueueMonitor::instance();
        $items = $monitor->getWaitingItems();

        return new WP_REST_Response([
            'success' => true,
            'items' => $items,
            'total' => count($items),
        ]);
    }

    /**
     * Cleanup AI jobs when resetting a queue item's AI status
     *
     * @param int $queueId Queue item ID
     * @param array $item Queue item data
     */
    private function cleanupAiJobsForQueue(int $queueId, array $item): void
    {
        global $wpdb;
        $jobsTable = $wpdb->prefix . 'acms_ai_jobs';

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("[ACMS QueueController] cleanupAiJobsForQueue called for queue {$queueId}");
        }

        // Check if AI jobs table exists (affiliatecms-ai plugin) - use simpler check
        $tableCheck = $wpdb->get_var("SHOW TABLES LIKE '{$jobsTable}'");
        if (empty($tableCheck)) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("[ACMS QueueController] AI jobs table not found: {$jobsTable}");
            }
            return;
        }

        // 1. Delete ALL standardize_categories jobs for this queue (including completed)
        // We delete all statuses because when resetting, we want to start completely fresh
        $deleted = $wpdb->query($wpdb->prepare(
            "DELETE FROM {$jobsTable}
             WHERE type = 'standardize_categories'
             AND target_type = 'queue'
             AND target_id = %s",
            (string) $queueId
        ));

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("[ACMS QueueController] Deleted {$deleted} standardize_categories jobs for queue {$queueId} (all statuses)");
        }

        // 2. If there's an assigned category, clean up its content generation jobs
        $assignedCategoryId = (int) ($item['assigned_category_id'] ?? 0);
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("[ACMS QueueController] assigned_category_id: {$assignedCategoryId}");
        }
        if ($assignedCategoryId > 0) {
            // Delete ALL content generation jobs for this category (including completed)
            $deletedContent = $wpdb->query($wpdb->prepare(
                "DELETE FROM {$jobsTable}
                 WHERE type = 'generate_seo_category'
                 AND target_type = 'seo_category'
                 AND target_id = %s",
                (string) $assignedCategoryId
            ));

            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("[ACMS QueueController] Deleted {$deletedContent} generate_seo_category jobs for category {$assignedCategoryId} (all statuses)");
            }

            // Reset category content status if it was generating
            $categoriesTable = $wpdb->prefix . 'acms_categories';
            $wpdb->update(
                $categoriesTable,
                [
                    'content_status' => 'empty',
                    'ai_generating_at' => null,
                    'ai_error_message' => null,
                ],
                [
                    'id' => $assignedCategoryId,
                    'content_status' => 'ai_generating',  // Only reset if stuck
                ],
                ['%s', '%s', '%s'],
                ['%d', '%s']
            );
        }

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("[ACMS QueueController] cleanupAiJobsForQueue completed for queue {$queueId}");
        }
    }

    /**
     * POST /queue/{id}/link-products - Re-link products to assigned category
     *
     * Use this when category is assigned but products aren't linked (CATEGORIES = 0)
     */
    public function link_products(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        global $wpdb;

        $id = (int) $request->get_param('id');
        $item = $this->repo->find($id);

        if (!$item) {
            return new WP_Error('not_found', 'Queue item not found', ['status' => 404]);
        }

        $categoryId = (int) ($item['assigned_category_id'] ?? 0);
        if ($categoryId <= 0) {
            return new WP_Error('no_category', 'No category assigned. Run "Assign Category" first.', ['status' => 400]);
        }

        $rawAsins = $item['linked_asins'] ?? '[]';
        $linkedAsins = is_array($rawAsins) ? $rawAsins : json_decode($rawAsins, true);
        if (empty($linkedAsins)) {
            return new WP_Error('no_asins', 'No linked ASINs found', ['status' => 400]);
        }

        // Get product IDs from ASINs
        $productsTable = $wpdb->prefix . 'acms_products';
        $placeholders = implode(',', array_fill(0, count($linkedAsins), '%s'));
        $products = $wpdb->get_results($wpdb->prepare(
            "SELECT id, asin FROM {$productsTable} WHERE asin IN ({$placeholders}) AND status = 'scraped'",
            ...$linkedAsins
        ), ARRAY_A);

        if (empty($products)) {
            return new WP_Error('no_scraped_products', 'No scraped products found. Products may not be scraped yet.', ['status' => 400]);
        }

        // Link products to category and append to custom_category_paths
        $categoryRepo = new \AffiliateCMS\Categories\Repositories\CategoryRepository();
        $productRepo = \AffiliateCMS\Pro\Repositories\ProductRepository::instance();
        $linkedCount = 0;
        $categoryPath = $item['custom_category_path'] ?? null;

        foreach ($products as $index => $product) {
            $isPrimary = ($index === 0);
            $added = $categoryRepo->addProduct($categoryId, (int) $product['id'], $isPrimary);
            if ($added) {
                $linkedCount++;
            }

            // Append path (safe merge, no overwrite)
            if ($categoryPath) {
                $productRepo->appendCategoryPaths((int) $product['id'], [$categoryPath]);
            }
        }

        // Update product_count on the category
        $categoryRepo->updateProductCount($categoryId);

        return new WP_REST_Response([
            'success' => true,
            'message' => "Linked {$linkedCount} products to category {$categoryId}",
            'data' => [
                'linked_count' => $linkedCount,
                'category_id' => $categoryId,
                'total_products' => count($products),
            ],
        ]);
    }

    /**
     * POST /queue/bulk-sync-links - Re-link scraped products to assigned categories
     *
     * Fixes orphaned products that were scraped after CategoryPathAssigner ran.
     * Accepts optional 'ids' array to sync specific items, otherwise syncs all.
     */
    public function bulk_sync_links(WP_REST_Request $request): WP_REST_Response
    {
        global $wpdb;

        $ids = $request->get_param('ids');
        $queueTable = $wpdb->prefix . 'acms_cat_queue';
        $productsTable = $wpdb->prefix . 'acms_products';

        // Get queue items with assigned categories
        if (!empty($ids) && is_array($ids)) {
            $placeholders = implode(',', array_fill(0, count($ids), '%d'));
            $items = $wpdb->get_results($wpdb->prepare(
                "SELECT id, linked_asins, assigned_category_id, custom_category_path
                 FROM {$queueTable}
                 WHERE assigned_category_id > 0
                   AND id IN ({$placeholders})",
                ...array_map('intval', $ids)
            ), ARRAY_A);
        } else {
            $items = $wpdb->get_results(
                "SELECT id, linked_asins, assigned_category_id, custom_category_path
                 FROM {$queueTable}
                 WHERE assigned_category_id > 0
                   AND linked_asins IS NOT NULL
                   AND linked_asins != '[]'",
                ARRAY_A
            );
        }

        if (empty($items)) {
            return new WP_REST_Response([
                'success' => true,
                'message' => 'No queue items with assigned categories found',
                'data' => ['items_checked' => 0, 'products_linked' => 0],
            ]);
        }

        $categoryRepo = new \AffiliateCMS\Categories\Repositories\CategoryRepository();
        $productRepo = \AffiliateCMS\Pro\Repositories\ProductRepository::instance();

        $totalLinked = 0;
        $itemsSynced = 0;

        foreach ($items as $item) {
            $linkedAsins = is_array($item['linked_asins'])
                ? $item['linked_asins']
                : json_decode($item['linked_asins'], true);

            if (empty($linkedAsins) || !is_array($linkedAsins)) {
                continue;
            }

            $categoryId = (int) $item['assigned_category_id'];
            $categoryPath = $item['custom_category_path'] ?? null;

            // Get scraped product IDs for these ASINs
            $placeholders = implode(',', array_fill(0, count($linkedAsins), '%s'));
            $products = $wpdb->get_results($wpdb->prepare(
                "SELECT id, asin FROM {$productsTable} WHERE asin IN ({$placeholders}) AND status = 'scraped'",
                ...$linkedAsins
            ), ARRAY_A);

            if (empty($products)) {
                continue;
            }

            $linkedInItem = 0;
            foreach ($products as $product) {
                $added = $categoryRepo->addProduct($categoryId, (int) $product['id'], false);
                if ($added) {
                    $linkedInItem++;
                }
                if ($categoryPath) {
                    $productRepo->appendCategoryPaths((int) $product['id'], [$categoryPath]);
                }
            }

            if ($linkedInItem > 0) {
                $itemsSynced++;
                $totalLinked += $linkedInItem;
            }
        }

        return new WP_REST_Response([
            'success' => true,
            'message' => "Synced {$totalLinked} product links across {$itemsSynced} queue items",
            'data' => [
                'items_checked' => count($items),
                'items_synced' => $itemsSynced,
                'products_linked' => $totalLinked,
            ],
        ]);
    }

    /**
     * POST /queue/{id}/generate-content - Trigger Category AI content generation
     *
     * Creates an AI job to generate content for the assigned category
     */
    public function generate_content(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        global $wpdb;

        $id = (int) $request->get_param('id');
        $item = $this->repo->find($id);

        if (!$item) {
            return new WP_Error('not_found', 'Queue item not found', ['status' => 404]);
        }

        $categoryId = (int) ($item['assigned_category_id'] ?? 0);
        if ($categoryId <= 0) {
            return new WP_Error('no_category', 'No category assigned. Run "Assign Category" first.', ['status' => 400]);
        }

        // Check if category has products
        $categoriesTable = $wpdb->prefix . 'acms_categories';
        $category = $wpdb->get_row($wpdb->prepare(
            "SELECT id, name, slug, product_count, content_status FROM {$categoriesTable} WHERE id = %d",
            $categoryId
        ), ARRAY_A);

        if (!$category) {
            return new WP_Error('category_not_found', 'Assigned category not found in database', ['status' => 404]);
        }

        if ((int) $category['product_count'] <= 0) {
            return new WP_Error('no_products', 'Category has no products. Run "Link Products" first.', ['status' => 400]);
        }

        try {
            $jobsTable = $wpdb->prefix . 'acms_ai_jobs';

            // Step 1: Cancel any existing pending/processing jobs for this category
            // This unblocks the duplicate check in createCategoryAiJob()
            $cancelledJobs = $wpdb->query($wpdb->prepare(
                "UPDATE {$jobsTable}
                 SET status = 'failed', error_message = 'Cancelled: manual re-trigger via Generate Content'
                 WHERE type = 'generate_seo_category'
                 AND target_id = %s
                 AND status IN ('pending', 'processing')",
                (string) $categoryId
            ));

            // Step 2: Reset category status to allow re-generation
            $wpdb->update(
                $categoriesTable,
                [
                    'content_status' => 'empty',
                    'ai_generating_at' => null,
                    'ai_error_message' => null,
                ],
                ['id' => $categoryId]
            );

            // Step 3: Reset queue item ai_status so it re-enters the pipeline
            $queueTable = $wpdb->prefix . 'acms_cat_queue';
            $wpdb->update(
                $queueTable,
                ['ai_status' => 'category_assigned'],
                ['id' => $id],
                ['%s'],
                ['%d']
            );

            // Step 4: Build category path for the hook
            $categoryPath = $category['name'];
            if (class_exists(\AffiliateCMS\Categories\Repositories\CategoryRepository::class)) {
                $catRepo = new \AffiliateCMS\Categories\Repositories\CategoryRepository();
                $ancestors = $catRepo->getAncestors($categoryId);
                if (!empty($ancestors)) {
                    $names = array_column($ancestors, 'name');
                    $names[] = $category['name'];
                    $categoryPath = implode(' > ', $names);
                }
            }

            // Step 5: Fire acms_category_assigned hook → Bootstrap.onCategoryAssigned()
            // This creates job + schedules AS immediately (with our new fix)
            do_action('acms_category_assigned', $id, $categoryId, $categoryPath);

            return new WP_REST_Response([
                'success' => true,
                'message' => 'Category AI content generation triggered for: ' . $category['name'],
                'data' => [
                    'category_id' => $categoryId,
                    'category_name' => $category['name'],
                    'cancelled_old_jobs' => (int) $cancelledJobs,
                    'queue_ai_status' => 'category_assigned → generating_content',
                ],
            ]);
        } catch (\Exception $e) {
            return new WP_Error('cron_error', 'Error triggering content generation: ' . $e->getMessage(), ['status' => 500]);
        }
    }

    /**
     * GET /queue/{id}/diagnose - Get diagnostic info about queue item state
     *
     * Returns detailed information about what's wrong and what steps are needed
     */
    public function diagnose_item(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        global $wpdb;

        $id = (int) $request->get_param('id');
        $item = $this->repo->find($id);

        if (!$item) {
            return new WP_Error('not_found', 'Queue item not found', ['status' => 404]);
        }

        $diagnosis = [
            'queue_id' => $id,
            'keyword' => $item['keyword'],
            'status' => $item['status'],
            'ai_status' => $item['ai_status'],
            'issues' => [],
            'next_actions' => [],
        ];

        // Check linked ASINs (handle already-decoded JSON)
        $rawAsins = $item['linked_asins'] ?? '[]';
        $linkedAsins = is_array($rawAsins) ? $rawAsins : json_decode($rawAsins, true);
        $diagnosis['linked_asins_count'] = count($linkedAsins);

        if (empty($linkedAsins)) {
            $diagnosis['issues'][] = 'No linked ASINs found';
            $diagnosis['next_actions'][] = 'Run "Process" to search for products';
        }

        // Check scrape progress
        $scrapeProgress = (int) ($item['scrape_progress'] ?? 0);
        $diagnosis['scrape_progress'] = $scrapeProgress;

        if (!empty($linkedAsins)) {
            // Count scraped products
            $productsTable = $wpdb->prefix . 'acms_products';
            $placeholders = implode(',', array_fill(0, count($linkedAsins), '%s'));
            $scrapedCount = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$productsTable} WHERE asin IN ({$placeholders}) AND status = 'scraped'",
                ...$linkedAsins
            ));
            $diagnosis['scraped_products'] = $scrapedCount;
            $diagnosis['total_products'] = count($linkedAsins);

            if ($scrapedCount === 0) {
                $diagnosis['issues'][] = 'No products have been scraped yet';
                $diagnosis['next_actions'][] = 'Wait for scraping to complete or trigger scrape manually';
            } elseif ($scrapedCount < count($linkedAsins)) {
                $diagnosis['issues'][] = "Only {$scrapedCount}/" . count($linkedAsins) . " products scraped";
            }
        }

        // Check assigned category
        $categoryId = (int) ($item['assigned_category_id'] ?? 0);
        $diagnosis['assigned_category_id'] = $categoryId;

        if ($categoryId <= 0) {
            $diagnosis['issues'][] = 'No category assigned';
            $diagnosis['next_actions'][] = 'Run "Assign Category" to assign using majority voting';
        } else {
            // Check category details
            $categoriesTable = $wpdb->prefix . 'acms_categories';
            $category = $wpdb->get_row($wpdb->prepare(
                "SELECT id, name, slug, product_count, content_status, content_intro FROM {$categoriesTable} WHERE id = %d",
                $categoryId
            ), ARRAY_A);

            if (!$category) {
                $diagnosis['issues'][] = "Assigned category ID {$categoryId} does not exist in database";
                $diagnosis['next_actions'][] = 'Run "Assign Category" to create the category';
            } else {
                $diagnosis['category'] = [
                    'id' => $category['id'],
                    'name' => $category['name'],
                    'slug' => $category['slug'],
                    'product_count' => (int) $category['product_count'],
                    'content_status' => $category['content_status'],
                    'has_content' => !empty($category['content_intro']),
                ];

                if ((int) $category['product_count'] <= 0) {
                    $diagnosis['issues'][] = 'Category has 0 products linked';
                    $diagnosis['next_actions'][] = 'Run "Link Products" to link products to the category';
                }

                if ($category['content_status'] === 'empty' && empty($category['content_intro'])) {
                    $diagnosis['issues'][] = 'Category has no AI-generated content';
                    $diagnosis['next_actions'][] = 'Run "Generate Content" to create AI content';
                } elseif ($category['content_status'] === 'ai_generating') {
                    $diagnosis['issues'][] = 'Category content is currently being generated';
                } elseif ($category['content_status'] === 'ai_generated') {
                    // No issue - content generated
                }
            }
        }

        // Check custom_category_path
        if (!empty($item['custom_category_path'])) {
            $diagnosis['custom_category_path'] = $item['custom_category_path'];
        }

        // Summary
        if (empty($diagnosis['issues'])) {
            $diagnosis['summary'] = 'All checks passed - queue item is complete';
        } else {
            $diagnosis['summary'] = count($diagnosis['issues']) . ' issue(s) found';
        }

        return new WP_REST_Response([
            'success' => true,
            'data' => $diagnosis,
        ]);
    }

    /**
     * POST /queue/{id}/update-asins - Re-run search and update ASINs
     *
     * Modes:
     * - append: keep existing ASINs, add newly found ones
     * - append_with_brands: same as append + create brand sub-categories
     * - replace: remove old product links, replace with fresh search results
     */
    public function update_asins(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        global $wpdb;

        $id = (int) $request->get_param('id');
        $mode = $request->get_param('mode');
        $item = $this->repo->find($id);

        if (!$item) {
            return new WP_Error('not_found', 'Queue item not found', ['status' => 404]);
        }

        if (empty($item['keyword'])) {
            return new WP_Error('no_keyword', 'Queue item has no keyword', ['status' => 400]);
        }

        $validStatuses = ['searched', 'ready_for_ai', 'completed'];
        if (!in_array($item['status'], $validStatuses, true)) {
            return new WP_Error(
                'invalid_status',
                'Item must be searched/ready_for_ai/completed to update ASINs (current: ' . $item['status'] . ')',
                ['status' => 400]
            );
        }

        // Check SearchService availability
        if (!class_exists('AffiliateCMS\\Pro\\Services\\SearchService')) {
            return new WP_Error('no_search_service', 'SearchService not available', ['status' => 500]);
        }

        // Run Crawlbase search
        $keyword = $item['keyword'];
        $searchLimitOverride = (int) $request->get_param('search_limit');
        $limit = $searchLimitOverride > 0 ? $searchLimitOverride : (int) ($item['search_limit'] ?? 20);
        $searchPagesOverride = (int) $request->get_param('search_pages');
        $maxPages = $searchPagesOverride > 0 ? $searchPagesOverride : (int) ($item['max_search_pages'] ?? 3);
        $domain = $item['search_domain'] ?? 'amazon.com';

        $searchService = \AffiliateCMS\Pro\Services\SearchService::instance();
        $searchResult = $searchService->searchAsins($keyword, $limit, $maxPages, $domain);

        if (empty($searchResult['asins'])) {
            $error = $searchService->getLastError() ?? 'No products found';
            return new WP_Error('search_failed', "No products found for '{$keyword}': {$error}", ['status' => 400]);
        }

        // Parse existing ASINs
        $rawAsins = $item['linked_asins'] ?? null;
        $existingAsins = $rawAsins
            ? (is_array($rawAsins) ? $rawAsins : json_decode($rawAsins, true))
            : [];

        $categoryId = (int) ($item['assigned_category_id'] ?? 0);

        // Compute final ASIN list based on mode
        if ($mode === 'replace') {
            // Remove old product links from category
            if ($categoryId > 0) {
                $catProductsTable = $wpdb->prefix . 'acms_category_products';
                $wpdb->delete($catProductsTable, ['category_id' => $categoryId]);
            }
            $newAsins = $searchResult['asins'];
            $finalAsins = $searchResult['asins'];
        } else {
            // append or append_with_brands
            $newAsins = array_values(array_diff($searchResult['asins'], $existingAsins));
            $finalAsins = array_values(array_unique(array_merge($existingAsins, $searchResult['asins'])));
        }

        // Index search products by ASIN
        $searchProducts = [];
        foreach ($searchResult['products'] ?? [] as $product) {
            if (!empty($product['asin'])) {
                $searchProducts[$product['asin']] = $product;
            }
        }
        $provider = $searchResult['provider'] ?? null;

        // Save new products to acms_products
        $productsSaved = 0;
        $productsSkipped = 0;

        if (class_exists('AffiliateCMS\\Pro\\Repositories\\ProductRepository')) {
            $productRepo = \AffiliateCMS\Pro\Repositories\ProductRepository::instance();

            foreach ($newAsins as $asin) {
                $existing = $productRepo->findByAsin($asin);
                if ($existing) {
                    $productsSkipped++;
                    continue;
                }

                $searchData = $searchProducts[$asin] ?? null;
                if ($searchData !== null) {
                    $productRepo->createOrUpdateFromSearch($asin, $searchData, $provider);
                } else {
                    $productRepo->create([
                        'asin' => $asin,
                        'status' => 'pending',
                        'title' => 'Pending scrape...',
                        'domain' => $domain,
                    ]);
                }
                $productsSaved++;
            }
        }

        // Update queue item
        $this->repo->update($id, [
            'linked_asins' => wp_json_encode($finalAsins),
            'products_found' => count($finalAsins),
            'search_status' => 'completed',
        ]);

        // Link products to assigned category
        $linkedCount = 0;
        if ($categoryId > 0) {
            $categoryRepo = new \AffiliateCMS\Categories\Repositories\CategoryRepository();
            $productsTable = $wpdb->prefix . 'acms_products';

            $placeholders = implode(',', array_fill(0, count($finalAsins), '%s'));
            $scrapedProducts = $wpdb->get_results($wpdb->prepare(
                "SELECT id, asin FROM {$productsTable} WHERE asin IN ({$placeholders})",
                ...$finalAsins
            ), ARRAY_A);

            $categoryPath = $item['custom_category_path'] ?? null;
            foreach ($scrapedProducts as $index => $product) {
                $isPrimary = ($index === 0);
                if ($categoryRepo->addProduct($categoryId, (int) $product['id'], $isPrimary)) {
                    $linkedCount++;
                }
                if ($categoryPath && class_exists('AffiliateCMS\\Pro\\Repositories\\ProductRepository')) {
                    $productRepo->appendCategoryPaths((int) $product['id'], [$categoryPath]);
                }
            }
            $categoryRepo->updateProductCount($categoryId);
        }

        // Brand category creation for append_with_brands mode
        $brandCatsCreated = 0;
        if ($mode === 'append_with_brands' && $categoryId > 0) {
            if (class_exists('AffiliateCMS\\Categories\\Core\\BrandCategoryAiCron')) {
                try {
                    $brandCron = \AffiliateCMS\Categories\Core\BrandCategoryAiCron::instance();
                    $createdIds = $brandCron->createBrandCategoriesForParent($categoryId);
                    $brandCatsCreated = count($createdIds);

                    // Spawn category AI workers for new brand-categories
                    if (!empty($createdIds) && class_exists('AffiliateCMS\\Categories\\Core\\CategoryAiCron')) {
                        $catCron = \AffiliateCMS\Categories\Core\CategoryAiCron::instance();
                        $catCron->spawnCategoryAiWorkers();
                    }
                } catch (\Throwable $e) {
                    error_log("[ACMS QueueController] update_asins brand creation error: " . $e->getMessage());
                }
            }
        }

        // Trigger scrape for new pending products
        if ($productsSaved > 0) {
            try {
                $scrapeRequest = new \WP_REST_Request('POST', '/acms/v1/automation/scrape');
                $scrapeRequest->set_param('_wp_cron', true);
                rest_do_request($scrapeRequest);
            } catch (\Throwable $e) {
                // Non-fatal — scrape will happen on next cron run
            }
        }

        error_log("[ACMS QueueController] update_asins #{$id} ({$keyword}): mode={$mode}, searched=" . count($searchResult['asins']) . ", new=" . count($newAsins) . ", final=" . count($finalAsins) . ", saved={$productsSaved}");

        return new WP_REST_Response([
            'success' => true,
            'message' => "Updated ASINs for '{$keyword}'",
            'data' => [
                'mode' => $mode,
                'searched' => count($searchResult['asins']),
                'new_asins' => count($newAsins),
                'existing_kept' => $mode === 'replace' ? 0 : count($existingAsins),
                'final_count' => count($finalAsins),
                'products_saved' => $productsSaved,
                'products_skipped' => $productsSkipped,
                'linked_to_category' => $linkedCount,
                'brand_categories_created' => $brandCatsCreated,
            ],
        ]);
    }

    /**
     * POST /queue/bulk-update-asins - Start background bulk update
     */
    public function bulk_update_asins_start(\WP_REST_Request $request): \WP_REST_Response|\WP_Error
    {
        $ids = $request->get_param('ids');
        $mode = $request->get_param('mode');
        $searchPages = (int) $request->get_param('search_pages');
        $searchLimit = (int) $request->get_param('search_limit');

        if (empty($ids)) {
            return new \WP_Error('no_ids', 'No queue item IDs provided', ['status' => 400]);
        }

        // Check if another batch is already running
        $worker = \AffiliateCMS\Categories\Core\BulkUpdateWorker::instance();
        $runningBatchId = $worker->hasRunningBatch();
        if ($runningBatchId) {
            return new \WP_Error(
                'batch_running',
                'Another bulk update is already running. Wait for it to finish or cancel it first.',
                ['status' => 409, 'batch_id' => $runningBatchId]
            );
        }

        // Validate IDs
        $validIds = [];
        $validStatuses = ['searched', 'ready_for_ai', 'completed'];
        foreach ($ids as $id) {
            $item = $this->repo->find((int) $id);
            if ($item && in_array($item['status'], $validStatuses, true) && !empty($item['keyword'])) {
                $validIds[] = (int) $id;
            }
        }

        if (empty($validIds)) {
            return new \WP_Error('no_valid_ids', 'No valid queue items found (must be searched/ready_for_ai/completed with a keyword)', ['status' => 400]);
        }

        $batchId = $worker->createBatch($validIds, $mode, $searchPages, $searchLimit);

        return new \WP_REST_Response([
            'success'  => true,
            'batch_id' => $batchId,
            'total'    => count($validIds),
            'skipped'  => count($ids) - count($validIds),
            'message'  => 'Bulk update started in background',
        ], 202);
    }

    /**
     * GET /queue/bulk-update-status - Poll batch progress
     */
    public function bulk_update_asins_status(\WP_REST_Request $request): \WP_REST_Response|\WP_Error
    {
        $batchId = $request->get_param('batch_id');

        $worker = \AffiliateCMS\Categories\Core\BulkUpdateWorker::instance();
        $status = $worker->getStatus($batchId);

        if (!$status) {
            return new \WP_Error('not_found', 'Batch not found', ['status' => 404]);
        }

        return new \WP_REST_Response([
            'success' => true,
            'data'    => $status,
        ]);
    }

    /**
     * POST /queue/bulk-update-cancel - Cancel a running batch
     */
    public function bulk_update_asins_cancel(\WP_REST_Request $request): \WP_REST_Response|\WP_Error
    {
        $batchId = $request->get_param('batch_id');

        $worker = \AffiliateCMS\Categories\Core\BulkUpdateWorker::instance();
        $cancelled = $worker->cancelBatch($batchId);

        if (!$cancelled) {
            return new \WP_Error('cannot_cancel', 'Batch not found or already finished', ['status' => 400]);
        }

        return new \WP_REST_Response([
            'success' => true,
            'message' => 'Batch cancelled',
        ]);
    }
}
