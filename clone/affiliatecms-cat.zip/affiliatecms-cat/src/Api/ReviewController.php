<?php
/**
 * Review REST API Controller
 *
 * Endpoints for product reviews
 *
 * @package AffiliateCMS\Categories
 */

declare(strict_types=1);

namespace AffiliateCMS\Categories\Api;

use AffiliateCMS\Categories\Repositories\ReviewRepository;
use WP_REST_Controller;
use WP_REST_Request;
use WP_REST_Response;
use WP_Error;

class ReviewController extends WP_REST_Controller
{
    protected $namespace = 'acms-cat/v1';
    protected $rest_base = 'reviews';

    private ReviewRepository $repo;

    public function __construct()
    {
        $this->repo = new ReviewRepository();
    }

    /**
     * Register routes
     */
    public function register_routes(): void
    {
        // GET /reviews - List reviews (admin)
        register_rest_route($this->namespace, '/' . $this->rest_base, [
            [
                'methods' => 'GET',
                'callback' => [$this, 'get_items'],
                'permission_callback' => [$this, 'admin_permission'],
                'args' => [
                    'status' => [
                        'type' => 'string',
                        'enum' => ['pending', 'approved', 'spam', 'trash'],
                    ],
                    'product_id' => [
                        'type' => 'integer',
                    ],
                    'asin' => [
                        'type' => 'string',
                    ],
                    'search' => [
                        'type' => 'string',
                    ],
                    'page' => [
                        'type' => 'integer',
                        'default' => 1,
                        'minimum' => 1,
                    ],
                    'per_page' => [
                        'type' => 'integer',
                        'default' => 20,
                        'minimum' => 1,
                        'maximum' => 100,
                    ],
                ],
            ],
        ]);

        // GET /reviews/product/{id} - Get reviews for a product (public)
        register_rest_route($this->namespace, '/' . $this->rest_base . '/product/(?P<id>\d+)', [
            [
                'methods' => 'GET',
                'callback' => [$this, 'get_product_reviews'],
                'permission_callback' => '__return_true',
                'args' => [
                    'id' => [
                        'required' => true,
                        'type' => 'integer',
                    ],
                    'page' => [
                        'type' => 'integer',
                        'default' => 1,
                        'minimum' => 1,
                    ],
                    'per_page' => [
                        'type' => 'integer',
                        'default' => 10,
                        'minimum' => 1,
                        'maximum' => 50,
                    ],
                ],
            ],
        ]);

        // GET /reviews/asin/{asin} - Get reviews by ASIN (public)
        // Note: ASIN pattern allows alphanumeric (Amazon ASINs can be mixed case)
        register_rest_route($this->namespace, '/' . $this->rest_base . '/asin/(?P<asin>[A-Za-z0-9]+)', [
            [
                'methods' => 'GET',
                'callback' => [$this, 'get_asin_reviews'],
                'permission_callback' => '__return_true',
                'args' => [
                    'asin' => [
                        'required' => true,
                        'type' => 'string',
                        'pattern' => '^[A-Za-z0-9]{10}$',
                    ],
                    'page' => [
                        'type' => 'integer',
                        'default' => 1,
                        'minimum' => 1,
                    ],
                    'per_page' => [
                        'type' => 'integer',
                        'default' => 10,
                        'minimum' => 1,
                        'maximum' => 50,
                    ],
                ],
            ],
        ]);

        // GET /reviews/stats/{id} - Get review stats for a product (public)
        register_rest_route($this->namespace, '/' . $this->rest_base . '/stats/(?P<id>\d+)', [
            [
                'methods' => 'GET',
                'callback' => [$this, 'get_product_stats'],
                'permission_callback' => '__return_true',
                'args' => [
                    'id' => [
                        'required' => true,
                        'type' => 'integer',
                    ],
                ],
            ],
        ]);

        // POST /reviews - Create a review (public, with rate limiting)
        register_rest_route($this->namespace, '/' . $this->rest_base, [
            [
                'methods' => 'POST',
                'callback' => [$this, 'create_item'],
                'permission_callback' => '__return_true',
                'args' => [
                    'product_id' => [
                        'required' => true,
                        'type' => 'integer',
                    ],
                    'asin' => [
                        'required' => true,
                        'type' => 'string',
                    ],
                    'author_name' => [
                        'required' => true,
                        'type' => 'string',
                        'minLength' => 2,
                        'maxLength' => 100,
                    ],
                    'author_email' => [
                        'type' => 'string',
                        'format' => 'email',
                    ],
                    'rating' => [
                        'required' => true,
                        'type' => 'integer',
                        'minimum' => 1,
                        'maximum' => 5,
                    ],
                    'title' => [
                        'type' => 'string',
                        'maxLength' => 255,
                    ],
                    'content' => [
                        'required' => true,
                        'type' => 'string',
                        'minLength' => 20,
                        'maxLength' => 5000,
                    ],
                    'pros' => [
                        'type' => 'array',
                        'items' => ['type' => 'string'],
                    ],
                    'cons' => [
                        'type' => 'array',
                        'items' => ['type' => 'string'],
                    ],
                ],
            ],
        ]);

        // GET /reviews/{id} - Get single review
        register_rest_route($this->namespace, '/' . $this->rest_base . '/(?P<id>\d+)', [
            [
                'methods' => 'GET',
                'callback' => [$this, 'get_item'],
                'permission_callback' => [$this, 'admin_permission'],
                'args' => [
                    'id' => [
                        'required' => true,
                        'type' => 'integer',
                    ],
                ],
            ],
        ]);

        // PUT /reviews/{id} - Update review (admin)
        register_rest_route($this->namespace, '/' . $this->rest_base . '/(?P<id>\d+)', [
            [
                'methods' => 'PUT',
                'callback' => [$this, 'update_item'],
                'permission_callback' => [$this, 'admin_permission'],
                'args' => [
                    'id' => [
                        'required' => true,
                        'type' => 'integer',
                    ],
                    'status' => [
                        'type' => 'string',
                        'enum' => ['pending', 'approved', 'spam', 'trash'],
                    ],
                    'admin_notes' => [
                        'type' => 'string',
                    ],
                ],
            ],
        ]);

        // DELETE /reviews/{id} - Delete review (admin)
        register_rest_route($this->namespace, '/' . $this->rest_base . '/(?P<id>\d+)', [
            [
                'methods' => 'DELETE',
                'callback' => [$this, 'delete_item'],
                'permission_callback' => [$this, 'admin_permission'],
                'args' => [
                    'id' => [
                        'required' => true,
                        'type' => 'integer',
                    ],
                ],
            ],
        ]);

        // POST /reviews/{id}/helpful - Mark as helpful (public)
        register_rest_route($this->namespace, '/' . $this->rest_base . '/(?P<id>\d+)/helpful', [
            [
                'methods' => 'POST',
                'callback' => [$this, 'mark_helpful'],
                'permission_callback' => '__return_true',
                'args' => [
                    'id' => [
                        'required' => true,
                        'type' => 'integer',
                    ],
                    'helpful' => [
                        'type' => 'boolean',
                        'default' => true,
                    ],
                ],
            ],
        ]);

        // POST /reviews/bulk - Bulk actions (admin)
        register_rest_route($this->namespace, '/' . $this->rest_base . '/bulk', [
            [
                'methods' => 'POST',
                'callback' => [$this, 'bulk_action'],
                'permission_callback' => [$this, 'admin_permission'],
                'args' => [
                    'action' => [
                        'required' => true,
                        'type' => 'string',
                        'enum' => ['approve', 'pending', 'spam', 'trash', 'delete'],
                    ],
                    'ids' => [
                        'required' => true,
                        'type' => 'array',
                        'items' => ['type' => 'integer'],
                    ],
                ],
            ],
        ]);

        // GET /reviews/counts - Get status counts (admin)
        register_rest_route($this->namespace, '/' . $this->rest_base . '/counts', [
            [
                'methods' => 'GET',
                'callback' => [$this, 'get_counts'],
                'permission_callback' => [$this, 'admin_permission'],
            ],
        ]);
    }

    /**
     * Check admin permission
     */
    public function admin_permission(): bool
    {
        return current_user_can('manage_options');
    }

    /**
     * GET /reviews - List all reviews (admin)
     */
    public function get_items($request)
    {
        $page = (int) $request->get_param('page');
        $per_page = (int) $request->get_param('per_page');

        $result = $this->repo->getAll([
            'status' => $request->get_param('status'),
            'product_id' => $request->get_param('product_id'),
            'asin' => $request->get_param('asin'),
            'search' => $request->get_param('search'),
            'limit' => $per_page,
            'offset' => ($page - 1) * $per_page,
        ]);

        // Parse JSON fields
        foreach ($result['items'] as &$item) {
            $item['pros'] = $item['pros'] ? json_decode($item['pros'], true) : [];
            $item['cons'] = $item['cons'] ? json_decode($item['cons'], true) : [];
        }

        return new WP_REST_Response([
            'items' => $result['items'],
            'total' => $result['total'],
            'pages' => $result['pages'],
            'page' => $page,
            'per_page' => $per_page,
        ]);
    }

    /**
     * GET /reviews/product/{id} - Get reviews for a product
     */
    public function get_product_reviews(WP_REST_Request $request): WP_REST_Response
    {
        $product_id = (int) $request->get_param('id');
        $page = (int) $request->get_param('page');
        $per_page = (int) $request->get_param('per_page');

        $reviews = $this->repo->getByProductId($product_id, [
            'status' => 'approved',
            'limit' => $per_page,
            'offset' => ($page - 1) * $per_page,
        ]);

        $stats = $this->repo->getProductStats($product_id);

        // Parse JSON fields and sanitize output
        foreach ($reviews as &$review) {
            $review['pros'] = $review['pros'] ? json_decode($review['pros'], true) : [];
            $review['cons'] = $review['cons'] ? json_decode($review['cons'], true) : [];
            // Remove sensitive fields
            unset($review['author_email'], $review['ip_address'], $review['user_agent'], $review['admin_notes']);
        }

        return new WP_REST_Response([
            'reviews' => $reviews,
            'stats' => $stats,
            'page' => $page,
            'per_page' => $per_page,
        ]);
    }

    /**
     * GET /reviews/asin/{asin} - Get reviews by ASIN
     */
    public function get_asin_reviews(WP_REST_Request $request): WP_REST_Response
    {
        $asin = $request->get_param('asin');
        $page = (int) $request->get_param('page');
        $per_page = (int) $request->get_param('per_page');

        $reviews = $this->repo->getByAsin($asin, [
            'status' => 'approved',
            'limit' => $per_page,
            'offset' => ($page - 1) * $per_page,
        ]);

        $stats = $this->repo->getProductStatsByAsin($asin);

        // Parse JSON fields and sanitize output
        foreach ($reviews as &$review) {
            $review['pros'] = $review['pros'] ? json_decode($review['pros'], true) : [];
            $review['cons'] = $review['cons'] ? json_decode($review['cons'], true) : [];
            unset($review['author_email'], $review['ip_address'], $review['user_agent'], $review['admin_notes']);
        }

        return new WP_REST_Response([
            'reviews' => $reviews,
            'stats' => $stats,
            'page' => $page,
            'per_page' => $per_page,
        ]);
    }

    /**
     * GET /reviews/stats/{id} - Get review stats
     */
    public function get_product_stats(WP_REST_Request $request): WP_REST_Response
    {
        $product_id = (int) $request->get_param('id');
        $stats = $this->repo->getProductStats($product_id);

        return new WP_REST_Response($stats);
    }

    /**
     * POST /reviews - Create a review
     */
    public function create_item($request)
    {
        $product_id = (int) $request->get_param('product_id');
        $asin = $request->get_param('asin');
        $author_email = $request->get_param('author_email');

        // Check if user already reviewed this product
        $user_id = get_current_user_id() ?: null;
        if ($this->repo->hasUserReviewed($product_id, $user_id, $author_email)) {
            return new WP_Error(
                'already_reviewed',
                __('You have already submitted a review for this product.', 'affiliatecms-cat'),
                ['status' => 400]
            );
        }

        // Rate limiting: Check if IP has submitted too many reviews recently
        $ip = $this->get_client_ip();
        if ($this->is_rate_limited($ip)) {
            return new WP_Error(
                'rate_limited',
                __('Too many review submissions. Please try again later.', 'affiliatecms-cat'),
                ['status' => 429]
            );
        }

        // Create the review
        $review_id = $this->repo->create([
            'product_id' => $product_id,
            'asin' => $asin,
            'user_id' => $user_id,
            'author_name' => $request->get_param('author_name'),
            'author_email' => $author_email,
            'rating' => (int) $request->get_param('rating'),
            'title' => $request->get_param('title') ?? '',
            'content' => $request->get_param('content'),
            'pros' => $request->get_param('pros') ?? [],
            'cons' => $request->get_param('cons') ?? [],
            'status' => 'pending', // Always pending for moderation
            'ip_address' => $ip,
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null,
        ]);

        if (!$review_id) {
            return new WP_Error(
                'create_failed',
                __('Failed to create review.', 'affiliatecms-cat'),
                ['status' => 500]
            );
        }

        return new WP_REST_Response([
            'success' => true,
            'message' => __('Thank you! Your review has been submitted and is pending approval.', 'affiliatecms-cat'),
            'review_id' => $review_id,
        ], 201);
    }

    /**
     * GET /reviews/{id} - Get single review
     */
    public function get_item($request)
    {
        $id = (int) $request->get_param('id');
        $review = $this->repo->find($id);

        if (!$review) {
            return new WP_Error(
                'not_found',
                __('Review not found.', 'affiliatecms-cat'),
                ['status' => 404]
            );
        }

        $review['pros'] = $review['pros'] ? json_decode($review['pros'], true) : [];
        $review['cons'] = $review['cons'] ? json_decode($review['cons'], true) : [];

        return new WP_REST_Response($review);
    }

    /**
     * PUT /reviews/{id} - Update review
     */
    public function update_item($request)
    {
        $id = (int) $request->get_param('id');
        $review = $this->repo->find($id);

        if (!$review) {
            return new WP_Error(
                'not_found',
                __('Review not found.', 'affiliatecms-cat'),
                ['status' => 404]
            );
        }

        $data = [];
        if ($request->has_param('status')) {
            $data['status'] = $request->get_param('status');
        }
        if ($request->has_param('admin_notes')) {
            $data['admin_notes'] = $request->get_param('admin_notes');
        }

        $this->repo->update($id, $data);

        return new WP_REST_Response([
            'success' => true,
            'message' => __('Review updated.', 'affiliatecms-cat'),
        ]);
    }

    /**
     * DELETE /reviews/{id} - Delete review
     */
    public function delete_item($request)
    {
        $id = (int) $request->get_param('id');
        $review = $this->repo->find($id);

        if (!$review) {
            return new WP_Error(
                'not_found',
                __('Review not found.', 'affiliatecms-cat'),
                ['status' => 404]
            );
        }

        $this->repo->delete($id);

        return new WP_REST_Response([
            'success' => true,
            'message' => __('Review deleted.', 'affiliatecms-cat'),
        ]);
    }

    /**
     * POST /reviews/{id}/helpful - Mark review as helpful/unhelpful
     */
    public function mark_helpful(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $id = (int) $request->get_param('id');
        $helpful = (bool) $request->get_param('helpful');

        $review = $this->repo->find($id);
        if (!$review || $review['status'] !== 'approved') {
            return new WP_Error(
                'not_found',
                __('Review not found.', 'affiliatecms-cat'),
                ['status' => 404]
            );
        }

        // Check if user already voted (using transient)
        $ip = $this->get_client_ip();
        $vote_key = 'acms_review_vote_' . $id . '_' . md5($ip);
        if (get_transient($vote_key)) {
            return new WP_Error(
                'already_voted',
                __('You have already voted on this review.', 'affiliatecms-cat'),
                ['status' => 400]
            );
        }

        if ($helpful) {
            $this->repo->incrementHelpful($id);
        } else {
            $this->repo->incrementUnhelpful($id);
        }

        // Set transient to prevent duplicate votes (24 hours)
        set_transient($vote_key, true, DAY_IN_SECONDS);

        return new WP_REST_Response([
            'success' => true,
            'message' => __('Thank you for your feedback!', 'affiliatecms-cat'),
        ]);
    }

    /**
     * POST /reviews/bulk - Bulk actions
     */
    public function bulk_action(WP_REST_Request $request): WP_REST_Response
    {
        $action = $request->get_param('action');
        $ids = $request->get_param('ids');

        $affected = 0;

        switch ($action) {
            case 'approve':
                $affected = $this->repo->bulkUpdateStatus($ids, 'approved');
                break;
            case 'pending':
                $affected = $this->repo->bulkUpdateStatus($ids, 'pending');
                break;
            case 'spam':
                $affected = $this->repo->bulkUpdateStatus($ids, 'spam');
                break;
            case 'trash':
                $affected = $this->repo->bulkUpdateStatus($ids, 'trash');
                break;
            case 'delete':
                $affected = $this->repo->bulkDelete($ids);
                break;
        }

        return new WP_REST_Response([
            'success' => true,
            'affected' => $affected,
        ]);
    }

    /**
     * GET /reviews/counts - Get status counts
     */
    public function get_counts(WP_REST_Request $request): WP_REST_Response
    {
        $counts = $this->repo->getStatusCounts();
        return new WP_REST_Response($counts);
    }

    /**
     * Get client IP address
     */
    private function get_client_ip(): string
    {
        $ip = '';

        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
        } elseif (!empty($_SERVER['REMOTE_ADDR'])) {
            $ip = $_SERVER['REMOTE_ADDR'];
        }

        return sanitize_text_field(trim($ip));
    }

    /**
     * Check if IP is rate limited
     */
    private function is_rate_limited(string $ip): bool
    {
        $key = 'acms_review_limit_' . md5($ip);
        $count = (int) get_transient($key);

        if ($count >= 5) { // Max 5 reviews per hour per IP
            return true;
        }

        set_transient($key, $count + 1, HOUR_IN_SECONDS);
        return false;
    }
}
