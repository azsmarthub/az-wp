<?php
/**
 * Cron REST API Controller
 *
 * Provides token-authenticated endpoints for server cron integration.
 *
 * @package AffiliateCMS\Categories\Api
 */

declare(strict_types=1);

namespace AffiliateCMS\Categories\Api;

use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;
use AffiliateCMS\Categories\Core\CategoryQueueMonitor;
use AffiliateCMS\Categories\Core\CategoryAiCron;
use AffiliateCMS\Categories\Core\CatQueueProcessorCron;
use AffiliateCMS\Categories\Core\CategoryPathAssigner;
use AffiliateCMS\Categories\Core\CategoryDirectoryCache;
use AffiliateCMS\Categories\Database\Schema;

class CronController
{
    private const NAMESPACE = 'acms-cat/v1';

    /**
     * Max self-chain depth for queue processor
     * 20 chains × 5 items/batch = 100 items per cron trigger
     */
    private const MAX_CHAIN = 20;

    /**
     * Acquire a transient lock to prevent overlapping execution.
     *
     * When multiple cron triggers hit the same handler,
     * only the first one executes — the rest skip gracefully.
     *
     * @param string $key Lock identifier (e.g., 'queue_processor')
     * @param int $ttlSeconds Lock duration in seconds (default: 90s for 2-min interval tasks)
     * @return bool True if lock acquired, false if already locked
     */
    private static function acquireLock(string $key, int $ttlSeconds = 90): bool
    {
        $lockKey = 'acms_cron_lock_' . $key;
        if (get_transient($lockKey)) {
            return false;
        }
        set_transient($lockKey, time(), $ttlSeconds);
        return true;
    }

    /**
     * Register REST API routes
     */
    public function register_routes(): void
    {
        // Token-authenticated endpoint for queue processor (processes pending items)
        register_rest_route(self::NAMESPACE, '/cron/queue-processor', [
            'methods' => 'GET, POST',
            'callback' => [$this, 'runQueueProcessor'],
            'permission_callback' => [$this, 'checkCronToken'],
        ]);

        // Token-authenticated endpoint for queue monitor (for server cron)
        register_rest_route(self::NAMESPACE, '/cron/queue-monitor', [
            'methods' => 'GET, POST',
            'callback' => [$this, 'runQueueMonitor'],
            'permission_callback' => [$this, 'checkCronToken'],
        ]);

        // Token-authenticated endpoint for category AI content generation
        register_rest_route(self::NAMESPACE, '/cron/category-ai', [
            'methods' => 'GET, POST',
            'callback' => [$this, 'runCategoryAiCron'],
            'permission_callback' => [$this, 'checkCronToken'],
        ]);

        // Process category AI: assign categories to ready queue items via CategoryAiProcessor
        register_rest_route(self::NAMESPACE, '/cron/process-category-ai', [
            'methods' => 'GET, POST',
            'callback' => [$this, 'runProcessCategoryAi'],
            'permission_callback' => [$this, 'checkCronToken'],
        ]);

        // Brand-Category AI: auto-create brand-category pages + trigger AI content
        register_rest_route(self::NAMESPACE, '/cron/brand-category-ai', [
            'methods' => 'GET, POST',
            'callback' => [$this, 'runBrandCategoryAiCron'],
            'permission_callback' => [$this, 'checkCronToken'],
        ]);

        // Retry stuck items (analyzing_category) — direct execution, no AS dependency
        register_rest_route(self::NAMESPACE, '/cron/retry-stuck', [
            'methods' => 'GET, POST',
            'callback' => [$this, 'runRetryStuck'],
            'permission_callback' => [$this, 'checkCronToken'],
        ]);

        // One-time maintenance: strip H1 tags from all AI-generated content
        register_rest_route(self::NAMESPACE, '/cron/strip-h1', [
            'methods' => 'GET, POST',
            'callback' => [$this, 'runStripH1'],
            'permission_callback' => [$this, 'checkCronToken'],
        ]);

        // Backfill orphan products into category_products via cat_queue ASINs
        register_rest_route(self::NAMESPACE, '/cron/backfill-category-links', [
            'methods' => 'GET, POST',
            'callback' => [$this, 'runBackfillCategoryLinks'],
            'permission_callback' => [$this, 'checkAdminOrCronToken'],
        ]);

        // Rebuild categories directory JSON cache (accepts admin nonce OR cron token)
        register_rest_route(self::NAMESPACE, '/cron/rebuild-category-cache', [
            'methods' => 'GET, POST',
            'callback' => [$this, 'runRebuildCategoryCache'],
            'permission_callback' => [$this, 'checkAdminOrCronToken'],
        ]);

        // Bulk update ASINs worker (server cron, processes N items per call)
        register_rest_route(self::NAMESPACE, '/cron/bulk-update-worker', [
            'methods' => 'GET, POST',
            'callback' => [$this, 'runBulkUpdateWorker'],
            'permission_callback' => [$this, 'checkCronToken'],
            'args' => [
                'batch_id' => [
                    'type' => 'string',
                    'required' => false,
                    'description' => 'Optional. Auto-detects running batch if omitted.',
                ],
            ],
        ]);
    }

    /**
     * Check cron token for external cron calls
     * Uses unified token (acms_api_token) with ?token=xxx query parameter
     */
    public function checkCronToken(WP_REST_Request $request): bool
    {
        // Prevent caching of cron responses by CDN/LiteSpeed/browser
        nocache_headers();

        $token = $request->get_param('token');
        $stored_token = get_option('acms_api_token', '');

        if (empty($stored_token)) {
            return false;
        }

        return hash_equals($stored_token, (string) $token);
    }

    /**
     * Run Category Queue Processor
     *
     * Self-chaining: after processing a batch, fires a non-blocking request
     * to continue processing. Each batch = 5 items in its own HTTP request,
     * so no PHP timeout. Chain stops when no more pending items or max depth.
     *
     * Throughput: 20 chains × 5 items × every 2 min = up to 3000 items/hour
     */
    public function runQueueProcessor(WP_REST_Request $request): WP_REST_Response
    {
        $chain = (int) $request->get_param('chain');

        // Only lock for initial cron calls (chain=0), not self-chained calls
        if ($chain === 0) {
            if (!self::acquireLock('queue_processor', 90)) {
                return new WP_REST_Response([
                    'success' => true,
                    'message' => 'Skipped: recently executed (lock active)',
                    'data' => ['skipped' => true],
                ]);
            }
            $chain = self::MAX_CHAIN;
        }

        try {
            $startTime = microtime(true);

            $processor = CatQueueProcessorCron::instance();
            $result = $processor->runManually();

            $duration = round((microtime(true) - $startTime) * 1000);
            $processed = $result['processed'] ?? 0;
            $remaining = $result['pending_remaining'] ?? 0;

            // Self-chain: if more items pending and chain budget remains
            $chained = false;
            if ($remaining > 0 && $chain > 1 && $processed > 0) {
                $this->spawnQueueProcessorChain($chain - 1);
                $chained = true;
            }

            $result['chain_remaining'] = $chain - 1;
            $result['chained'] = $chained;

            // Only log on initial call, not every chain link
            if ($chain === self::MAX_CHAIN) {
                self::addLog('cat_queue', 'info', "Queue processor started (pending: {$remaining})");
            }
            if (!$chained && $chain < self::MAX_CHAIN) {
                $totalProcessed = self::MAX_CHAIN - $chain;
                self::addLog('cat_queue', 'success', "Chain done: batch {$processed}, chain depth " . (self::MAX_CHAIN - $chain), "Duration: {$duration}ms");
            }

            return new WP_REST_Response([
                'success' => true,
                'message' => "Processed {$processed} items" . ($chained ? ', chaining next batch' : ''),
                'data' => $result,
            ]);
        } catch (\Throwable $e) {
            error_log('[ACMS Cat CronController] Queue processor failed: ' . $e->getMessage());
            self::addLog('cat_queue', 'error', 'Cat queue processor failed', $e->getMessage());

            return new WP_REST_Response([
                'success' => false,
                'message' => 'Error: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Spawn next chain link for queue processor (non-blocking)
     */
    private function spawnQueueProcessorChain(int $remainingChain): void
    {
        $apiToken = get_option('acms_api_token', '');
        if (empty($apiToken)) {
            return;
        }

        $url = rest_url(self::NAMESPACE . '/cron/queue-processor')
            . '?token=' . urlencode($apiToken)
            . '&chain=' . $remainingChain;

        wp_remote_post($url, [
            'timeout' => 0.5,
            'blocking' => false,
            'sslverify' => false,
        ]);
    }

    /**
     * Run Category Queue Monitor
     *
     * Checks items waiting for scrape and marks them ready for AI
     * when scrape progress reaches threshold (default 50%).
     */
    public function runQueueMonitor(WP_REST_Request $request): WP_REST_Response
    {
        if (!self::acquireLock('queue_monitor', 90)) {
            return new WP_REST_Response([
                'success' => true,
                'message' => 'Skipped: recently executed (lock active)',
                'data' => ['skipped' => true],
            ]);
        }

        try {
            self::addLog('cat_monitor', 'info', 'Cat queue monitor started');
            $startTime = microtime(true);

            $monitor = CategoryQueueMonitor::instance();
            $result = $monitor->runManually();

            $duration = round((microtime(true) - $startTime) * 1000);
            self::addLog('cat_monitor', 'success', 'Cat queue monitor completed', "Duration: {$duration}ms");

            return new WP_REST_Response([
                'success' => true,
                'message' => 'Category queue monitor executed',
                'data' => $result,
            ]);
        } catch (\Throwable $e) {
            error_log('[ACMS Cat CronController] Queue monitor failed: ' . $e->getMessage());
            self::addLog('cat_monitor', 'error', 'Cat queue monitor failed', $e->getMessage());

            return new WP_REST_Response([
                'success' => false,
                'message' => 'Error: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Run Category AI Content Generation
     *
     * Two-phase approach:
     * 1. Sweep: re-fire hooks for queue items stuck at category_assigned (no other cron handles these)
     * 2. Generate: spawn workers for categories with content_status='empty'
     *
     * Runs every 2 min via cron server (Tier 1).
     */
    public function runCategoryAiCron(WP_REST_Request $request): WP_REST_Response
    {
        if (!self::acquireLock('category_ai', 240)) {
            return new WP_REST_Response([
                'success' => true,
                'message' => 'Skipped: recently executed (lock active)',
                'data' => ['skipped' => true],
            ]);
        }

        try {
            self::addLog('category_ai', 'info', 'Category AI cron started');
            $startTime = microtime(true);

            // Phase 1: Sweep stuck category_assigned queue items
            // These items have their category assigned but the hook-based job creation
            // failed. No other cron handles them — must re-fire the hook here.
            $sweepResult = $this->sweepStuckCategoryAssigned();

            // Phase 2: Spawn workers for categories needing AI content
            $cron = CategoryAiCron::instance();
            $result = $cron->runManually();
            $result['sweep'] = $sweepResult;

            $duration = round((microtime(true) - $startTime) * 1000);
            $sweepMsg = $sweepResult['total'] > 0
                ? "swept {$sweepResult['retried']}r/{$sweepResult['synced']}s/{$sweepResult['total']}t, "
                : '';
            self::addLog('category_ai', 'success', $sweepMsg . 'Category AI cron completed', "Duration: {$duration}ms");

            return new WP_REST_Response([
                'success' => true,
                'message' => 'Category AI cron executed',
                'data' => $result,
            ]);
        } catch (\Throwable $e) {
            error_log('[ACMS Cat CronController] Category AI cron failed: ' . $e->getMessage());
            self::addLog('category_ai', 'error', 'Category AI cron failed', $e->getMessage());

            return new WP_REST_Response([
                'success' => false,
                'message' => 'Error: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Sweep queue items stuck at category_assigned
     *
     * Lightweight fallback that runs every time /cron/category-ai fires (every 2 min).
     * For items stuck > 2 min:
     * - Category already generated → sync queue to completed
     * - Category empty → cancel stale jobs + re-fire acms_category_assigned hook
     * - Category ai_generating → reset to empty + re-fire hook
     *
     * @return array{total: int, retried: int, synced: int, failed: int}
     */
    private function sweepStuckCategoryAssigned(): array
    {
        global $wpdb;
        $stats = ['total' => 0, 'retried' => 0, 'synced' => 0, 'failed' => 0, 'debug' => []];

        $queueTable = Schema::queueTable();
        $categoriesTable = $wpdb->prefix . 'acms_categories';
        $jobsTable = $wpdb->prefix . 'acms_ai_jobs';

        // Check jobs table availability once
        $hasJobsTable = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $jobsTable)) === $jobsTable;

        // Find ALL non-completed queue items stuck in intermediate ai_status
        // LEFT JOIN: catch items even if assigned_category_id doesn't match any category
        // No updated_at threshold: column has ON UPDATE CURRENT_TIMESTAMP so any
        // cron touching the row resets it, making time-based checks unreliable
        $stuckItems = $wpdb->get_results(
            "SELECT q.id, q.keyword, q.assigned_category_id, q.ai_status, q.status as q_status,
                    c.id as cat_id, c.name as cat_name, c.content_status, c.path
             FROM {$queueTable} q
             LEFT JOIN {$categoriesTable} c ON c.id = q.assigned_category_id
             WHERE q.status NOT IN ('completed', 'failed', 'pending', 'processing', 'searched')
             AND q.ai_status NOT IN ('completed', 'failed', 'not_started', 'waiting_scrape')
             LIMIT 50",
            ARRAY_A
        );

        if (empty($stuckItems)) {
            return $stats;
        }

        $stats['total'] = count($stuckItems);

        foreach ($stuckItems as $item) {
            $queueId = (int) $item['id'];
            $categoryId = (int) $item['assigned_category_id'];
            $contentStatus = $item['content_status'] ?? null; // null if LEFT JOIN missed
            $aiStatus = $item['ai_status'] ?? '';

            $stats['debug'][] = [
                'queue_id' => $queueId,
                'keyword' => $item['keyword'] ?? '',
                'q_status' => $item['q_status'],
                'ai_status' => $aiStatus,
                'category_id' => $categoryId,
                'cat_found' => $item['cat_id'] !== null,
                'content_status' => $contentStatus,
            ];

            // Case 1: Category content already generated → sync to completed
            if ($contentStatus === 'ai_generated' || $contentStatus === 'manual') {
                $wpdb->update($queueTable, [
                    'ai_status' => 'completed',
                    'status' => 'completed',
                    'completed_at' => current_time('mysql'),
                ], ['id' => $queueId]);
                $stats['synced']++;
                error_log("[ACMS CatAI Sweep] Queue #{$queueId} synced (category #{$categoryId} content_status={$contentStatus})");
                continue;
            }

            // Case 2: Check if a completed AI job exists for this category
            if ($hasJobsTable && $categoryId > 0) {
                $completedJob = $wpdb->get_var($wpdb->prepare(
                    "SELECT id FROM {$jobsTable}
                     WHERE type = 'generate_seo_category'
                     AND target_id = %s
                     AND status = 'completed'
                     ORDER BY id DESC LIMIT 1",
                    (string) $categoryId
                ));

                if ($completedJob) {
                    $wpdb->update($queueTable, [
                        'ai_status' => 'completed',
                        'status' => 'completed',
                        'completed_at' => current_time('mysql'),
                    ], ['id' => $queueId]);
                    $stats['synced']++;
                    error_log("[ACMS CatAI Sweep] Queue #{$queueId} synced (completed job #{$completedJob})");
                    continue;
                }
            }

            // Case 3: No category found (assigned_category_id invalid) → mark failed
            if ($item['cat_id'] === null && $categoryId > 0) {
                $wpdb->update($queueTable, [
                    'ai_status' => 'failed',
                    'error_message' => "Category #{$categoryId} not found in acms_categories",
                ], ['id' => $queueId]);
                $stats['failed']++;
                error_log("[ACMS CatAI Sweep] Queue #{$queueId} failed (category #{$categoryId} missing)");
                continue;
            }

            // Case 4: Category exists but content not generated → retry
            if ($categoryId > 0 && $item['cat_id'] !== null) {
                // Reset category if stuck at ai_generating
                if ($contentStatus === 'ai_generating') {
                    $wpdb->update($categoriesTable, [
                        'content_status' => 'empty',
                        'ai_error_message' => null,
                    ], ['id' => $categoryId]);
                }

                // Cancel stale jobs
                if ($hasJobsTable) {
                    $wpdb->query($wpdb->prepare(
                        "UPDATE {$jobsTable}
                         SET status = 'failed', error_message = 'Cancelled: sweep retry'
                         WHERE type = 'generate_seo_category'
                         AND target_id = %s
                         AND status IN ('pending', 'processing')",
                        (string) $categoryId
                    ));
                }

                // Build category_path and re-fire hook
                $categoryPath = $item['cat_name'] ?? '';
                if (!empty($item['path']) && $item['path'] !== '/') {
                    $pathIds = array_filter(explode('/', trim($item['path'], '/')));
                    if (!empty($pathIds)) {
                        $placeholders = implode(',', array_fill(0, count($pathIds), '%d'));
                        $parentNames = $wpdb->get_col($wpdb->prepare(
                            "SELECT name FROM {$categoriesTable} WHERE id IN ({$placeholders}) ORDER BY depth ASC",
                            ...$pathIds
                        ));
                        if (!empty($parentNames)) {
                            $categoryPath = implode(' > ', $parentNames) . ' > ' . $item['cat_name'];
                        }
                    }
                }

                try {
                    do_action('acms_category_assigned', $queueId, $categoryId, $categoryPath);
                    $stats['retried']++;
                    error_log("[ACMS CatAI Sweep] Re-fired hook for queue #{$queueId} → category #{$categoryId}");
                } catch (\Throwable $e) {
                    $wpdb->update($queueTable, [
                        'ai_status' => 'failed',
                        'error_message' => 'Sweep error: ' . substr($e->getMessage(), 0, 300),
                    ], ['id' => $queueId]);
                    $stats['failed']++;
                    error_log("[ACMS CatAI Sweep] Hook error for queue #{$queueId}: " . $e->getMessage());
                }
            }
        }

        if ($stats['total'] > 0) {
            error_log("[ACMS CatAI Sweep] {$stats['total']} stuck, {$stats['retried']} retried, {$stats['synced']} synced, {$stats['failed']} failed");
        }

        return $stats;
    }

    /**
     * Run Process Category AI
     *
     * Processes queue items that are ready for category assignment.
     * Uses CategoryAiProcessor from affiliatecms-ai plugin.
     */
    public function runProcessCategoryAi(WP_REST_Request $request): WP_REST_Response
    {
        if (!self::acquireLock('process_category_ai', 90)) {
            return new WP_REST_Response([
                'success' => true,
                'message' => 'Skipped: recently executed (lock active)',
                'data' => ['skipped' => true],
            ]);
        }

        try {
            self::addLog('process_category_ai', 'info', 'Process Category AI started');
            $startTime = microtime(true);

            if (!class_exists(\AffiliateCMS\AI\Core\CategoryAiProcessor::class)) {
                self::addLog('process_category_ai', 'error', 'CategoryAiProcessor class not available');
                return new WP_REST_Response([
                    'success' => false,
                    'message' => 'CategoryAiProcessor class not available (affiliatecms-ai plugin required)',
                ], 500);
            }

            $processor = new \AffiliateCMS\AI\Core\CategoryAiProcessor();
            $processed = $processor->processReadyItems();

            $duration = round((microtime(true) - $startTime) * 1000);
            self::addLog('process_category_ai', 'success', "Processed {$processed} items", "Duration: {$duration}ms");

            return new WP_REST_Response([
                'success' => true,
                'message' => "Process Category AI executed: {$processed} items processed",
                'data' => [
                    'processed' => $processed,
                    'duration_ms' => $duration,
                ],
            ]);
        } catch (\Throwable $e) {
            error_log('[ACMS Cat CronController] Process Category AI failed: ' . $e->getMessage());
            self::addLog('process_category_ai', 'error', 'Process Category AI failed', $e->getMessage());

            return new WP_REST_Response([
                'success' => false,
                'message' => 'Error: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Run Brand-Category AI Cron
     *
     * Auto-creates brand-category child pages and triggers AI content generation.
     * Uses BrandCategoryAiCron from affiliatecms-cat plugin.
     */
    public function runBrandCategoryAiCron(WP_REST_Request $request): WP_REST_Response
    {
        if (!self::acquireLock('brand_category_ai', 240)) {
            return new WP_REST_Response([
                'success' => true,
                'message' => 'Skipped: recently executed (lock active)',
                'data' => ['skipped' => true],
            ]);
        }

        try {
            self::addLog('brand_category_ai', 'info', 'Brand-Category AI cron started');
            $startTime = microtime(true);

            if (!class_exists(\AffiliateCMS\Categories\Core\BrandCategoryAiCron::class)) {
                self::addLog('brand_category_ai', 'error', 'BrandCategoryAiCron class not available');
                return new WP_REST_Response([
                    'success' => false,
                    'message' => 'BrandCategoryAiCron class not available',
                ], 500);
            }

            $cron = \AffiliateCMS\Categories\Core\BrandCategoryAiCron::instance();
            $cron->generateContent();

            $duration = round((microtime(true) - $startTime) * 1000);
            self::addLog('brand_category_ai', 'success', 'Brand-Category AI cron completed', "Duration: {$duration}ms");

            return new WP_REST_Response([
                'success' => true,
                'message' => 'Brand-Category AI cron executed',
                'data' => [
                    'duration_ms' => $duration,
                ],
            ]);
        } catch (\Throwable $e) {
            error_log('[ACMS Cat CronController] Brand-Category AI failed: ' . $e->getMessage());
            self::addLog('brand_category_ai', 'error', 'Brand-Category AI failed', $e->getMessage());

            return new WP_REST_Response([
                'success' => false,
                'message' => 'Error: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Retry stuck queue items
     *
     * Handles three stuck states:
     * 1. generating_content — syncs with AI job status or resets to category_assigned
     * 2. analyzing_category — re-fires acms_category_ready_for_ai hook
     * 3. category_assigned — re-fires acms_category_assigned hook (no cron picks these up)
     *
     * Direct HTTP execution — no AS dependency.
     * Includes diagnostic info to debug why items might be stuck.
     */
    public function runRetryStuck(WP_REST_Request $request): WP_REST_Response
    {
        $startTime = microtime(true);
        self::addLog('retry_stuck', 'info', 'Retry stuck started');

        try {
            global $wpdb;
            $table = Schema::queueTable();
            $now = current_time('mysql');

            // ── Phase 1: Reset stuck generating_content items ──
            $generatingReset = $this->resetStuckGenerating($wpdb, $table);

            // ── Phase 3: Retry stuck category_assigned items ──
            // These items had their category assigned but onCategoryAssigned() hook
            // failed to create a job. No cron picks these up — must re-fire the hook.
            $assignedRetry = $this->retryStuckCategoryAssigned($wpdb, $table);

            // ── Phase 2: Retry stuck analyzing_category items ──

            // Diagnostic: count ALL items at analyzing_category (no time filter)
            $diagCounts = $wpdb->get_row(
                "SELECT
                    COUNT(*) as total_analyzing,
                    SUM(CASE WHEN linked_asins IS NOT NULL AND linked_asins != '[]' THEN 1 ELSE 0 END) as with_asins,
                    MIN(updated_at) as oldest_updated,
                    MAX(updated_at) as newest_updated
                 FROM {$table}
                 WHERE status = 'ready_for_ai'
                 AND ai_status = 'analyzing_category'",
                ARRAY_A
            );

            // Find ALL stuck items — no time threshold, retry everything
            $stuckItems = $wpdb->get_results(
                "SELECT id, keyword, linked_asins, ai_status, status, updated_at, error_message, assigned_category_id
                 FROM {$table}
                 WHERE status = 'ready_for_ai'
                 AND ai_status = 'analyzing_category'
                 AND linked_asins IS NOT NULL
                 AND linked_asins != '[]'
                 LIMIT 50",
                ARRAY_A
            );

            if (empty($stuckItems)) {
                // Also check: are there analyzing items with OTHER status values?
                $otherAnalyzing = $wpdb->get_results(
                    "SELECT id, keyword, status, ai_status, updated_at
                     FROM {$table}
                     WHERE ai_status = 'analyzing_category'
                     LIMIT 20",
                    ARRAY_A
                );

                return new WP_REST_Response([
                    'success' => true,
                    'message' => 'No stuck items found matching criteria',
                    'data' => [
                        'stuck_count' => 0,
                        'retried' => 0,
                        'server_time' => $now,
                        'diagnostic' => $diagCounts,
                        'other_analyzing' => $otherAnalyzing,
                        'duration_ms' => round((microtime(true) - $startTime) * 1000),
                    ],
                ]);
            }

            $retried = 0;
            $failed = 0;
            $results = [];

            foreach ($stuckItems as $item) {
                $queueId = (int) $item['id'];
                $linkedAsins = is_array($item['linked_asins'])
                    ? $item['linked_asins']
                    : json_decode($item['linked_asins'] ?? '[]', true);

                if (empty($linkedAsins)) {
                    $results[] = [
                        'id' => $queueId,
                        'keyword' => $item['keyword'] ?? '',
                        'result' => 'skipped',
                        'reason' => 'No linked ASINs',
                    ];
                    continue;
                }

                error_log("[ACMS CronController] Retrying stuck analyzing queue #{$queueId} ({$item['keyword']})");

                // Fire the hook — CategoryPathAssigner listens to this
                // Wrap in try/catch for Throwable to catch TypeErrors etc.
                $beforeStatus = $item['ai_status'];
                try {
                    do_action('acms_category_ready_for_ai', $queueId, $linkedAsins);
                } catch (\Throwable $e) {
                    error_log("[ACMS CronController] Hook error for queue #{$queueId}: " . $e->getMessage());
                    // Mark as failed so it doesn't stay stuck forever
                    $wpdb->update($table, [
                        'ai_status' => 'failed',
                        'error_message' => 'Retry hook error: ' . $e->getMessage(),
                    ], ['id' => $queueId]);
                    $failed++;
                    $results[] = [
                        'id' => $queueId,
                        'keyword' => $item['keyword'] ?? '',
                        'result' => 'error',
                        'error' => $e->getMessage(),
                    ];
                    continue;
                }

                // Check if the item actually moved away from analyzing_category
                $afterStatus = $wpdb->get_var($wpdb->prepare(
                    "SELECT ai_status FROM {$table} WHERE id = %d",
                    $queueId
                ));

                $retried++;
                $results[] = [
                    'id' => $queueId,
                    'keyword' => $item['keyword'] ?? '',
                    'asins_count' => count($linkedAsins),
                    'result' => $afterStatus !== 'analyzing_category' ? 'resolved' : 'still_stuck',
                    'before_status' => $beforeStatus,
                    'after_status' => $afterStatus,
                    'updated_at' => $item['updated_at'],
                ];
            }

            $duration = round((microtime(true) - $startTime) * 1000);
            $resolved = count(array_filter($results, fn($r) => ($r['result'] ?? '') === 'resolved'));

            $logParts = [];
            if ($generatingReset['total'] > 0) {
                $logParts[] = "generating={$generatingReset['total']}({$generatingReset['synced']}synced/{$generatingReset['reset']}reset)";
            }
            if ($assignedRetry['total'] > 0) {
                $logParts[] = "assigned={$assignedRetry['total']}({$assignedRetry['retried']}retried/{$assignedRetry['synced']}synced)";
            }
            if ($retried > 0) {
                $logParts[] = "analyzing={$retried}({$resolved}resolved/{$failed}errors)";
            }
            $logMsg = !empty($logParts) ? implode(' ', $logParts) : 'Nothing stuck';

            error_log("[ACMS CronController] Retry stuck completed: {$logMsg} in {$duration}ms");
            $hasErrors = $failed > 0 || $assignedRetry['failed'] > 0;
            self::addLog('retry_stuck', $hasErrors ? 'warning' : 'success', $logMsg, "Duration: {$duration}ms");

            return new WP_REST_Response([
                'success' => true,
                'message' => $logMsg,
                'data' => [
                    'stuck_count' => count($stuckItems),
                    'retried' => $retried,
                    'resolved' => $resolved,
                    'failed' => $failed,
                    'generating_reset' => $generatingReset,
                    'assigned_retry' => $assignedRetry,
                    'server_time' => $now,
                    'diagnostic' => $diagCounts,
                    'items' => $results,
                    'duration_ms' => $duration,
                ],
            ]);
        } catch (\Throwable $e) {
            error_log('[ACMS CronController] Retry stuck failed: ' . $e->getMessage());
            self::addLog('retry_stuck', 'error', 'Retry stuck failed', $e->getMessage());

            return new WP_REST_Response([
                'success' => false,
                'message' => 'Error: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Strip H1 tags from all AI-generated content in categories and brands.
     * One-time maintenance endpoint. Safe to run multiple times.
     */
    public function runStripH1(WP_REST_Request $request): WP_REST_Response
    {
        global $wpdb;
        $stats = ['categories' => 0, 'brands' => 0];

        // Strip H1 from acms_categories.content_main
        $catTable = $wpdb->prefix . 'acms_categories';
        $catsWithH1 = $wpdb->get_results(
            "SELECT id, content_main FROM {$catTable}
             WHERE content_main LIKE '%<h1%'
             AND content_status IN ('ai_generated', 'manual')",
            ARRAY_A
        );

        foreach ($catsWithH1 as $row) {
            $cleaned = preg_replace('/<h1[^>]*>.*?<\/h1>/is', '', $row['content_main']);
            if ($cleaned !== $row['content_main']) {
                $wpdb->update($catTable, ['content_main' => $cleaned], ['id' => (int) $row['id']]);
                $stats['categories']++;
            }
        }

        // Strip H1 from acms_brands.content_main
        $brandTable = $wpdb->prefix . 'acms_brands';
        $brandTableExists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $brandTable)) === $brandTable;
        if ($brandTableExists) {
            $brandsWithH1 = $wpdb->get_results(
                "SELECT id, content_main FROM {$brandTable}
                 WHERE content_main LIKE '%<h1%'",
                ARRAY_A
            );

            foreach ($brandsWithH1 as $row) {
                $cleaned = preg_replace('/<h1[^>]*>.*?<\/h1>/is', '', $row['content_main']);
                if ($cleaned !== $row['content_main']) {
                    $wpdb->update($brandTable, ['content_main' => $cleaned], ['id' => (int) $row['id']]);
                    $stats['brands']++;
                }
            }
        }

        return new WP_REST_Response([
            'success' => true,
            'message' => "Stripped H1 from {$stats['categories']} categories, {$stats['brands']} brands",
            'data' => $stats,
        ]);
    }

    /**
     * Retry queue items stuck at category_assigned
     *
     * Items reach category_assigned when CategoryPathAssigner fires the
     * acms_category_assigned hook. Bootstrap.onCategoryAssigned() should
     * create a job — but if it fails, items stay here forever because
     * NO cron picks them up (CategoryAiCron works on category content_status,
     * not queue ai_status).
     *
     * Fix: sync with category status, or re-fire the hook.
     *
     * @return array{total: int, retried: int, synced: int, failed: int, items: array}
     */
    private function retryStuckCategoryAssigned(\wpdb $wpdb, string $table): array
    {
        $stats = ['total' => 0, 'retried' => 0, 'synced' => 0, 'failed' => 0, 'items' => []];
        $categoriesTable = $wpdb->prefix . 'acms_categories';

        // Find items stuck at category_assigned > 2 minutes
        $threshold = date('Y-m-d H:i:s', current_time('timestamp') - 120);
        $stuckItems = $wpdb->get_results($wpdb->prepare(
            "SELECT id, keyword, assigned_category_id, updated_at
             FROM {$table}
             WHERE ai_status = 'category_assigned'
             AND assigned_category_id IS NOT NULL
             AND assigned_category_id > 0
             AND (updated_at < %s OR updated_at IS NULL)
             LIMIT 30",
            $threshold
        ), ARRAY_A);

        if (empty($stuckItems)) {
            return $stats;
        }

        $stats['total'] = count($stuckItems);

        // Check if AI jobs table exists (once, outside loop)
        $jobsTable = $wpdb->prefix . 'acms_ai_jobs';
        $hasJobsTable = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $jobsTable)) === $jobsTable;

        foreach ($stuckItems as $item) {
            $queueId = (int) $item['id'];
            $categoryId = (int) $item['assigned_category_id'];

            // Check the category's current content_status
            $category = $wpdb->get_row($wpdb->prepare(
                "SELECT id, name, content_status, path FROM {$categoriesTable} WHERE id = %d",
                $categoryId
            ), ARRAY_A);

            if (!$category) {
                // Category deleted — mark queue as failed
                $wpdb->update($table, [
                    'ai_status' => 'failed',
                    'error_message' => "Category #{$categoryId} not found",
                ], ['id' => $queueId]);
                $stats['failed']++;
                $stats['items'][] = ['id' => $queueId, 'action' => 'failed', 'reason' => 'category_deleted'];
                continue;
            }

            if ($category['content_status'] === 'ai_generated' || $category['content_status'] === 'manual') {
                // Category already has content — sync queue to completed
                $wpdb->update($table, [
                    'ai_status' => 'completed',
                    'status' => 'completed',
                    'completed_at' => current_time('mysql'),
                ], ['id' => $queueId]);
                $stats['synced']++;
                $stats['items'][] = ['id' => $queueId, 'action' => 'synced_completed', 'content_status' => $category['content_status']];
                continue;
            }

            // Category content_status is 'empty' or 'ai_generating' — re-fire the hook
            // Build category_path from the category's path + name
            $categoryPath = $category['name']; // fallback
            if (!empty($category['path']) && $category['path'] !== '/') {
                $pathIds = array_filter(explode('/', trim($category['path'], '/')));
                if (!empty($pathIds)) {
                    $placeholders = implode(',', array_fill(0, count($pathIds), '%d'));
                    $parentNames = $wpdb->get_col($wpdb->prepare(
                        "SELECT name FROM {$categoriesTable} WHERE id IN ({$placeholders}) ORDER BY depth ASC",
                        ...$pathIds
                    ));
                    if (!empty($parentNames)) {
                        $categoryPath = implode(' > ', $parentNames) . ' > ' . $category['name'];
                    }
                }
            }

            // Reset category to empty if it's stuck at ai_generating
            if ($category['content_status'] === 'ai_generating') {
                $wpdb->update($categoriesTable, [
                    'content_status' => 'empty',
                    'ai_error_message' => null,
                ], ['id' => $categoryId]);
            }

            // Cancel any stale pending/processing jobs for this category
            // so onCategoryAssigned()'s duplicate check doesn't block the new job
            if ($hasJobsTable) {
                $wpdb->query($wpdb->prepare(
                    "UPDATE {$jobsTable}
                     SET status = 'failed', error_message = 'Cancelled: queue item retry'
                     WHERE type = 'generate_seo_category'
                     AND target_id = %s
                     AND status IN ('pending', 'processing')",
                    (string) $categoryId
                ));
            }

            // Re-fire the hook — Bootstrap.onCategoryAssigned() will create a new job
            try {
                do_action('acms_category_assigned', $queueId, $categoryId, $categoryPath);
                $stats['retried']++;
                $stats['items'][] = ['id' => $queueId, 'action' => 'retried', 'category' => $category['name']];
                error_log("[ACMS CronController] Re-fired acms_category_assigned for queue #{$queueId} (category #{$categoryId}: {$category['name']})");
            } catch (\Throwable $e) {
                error_log("[ACMS CronController] Hook error for assigned queue #{$queueId}: " . $e->getMessage());
                $wpdb->update($table, [
                    'ai_status' => 'failed',
                    'error_message' => 'Retry hook error: ' . $e->getMessage(),
                ], ['id' => $queueId]);
                $stats['failed']++;
                $stats['items'][] = ['id' => $queueId, 'action' => 'error', 'error' => $e->getMessage()];
            }
        }

        if ($stats['total'] > 0) {
            error_log("[ACMS CronController] Retry assigned: {$stats['total']} found, {$stats['retried']} retried, {$stats['synced']} synced, {$stats['failed']} failed");
        }

        return $stats;
    }

    /**
     * Reset queue items stuck at generating_content by syncing with AI job status
     *
     * Checks acms_ai_jobs table for the actual job outcome:
     * - Job completed → sync queue to completed
     * - Job failed → sync queue to failed
     * - Job pending/processing > 15 min → reset to category_assigned for re-queue
     * - No job found → reset to category_assigned for re-queue
     *
     * @return array{total: int, synced: int, reset: int}
     */
    private function resetStuckGenerating(\wpdb $wpdb, string $table): array
    {
        $stats = ['total' => 0, 'synced' => 0, 'reset' => 0, 'items' => []];
        $jobsTable = $wpdb->prefix . 'acms_ai_jobs';
        $categoriesTable = $wpdb->prefix . 'acms_categories';

        // Find items stuck at generating_content > 10 minutes
        $threshold = date('Y-m-d H:i:s', current_time('timestamp') - 600);
        $stuckItems = $wpdb->get_results($wpdb->prepare(
            "SELECT id, keyword, assigned_category_id, updated_at
             FROM {$table}
             WHERE ai_status = 'generating_content'
             AND (updated_at < %s OR updated_at IS NULL)
             LIMIT 50",
            $threshold
        ), ARRAY_A);

        if (empty($stuckItems)) {
            return $stats;
        }

        $stats['total'] = count($stuckItems);

        foreach ($stuckItems as $item) {
            $queueId = (int) $item['id'];
            $categoryId = (int) ($item['assigned_category_id'] ?? 0);

            if (!$categoryId) {
                // No assigned category — can't have a valid job, reset
                $wpdb->update($table, [
                    'ai_status' => 'category_assigned',
                    'error_message' => 'Reset: no assigned_category_id',
                ], ['id' => $queueId]);
                $stats['reset']++;
                $stats['items'][] = ['id' => $queueId, 'action' => 'reset', 'reason' => 'no_category_id'];
                continue;
            }

            // Check the latest AI job for this category
            $job = $wpdb->get_row($wpdb->prepare(
                "SELECT id, status, completed_at, error_message
                 FROM {$jobsTable}
                 WHERE type = 'generate_seo_category'
                 AND target_id = %s
                 ORDER BY id DESC
                 LIMIT 1",
                (string) $categoryId
            ), ARRAY_A);

            if (!$job) {
                // No job exists — reset to category_assigned so it gets re-queued
                $wpdb->update($table, [
                    'ai_status' => 'category_assigned',
                    'error_message' => 'Reset: no AI job found',
                ], ['id' => $queueId]);
                // Also reset category content_status
                $wpdb->update($categoriesTable, [
                    'content_status' => 'empty',
                ], ['id' => $categoryId]);
                $stats['reset']++;
                $stats['items'][] = ['id' => $queueId, 'action' => 'reset', 'reason' => 'no_job'];
                continue;
            }

            if ($job['status'] === 'completed') {
                // Job completed but queue wasn't synced — fix it now
                $wpdb->update($table, [
                    'ai_status' => 'completed',
                    'status' => 'completed',
                    'completed_at' => $job['completed_at'] ?: current_time('mysql'),
                ], ['id' => $queueId]);
                $stats['synced']++;
                $stats['items'][] = ['id' => $queueId, 'action' => 'synced_completed', 'job_id' => $job['id']];
            } elseif ($job['status'] === 'failed') {
                // Job failed but queue wasn't synced — fix it now
                $wpdb->update($table, [
                    'ai_status' => 'failed',
                    'error_message' => $job['error_message'] ?: 'AI job failed',
                ], ['id' => $queueId]);
                // Reset category content_status
                $wpdb->update($categoriesTable, [
                    'content_status' => 'empty',
                    'ai_error_message' => $job['error_message'] ?: 'AI job failed',
                ], ['id' => $categoryId]);
                $stats['synced']++;
                $stats['items'][] = ['id' => $queueId, 'action' => 'synced_failed', 'job_id' => $job['id']];
            } else {
                // Job is pending or processing — reset both to try again
                $wpdb->update($table, [
                    'ai_status' => 'category_assigned',
                    'error_message' => "Reset: job #{$job['id']} stuck at {$job['status']}",
                ], ['id' => $queueId]);
                // Reset category content_status
                $wpdb->update($categoriesTable, [
                    'content_status' => 'empty',
                    'ai_error_message' => null,
                ], ['id' => $categoryId]);
                // Mark the stale job as failed so it doesn't block new jobs
                $wpdb->update($jobsTable, [
                    'status' => 'failed',
                    'error_message' => 'Reset: stuck too long, will retry',
                ], ['id' => $job['id']]);
                $stats['reset']++;
                $stats['items'][] = ['id' => $queueId, 'action' => 'reset', 'reason' => "job_{$job['status']}", 'job_id' => $job['id']];
            }
        }

        if ($stats['total'] > 0) {
            error_log("[ACMS CronController] Reset stuck generating: {$stats['total']} found, {$stats['synced']} synced, {$stats['reset']} reset");
        }

        return $stats;
    }

    /**
     * Check if request is from admin (nonce) or external cron (token).
     */
    public function checkAdminOrCronToken(WP_REST_Request $request): bool
    {
        // Admin with valid nonce
        if (current_user_can('manage_options')) {
            return true;
        }

        // External cron with token
        return $this->checkCronToken($request);
    }

    /**
     * Backfill orphan products into acms_category_products.
     *
     * Strategy: Iterate cat_queue items with linked_asins + assigned_category_id.
     * For each queue item, find products matching those ASINs that are NOT already
     * in category_products, then INSERT them.
     *
     * Processes in batches (50 queue items per run) to avoid timeout.
     * Self-chains to continue processing remaining items.
     */
    public function runBackfillCategoryLinks(WP_REST_Request $request): WP_REST_Response
    {
        global $wpdb;

        $queueTable    = $wpdb->prefix . 'acms_cat_queue';
        $productsTable = $wpdb->prefix . 'acms_products';
        $catProdTable  = $wpdb->prefix . 'acms_category_products';

        $batchSize = 50; // queue items per run
        $offset    = (int) $request->get_param('offset');

        // Only lock initial calls (offset=0), not self-chained continuations
        if ($offset === 0 && !self::acquireLock('backfill_category_links', 120)) {
            return new WP_REST_Response([
                'success' => true,
                'message' => 'Skipped: recently executed (lock active)',
                'data'    => ['skipped' => true],
            ]);
        }
        $startTime = microtime(true);

        $totalLinked   = 0;
        $totalSkipped  = 0;
        $queueProcessed = 0;
        $errors        = [];

        try {
            // Get batch of queue items with assigned categories and linked ASINs
            $queueItems = $wpdb->get_results($wpdb->prepare(
                "SELECT id, keyword, assigned_category_id, linked_asins
                 FROM {$queueTable}
                 WHERE assigned_category_id IS NOT NULL
                   AND linked_asins IS NOT NULL
                   AND linked_asins != '[]'
                   AND linked_asins != 'null'
                 ORDER BY id ASC
                 LIMIT %d OFFSET %d",
                $batchSize,
                $offset
            ));

            if (empty($queueItems)) {
                $duration = round((microtime(true) - $startTime) * 1000);
                self::addLog('backfill_links', 'success',
                    "Backfill complete: no more queue items at offset {$offset}",
                    "Duration: {$duration}ms"
                );
                return new WP_REST_Response([
                    'success' => true,
                    'message' => "Backfill complete. No more queue items to process.",
                    'data'    => ['offset' => $offset, 'finished' => true],
                ]);
            }

            foreach ($queueItems as $item) {
                $categoryId = (int) $item->assigned_category_id;
                $asins = json_decode($item->linked_asins, true);

                if (!is_array($asins) || empty($asins)) {
                    $queueProcessed++;
                    continue;
                }

                // Clean ASINs - trim whitespace, filter empties
                $asins = array_filter(array_map('trim', $asins));
                if (empty($asins)) {
                    $queueProcessed++;
                    continue;
                }

                // Find product IDs for these ASINs
                $placeholders = implode(',', array_fill(0, count($asins), '%s'));
                $productRows = $wpdb->get_results(
                    $wpdb->prepare(
                        "SELECT id, asin FROM {$productsTable} WHERE asin IN ({$placeholders})",
                        ...$asins
                    )
                );

                if (empty($productRows)) {
                    $queueProcessed++;
                    continue;
                }

                // Check which products are NOT already linked to this category
                $productIds = array_column($productRows, 'id');
                $idPlaceholders = implode(',', array_fill(0, count($productIds), '%d'));
                $alreadyLinked = $wpdb->get_col(
                    $wpdb->prepare(
                        "SELECT product_id FROM {$catProdTable}
                         WHERE category_id = %d AND product_id IN ({$idPlaceholders})",
                        $categoryId,
                        ...$productIds
                    )
                );

                $alreadyLinkedMap = array_flip($alreadyLinked);

                // Get next position for this category
                $nextPosition = (int) $wpdb->get_var($wpdb->prepare(
                    "SELECT COALESCE(MAX(position), 0) + 1 FROM {$catProdTable} WHERE category_id = %d",
                    $categoryId
                ));

                $insertCount = 0;
                foreach ($productRows as $product) {
                    $productId = (int) $product->id;

                    if (isset($alreadyLinkedMap[$productId])) {
                        $totalSkipped++;
                        continue;
                    }

                    $result = $wpdb->insert($catProdTable, [
                        'category_id' => $categoryId,
                        'product_id'  => $productId,
                        'is_primary'  => 0,
                        'position'    => $nextPosition++,
                    ]);

                    if ($result) {
                        $insertCount++;
                        $totalLinked++;
                    } else {
                        $errors[] = "Failed to insert product {$productId} into category {$categoryId}";
                    }
                }

                // Update product_count for this category if we inserted any
                if ($insertCount > 0) {
                    $wpdb->query($wpdb->prepare(
                        "UPDATE {$wpdb->prefix}acms_categories
                         SET product_count = (
                             SELECT COUNT(*) FROM {$catProdTable} WHERE category_id = %d
                         )
                         WHERE id = %d",
                        $categoryId,
                        $categoryId
                    ));
                }

                $queueProcessed++;
            }

            $duration = round((microtime(true) - $startTime) * 1000);
            $nextOffset = $offset + $batchSize;
            $hasMore = count($queueItems) === $batchSize;

            $message = "Processed {$queueProcessed} queue items: linked {$totalLinked} products, skipped {$totalSkipped} existing.";
            if ($hasMore) {
                $message .= " More remaining (next offset: {$nextOffset}).";
            }

            self::addLog('backfill_links', 'success', $message, "Duration: {$duration}ms, Offset: {$offset}");

            // Self-chain if more items remain
            if ($hasMore) {
                $this->chainBackfill($nextOffset, $request->get_param('token'));
            }

            return new WP_REST_Response([
                'success' => true,
                'message' => $message,
                'data'    => [
                    'queue_processed' => $queueProcessed,
                    'products_linked' => $totalLinked,
                    'products_skipped' => $totalSkipped,
                    'errors'          => $errors,
                    'offset'          => $offset,
                    'next_offset'     => $hasMore ? $nextOffset : null,
                    'finished'        => !$hasMore,
                    'duration_ms'     => $duration,
                ],
            ]);
        } catch (\Throwable $e) {
            error_log('[ACMS Cat CronController] Backfill category links failed: ' . $e->getMessage());
            self::addLog('backfill_links', 'error', 'Backfill failed', $e->getMessage());

            return new WP_REST_Response([
                'success' => false,
                'message' => 'Error: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Fire a non-blocking self-chain request to continue backfill processing.
     */
    private function chainBackfill(int $offset, ?string $token): void
    {
        $url = rest_url('acms-cat/v1/cron/backfill-category-links');
        $url = add_query_arg(['token' => $token, 'offset' => $offset], $url);

        wp_remote_post($url, [
            'timeout'   => 0.5,
            'blocking'  => false,
            'sslverify' => false,
        ]);
    }

    /**
     * Rebuild the categories directory JSON cache.
     *
     * Pre-generates a static JSON file with tree, A-Z list, stats for /categories/ page.
     * Solves 512MB memory exhaustion from loading all 2500+ categories with LONGTEXT columns.
     */
    public function runRebuildCategoryCache(WP_REST_Request $request): WP_REST_Response
    {
        if (!self::acquireLock('rebuild_category_cache', 60)) {
            return new WP_REST_Response([
                'success' => true,
                'message' => 'Skipped: recently executed (lock active)',
                'data'    => ['skipped' => true],
            ]);
        }

        try {
            self::addLog('rebuild_cache', 'info', 'Category cache rebuild started');
            $startTime = microtime(true);

            $result = CategoryDirectoryCache::instance()->rebuild();

            $duration = round((microtime(true) - $startTime) * 1000);

            if ($result['success']) {
                $sizeKb = round(($result['file_size'] ?? 0) / 1024, 1);
                self::addLog('rebuild_cache', 'success',
                    "Cache rebuilt: {$result['categories_count']} cats, {$sizeKb}KB",
                    "Duration: {$duration}ms"
                );
            } else {
                self::addLog('rebuild_cache', 'error', $result['message'], "Duration: {$duration}ms");
            }

            return new WP_REST_Response([
                'success' => $result['success'],
                'message' => $result['message'],
                'data'    => array_merge($result, ['duration_ms' => $duration]),
            ]);
        } catch (\Throwable $e) {
            error_log('[ACMS Cat CronController] Category cache rebuild failed: ' . $e->getMessage());
            self::addLog('rebuild_cache', 'error', 'Cache rebuild failed', $e->getMessage());

            return new WP_REST_Response([
                'success' => false,
                'message' => 'Error: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Add a log entry for a cron type
     *
     * Uses the same WordPress option storage as the pro CronController
     * so all logs appear in one unified UI.
     *
     * @param string $type Log type (cat_queue, cat_monitor, category_ai, process_category_ai, brand_category_ai, retry_stuck)
     * @param string $status Status (info, success, warning, error)
     * @param string $message Log message
     * @param string|null $details Additional details
     */
    private static function addLog(string $type, string $status, string $message, ?string $details = null): void
    {
        $optionKey = 'acms_cron_logs_' . $type;
        $logs = get_option($optionKey, []);

        array_unshift($logs, [
            'time' => current_time('Y-m-d H:i:s'),
            'status' => $status,
            'message' => $message,
            'details' => $details,
        ]);

        // Keep only the last 20 entries
        $logs = array_slice($logs, 0, 20);

        update_option($optionKey, $logs, false);
    }

    /**
     * GET|POST /cron/bulk-update-worker
     *
     * Server cron endpoint. Processes up to 3 items from the active batch.
     * If no batch is running, returns immediately with no_batch status.
     */
    public function runBulkUpdateWorker(WP_REST_Request $request): WP_REST_Response
    {
        $batchId = $request->get_param('batch_id') ?: null;

        $worker = \AffiliateCMS\Categories\Core\BulkUpdateWorker::instance();
        $result = $worker->processBatch($batchId);

        return new WP_REST_Response([
            'ok'     => true,
            'result' => $result,
        ]);
    }
}
