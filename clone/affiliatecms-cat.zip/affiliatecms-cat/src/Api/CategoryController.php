<?php
/**
 * Category REST API Controller
 *
 * @package AffiliateCMS\Categories
 */

declare(strict_types=1);

namespace AffiliateCMS\Categories\Api;

use AffiliateCMS\Categories\Repositories\CategoryRepository;
use WP_REST_Controller;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;
use WP_Error;

class CategoryController extends WP_REST_Controller
{
    protected $namespace = 'acms-cat/v1';
    protected $rest_base = 'categories';

    private CategoryRepository $repository;

    public function __construct(CategoryRepository $repository)
    {
        $this->repository = $repository;
    }

    public function registerRoutes(): void
    {
        // GET /categories - List all categories
        register_rest_route($this->namespace, '/' . $this->rest_base, [
            [
                'methods' => WP_REST_Server::READABLE,
                'callback' => [$this, 'getCategories'],
                'permission_callback' => '__return_true',
                'args' => $this->getCollectionParams(),
            ],
            [
                'methods' => WP_REST_Server::CREATABLE,
                'callback' => [$this, 'createCategory'],
                'permission_callback' => [$this, 'createPermissionCheck'],
                'args' => $this->getCreateParams(),
            ],
        ]);

        // GET /categories/tree - Get category tree
        register_rest_route($this->namespace, '/' . $this->rest_base . '/tree', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'getTree'],
            'permission_callback' => '__return_true',
        ]);

        // GET /categories/featured - Get featured categories
        register_rest_route($this->namespace, '/' . $this->rest_base . '/featured', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'getFeatured'],
            'permission_callback' => '__return_true',
            'args' => [
                'limit' => [
                    'default' => 10,
                    'sanitize_callback' => 'absint',
                ],
            ],
        ]);

        // GET /categories/search - Search categories
        register_rest_route($this->namespace, '/' . $this->rest_base . '/search', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'searchCategories'],
            'permission_callback' => '__return_true',
            'args' => [
                'q' => [
                    'required' => true,
                    'sanitize_callback' => 'sanitize_text_field',
                    'description' => 'Search keyword',
                ],
                'limit' => [
                    'default' => 15,
                    'sanitize_callback' => 'absint',
                    'description' => 'Max number of results (default 15, max 50)',
                ],
            ],
        ]);

        // GET /categories/directory-az?letter=A — lazy-load A-Z directory by letter
        register_rest_route($this->namespace, '/' . $this->rest_base . '/directory-az', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'getDirectoryAz'],
            'permission_callback' => '__return_true',
            'args' => [
                'letter' => [
                    'required' => true,
                    'sanitize_callback' => 'sanitize_text_field',
                ],
            ],
        ]);

        // GET/PUT/DELETE /categories/{id}
        register_rest_route($this->namespace, '/' . $this->rest_base . '/(?P<id>\d+)', [
            [
                'methods' => WP_REST_Server::READABLE,
                'callback' => [$this, 'getCategory'],
                'permission_callback' => '__return_true',
            ],
            [
                'methods' => WP_REST_Server::EDITABLE,
                'callback' => [$this, 'updateCategory'],
                'permission_callback' => [$this, 'updatePermissionCheck'],
                'args' => $this->getUpdateParams(),
            ],
            [
                'methods' => WP_REST_Server::DELETABLE,
                'callback' => [$this, 'deleteCategory'],
                'permission_callback' => [$this, 'deletePermissionCheck'],
            ],
        ]);

        // GET /categories/{id}/children
        register_rest_route($this->namespace, '/' . $this->rest_base . '/(?P<id>\d+)/children', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'getChildren'],
            'permission_callback' => '__return_true',
        ]);

        // GET /categories/{id}/ancestors
        register_rest_route($this->namespace, '/' . $this->rest_base . '/(?P<id>\d+)/ancestors', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'getAncestors'],
            'permission_callback' => '__return_true',
        ]);

        // GET /categories/{id}/breadcrumb
        register_rest_route($this->namespace, '/' . $this->rest_base . '/(?P<id>\d+)/breadcrumb', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'getBreadcrumb'],
            'permission_callback' => '__return_true',
        ]);

        // GET /categories/{id}/products
        register_rest_route($this->namespace, '/' . $this->rest_base . '/(?P<id>\d+)/products', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'getProducts'],
            'permission_callback' => '__return_true',
            'args' => [
                'limit' => [
                    'default' => 20,
                    'sanitize_callback' => 'absint',
                ],
                'offset' => [
                    'default' => 0,
                    'sanitize_callback' => 'absint',
                ],
            ],
        ]);

        // GET /categories/{id}/products-page - Public paginated products (includes descendants)
        register_rest_route($this->namespace, '/' . $this->rest_base . '/(?P<id>\d+)/products-page', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'getProductsPage'],
            'permission_callback' => '__return_true',
            'args' => [
                'limit' => [
                    'default' => 50,
                    'sanitize_callback' => 'absint',
                ],
                'offset' => [
                    'default' => 0,
                    'sanitize_callback' => 'absint',
                ],
            ],
        ]);

        // POST /categories/{id}/products - Add product to category
        register_rest_route($this->namespace, '/' . $this->rest_base . '/(?P<id>\d+)/products', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'addProduct'],
            'permission_callback' => [$this, 'updatePermissionCheck'],
            'args' => [
                'product_id' => [
                    'required' => true,
                    'sanitize_callback' => 'absint',
                ],
                'is_primary' => [
                    'default' => false,
                    'sanitize_callback' => 'rest_sanitize_boolean',
                ],
            ],
        ]);

        // DELETE /categories/{id}/products/{product_id}
        register_rest_route($this->namespace, '/' . $this->rest_base . '/(?P<id>\d+)/products/(?P<product_id>\d+)', [
            'methods' => WP_REST_Server::DELETABLE,
            'callback' => [$this, 'removeProduct'],
            'permission_callback' => [$this, 'updatePermissionCheck'],
        ]);

        // POST /categories/{id}/move - Move category to new parent
        register_rest_route($this->namespace, '/' . $this->rest_base . '/(?P<id>\d+)/move', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'moveCategory'],
            'permission_callback' => [$this, 'updatePermissionCheck'],
            'args' => [
                'parent_id' => [
                    'required' => true,
                    'sanitize_callback' => 'absint',
                ],
            ],
        ]);

        // GET /categories/slug/{slug} - Get by slug
        register_rest_route($this->namespace, '/' . $this->rest_base . '/slug/(?P<slug>[a-z0-9-]+)', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'getCategoryBySlug'],
            'permission_callback' => '__return_true',
        ]);

        // GET /product-detail/{id} - Public product detail for category page
        register_rest_route($this->namespace, '/product-detail/(?P<id>\d+)', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'getProductDetail'],
            'permission_callback' => '__return_true',
        ]);

        // POST /categories/bulk-ai - Bulk AI content generation
        register_rest_route($this->namespace, '/' . $this->rest_base . '/bulk-ai', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'bulkAiGeneration'],
            'permission_callback' => [$this, 'updatePermissionCheck'],
            'args' => [
                'action' => [
                    'required' => true,
                    'enum' => ['generate', 'regenerate'],
                    'sanitize_callback' => 'sanitize_text_field',
                ],
                'category_ids' => [
                    'required' => true,
                    'type' => 'array',
                    'items' => ['type' => 'integer'],
                ],
                'include_children' => [
                    'default' => false,
                    'sanitize_callback' => 'rest_sanitize_boolean',
                ],
            ],
        ]);
    }

    // =========================================
    // Permission Checks
    // =========================================

    public function createPermissionCheck(): bool
    {
        return current_user_can('manage_options');
    }

    public function updatePermissionCheck(): bool
    {
        return current_user_can('manage_options');
    }

    public function deletePermissionCheck(): bool
    {
        return current_user_can('manage_options');
    }

    // =========================================
    // Endpoint Handlers
    // =========================================

    public function getCategories(WP_REST_Request $request): WP_REST_Response
    {
        $status = $request->get_param('status') ?: 'publish';
        $parent_id = $request->get_param('parent_id');
        $search = $request->get_param('search') ?? '';

        if ($search) {
            $limit = (int) ($request->get_param('limit') ?: 100);
            $categories = $this->repository->search($search, $limit, $status);
        } elseif ($parent_id !== null) {
            $categories = $this->repository->getChildren((int) $parent_id, $status);
        } else {
            $categories = $this->repository->getAll($status);
        }

        return new WP_REST_Response([
            'success' => true,
            'data' => $categories,
            'total' => count($categories),
        ]);
    }

    public function getCategory(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $id = (int) $request->get_param('id');
        $category = $this->repository->find($id);

        if (!$category) {
            return new WP_Error('not_found', 'Category not found', ['status' => 404]);
        }

        // Increment view count (async would be better)
        $this->repository->incrementViewCount($id);

        return new WP_REST_Response([
            'success' => true,
            'data' => $category,
        ]);
    }

    public function getCategoryBySlug(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $slug = $request->get_param('slug');
        $category = $this->repository->findBySlug($slug);

        if (!$category) {
            return new WP_Error('not_found', 'Category not found', ['status' => 404]);
        }

        $this->repository->incrementViewCount((int) $category['id']);

        return new WP_REST_Response([
            'success' => true,
            'data' => $category,
        ]);
    }

    /**
     * Get product detail for category page (public, read-only)
     * Returns only display fields — no admin/internal data
     */
    public function getProductDetail(WP_REST_Request $request): WP_REST_Response
    {
        global $wpdb;
        $id = (int) $request->get_param('id');
        $table = $wpdb->prefix . 'acms_products';

        $p = $wpdb->get_row($wpdb->prepare(
            "SELECT id, asin, features, custom_features, ai_features,
                    custom_pros, custom_cons, ai_short_review
             FROM {$table} WHERE id = %d AND status = 'scraped'",
            $id
        ));

        if (!$p) {
            return new WP_REST_Response(['error' => 'Not found'], 404);
        }

        $features_raw = $p->ai_features ?: ($p->custom_features ?: ($p->features ?? '[]'));
        $features = is_array($features_raw) ? $features_raw : (json_decode($features_raw, true) ?: []);

        $pros = [];
        if (!empty($p->custom_pros)) {
            $pros = is_array($p->custom_pros) ? $p->custom_pros : (json_decode($p->custom_pros, true) ?: []);
        }

        $cons = [];
        if (!empty($p->custom_cons)) {
            $cons = is_array($p->custom_cons) ? $p->custom_cons : (json_decode($p->custom_cons, true) ?: []);
        }

        // Load affiliate links if ProductLinkRepository is available
        $affiliate_links = [];
        if (class_exists(\AffiliateCMS\Pro\Repositories\ProductLinkRepository::class)) {
            $links = \AffiliateCMS\Pro\Repositories\ProductLinkRepository::instance()->getByProductId((int) $p->id);
            $affiliate_links = array_map(fn($link) => $link->toArray(), $links);

            // Wrap through redirect if enabled
            $gSettings = get_option('acms_general_settings', []);
            if (!empty($gSettings['redirect_enabled'])) {
                $slug = $gSettings['redirect_slug'] ?? 'go';
                $cfParam = $gSettings['cf_param'] ?? '';
                foreach ($affiliate_links as &$al) {
                    if (!empty($al['affiliate_url'])) {
                        $al['affiliate_url'] = home_url('/' . $slug . '/?url=' . urlencode($al['affiliate_url']));
                        if (!empty($cfParam)) {
                            $al['affiliate_url'] .= '&' . $cfParam;
                        }
                    }
                }
                unset($al);
            }
        }

        return new WP_REST_Response([
            'id' => (int) $p->id,
            'features' => $features,
            'pros' => $pros,
            'cons' => $cons,
            'short_review' => $p->ai_short_review ?? '',
            'affiliate_links' => $affiliate_links,
        ]);
    }

    public function createCategory(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $data = [
            'name' => $request->get_param('name'),
            'slug' => $request->get_param('slug'),
            'parent_id' => $request->get_param('parent_id') ?: 0,
            'description' => $request->get_param('description'),
            'seo_title' => $request->get_param('seo_title'),
            'seo_description' => $request->get_param('seo_description'),
            'status' => $request->get_param('status') ?: 'draft',
            'is_featured' => $request->get_param('is_featured') ? 1 : 0,
            'icon' => $request->get_param('icon'),
            'color' => $request->get_param('color'),
        ];

        $data = array_filter($data, fn($v) => $v !== null);

        $id = $this->repository->create($data);

        if (!$id) {
            return new WP_Error('create_failed', 'Failed to create category', ['status' => 500]);
        }

        $category = $this->repository->find($id);

        return new WP_REST_Response([
            'success' => true,
            'data' => $category,
            'message' => 'Category created successfully',
        ], 201);
    }

    public function updateCategory(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $id = (int) $request->get_param('id');
        $category = $this->repository->find($id);

        if (!$category) {
            return new WP_Error('not_found', 'Category not found', ['status' => 404]);
        }

        $data = [];
        $fields = ['name', 'slug', 'description', 'seo_title', 'seo_description', 'status', 'is_featured', 'icon', 'color', 'content_intro', 'content_main', 'content_faq', 'content_status', 'template', 'featured_image_id'];

        foreach ($fields as $field) {
            $value = $request->get_param($field);
            if ($value !== null) {
                $data[$field] = $field === 'is_featured' ? ($value ? 1 : 0) : $value;
            }
        }

        if (empty($data)) {
            return new WP_Error('no_data', 'No data to update', ['status' => 400]);
        }

        $result = $this->repository->update($id, $data);

        if (!$result) {
            return new WP_Error('update_failed', 'Failed to update category', ['status' => 500]);
        }

        $category = $this->repository->find($id);

        return new WP_REST_Response([
            'success' => true,
            'data' => $category,
            'message' => 'Category updated successfully',
        ]);
    }

    public function deleteCategory(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        global $wpdb;

        $id = (int) $request->get_param('id');
        $deleteMode = $request->get_param('delete_mode') ?: 'category_only';
        $childrenMode = $request->get_param('children_mode') ?: 'reassign'; // 'reassign' or 'delete'

        $category = $this->repository->find($id);

        if (!$category) {
            return new WP_Error('not_found', 'Category not found', ['status' => 404]);
        }

        $tables = \AffiliateCMS\Categories\Database\Schema::tables();
        $productsTable = $wpdb->prefix . 'acms_products';
        $categoryProductsTable = $tables['category_products'];

        $orphanedProducts = 0;
        $childrenHandled = 0;

        // Determine reassign flag for repository->delete()
        $reassignChildren = ($childrenMode === 'reassign');

        // Collect all category IDs that will be deleted (for orphaned product detection)
        $allCategoryIdsToDelete = [$id];
        if (!$reassignChildren) {
            // If deleting children too, collect all descendant IDs
            $descendants = $this->repository->getDescendants($id, 'all');
            $childrenHandled = count($descendants);
            foreach ($descendants as $desc) {
                $allCategoryIdsToDelete[] = (int) $desc['id'];
            }
        } else {
            // Count children that will be reassigned
            $children = $this->repository->getChildren($id, 'all');
            $childrenHandled = count($children);
        }

        // If full_data mode, delete orphaned products
        if ($deleteMode === 'full_data') {
            // Find products that are ONLY linked to categories being deleted
            $placeholders = implode(',', array_fill(0, count($allCategoryIdsToDelete), '%d'));
            $orphanedProductIds = $wpdb->get_col($wpdb->prepare(
                "SELECT cp.product_id
                 FROM {$categoryProductsTable} cp
                 WHERE cp.category_id IN ({$placeholders})
                 AND NOT EXISTS (
                     SELECT 1 FROM {$categoryProductsTable} cp2
                     WHERE cp2.product_id = cp.product_id
                     AND cp2.category_id NOT IN ({$placeholders})
                 )",
                ...array_merge($allCategoryIdsToDelete, $allCategoryIdsToDelete)
            ));

            // Deduplicate
            $orphanedProductIds = array_unique($orphanedProductIds);

            // Delete orphaned products from acms_products table
            if (!empty($orphanedProductIds)) {
                $orphanedProducts = count($orphanedProductIds);
                $pholders = implode(',', array_fill(0, count($orphanedProductIds), '%d'));
                $wpdb->query($wpdb->prepare(
                    "DELETE FROM {$productsTable} WHERE id IN ({$pholders})",
                    ...$orphanedProductIds
                ));
            }
        }

        $result = $this->repository->delete($id, $reassignChildren);

        if (!$result) {
            return new WP_Error('delete_failed', 'Failed to delete category', ['status' => 500]);
        }

        // Build response message
        $message = 'Category deleted successfully';
        if ($childrenHandled > 0) {
            if ($reassignChildren) {
                $message .= ". {$childrenHandled} child(ren) moved to parent.";
            } else {
                $message .= ". {$childrenHandled} child(ren) also deleted.";
            }
        }
        if ($orphanedProducts > 0) {
            $message .= " {$orphanedProducts} orphaned product(s) deleted.";
        }

        return new WP_REST_Response([
            'success' => true,
            'message' => $message,
            'children_handled' => $childrenHandled,
            'orphaned_products_deleted' => $orphanedProducts,
        ]);
    }

    public function getTree(WP_REST_Request $request): WP_REST_Response
    {
        $status = $request->get_param('status') ?: 'publish';
        $tree = $this->repository->getTree($status);

        return new WP_REST_Response([
            'success' => true,
            'data' => $tree,
        ]);
    }

    public function getFeatured(WP_REST_Request $request): WP_REST_Response
    {
        $limit = (int) $request->get_param('limit');
        $categories = $this->repository->getFeatured($limit);

        return new WP_REST_Response([
            'success' => true,
            'data' => $categories,
        ]);
    }

    /**
     * Search categories by keyword
     *
     * GET /wp-json/acms-cat/v1/categories/search?q=keyword&limit=10
     *
     * Searches in: name, slug, seo_title
     * Returns: id, name, slug, url, breadcrumb_path, product_count
     * Ordered by: exact match → starts with → partial match → product_count DESC
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    public function searchCategories(WP_REST_Request $request): WP_REST_Response
    {
        $q = $request->get_param('q');
        $limit = min((int) $request->get_param('limit'), 50); // Cap at 50 for performance

        if (empty($q)) {
            return new WP_REST_Response([
                'success' => false,
                'data' => [],
                'total' => 0,
                'message' => 'Search query (q) is required',
            ], 400);
        }

        $categories = $this->repository->search($q, $limit);

        return new WP_REST_Response([
            'success' => true,
            'data' => $categories,
            'total' => count($categories),
        ]);
    }

    /**
     * GET /categories/directory-az?letter=A
     * Returns A-Z categories for a single letter from pre-built JSON cache.
     */
    public function getDirectoryAz(WP_REST_Request $request): WP_REST_Response
    {
        $letter = mb_strtoupper(trim($request->get_param('letter')));

        if (empty($letter)) {
            return new WP_REST_Response(['success' => false, 'data' => []], 400);
        }

        $cached = \AffiliateCMS\Categories\Core\CategoryDirectoryCache::load();
        if ($cached === null) {
            return new WP_REST_Response(['success' => false, 'message' => 'Cache not available'], 503);
        }

        $items = $cached['az_grouped'][$letter] ?? [];

        return new WP_REST_Response([
            'success' => true,
            'letter'  => $letter,
            'data'    => $items,
            'total'   => count($items),
        ]);
    }

    public function getChildren(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $id = (int) $request->get_param('id');
        $category = $this->repository->find($id);

        if (!$category) {
            return new WP_Error('not_found', 'Category not found', ['status' => 404]);
        }

        // Lightweight mode: only return fields needed for tree navigation (no LONGTEXT)
        $fields = $request->get_param('fields');
        if ($fields === 'nav') {
            $children = $this->repository->getChildrenNav($id);
        } else {
            $children = $this->repository->getChildren($id);
        }

        // Exclude brand-categories from tree navigation (brand filter handles those)
        $exclude_brands = $request->get_param('exclude_brands');
        if ($exclude_brands) {
            $children = array_values(array_filter($children, fn($c) => empty($c['brand_id'])));
        }

        return new WP_REST_Response([
            'success' => true,
            'data' => $children,
        ]);
    }

    public function getAncestors(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $id = (int) $request->get_param('id');
        $category = $this->repository->find($id);

        if (!$category) {
            return new WP_Error('not_found', 'Category not found', ['status' => 404]);
        }

        $ancestors = $this->repository->getAncestors($id);

        return new WP_REST_Response([
            'success' => true,
            'data' => $ancestors,
        ]);
    }

    public function getBreadcrumb(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $id = (int) $request->get_param('id');
        $category = $this->repository->find($id);

        if (!$category) {
            return new WP_Error('not_found', 'Category not found', ['status' => 404]);
        }

        $breadcrumb = $this->repository->getBreadcrumb($id);

        return new WP_REST_Response([
            'success' => true,
            'data' => $breadcrumb,
        ]);
    }

    public function getProducts(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $id = (int) $request->get_param('id');
        $limit = (int) $request->get_param('limit');
        $offset = (int) $request->get_param('offset');

        $category = $this->repository->find($id);

        if (!$category) {
            return new WP_Error('not_found', 'Category not found', ['status' => 404]);
        }

        $products = $this->repository->getProducts($id, $limit, $offset);

        return new WP_REST_Response([
            'success' => true,
            'data' => $products,
            'total' => (int) $category['product_count'],
            'limit' => $limit,
            'offset' => $offset,
        ]);
    }

    /**
     * Get paginated products for a category including all descendants
     * Used by Load More button on category page
     */
    public function getProductsPage(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        global $wpdb;

        $id = (int) $request->get_param('id');
        $limit = min((int) $request->get_param('limit'), 100);
        $offset = (int) $request->get_param('offset');

        $categories_table = $wpdb->prefix . 'acms_categories';
        $products_table = $wpdb->prefix . 'acms_products';
        $cat_products_table = $wpdb->prefix . 'acms_category_products';

        $category = $this->repository->find($id);
        if (!$category) {
            return new WP_Error('not_found', 'Category not found', ['status' => 404]);
        }

        // Step 1: Get descendant category IDs via Materialized Path (fast index lookup)
        $current_path = rtrim($category['path'], '/');
        $descendant_pattern = $current_path . '/' . $category['id'] . '/%';
        $descendant_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT id FROM {$categories_table} WHERE path LIKE %s",
            $descendant_pattern
        ));
        $all_cat_ids = array_merge([$id], array_map('intval', $descendant_ids));
        $cat_placeholders = implode(',', array_fill(0, count($all_cat_ids), '%d'));

        // Step 2: Total count from junction table only (no products table JOIN needed)
        $total = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(DISTINCT product_id) FROM {$cat_products_table}
             WHERE category_id IN ({$cat_placeholders})",
            ...$all_cat_ids
        ));

        // Step 3: Get product IDs with pagination from junction table
        $product_rows = $wpdb->get_results($wpdb->prepare(
            "SELECT product_id, MIN(position) as position, MIN(category_id) as source_category_id
             FROM {$cat_products_table}
             WHERE category_id IN ({$cat_placeholders})
             GROUP BY product_id
             ORDER BY product_id DESC
             LIMIT %d OFFSET %d",
            ...array_merge($all_cat_ids, [$limit, $offset])
        ));

        // Step 4: Fetch only needed columns from products (skip LONGTEXT blobs)
        $products = [];
        if (!empty($product_rows)) {
            $pid_map = [];
            foreach ($product_rows as $row) {
                $pid_map[(int) $row->product_id] = $row;
            }
            $product_ids = array_keys($pid_map);
            $pid_placeholders = implode(',', array_fill(0, count($product_ids), '%d'));

            $products = $wpdb->get_results($wpdb->prepare(
                "SELECT id, asin, title, brand, price, original_price, currency, rating, reviews_count,
                        score, in_stock, is_prime, image_url, best_sellers_rank, updated_at, custom_title
                 FROM {$products_table}
                 WHERE id IN ({$pid_placeholders})
                 ORDER BY id DESC",
                ...$product_ids
            ));

            // Attach position & source_category_id from junction query
            foreach ($products as $p) {
                $meta = $pid_map[(int) $p->id] ?? null;
                $p->position = $meta ? $meta->position : 0;
                $p->source_category_id = $meta ? $meta->source_category_id : 0;
            }
        }

        // Get affiliate settings
        $acms_general = get_option('acms_general_settings', []);
        $affiliate_tag = !empty($acms_general['affiliate_tag']) ? $acms_general['affiliate_tag'] : '';
        if (!$affiliate_tag) {
            $affiliate_tag = get_option('acms_paapi_partner_tag', '');
        }
        if (!$affiliate_tag) {
            $affiliate_tag = get_option('acms_affiliate_tag', '');
        }
        $custom_url_params = !empty($acms_general['custom_url_params'])
            ? ltrim($acms_general['custom_url_params'], '&')
            : 'linkCode=ogi&th=1&psc=1';

        // Brand slugs lookup
        $brand_names = array_unique(array_filter(array_map(fn($p) => $p->brand ?? '', $products)));
        $brand_slugs = [];
        if (!empty($brand_names)) {
            $brands_table = $wpdb->prefix . 'acms_brands';
            $name_ph = implode(',', array_fill(0, count($brand_names), '%s'));
            $brand_rows = $wpdb->get_results($wpdb->prepare(
                "SELECT name, slug FROM {$brands_table} WHERE name IN ({$name_ph}) AND status = 'publish'",
                ...array_values($brand_names)
            ));
            foreach ($brand_rows as $br) {
                $brand_slugs[$br->name] = $br->slug;
            }
        }

        // Redirect settings for wrapping URLs
        $redirect_enabled = !empty($acms_general['redirect_enabled']);
        $redirect_slug = $acms_general['redirect_slug'] ?? 'go';
        $cf_param = $acms_general['cf_param'] ?? '';

        // Format products (same shape as Alpine inline data)
        $formatted = array_map(function ($p) use ($affiliate_tag, $custom_url_params, $brand_slugs, $redirect_enabled, $redirect_slug, $cf_param) {
            $title = !empty($p->custom_title) ? $p->custom_title : $p->title;
            $is_best_seller = false;
            if (!empty($p->best_sellers_rank) && is_string($p->best_sellers_rank)) {
                if (preg_match('/#(\d+)/', $p->best_sellers_rank, $m)) {
                    $is_best_seller = (int) $m[1] <= 100;
                }
            }

            $buy_url = 'https://www.amazon.com/dp/' . $p->asin . '?tag=' . urlencode($affiliate_tag) . ($custom_url_params ? '&' . $custom_url_params : '');

            // Wrap through redirect if enabled
            if ($redirect_enabled) {
                $buy_url = home_url('/' . $redirect_slug . '/?url=' . urlencode($buy_url));
                if (!empty($cf_param)) {
                    $buy_url .= '&' . $cf_param;
                }
            }

            return [
                'id' => (int) $p->id,
                'asin' => $p->asin,
                'title' => $title,
                'price' => (float) ($p->price ?? 0),
                'original_price' => (float) ($p->original_price ?? 0),
                'currency' => $p->currency ?? 'USD',
                'rating' => (float) ($p->rating ?? 0),
                'reviews_count' => (int) ($p->reviews_count ?? 0),
                'main_image' => $p->image_url ?? null,
                'buy_url' => $buy_url,
                'brand' => $p->brand ?? '',
                'brand_url' => isset($brand_slugs[$p->brand ?? '']) ? home_url('/brand/' . $brand_slugs[$p->brand] . '/') : '',
                'source_category_id' => (int) ($p->source_category_id ?? 0),
                'is_prime' => (bool) ($p->is_prime ?? false),
                'in_stock' => (bool) ($p->in_stock ?? true),
                'score' => (int) ($p->score ?? 70),
                'is_best_seller' => $is_best_seller,
                'updated_at' => $p->updated_at ?? null,
                'features' => [],
                'pros' => [],
                'cons' => [],
                'short_review' => '',
                'affiliate_links' => [],
                '_detailLoaded' => false,
            ];
        }, $products);

        return new WP_REST_Response([
            'data' => $formatted,
            'total' => $total,
            'has_more' => ($offset + $limit) < $total,
        ]);
    }

    public function addProduct(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $category_id = (int) $request->get_param('id');
        $product_id = (int) $request->get_param('product_id');
        $is_primary = (bool) $request->get_param('is_primary');

        $category = $this->repository->find($category_id);

        if (!$category) {
            return new WP_Error('not_found', 'Category not found', ['status' => 404]);
        }

        $result = $this->repository->addProduct($category_id, $product_id, $is_primary);

        if (!$result) {
            return new WP_Error('add_failed', 'Failed to add product to category', ['status' => 500]);
        }

        return new WP_REST_Response([
            'success' => true,
            'message' => 'Product added to category',
        ]);
    }

    public function removeProduct(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $category_id = (int) $request->get_param('id');
        $product_id = (int) $request->get_param('product_id');

        $result = $this->repository->removeProduct($category_id, $product_id);

        if (!$result) {
            return new WP_Error('remove_failed', 'Failed to remove product from category', ['status' => 500]);
        }

        return new WP_REST_Response([
            'success' => true,
            'message' => 'Product removed from category',
        ]);
    }

    public function moveCategory(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $id = (int) $request->get_param('id');
        $parent_id = (int) $request->get_param('parent_id');

        $category = $this->repository->find($id);

        if (!$category) {
            return new WP_Error('not_found', 'Category not found', ['status' => 404]);
        }

        $result = $this->repository->moveCategory($id, $parent_id);

        if (!$result) {
            return new WP_Error('move_failed', 'Failed to move category (check for circular reference)', ['status' => 400]);
        }

        $category = $this->repository->find($id);

        return new WP_REST_Response([
            'success' => true,
            'data' => $category,
            'message' => 'Category moved successfully',
        ]);
    }

    // =========================================
    // Bulk AI Generation
    // =========================================

    /**
     * Bulk AI content generation for categories
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response|WP_Error
     */
    public function bulkAiGeneration(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        global $wpdb;

        $action = $request->get_param('action');
        $categoryIds = $request->get_param('category_ids');
        $includeChildren = (bool) $request->get_param('include_children');

        // Validate category_ids
        if (!is_array($categoryIds) || empty($categoryIds)) {
            return new WP_Error('invalid_ids', 'category_ids must be a non-empty array', ['status' => 400]);
        }

        // Sanitize IDs
        $categoryIds = array_map('absint', $categoryIds);
        $categoryIds = array_filter($categoryIds);

        // If include_children, gather all descendant IDs
        if ($includeChildren) {
            $allIds = $categoryIds;
            foreach ($categoryIds as $parentId) {
                $descendants = $this->getAllDescendantIds($parentId);
                $allIds = array_merge($allIds, $descendants);
            }
            $categoryIds = array_unique($allIds);
        }

        // Limit to 200 categories when including children (more generous limit)
        $maxLimit = $includeChildren ? 200 : 50;
        if (count($categoryIds) > $maxLimit) {
            return new WP_Error('too_many', "Maximum {$maxLimit} categories per request", ['status' => 400]);
        }

        // Check if AI plugin is active (jobs table exists)
        $jobsTable = $wpdb->prefix . 'acms_ai_jobs';
        $tableExists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $jobsTable));
        if ($tableExists !== $jobsTable) {
            return new WP_Error('ai_not_active', 'AI plugin is not active. Please activate affiliatecms-ai plugin.', ['status' => 400]);
        }

        $queued = 0;
        $skipped = 0;
        $alreadyProcessing = 0;
        $alreadyGenerated = 0;

        foreach ($categoryIds as $categoryId) {
            $category = $this->repository->find($categoryId);

            if (!$category) {
                $skipped++;
                continue;
            }

            // Check for existing pending/processing job
            $existingJob = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$jobsTable}
                 WHERE type = 'generate_seo_category'
                 AND target_type = 'seo_category'
                 AND target_id = %s
                 AND status IN ('pending', 'processing')",
                (string) $categoryId
            ));

            if ($existingJob) {
                $alreadyProcessing++;
                continue;
            }

            // For "generate" action: skip if not empty
            if ($action === 'generate' && $category['content_status'] !== 'empty') {
                $alreadyGenerated++;
                continue;
            }

            // For "regenerate" action: reset content fields
            if ($action === 'regenerate') {
                $this->repository->update($categoryId, [
                    'content_intro' => null,
                    'content_main' => null,
                    'content_faq' => null,
                    'seo_title' => null,
                    'seo_description' => null,
                    'ai_error_message' => null,
                ]);
            }

            // Create AI job
            $success = $this->createAiJobForCategory($categoryId, $category);
            if ($success) {
                $queued++;
            } else {
                $skipped++;
            }
        }

        $message = "AI generation queued for {$queued} categories";
        if ($skipped > 0) {
            $message .= ", {$skipped} skipped";
        }
        if ($alreadyProcessing > 0) {
            $message .= ", {$alreadyProcessing} already processing";
        }
        if ($alreadyGenerated > 0 && $action === 'generate') {
            $message .= ", {$alreadyGenerated} already have content";
        }

        return new WP_REST_Response([
            'success' => true,
            'message' => $message,
            'data' => [
                'queued' => $queued,
                'skipped' => $skipped,
                'already_processing' => $alreadyProcessing,
                'already_generated' => $alreadyGenerated,
            ],
        ]);
    }

    /**
     * Create AI job for a single category
     *
     * @param int $categoryId
     * @param array $category
     * @return bool Success
     */
    private function createAiJobForCategory(int $categoryId, array $category): bool
    {
        global $wpdb;
        $jobsTable = $wpdb->prefix . 'acms_ai_jobs';

        // Mark category as generating
        $this->repository->update($categoryId, [
            'content_status' => 'ai_generating',
            'ai_generating_at' => current_time('mysql'),
            'ai_error_message' => null,
        ]);

        // Get products in this category
        $products = $this->getCategoryProductsForAi($categoryId);

        // Get parent categories for context
        $parentCategories = $this->getParentCategoryNamesForAi($categoryId);

        // Build category path
        $categoryPath = !empty($parentCategories)
            ? implode(' > ', $parentCategories) . ' > ' . $category['name']
            : $category['name'];

        // Gather related categories for internal linking
        $relatedCategories = $this->repository->getInternalLinkContext($categoryId);

        // Prepare job input data
        $inputData = [
            'category_id' => $categoryId,
            'category_name' => $category['name'],
            'category_slug' => $category['slug'] ?? '',
            'category_path' => $categoryPath,
            'parent_categories' => $parentCategories,
            'products' => $products,
            'current_description' => $category['description'] ?? '',
            'related_categories' => $relatedCategories,
        ];

        // Create the job
        $inserted = $wpdb->insert($jobsTable, [
            'type' => 'generate_seo_category',
            'status' => 'pending',
            'priority' => 40,
            'target_type' => 'seo_category',
            'target_id' => (string) $categoryId,
            'input_data' => wp_json_encode($inputData),
            'created_at' => current_time('mysql'),
        ]);

        if (!$inserted) {
            // Reset category status on failure
            $this->repository->update($categoryId, [
                'content_status' => 'empty',
                'ai_error_message' => 'Failed to create AI job',
            ]);
            return false;
        }

        // Job will be picked up by WP-Cron fallback (acms_ai_process_queue)
        return true;
    }

    /**
     * Get products in a category for AI context
     *
     * @param int $categoryId
     * @return array
     */
    private function getCategoryProductsForAi(int $categoryId): array
    {
        global $wpdb;

        $junctionTable = $wpdb->prefix . 'acms_category_products';
        $productsTable = $wpdb->prefix . 'acms_products';

        // Check if junction table exists
        $tableExists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $junctionTable));
        if ($tableExists !== $junctionTable) {
            return [];
        }

        $products = $wpdb->get_results($wpdb->prepare(
            "SELECT p.asin, p.title, p.brand, p.category_path, p.rating, p.reviews_count
             FROM {$productsTable} p
             INNER JOIN {$junctionTable} cp ON cp.product_id = p.id
             WHERE cp.category_id = %d AND p.status = 'scraped'
             ORDER BY cp.is_primary DESC, p.rating DESC
             LIMIT 15",
            $categoryId
        ), ARRAY_A);

        return $products ?: [];
    }

    /**
     * Get parent category names for breadcrumb/context
     *
     * @param int $categoryId
     * @return array Parent category names from root to direct parent
     */
    private function getParentCategoryNamesForAi(int $categoryId): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'acms_categories';

        // Get current category's path
        $category = $wpdb->get_row($wpdb->prepare(
            "SELECT path, parent_id FROM {$table} WHERE id = %d",
            $categoryId
        ), ARRAY_A);

        if (!$category || empty($category['path']) || $category['path'] === '/') {
            return [];
        }

        // Extract parent IDs from path (e.g., "/1/5/23/" -> [1, 5, 23])
        $pathIds = array_filter(explode('/', trim($category['path'], '/')));
        if (empty($pathIds)) {
            return [];
        }

        // Get parent category names in order
        $placeholders = implode(',', array_fill(0, count($pathIds), '%d'));
        $names = $wpdb->get_results($wpdb->prepare(
            "SELECT id, name FROM {$table} WHERE id IN ({$placeholders}) ORDER BY depth ASC",
            ...$pathIds
        ), ARRAY_A);

        // Return names in correct order
        $nameMap = [];
        foreach ($names as $cat) {
            $nameMap[$cat['id']] = $cat['name'];
        }

        $result = [];
        foreach ($pathIds as $id) {
            if (isset($nameMap[$id])) {
                $result[] = $nameMap[$id];
            }
        }

        return $result;
    }

    /**
     * Get all descendant IDs for a category (children, grandchildren, etc.)
     *
     * @param int $categoryId Parent category ID
     * @return array Array of descendant category IDs
     */
    private function getAllDescendantIds(int $categoryId): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'acms_categories';

        // Get the category's path to find all descendants
        $category = $wpdb->get_row($wpdb->prepare(
            "SELECT path FROM {$table} WHERE id = %d",
            $categoryId
        ), ARRAY_A);

        if (!$category) {
            return [];
        }

        // Build the path prefix for this category
        $pathPrefix = rtrim($category['path'], '/') . '/' . $categoryId . '/';

        // Find all categories whose path starts with this prefix
        $descendants = $wpdb->get_col($wpdb->prepare(
            "SELECT id FROM {$table} WHERE path LIKE %s",
            $wpdb->esc_like($pathPrefix) . '%'
        ));

        return array_map('intval', $descendants ?: []);
    }

    // =========================================
    // Parameter Definitions
    // =========================================

    protected function getCollectionParams(): array
    {
        return [
            'status' => [
                'default' => 'publish',
                'enum' => ['publish', 'draft', 'pending', 'trash', 'all'],
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'parent_id' => [
                'sanitize_callback' => 'absint',
            ],
        ];
    }

    protected function getCreateParams(): array
    {
        return [
            'name' => [
                'required' => true,
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'slug' => [
                'sanitize_callback' => 'sanitize_title',
            ],
            'parent_id' => [
                'default' => 0,
                'sanitize_callback' => 'absint',
            ],
            'description' => [
                'sanitize_callback' => 'wp_kses_post',
            ],
            'seo_title' => [
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'seo_description' => [
                'sanitize_callback' => 'sanitize_textarea_field',
            ],
            'status' => [
                'default' => 'draft',
                'enum' => ['publish', 'draft', 'pending'],
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'is_featured' => [
                'default' => false,
                'sanitize_callback' => 'rest_sanitize_boolean',
            ],
            'icon' => [
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'color' => [
                'sanitize_callback' => 'sanitize_hex_color',
            ],
        ];
    }

    protected function getUpdateParams(): array
    {
        $params = $this->getCreateParams();
        unset($params['name']['required']);
        return $params;
    }
}
