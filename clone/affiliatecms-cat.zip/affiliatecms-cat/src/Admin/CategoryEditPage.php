<?php
/**
 * Category Edit Page - Full SEO Post-like Editor
 *
 * @package AffiliateCMS\Categories
 */

declare(strict_types=1);

namespace AffiliateCMS\Categories\Admin;

use AffiliateCMS\Categories\Repositories\CategoryRepository;

class CategoryEditPage
{
    private CategoryRepository $repo;
    private ?array $category = null;
    private int $categoryId = 0;
    private bool $isNew = false;

    public function __construct(CategoryRepository $repo)
    {
        $this->repo = $repo;
    }

    /**
     * Enqueue admin assets
     */
    public function enqueueAssets(): void
    {
        // Bootstrap Icons
        wp_enqueue_style(
            'bootstrap-icons',
            'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css',
            [],
            '1.11.3'
        );

        // Alpine.js
        wp_enqueue_script(
            'alpinejs',
            'https://cdn.jsdelivr.net/npm/alpinejs@3.14.3/dist/cdn.min.js',
            [],
            '3.14.3',
            true
        );

        // WordPress Media Library
        wp_enqueue_media();

        // WordPress Editor (TinyMCE) - load all required scripts
        wp_enqueue_editor();
        wp_enqueue_script('editor');
        wp_enqueue_script('quicktags');
        wp_enqueue_style('editor-buttons');

        // Add defer attribute to Alpine.js
        add_filter('script_loader_tag', function($tag, $handle) {
            if ($handle === 'alpinejs') {
                return str_replace(' src', ' defer src', $tag);
            }
            return $tag;
        }, 10, 2);
    }

    /**
     * Render the edit page
     */
    public function render(): void
    {
        $this->enqueueAssets();

        // Get category ID from URL
        $this->categoryId = isset($_GET['id']) ? absint($_GET['id']) : 0;
        $this->isNew = $this->categoryId === 0;

        // Load category if editing
        if (!$this->isNew) {
            $this->category = $this->repo->find($this->categoryId);
            if (!$this->category) {
                echo '<div class="wrap"><div class="notice notice-error"><p>Category not found.</p></div></div>';
                return;
            }
        }

        // Fetch current parent name only (for display in autocomplete input)
        $parentId = (int) ($this->category['parent_id'] ?? 0);
        $parentName = '';
        if ($parentId > 0) {
            $parentCat = $this->repo->find($parentId);
            $parentName = $parentCat['name'] ?? '';
        }

        // Prepare category data for JavaScript
        $categoryData = $this->category ?: [
            'id' => 0,
            'name' => '',
            'slug' => '',
            'parent_id' => 0,
            'description' => '',
            'seo_title' => '',
            'seo_description' => '',
            'content_main' => '',
            'featured_image_id' => null,
            'icon' => '',
            'color' => '#3b82f6',
            'template' => 'default',
            'status' => 'draft',
            'is_featured' => 0,
        ];

        // Get featured image URL if exists
        $featuredImageUrl = '';
        if (!empty($categoryData['featured_image_id'])) {
            $featuredImageUrl = wp_get_attachment_image_url($categoryData['featured_image_id'], 'medium') ?: '';
        }

        ?>
        <style>
            <?php $this->renderStyles(); ?>
        </style>

        <?php
        // Build back URL - go to parent folder instead of root
        $backUrl = admin_url('admin.php?page=acms-categories');
        if ($parentId > 0) {
            $backUrl .= '#parent-' . $parentId;
        }
        ?>
        <script>
        window.acmsCatEditConfig = {
            restUrl: '<?php echo esc_js(rest_url('acms-cat/v1/')); ?>',
            nonce: '<?php echo esc_js(wp_create_nonce('wp_rest')); ?>',
            listUrl: '<?php echo esc_js(admin_url('admin.php?page=acms-categories')); ?>',
            backUrl: '<?php echo esc_js($backUrl); ?>',
            category: <?php echo wp_json_encode($categoryData); ?>,
            currentParentName: '<?php echo esc_js($parentName); ?>',
            currentCategoryId: <?php echo $this->categoryId; ?>,
            featuredImageUrl: '<?php echo esc_js($featuredImageUrl); ?>',
            isNew: <?php echo $this->isNew ? 'true' : 'false'; ?>
        };
        </script>

        <div id="acms-cat-edit" class="acms-admin" x-data="categoryEditor()">
            <div class="editor-container">
                <!-- Header -->
                <header class="editor-header">
                    <div class="header-left">
                        <a :href="backUrl" class="back-link">
                            <i class="bi bi-arrow-left"></i>
                            Back
                        </a>
                        <div class="header-divider"></div>
                        <h1 class="editor-title" x-text="isNew ? 'New Category' : 'Edit Category'"></h1>
                        <div class="status-indicator" :class="'status-' + form.status">
                            <span x-text="form.status.charAt(0).toUpperCase() + form.status.slice(1)"></span>
                        </div>
                    </div>
                    <div class="header-actions">
                        <!-- Generate with AI -->
                        <button type="button" class="btn btn-outline" @click="generateWithAI()" :disabled="isGenerating">
                            <i class="bi" :class="isGenerating ? 'bi-arrow-clockwise animate-spin' : 'bi-magic'"></i>
                            Generate AI
                        </button>

                        <div class="header-divider"></div>

                        <!-- View (only for existing) -->
                        <a :href="'/c/' + form.slug + '/'" target="_blank" class="btn btn-outline" x-show="!isNew && form.slug">
                            <i class="bi bi-eye"></i>
                            View
                        </a>

                        <!-- Delete (only for existing) -->
                        <button type="button" class="btn btn-outline btn-danger" @click="deleteCategory()" x-show="!isNew">
                            <i class="bi bi-trash"></i>
                            Delete
                        </button>

                        <div class="header-divider" x-show="!isNew"></div>

                        <!-- Save Draft -->
                        <button type="button" class="btn btn-secondary" @click="saveDraft()" :disabled="isSaving" x-show="form.status !== 'publish'">
                            <i class="bi" :class="isSaving ? 'bi-arrow-clockwise animate-spin' : 'bi-file-earmark'"></i>
                            Save Draft
                        </button>

                        <!-- Publish/Update -->
                        <button type="button" class="btn btn-primary" @click="saveCategory()" :disabled="isSaving || !form.name.trim()">
                            <i class="bi" :class="isSaving ? 'bi-arrow-clockwise animate-spin' : 'bi-check-lg'"></i>
                            <span x-text="isNew ? 'Publish' : (form.status === 'publish' ? 'Update' : 'Publish')"></span>
                        </button>
                    </div>
                </header>

                <!-- Main Content -->
                <div class="editor-main">
                    <!-- Left Column - Main Content -->
                    <div class="editor-content">
                        <!-- Name -->
                        <div class="form-group">
                            <label class="form-label">Name <span class="required">*</span></label>
                            <input type="text" class="form-input form-input-lg" x-model="form.name"
                                   @input="autoGenerateSlug()" placeholder="Category name">
                        </div>

                        <!-- Description -->
                        <div class="form-group">
                            <label class="form-label">Description</label>
                            <textarea class="form-textarea" rows="3" x-model="form.description"
                                      placeholder="Brief description of this category..."></textarea>
                            <p class="form-hint">Used as excerpt and fallback meta description.</p>
                        </div>

                        <!-- Main Content with TinyMCE -->
                        <div class="form-group">
                            <label class="form-label">Main Content</label>
                            <div class="wp-editor-wrapper" id="acms-editor-container">
                                <textarea id="acms_content_main" name="content_main" rows="20"><?php echo esc_textarea($categoryData['content_main'] ?? ''); ?></textarea>
                            </div>
                            <p class="form-hint">Displayed on the category page. Use formatting tools above.</p>
                        </div>

                        <!-- SEO Section -->
                        <div class="seo-section">
                            <h3 class="section-title">
                                <i class="bi bi-search"></i>
                                SEO Settings
                            </h3>

                            <!-- Google Preview -->
                            <div class="seo-preview">
                                <div class="seo-preview-title">Google Preview</div>
                                <div class="seo-preview-content">
                                    <div class="seo-preview-url" x-text="'<?php echo esc_js(home_url('/c/')); ?>' + (form.slug || 'category-slug') + '/'"></div>
                                    <h3 class="seo-preview-heading" x-text="form.seo_title || form.name || 'Category Title'"></h3>
                                    <p class="seo-preview-desc" x-text="(form.seo_description || form.description || 'Category description will appear here...').substring(0, 160)"></p>
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group flex-1">
                                    <label class="form-label">
                                        SEO Title
                                        <span class="char-count" :class="{ 'warning': form.seo_title.length > 60 }">
                                            <span x-text="form.seo_title.length"></span>/60
                                        </span>
                                    </label>
                                    <input type="text" class="form-input" x-model="form.seo_title"
                                           placeholder="Custom title for search engines (leave empty to use category name)">
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group flex-1">
                                    <label class="form-label">
                                        SEO Description
                                        <span class="char-count" :class="{ 'warning': form.seo_description.length > 160 }">
                                            <span x-text="form.seo_description.length"></span>/160
                                        </span>
                                    </label>
                                    <textarea class="form-textarea" rows="2" x-model="form.seo_description"
                                              placeholder="Meta description for search engines (leave empty to use category description)"></textarea>
                                </div>
                            </div>

                        </div>
                    </div>

                    <!-- Right Sidebar -->
                    <aside class="editor-sidebar">
                        <!-- Status Panel -->
                        <div class="sidebar-panel">
                            <h3 class="panel-title">
                                <i class="bi bi-gear"></i>
                                Status
                            </h3>
                            <div class="panel-body">
                                <div class="form-group">
                                    <label class="form-label">Status</label>
                                    <select class="form-select" x-model="form.status">
                                        <option value="draft">Draft</option>
                                        <option value="pending">Pending Review</option>
                                        <option value="publish">Published</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label class="checkbox-label">
                                        <input type="checkbox" :checked="form.is_featured == 1" @change="form.is_featured = $event.target.checked ? 1 : 0">
                                        <span>Featured Category</span>
                                    </label>
                                </div>
                            </div>
                        </div>

                        <!-- URL & Structure Panel -->
                        <div class="sidebar-panel">
                            <h3 class="panel-title">
                                <i class="bi bi-link-45deg"></i>
                                URL & Structure
                            </h3>
                            <div class="panel-body">
                                <div class="form-group">
                                    <label class="form-label">Slug</label>
                                    <div class="slug-input-wrapper">
                                        <span class="slug-prefix">/c/</span>
                                        <input type="text" class="form-input" x-model="form.slug" placeholder="category-slug" style="border: none !important; box-shadow: none !important;">
                                    </div>
                                </div>

                                <div class="form-group" x-data="parentSearch(form)" style="position:relative;">
                                    <label class="form-label">Parent Category</label>
                                    <div style="display:flex;gap:6px;align-items:center;">
                                        <input type="text" class="form-input"
                                            x-model="searchText"
                                            @input.debounce.300ms="fetchSuggestions()"
                                            @focus="if(searchText) fetchSuggestions()"
                                            @keydown.escape="closeSuggestions()"
                                            @click.outside="closeSuggestions()"
                                            placeholder="Search parent category..."
                                            autocomplete="off"
                                        >
                                        <button type="button" class="btn btn-sm btn-secondary" @click="clearParent()" x-show="form.parent_id > 0" title="Remove parent" style="white-space:nowrap;">
                                            <i class="bi bi-x"></i> Root
                                        </button>
                                    </div>
                                    <div x-show="open && (suggestions.length > 0 || loading)" style="position:absolute;z-index:999;background:#fff;border:1px solid #d0d5dd;border-radius:6px;box-shadow:0 4px 12px rgba(0,0,0,.12);width:100%;max-height:220px;overflow-y:auto;margin-top:2px;">
                                        <div x-show="loading" style="padding:10px;color:#888;font-size:13px;"><i class="bi bi-arrow-repeat"></i> Searching...</div>
                                        <template x-for="cat in suggestions" :key="cat.id">
                                            <div
                                                @click="selectParent(cat)"
                                                style="padding:8px 12px;cursor:pointer;font-size:13px;border-bottom:1px solid #f2f4f7;"
                                                @mouseenter="$el.style.background='#f5f8ff'"
                                                @mouseleave="$el.style.background=''"
                                            >
                                                <span x-text="cat.name" style="font-weight:500;"></span>
                                                <span x-show="cat.depth > 0" x-text="' · depth ' + cat.depth" style="color:#999;font-size:11px;margin-left:4px;"></span>
                                            </div>
                                        </template>
                                    </div>
                                    <div x-show="form.parent_id > 0" style="margin-top:4px;font-size:12px;color:#555;">
                                        Parent: <strong x-text="searchText"></strong> <span style="color:#999;">(ID: <span x-text="form.parent_id"></span>)</span>
                                    </div>
                                    <div x-show="!form.parent_id" style="margin-top:4px;font-size:12px;color:#999;">Root category (no parent)</div>
                                </div>

                            </div>
                        </div>

                        <!-- Display Panel -->
                        <div class="sidebar-panel">
                            <h3 class="panel-title">
                                <i class="bi bi-palette"></i>
                                Display
                            </h3>
                            <div class="panel-body">
                                <div class="form-group" x-data="{ iconPickerOpen: false, iconSearch: '', get filteredIcons() { const q = this.iconSearch.toLowerCase(); return q ? ACMS_ICON_LIST.filter(i => i.includes(q)) : ACMS_ICON_LIST; } }">
                                    <label class="form-label">Icon</label>
                                    <div class="icon-input-wrapper">
                                        <span class="icon-preview" x-show="form.icon" @click="iconPickerOpen = !iconPickerOpen" style="cursor: pointer;" title="Click to change">
                                            <i :class="'bi ' + form.icon"></i>
                                        </span>
                                        <input type="text" class="form-input" x-model="form.icon" placeholder="bi-tag" @focus="iconPickerOpen = true">
                                        <button type="button" class="btn btn-sm btn-outline" @click="iconPickerOpen = !iconPickerOpen" title="Browse icons" style="padding: 8px 10px; flex-shrink: 0;">
                                            <i class="bi bi-grid-3x3-gap"></i>
                                        </button>
                                    </div>
                                    <div class="icon-picker-dropdown" x-show="iconPickerOpen" x-cloak @click.outside="iconPickerOpen = false" x-transition>
                                        <div class="icon-picker-search">
                                            <input type="text" class="form-input" x-model="iconSearch" placeholder="Search icons..." style="font-size: 12px; padding: 6px 10px;">
                                        </div>
                                        <div class="icon-picker-grid">
                                            <template x-for="(icon, idx) in filteredIcons" :key="idx">
                                                <button type="button" class="icon-picker-item" :class="{ 'is-selected': form.icon === icon }"
                                                        @click="form.icon = icon; iconPickerOpen = false; iconSearch = '';" :title="icon">
                                                    <i :class="'bi ' + icon"></i>
                                                </button>
                                            </template>
                                        </div>
                                        <div class="icon-picker-footer" x-show="form.icon">
                                            <button type="button" class="btn btn-sm" style="font-size: 11px; padding: 4px 8px; color: var(--error);"
                                                    @click="form.icon = ''; iconPickerOpen = false;">
                                                <i class="bi bi-x"></i> Clear
                                            </button>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="form-label">Color</label>
                                    <div class="color-picker-wrapper">
                                        <input type="color" class="color-picker" x-model="form.color">
                                        <input type="text" class="form-input color-input" x-model="form.color" placeholder="#3b82f6">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Featured Image Panel -->
                        <div class="sidebar-panel">
                            <h3 class="panel-title">
                                <i class="bi bi-image"></i>
                                Featured Image
                            </h3>
                            <div class="panel-body">
                                <div class="featured-image-preview" x-show="featuredImageUrl" @click="selectFeaturedImage()">
                                    <img :src="featuredImageUrl" alt="Featured image">
                                    <button type="button" class="remove-image" @click.stop="removeFeaturedImage()" title="Remove image">
                                        <i class="bi bi-x-lg"></i>
                                    </button>
                                </div>
                                <button type="button" class="btn btn-outline btn-block"
                                        @click="selectFeaturedImage()" x-show="!featuredImageUrl">
                                    <i class="bi bi-upload"></i>
                                    Select Image
                                </button>
                            </div>
                        </div>

                        <!-- Stats Panel (for existing categories) -->
                        <div class="sidebar-panel" x-show="!isNew">
                            <h3 class="panel-title">
                                <i class="bi bi-bar-chart"></i>
                                Statistics
                            </h3>
                            <div class="panel-body">
                                <div class="stat-row">
                                    <span class="stat-label">Products</span>
                                    <span class="stat-value" x-text="category.product_count || 0"></span>
                                </div>
                                <div class="stat-row">
                                    <span class="stat-label">Children</span>
                                    <span class="stat-value" x-text="category.child_count || 0"></span>
                                </div>
                                <div class="stat-row">
                                    <span class="stat-label">Depth</span>
                                    <span class="stat-value" x-text="category.depth || 0"></span>
                                </div>
                            </div>
                        </div>
                    </aside>
                </div>
            </div>

            <!-- Toast -->
            <div class="toast-container" x-show="showToast" x-cloak
                 x-transition:enter="transition ease-out duration-300"
                 x-transition:enter-start="opacity-0 transform translate-y-4"
                 x-transition:enter-end="opacity-100 transform translate-y-0"
                 x-transition:leave="transition ease-in duration-200"
                 x-transition:leave-start="opacity-100"
                 x-transition:leave-end="opacity-0">
                <div class="toast" :class="'toast-' + toastType">
                    <div class="toast-icon">
                        <i class="bi" :class="{
                            'bi-check-circle-fill': toastType === 'success',
                            'bi-exclamation-triangle-fill': toastType === 'warning',
                            'bi-x-circle-fill': toastType === 'error',
                            'bi-info-circle-fill': toastType === 'info'
                        }"></i>
                    </div>
                    <div class="toast-content">
                        <div class="toast-title" x-text="toastTitle"></div>
                        <div class="toast-message" x-text="toastMessage"></div>
                    </div>
                    <button class="toast-close" @click="showToast = false">
                        <i class="bi bi-x"></i>
                    </button>
                </div>
            </div>

            <!-- Confirm Dialog -->
            <div class="confirm-overlay" x-show="confirmDialog.show" x-cloak
                 x-transition:enter="transition ease-out duration-200"
                 x-transition:enter-start="opacity-0"
                 x-transition:enter-end="opacity-100"
                 x-transition:leave="transition ease-in duration-150"
                 x-transition:leave-start="opacity-100"
                 x-transition:leave-end="opacity-0"
                 @click.self="confirmDialog.show = false">
                <div class="confirm-dialog"
                     x-transition:enter="transition ease-out duration-200"
                     x-transition:enter-start="opacity-0 transform scale-95"
                     x-transition:enter-end="opacity-100 transform scale-100">
                    <div class="confirm-icon" :class="'confirm-icon-' + confirmDialog.type">
                        <i class="bi" :class="confirmDialog.icon"></i>
                    </div>
                    <h3 class="confirm-title" x-text="confirmDialog.title"></h3>
                    <p class="confirm-message" x-text="confirmDialog.message"></p>
                    <div class="confirm-actions">
                        <button type="button" class="btn btn-outline" @click="confirmDialog.show = false">Cancel</button>
                        <button type="button" class="btn" :class="confirmDialog.btnClass || 'btn-primary'" @click="confirmDialog.onConfirm(); confirmDialog.show = false">
                            <span x-text="confirmDialog.confirmText || 'Confirm'"></span>
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <script>
        // Icon list for picker - curated Bootstrap Icons for e-commerce/categories
        const ACMS_ICON_LIST = [
            // Shopping & E-commerce
            'bi-cart', 'bi-cart-fill', 'bi-bag', 'bi-bag-fill', 'bi-shop', 'bi-shop-window',
            'bi-basket', 'bi-basket-fill', 'bi-gift', 'bi-gift-fill', 'bi-percent', 'bi-tags', 'bi-tags-fill',
            'bi-tag', 'bi-tag-fill', 'bi-credit-card', 'bi-wallet', 'bi-wallet2', 'bi-cash-stack',
            'bi-currency-dollar', 'bi-piggy-bank', 'bi-receipt', 'bi-box-seam', 'bi-box',
            // Tech & Electronics
            'bi-laptop', 'bi-pc-display', 'bi-phone', 'bi-tablet', 'bi-smartwatch', 'bi-headphones',
            'bi-speaker', 'bi-camera', 'bi-camera-video', 'bi-printer', 'bi-keyboard', 'bi-mouse',
            'bi-cpu', 'bi-gpu-card', 'bi-memory', 'bi-usb-drive', 'bi-router', 'bi-wifi',
            'bi-bluetooth', 'bi-battery-charging', 'bi-plug', 'bi-controller', 'bi-joystick',
            'bi-tv', 'bi-display', 'bi-projector',
            // Home & Living
            'bi-house', 'bi-house-fill', 'bi-house-door', 'bi-lamp', 'bi-lightbulb',
            'bi-fan', 'bi-thermometer', 'bi-droplet', 'bi-cup-hot', 'bi-cup-straw',
            // Fashion & Beauty
            'bi-watch', 'bi-eyeglasses', 'bi-sunglasses', 'bi-scissors', 'bi-gem',
            // Health & Fitness
            'bi-heart', 'bi-heart-fill', 'bi-heart-pulse', 'bi-activity', 'bi-bandaid',
            'bi-capsule', 'bi-lungs', 'bi-bicycle',
            // Sports & Outdoors
            'bi-trophy', 'bi-trophy-fill', 'bi-compass', 'bi-binoculars', 'bi-map',
            'bi-globe', 'bi-globe-americas', 'bi-globe-europe-africa', 'bi-flag',
            // Food & Drink
            'bi-egg-fried', 'bi-cup', 'bi-cup-fill',
            // Office & Work
            'bi-briefcase', 'bi-briefcase-fill', 'bi-clipboard', 'bi-journal', 'bi-book',
            'bi-pen', 'bi-pencil', 'bi-palette', 'bi-rulers', 'bi-tools', 'bi-wrench', 'bi-hammer',
            // Media & Entertainment
            'bi-music-note-beamed', 'bi-film', 'bi-play-circle', 'bi-headset', 'bi-vinyl',
            'bi-newspaper', 'bi-megaphone',
            // Transport & Auto
            'bi-car-front', 'bi-truck', 'bi-airplane', 'bi-fuel-pump',
            // Nature & Pets
            'bi-tree', 'bi-flower1', 'bi-flower2', 'bi-sun', 'bi-moon', 'bi-cloud',
            'bi-snow', 'bi-umbrella', 'bi-bug',
            // Baby & Kids
            'bi-balloon', 'bi-puzzle', 'bi-dice-5',
            // General UI
            'bi-star', 'bi-star-fill', 'bi-lightning', 'bi-lightning-fill', 'bi-fire',
            'bi-shield', 'bi-shield-check', 'bi-award', 'bi-patch-check', 'bi-rocket',
            'bi-speedometer', 'bi-bullseye', 'bi-magic', 'bi-infinity',
            'bi-arrow-through-heart', 'bi-bookmark', 'bi-bookmark-fill',
            'bi-pin-map', 'bi-geo-alt', 'bi-building', 'bi-buildings',
            'bi-hand-thumbs-up', 'bi-emoji-smile', 'bi-people', 'bi-person',
            'bi-graph-up', 'bi-bar-chart', 'bi-pie-chart', 'bi-diagram-3',
        ];

        document.addEventListener('alpine:init', () => {

            // Lazy-load parent category search — avoids dumping 100K+ categories into page HTML
            Alpine.data('parentSearch', (form) => ({
                form: form,
                searchText: acmsCatEditConfig.currentParentName || '',
                suggestions: [],
                loading: false,
                open: false,

                async fetchSuggestions() {
                    const q = this.searchText.trim();
                    if (q.length < 1) { this.suggestions = []; this.open = false; return; }
                    this.loading = true;
                    this.open = true;
                    try {
                        const excludeId = acmsCatEditConfig.currentCategoryId || 0;
                        const url = acmsCatEditConfig.restUrl + 'categories/search?q=' + encodeURIComponent(q) + '&limit=20&status=all&exclude=' + excludeId;
                        const res = await fetch(url, { headers: { 'X-WP-Nonce': acmsCatEditConfig.nonce } });
                        const data = await res.json();
                        this.suggestions = (data.data || []).filter(c => c.id != excludeId);
                    } catch(e) {
                        this.suggestions = [];
                    }
                    this.loading = false;
                },

                selectParent(cat) {
                    this.form.parent_id = cat.id;
                    this.searchText = cat.name;
                    this.closeSuggestions();
                },

                clearParent() {
                    this.form.parent_id = 0;
                    this.searchText = '';
                    this.closeSuggestions();
                },

                closeSuggestions() {
                    this.open = false;
                    this.suggestions = [];
                },
            }));

            Alpine.data('categoryEditor', () => ({
                // Config
                isNew: acmsCatEditConfig.isNew,
                category: acmsCatEditConfig.category,
                backUrl: acmsCatEditConfig.backUrl || acmsCatEditConfig.listUrl,

                // Form state
                form: {
                    name: acmsCatEditConfig.category.name || '',
                    slug: acmsCatEditConfig.category.slug || '',
                    parent_id: parseInt(acmsCatEditConfig.category.parent_id) || 0,
                    description: acmsCatEditConfig.category.description || '',
                    seo_title: acmsCatEditConfig.category.seo_title || '',
                    seo_description: acmsCatEditConfig.category.seo_description || '',
                    content_main: acmsCatEditConfig.category.content_main || '',
                    featured_image_id: acmsCatEditConfig.category.featured_image_id || null,
                    icon: acmsCatEditConfig.category.icon || '',
                    color: acmsCatEditConfig.category.color || '#3b82f6',
                    template: acmsCatEditConfig.category.template || 'default',
                    status: acmsCatEditConfig.category.status || 'draft',
                    is_featured: parseInt(acmsCatEditConfig.category.is_featured) || 0,
                },

                // UI state
                isSaving: false,
                isGenerating: false,
                featuredImageUrl: acmsCatEditConfig.featuredImageUrl || '',
                slugManuallyEdited: false,

                // Toast
                showToast: false,
                toastType: 'success',
                toastTitle: '',
                toastMessage: '',

                // Confirm dialog
                confirmDialog: {
                    show: false,
                    type: 'info',
                    icon: 'bi-question-circle',
                    title: '',
                    message: '',
                    confirmText: 'Confirm',
                    btnClass: 'btn-primary',
                    onConfirm: () => {},
                },

                init() {
                    // Watch for manual slug edits
                    this.$watch('form.slug', (newVal, oldVal) => {
                        if (newVal !== this.slugify(this.form.name)) {
                            this.slugManuallyEdited = true;
                        }
                    });
                },

                autoGenerateSlug() {
                    if (!this.slugManuallyEdited || !this.form.slug) {
                        this.form.slug = this.slugify(this.form.name);
                    }
                },

                slugify(text) {
                    return text.toLowerCase()
                        .replace(/[^a-z0-9]+/g, '-')
                        .replace(/^-+|-+$/g, '');
                },

                async saveDraft() {
                    this.form.status = 'draft';
                    // Sync TinyMCE content
                    this.syncEditorContent();
                    await this.saveCategory();
                },

                syncEditorContent() {
                    if (typeof tinymce !== 'undefined') {
                        const editor = tinymce.get('acms_content_main');
                        if (editor) {
                            this.form.content_main = editor.getContent();
                        }
                    } else {
                        // Fallback to textarea if TinyMCE not loaded (text mode)
                        const textarea = document.getElementById('acms_content_main');
                        if (textarea) {
                            this.form.content_main = textarea.value;
                        }
                    }
                },

                async saveCategory() {
                    if (!this.form.name.trim()) {
                        this.toast('error', 'Error', 'Category name is required');
                        return;
                    }

                    // Sync TinyMCE content before saving
                    this.syncEditorContent();

                    this.isSaving = true;

                    try {
                        const url = this.isNew
                            ? acmsCatEditConfig.restUrl + 'categories'
                            : acmsCatEditConfig.restUrl + 'categories/' + acmsCatEditConfig.category.id;

                        const method = this.isNew ? 'POST' : 'PUT';

                        // Ensure slug is generated if empty
                        if (!this.form.slug) {
                            this.form.slug = this.slugify(this.form.name);
                        }

                        // Set status to publish if not draft
                        if (this.form.status !== 'draft' && this.form.status !== 'pending') {
                            this.form.status = 'publish';
                        }

                        const response = await fetch(url, {
                            method: method,
                            headers: {
                                'Content-Type': 'application/json',
                                'X-WP-Nonce': acmsCatEditConfig.nonce
                            },
                            body: JSON.stringify(this.form)
                        });

                        const result = await response.json();

                        if (result.success) {
                            this.toast('success', 'Saved', this.isNew ? 'Category created successfully' : 'Category updated successfully');

                            if (this.isNew && result.data && result.data.id) {
                                // Redirect to edit page for new category
                                setTimeout(() => {
                                    window.location.href = acmsCatEditConfig.listUrl + '&action=edit&id=' + result.data.id;
                                }, 1000);
                            } else {
                                // Update local data
                                this.category = result.data;
                                this.isNew = false;
                            }
                        } else {
                            this.toast('error', 'Error', result.message || 'Failed to save category');
                        }
                    } catch (error) {
                        console.error('Save error:', error);
                        this.toast('error', 'Error', 'Failed to save category');
                    } finally {
                        this.isSaving = false;
                    }
                },

                deleteCategory() {
                    this.confirmDialog = {
                        show: true,
                        type: 'danger',
                        icon: 'bi-trash',
                        title: 'Delete Category',
                        message: 'This category and all its data will be permanently deleted. This action cannot be undone.',
                        confirmText: 'Delete',
                        btnClass: 'btn-danger',
                        onConfirm: () => this._doDeleteCategory(),
                    };
                },

                async _doDeleteCategory() {
                    try {
                        const response = await fetch(acmsCatEditConfig.restUrl + 'categories/' + acmsCatEditConfig.category.id, {
                            method: 'DELETE',
                            headers: {
                                'X-WP-Nonce': acmsCatEditConfig.nonce
                            }
                        });

                        const result = await response.json();

                        if (result.success) {
                            this.toast('success', 'Deleted', 'Category deleted');
                            setTimeout(() => {
                                window.location.href = acmsCatEditConfig.listUrl;
                            }, 1000);
                        } else {
                            this.toast('error', 'Error', result.message || 'Failed to delete category');
                        }
                    } catch (error) {
                        this.toast('error', 'Error', 'Failed to delete category');
                    }
                },

                selectFeaturedImage() {
                    const frame = wp.media({
                        title: 'Select Featured Image',
                        button: { text: 'Use this image' },
                        multiple: false
                    });

                    frame.on('select', () => {
                        const attachment = frame.state().get('selection').first().toJSON();
                        this.form.featured_image_id = attachment.id;
                        this.featuredImageUrl = attachment.sizes?.medium?.url || attachment.url;
                    });

                    frame.open();
                },

                removeFeaturedImage() {
                    this.form.featured_image_id = null;
                    this.featuredImageUrl = '';
                },

                generateWithAI() {
                    if (this.isNew) {
                        this.toast('warning', 'Save First', 'Please save the category before generating AI content');
                        return;
                    }

                    const hasContent = this.category.content_status === 'ai_generated' || this.category.content_status === 'manual';
                    this.confirmDialog = {
                        show: true,
                        type: hasContent ? 'warning' : 'info',
                        icon: 'bi-magic',
                        title: hasContent ? 'Regenerate AI Content' : 'Generate AI Content',
                        message: hasContent
                            ? 'A new AI content job will be queued. When complete, the new content will overwrite existing content.'
                            : 'An AI content generation job will be queued for this category. This may take a few minutes.',
                        confirmText: hasContent ? 'Regenerate' : 'Generate',
                        btnClass: 'btn-primary',
                        onConfirm: () => this._doGenerateWithAI(),
                    };
                },

                async _doGenerateWithAI() {
                    this.isGenerating = true;
                    try {
                        const response = await fetch(acmsCatEditConfig.restUrl + 'categories/bulk-ai', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-WP-Nonce': acmsCatEditConfig.nonce
                            },
                            body: JSON.stringify({
                                action: 'regenerate',
                                category_ids: [parseInt(acmsCatEditConfig.category.id)],
                                include_children: false
                            })
                        });

                        const result = await response.json();
                        if (result.success) {
                            this.toast('success', 'AI Generation Queued', result.message || 'Content generation job has been queued');
                        } else {
                            this.toast('error', 'Error', result.message || 'Failed to queue AI generation');
                        }
                    } catch (error) {
                        console.error('AI generation error:', error);
                        this.toast('error', 'Error', 'Failed to queue AI generation');
                    } finally {
                        this.isGenerating = false;
                    }
                },

                toast(type, title, message) {
                    this.toastType = type;
                    this.toastTitle = title;
                    this.toastMessage = message;
                    this.showToast = true;
                    setTimeout(() => { this.showToast = false; }, 5000);
                }
            }));
        });

        // Initialize TinyMCE on custom admin page
        (function() {
            const editorId = 'acms_content_main';
            let initialized = false;

            function initEditor() {
                if (initialized) return;

                // Check if wp.editor is available
                if (typeof wp === 'undefined' || typeof wp.editor === 'undefined') {
                    setTimeout(initEditor, 100);
                    return;
                }

                // Check if editor element exists
                const textarea = document.getElementById(editorId);
                if (!textarea) return;

                // Check if TinyMCE is already initialized for this editor
                if (typeof tinymce !== 'undefined' && tinymce.get(editorId)) {
                    initialized = true;
                    applyDarkMode(tinymce.get(editorId));
                    markEditorReady();
                    return;
                }

                initialized = true;

                // Initialize the editor
                wp.editor.initialize(editorId, {
                    tinymce: {
                        wpautop: true,
                        plugins: 'charmap,colorpicker,hr,lists,media,paste,tabfocus,textcolor,fullscreen,wordpress,wpeditimage,wpemoji,wpgallery,wplink,wptextpattern',
                        toolbar1: 'formatselect,bold,italic,bullist,numlist,blockquote,alignleft,aligncenter,alignright,link,wp_more,fullscreen,wp_adv',
                        toolbar2: 'strikethrough,hr,forecolor,pastetext,removeformat,charmap,outdent,indent,undo,redo,wp_help',
                        content_style: 'body { background: #0a0a0b !important; color: #fafafa !important; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; font-size: 14px; line-height: 1.6; padding: 16px; } a { color: #3b82f6; } h1,h2,h3,h4,h5,h6 { color: #fafafa; } blockquote { border-left: 3px solid #3b82f6; margin-left: 0; padding-left: 16px; color: #a1a1aa; }',
                        height: 400,
                        setup: function(editor) {
                            editor.on('init', function() {
                                applyDarkMode(editor);
                                // Mark editor ready for CSS styling
                                setTimeout(markEditorReady, 100);
                            });
                        }
                    },
                    quicktags: true,
                    mediaButtons: true
                });
            }

            function applyDarkMode(editor) {
                if (editor && editor.getBody()) {
                    editor.getBody().style.background = '#0a0a0b';
                    editor.getBody().style.color = '#fafafa';
                }
            }

            // Mark editor as ready for CSS styling (no DOM manipulation)
            function markEditorReady() {
                const wrapper = document.querySelector('.wp-editor-wrapper');
                if (!wrapper) return;
                if (wrapper.classList.contains('acms-editor-ready')) return;

                const toolbarGrp = wrapper.querySelector('.mce-toolbar-grp');
                if (toolbarGrp) {
                    wrapper.classList.add('acms-editor-ready');
                }
            }

            function setupModeWatcher() {
                // Watch for mode switch (Visual/Code) and re-apply if needed
            }

            // Initialize when DOM and WP scripts are ready
            if (document.readyState === 'complete') {
                setTimeout(function() {
                    initEditor();
                    setupModeWatcher();
                }, 50);
            } else {
                window.addEventListener('load', function() {
                    setTimeout(function() {
                        initEditor();
                        setupModeWatcher();
                    }, 50);
                });
            }
        })();
        </script>
        <?php
    }

    /**
     * Render CSS styles
     */
    private function renderStyles(): void
    {
        ?>
        /* CSS Variables - Dark Theme */
        :root {
            --primary: #2271b1;
            --primary-hover: #135e96;
            --primary-light: rgba(34, 113, 177, 0.1);
            --bg-base: #0a0a0b;
            --bg-surface: #111113;
            --bg-elevated: #18181b;
            --bg-hover: #1f1f23;
            --border: #27272a;
            --border-hover: #3f3f46;
            --text-primary: #fafafa;
            --text-secondary: #a1a1aa;
            --text-muted: #71717a;
            --success: #22c55e;
            --success-light: rgba(34, 197, 94, 0.1);
            --warning: #f59e0b;
            --warning-light: rgba(245, 158, 11, 0.1);
            --error: #ef4444;
            --error-light: rgba(239, 68, 68, 0.1);
            --info: #3b82f6;
            --info-light: rgba(59, 130, 246, 0.1);
            --radius-sm: 6px;
            --radius-md: 8px;
            --radius-lg: 12px;
            --shadow-md: 0 4px 12px rgba(0, 0, 0, 0.4);
            --shadow-lg: 0 10px 40px rgba(0, 0, 0, 0.5);
            --wp-admin-bar-height: 32px;
        }

        /* WP Admin Z-Index Fix */
        #adminmenuback, #adminmenuwrap { z-index: 1001 !important; }

        /* Reset */
        .acms-admin, .acms-admin *, .acms-admin *::before, .acms-admin *::after { box-sizing: border-box; }
        .acms-admin {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif !important;
            font-size: 14px !important;
            line-height: 1.5 !important;
            color: var(--text-primary) !important;
            -webkit-font-smoothing: antialiased;
        }
        [x-cloak] { display: none !important; }

        /* Layout */
        html.wp-toolbar, body.wp-admin { overflow: hidden !important; height: 100vh !important; }
        .wrap:has(.acms-admin) { margin: 0 !important; padding: 0 !important; max-width: none !important; }
        .acms-admin {
            position: fixed;
            top: var(--wp-admin-bar-height);
            left: 160px;
            right: 0;
            bottom: 0;
            overflow-y: auto;
            background: var(--bg-base);
        }
        .folded .acms-admin { left: 36px; }
        @media (max-width: 960px) { .acms-admin { left: 36px; } }
        @media (max-width: 782px) { .acms-admin { left: 0; top: 46px; } }

        .acms-admin h1, .acms-admin h2, .acms-admin h3, .acms-admin h4, .acms-admin h5, .acms-admin h6 {
            font-family: inherit;
            color: var(--text-primary);
            margin: 0;
            padding: 7px;
        }

        .editor-container { max-width: 1600px; margin: 0 auto; padding: 16px; }

        /* Header */
        .editor-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 16px;
            margin-bottom: 20px;
            padding: 12px 16px;
            background: var(--bg-surface);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
        }
        .header-left { display: flex; align-items: center; gap: 12px; }
        .back-link {
            display: flex;
            align-items: center;
            gap: 6px;
            color: var(--text-secondary);
            text-decoration: none;
            font-size: 13px;
            padding: 6px 10px;
            border-radius: var(--radius-md);
            transition: all 0.15s ease;
        }
        .back-link:hover { background: var(--bg-hover); color: var(--text-primary); }
        .editor-title {
            font-size: 18px;
            font-weight: 600;
            color: var(--text-primary);
            margin: 0;
        }
        .header-actions { display: flex; align-items: center; gap: 8px; }
        .header-divider { width: 1px; height: 24px; background: var(--border); margin: 0 4px; }

        /* Status Indicator */
        .status-indicator {
            padding: 4px 10px;
            font-size: 11px;
            font-weight: 500;
            border-radius: 20px;
            text-transform: uppercase;
        }
        .status-draft { background: var(--bg-hover); color: var(--text-muted); }
        .status-pending { background: var(--warning-light); color: var(--warning); }
        .status-publish { background: var(--success-light); color: var(--success); }

        /* Buttons */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            padding: 8px 14px;
            font-size: 13px;
            font-weight: 500;
            border-radius: var(--radius-md);
            border: 1px solid transparent;
            cursor: pointer;
            transition: all 0.15s ease;
            white-space: nowrap;
            text-decoration: none;
        }
        .btn:disabled { opacity: 0.5; cursor: not-allowed; }
        .btn-primary { background: var(--primary); color: white; border-color: var(--primary); }
        .btn-primary:hover:not(:disabled) { background: var(--primary-hover); }
        .btn-secondary { background: var(--bg-elevated); color: var(--text-primary); border-color: var(--border); }
        .btn-secondary:hover:not(:disabled) { background: var(--bg-hover); border-color: var(--border-hover); }
        .btn-outline { background: transparent; color: var(--text-secondary); border-color: var(--border); }
        .btn-outline:hover:not(:disabled) { background: var(--bg-hover); color: var(--text-primary); border-color: var(--border-hover); }
        .btn-block { width: 100%; }
        .btn-danger { color: var(--error); }
        .btn-danger:hover:not(:disabled) { background: var(--error-light); border-color: var(--error); }

        /* Main Layout */
        .editor-main {
            display: grid;
            grid-template-columns: 1fr 320px;
            gap: 20px;
            align-items: start;
        }
        @media (max-width: 1200px) {
            .editor-main { grid-template-columns: 1fr; }
            .editor-sidebar { order: -1; display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 16px; }
        }

        /* Editor Content */
        .editor-content {
            background: var(--bg-surface);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            padding: 24px;
        }

        /* Form Elements */
        .form-group { margin-bottom: 20px; }
        .form-group:last-child { margin-bottom: 0; }
        .form-row { display: flex; gap: 16px; }
        .form-row .form-group { flex: 1; margin-bottom: 16px; }
        .flex-1 { flex: 1; }

        .form-label {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 8px;
            font-size: 13px;
            font-weight: 500;
            color: var(--text-primary);
        }
        .required { color: var(--error); margin-left: 4px; }
        .form-hint { font-size: 12px; color: var(--text-muted); margin-top: 6px; }

        .form-input, .form-textarea, .form-select {
            width: 100%;
            padding: 10px 12px;
            font-size: 14px;
            color: var(--text-primary);
            background: var(--bg-base);
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
            transition: border-color 0.15s ease;
        }
        .form-input:focus, .form-textarea:focus, .form-select:focus {
            outline: none;
            border-color: var(--primary);
        }
        .form-input::placeholder, .form-textarea::placeholder { color: var(--text-muted); }
        .form-input-lg { font-size: 18px; padding: 12px 14px; font-weight: 500; }
        .form-textarea { resize: vertical; font-family: inherit; }
        .form-select { cursor: pointer; }

        /* Slug Input */
        .slug-input-wrapper {
            display: flex;
            align-items: center;
            background: var(--bg-base);
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
            overflow: hidden;
        }
        .slug-input-wrapper:focus-within { border-color: var(--primary); }
        .slug-prefix {
            padding: 10px 8px 10px 12px;
            font-size: 13px;
            color: var(--text-muted);
            background: var(--bg-elevated);
            border-right: 1px solid var(--border);
        }
        .slug-input-wrapper .form-input {
            border: none !important;
            border-radius: 0 !important;
            padding-left: 8px !important;
            padding-right: 12px !important;
            background: transparent !important;
        }
        .slug-input-wrapper .form-input:focus,
        .slug-input-wrapper .form-input:active,
        .slug-input-wrapper .form-input:hover {
            border: none !important;
            box-shadow: none !important;
            outline: none !important;
            border-color: transparent !important;
        }

        /* Icon Input */
        .icon-input-wrapper {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .icon-preview {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            background: var(--bg-elevated);
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
            font-size: 18px;
            color: var(--text-secondary);
        }
        .icon-input-wrapper .form-input { flex: 1; }

        /* Icon Picker Dropdown */
        .icon-picker-dropdown {
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            margin-top: 4px;
            background: var(--bg-elevated);
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
            box-shadow: var(--shadow-lg);
            z-index: 100;
            max-height: 320px;
            display: flex;
            flex-direction: column;
        }
        .icon-picker-search {
            padding: 8px;
            border-bottom: 1px solid var(--border);
        }
        .icon-picker-grid {
            display: grid;
            grid-template-columns: repeat(8, 1fr);
            gap: 2px;
            padding: 8px;
            overflow-y: auto;
            flex: 1;
        }
        .icon-picker-item {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 100%;
            aspect-ratio: 1;
            border: 1px solid transparent;
            border-radius: var(--radius-sm);
            background: none;
            color: var(--text-secondary);
            font-size: 16px;
            cursor: pointer;
            transition: all 0.1s ease;
        }
        .icon-picker-item:hover {
            background: var(--bg-hover);
            color: var(--text-primary);
            border-color: var(--border);
        }
        .icon-picker-item.is-selected {
            background: var(--primary-light);
            color: var(--primary);
            border-color: var(--primary);
        }
        .icon-picker-footer {
            padding: 6px 8px;
            border-top: 1px solid var(--border);
            text-align: right;
        }
        .form-group:has(.icon-picker-dropdown) { position: relative; }
        .sidebar-panel:has(.icon-picker-dropdown) { overflow: visible; }
        .sidebar-panel:has(.icon-picker-dropdown) .panel-body { overflow: visible; }

        /* Color Picker */
        .color-picker-wrapper { display: flex; gap: 8px; align-items: center; }
        .color-picker {
            width: 40px;
            height: 40px;
            padding: 2px;
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
            background: var(--bg-base);
            cursor: pointer;
        }
        .color-input { flex: 1; }

        /* Checkbox */
        .checkbox-label {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            font-size: 14px;
        }
        .checkbox-label input[type="checkbox"] {
            width: 18px;
            height: 18px;
            accent-color: var(--primary);
        }

        /* Character Count */
        .char-count {
            font-size: 11px;
            font-weight: 400;
            color: var(--text-muted);
        }
        .char-count.warning { color: var(--warning); }

        /* WordPress Editor Wrapper */
        .wp-editor-wrapper {
            display: block !important;
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
            overflow: visible;
        }
        .wp-editor-wrapper > textarea {
            width: 100%;
            min-height: 400px;
            padding: 16px;
            font-size: 14px;
            font-family: inherit;
            background: var(--bg-base);
            color: var(--text-primary);
            border: none;
            resize: vertical;
        }
        /* Force vertical stacking layout */
        .wp-editor-wrapper .wp-editor-wrap {
            display: block !important;
        }
        /* Editor container */
        .wp-editor-wrapper .wp-editor-container {
            display: block !important;
            clear: both !important;
            border: none !important;
            background: var(--bg-elevated) !important;
        }
        .wp-editor-wrapper .mce-tinymce {
            border: none !important;
            box-shadow: none !important;
        }
        .wp-editor-wrapper .mce-panel {
            background: var(--bg-surface) !important;
            border-color: var(--border) !important;
        }

        /* Force vertical stacking with CSS Grid */
        .wp-editor-wrapper .wp-editor-wrap {
            display: grid !important;
            grid-template-columns: 1fr !important;
            grid-template-rows: auto 1fr !important;
        }
        /* Row 1: Add Media (left) + Visual/Code tabs (right) */
        .wp-editor-wrapper .wp-editor-tools {
            grid-column: 1 !important;
            grid-row: 1 !important;
            padding: 8px 12px !important;
            background: var(--bg-elevated) !important;
            border-bottom: 1px solid var(--border) !important;
            box-sizing: border-box !important;
            overflow: hidden !important;
        }
        .wp-editor-wrapper .wp-media-buttons {
            float: left !important;
            padding: 0 !important;
        }
        .wp-editor-wrapper .wp-editor-tabs {
            float: right !important;
            display: flex !important;
            gap: 4px !important;
            background: transparent !important;
            border: none !important;
            padding: 0 !important;
        }

        /* Row 2: Editor container (full width below tools) */
        .wp-editor-wrapper .wp-editor-container {
            grid-column: 1 !important;
            grid-row: 2 !important;
            display: block !important;
            float: none !important;
            width: 100% !important;
            border: none !important;
            background: var(--bg-elevated) !important;
        }

        /* TinyMCE Toolbar (centered) */
        .wp-editor-wrapper .mce-toolbar-grp {
            background: var(--bg-elevated) !important;
            border-bottom: 1px solid var(--border) !important;
            padding: 8px 12px !important;
            text-align: center !important;
        }
        .wp-editor-wrapper .mce-toolbar-grp .mce-stack-layout {
            display: flex !important;
            flex-direction: column !important;
            align-items: center !important;
        }
        .wp-editor-wrapper .mce-toolbar-grp .mce-stack-layout-item {
            text-align: center !important;
            float: none !important;
            display: flex !important;
            justify-content: center !important;
        }
        .wp-editor-wrapper .mce-toolbar-grp .mce-toolbar {
            display: inline-flex !important;
            float: none !important;
        }
        /* Toolbar toggle (Shift+Alt+Z) - respect hidden state */
        .wp-editor-wrapper .mce-toolbar-grp .mce-toolbar[style*="display: none"] {
            display: none !important;
        }
        .wp-editor-wrapper .mce-toolbar-grp .mce-flow-layout {
            display: flex !important;
            flex-wrap: wrap !important;
            justify-content: center !important;
        }
        .wp-editor-wrapper .mce-toolbar-grp .mce-flow-layout-item {
            float: none !important;
        }
        /* Add Media Button - Dark Style */
        .wp-editor-wrapper .wp-media-buttons .button {
            background: var(--bg-surface) !important;
            border: 1px solid var(--border) !important;
            color: var(--text-secondary) !important;
            padding: 4px 12px !important;
            height: auto !important;
            line-height: 1.5 !important;
            font-size: 13px !important;
            border-radius: var(--radius-sm) !important;
            box-shadow: none !important;
            margin: 0 !important;
        }
        .wp-editor-wrapper .wp-media-buttons .button:hover {
            background: var(--bg-hover) !important;
            border-color: var(--border-hover) !important;
            color: var(--text-primary) !important;
        }
        .wp-editor-wrapper .wp-media-buttons .button .wp-media-buttons-icon:before {
            color: var(--text-muted) !important;
        }
        .wp-editor-wrapper .wp-media-buttons .button:hover .wp-media-buttons-icon:before {
            color: var(--text-secondary) !important;
        }

        /* Visual/Code Tabs - Better visibility */
        .wp-editor-wrapper .wp-switch-editor {
            background: var(--bg-surface) !important;
            border: 1px solid var(--border) !important;
            color: var(--text-muted) !important;
            padding: 4px 14px !important;
            height: auto !important;
            margin: 0 0 0 4px !important;
            font-size: 13px !important;
            border-radius: var(--radius-sm) !important;
            font-weight: 500 !important;
        }
        .wp-editor-wrapper .wp-switch-editor:hover {
            background: var(--bg-hover) !important;
            color: var(--text-secondary) !important;
        }
        .wp-editor-wrapper .wp-switch-editor:focus,
        .wp-editor-wrapper .wp-switch-editor:active {
            box-shadow: none !important;
        }
        /* Active tab - Primary color highlight */
        .wp-editor-wrapper .html-active .switch-html,
        .wp-editor-wrapper .tmce-active .switch-tmce {
            background: var(--primary) !important;
            border-color: var(--primary) !important;
            color: #fff !important;
        }

        /* TinyMCE edit area */
        .wp-editor-wrapper .mce-edit-area {
            border-top: none !important;
        }
        .wp-editor-wrapper .mce-btn,
        .wp-editor-wrapper .mce-btn button {
            background: transparent !important;
            border-color: transparent !important;
            color: var(--text-secondary) !important;
        }
        .wp-editor-wrapper .mce-btn:hover,
        .wp-editor-wrapper .mce-btn.mce-active {
            background: var(--bg-hover) !important;
            border-color: var(--border) !important;
            color: var(--text-primary) !important;
        }
        .wp-editor-wrapper .mce-btn i {
            color: var(--text-secondary) !important;
        }
        .wp-editor-wrapper .mce-btn:hover i,
        .wp-editor-wrapper .mce-btn.mce-active i {
            color: var(--text-primary) !important;
        }
        .wp-editor-wrapper .mce-ico {
            color: var(--text-secondary) !important;
        }
        .wp-editor-wrapper .mce-menubtn.mce-fixed-width span {
            color: var(--text-secondary) !important;
        }
        .wp-editor-wrapper .mce-edit-area iframe {
            background: var(--bg-base) !important;
        }
        /* Quicktags toolbar - Code mode */
        .wp-editor-wrapper .quicktags-toolbar {
            background: var(--bg-elevated) !important;
            border: none !important;
            border-bottom: 1px solid var(--border) !important;
            padding: 8px 12px !important;
            text-align: center !important;
        }
        .wp-editor-wrapper .quicktags-toolbar .ed_button {
            float: none !important;
            display: inline-block !important;
        }
        /* Quicktags buttons container - centered */
        .wp-editor-wrapper .quicktags-toolbar > input.ed_button {
            display: inline-block !important;
        }
        .wp-editor-wrapper .ed_button {
            background: var(--bg-surface) !important;
            border: 1px solid var(--border) !important;
            color: var(--text-secondary) !important;
            padding: 4px 10px !important;
            border-radius: var(--radius-sm) !important;
            font-size: 12px !important;
            height: auto !important;
            line-height: 1.4 !important;
        }
        .wp-editor-wrapper .ed_button:hover {
            background: var(--bg-hover) !important;
            color: var(--text-primary) !important;
            border-color: var(--border-hover) !important;
        }
        .wp-editor-wrapper .ed_button:focus {
            outline: none !important;
            box-shadow: none !important;
        }
        .wp-editor-wrapper textarea.wp-editor-area {
            background: var(--bg-base) !important;
            color: var(--text-primary) !important;
            border: none !important;
            font-family: 'SF Mono', Monaco, Consolas, monospace !important;
            font-size: 13px !important;
            padding: 16px !important;
        }
        .wp-editor-wrapper .mce-statusbar {
            background: var(--bg-elevated) !important;
            border-top: 1px solid var(--border) !important;
        }
        .wp-editor-wrapper .mce-path,
        .wp-editor-wrapper .mce-path-item {
            color: var(--text-muted) !important;
        }
        .wp-editor-wrapper .mce-wordcount {
            color: var(--text-muted) !important;
        }
        /* TinyMCE content area */
        .wp-editor-wrapper .mce-content-body {
            background: var(--bg-base) !important;
            color: var(--text-primary) !important;
            padding: 16px !important;
        }

        /* TinyMCE Floating Panels & Menus (outside wrapper - global) */
        .mce-floatpanel,
        .mce-menu,
        .mce-popover {
            background: #18181b !important;
            border: 1px solid #27272a !important;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.5) !important;
        }
        .mce-menu-item {
            background: transparent !important;
            color: #fafafa !important;
        }
        .mce-menu-item:hover,
        .mce-menu-item.mce-selected,
        .mce-menu-item:focus {
            background: #1f1f23 !important;
            color: #fafafa !important;
        }
        .mce-menu-item .mce-text {
            color: #fafafa !important;
        }
        .mce-menu-item .mce-ico {
            color: #a1a1aa !important;
        }
        .mce-menu-item:hover .mce-text,
        .mce-menu-item:hover .mce-ico {
            color: #fafafa !important;
        }
        .mce-menu-item-sep,
        .mce-menu .mce-menu-item-sep {
            background: #27272a !important;
            border: none !important;
        }
        /* Format selector dropdown */
        .mce-listbox,
        .mce-menubtn {
            background: #111113 !important;
            border-color: #27272a !important;
        }
        .mce-listbox button,
        .mce-menubtn button {
            color: #a1a1aa !important;
        }
        .mce-listbox:hover,
        .mce-menubtn:hover {
            background: #1f1f23 !important;
            border-color: #3f3f46 !important;
        }
        .mce-listbox:hover button,
        .mce-menubtn:hover button {
            color: #fafafa !important;
        }
        .mce-open {
            border-left-color: #27272a !important;
        }
        .mce-caret {
            border-top-color: #a1a1aa !important;
        }
        /* TinyMCE panel backgrounds */
        .mce-panel {
            background: #111113 !important;
            border-color: #27272a !important;
        }
        .mce-toolbar-grp {
            background: #18181b !important;
            border-bottom: 1px solid #27272a !important;
        }
        /* TinyMCE buttons global */
        .mce-btn {
            background: transparent !important;
            border-color: transparent !important;
        }
        .mce-btn button {
            color: #a1a1aa !important;
        }
        .mce-btn:hover,
        .mce-btn.mce-active {
            background: #1f1f23 !important;
            border-color: #27272a !important;
        }
        .mce-btn:hover button,
        .mce-btn.mce-active button {
            color: #fafafa !important;
        }
        .mce-ico {
            color: #a1a1aa !important;
        }
        .mce-btn:hover .mce-ico,
        .mce-btn.mce-active .mce-ico {
            color: #fafafa !important;
        }
        /* Format preview text in dropdown */
        .mce-menu .mce-menu-item-preview {
            color: #fafafa !important;
        }
        h1.mce-menu-item-preview { font-size: 2em !important; }
        h2.mce-menu-item-preview { font-size: 1.5em !important; }
        h3.mce-menu-item-preview { font-size: 1.17em !important; }
        h4.mce-menu-item-preview { font-size: 1em !important; }
        h5.mce-menu-item-preview { font-size: 0.83em !important; }
        h6.mce-menu-item-preview { font-size: 0.67em !important; }
        /* Color picker */
        .mce-colorbutton-grid {
            background: #18181b !important;
            border-color: #27272a !important;
        }
        /* Link dialog */
        .mce-window {
            background: #18181b !important;
            border: 1px solid #27272a !important;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.5) !important;
        }
        .mce-window-head {
            background: #111113 !important;
            border-bottom: 1px solid #27272a !important;
        }
        .mce-window-head .mce-title {
            color: #fafafa !important;
        }
        .mce-window-body {
            background: #18181b !important;
        }
        .mce-textbox {
            background: #0a0a0b !important;
            border-color: #27272a !important;
            color: #fafafa !important;
        }
        .mce-label {
            color: #a1a1aa !important;
            text-shadow: none !important;
        }
        .mce-foot {
            background: #111113 !important;
            border-top: 1px solid #27272a !important;
        }
        .mce-primary {
            background: #2271b1 !important;
            border-color: #2271b1 !important;
        }
        .mce-primary button {
            color: #fff !important;
        }
        .mce-close {
            color: #a1a1aa !important;
        }
        .mce-close:hover {
            color: #fafafa !important;
        }

        /* SEO Section */
        .seo-section {
            margin-top: 24px;
            padding-top: 24px;
            border-top: 1px solid var(--border);
        }
        .section-title {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 14px;
            font-weight: 600;
            color: var(--text-primary);
            margin: 0 0 16px;
        }
        .section-title i { color: var(--text-muted); }

        /* SEO Preview */
        .seo-preview {
            background: var(--bg-elevated);
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
            padding: 16px;
            margin-bottom: 20px;
        }
        .seo-preview-title {
            font-size: 11px;
            font-weight: 600;
            color: var(--text-muted);
            text-transform: uppercase;
            margin-bottom: 12px;
        }
        .seo-preview-content { font-family: Arial, sans-serif; }
        .seo-preview-url { font-size: 12px; color: #006621; margin-bottom: 4px; }
        .seo-preview-heading { font-size: 18px; color: #1a0dab; margin: 0 0 4px; font-weight: 400; }
        .seo-preview-desc { font-size: 13px; color: #545454; margin: 0; line-height: 1.4; }

        /* Sidebar */
        .editor-sidebar { display: flex; flex-direction: column; gap: 16px; }

        .sidebar-panel {
            background: var(--bg-surface);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            overflow: hidden;
        }
        .panel-title {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 12px 16px;
            font-size: 13px;
            font-weight: 600;
            color: var(--text-primary);
            background: var(--bg-elevated);
            border-bottom: 1px solid var(--border);
            margin: 0;
        }
        .panel-body { padding: 16px; }
        .panel-body .form-group { margin-bottom: 16px; }
        .panel-body .form-group:last-child { margin-bottom: 0; }

        /* Stats */
        .stat-row {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid var(--border);
        }
        .stat-row:last-child { border-bottom: none; padding-bottom: 0; }
        .stat-row:first-child { padding-top: 0; }
        .stat-label { color: var(--text-secondary); font-size: 13px; }
        .stat-value { font-weight: 600; color: var(--text-primary); }

        /* Featured Image */
        .featured-image-preview {
            position: relative;
            border-radius: var(--radius-md);
            overflow: hidden;
            cursor: pointer;
        }
        .featured-image-preview img {
            width: 100%;
            height: auto;
            display: block;
        }
        .featured-image-preview .remove-image {
            position: absolute;
            top: 8px;
            right: 8px;
            width: 28px;
            height: 28px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: var(--bg-base);
            border: 1px solid var(--border);
            border-radius: 50%;
            color: var(--text-secondary);
            cursor: pointer;
            opacity: 0;
            transition: all 0.15s ease;
        }
        .featured-image-preview:hover .remove-image { opacity: 1; }
        .featured-image-preview .remove-image:hover {
            background: var(--error);
            color: white;
            border-color: var(--error);
        }

        /* Toast */
        .toast-container {
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 10001;
        }
        .toast {
            display: flex;
            align-items: flex-start;
            gap: 12px;
            padding: 16px;
            background: var(--bg-elevated);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-lg);
            min-width: 300px;
            max-width: 400px;
        }
        .toast-icon { font-size: 20px; flex-shrink: 0; }
        .toast-success .toast-icon { color: var(--success); }
        .toast-warning .toast-icon { color: var(--warning); }
        .toast-error .toast-icon { color: var(--error); }
        .toast-info .toast-icon { color: var(--info); }
        .toast-content { flex: 1; }
        .toast-title { font-weight: 600; color: var(--text-primary); margin-bottom: 2px; }
        .toast-message { font-size: 13px; color: var(--text-secondary); }
        .toast-close {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 24px;
            height: 24px;
            padding: 0;
            background: transparent;
            border: none;
            color: var(--text-muted);
            cursor: pointer;
            border-radius: var(--radius-sm);
        }
        .toast-close:hover { background: var(--bg-hover); color: var(--text-primary); }

        /* Confirm Dialog */
        .confirm-overlay {
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.6);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 10000;
            backdrop-filter: blur(2px);
        }
        .confirm-dialog {
            background: var(--bg-surface);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            padding: 28px;
            max-width: 400px;
            width: 90%;
            text-align: center;
            box-shadow: var(--shadow-lg);
        }
        .confirm-icon {
            width: 48px;
            height: 48px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 16px;
            font-size: 22px;
        }
        .confirm-icon-info { background: var(--info-light); color: var(--info); }
        .confirm-icon-warning { background: var(--warning-light); color: var(--warning); }
        .confirm-icon-danger { background: var(--error-light); color: var(--error); }
        .confirm-title {
            font-size: 16px;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 8px;
            padding: 0;
        }
        .confirm-message {
            font-size: 13px;
            color: var(--text-secondary);
            line-height: 1.5;
            margin-bottom: 24px;
        }
        .confirm-actions {
            display: flex;
            gap: 10px;
            justify-content: center;
        }
        .confirm-actions .btn { min-width: 100px; }
        .btn-danger {
            background: var(--error) !important;
            color: #fff !important;
            border-color: var(--error) !important;
        }
        .btn-danger:hover { opacity: 0.9; }

        /* Animations */
        .animate-spin { animation: spin 1s linear infinite; }
        @keyframes spin { to { transform: rotate(360deg); } }
        <?php
    }
}
