<?php
/**
 * AffiliateCMS Categories - Settings Page
 */

declare(strict_types=1);

namespace AffiliateCMS\Cat\Admin;

class SettingsPage
{
    /**
     * Render the settings page
     */
    public function render(): void
    {
        // Handle form submission
        if (isset($_POST['acms_cat_save_settings']) && check_admin_referer('acms_cat_settings')) {
            $this->saveSettings();
        }

        $settings = $this->getSettings();
        ?>
        <div class="wrap acms-admin">
            <div class="acms-page-header">
                <div class="acms-page-header__title">
                    <h1><?php esc_html_e('Category Settings', 'affiliatecms-cat'); ?></h1>
                </div>
            </div>

            <form method="post" action="">
                <?php wp_nonce_field('acms_cat_settings'); ?>

                <div style="max-width: 800px;">
                    <!-- Processing Settings -->
                    <div class="acms-card" style="margin-bottom: 24px;">
                        <div class="acms-card__header">
                            <h3 class="acms-card__title">
                                <i class="bi bi-gear"></i>
                                <?php esc_html_e('Processing Settings', 'affiliatecms-cat'); ?>
                            </h3>
                        </div>
                        <div class="acms-card__body">
                            <table class="form-table">
                                <tr>
                                    <th scope="row">
                                        <label for="batch_size"><?php esc_html_e('Batch Size', 'affiliatecms-cat'); ?></label>
                                    </th>
                                    <td>
                                        <input
                                            type="number"
                                            name="acms_cat_batch_size"
                                            id="batch_size"
                                            value="<?php echo esc_attr($settings['batch_size']); ?>"
                                            min="1"
                                            max="100"
                                            class="small-text"
                                        >
                                        <p class="description"><?php esc_html_e('Number of keywords to process per batch', 'affiliatecms-cat'); ?></p>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">
                                        <label for="max_depth"><?php esc_html_e('Maximum Category Depth', 'affiliatecms-cat'); ?></label>
                                    </th>
                                    <td>
                                        <input
                                            type="number"
                                            name="acms_cat_max_depth"
                                            id="max_depth"
                                            value="<?php echo esc_attr($settings['max_depth']); ?>"
                                            min="1"
                                            max="10"
                                            class="small-text"
                                        >
                                        <p class="description"><?php esc_html_e('Maximum depth of category hierarchy to create', 'affiliatecms-cat'); ?></p>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">
                                        <label for="min_products"><?php esc_html_e('Minimum Products', 'affiliatecms-cat'); ?></label>
                                    </th>
                                    <td>
                                        <input
                                            type="number"
                                            name="acms_cat_min_products"
                                            id="min_products"
                                            value="<?php echo esc_attr($settings['min_products']); ?>"
                                            min="0"
                                            class="small-text"
                                        >
                                        <p class="description"><?php esc_html_e('Minimum products required to create a category', 'affiliatecms-cat'); ?></p>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>

                    <!-- Display Settings -->
                    <div class="acms-card" style="margin-bottom: 24px;">
                        <div class="acms-card__header">
                            <h3 class="acms-card__title">
                                <i class="bi bi-display"></i>
                                <?php esc_html_e('Display Settings', 'affiliatecms-cat'); ?>
                            </h3>
                        </div>
                        <div class="acms-card__body">
                            <table class="form-table">
                                <tr>
                                    <th scope="row">
                                        <label for="per_page"><?php esc_html_e('Categories Per Page', 'affiliatecms-cat'); ?></label>
                                    </th>
                                    <td>
                                        <input
                                            type="number"
                                            name="acms_cat_per_page"
                                            id="per_page"
                                            value="<?php echo esc_attr($settings['per_page']); ?>"
                                            min="10"
                                            max="100"
                                            class="small-text"
                                        >
                                        <p class="description"><?php esc_html_e('Number of categories to display per page in admin', 'affiliatecms-cat'); ?></p>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php esc_html_e('Show Empty Categories', 'affiliatecms-cat'); ?></th>
                                    <td>
                                        <label>
                                            <input
                                                type="checkbox"
                                                name="acms_cat_show_empty"
                                                value="1"
                                                <?php checked($settings['show_empty'], true); ?>
                                            >
                                            <?php esc_html_e('Show categories with no products', 'affiliatecms-cat'); ?>
                                        </label>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>

                    <!-- SEO Settings -->
                    <div class="acms-card" style="margin-bottom: 24px;">
                        <div class="acms-card__header">
                            <h3 class="acms-card__title">
                                <i class="bi bi-search"></i>
                                <?php esc_html_e('SEO Settings', 'affiliatecms-cat'); ?>
                            </h3>
                        </div>
                        <div class="acms-card__body">
                            <table class="form-table">
                                <tr>
                                    <th scope="row"><?php esc_html_e('Auto-generate Meta', 'affiliatecms-cat'); ?></th>
                                    <td>
                                        <label>
                                            <input
                                                type="checkbox"
                                                name="acms_cat_auto_meta"
                                                value="1"
                                                <?php checked($settings['auto_meta'], true); ?>
                                            >
                                            <?php esc_html_e('Automatically generate meta title and description for categories', 'affiliatecms-cat'); ?>
                                        </label>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">
                                        <label for="title_template"><?php esc_html_e('Title Template', 'affiliatecms-cat'); ?></label>
                                    </th>
                                    <td>
                                        <input
                                            type="text"
                                            name="acms_cat_title_template"
                                            id="title_template"
                                            value="<?php echo esc_attr($settings['title_template']); ?>"
                                            class="large-text"
                                        >
                                        <p class="description"><?php esc_html_e('Available placeholders: {category_name}, {product_count}, {site_name}', 'affiliatecms-cat'); ?></p>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>

                    <p class="submit">
                        <button type="submit" name="acms_cat_save_settings" class="acms-btn acms-btn--primary">
                            <i class="bi bi-check-lg"></i>
                            <?php esc_html_e('Save Settings', 'affiliatecms-cat'); ?>
                        </button>
                    </p>
                </div>
            </form>
        </div>
        <?php
    }

    /**
     * Get current settings
     */
    private function getSettings(): array
    {
        return [
            'batch_size' => (int) get_option('acms_cat_batch_size', 50),
            'max_depth' => (int) get_option('acms_cat_max_depth', 5),
            'min_products' => (int) get_option('acms_cat_min_products', 1),
            'per_page' => (int) get_option('acms_cat_per_page', 50),
            'show_empty' => (bool) get_option('acms_cat_show_empty', false),
            'auto_meta' => (bool) get_option('acms_cat_auto_meta', true),
            'title_template' => get_option('acms_cat_title_template', '{category_name} - {product_count} Products | {site_name}'),
        ];
    }

    /**
     * Save settings
     */
    private function saveSettings(): void
    {
        update_option('acms_cat_batch_size', (int) ($_POST['acms_cat_batch_size'] ?? 50));
        update_option('acms_cat_max_depth', (int) ($_POST['acms_cat_max_depth'] ?? 5));
        update_option('acms_cat_min_products', (int) ($_POST['acms_cat_min_products'] ?? 1));
        update_option('acms_cat_per_page', (int) ($_POST['acms_cat_per_page'] ?? 50));
        update_option('acms_cat_show_empty', isset($_POST['acms_cat_show_empty']));
        update_option('acms_cat_auto_meta', isset($_POST['acms_cat_auto_meta']));
        update_option('acms_cat_title_template', sanitize_text_field($_POST['acms_cat_title_template'] ?? ''));

        add_settings_error(
            'acms_cat_settings',
            'settings_saved',
            __('Settings saved successfully.', 'affiliatecms-cat'),
            'success'
        );
    }
}
