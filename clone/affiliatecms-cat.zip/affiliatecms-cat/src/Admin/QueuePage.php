<?php
/**
 * Category Queue Admin Page
 *
 * @package AffiliateCMS\Categories
 */

declare(strict_types=1);

namespace AffiliateCMS\Categories\Admin;

use AffiliateCMS\Categories\Repositories\QueueRepository;

class QueuePage
{
    private QueueRepository $repo;

    public function __construct()
    {
        $this->repo = new QueueRepository();
    }

    /**
     * Enqueue admin assets
     */
    public function enqueueAssets(): void
    {
        // Bootstrap Icons
        wp_enqueue_style(
            'bootstrap-icons',
            'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css',
            [],
            '1.11.3'
        );

        // Alpine.js
        wp_enqueue_script(
            'alpinejs',
            'https://cdn.jsdelivr.net/npm/alpinejs@3.14.3/dist/cdn.min.js',
            [],
            '3.14.3',
            true
        );

        // Add defer attribute to Alpine.js
        add_filter('script_loader_tag', function($tag, $handle) {
            if ($handle === 'alpinejs') {
                return str_replace(' src', ' defer src', $tag);
            }
            return $tag;
        }, 10, 2);
    }

    /**
     * Render the page
     */
    public function render(): void
    {
        $this->enqueueAssets();

        $stats = $this->repo->getStats();
        ?>
        <style>
            <?php $this->renderStyles(); ?>
        </style>

        <script>
        window.acmsCatConfig = {
            restUrl: '<?php echo esc_js(rest_url('acms-cat/v1/')); ?>',
            nonce: '<?php echo esc_js(wp_create_nonce('wp_rest')); ?>',
            siteUrl: '<?php echo esc_js(home_url()); ?>',
            editUrl: '<?php echo esc_js(admin_url('admin.php?page=acms-category-edit&id=')); ?>',
            categoriesUrl: '<?php echo esc_js(admin_url('admin.php?page=acms-categories')); ?>',
            stats: <?php echo wp_json_encode($stats); ?>
        };
        // For AS Progress Modal
        window.acmsConfig = {
            restUrl: '<?php echo esc_js(rest_url('acms/v1/')); ?>',
            nonce: '<?php echo esc_js(wp_create_nonce('wp_rest')); ?>'
        };
        </script>

        <div id="acms-cat-queue-app" class="acms-admin" x-data="catQueuePage()">
            <div class="app-container">
                <!-- Page Header with Stats -->
                <header class="page-header">
                    <div class="header-left">
                        <div class="stats-inline">
                            <div class="stat-item total" title="Total keywords">
                                <span class="stat-item-dot"></span>
                                <span class="stat-item-value" x-text="stats.total">0</span>
                                <span class="stat-item-label">Total</span>
                            </div>
                            <div class="stat-item pending" title="Pending keywords">
                                <span class="stat-item-dot"></span>
                                <span class="stat-item-value" x-text="stats.pending">0</span>
                                <span class="stat-item-label">Pending</span>
                            </div>
                            <div class="stat-item processing" title="Processing keywords">
                                <span class="stat-item-dot"></span>
                                <span class="stat-item-value" x-text="stats.processing">0</span>
                                <span class="stat-item-label">Processing</span>
                            </div>
                            <div class="stat-item completed" title="Completed keywords">
                                <span class="stat-item-dot"></span>
                                <span class="stat-item-value" x-text="stats.completed">0</span>
                                <span class="stat-item-label">Completed</span>
                            </div>
                            <div class="stat-item failed" title="Failed keywords">
                                <span class="stat-item-dot"></span>
                                <span class="stat-item-value" x-text="stats.failed">0</span>
                                <span class="stat-item-label">Failed</span>
                            </div>
                        </div>
                    </div>

                    <div class="header-actions">
                        <button class="btn-icon tooltip" title="Background Processes" @click="showAsProgressModal = true">
                            <i class="bi bi-lightning-charge"></i>
                        </button>
                        <a href="<?php echo esc_url(admin_url('admin.php?page=acms-categories')); ?>" class="btn-icon tooltip" title="Categories">
                            <i class="bi bi-diagram-3"></i>
                        </a>
                        <div class="header-divider"></div>
                        <button class="btn btn-primary" @click="showAddModal = true">
                            <i class="bi bi-plus-lg"></i>
                            Add Keywords
                        </button>
                    </div>
                </header>

                <!-- Toolbar -->
                <div class="toolbar">
                    <div class="toolbar-section toolbar-left">
                        <!-- Bulk Actions - 4 Workflow Phases -->
                        <div class="dropdown" x-data="{ open: false }">
                            <button class="btn btn-secondary" @click="open = !open" :disabled="selectedIds.length === 0">
                                <i class="bi bi-lightning-charge"></i>
                                Actions
                                <i class="bi bi-chevron-down" style="font-size:12px;margin-left:4px;"></i>
                            </button>
                            <div class="dropdown-menu" x-show="open" @click.outside="open = false" x-cloak style="min-width: 220px;">
                                <!-- Phase 1: Search -->
                                <button class="dropdown-item" @click="bulkProcess(); open = false" title="(Re)run search for products">
                                    <i class="bi bi-1-circle-fill text-muted"></i>
                                    <i class="bi bi-search"></i> Search Products
                                </button>

                                <!-- Phase 2: Assign Category -->
                                <button class="dropdown-item" @click="bulkAssignCategory(); open = false" title="(Re)assign category using majority voting from product paths">
                                    <i class="bi bi-2-circle-fill text-muted"></i>
                                    <i class="bi bi-folder-plus"></i> Assign Category
                                </button>

                                <!-- Phase 3: Link Products -->
                                <button class="dropdown-item" @click="bulkLinkProducts(); open = false" title="(Re)link products to assigned category">
                                    <i class="bi bi-3-circle-fill text-muted"></i>
                                    <i class="bi bi-link-45deg"></i> Link Products
                                </button>

                                <!-- Phase 4: Generate Content -->
                                <button class="dropdown-item" @click="bulkGenerateContent(); open = false" title="(Re)generate AI content for category">
                                    <i class="bi bi-4-circle-fill text-muted"></i>
                                    <i class="bi bi-file-earmark-text"></i> Generate Content
                                </button>

                                <div class="dropdown-divider"></div>
                                <!-- Update ASINs -->
                                <button class="dropdown-item" @click="bulkUpdateAsins(); open = false" title="Re-run search and update ASINs for selected items">
                                    <i class="bi bi-arrow-repeat"></i> Update ASINs
                                </button>
                                <!-- Sync Links -->
                                <button class="dropdown-item" @click="bulkSyncLinks(); open = false" title="Re-link scraped products to their assigned categories">
                                    <i class="bi bi-link-45deg"></i> Sync Links
                                </button>

                                <div class="dropdown-divider"></div>
                                <button class="dropdown-item danger" @click="bulkDelete(); open = false">
                                    <i class="bi bi-trash"></i> Delete
                                </button>
                            </div>
                        </div>
                        <span class="selected-count" x-show="selectedIds.length > 0" x-cloak>
                            <span class="selected-count-number" x-text="selectedIds.length"></span> selected
                        </span>
                    </div>

                    <div class="toolbar-section toolbar-center">
                        <div class="search-box">
                            <i class="bi bi-search search-icon"></i>
                            <input type="search" class="search-input" placeholder="Search keywords..."
                                   x-model="searchQuery" @input.debounce.300ms="_resetPageAndLoad()">
                            <button type="button" class="search-clear" x-show="searchQuery" x-cloak @click="searchQuery = ''; _resetPageAndLoad()">
                                <i class="bi bi-x-lg"></i>
                            </button>
                        </div>
                    </div>

                    <div class="toolbar-section toolbar-right">
                        <!-- Status Filter -->
                        <div class="dropdown" x-data="{ open: false }">
                            <button class="btn-icon" :class="{ 'active': statusFilter }" @click="open = !open" title="Filter by status">
                                <i class="bi" :class="statusFilter ? 'bi-funnel-fill' : 'bi-funnel'"></i>
                            </button>
                            <div class="dropdown-menu right" x-show="open" @click.outside="open = false" x-cloak>
                                <button class="dropdown-item" :class="{ 'selected': statusFilter === '' }" @click="statusFilter = ''; open = false; _resetPageAndLoad()">All Status</button>
                                <button class="dropdown-item" :class="{ 'selected': statusFilter === 'pending' }" @click="statusFilter = 'pending'; open = false; _resetPageAndLoad()">Pending</button>
                                <button class="dropdown-item" :class="{ 'selected': statusFilter === 'processing' }" @click="statusFilter = 'processing'; open = false; _resetPageAndLoad()">Processing</button>
                                <button class="dropdown-item" :class="{ 'selected': statusFilter === 'completed' }" @click="statusFilter = 'completed'; open = false; _resetPageAndLoad()">Completed</button>
                                <button class="dropdown-item" :class="{ 'selected': statusFilter === 'failed' }" @click="statusFilter = 'failed'; open = false; _resetPageAndLoad()">Failed</button>
                            </div>
                        </div>

                        <!-- Refresh -->
                        <button class="btn-icon" :class="{ 'refresh-success': refreshSuccess }" @click="loadData()" title="Refresh">
                            <i class="bi" :class="{ 'bi-arrow-clockwise': !refreshSuccess, 'animate-spin': isLoading, 'bi-check-lg': refreshSuccess }"></i>
                        </button>
                    </div>
                </div>

                <!-- Data Table -->
                <div class="data-table-wrapper">
                    <!-- Loading State -->
                    <div class="data-table-loading" x-show="isLoading" x-cloak>
                        <div class="spinner"></div>
                        <span>Loading keywords...</span>
                    </div>

                    <!-- Empty State -->
                    <div class="data-table-empty" x-show="!isLoading && items.length === 0" x-cloak>
                        <i class="bi bi-inbox"></i>
                        <span>No keywords found</span>
                        <small>Click "Add Keywords" to add category keywords to the queue</small>
                    </div>

                    <!-- Table -->
                    <div class="data-table-container" x-show="!isLoading && items.length > 0">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th class="col-checkbox">
                                        <input type="checkbox" @change="toggleSelectAll($event.target.checked)"
                                               :checked="selectedIds.length > 0 && selectedIds.length === items.length"
                                               :indeterminate="selectedIds.length > 0 && selectedIds.length < items.length">
                                    </th>
                                    <th class="col-keyword sortable" :class="{ 'sorted': sortColumn === 'keyword' }" @click="sortBy('keyword')">
                                        <span>Keyword</span>
                                        <i class="bi bi-chevron-expand sort-icon"></i>
                                    </th>
                                    <th class="col-status sortable" :class="{ 'sorted': sortColumn === 'status' }" @click="sortBy('status')">
                                        <span>Status</span>
                                        <i class="bi bi-chevron-expand sort-icon"></i>
                                    </th>
                                    <th class="col-scrape sortable" :class="{ 'sorted': sortColumn === 'scrape_progress' }" @click="sortBy('scrape_progress')" title="Scrape Progress">
                                        <span>Scrape</span>
                                        <i class="bi bi-chevron-expand sort-icon"></i>
                                    </th>
                                    <th class="col-ai sortable" :class="{ 'sorted': sortColumn === 'ai_status' }" @click="sortBy('ai_status')" title="AI Status">
                                        <span>AI</span>
                                        <i class="bi bi-chevron-expand sort-icon"></i>
                                    </th>
                                    <th class="col-products">Products</th>
                                    <th class="col-categories">Categories</th>
                                    <th class="col-date sortable" :class="{ 'sorted': sortColumn === 'created_at' }" @click="sortBy('created_at')">
                                        <span>Created</span>
                                        <i class="bi bi-chevron-expand sort-icon"></i>
                                    </th>
                                    <th class="col-actions">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <template x-for="item in items" :key="item.id">
                                    <tr :class="{ 'selected': selectedIds.includes(item.id) }">
                                        <td class="col-checkbox">
                                            <input type="checkbox" :value="item.id" :checked="selectedIds.includes(item.id)" @change="toggleSelect(item.id)">
                                        </td>
                                        <td class="col-keyword">
                                            <div class="keyword-cell">
                                                <div class="keyword-row">
                                                    <span class="keyword-text" x-text="item.keyword"></span>
                                                    <button class="btn-icon-inline" title="Copy keyword" @click.stop="copyKeyword(item.keyword)">
                                                        <i class="bi bi-copy"></i>
                                                    </button>
                                                </div>
                                                <a class="keyword-cat-link" x-show="item.category_slug" x-cloak
                                                   :href="acmsCatConfig.siteUrl + '/c/' + item.category_slug + '/'"
                                                   target="_blank" :title="'View: ' + (item.category_name || '')">
                                                    <i class="bi bi-box-arrow-up-right"></i>
                                                    <span x-text="item.category_name"></span>
                                                </a>
                                                <span class="error-text" x-show="item.error_message" x-cloak x-text="item.error_message"></span>
                                            </div>
                                        </td>
                                        <td class="col-status">
                                            <span class="badge" :class="'badge-' + getStatusColor(item.status)" x-text="item.status"></span>
                                        </td>
                                        <td class="col-scrape">
                                            <div class="scrape-progress-cell" :title="getScrapeProgressTitle(item)">
                                                <div class="progress-bar-mini" :class="getScrapeProgressClass(item)">
                                                    <div class="progress-fill" :style="'width: ' + (item.scrape_progress || 0) + '%'"></div>
                                                </div>
                                                <span class="progress-text" x-text="(item.scrape_progress || 0) + '%'"></span>
                                            </div>
                                        </td>
                                        <td class="col-ai">
                                            <span class="badge badge-ai"
                                                  :class="'badge-' + getAiStatusColor(item.ai_status)"
                                                  :title="getAiStatusTitle(item)"
                                                  x-text="getAiStatusLabel(item.ai_status)">
                                            </span>
                                        </td>
                                        <td class="col-products">
                                            <div class="products-cell" x-data="{ showAsins: false }">
                                                <span class="products-count"
                                                      :class="{ 'clickable': item.products_found > 0 }"
                                                      @click="item.products_found > 0 && (showAsins = !showAsins)"
                                                      x-text="item.products_found || 0"></span>
                                                <button class="btn-icon btn-icon-xs" title="Copy ASINs" @click="copyAsins(item)" x-show="item.products_found > 0">
                                                    <i class="bi bi-clipboard"></i>
                                                </button>
                                                <div class="asins-tooltip" x-show="showAsins && item.linked_asins" @click.outside="showAsins = false" x-cloak>
                                                    <div class="asins-tooltip-content" x-text="formatAsinsInline(item.linked_asins)"></div>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="col-categories">
                                            <div class="categories-cell" x-show="item.assigned_category_id && item.category_name">
                                                <a class="cat-name-link" :href="acmsCatConfig.categoriesUrl + '#parent-' + (item.category_parent_id || 0)" :title="'View in tree: ' + item.category_name">
                                                    <span x-text="item.category_name"></span>
                                                </a>
                                                <span class="cat-product-count" x-show="item.category_count > 0" x-text="item.category_count + 'p'"></span>
                                            </div>
                                            <span class="text-muted" x-show="!item.assigned_category_id" x-text="item.categories_created > 0 ? item.categories_created : '-'"></span>
                                        </td>
                                        <td class="col-date">
                                            <span class="date-value" x-text="formatDate(item.created_at)"></span>
                                        </td>
                                        <td class="col-actions">
                                            <div class="actions-cell">
                                                <!-- Process (search for products) -->
                                                <button class="btn-icon btn-icon-sm" title="Process (Search)" @click="processItem(item)" :disabled="item.status === 'processing' || processingIds.includes(item.id)" x-show="item.status !== 'processing' && item.status !== 'completed'">
                                                    <i class="bi" :class="processingIds.includes(item.id) ? 'bi-arrow-clockwise animate-spin' : 'bi-play-fill'"></i>
                                                </button>
                                                <button class="btn-icon btn-icon-sm" title="Force Reset" @click="forceResetItem(item)" x-show="item.status === 'processing'">
                                                    <i class="bi bi-arrow-counterclockwise"></i>
                                                </button>
                                                <!-- View Log -->
                                                <button class="btn-icon btn-icon-sm" title="View Log" @click="viewLog(item)" x-show="item.processing_log || item.status === 'completed' || item.status === 'failed' || item.status === 'processing'">
                                                    <i class="bi bi-file-text"></i>
                                                </button>
                                                <!-- Diagnose - show when there's a potential issue (assigned but category_count=0 or status stuck) -->
                                                <button class="btn-icon btn-icon-sm btn-warning" title="Diagnose Issues" @click="diagnoseItem(item)"
                                                        :disabled="diagnosing.includes(item.id)"
                                                        x-show="(item.assigned_category_id && item.category_count == 0) || (item.ai_status === 'category_assigned' && !item.category_count) || item.status === 'failed'">
                                                    <i class="bi" :class="diagnosing.includes(item.id) ? 'bi-arrow-clockwise animate-spin' : 'bi-bug'"></i>
                                                </button>
                                                <!-- Run Category AI (when AI Standardize is ON) -->
                                                <button class="btn-icon btn-icon-sm btn-ai" title="Run Category AI (Standardize)" @click="runCategoryAi(item)"
                                                        :disabled="categoryAiRunning.includes(item.id)"
                                                        x-show="item.scrape_progress >= 50 && !item.suggested_categories && item.products_found > 0 && !item.assigned_category_id">
                                                    <i class="bi" :class="categoryAiRunning.includes(item.id) ? 'bi-arrow-clockwise animate-spin' : 'bi-robot'"></i>
                                                </button>
                                                <!-- Auto-assign Category (Majority Voting) - show when scrape done and no category yet -->
                                                <button class="btn-icon btn-icon-sm btn-secondary" title="Assign Category (Majority Voting)" @click="assignCategoryMajority(item)"
                                                        :disabled="majorityRunning.includes(item.id)"
                                                        x-show="item.scrape_progress >= 50 && item.products_found > 0 && !item.assigned_category_id">
                                                    <i class="bi" :class="majorityRunning.includes(item.id) ? 'bi-arrow-clockwise animate-spin' : 'bi-diagram-3'"></i>
                                                </button>
                                                <!-- Re-assign Category (Force) - hidden, use bulk actions instead -->
                                                <!-- <button class="btn-icon btn-icon-sm btn-outline" title="Re-assign Category (Force)" @click="assignCategoryMajority(item, true)"
                                                        :disabled="majorityRunning.includes(item.id)"
                                                        x-show="item.assigned_category_id && item.products_found > 0">
                                                    <i class="bi" :class="majorityRunning.includes(item.id) ? 'bi-arrow-clockwise animate-spin' : 'bi-arrow-repeat'"></i>
                                                </button> -->
                                                <!-- Link Products - show when category assigned but no products linked -->
                                                <button class="btn-icon btn-icon-sm btn-info" title="Link Products to Category" @click="linkProducts(item)"
                                                        :disabled="linkingProducts.includes(item.id)"
                                                        x-show="item.assigned_category_id && item.category_count == 0 && item.products_found > 0">
                                                    <i class="bi" :class="linkingProducts.includes(item.id) ? 'bi-arrow-clockwise animate-spin' : 'bi-link-45deg'"></i>
                                                </button>
                                                <!-- Generate Content - show when category has products but no content -->
                                                <button class="btn-icon btn-icon-sm btn-success" title="Generate Category Content" @click="generateContent(item)"
                                                        :disabled="generatingContent.includes(item.id)"
                                                        x-show="item.assigned_category_id && item.category_count > 0 && item.category_content_status !== 'ai_generated'">
                                                    <i class="bi" :class="generatingContent.includes(item.id) ? 'bi-arrow-clockwise animate-spin' : 'bi-magic'"></i>
                                                </button>
                                                <button class="btn-icon btn-icon-sm" title="Edit" @click="editItem(item)" :disabled="item.status === 'processing'">
                                                    <i class="bi bi-pencil"></i>
                                                </button>
                                                <button class="btn-icon btn-icon-sm" title="Retry" @click="retryItem(item)" x-show="item.status === 'failed'">
                                                    <i class="bi bi-arrow-counterclockwise"></i>
                                                </button>
                                                <button class="btn-icon btn-icon-sm btn-danger" title="Delete" @click="deleteItem(item)" x-show="item.status !== 'processing'">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                                <button class="btn-icon btn-icon-sm btn-danger" title="Force Delete" @click="forceDeleteItem(item)" x-show="item.status === 'processing'">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                </template>
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination -->
                    <div class="data-table-pagination" x-show="!isLoading && items.length > 0">
                        <div class="pagination-info">
                            <span x-text="'Showing ' + ((currentPage - 1) * pageSize + 1) + ' - ' + Math.min(currentPage * pageSize, totalItems) + ' of ' + totalItems"></span>
                        </div>
                        <div class="pagination-controls">
                            <div class="pagination-buttons">
                                <button class="pagination-btn" :disabled="currentPage === 1" @click="currentPage = 1" title="First">
                                    <i class="bi bi-chevron-double-left"></i>
                                </button>
                                <button class="pagination-btn" :disabled="currentPage === 1" @click="currentPage--" title="Previous">
                                    <i class="bi bi-chevron-left"></i>
                                </button>
                                <template x-for="page in visiblePages" :key="page">
                                    <button class="pagination-btn" :class="{ 'active': page === currentPage }" @click="currentPage = page" x-text="page"></button>
                                </template>
                                <button class="pagination-btn" :disabled="currentPage === totalPages" @click="currentPage++" title="Next">
                                    <i class="bi bi-chevron-right"></i>
                                </button>
                                <button class="pagination-btn" :disabled="currentPage === totalPages" @click="currentPage = totalPages" title="Last">
                                    <i class="bi bi-chevron-double-right"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Add Keywords Modal -->
            <div class="modal-backdrop" x-show="showAddModal" x-cloak
                 x-transition:enter="transition ease-out duration-200"
                 x-transition:enter-start="opacity-0"
                 x-transition:enter-end="opacity-100"
                 x-transition:leave="transition ease-in duration-150"
                 x-transition:leave-start="opacity-100"
                 x-transition:leave-end="opacity-0"
                 @click.self="showAddModal = false"
                 @keydown.escape.window="showAddModal = false">

                <div class="modal modal-md"
                     x-transition:enter="transition ease-out duration-200"
                     x-transition:enter-start="opacity-0 transform scale-95"
                     x-transition:enter-end="opacity-100 transform scale-100"
                     @click.stop>

                    <div class="modal-header">
                        <h3 class="modal-title">
                            <i class="bi bi-plus-lg"></i>
                            Add Keywords
                        </h3>
                        <button type="button" class="modal-close" @click="showAddModal = false">
                            <i class="bi bi-x-lg"></i>
                        </button>
                    </div>

                    <div class="modal-body">
                        <div class="form-group">
                            <label class="form-label">
                                Keywords
                                <span class="form-hint">(one per line or comma-separated)</span>
                            </label>
                            <textarea class="form-textarea" rows="6"
                                      placeholder="Gaming Chairs&#10;Laptops, Monitors, Keyboards&#10;Headphones"
                                      x-model="addForm.keywords" @input="parseKeywords()"></textarea>
                            <div class="form-help">
                                <span x-show="addForm.keywordCount > 0" x-text="addForm.keywordCount + ' keyword(s) detected'"></span>
                            </div>
                        </div>

                        <div class="form-row" x-show="!addForm.customAsins">
                            <div class="form-group">
                                <label class="form-label">Pages <span class="form-hint">(1-5)</span></label>
                                <div class="stepper">
                                    <button type="button" class="stepper-btn" @click="updatePages(Math.max(1, addForm.searchPages - 1))">
                                        <i class="bi bi-dash"></i>
                                    </button>
                                    <input type="number" class="stepper-input" x-model.number="addForm.searchPages" min="1" max="5" @input="updatePagesFromInput()">
                                    <button type="button" class="stepper-btn" @click="updatePages(Math.min(5, addForm.searchPages + 1))">
                                        <i class="bi bi-plus"></i>
                                    </button>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="form-label">ASINs <span class="form-hint">(suggested: <span x-text="addForm.searchPages * 25"></span>)</span></label>
                                <div class="stepper">
                                    <button type="button" class="stepper-btn" @click="addForm.searchLimit = Math.max(1, addForm.searchLimit - 5)">
                                        <i class="bi bi-dash"></i>
                                    </button>
                                    <input type="number" class="stepper-input" x-model.number="addForm.searchLimit" min="1" max="100">
                                    <button type="button" class="stepper-btn" @click="addForm.searchLimit = Math.min(100, addForm.searchLimit + 5)">
                                        <i class="bi bi-plus"></i>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- Custom ASINs (optional - if provided, skip auto-search) -->
                        <div class="form-group">
                            <label class="form-label">
                                <i class="bi bi-box-seam" style="color: var(--info);"></i>
                                Custom ASINs
                                <span class="form-hint">(optional, comma-separated)</span>
                            </label>
                            <textarea class="form-textarea" rows="2"
                                      placeholder="B01ABC123, B02DEF456, B03GHI789..."
                                      x-model="addForm.customAsins" @input="parseCustomAsins()"></textarea>
                            <div class="form-help">
                                <i class="bi bi-info-circle"></i>
                                <span x-show="!addForm.customAsins">Leave empty to auto-search ASINs from Amazon</span>
                                <span x-show="addForm.customAsins" class="text-success">
                                    <span x-text="addForm.customAsinsCount"></span> ASIN(s) - will skip auto-search
                                </span>
                            </div>
                        </div>

                        <!-- Category Path (optional - pre-assign category) -->
                        <div class="form-group">
                            <label class="form-label">
                                <i class="bi bi-folder-plus" style="color: var(--primary);"></i>
                                Category Path
                                <span class="form-hint">(optional)</span>
                            </label>
                            <input type="text" class="form-input" x-model="addForm.categoryPath"
                                   placeholder="e.g., Electronics > Audio > Headphones">
                            <div class="form-help">
                                <i class="bi bi-info-circle"></i> Pre-assign a category path for all keywords
                            </div>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" @click="showAddModal = false">Cancel</button>
                        <div class="btn-group">
                            <button type="button" class="btn btn-primary" @click="submitKeywords(false)" :disabled="isSubmitting || addForm.keywordCount === 0">
                                <i class="bi" :class="isSubmitting && !processNow ? 'bi-arrow-clockwise animate-spin' : 'bi-plus-lg'"></i>
                                <span x-text="isSubmitting && !processNow ? 'Adding...' : 'Add to Queue'"></span>
                            </button>
                            <!-- Hidden: Process Now button
                            <button type="button" class="btn btn-success" @click="submitKeywords(true)" :disabled="isSubmitting || addForm.keywordCount === 0" title="Add and start processing immediately">
                                <i class="bi" :class="isSubmitting && processNow ? 'bi-arrow-clockwise animate-spin' : 'bi-play-fill'"></i>
                                <span x-text="isSubmitting && processNow ? 'Processing...' : 'Process Now'"></span>
                            </button>
                            -->
                        </div>
                    </div>
                </div>
            </div>

            <!-- Processing Log Modal -->
            <div class="modal-backdrop" x-show="showLogModal" x-cloak
                 x-transition:enter="transition ease-out duration-200"
                 x-transition:enter-start="opacity-0"
                 x-transition:enter-end="opacity-100"
                 x-transition:leave="transition ease-in duration-150"
                 x-transition:leave-start="opacity-100"
                 x-transition:leave-end="opacity-0"
                 @click.self="showLogModal = false"
                 @keydown.escape.window="showLogModal = false">

                <div class="modal modal-lg"
                     x-transition:enter="transition ease-out duration-200"
                     x-transition:enter-start="opacity-0 transform scale-95"
                     x-transition:enter-end="opacity-100 transform scale-100"
                     @click.stop>

                    <div class="modal-header">
                        <h3 class="modal-title">
                            <i class="bi bi-file-text"></i>
                            Processing Log
                        </h3>
                        <button type="button" class="modal-close" @click="showLogModal = false">
                            <i class="bi bi-x-lg"></i>
                        </button>
                    </div>

                    <div class="modal-body">
                        <!-- Item Info Header -->
                        <div class="log-item-info" x-show="currentLogItem">
                            <div class="log-item-keyword">
                                <i class="bi bi-tag"></i>
                                <span x-text="currentLogItem?.keyword || 'Unknown'"></span>
                            </div>
                            <div class="log-item-meta">
                                <span class="log-item-id">ID: <strong x-text="currentLogItem?.id"></strong></span>
                                <span class="log-item-status" :class="'status-' + currentLogItem?.status" x-text="currentLogItem?.status"></span>
                                <span class="log-item-ai-status" x-show="currentLogItem?.ai_status" x-text="'AI: ' + (currentLogItem?.ai_status || '')"></span>
                            </div>
                        </div>

                        <!-- Phase Progress Indicator -->
                        <div class="log-phases" x-show="currentLog && currentLog.log?.length > 0">
                            <div class="phase-item" :class="{'phase-done': hasPhaseCompleted('search'), 'phase-active': isPhaseActive('search')}">
                                <div class="phase-icon"><i class="bi bi-search"></i></div>
                                <div class="phase-label">Search</div>
                            </div>
                            <div class="phase-connector"></div>
                            <div class="phase-item" :class="{'phase-done': hasPhaseCompleted('products'), 'phase-active': isPhaseActive('products')}">
                                <div class="phase-icon"><i class="bi bi-box-seam"></i></div>
                                <div class="phase-label">Products</div>
                            </div>
                            <div class="phase-connector"></div>
                            <div class="phase-item" :class="{'phase-done': hasPhaseCompleted('scrape'), 'phase-active': isPhaseActive('scrape')}">
                                <div class="phase-icon"><i class="bi bi-cloud-download"></i></div>
                                <div class="phase-label">Scrape</div>
                            </div>
                            <div class="phase-connector"></div>
                            <div class="phase-item" :class="{'phase-done': hasPhaseCompleted('category'), 'phase-active': isPhaseActive('category')}">
                                <div class="phase-icon"><i class="bi bi-folder"></i></div>
                                <div class="phase-label">Category</div>
                            </div>
                            <div class="phase-connector"></div>
                            <div class="phase-item" :class="{'phase-done': hasPhaseCompleted('content'), 'phase-active': isPhaseActive('content')}">
                                <div class="phase-icon"><i class="bi bi-magic"></i></div>
                                <div class="phase-label">Content</div>
                            </div>
                        </div>

                        <!-- No Log -->
                        <div x-show="!currentLog || (!currentLog.log?.length && !currentLog.errors?.length)" class="empty-log">
                            <i class="bi bi-inbox"></i>
                            <span>No processing log available</span>
                        </div>

                        <!-- Grouped Log Entries by Phase -->
                        <div x-show="currentLog && currentLog.log?.length > 0" class="log-phases-detail">

                            <!-- Phase 1: Search -->
                            <template x-if="getPhaseEntries('search').length > 0">
                                <div class="log-phase-section">
                                    <div class="log-phase-header">
                                        <i class="bi bi-search"></i>
                                        <span>Phase 1: Search</span>
                                        <span class="phase-count" x-text="getPhaseEntries('search').length + ' entries'"></span>
                                    </div>
                                    <div class="log-phase-entries">
                                        <template x-for="(entry, index) in getPhaseEntries('search')" :key="'search-' + index">
                                            <div class="log-entry" :class="{'log-entry-error': entry.step === 'error'}">
                                                <div class="log-entry-header">
                                                    <span class="log-step-badge" x-text="formatStepName(entry.step)"></span>
                                                    <span class="log-timestamp" x-text="formatTimestamp(entry.timestamp)"></span>
                                                </div>
                                                <div class="log-message" x-text="entry.message"></div>
                                                <div x-show="entry.data && Object.keys(entry.data).length > 0" class="log-data">
                                                    <template x-for="(value, key) in entry.data" :key="key">
                                                        <span class="log-data-item">
                                                            <span class="log-data-key" x-text="key + ':'"></span>
                                                            <span class="log-data-value" x-text="typeof value === 'object' ? JSON.stringify(value) : value"></span>
                                                        </span>
                                                    </template>
                                                </div>
                                            </div>
                                        </template>
                                    </div>
                                </div>
                            </template>

                            <!-- Phase 2: Products -->
                            <template x-if="getPhaseEntries('products').length > 0">
                                <div class="log-phase-section">
                                    <div class="log-phase-header">
                                        <i class="bi bi-box-seam"></i>
                                        <span>Phase 2: Products</span>
                                        <span class="phase-count" x-text="getPhaseEntries('products').length + ' entries'"></span>
                                    </div>
                                    <div class="log-phase-entries">
                                        <template x-for="(entry, index) in getPhaseEntries('products')" :key="'products-' + index">
                                            <div class="log-entry">
                                                <div class="log-entry-header">
                                                    <span class="log-step-badge" x-text="formatStepName(entry.step)"></span>
                                                    <span class="log-timestamp" x-text="formatTimestamp(entry.timestamp)"></span>
                                                </div>
                                                <div class="log-message" x-text="entry.message"></div>
                                                <div x-show="entry.data && Object.keys(entry.data).length > 0" class="log-data">
                                                    <template x-for="(value, key) in entry.data" :key="key">
                                                        <span class="log-data-item">
                                                            <span class="log-data-key" x-text="key + ':'"></span>
                                                            <span class="log-data-value" x-text="typeof value === 'object' ? JSON.stringify(value) : value"></span>
                                                        </span>
                                                    </template>
                                                </div>
                                            </div>
                                        </template>
                                    </div>
                                </div>
                            </template>

                            <!-- Phase 3: Scrape -->
                            <template x-if="getPhaseEntries('scrape').length > 0">
                                <div class="log-phase-section">
                                    <div class="log-phase-header">
                                        <i class="bi bi-cloud-download"></i>
                                        <span>Phase 3: Scrape</span>
                                        <span class="phase-count" x-text="getPhaseEntries('scrape').length + ' entries'"></span>
                                    </div>
                                    <div class="log-phase-entries">
                                        <template x-for="(entry, index) in getPhaseEntries('scrape')" :key="'scrape-' + index">
                                            <div class="log-entry">
                                                <div class="log-entry-header">
                                                    <span class="log-step-badge" x-text="formatStepName(entry.step)"></span>
                                                    <span class="log-timestamp" x-text="formatTimestamp(entry.timestamp)"></span>
                                                </div>
                                                <div class="log-message" x-text="entry.message"></div>
                                                <div x-show="entry.data && Object.keys(entry.data).length > 0" class="log-data">
                                                    <template x-for="(value, key) in entry.data" :key="key">
                                                        <span class="log-data-item">
                                                            <span class="log-data-key" x-text="key + ':'"></span>
                                                            <span class="log-data-value" x-text="typeof value === 'object' ? JSON.stringify(value) : value"></span>
                                                        </span>
                                                    </template>
                                                </div>
                                            </div>
                                        </template>
                                    </div>
                                </div>
                            </template>

                            <!-- Phase 4: Category -->
                            <template x-if="getPhaseEntries('category').length > 0">
                                <div class="log-phase-section">
                                    <div class="log-phase-header">
                                        <i class="bi bi-folder"></i>
                                        <span>Phase 4: Category Assignment</span>
                                        <span class="phase-count" x-text="getPhaseEntries('category').length + ' entries'"></span>
                                    </div>
                                    <div class="log-phase-entries">
                                        <template x-for="(entry, index) in getPhaseEntries('category')" :key="'category-' + index">
                                            <div class="log-entry">
                                                <div class="log-entry-header">
                                                    <span class="log-step-badge" x-text="formatStepName(entry.step)"></span>
                                                    <span class="log-timestamp" x-text="formatTimestamp(entry.timestamp)"></span>
                                                </div>
                                                <div class="log-message" x-text="entry.message"></div>
                                                <div x-show="entry.data && Object.keys(entry.data).length > 0" class="log-data">
                                                    <template x-for="(value, key) in entry.data" :key="key">
                                                        <span class="log-data-item">
                                                            <span class="log-data-key" x-text="key + ':'"></span>
                                                            <span class="log-data-value" x-text="typeof value === 'object' ? JSON.stringify(value) : value"></span>
                                                        </span>
                                                    </template>
                                                </div>
                                            </div>
                                        </template>
                                    </div>
                                </div>
                            </template>

                            <!-- Phase 5: Content Generation -->
                            <template x-if="getPhaseEntries('content').length > 0">
                                <div class="log-phase-section">
                                    <div class="log-phase-header">
                                        <i class="bi bi-magic"></i>
                                        <span>Phase 5: Content Generation</span>
                                        <span class="phase-count" x-text="getPhaseEntries('content').length + ' entries'"></span>
                                    </div>
                                    <div class="log-phase-entries">
                                        <template x-for="(entry, index) in getPhaseEntries('content')" :key="'content-' + index">
                                            <div class="log-entry">
                                                <div class="log-entry-header">
                                                    <span class="log-step-badge" x-text="formatStepName(entry.step)"></span>
                                                    <span class="log-timestamp" x-text="formatTimestamp(entry.timestamp)"></span>
                                                </div>
                                                <div class="log-message" x-text="entry.message"></div>
                                                <div x-show="entry.data && Object.keys(entry.data).length > 0" class="log-data">
                                                    <template x-for="(value, key) in entry.data" :key="key">
                                                        <span class="log-data-item">
                                                            <span class="log-data-key" x-text="key + ':'"></span>
                                                            <span class="log-data-value" x-text="typeof value === 'object' ? JSON.stringify(value) : value"></span>
                                                        </span>
                                                    </template>
                                                </div>
                                            </div>
                                        </template>
                                    </div>
                                </div>
                            </template>
                        </div>

                        <!-- Errors -->
                        <div x-show="currentLog && currentLog.errors?.length > 0" class="log-container log-errors-container">
                            <h4 class="log-section-title error">
                                <i class="bi bi-exclamation-triangle-fill"></i>
                                Errors (<span x-text="currentLog?.errors?.length || 0"></span>)
                            </h4>
                            <template x-for="(error, index) in currentLog.errors" :key="index">
                                <div class="log-entry log-entry-error">
                                    <div class="log-entry-header">
                                        <span class="log-step-badge error" x-text="formatStepName(error.step)"></span>
                                        <span class="log-timestamp" x-text="formatTimestamp(error.timestamp)"></span>
                                    </div>
                                    <div class="log-message" x-text="error.message"></div>
                                </div>
                            </template>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" @click="copyLog()">
                            <i class="bi bi-clipboard"></i>
                            Copy Log
                        </button>
                        <button type="button" class="btn btn-secondary" @click="showLogModal = false">Close</button>
                    </div>
                </div>
            </div>

            <!-- Edit Keyword Modal -->
            <div class="modal-backdrop" x-show="showEditModal" x-cloak
                 x-transition:enter="transition ease-out duration-200"
                 x-transition:enter-start="opacity-0"
                 x-transition:enter-end="opacity-100"
                 x-transition:leave="transition ease-in duration-150"
                 x-transition:leave-start="opacity-100"
                 x-transition:leave-end="opacity-0"
                 @click.self="showEditModal = false"
                 @keydown.escape.window="showEditModal = false">

                <div class="modal modal-md"
                     x-transition:enter="transition ease-out duration-200"
                     x-transition:enter-start="opacity-0 transform scale-95"
                     x-transition:enter-end="opacity-100 transform scale-100"
                     @click.stop>

                    <div class="modal-header">
                        <h3 class="modal-title">
                            <i class="bi bi-pencil"></i>
                            Edit Keyword
                        </h3>
                        <button type="button" class="modal-close" @click="showEditModal = false">
                            <i class="bi bi-x-lg"></i>
                        </button>
                    </div>

                    <div class="modal-body">
                        <div class="form-group">
                            <label class="form-label">Keyword</label>
                            <input type="text" class="form-input" x-model="editForm.keyword" placeholder="Enter keyword">
                        </div>

                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">Pages <span class="form-hint">(1-5)</span></label>
                                <div class="stepper">
                                    <button type="button" class="stepper-btn" @click="updateEditPages(Math.max(1, editForm.searchPages - 1))">
                                        <i class="bi bi-dash"></i>
                                    </button>
                                    <input type="number" class="stepper-input" x-model.number="editForm.searchPages" min="1" max="5" @input="updateEditPagesFromInput()">
                                    <button type="button" class="stepper-btn" @click="updateEditPages(Math.min(5, editForm.searchPages + 1))">
                                        <i class="bi bi-plus"></i>
                                    </button>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="form-label">Limit <span class="form-hint">(suggested: <span x-text="editForm.searchPages * 25"></span>)</span></label>
                                <div class="stepper">
                                    <button type="button" class="stepper-btn" @click="editForm.searchLimit = Math.max(1, editForm.searchLimit - 5)">
                                        <i class="bi bi-dash"></i>
                                    </button>
                                    <input type="number" class="stepper-input" x-model.number="editForm.searchLimit" min="1" max="100">
                                    <button type="button" class="stepper-btn" @click="editForm.searchLimit = Math.min(100, editForm.searchLimit + 5)">
                                        <i class="bi bi-plus"></i>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="form-label">
                                ASINs
                                <span class="form-hint">(<span x-text="editForm.asins ? editForm.asins.split(',').filter(a => a.trim()).length : 0"></span> items, comma-separated)</span>
                            </label>
                            <textarea class="form-textarea" rows="3" x-model="editForm.asins" placeholder="B01ABC123, B02DEF456, ..."></textarea>
                            <div class="form-help" x-show="editForm.asins !== editForm.originalAsins && editForm.originalAsins">
                                <i class="bi bi-info-circle"></i> ASINs modified - will be saved on update
                            </div>
                            <div class="form-help form-help-success" x-show="editForm.asins && !editForm.originalAsins && editForm.searchStatus !== 'completed'">
                                <i class="bi bi-lightbulb"></i> Adding ASINs manually will mark this item as <strong>searched</strong>
                            </div>
                        </div>

                        <!-- Assigned Category Path (ONE path per keyword) -->
                        <div class="form-group">
                            <label class="form-label">
                                <i class="bi bi-folder-plus" style="color: var(--primary);"></i>
                                Assigned Category Path
                                <span class="form-hint">(this keyword will be assigned to ONE category)</span>
                            </label>
                            <input type="text" class="form-input" x-model="editForm.customCategoryPath"
                                placeholder="e.g., Home & Kitchen > Kitchen & Dining > Coffee Makers">
                            <div class="form-help">
                                <i class="bi bi-info-circle"></i> This path will create/find a category and assign this keyword to it
                            </div>
                        </div>

                        <!-- AI Suggested Paths (click to select) -->
                        <div class="form-group" x-show="editForm.suggestedCategories && editForm.suggestedCategories.paths && editForm.suggestedCategories.paths.length > 0">
                            <label class="form-label">
                                <i class="bi bi-robot text-purple"></i>
                                AI Suggested Paths
                                <span class="form-hint">(click to select)</span>
                            </label>
                            <div class="suggested-categories-box">
                                <div class="suggested-paths">
                                    <template x-for="(path, idx) in (editForm.suggestedCategories ? editForm.suggestedCategories.paths : [])" :key="idx">
                                        <div class="suggested-path-item"
                                             :class="{ 'selected': editForm.customCategoryPath === path }"
                                             @click="editForm.customCategoryPath = path">
                                            <i class="bi" :class="editForm.customCategoryPath === path ? 'bi-check-circle-fill' : 'bi-folder'"></i>
                                            <span x-text="path"></span>
                                        </div>
                                    </template>
                                </div>
                                <div class="ai-reasoning" x-show="editForm.suggestedCategories && editForm.suggestedCategories.reasoning">
                                    <i class="bi bi-lightbulb"></i>
                                    <span x-text="editForm.suggestedCategories ? editForm.suggestedCategories.reasoning : ''"></span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" @click="showEditModal = false">Cancel</button>
                        <button type="button" class="btn btn-primary" @click="updateKeyword()" :disabled="isSubmitting">
                            <i class="bi" :class="isSubmitting ? 'bi-arrow-clockwise animate-spin' : 'bi-check-lg'"></i>
                            <span x-text="isSubmitting ? 'Updating...' : 'Update'"></span>
                        </button>
                    </div>
                </div>
            </div>

            <!-- Delete Confirmation Modal -->
            <div class="modal-backdrop" x-show="showDeleteModal" x-cloak
                 x-transition:enter="transition ease-out duration-200"
                 x-transition:enter-start="opacity-0"
                 x-transition:enter-end="opacity-100"
                 x-transition:leave="transition ease-in duration-150"
                 x-transition:leave-start="opacity-100"
                 x-transition:leave-end="opacity-0"
                 @click.self="showDeleteModal = false"
                 @keydown.escape.window="showDeleteModal = false">

                <div class="modal modal-md"
                     x-transition:enter="transition ease-out duration-200"
                     x-transition:enter-start="opacity-0 transform scale-95"
                     x-transition:enter-end="opacity-100 transform scale-100"
                     @click.stop>

                    <div class="modal-header">
                        <h3 class="modal-title">
                            <i class="bi bi-trash text-error"></i>
                            Delete Keyword
                        </h3>
                        <button type="button" class="modal-close" @click="showDeleteModal = false">
                            <i class="bi bi-x-lg"></i>
                        </button>
                    </div>

                    <div class="modal-body">
                        <div class="delete-info">
                            <div class="delete-keyword">
                                <strong>Keyword:</strong>
                                <span x-text="deleteForm.keyword"></span>
                            </div>
                            <div class="delete-stats" x-show="deleteForm.productsFound > 0">
                                <strong>Products found:</strong>
                                <span x-text="deleteForm.productsFound"></span>
                            </div>
                            <div class="delete-stats" x-show="deleteForm.categoryName">
                                <strong>Category:</strong>
                                <span x-text="deleteForm.categoryName"></span>
                            </div>
                        </div>

                        <div class="delete-options">
                            <label class="delete-option" :class="{ 'selected': deleteForm.mode === 'keyword_only' }">
                                <input type="radio" name="delete_mode" value="keyword_only" x-model="deleteForm.mode">
                                <div class="delete-option-content">
                                    <div class="delete-option-title">
                                        <i class="bi bi-file-earmark-x"></i>
                                        Delete Keyword Only
                                    </div>
                                    <div class="delete-option-desc">Only remove this keyword from the queue. Products and categories will not be affected.</div>
                                </div>
                            </label>

                            <label class="delete-option" :class="{ 'selected': deleteForm.mode === 'with_orphan_asins' }" x-show="deleteForm.productsFound > 0">
                                <input type="radio" name="delete_mode" value="with_orphan_asins" x-model="deleteForm.mode">
                                <div class="delete-option-content">
                                    <div class="delete-option-title">
                                        <i class="bi bi-box-seam"></i>
                                        Delete Keyword + Orphan Products
                                    </div>
                                    <div class="delete-option-desc">Remove keyword and delete products NOT used in any posts. Also cleans up category-product links for deleted products.</div>
                                </div>
                            </label>

                            <label class="delete-option" :class="{ 'selected': deleteForm.mode === 'full' }" x-show="deleteForm.productsFound > 0 || deleteForm.categoryId > 0">
                                <input type="radio" name="delete_mode" value="full" x-model="deleteForm.mode">
                                <div class="delete-option-content">
                                    <div class="delete-option-title">
                                        <i class="bi bi-trash3"></i>
                                        Full Delete
                                    </div>
                                    <div class="delete-option-desc">Remove keyword, orphan products, category with all brand sub-categories, empty parent categories, orphan brand pages, and related AI jobs.</div>
                                </div>
                            </label>
                        </div>

                        <div class="delete-warning" x-show="deleteForm.mode !== 'keyword_only'">
                            <i class="bi bi-info-circle"></i>
                            <span>Products, categories, and brands in use by other keywords or posts will NOT be deleted. Empty parent categories will be removed up the tree.</span>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" @click="showDeleteModal = false">Cancel</button>
                        <button type="button" class="btn btn-danger" @click="confirmDelete()" :disabled="isDeleting">
                            <i class="bi" :class="isDeleting ? 'bi-arrow-clockwise animate-spin' : 'bi-trash'"></i>
                            <span x-text="isDeleting ? 'Deleting...' : 'Delete'"></span>
                        </button>
                    </div>
                </div>
            </div>

            <!-- Bulk Delete Modal -->
            <div class="modal-backdrop" x-show="showBulkDeleteModal" x-cloak
                 x-transition:enter="transition ease-out duration-200"
                 x-transition:enter-start="opacity-0"
                 x-transition:enter-end="opacity-100"
                 x-transition:leave="transition ease-in duration-150"
                 x-transition:leave-start="opacity-100"
                 x-transition:leave-end="opacity-0"
                 @click.self="!isBulkDeleting && (showBulkDeleteModal = false)"
                 @keydown.escape.window="!isBulkDeleting && (showBulkDeleteModal = false)">

                <div class="modal modal-md"
                     x-transition:enter="transition ease-out duration-200"
                     x-transition:enter-start="opacity-0 transform scale-95"
                     x-transition:enter-end="opacity-100 transform scale-100"
                     @click.stop>

                    <div class="modal-header">
                        <h3 class="modal-title">
                            <i class="bi bi-trash text-error"></i>
                            Bulk Delete
                        </h3>
                        <button type="button" class="modal-close" @click="showBulkDeleteModal = false" :disabled="isBulkDeleting">
                            <i class="bi bi-x-lg"></i>
                        </button>
                    </div>

                    <div class="modal-body">
                        <!-- Summary -->
                        <div class="delete-info">
                            <div class="delete-keyword">
                                <strong>Selected:</strong>
                                <span x-text="selectedIds.length + ' keyword(s)'"></span>
                            </div>
                        </div>

                        <!-- Delete mode options -->
                        <div class="delete-options" x-show="!isBulkDeleting">
                            <label class="delete-option" :class="{ 'selected': bulkDeleteMode === 'keyword_only' }">
                                <input type="radio" name="bulk_delete_mode" value="keyword_only" x-model="bulkDeleteMode">
                                <div class="delete-option-content">
                                    <div class="delete-option-title">
                                        <i class="bi bi-file-earmark-x"></i>
                                        Delete Keywords Only
                                    </div>
                                    <div class="delete-option-desc">Only remove keywords from the queue. Products and categories will not be affected.</div>
                                </div>
                            </label>

                            <label class="delete-option" :class="{ 'selected': bulkDeleteMode === 'with_orphan_asins' }">
                                <input type="radio" name="bulk_delete_mode" value="with_orphan_asins" x-model="bulkDeleteMode">
                                <div class="delete-option-content">
                                    <div class="delete-option-title">
                                        <i class="bi bi-box-seam"></i>
                                        Delete Keywords + Orphan Products
                                    </div>
                                    <div class="delete-option-desc">Remove keywords and delete associated products that are NOT used in any posts/pages.</div>
                                </div>
                            </label>

                            <label class="delete-option" :class="{ 'selected': bulkDeleteMode === 'full' }">
                                <input type="radio" name="bulk_delete_mode" value="full" x-model="bulkDeleteMode">
                                <div class="delete-option-content">
                                    <div class="delete-option-title">
                                        <i class="bi bi-trash3"></i>
                                        Full Delete
                                    </div>
                                    <div class="delete-option-desc">Remove keywords, orphan products, categories with brand sub-categories, empty parent categories, and orphan brand pages. Items in use elsewhere will be preserved.</div>
                                </div>
                            </label>
                        </div>

                        <div class="delete-warning" x-show="bulkDeleteMode !== 'keyword_only' && !isBulkDeleting">
                            <i class="bi bi-info-circle"></i>
                            <span>Products and categories that are in use will NOT be deleted.</span>
                        </div>

                        <!-- Progress (shown during deletion) -->
                        <div x-show="isBulkDeleting" style="margin-top: 16px;">
                            <div style="display:flex; justify-content:space-between; margin-bottom:8px; font-size:13px;">
                                <span>Deleting... <span x-text="bulkDeleteProgress.current"></span> / <span x-text="bulkDeleteProgress.total"></span></span>
                                <span>
                                    <span class="text-success" x-show="bulkDeleteProgress.deleted > 0" x-text="bulkDeleteProgress.deleted + ' deleted'"></span>
                                    <span class="text-error" x-show="bulkDeleteProgress.failed > 0" x-text="', ' + bulkDeleteProgress.failed + ' failed'"></span>
                                </span>
                            </div>
                            <div style="background:var(--border-color);border-radius:4px;height:6px;overflow:hidden;">
                                <div style="background:var(--error);height:100%;border-radius:4px;transition:width 0.3s;"
                                     :style="'width:' + (bulkDeleteProgress.total > 0 ? Math.round(bulkDeleteProgress.current / bulkDeleteProgress.total * 100) : 0) + '%'"></div>
                            </div>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" @click="showBulkDeleteModal = false" :disabled="isBulkDeleting">Cancel</button>
                        <button type="button" class="btn btn-danger" @click="confirmBulkDelete()" :disabled="isBulkDeleting">
                            <i class="bi" :class="isBulkDeleting ? 'bi-arrow-clockwise animate-spin' : 'bi-trash'"></i>
                            <span x-text="isBulkDeleting ? 'Deleting...' : 'Delete ' + selectedIds.length + ' item(s)'"></span>
                        </button>
                    </div>
                </div>
            </div>

            <!-- Update ASINs Modal -->
            <div class="modal-backdrop" x-show="showUpdateAsinsModal" x-cloak
                 x-transition:enter="transition ease-out duration-200"
                 x-transition:enter-start="opacity-0"
                 x-transition:enter-end="opacity-100"
                 x-transition:leave="transition ease-in duration-150"
                 x-transition:leave-start="opacity-100"
                 x-transition:leave-end="opacity-0"
                 @click.self="!isUpdatingAsins && (showUpdateAsinsModal = false)"
                 @keydown.escape.window="!isUpdatingAsins && (showUpdateAsinsModal = false)">

                <div class="modal modal-md"
                     x-transition:enter="transition ease-out duration-200"
                     x-transition:enter-start="opacity-0 transform scale-95"
                     x-transition:enter-end="opacity-100 transform scale-100"
                     @click.stop>

                    <div class="modal-header">
                        <h3 class="modal-title">
                            <i class="bi bi-arrow-repeat text-primary"></i>
                            Update ASINs
                        </h3>
                        <button type="button" class="modal-close" @click="showUpdateAsinsModal = false" :disabled="isUpdatingAsins">
                            <i class="bi bi-x-lg"></i>
                        </button>
                    </div>

                    <div class="modal-body">
                        <!-- Summary -->
                        <div class="delete-info">
                            <div class="delete-keyword">
                                <strong>Selected:</strong>
                                <span x-text="selectedIds.length + ' keyword(s)'"></span>
                            </div>
                        </div>

                        <!-- Mode options -->
                        <div class="delete-options" x-show="!isUpdatingAsins">
                            <label class="delete-option" :class="{ 'selected': updateAsinsMode === 'append' }">
                                <input type="radio" name="update_asins_mode" value="append" x-model="updateAsinsMode">
                                <div class="delete-option-content">
                                    <div class="delete-option-title">
                                        <i class="bi bi-plus-circle"></i>
                                        Add New ASINs Only
                                    </div>
                                    <div class="delete-option-desc">Re-run search and add any newly found products. Existing ASINs are kept.</div>
                                </div>
                            </label>

                            <label class="delete-option" :class="{ 'selected': updateAsinsMode === 'append_with_brands' }">
                                <input type="radio" name="update_asins_mode" value="append_with_brands" x-model="updateAsinsMode">
                                <div class="delete-option-content">
                                    <div class="delete-option-title">
                                        <i class="bi bi-diagram-2"></i>
                                        Add New ASINs + Create Brand Pages
                                    </div>
                                    <div class="delete-option-desc">Same as above, plus automatically create brand sub-categories for any new brands found.</div>
                                </div>
                            </label>

                            <label class="delete-option" :class="{ 'selected': updateAsinsMode === 'replace' }">
                                <input type="radio" name="update_asins_mode" value="replace" x-model="updateAsinsMode">
                                <div class="delete-option-content">
                                    <div class="delete-option-title">
                                        <i class="bi bi-arrow-clockwise"></i>
                                        Replace All
                                    </div>
                                    <div class="delete-option-desc">Remove all existing ASINs and category-product links, then run a fresh search and replace entirely with new results.</div>
                                </div>
                            </label>
                        </div>

                        <!-- Search options override -->
                        <div class="form-row" x-show="!isUpdatingAsins" style="margin-top: 12px;">
                            <div class="form-group">
                                <label class="form-label">Pages <span class="form-hint">(0 = default, 1-5)</span></label>
                                <div class="stepper">
                                    <button type="button" class="stepper-btn" @click="updateAsinsSearchPages = Math.max(0, updateAsinsSearchPages - 1)">
                                        <i class="bi bi-dash"></i>
                                    </button>
                                    <input type="number" class="stepper-input" x-model.number="updateAsinsSearchPages" min="0" max="5">
                                    <button type="button" class="stepper-btn" @click="updateAsinsSearchPages = Math.min(5, updateAsinsSearchPages + 1)">
                                        <i class="bi bi-plus"></i>
                                    </button>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="form-label">ASINs Limit <span class="form-hint">(0 = default)</span></label>
                                <div class="stepper">
                                    <button type="button" class="stepper-btn" @click="updateAsinsSearchLimit = Math.max(0, updateAsinsSearchLimit - 5)">
                                        <i class="bi bi-dash"></i>
                                    </button>
                                    <input type="number" class="stepper-input" x-model.number="updateAsinsSearchLimit" min="0" max="200">
                                    <button type="button" class="stepper-btn" @click="updateAsinsSearchLimit = Math.min(200, updateAsinsSearchLimit + 5)">
                                        <i class="bi bi-plus"></i>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div class="delete-warning" x-show="updateAsinsMode === 'replace' && !isUpdatingAsins">
                            <i class="bi bi-exclamation-triangle"></i>
                            <span>Replace mode will remove all existing product links from the assigned category before adding new ones.</span>
                        </div>

                        <!-- Progress (shown during update) -->
                        <div x-show="isUpdatingAsins" style="margin-top: 16px;">
                            <div style="display:flex; justify-content:space-between; margin-bottom:4px; font-size:13px;">
                                <span>
                                    <template x-if="updateAsinsProgress.current_keyword">
                                        <span>Processing: <strong x-text="updateAsinsProgress.current_keyword"></strong></span>
                                    </template>
                                    <template x-if="!updateAsinsProgress.current_keyword">
                                        <span>Starting background worker...</span>
                                    </template>
                                </span>
                                <span x-text="updateAsinsProgress.current + ' / ' + updateAsinsProgress.total"></span>
                            </div>
                            <div style="background:var(--border-color);border-radius:4px;height:6px;overflow:hidden;">
                                <div style="background:var(--primary);height:100%;border-radius:4px;transition:width 0.3s;"
                                     :style="'width:' + (updateAsinsProgress.total > 0 ? Math.round(updateAsinsProgress.current / updateAsinsProgress.total * 100) : 0) + '%'"></div>
                            </div>
                            <div style="display:flex; justify-content:space-between; margin-top:6px; font-size:12px; color:var(--text-muted);">
                                <span>
                                    <span class="text-success" x-show="updateAsinsProgress.success > 0" x-text="updateAsinsProgress.success + ' updated'"></span>
                                    <span class="text-error" x-show="updateAsinsProgress.failed > 0" x-text="' / ' + updateAsinsProgress.failed + ' failed'"></span>
                                </span>
                                <span x-text="updateAsinsProgress.total > 0 ? Math.round(updateAsinsProgress.current / updateAsinsProgress.total * 100) + '%' : ''"></span>
                            </div>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary"
                                @click="isUpdatingAsins ? cancelBulkUpdate() : (showUpdateAsinsModal = false)">
                            <span x-text="isUpdatingAsins ? 'Cancel' : 'Close'"></span>
                        </button>
                        <button type="button" class="btn btn-primary" @click="confirmUpdateAsins()" :disabled="isUpdatingAsins" x-show="!isUpdatingAsins">
                            <i class="bi bi-arrow-repeat"></i>
                            <span x-text="'Update ' + selectedIds.length + ' item(s)'"></span>
                        </button>
                    </div>
                </div>
            </div>

            <!-- Sync Links Modal -->
            <div class="modal-backdrop" x-show="showSyncLinksModal" x-cloak
                 x-transition:enter="transition ease-out duration-200"
                 x-transition:enter-start="opacity-0"
                 x-transition:enter-end="opacity-100"
                 x-transition:leave="transition ease-in duration-150"
                 x-transition:leave-start="opacity-100"
                 x-transition:leave-end="opacity-0"
                 @click.self="!isSyncingLinks && (showSyncLinksModal = false)"
                 @keydown.escape.window="!isSyncingLinks && (showSyncLinksModal = false)">

                <div class="modal modal-md"
                     x-transition:enter="transition ease-out duration-200"
                     x-transition:enter-start="opacity-0 transform scale-95"
                     x-transition:enter-end="opacity-100 transform scale-100"
                     @click.stop>

                    <div class="modal-header">
                        <h3 class="modal-title">
                            <i class="bi bi-link-45deg text-primary"></i>
                            Sync Links
                        </h3>
                        <button type="button" class="modal-close" @click="showSyncLinksModal = false" :disabled="isSyncingLinks">
                            <i class="bi bi-x-lg"></i>
                        </button>
                    </div>

                    <div class="modal-body">
                        <div class="delete-info">
                            <div class="delete-keyword">
                                <strong>Selected:</strong>
                                <span x-text="selectedIds.length + ' keyword(s)'"></span>
                            </div>
                        </div>

                        <p style="margin: 12px 0; font-size: 13px; color: var(--text-secondary);">
                            Re-link all scraped products to their assigned categories. This fixes products that were scraped after the initial category assignment (e.g. re-scraped failures).
                        </p>

                        <!-- Result (shown after sync) -->
                        <div x-show="syncLinksResult" style="margin-top: 12px;">
                            <div style="padding: 12px; background: var(--bg-tertiary); border-radius: 6px; font-size: 13px;">
                                <div><strong x-text="syncLinksResult?.items_checked + ' items checked'"></strong></div>
                                <div x-show="syncLinksResult?.products_linked > 0" class="text-success" style="margin-top: 4px;">
                                    <i class="bi bi-check-circle"></i> <span x-text="syncLinksResult?.products_linked + ' products linked across ' + syncLinksResult?.items_synced + ' items'"></span>
                                </div>
                                <div x-show="syncLinksResult?.products_linked === 0" class="text-muted" style="margin-top: 4px;">
                                    <i class="bi bi-info-circle"></i> All products already linked
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" @click="showSyncLinksModal = false" :disabled="isSyncingLinks">
                            <span x-text="syncLinksResult ? 'Close' : 'Cancel'"></span>
                        </button>
                        <button type="button" class="btn btn-primary" @click="confirmSyncLinks()" :disabled="isSyncingLinks || syncLinksResult" x-show="!syncLinksResult">
                            <i class="bi" :class="isSyncingLinks ? 'bi-arrow-clockwise animate-spin' : 'bi-link-45deg'"></i>
                            <span x-text="isSyncingLinks ? 'Syncing...' : 'Sync ' + selectedIds.length + ' item(s)'"></span>
                        </button>
                    </div>
                </div>
            </div>

            <!-- Toast -->
            <div class="toast-container" x-show="showToast" x-cloak
                 x-transition:enter="transition ease-out duration-300"
                 x-transition:enter-start="opacity-0 transform translate-y-4"
                 x-transition:enter-end="opacity-100 transform translate-y-0"
                 x-transition:leave="transition ease-in duration-200"
                 x-transition:leave-start="opacity-100"
                 x-transition:leave-end="opacity-0">
                <div class="toast" :class="'toast-' + toastType">
                    <div class="toast-icon">
                        <i class="bi" :class="{
                            'bi-check-circle-fill': toastType === 'success',
                            'bi-exclamation-triangle-fill': toastType === 'warning',
                            'bi-x-circle-fill': toastType === 'error',
                            'bi-info-circle-fill': toastType === 'info'
                        }"></i>
                    </div>
                    <div class="toast-content">
                        <div class="toast-title" x-text="toastTitle"></div>
                        <div class="toast-message" x-text="toastMessage"></div>
                    </div>
                    <button class="toast-close" @click="showToast = false">
                        <i class="bi bi-x"></i>
                    </button>
                </div>
            </div>

            <!-- AS Progress Modal -->
            <?php
            $asProgressModal = WP_PLUGIN_DIR . '/affiliatecms-pro/templates/admin/modals/as-progress-modal.php';
            if (file_exists($asProgressModal)) {
                include $asProgressModal;
            }
            ?>

        </div>

        <script>
        document.addEventListener('alpine:init', () => {
            Alpine.data('catQueuePage', () => ({
                // State
                items: [],
                stats: acmsCatConfig.stats || { total: 0, pending: 0, processing: 0, completed: 0, failed: 0 },
                isLoading: true,
                refreshSuccess: false,
                selectedIds: [],
                searchQuery: '',
                statusFilter: '',
                sortColumn: 'created_at',
                sortDirection: 'desc',
                currentPage: 1,
                pageSize: 50,

                // Processing tracking
                processingIds: [],
                categoryAiRunning: [],
                majorityRunning: [],
                diagnosing: [],
                linkingProducts: [],
                generatingContent: [],

                // Modal
                showAddModal: false,
                showLogModal: false,
                showEditModal: false,
                showAsProgressModal: false,
                isSubmitting: false,
                processNow: false,
                addForm: {
                    keywords: '',
                    keywordCount: 0,
                    searchPages: 1,
                    searchLimit: 25,
                    customAsins: '',
                    customAsinsCount: 0,
                    categoryPath: ''
                },
                editForm: {
                    id: null,
                    keyword: '',
                    searchPages: 1,
                    searchLimit: 20,
                    asins: '',
                    originalAsins: '',
                    searchStatus: '',
                    status: '',
                    suggestedCategories: null,
                    customCategoryPath: '',
                    assignedCategoryId: null
                },
                currentLog: { log: [], errors: [] },
                currentLogItem: null,

                // Delete Modal (single)
                showDeleteModal: false,
                isDeleting: false,
                deleteForm: {
                    id: null,
                    keyword: '',
                    productsFound: 0,
                    categoryName: '',
                    categoryId: 0,
                    mode: 'keyword_only'
                },

                // Bulk Delete Modal
                showBulkDeleteModal: false,
                isBulkDeleting: false,
                bulkDeleteProgress: { current: 0, total: 0, deleted: 0, failed: 0 },
                bulkDeleteMode: 'keyword_only',

                // Update ASINs Modal
                showUpdateAsinsModal: false,
                isUpdatingAsins: false,
                updateAsinsMode: 'append',
                updateAsinsSearchPages: 0, // 0 = use each key's default
                updateAsinsSearchLimit: 0, // 0 = use each key's default
                updateAsinsProgress: { current: 0, total: 0, success: 0, failed: 0, current_keyword: '' },
                bulkUpdateBatchId: null,
                bulkUpdatePolling: null,

                // Sync Links
                showSyncLinksModal: false,
                isSyncingLinks: false,
                syncLinksResult: null,

                // Toast
                showToast: false,
                toastType: 'success',
                toastTitle: '',
                toastMessage: '',

                // Server-side pagination state
                totalItems: 0,
                totalPages: 1,
                _skipPageWatch: false,

                init() {
                    this.loadData();
                    this.$watch('currentPage', () => {
                        if (!this._skipPageWatch) {
                            this.loadData();
                        }
                    });
                    this.$watch('updateAsinsSearchPages', (newVal, oldVal) => {
                        const oldSuggested = oldVal * 20;
                        if (this.updateAsinsSearchLimit === 0 || this.updateAsinsSearchLimit === oldSuggested) {
                            this.updateAsinsSearchLimit = newVal > 0 ? newVal * 20 : 0;
                        }
                    });
                },

                get visiblePages() {
                    const pages = [];
                    const total = this.totalPages;
                    const current = this.currentPage;
                    let start = Math.max(1, current - 2);
                    let end = Math.min(total, current + 2);
                    if (end - start < 4) {
                        if (start === 1) end = Math.min(total, start + 4);
                        else if (end === total) start = Math.max(1, end - 4);
                    }
                    for (let i = start; i <= end; i++) pages.push(i);
                    return pages;
                },

                async loadData() {
                    this.isLoading = true;
                    try {
                        const params = new URLSearchParams({
                            page: this.currentPage,
                            per_page: this.pageSize,
                            orderby: this.sortColumn,
                            order: this.sortDirection.toUpperCase(),
                        });
                        if (this.searchQuery) params.set('search', this.searchQuery);
                        if (this.statusFilter) params.set('status', this.statusFilter);

                        const response = await fetch(acmsCatConfig.restUrl + 'queue?' + params.toString(), {
                            headers: { 'X-WP-Nonce': acmsCatConfig.nonce }
                        });
                        const result = await response.json();
                        if (result.success) {
                            this.items = result.data.items || [];
                            this.totalItems = result.data.total || 0;
                            this.totalPages = result.data.total_pages || 1;
                            this.stats = result.data.stats || this.stats;
                        } else {
                            this.toast('error', 'Error', result.message || 'Failed to load queue items');
                        }
                    } catch (error) {
                        this.toast('error', 'Error', 'Failed to load queue items: ' + error.message);
                    } finally {
                        this.isLoading = false;
                        this.refreshSuccess = true;
                        setTimeout(() => { this.refreshSuccess = false; }, 2000);
                    }
                },

                _resetPageAndLoad() {
                    this._skipPageWatch = true;
                    this.currentPage = 1;
                    this.selectedIds = [];
                    this.$nextTick(() => {
                        this._skipPageWatch = false;
                        this.loadData();
                    });
                },

                sortBy(column) {
                    if (this.sortColumn === column) {
                        this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
                    } else {
                        this.sortColumn = column;
                        this.sortDirection = 'asc';
                    }
                    this._skipPageWatch = true;
                    this.currentPage = 1;
                    this.$nextTick(() => {
                        this._skipPageWatch = false;
                        this.loadData();
                    });
                },

                toggleSelect(id) {
                    const idx = this.selectedIds.indexOf(id);
                    if (idx === -1) this.selectedIds.push(id);
                    else this.selectedIds.splice(idx, 1);
                },

                toggleSelectAll(checked) {
                    if (checked) {
                        this.selectedIds = this.items.map(i => i.id);
                    } else {
                        this.selectedIds = [];
                    }
                },

                getStatusColor(status) {
                    const colors = { pending: 'primary', processing: 'info', completed: 'success', failed: 'error' };
                    return colors[status] || 'secondary';
                },

                // AI Status helper functions
                getAiStatusColor(aiStatus) {
                    const colors = {
                        'not_started': 'secondary',
                        'waiting_scrape': 'info',
                        'analyzing_category': 'warning',
                        'category_assigned': 'primary',
                        'generating_content': 'purple',
                        'completed': 'success',
                        'failed': 'error'
                    };
                    return colors[aiStatus] || 'secondary';
                },

                getAiStatusLabel(aiStatus) {
                    const labels = {
                        'not_started': 'Not Started',
                        'waiting_scrape': 'Waiting',
                        'analyzing_category': 'Analyzing',
                        'category_assigned': 'Assigned',
                        'generating_content': 'Generating',
                        'completed': 'Done',
                        'failed': 'Failed'
                    };
                    return labels[aiStatus] || aiStatus || '-';
                },

                getAiStatusTitle(item) {
                    const status = item.ai_status || 'not_started';
                    const titles = {
                        'not_started': 'AI processing not started',
                        'waiting_scrape': 'Waiting for product scraping to complete',
                        'analyzing_category': 'AI is analyzing and suggesting categories',
                        'category_assigned': 'Category assigned, waiting for content generation',
                        'generating_content': 'AI is generating category content',
                        'completed': 'AI processing completed',
                        'failed': 'AI processing failed'
                    };
                    let title = titles[status] || status;
                    if (item.ai_error) {
                        title += '\nError: ' + item.ai_error;
                    }
                    return title;
                },

                // Scrape progress helper functions
                getScrapeProgressClass(item) {
                    const progress = item.scrape_progress || 0;
                    if (progress >= 100) return 'progress-complete';
                    if (progress >= 80) return 'progress-high';
                    if (progress >= 50) return 'progress-medium';
                    return 'progress-low';
                },

                getScrapeProgressTitle(item) {
                    const progress = item.scrape_progress || 0;
                    const total = item.products_found || 0;
                    const scraped = Math.round((progress / 100) * total);
                    return `Scrape Progress: ${progress}% (${scraped}/${total} products scraped)`;
                },

                formatDate(dateStr) {
                    if (!dateStr) return '-';
                    const d = new Date(dateStr);
                    return d.toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' });
                },

                formatAsinsInline(linkedAsins) {
                    if (!linkedAsins) return '';
                    try {
                        const asins = JSON.parse(linkedAsins);
                        return asins.join(', ');
                    } catch (e) {
                        return linkedAsins;
                    }
                },

                parseKeywords() {
                    // Split by newlines first, then by commas
                    const keywords = this.addForm.keywords
                        .split('\n')
                        .flatMap(line => line.split(','))
                        .map(kw => kw.trim())
                        .filter(kw => kw !== '');
                    this.addForm.keywordCount = keywords.length;
                },

                parseCustomAsins() {
                    // Split by commas, newlines, or spaces
                    const asins = this.addForm.customAsins
                        .split(/[\s,\n]+/)
                        .map(a => a.trim().toUpperCase())
                        .filter(a => a !== '' && /^[A-Z0-9]{10}$/.test(a));
                    this.addForm.customAsinsCount = asins.length;
                },

                getCustomAsinsArray() {
                    return this.addForm.customAsins
                        .split(/[\s,\n]+/)
                        .map(a => a.trim().toUpperCase())
                        .filter(a => a !== '' && /^[A-Z0-9]{10}$/.test(a));
                },

                updatePages(pages) {
                    this.addForm.searchPages = Math.max(1, Math.min(5, pages));
                    // Auto-suggest ASINs based on pages (25 per page)
                    this.addForm.searchLimit = this.addForm.searchPages * 25;
                },

                updatePagesFromInput() {
                    // Validate and constrain pages
                    this.addForm.searchPages = Math.max(1, Math.min(5, this.addForm.searchPages || 1));
                    // Auto-update ASINs
                    this.addForm.searchLimit = this.addForm.searchPages * 25;
                },

                getParsedKeywords() {
                    // Split by newlines first, then by commas
                    return this.addForm.keywords
                        .split('\n')
                        .flatMap(line => line.split(','))
                        .map(kw => kw.trim())
                        .filter(kw => kw !== '');
                },

                async submitKeywords(processImmediately = false) {
                    if (this.addForm.keywordCount === 0) return;

                    this.isSubmitting = true;
                    this.processNow = processImmediately;

                    try {
                        const keywordsArray = this.getParsedKeywords();
                        const customAsins = this.getCustomAsinsArray();

                        // Build request body
                        const requestBody = {
                            keywords: keywordsArray,
                            search_limit: this.addForm.searchLimit,
                            search_pages: this.addForm.searchPages,
                            process_now: processImmediately
                        };

                        // Add custom ASINs if provided
                        if (customAsins.length > 0) {
                            requestBody.linked_asins = customAsins;
                        }

                        // Add category path if provided
                        if (this.addForm.categoryPath.trim()) {
                            requestBody.custom_category_path = this.addForm.categoryPath.trim();
                        }

                        const response = await fetch(acmsCatConfig.restUrl + 'queue', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-WP-Nonce': acmsCatConfig.nonce
                            },
                            body: JSON.stringify(requestBody)
                        });

                        const result = await response.json();
                        if (result.success) {
                            this.toast('success', 'Success', result.message || 'Keywords added to queue');
                            // Reset form
                            this.addForm.keywords = '';
                            this.addForm.keywordCount = 0;
                            this.addForm.customAsins = '';
                            this.addForm.customAsinsCount = 0;
                            this.addForm.categoryPath = '';
                            this.showAddModal = false;
                            this.loadData();
                        } else {
                            this.toast('error', 'Error', result.message || 'Failed to add keywords');
                        }
                    } catch (error) {
                        this.toast('error', 'Error', 'Failed to add keywords');
                    } finally {
                        this.isSubmitting = false;
                        this.processNow = false;
                    }
                },

                async processItem(item) {
                    // Add to processingIds immediately for UI feedback
                    this.processingIds.push(item.id);

                    try {
                        const response = await fetch(acmsCatConfig.restUrl + 'queue/' + item.id + '/process', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-WP-Nonce': acmsCatConfig.nonce
                            }
                        });
                        const result = await response.json();
                        if (result.success) {
                            this.toast('success', 'Success', result.message || 'Item processed');
                            this.loadData();
                        } else {
                            this.toast('error', 'Error', result.message || 'Failed to process item');
                        }
                    } catch (error) {
                        this.toast('error', 'Error', 'Failed to process item');
                    } finally {
                        // Remove from processingIds
                        this.processingIds = this.processingIds.filter(id => id !== item.id);
                    }
                },

                async runCategoryAi(item) {
                    // Add to running list for UI feedback
                    this.categoryAiRunning.push(item.id);

                    try {
                        // Call the AI plugin endpoint
                        const response = await fetch('<?php echo esc_js(rest_url('acms-ai/v1/category-ai/queue/')); ?>' + item.id, {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-WP-Nonce': acmsCatConfig.nonce
                            }
                        });
                        const result = await response.json();
                        if (result.success) {
                            this.toast('success', 'Category AI', result.message || 'AI job created successfully');
                            this.loadData();
                        } else {
                            this.toast('error', 'Category AI', result.message || 'Failed to create AI job');
                        }
                    } catch (error) {
                        this.toast('error', 'Category AI', 'Failed to trigger Category AI: ' + error.message);
                    } finally {
                        // Remove from running list
                        this.categoryAiRunning = this.categoryAiRunning.filter(id => id !== item.id);
                    }
                },

                /**
                 * Assign category using majority voting for a single item
                 * Used when "Standardize Category Paths" setting is OFF
                 * @param {Object} item - Queue item
                 * @param {boolean} force - Force re-run even if already assigned
                 */
                async assignCategoryMajority(item, force = false) {
                    // Add to running list for UI feedback
                    this.majorityRunning.push(item.id);

                    try {
                        const response = await fetch(acmsCatConfig.restUrl + 'queue/' + item.id + '/assign-category', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-WP-Nonce': acmsCatConfig.nonce
                            },
                            body: JSON.stringify({ force: force })
                        });
                        const result = await response.json();
                        if (result.success) {
                            this.toast('success', 'Category Assigned', result.message || 'Category assigned using majority voting');
                            this.loadData();
                        } else {
                            this.toast('error', 'Assignment Failed', result.message || 'Failed to assign category');
                        }
                    } catch (error) {
                        this.toast('error', 'Error', 'Failed to assign category: ' + error.message);
                    } finally {
                        // Remove from running list
                        this.majorityRunning = this.majorityRunning.filter(id => id !== item.id);
                    }
                },

                /**
                 * Diagnose issues with a queue item
                 */
                async diagnoseItem(item) {
                    this.diagnosing.push(item.id);

                    try {
                        const response = await fetch(acmsCatConfig.restUrl + 'queue/' + item.id + '/diagnose', {
                            headers: { 'X-WP-Nonce': acmsCatConfig.nonce }
                        });
                        const result = await response.json();

                        if (result.success) {
                            const d = result.data;
                            let message = `<strong>Status:</strong> ${d.status}<br>`;
                            message += `<strong>AI Status:</strong> ${d.ai_status || 'N/A'}<br>`;
                            message += `<strong>Linked ASINs:</strong> ${d.linked_asins_count}<br>`;
                            message += `<strong>Scraped Products:</strong> ${d.scraped_products || 0}/${d.total_products || 0}<br>`;
                            message += `<strong>Scrape Progress:</strong> ${d.scrape_progress}%<br>`;

                            if (d.category) {
                                message += `<br><strong>Category:</strong> ${d.category.name} (ID: ${d.category.id})<br>`;
                                message += `<strong>Products Linked:</strong> ${d.category.product_count}<br>`;
                                message += `<strong>Content Status:</strong> ${d.category.content_status}<br>`;
                            }

                            if (d.issues.length > 0) {
                                message += `<br><strong class="text-warning">Issues:</strong><br>`;
                                d.issues.forEach(issue => {
                                    message += `- ${issue}<br>`;
                                });
                            }

                            if (d.next_actions.length > 0) {
                                message += `<br><strong class="text-info">Suggested Actions:</strong><br>`;
                                d.next_actions.forEach(action => {
                                    message += `- ${action}<br>`;
                                });
                            }

                            // Show in a modal or alert
                            this.showDiagnoseModal(item.keyword, message);
                        } else {
                            this.toast('error', 'Diagnose Failed', result.message || 'Failed to diagnose');
                        }
                    } catch (error) {
                        this.toast('error', 'Error', 'Failed to diagnose: ' + error.message);
                    } finally {
                        this.diagnosing = this.diagnosing.filter(id => id !== item.id);
                    }
                },

                /**
                 * Show diagnose results in a simple alert (can be enhanced to modal later)
                 */
                showDiagnoseModal(keyword, message) {
                    // Create a simple modal/alert
                    const modal = document.createElement('div');
                    modal.className = 'diagnose-overlay';
                    modal.innerHTML = `
                        <div class="diagnose-modal">
                            <div class="diagnose-header">
                                <h3><i class="bi bi-bug"></i> Diagnose: ${keyword}</h3>
                                <button class="diagnose-close" onclick="this.closest('.diagnose-overlay').remove()">&times;</button>
                            </div>
                            <div class="diagnose-body">${message}</div>
                            <div class="diagnose-footer">
                                <button class="btn btn-secondary btn-sm" onclick="this.closest('.diagnose-overlay').remove()">Close</button>
                            </div>
                        </div>
                    `;
                    document.body.appendChild(modal);
                },

                /**
                 * Link products to the assigned category
                 */
                async linkProducts(item) {
                    this.linkingProducts.push(item.id);

                    try {
                        const response = await fetch(acmsCatConfig.restUrl + 'queue/' + item.id + '/link-products', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-WP-Nonce': acmsCatConfig.nonce
                            }
                        });
                        const result = await response.json();

                        if (result.success) {
                            this.toast('success', 'Products Linked', result.message || 'Products linked to category');
                            this.loadData();
                        } else {
                            this.toast('error', 'Link Failed', result.message || 'Failed to link products');
                        }
                    } catch (error) {
                        this.toast('error', 'Error', 'Failed to link products: ' + error.message);
                    } finally {
                        this.linkingProducts = this.linkingProducts.filter(id => id !== item.id);
                    }
                },

                /**
                 * Generate category content using AI
                 */
                async generateContent(item) {
                    this.generatingContent.push(item.id);

                    try {
                        const response = await fetch(acmsCatConfig.restUrl + 'queue/' + item.id + '/generate-content', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-WP-Nonce': acmsCatConfig.nonce
                            }
                        });
                        const result = await response.json();

                        if (result.success) {
                            this.toast('success', 'Content Generation', result.message || 'Content generation triggered');
                            this.loadData();
                        } else {
                            this.toast('error', 'Generation Failed', result.message || 'Failed to trigger content generation');
                        }
                    } catch (error) {
                        this.toast('error', 'Error', 'Failed to generate content: ' + error.message);
                    } finally {
                        this.generatingContent = this.generatingContent.filter(id => id !== item.id);
                    }
                },

                async copyKeyword(keyword) {
                    try {
                        await navigator.clipboard.writeText(keyword);
                        this.toast('success', 'Copied', 'Keyword copied to clipboard');
                    } catch (error) {
                        this.toast('error', 'Error', 'Failed to copy keyword');
                    }
                },

                async copyAsins(item) {
                    try {
                        // Get the full queue item with linked_asins
                        const response = await fetch(acmsCatConfig.restUrl + 'queue/' + item.id, {
                            headers: { 'X-WP-Nonce': acmsCatConfig.nonce }
                        });
                        const result = await response.json();

                        if (result && result.linked_asins) {
                            const asins = JSON.parse(result.linked_asins);
                            const asinText = asins.join(', ');

                            await navigator.clipboard.writeText(asinText);
                            this.toast('success', 'Copied', `${asins.length} ASINs copied to clipboard`);
                        } else {
                            this.toast('warning', 'No ASINs', 'No ASINs found for this item');
                        }
                    } catch (error) {
                        this.toast('error', 'Error', 'Failed to copy ASINs');
                    }
                },

                editItem(item) {
                    this.editForm.id = item.id;
                    this.editForm.keyword = item.keyword;
                    this.editForm.searchLimit = item.search_limit || 20;
                    this.editForm.searchPages = Math.max(1, Math.min(5, Math.ceil(this.editForm.searchLimit / 25)));
                    this.editForm.asins = '';
                    this.editForm.originalAsins = '';
                    this.editForm.searchStatus = item.search_status || 'not_searched';
                    this.editForm.status = item.status || 'pending';
                    this.editForm.suggestedCategories = null;
                    this.editForm.customCategoryPath = item.custom_category_path || '';
                    this.editForm.assignedCategoryId = item.assigned_category_id || null;

                    // Load ASINs if available from list data
                    if (item.linked_asins) {
                        try {
                            const asins = typeof item.linked_asins === 'string'
                                ? JSON.parse(item.linked_asins) : item.linked_asins;
                            this.editForm.asins = asins.join(', ');
                            this.editForm.originalAsins = this.editForm.asins;
                        } catch (e) {}
                    }

                    // Load suggested categories if available from list data
                    if (item.suggested_categories) {
                        try {
                            this.editForm.suggestedCategories = typeof item.suggested_categories === 'string'
                                ? JSON.parse(item.suggested_categories)
                                : item.suggested_categories;
                            if (!this.editForm.customCategoryPath && this.editForm.suggestedCategories?.paths?.length > 0) {
                                this.editForm.customCategoryPath = this.editForm.suggestedCategories.paths[0];
                            }
                        } catch (e) {}
                    }

                    // Show modal immediately with available data
                    this.showEditModal = true;

                    // Fetch extra data in background (non-blocking)
                    if (item.products_found > 0 && (!item.linked_asins || !item.suggested_categories)) {
                        fetch(acmsCatConfig.restUrl + 'queue/' + item.id, {
                            headers: { 'X-WP-Nonce': acmsCatConfig.nonce }
                        })
                        .then(r => r.json())
                        .then(result => {
                            if (!result || !this.showEditModal || this.editForm.id !== item.id) return;
                            if (result.linked_asins && !this.editForm.asins) {
                                try {
                                    const asins = JSON.parse(result.linked_asins);
                                    this.editForm.asins = asins.join(', ');
                                    this.editForm.originalAsins = this.editForm.asins;
                                } catch (e) {}
                            }
                            if (result.suggested_categories && !this.editForm.suggestedCategories) {
                                try {
                                    this.editForm.suggestedCategories = typeof result.suggested_categories === 'string'
                                        ? JSON.parse(result.suggested_categories)
                                        : result.suggested_categories;
                                    if (!this.editForm.customCategoryPath && this.editForm.suggestedCategories?.paths?.length > 0) {
                                        this.editForm.customCategoryPath = this.editForm.suggestedCategories.paths[0];
                                    }
                                } catch (e) {}
                            }
                            if (result.custom_category_path && !this.editForm.customCategoryPath) {
                                this.editForm.customCategoryPath = result.custom_category_path;
                            }
                        })
                        .catch(() => {});
                    }
                },

                updateEditPages(pages) {
                    this.editForm.searchPages = Math.max(1, Math.min(5, pages));
                    // Auto-suggest ASINs based on pages (25 per page)
                    this.editForm.searchLimit = this.editForm.searchPages * 25;
                },

                updateEditPagesFromInput() {
                    // Validate and constrain pages
                    this.editForm.searchPages = Math.max(1, Math.min(5, this.editForm.searchPages || 1));
                    // Auto-update ASINs
                    this.editForm.searchLimit = this.editForm.searchPages * 25;
                },

                async updateKeyword() {
                    if (!this.editForm.keyword.trim()) {
                        this.toast('error', 'Error', 'Keyword cannot be empty');
                        return;
                    }

                    this.isSubmitting = true;
                    try {
                        // Build update data
                        const updateData = {
                            keyword: this.editForm.keyword,
                            search_pages: this.editForm.searchPages,
                            search_limit: this.editForm.searchLimit
                        };

                        // Include ASINs if modified
                        if (this.editForm.asins !== this.editForm.originalAsins) {
                            const asinsArray = this.editForm.asins
                                .split(',')
                                .map(a => a.trim())
                                .filter(a => a !== '');
                            updateData.linked_asins = asinsArray;
                        }

                        // Include custom category paths
                        // Include custom category path (single path for this keyword)
                        if (this.editForm.customCategoryPath && this.editForm.customCategoryPath.trim()) {
                            updateData.custom_category_path = this.editForm.customCategoryPath.trim();
                        }

                        const response = await fetch(acmsCatConfig.restUrl + 'queue/' + this.editForm.id, {
                            method: 'PUT',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-WP-Nonce': acmsCatConfig.nonce
                            },
                            body: JSON.stringify(updateData)
                        });

                        const result = await response.json();
                        if (result.success) {
                            this.toast('success', 'Updated', result.message || 'Keyword updated successfully');
                            this.showEditModal = false;
                            this.loadData();
                        } else {
                            this.toast('error', 'Error', result.message || 'Failed to update keyword');
                        }
                    } catch (error) {
                        this.toast('error', 'Error', 'Failed to update keyword');
                    } finally {
                        this.isSubmitting = false;
                    }
                },

                viewLog(item) {
                    // Show modal immediately with loading state
                    this.currentLog = { log: [], errors: [] };
                    this.currentLogItem = item;
                    this.showLogModal = true;

                    // Try to parse inline processing_log first
                    if (item.processing_log) {
                        try {
                            const parsed = typeof item.processing_log === 'string'
                                ? JSON.parse(item.processing_log) : item.processing_log;
                            this.currentLog = parsed;
                        } catch (e) {}
                    }

                    // Fetch full log in background
                    fetch(acmsCatConfig.restUrl + 'queue/' + item.id + '/log', {
                        headers: { 'X-WP-Nonce': acmsCatConfig.nonce }
                    })
                    .then(r => r.json())
                    .then(result => {
                        if (result.success && this.showLogModal && this.currentLogItem?.id === item.id) {
                            this.currentLog = result.log;
                        }
                    })
                    .catch(() => {});
                },

                copyLog() {
                    if (!this.currentLog) return;

                    let text = '=== Processing Log ===\n';
                    if (this.currentLogItem) {
                        text += `Keyword: ${this.currentLogItem.keyword}\n`;
                        text += `Queue ID: ${this.currentLogItem.id}\n`;
                        text += `Status: ${this.currentLogItem.status}\n\n`;
                    }

                    // Add log entries
                    if (this.currentLog.log && this.currentLog.log.length > 0) {
                        text += '--- Processing Steps ---\n';
                        this.currentLog.log.forEach(entry => {
                            text += `[${entry.step}] ${entry.timestamp}\n`;
                            text += `  ${entry.message}\n`;
                            if (entry.data) {
                                text += `  Data: ${JSON.stringify(entry.data, null, 2)}\n`;
                            }
                            text += '\n';
                        });
                    }

                    // Add errors
                    if (this.currentLog.errors && this.currentLog.errors.length > 0) {
                        text += '\n--- Errors ---\n';
                        this.currentLog.errors.forEach(error => {
                            text += `[${error.step}] ${error.timestamp}\n`;
                            text += `  ERROR: ${error.message}\n\n`;
                        });
                    }

                    // Copy to clipboard
                    navigator.clipboard.writeText(text).then(() => {
                        this.toast('success', 'Copied', 'Log copied to clipboard');
                    }).catch(() => {
                        this.toast('error', 'Error', 'Failed to copy log');
                    });
                },

                /**
                 * Get log entries for a specific phase
                 * Phases: search, products, scrape, category, content
                 */
                getPhaseEntries(phase) {
                    if (!this.currentLog || !this.currentLog.log) return [];

                    const phaseSteps = {
                        search: ['search_started', 'search', 'search_completed', 'search_error', 'search_api', 'amazon_search'],
                        products: ['products_found', 'products_scraped', 'products_imported', 'add_products', 'product_add', 'link_asins', 'linked_asins'],
                        scrape: ['scrape_started', 'scrape_progress', 'scrape_completed', 'scraping', 'scrape_batch', 'scrape_product', 'scrape_queue'],
                        category: ['category_ai', 'category_assigned', 'category_created', 'standardize_categories', 'assign_category', 'suggested_categories', 'category_selection', 'link_products'],
                        content: ['content_generating', 'content_generated', 'content_ai', 'generate_content', 'ai_content', 'seo_content', 'post_generation']
                    };

                    const steps = phaseSteps[phase] || [];

                    return this.currentLog.log.filter(entry => {
                        const step = (entry.step || '').toLowerCase();
                        // Check if step contains any of the phase keywords
                        return steps.some(s => step.includes(s) || step.includes(phase));
                    });
                },

                /**
                 * Check if a phase has completed entries
                 * Also checks actual item status fields, not just log entries
                 */
                hasPhaseCompleted(phase) {
                    const item = this.currentLogItem;

                    // Check actual item status fields first (more reliable than log entries)
                    if (item) {
                        switch (phase) {
                            case 'search':
                                // Search is complete if we have search_status = 'completed' or products_found > 0
                                if (item.search_status === 'completed' || (item.products_found && item.products_found > 0)) {
                                    return true;
                                }
                                break;
                            case 'products':
                                // Products phase complete if linked_asins exist
                                if (item.linked_asins && JSON.parse(item.linked_asins || '[]').length > 0) {
                                    return true;
                                }
                                break;
                            case 'scrape':
                                // Scrape complete if scrape_progress >= 50% (threshold)
                                if (item.scrape_progress && parseInt(item.scrape_progress) >= 50) {
                                    return true;
                                }
                                break;
                            case 'category':
                                // Category complete if assigned_category_id exists or ai_status indicates assignment
                                if (item.assigned_category_id ||
                                    ['category_assigned', 'generating_content', 'completed'].includes(item.ai_status)) {
                                    return true;
                                }
                                break;
                            case 'content':
                                // Content complete if ai_status is 'completed' or category has AI content
                                if (item.ai_status === 'completed' ||
                                    item.category_content_status === 'ai_generated') {
                                    return true;
                                }
                                break;
                        }
                    }

                    // Fallback: check log entries
                    const entries = this.getPhaseEntries(phase);
                    if (entries.length === 0) return false;

                    // Check if any entry indicates completion
                    const completionIndicators = ['completed', 'done', 'finished', 'success', 'assigned', 'created', 'generated'];
                    return entries.some(entry => {
                        const step = (entry.step || '').toLowerCase();
                        const message = (entry.message || '').toLowerCase();
                        return completionIndicators.some(ind => step.includes(ind) || message.includes(ind));
                    });
                },

                /**
                 * Check if a phase is currently active (has entries but not completed)
                 */
                isPhaseActive(phase) {
                    const entries = this.getPhaseEntries(phase);
                    if (entries.length === 0) return false;

                    // Check if this is the latest phase with entries
                    const phases = ['search', 'products', 'scrape', 'category', 'content'];
                    const currentIndex = phases.indexOf(phase);

                    // It's active if it has entries but later phases don't
                    for (let i = currentIndex + 1; i < phases.length; i++) {
                        if (this.getPhaseEntries(phases[i]).length > 0) {
                            return false; // Later phase has entries, so this one is done
                        }
                    }

                    // Check if not fully completed
                    return !this.hasPhaseCompleted(phase);
                },

                /**
                 * Format step name for display
                 */
                formatStepName(step) {
                    if (!step) return '';
                    return step
                        .replace(/_/g, ' ')
                        .replace(/([a-z])([A-Z])/g, '$1 $2')
                        .split(' ')
                        .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
                        .join(' ');
                },

                /**
                 * Format timestamp for display
                 */
                formatTimestamp(timestamp) {
                    if (!timestamp) return '';
                    // If timestamp is ISO format or unix timestamp
                    try {
                        const date = new Date(timestamp);
                        if (isNaN(date.getTime())) return timestamp;
                        return date.toLocaleString('en-US', {
                            month: 'short',
                            day: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit',
                            second: '2-digit'
                        });
                    } catch (e) {
                        return timestamp;
                    }
                },

                async retryItem(item) {
                    try {
                        const response = await fetch(acmsCatConfig.restUrl + 'queue/' + item.id + '/retry', {
                            method: 'POST',
                            headers: { 'X-WP-Nonce': acmsCatConfig.nonce }
                        });
                        const result = await response.json();
                        if (result.success) {
                            this.toast('success', 'Success', 'Item queued for retry');
                            this.loadData();
                        } else {
                            this.toast('error', 'Error', result.message || 'Failed to retry item');
                        }
                    } catch (error) {
                        this.toast('error', 'Error', 'Failed to retry item');
                    }
                },

                deleteItem(item) {
                    this.deleteForm.id = item.id;
                    this.deleteForm.keyword = item.keyword;
                    this.deleteForm.productsFound = item.products_found || 0;
                    this.deleteForm.categoryName = item.category_name || '';
                    this.deleteForm.categoryId = item.assigned_category_id || 0;
                    this.deleteForm.mode = 'keyword_only';
                    this.showDeleteModal = true;
                },

                async confirmDelete() {
                    if (!this.deleteForm.id) return;

                    this.isDeleting = true;
                    try {
                        const response = await fetch(acmsCatConfig.restUrl + 'queue/' + this.deleteForm.id + '/delete-advanced', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-WP-Nonce': acmsCatConfig.nonce
                            },
                            body: JSON.stringify({ mode: this.deleteForm.mode })
                        });
                        const result = await response.json();

                        if (result.success) {
                            this.showDeleteModal = false;
                            this.toast('success', 'Deleted', result.message || 'Keyword deleted');
                            this.loadData();
                        } else {
                            this.toast('error', 'Error', result.message || 'Failed to delete');
                        }
                    } catch (error) {
                        this.toast('error', 'Error', 'Failed to delete');
                    } finally {
                        this.isDeleting = false;
                    }
                },

                async bulkProcess() {
                    if (this.selectedIds.length === 0) return;
                    try {
                        const response = await fetch(acmsCatConfig.restUrl + 'queue/process-batch', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-WP-Nonce': acmsCatConfig.nonce
                            },
                            body: JSON.stringify({ limit: this.selectedIds.length })
                        });
                        const result = await response.json();
                        if (result.success) {
                            this.toast('success', 'Success', result.message || 'Items processed');
                            this.selectedIds = [];
                            this.loadData();
                        } else {
                            this.toast('error', 'Error', result.message || 'Failed to process items');
                        }
                    } catch (error) {
                        this.toast('error', 'Error', 'Failed to process items');
                    }
                },

                async bulkRetry() {
                    if (this.selectedIds.length === 0) return;
                    for (const id of this.selectedIds) {
                        await fetch(acmsCatConfig.restUrl + 'queue/' + id + '/retry', {
                            method: 'POST',
                            headers: { 'X-WP-Nonce': acmsCatConfig.nonce }
                        });
                    }
                    this.toast('success', 'Success', 'Items queued for retry');
                    this.selectedIds = [];
                    this.loadData();
                },

                bulkDelete() {
                    if (this.selectedIds.length === 0) return;
                    this.bulkDeleteMode = 'keyword_only';
                    this.bulkDeleteProgress = { current: 0, total: 0, deleted: 0, failed: 0 };
                    this.showBulkDeleteModal = true;
                },

                async confirmBulkDelete() {
                    if (this.selectedIds.length === 0) return;

                    this.isBulkDeleting = true;
                    const ids = [...this.selectedIds];
                    this.bulkDeleteProgress = { current: 0, total: ids.length, deleted: 0, failed: 0 };

                    for (const id of ids) {
                        this.bulkDeleteProgress.current++;
                        try {
                            const response = await fetch(acmsCatConfig.restUrl + 'queue/' + id + '/delete-advanced', {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json',
                                    'X-WP-Nonce': acmsCatConfig.nonce
                                },
                                body: JSON.stringify({ mode: this.bulkDeleteMode })
                            });
                            const result = await response.json();
                            if (result.success) {
                                this.bulkDeleteProgress.deleted++;
                            } else {
                                this.bulkDeleteProgress.failed++;
                            }
                        } catch (error) {
                            this.bulkDeleteProgress.failed++;
                        }
                    }

                    this.isBulkDeleting = false;
                    this.showBulkDeleteModal = false;

                    const msg = [];
                    if (this.bulkDeleteProgress.deleted > 0) msg.push(this.bulkDeleteProgress.deleted + ' deleted');
                    if (this.bulkDeleteProgress.failed > 0) msg.push(this.bulkDeleteProgress.failed + ' failed');

                    this.toast(
                        this.bulkDeleteProgress.failed > 0 ? 'warning' : 'success',
                        'Bulk Delete',
                        msg.join(', ')
                    );
                    this.selectedIds = [];
                    this.loadData();
                },

                /**
                 * Open Update ASINs modal
                 */
                bulkUpdateAsins() {
                    if (this.selectedIds.length === 0) return;
                    this.updateAsinsMode = 'append';
                    this.updateAsinsSearchPages = 0;
                    this.updateAsinsSearchLimit = 0;
                    this.updateAsinsProgress = { current: 0, total: 0, success: 0, failed: 0, current_keyword: '' };
                    this.bulkUpdateBatchId = null;
                    this.showUpdateAsinsModal = true;
                },

                /**
                 * Start background bulk update for selected items
                 */
                async confirmUpdateAsins() {
                    if (this.selectedIds.length === 0) return;

                    this.isUpdatingAsins = true;
                    const ids = [...this.selectedIds];
                    this.updateAsinsProgress = { current: 0, total: ids.length, success: 0, failed: 0, current_keyword: '' };

                    try {
                        const response = await fetch(acmsCatConfig.restUrl + 'queue/bulk-update-asins', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-WP-Nonce': acmsCatConfig.nonce
                            },
                            body: JSON.stringify({
                                ids: ids,
                                mode: this.updateAsinsMode,
                                search_pages: this.updateAsinsSearchPages || 0,
                                search_limit: this.updateAsinsSearchLimit || 0
                            })
                        });
                        const result = await response.json();

                        if (!result.success) {
                            this.isUpdatingAsins = false;
                            this.toast('error', 'Update ASINs', result.message || 'Failed to start bulk update');
                            return;
                        }

                        this.bulkUpdateBatchId = result.batch_id;
                        this.updateAsinsProgress.total = result.total;

                        // Start polling for progress
                        this.bulkUpdatePolling = setInterval(() => this.pollBulkUpdateStatus(), 2500);

                    } catch (error) {
                        this.isUpdatingAsins = false;
                        this.toast('error', 'Update ASINs', 'Failed to start: ' + error.message);
                    }
                },

                /**
                 * Poll background batch status
                 */
                async pollBulkUpdateStatus() {
                    if (!this.bulkUpdateBatchId) return;

                    try {
                        const response = await fetch(
                            acmsCatConfig.restUrl + 'queue/bulk-update-status?batch_id=' + encodeURIComponent(this.bulkUpdateBatchId),
                            { headers: { 'X-WP-Nonce': acmsCatConfig.nonce } }
                        );
                        const result = await response.json();

                        if (!result.success || !result.data) {
                            this.finishBulkUpdate('Batch status unavailable');
                            return;
                        }

                        const data = result.data;
                        this.updateAsinsProgress = {
                            current: data.current,
                            total: data.total,
                            success: data.success,
                            failed: data.failed,
                            current_keyword: data.current_keyword || ''
                        };

                        if (data.status === 'completed' || data.status === 'cancelled') {
                            this.finishBulkUpdate(data.status === 'cancelled' ? 'Batch cancelled' : null);
                        }
                    } catch (error) {
                        console.warn('Poll error:', error);
                    }
                },

                /**
                 * Finish bulk update — stop polling, show toast, reload data
                 */
                finishBulkUpdate(overrideMessage) {
                    if (this.bulkUpdatePolling) {
                        clearInterval(this.bulkUpdatePolling);
                        this.bulkUpdatePolling = null;
                    }

                    this.isUpdatingAsins = false;
                    this.showUpdateAsinsModal = false;

                    const p = this.updateAsinsProgress;
                    const msg = overrideMessage || [
                        p.success > 0 ? p.success + ' updated' : '',
                        p.failed > 0 ? p.failed + ' failed' : ''
                    ].filter(Boolean).join(', ');

                    this.toast(
                        p.failed > 0 ? 'warning' : 'success',
                        'Update ASINs',
                        msg || 'Completed'
                    );

                    this.bulkUpdateBatchId = null;
                    this.selectedIds = [];
                    this.loadData();
                },

                /**
                 * Cancel running background batch
                 */
                async cancelBulkUpdate() {
                    if (!this.bulkUpdateBatchId) return;

                    try {
                        await fetch(acmsCatConfig.restUrl + 'queue/bulk-update-cancel', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-WP-Nonce': acmsCatConfig.nonce
                            },
                            body: JSON.stringify({ batch_id: this.bulkUpdateBatchId })
                        });
                        // Next poll will detect status=cancelled and call finishBulkUpdate
                    } catch (error) {
                        this.toast('error', 'Cancel', 'Failed to cancel: ' + error.message);
                    }
                },

                /**
                 * Open Sync Links modal
                 */
                bulkSyncLinks() {
                    if (this.selectedIds.length === 0) return;
                    this.syncLinksResult = null;
                    this.showSyncLinksModal = true;
                },

                /**
                 * Execute Sync Links for selected items (single API call)
                 */
                async confirmSyncLinks() {
                    if (this.selectedIds.length === 0) return;

                    this.isSyncingLinks = true;
                    try {
                        const response = await fetch(acmsCatConfig.restUrl + 'queue/bulk-sync-links', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-WP-Nonce': acmsCatConfig.nonce
                            },
                            body: JSON.stringify({ ids: this.selectedIds })
                        });
                        const result = await response.json();
                        if (result.success) {
                            this.syncLinksResult = result.data;
                            this.toast('success', 'Sync Links', result.message);
                        } else {
                            this.toast('error', 'Sync Links', result.message || 'Failed to sync links');
                        }
                    } catch (error) {
                        this.toast('error', 'Sync Links', 'Request failed');
                    }
                    this.isSyncingLinks = false;
                    this.selectedIds = [];
                    this.loadData();
                },

                /**
                 * Phase 2: Assign Category (simplified - always force re-run)
                 * Uses majority voting from product category paths
                 */
                async bulkAssignCategory() {
                    if (this.selectedIds.length === 0) return;

                    const count = this.selectedIds.length;
                    this.toast('info', 'Processing', `Assigning categories for ${count} item(s)...`);

                    let successCount = 0;
                    let failCount = 0;
                    let lastError = '';

                    for (const id of this.selectedIds) {
                        try {
                            const response = await fetch(acmsCatConfig.restUrl + 'queue/' + id + '/assign-category', {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json',
                                    'X-WP-Nonce': acmsCatConfig.nonce
                                },
                                body: JSON.stringify({ force: true })  // Always force re-run
                            });
                            const result = await response.json();

                            if (result.success) {
                                successCount++;
                            } else {
                                failCount++;
                                lastError = result.message || 'Unknown error';
                            }
                        } catch (error) {
                            failCount++;
                            lastError = error.message || 'Network error';
                        }
                    }

                    if (failCount === 0) {
                        this.toast('success', 'Done', `Category assigned for ${successCount} item(s)`);
                    } else if (successCount > 0) {
                        this.toast('warning', 'Partial', `${successCount} OK, ${failCount} failed: ${lastError}`);
                    } else {
                        this.toast('error', 'Error', lastError || 'Failed to assign categories');
                    }

                    this.selectedIds = [];
                    this.loadData();
                },

                /**
                 * Phase 4: Generate Content (simplified - always force re-run)
                 */
                async bulkGenerateContent() {
                    if (this.selectedIds.length === 0) return;

                    // Get items that have assigned_category_id
                    const eligibleItems = this.items.filter(item =>
                        this.selectedIds.includes(item.id) && item.assigned_category_id
                    );

                    if (eligibleItems.length === 0) {
                        this.toast('warning', 'No Categories', 'Selected items must have category assigned first. Run "Assign Category" first.');
                        return;
                    }

                    const count = eligibleItems.length;
                    this.toast('info', 'Processing', `Generating content for ${count} item(s)...`);

                    let successCount = 0;
                    let failCount = 0;

                    for (const item of eligibleItems) {
                        try {
                            const response = await fetch(acmsCatConfig.restUrl + 'queue/' + item.id + '/generate-content', {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json',
                                    'X-WP-Nonce': acmsCatConfig.nonce
                                }
                            });
                            const result = await response.json();

                            if (result.success) {
                                successCount++;
                            } else {
                                failCount++;
                            }
                        } catch (error) {
                            failCount++;
                        }
                    }

                    if (failCount === 0) {
                        this.toast('success', 'Done', `Content generation triggered for ${successCount} item(s)`);
                    } else if (successCount > 0) {
                        this.toast('warning', 'Partial', `${successCount} OK, ${failCount} failed`);
                    } else {
                        this.toast('error', 'Error', 'Failed to generate content');
                    }

                    this.selectedIds = [];
                    this.loadData();
                },

                async resetFailed() {
                    try {
                        const response = await fetch(acmsCatConfig.restUrl + 'queue/reset-failed', {
                            method: 'POST',
                            headers: { 'X-WP-Nonce': acmsCatConfig.nonce }
                        });
                        const result = await response.json();
                        if (result.success) {
                            this.toast('success', 'Success', result.message || 'Failed items reset');
                            this.loadData();
                        } else {
                            this.toast('error', 'Error', result.message || 'Failed to reset items');
                        }
                    } catch (error) {
                        this.toast('error', 'Error', 'Failed to reset items');
                    }
                },

                async resetStuck() {
                    try {
                        const response = await fetch(acmsCatConfig.restUrl + 'queue/reset-stuck', {
                            method: 'POST',
                            headers: { 'X-WP-Nonce': acmsCatConfig.nonce }
                        });
                        const result = await response.json();
                        if (result.success) {
                            this.toast('success', 'Success', result.message || 'Stuck items reset');
                            this.loadData();
                        } else {
                            this.toast('error', 'Error', result.message || 'Failed to reset stuck items');
                        }
                    } catch (error) {
                        this.toast('error', 'Error', 'Failed to reset stuck items');
                    }
                },

                /**
                 * Bulk run Category AI for selected items
                 * Triggers AI category standardization via affiliatecms-ai plugin
                 * @param {boolean} force - Force re-run even if already processed
                 */
                async bulkRunCategoryAi(force = false) {
                    if (this.selectedIds.length === 0) return;

                    const count = this.selectedIds.length;
                    const action = force ? 'Re-running' : 'Triggering';
                    this.toast('info', 'Processing', `${action} Category AI for ${count} item(s)...`);

                    let successCount = 0;
                    let failCount = 0;
                    let lastError = '';

                    // Process each selected item
                    for (const id of this.selectedIds) {
                        try {
                            // Use the AI plugin endpoint for category standardization
                            // Note: acms-ai plugin uses 'acms-ai/v1' namespace
                            const url = acmsCatConfig.restUrl.replace('acms-cat/v1', 'acms-ai/v1') + 'category-ai/queue/' + id;
                            console.log(`[ACMS] Calling Category AI: ${url}, force=${force}`);

                            const response = await fetch(url, {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json',
                                    'X-WP-Nonce': acmsCatConfig.nonce
                                },
                                body: JSON.stringify({ force: force })
                            });
                            const result = await response.json();
                            console.log(`[ACMS] Category AI response for queue ${id}:`, result);

                            if (result.success) {
                                successCount++;
                            } else {
                                failCount++;
                                lastError = result.message || 'Unknown error';
                                console.warn(`[ACMS] Failed for queue ${id}:`, result.message, 'Debug:', result.debug);
                            }
                        } catch (error) {
                            failCount++;
                            lastError = error.message || 'Network error';
                            console.error(`[ACMS] Error triggering Category AI for queue ${id}:`, error);
                        }
                    }

                    // Show result with last error message
                    if (failCount === 0) {
                        this.toast('success', 'Success', `Category AI triggered for ${successCount} item(s)`);
                    } else if (successCount > 0) {
                        this.toast('warning', 'Partial', `${successCount} succeeded, ${failCount} failed. Check console for details.`);
                    } else {
                        this.toast('error', 'Error', lastError || 'Failed to trigger Category AI. Check console for details.');
                    }

                    this.selectedIds = [];
                    this.loadData();
                },

                /**
                 * Bulk assign category using majority voting
                 * Uses product category_path to find most common path
                 * This is the method used when "Standardize Category Paths" setting is OFF
                 */
                async bulkAssignCategoryMajority() {
                    if (this.selectedIds.length === 0) return;

                    const count = this.selectedIds.length;
                    this.toast('info', 'Processing', `Assigning categories for ${count} item(s) using majority voting...`);

                    let successCount = 0;
                    let failCount = 0;
                    let lastError = '';

                    for (const id of this.selectedIds) {
                        try {
                            const url = acmsCatConfig.restUrl + 'queue/' + id + '/assign-category';
                            console.log(`[ACMS Majority] POST ${url}`);

                            const response = await fetch(url, {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json',
                                    'X-WP-Nonce': acmsCatConfig.nonce
                                }
                            });
                            const result = await response.json();
                            console.log(`[ACMS Majority] Response for ${id}:`, result);

                            if (result.success) {
                                successCount++;
                            } else {
                                failCount++;
                                lastError = result.message || 'Unknown error';
                            }
                        } catch (error) {
                            failCount++;
                            lastError = error.message || 'Network error';
                            console.error(`[ACMS Majority] Error for ${id}:`, error);
                        }
                    }

                    if (failCount === 0) {
                        this.toast('success', 'Success', `Category assigned for ${successCount} item(s) using majority voting`);
                    } else if (successCount > 0) {
                        this.toast('warning', 'Partial', `${successCount} succeeded, ${failCount} failed. Last error: ${lastError}`);
                    } else {
                        this.toast('error', 'Error', lastError || 'Failed to assign categories');
                    }

                    this.selectedIds = [];
                    this.loadData();
                },

                /**
                 * Bulk reset AI status for selected items
                 * Resets ai_status to 'not_started' so they can be re-processed
                 */
                async bulkResetAiStatus() {
                    if (this.selectedIds.length === 0) return;

                    const count = this.selectedIds.length;
                    this.toast('info', 'Processing', `Resetting AI status for ${count} item(s)...`);

                    let successCount = 0;
                    let failCount = 0;

                    for (const id of this.selectedIds) {
                        try {
                            const url = acmsCatConfig.restUrl + 'queue/' + id;
                            const body = {
                                status: 'ready_for_ai',  // Reset main status too
                                ai_status: 'not_started',
                                assigned_category_id: null,
                                suggested_categories: null,
                                cat_ai_generation_id: null,
                                custom_category_path: null
                            };
                            console.log(`[ACMS Reset AI] PUT ${url}`, body);

                            const response = await fetch(url, {
                                method: 'PUT',
                                headers: {
                                    'Content-Type': 'application/json',
                                    'X-WP-Nonce': acmsCatConfig.nonce
                                },
                                body: JSON.stringify(body)
                            });
                            const result = await response.json();
                            console.log(`[ACMS Reset AI] Response for ${id}:`, result);

                            if (result.success) {
                                successCount++;
                            } else {
                                console.warn(`[ACMS Reset AI] Failed for ${id}:`, result);
                                failCount++;
                            }
                        } catch (error) {
                            console.error(`[ACMS Reset AI] Error for ${id}:`, error);
                            failCount++;
                        }
                    }

                    if (failCount === 0) {
                        this.toast('success', 'Success', `AI status reset for ${successCount} item(s)`);
                    } else if (successCount > 0) {
                        this.toast('warning', 'Partial', `${successCount} succeeded, ${failCount} failed`);
                    } else {
                        this.toast('error', 'Error', 'Failed to reset AI status');
                    }

                    this.selectedIds = [];
                    this.loadData();
                },

                async bulkRunContentAi() {
                    if (this.selectedIds.length === 0) return;

                    // Filter items that have assigned_category_id (path already assigned)
                    const eligibleItems = this.items.filter(item =>
                        this.selectedIds.includes(item.id) &&
                        item.assigned_category_id &&
                        ['category_assigned', 'generating_content', 'failed'].includes(item.ai_status)
                    );

                    if (eligibleItems.length === 0) {
                        this.toast('warning', 'No Eligible Items', 'Selected items must have a category assigned first. Run Category AI first.');
                        return;
                    }

                    const count = eligibleItems.length;
                    this.toast('info', 'Processing', `Triggering content generation for ${count} item(s)...`);

                    let successCount = 0;
                    let failCount = 0;

                    for (const item of eligibleItems) {
                        try {
                            const url = acmsCatConfig.restUrl.replace('acms-cat/v1', 'acms-ai/v1') + 'content-ai/category/' + item.assigned_category_id;
                            console.log(`[ACMS Content AI] POST ${url}`, { queue_id: item.id });

                            const response = await fetch(url, {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json',
                                    'X-WP-Nonce': acmsCatConfig.nonce
                                },
                                body: JSON.stringify({
                                    queue_id: item.id,
                                    force: true  // Allow re-run even if content exists
                                })
                            });
                            const result = await response.json();
                            console.log(`[ACMS Content AI] Response for category ${item.assigned_category_id}:`, result);

                            if (result.success) {
                                successCount++;
                            } else {
                                console.warn(`[ACMS Content AI] Failed:`, result);
                                failCount++;
                            }
                        } catch (error) {
                            console.error(`[ACMS Content AI] Error:`, error);
                            failCount++;
                        }
                    }

                    if (failCount === 0) {
                        this.toast('success', 'Success', `Content AI triggered for ${successCount} item(s)`);
                    } else if (successCount > 0) {
                        this.toast('warning', 'Partial', `${successCount} succeeded, ${failCount} failed`);
                    } else {
                        this.toast('error', 'Error', 'Failed to trigger content AI');
                    }

                    this.selectedIds = [];
                    this.loadData();
                },

                /**
                 * Bulk link products to their assigned categories
                 */
                async bulkLinkProducts() {
                    if (this.selectedIds.length === 0) return;

                    // Filter items that have assigned_category_id but may need product linking
                    const eligibleItems = this.items.filter(item =>
                        this.selectedIds.includes(item.id) &&
                        item.assigned_category_id
                    );

                    if (eligibleItems.length === 0) {
                        this.toast('warning', 'No Eligible Items', 'Selected items must have a category assigned first. Run "Assign Category" first.');
                        return;
                    }

                    const count = eligibleItems.length;
                    this.toast('info', 'Processing', `Linking products for ${count} item(s)...`);

                    let successCount = 0;
                    let failCount = 0;
                    let totalLinked = 0;

                    for (const item of eligibleItems) {
                        try {
                            const response = await fetch(acmsCatConfig.restUrl + 'queue/' + item.id + '/link-products', {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json',
                                    'X-WP-Nonce': acmsCatConfig.nonce
                                }
                            });
                            const result = await response.json();

                            if (result.success) {
                                successCount++;
                                totalLinked += result.data?.linked_count || 0;
                            } else {
                                console.warn(`[ACMS Link Products] Failed for ${item.keyword}:`, result);
                                failCount++;
                            }
                        } catch (error) {
                            console.error(`[ACMS Link Products] Error:`, error);
                            failCount++;
                        }
                    }

                    if (failCount === 0) {
                        this.toast('success', 'Success', `Linked ${totalLinked} products for ${successCount} item(s)`);
                    } else if (successCount > 0) {
                        this.toast('warning', 'Partial', `${successCount} succeeded (${totalLinked} products), ${failCount} failed`);
                    } else {
                        this.toast('error', 'Error', 'Failed to link products');
                    }

                    this.selectedIds = [];
                    this.loadData();
                },

                /**
                 * Bulk diagnose issues with selected items
                 */
                async bulkDiagnose() {
                    if (this.selectedIds.length === 0) return;

                    const count = this.selectedIds.length;
                    this.toast('info', 'Diagnosing', `Checking ${count} item(s)...`);

                    const results = [];

                    for (const id of this.selectedIds) {
                        try {
                            const response = await fetch(acmsCatConfig.restUrl + 'queue/' + id + '/diagnose', {
                                headers: { 'X-WP-Nonce': acmsCatConfig.nonce }
                            });
                            const result = await response.json();
                            if (result.success && result.data) {
                                results.push(result.data);
                            }
                        } catch (error) {
                            console.error(`[ACMS Diagnose] Error for ID ${id}:`, error);
                        }
                    }

                    // Show summary modal
                    this.showBulkDiagnoseResults(results);
                },

                /**
                 * Show bulk diagnose results in a modal/toast
                 */
                showBulkDiagnoseResults(results) {
                    if (results.length === 0) {
                        this.toast('warning', 'No Results', 'No diagnosis data available');
                        return;
                    }

                    // Count issues by type
                    const issueTypes = {};
                    const actionTypes = {};

                    results.forEach(r => {
                        (r.issues || []).forEach(issue => {
                            issueTypes[issue] = (issueTypes[issue] || 0) + 1;
                        });
                        (r.next_actions || []).forEach(action => {
                            actionTypes[action] = (actionTypes[action] || 0) + 1;
                        });
                    });

                    // Build summary message
                    const totalIssues = Object.values(issueTypes).reduce((a, b) => a + b, 0);
                    const okCount = results.filter(r => r.issues?.length === 0).length;

                    let message = `Checked ${results.length} items:\n`;
                    message += `• ${okCount} items OK\n`;
                    message += `• ${results.length - okCount} items with issues\n\n`;

                    if (Object.keys(issueTypes).length > 0) {
                        message += 'Common issues:\n';
                        Object.entries(issueTypes)
                            .sort((a, b) => b[1] - a[1])
                            .slice(0, 5)
                            .forEach(([issue, count]) => {
                                message += `• ${issue}: ${count}\n`;
                            });
                    }

                    if (Object.keys(actionTypes).length > 0) {
                        message += '\nRecommended actions:\n';
                        Object.entries(actionTypes)
                            .sort((a, b) => b[1] - a[1])
                            .slice(0, 3)
                            .forEach(([action, count]) => {
                                message += `• ${action}: ${count}\n`;
                            });
                    }

                    // Show as alert for now (could be improved to a modal)
                    alert(message);
                },

                async forceResetItem(item) {
                    if (!confirm('Force reset this item? It will be reset to pending status.')) return;
                    try {
                        const response = await fetch(acmsCatConfig.restUrl + 'queue/' + item.id + '/force-reset', {
                            method: 'POST',
                            headers: { 'X-WP-Nonce': acmsCatConfig.nonce }
                        });
                        const result = await response.json();
                        if (result.success) {
                            this.toast('success', 'Reset', 'Item reset to pending');
                            this.loadData();
                        } else {
                            this.toast('error', 'Error', result.message || 'Failed to reset item');
                        }
                    } catch (error) {
                        this.toast('error', 'Error', 'Failed to reset item');
                    }
                },

                async forceDeleteItem(item) {
                    if (!confirm('Force delete this processing item?')) return;
                    try {
                        const response = await fetch(acmsCatConfig.restUrl + 'queue/' + item.id + '/force', {
                            method: 'DELETE',
                            headers: { 'X-WP-Nonce': acmsCatConfig.nonce }
                        });
                        const result = await response.json();
                        if (result.success) {
                            this.toast('success', 'Deleted', 'Item force deleted');
                            this.loadData();
                        } else {
                            this.toast('error', 'Error', result.message || 'Failed to delete item');
                        }
                    } catch (error) {
                        this.toast('error', 'Error', 'Failed to delete item');
                    }
                },

                toast(type, title, message) {
                    this.toastType = type;
                    this.toastTitle = title;
                    this.toastMessage = message;
                    this.showToast = true;
                    setTimeout(() => { this.showToast = false; }, 5000);
                }
            }));
        });
        </script>
        <?php
    }

    /**
     * Render CSS styles
     */
    private function renderStyles(): void
    {
        ?>
        /* CSS Variables - Dark Theme */
        :root {
            --primary: #2271b1;
            --primary-hover: #135e96;
            --primary-light: rgba(34, 113, 177, 0.1);
            --bg-base: #0a0a0b;
            --bg-surface: #111113;
            --bg-elevated: #18181b;
            --bg-hover: #1f1f23;
            --border: #27272a;
            --border-hover: #3f3f46;
            --text-primary: #fafafa;
            --text-secondary: #a1a1aa;
            --text-muted: #71717a;
            --success: #22c55e;
            --success-light: rgba(34, 197, 94, 0.1);
            --warning: #f59e0b;
            --warning-light: rgba(245, 158, 11, 0.1);
            --error: #ef4444;
            --error-light: rgba(239, 68, 68, 0.1);
            --info: #3b82f6;
            --info-light: rgba(59, 130, 246, 0.1);
            --radius-sm: 6px;
            --radius-md: 8px;
            --radius-lg: 12px;
            --shadow-md: 0 4px 12px rgba(0, 0, 0, 0.4);
            --shadow-lg: 0 10px 40px rgba(0, 0, 0, 0.5);
            --wp-admin-bar-height: 32px;
        }

        /* WP Admin Z-Index Fix */
        #adminmenuback, #adminmenuwrap { z-index: 1001 !important; }

        /* Reset */
        .acms-admin, .acms-admin *, .acms-admin *::before, .acms-admin *::after { box-sizing: border-box; }
        .acms-admin {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif !important;
            font-size: 14px !important;
            line-height: 1.5 !important;
            color: var(--text-primary) !important;
            -webkit-font-smoothing: antialiased;
        }
        [x-cloak] { display: none !important; }

        /* Layout */
        html.wp-toolbar, body.wp-admin { overflow: hidden !important; height: 100vh !important; }
        .wrap:has(.acms-admin) { margin: 0 !important; padding: 0 !important; max-width: none !important; }
        .acms-admin {
            position: fixed;
            top: var(--wp-admin-bar-height);
            left: 160px;
            right: 0;
            bottom: 0;
            overflow-y: auto;
            background: var(--bg-base);
        }
        .folded .acms-admin { left: 36px; }
        @media (max-width: 960px) { .acms-admin { left: 36px; } }
        @media (max-width: 782px) { .acms-admin { left: 0; top: 46px; } }

        .app-container { max-width: 1600px; margin: 0 auto; padding: 16px; }

        /* Page Header */
        .page-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 16px;
            margin-bottom: 16px;
        }
        .header-left { display: flex; align-items: center; gap: 12px; }
        .header-actions { display: flex; align-items: center; gap: 8px; }
        .header-divider { width: 1px; height: 28px; background: var(--border); }

        /* Stats Inline */
        .stats-inline { display: flex; gap: 16px; }
        .stat-item {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 8px 12px;
            background: var(--bg-surface);
            border-radius: var(--radius-md);
            border: 1px solid var(--border);
        }
        .stat-item-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: var(--text-muted);
        }
        .stat-item.pending .stat-item-dot { background: var(--primary); }
        .stat-item.processing .stat-item-dot { background: var(--info); }
        .stat-item.completed .stat-item-dot { background: var(--success); }
        .stat-item.failed .stat-item-dot { background: var(--error); }
        .stat-item-value { font-size: 18px; font-weight: 600; color: var(--text-primary); }
        .stat-item-label { font-size: 12px; color: var(--text-muted); }

        /* Buttons */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 8px 16px;
            font-size: 13px;
            font-weight: 500;
            border-radius: var(--radius-md);
            border: 1px solid transparent;
            cursor: pointer;
            transition: all 0.15s ease;
            white-space: nowrap;
        }
        .btn:disabled { opacity: 0.5; cursor: not-allowed; }
        .btn-primary { background: var(--primary); color: white; border-color: var(--primary); }
        .btn-primary:hover:not(:disabled) { background: var(--primary-hover); }
        .btn-secondary { background: var(--bg-surface); color: var(--text-primary); border-color: var(--border); }
        .btn-secondary:hover:not(:disabled) { background: var(--bg-hover); border-color: var(--border-hover); }
        .btn-success { background: var(--success); color: white; border: none; }
        .btn-success:hover:not(:disabled) { opacity: 0.9; }
        .btn-group { display: flex; gap: 8px; }

        .btn-icon {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 36px;
            height: 36px;
            padding: 0;
            background: var(--bg-surface);
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
            color: var(--text-secondary);
            cursor: pointer;
            transition: all 0.15s ease;
        }
        .btn-icon:hover { background: var(--bg-hover); color: var(--text-primary); border-color: var(--border-hover); }
        .btn-icon.active { background: var(--primary-light); color: var(--primary); border-color: var(--primary); }
        .btn-icon-sm { width: 28px; height: 28px; font-size: 14px; }
        .btn-icon-xs { width: 20px; height: 20px; font-size: 11px; border: none; background: transparent; }
        .btn-icon-xs:hover { background: var(--bg-hover); }
        .btn-icon.btn-danger:hover { background: var(--error-light); color: var(--error); border-color: var(--error); }
        .btn-icon.btn-ai { color: var(--purple, #a855f7); }
        .btn-icon.btn-ai:hover { background: rgba(168, 85, 247, 0.1); color: var(--purple, #a855f7); border-color: var(--purple, #a855f7); }
        .btn-icon.btn-warning { color: var(--warning, #f59e0b); }
        .btn-icon.btn-warning:hover { background: rgba(245, 158, 11, 0.1); color: var(--warning, #f59e0b); border-color: var(--warning, #f59e0b); }
        .btn-icon.btn-info { color: var(--info, #06b6d4); }
        .btn-icon.btn-info:hover { background: rgba(6, 182, 212, 0.1); color: var(--info, #06b6d4); border-color: var(--info, #06b6d4); }
        .btn-icon.btn-success { color: var(--success, #10b981); }
        .btn-icon.btn-success:hover { background: rgba(16, 185, 129, 0.1); color: var(--success, #10b981); border-color: var(--success, #10b981); }
        .btn-icon.btn-outline { color: var(--text-muted); border-style: dashed; }
        .btn-icon.btn-outline:hover { color: var(--primary); border-color: var(--primary); border-style: solid; }

        /* Diagnose Modal */
        .diagnose-overlay {
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 10000;
        }
        .diagnose-modal {
            background: var(--bg-base);
            border-radius: var(--radius-lg);
            min-width: 400px;
            max-width: 600px;
            max-height: 80vh;
            overflow: hidden;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.3);
        }
        .diagnose-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 16px 20px;
            border-bottom: 1px solid var(--border);
            background: var(--bg-surface);
        }
        .diagnose-header h3 {
            margin: 0;
            font-size: 16px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .diagnose-close {
            background: none;
            border: none;
            font-size: 24px;
            color: var(--text-muted);
            cursor: pointer;
            line-height: 1;
        }
        .diagnose-close:hover { color: var(--text-primary); }
        .diagnose-body {
            padding: 20px;
            font-size: 13px;
            line-height: 1.6;
            max-height: 50vh;
            overflow-y: auto;
        }
        .diagnose-body strong { color: var(--text-primary); }
        .diagnose-body .text-warning { color: var(--warning); }
        .diagnose-body .text-info { color: var(--info); }
        .diagnose-footer {
            padding: 12px 20px;
            border-top: 1px solid var(--border);
            display: flex;
            justify-content: flex-end;
        }

        /* Toolbar */
        .toolbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 16px;
            padding: 12px 16px;
            background: var(--bg-surface);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            margin-bottom: 16px;
        }
        .toolbar-section { display: flex; align-items: center; gap: 8px; }
        .toolbar-center { flex: 1; max-width: 400px; margin: 0 auto; }

        .selected-count {
            font-size: 13px;
            color: var(--text-muted);
            padding: 4px 8px;
            background: var(--primary-light);
            border-radius: var(--radius-sm);
        }
        .selected-count-number { font-weight: 600; color: var(--primary); }

        /* Search Box */
        .search-box {
            position: relative;
            display: flex;
            align-items: center;
            width: 100%;
            max-width: 400px;
        }
        .search-box .search-icon {
            position: absolute;
            right: 12px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-muted);
            font-size: 14px;
            pointer-events: none;
            z-index: 1;
            line-height: 1;
        }
        .search-box .search-input {
            width: 100%;
            height: 36px;
            padding: 0 64px 0 14px !important;
            font-size: 13px !important;
            background: var(--bg-base) !important;
            border: 1px solid var(--border) !important;
            border-radius: var(--radius-md) !important;
            color: var(--text-primary) !important;
            transition: all 0.15s ease;
            line-height: 36px;
        }
        .search-box .search-input:focus {
            border-color: var(--primary) !important;
            box-shadow: 0 0 0 3px var(--primary-light) !important;
            outline: none !important;
        }
        .search-box .search-input::placeholder {
            color: var(--text-muted) !important;
        }
        .search-box .search-input::-webkit-search-cancel-button {
            -webkit-appearance: none;
            display: none;
        }
        .search-box .search-clear {
            position: absolute;
            right: 36px;
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: var(--bg-hover);
            border: none;
            border-radius: 50%;
            color: var(--text-muted);
            cursor: pointer;
            transition: all 0.15s ease;
            z-index: 2;
        }
        .search-box .search-clear:hover {
            background: var(--border);
            color: var(--text-primary);
        }
        .search-box .search-clear i {
            font-size: 10px;
        }

        /* Dropdown */
        .dropdown { position: relative; }
        .dropdown-menu {
            position: absolute;
            top: 100%;
            left: 0;
            margin-top: 4px;
            min-width: 160px;
            padding: 4px;
            background: var(--bg-elevated);
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
            box-shadow: var(--shadow-lg);
            z-index: 100;
        }
        .dropdown-menu.right { left: auto; right: 0; }
        .dropdown-item {
            display: flex;
            align-items: center;
            gap: 8px;
            width: 100%;
            padding: 8px 12px;
            font-size: 13px;
            color: var(--text-primary);
            background: transparent;
            border: none;
            border-radius: var(--radius-sm);
            cursor: pointer;
            text-align: left;
        }
        .dropdown-item:hover { background: var(--bg-hover); }
        .dropdown-item.selected { background: var(--primary-light); color: var(--primary); }
        .dropdown-item.danger { color: var(--error); }
        .dropdown-item.danger:hover { background: var(--error-light); }
        .dropdown-divider { height: 1px; background: var(--border); margin: 4px 0; }

        /* Wide dropdown menu for bulk actions */
        .dropdown-menu-wide {
            min-width: 280px;
            max-height: 70vh;
            overflow-y: auto;
        }
        .dropdown-header {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 10px 12px 6px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
            color: var(--text-muted);
            letter-spacing: 0.5px;
        }
        .dropdown-header:not(:first-child) {
            margin-top: 8px;
            padding-top: 12px;
            border-top: 1px solid var(--border);
        }
        .dropdown-header i {
            font-size: 14px;
            color: var(--primary);
        }

        /* Icon color classes for dropdown items */
        .dropdown-item .text-success { color: var(--success); }
        .dropdown-item .text-warning { color: var(--warning); }
        .dropdown-item .text-primary { color: var(--primary); }
        .dropdown-item .text-info { color: #3b82f6; }
        .dropdown-item .text-accent { color: #a855f7; }

        /* Data Table */
        .data-table-wrapper {
            background: var(--bg-surface);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            overflow: hidden;
        }
        .data-table-loading, .data-table-empty {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 12px;
            padding: 60px 20px;
            color: var(--text-muted);
        }
        .data-table-empty i { font-size: 48px; opacity: 0.5; }
        .spinner {
            width: 32px;
            height: 32px;
            border: 3px solid var(--border);
            border-top-color: var(--primary);
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        @keyframes spin { to { transform: rotate(360deg); } }

        .data-table-container { overflow-x: auto; }
        .data-table {
            width: 100%;
            border-collapse: collapse;
        }
        .data-table th, .data-table td {
            padding: 12px 16px;
            text-align: left;
            border-bottom: 1px solid var(--border);
        }
        .data-table th {
            font-size: 12px;
            font-weight: 600;
            color: var(--text-muted);
            text-transform: uppercase;
            background: var(--bg-elevated);
        }
        .data-table th.sortable { cursor: pointer; }
        .data-table th.sortable:hover { color: var(--text-primary); }
        .data-table th.sorted { color: var(--primary); }
        .sort-icon { font-size: 10px; margin-left: 4px; opacity: 0.5; }
        .data-table tr:hover { background: var(--bg-hover); }
        .data-table tr.selected { background: var(--primary-light); }

        .col-checkbox { width: 40px; }
        .col-keyword { min-width: 200px; }
        .col-status { width: 100px; }
        .col-scrape { width: 90px; text-align: center; }
        .col-ai { width: 90px; text-align: center; }
        .col-products { width: 100px; text-align: center; }
        .col-categories { min-width: 120px; }
        .col-date { width: 100px; }
        .col-actions { width: 180px; }

        .keyword-cell { display: flex; flex-direction: column; gap: 3px; }
        .keyword-row { display: flex; align-items: center; gap: 4px; }
        .keyword-text { font-weight: 500; color: var(--text-primary); }
        .btn-icon-inline {
            display: inline-flex; align-items: center; justify-content: center;
            width: 20px; height: 20px; border: none; background: none;
            color: var(--text-muted); cursor: pointer; border-radius: 3px;
            padding: 0; opacity: 0; transition: opacity 0.15s, color 0.15s, background 0.15s;
        }
        .keyword-row:hover .btn-icon-inline { opacity: 1; }
        .btn-icon-inline:hover { color: var(--primary); background: var(--bg-hover); }
        .btn-icon-inline i { font-size: 11px; }
        .keyword-cat-link {
            display: inline-flex; align-items: center; gap: 3px;
            font-size: 11px; color: var(--primary); text-decoration: none;
            max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
        }
        .keyword-cat-link:hover { text-decoration: underline; }
        .keyword-cat-link i { font-size: 10px; flex-shrink: 0; }
        .error-text { font-size: 12px; color: var(--error); }

        .categories-cell { display: flex; flex-direction: column; gap: 2px; }
        .cat-name-link {
            font-size: 12px; color: var(--text-primary); text-decoration: none;
            font-weight: 500; max-width: 140px; overflow: hidden;
            text-overflow: ellipsis; white-space: nowrap; display: block;
        }
        .cat-name-link:hover { color: var(--primary); text-decoration: underline; }
        .cat-product-count {
            font-size: 10px; color: var(--text-muted);
        }

        .products-cell {
            position: relative;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
        }
        .products-count.clickable {
            cursor: pointer;
            text-decoration: underline;
            text-decoration-style: dotted;
        }
        .products-count.clickable:hover {
            color: var(--primary);
        }
        .asins-tooltip {
            position: absolute;
            top: 100%;
            left: 50%;
            transform: translateX(-50%);
            margin-top: 8px;
            min-width: 300px;
            max-width: 500px;
            max-height: 150px;
            padding: 12px;
            background: var(--bg-elevated);
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
            box-shadow: var(--shadow-lg);
            z-index: 200;
            overflow-y: auto;
        }
        .asins-tooltip-content {
            font-size: 12px;
            font-family: 'Consolas', 'Monaco', monospace;
            color: var(--text-secondary);
            line-height: 1.6;
            word-break: break-all;
        }

        .badge {
            display: inline-block;
            padding: 4px 8px;
            font-size: 11px;
            font-weight: 500;
            text-transform: capitalize;
            border-radius: var(--radius-sm);
        }
        .badge-primary { background: var(--primary-light); color: var(--primary); }
        .badge-info { background: var(--info-light); color: var(--info); }
        .badge-success { background: var(--success-light); color: var(--success); }
        .badge-error { background: var(--error-light); color: var(--error); }
        .badge-secondary { background: var(--bg-hover); color: var(--text-muted); }
        .badge-warning { background: #fef3c7; color: #d97706; }
        .badge-purple { background: #ede9fe; color: #7c3aed; }

        /* Scrape Progress Mini Bar */
        .scrape-progress-cell {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
        }
        .progress-bar-mini {
            width: 40px;
            height: 6px;
            background: var(--bg-hover);
            border-radius: 3px;
            overflow: hidden;
        }
        .progress-fill {
            height: 100%;
            transition: width 0.3s ease;
            border-radius: 3px;
        }
        .progress-low .progress-fill { background: var(--error); }
        .progress-medium .progress-fill { background: #f59e0b; }
        .progress-high .progress-fill { background: var(--info); }
        .progress-complete .progress-fill { background: var(--success); }
        .progress-text {
            font-size: 11px;
            font-weight: 500;
            color: var(--text-secondary);
            min-width: 32px;
        }

        /* AI Status Badge */
        .badge-ai {
            font-size: 10px;
            padding: 3px 6px;
        }

        .date-value { font-size: 12px; color: var(--text-secondary); }
        .actions-cell { display: flex; gap: 4px; }

        /* Pagination */
        .data-table-pagination {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 12px 16px;
            border-top: 1px solid var(--border);
        }
        .pagination-info { font-size: 13px; color: var(--text-muted); }
        .pagination-controls { display: flex; align-items: center; gap: 8px; }
        .pagination-buttons { display: flex; gap: 4px; }
        .pagination-btn {
            display: flex;
            align-items: center;
            justify-content: center;
            min-width: 32px;
            height: 32px;
            padding: 0 8px;
            font-size: 13px;
            background: var(--bg-elevated);
            border: 1px solid var(--border);
            border-radius: var(--radius-sm);
            color: var(--text-secondary);
            cursor: pointer;
        }
        .pagination-btn:hover:not(:disabled) { background: var(--bg-hover); color: var(--text-primary); }
        .pagination-btn.active { background: var(--primary); color: white; border-color: var(--primary); }
        .pagination-btn:disabled { opacity: 0.5; cursor: not-allowed; }

        /* Modal */
        .modal-backdrop {
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.7);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 10000;
            padding: 20px;
        }
        .modal {
            background: var(--bg-surface);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-lg);
            max-width: 100%;
            max-height: 90vh;
            overflow: hidden;
            display: flex;
            flex-direction: column;
        }
        .modal-md { width: 560px; }
        .modal-lg { width: 800px; }
        .modal-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 16px 20px;
            border-bottom: 1px solid var(--border);
        }
        .modal-title {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 16px;
            font-weight: 600;
            color: var(--text-primary);
            margin: 0;
        }
        .modal-close {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 32px;
            height: 32px;
            padding: 0;
            background: transparent;
            border: none;
            border-radius: var(--radius-sm);
            color: var(--text-muted);
            cursor: pointer;
        }
        .modal-close:hover { background: var(--bg-hover); color: var(--text-primary); }
        .modal-body { padding: 20px; overflow-y: auto; }
        .modal-footer {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 16px 20px;
            border-top: 1px solid var(--border);
        }

        /* Form */
        .form-group { margin-bottom: 16px; }
        .form-label {
            display: block;
            margin-bottom: 6px;
            font-size: 13px;
            font-weight: 500;
            color: var(--text-primary);
        }
        .form-hint { font-weight: 400; color: var(--text-muted); }
        .form-textarea, .form-input {
            width: 100%;
            padding: 10px 12px;
            font-size: 14px;
            color: var(--text-primary);
            background: var(--bg-base);
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
            resize: vertical;
        }
        .form-textarea:focus, .form-input:focus {
            outline: none;
            border-color: var(--primary);
        }
        .form-textarea::placeholder, .form-input::placeholder { color: var(--text-muted); }
        .form-help { font-size: 12px; color: var(--text-muted); margin-top: 4px; }
        .form-help-success { color: #059669; }
        .form-row { display: flex; gap: 16px; }

        /* AI Suggested Categories */
        .text-purple { color: #8b5cf6; }
        .text-success { color: var(--success); }
        .text-info { color: var(--info); }
        .suggested-categories-box {
            background: linear-gradient(135deg, rgba(139, 92, 246, 0.05), rgba(59, 130, 246, 0.05));
            border: 1px solid rgba(139, 92, 246, 0.2);
            border-radius: var(--radius-md);
            padding: 12px;
        }
        .suggested-paths {
            display: flex;
            flex-direction: column;
            gap: 6px;
            margin-bottom: 8px;
        }
        .suggested-path-item {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 8px 12px;
            background: var(--bg-elevated);
            border: 1px solid var(--border);
            border-radius: var(--radius-sm);
            font-size: 13px;
            cursor: pointer;
            transition: all 0.15s ease;
        }
        .suggested-path-item:hover {
            border-color: var(--primary);
            background: rgba(59, 130, 246, 0.05);
        }
        .suggested-path-item .bi-folder { color: #f59e0b; }
        .suggested-path-item .add-icon {
            margin-left: auto;
            color: var(--text-muted);
            opacity: 0;
            transition: opacity 0.15s ease;
        }
        .suggested-path-item:hover .add-icon {
            opacity: 1;
            color: var(--primary);
        }
        .ai-reasoning {
            font-size: 12px;
            color: var(--text-muted);
            padding: 8px;
            background: var(--bg-base);
            border-radius: var(--radius-sm);
            display: flex;
            gap: 6px;
            align-items: flex-start;
        }
        .ai-reasoning .bi-lightbulb { color: #f59e0b; flex-shrink: 0; }
        .form-row > .form-group { flex: 1; }

        /* Delete Modal */
        .delete-info {
            padding: 12px 16px;
            background: var(--bg-base);
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
            margin-bottom: 16px;
        }
        .delete-keyword {
            font-size: 14px;
            margin-bottom: 4px;
        }
        .delete-keyword strong {
            color: var(--text-muted);
            margin-right: 8px;
        }
        .delete-stats {
            font-size: 13px;
            color: var(--text-secondary);
        }
        .delete-stats strong {
            color: var(--text-muted);
            margin-right: 8px;
        }
        .delete-options {
            display: flex;
            flex-direction: column;
            gap: 8px;
            margin-bottom: 16px;
        }
        .delete-option {
            display: flex;
            align-items: flex-start;
            gap: 12px;
            padding: 12px 16px;
            background: var(--bg-base);
            border: 2px solid var(--border);
            border-radius: var(--radius-md);
            cursor: pointer;
            transition: all 0.15s ease;
        }
        .delete-option:hover {
            border-color: var(--border-hover);
        }
        .delete-option.selected {
            border-color: var(--primary);
            background: var(--primary-light);
        }
        .delete-option input[type="radio"] {
            margin-top: 2px;
            accent-color: var(--primary);
        }
        .delete-option-content {
            flex: 1;
        }
        .delete-option-title {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 14px;
            font-weight: 500;
            color: var(--text-primary);
            margin-bottom: 4px;
        }
        .delete-option-desc {
            font-size: 12px;
            color: var(--text-muted);
            line-height: 1.4;
        }
        .delete-warning {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 10px 14px;
            background: var(--info-light);
            border-radius: var(--radius-md);
            font-size: 12px;
            color: var(--info);
        }
        .btn-danger {
            background: var(--error);
            color: white;
            border-color: var(--error);
        }
        .btn-danger:hover:not(:disabled) {
            opacity: 0.9;
        }
        .text-error {
            color: var(--error);
        }

        /* Stepper */
        .stepper {
            position: relative;
            display: flex;
            align-items: center;
            width: 100%;
        }
        .stepper-input {
            flex: 1;
            width: 100%;
            height: 38px;
            padding: 0 36px;
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
            background: var(--bg-base);
            text-align: center;
            font-size: 14px;
            font-weight: 600;
            color: var(--text-primary);
            -moz-appearance: textfield;
        }
        .stepper-input::-webkit-outer-spin-button,
        .stepper-input::-webkit-inner-spin-button { -webkit-appearance: none; margin: 0; }
        .stepper-input:focus { outline: none; border-color: var(--primary); }
        .stepper-btn {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            width: 28px;
            height: 28px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: transparent;
            border: none;
            color: var(--text-muted);
            cursor: pointer;
        }
        .stepper-btn:first-child { left: 4px; }
        .stepper-btn:last-child { right: 4px; }
        .stepper-btn:hover { color: var(--text-primary); }

        /* Toast */
        .toast-container {
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 10001;
        }
        .toast {
            display: flex;
            align-items: flex-start;
            gap: 12px;
            padding: 16px;
            background: var(--bg-elevated);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-lg);
            min-width: 300px;
            max-width: 400px;
        }
        .toast-icon { font-size: 20px; flex-shrink: 0; }
        .toast-success .toast-icon { color: var(--success); }
        .toast-warning .toast-icon { color: var(--warning); }
        .toast-error .toast-icon { color: var(--error); }
        .toast-info .toast-icon { color: var(--info); }
        .toast-content { flex: 1; }
        .toast-title { font-weight: 600; color: var(--text-primary); margin-bottom: 2px; }
        .toast-message { font-size: 13px; color: var(--text-secondary); }
        .toast-close {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 24px;
            height: 24px;
            padding: 0;
            background: transparent;
            border: none;
            color: var(--text-muted);
            cursor: pointer;
            border-radius: var(--radius-sm);
        }
        .toast-close:hover { background: var(--bg-hover); color: var(--text-primary); }

        /* Animations */
        .animate-spin { animation: spin 1s linear infinite; }
        .transition { transition: all 0.15s ease; }
        .refresh-success i { color: var(--success) !important; }

        /* Processing Log Modal */
        .modal-subtitle {
            font-size: 13px;
            font-weight: 400;
            color: var(--text-muted);
            margin-left: 8px;
        }
        .empty-log {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 12px;
            padding: 60px 20px;
            color: var(--text-muted);
        }
        .empty-log i { font-size: 48px; opacity: 0.5; }

        .log-container {
            margin-bottom: 24px;
        }
        .log-container:last-child {
            margin-bottom: 0;
        }
        .log-section-title {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 14px;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 12px;
            padding-bottom: 8px;
            border-bottom: 1px solid var(--border);
        }
        .log-section-title.error {
            color: var(--error);
        }

        .log-entry {
            padding: 12px;
            background: var(--bg-base);
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
            margin-bottom: 8px;
        }
        .log-entry:last-child {
            margin-bottom: 0;
        }
        .log-entry.error,
        .log-entry-error {
            background: var(--error-light);
            border-color: var(--error);
        }
        .log-entry-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 6px;
        }
        .log-step {
            display: inline-block;
            padding: 2px 8px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
            background: var(--primary-light);
            color: var(--primary);
            border-radius: var(--radius-sm);
        }
        .log-entry.error .log-step {
            background: var(--error-light);
            color: var(--error);
        }
        .log-timestamp {
            font-size: 11px;
            color: var(--text-muted);
        }
        .log-message {
            font-size: 13px;
            color: var(--text-primary);
            line-height: 1.5;
        }
        .log-data {
            margin-top: 8px;
            padding: 8px;
            background: var(--bg-elevated);
            border-radius: var(--radius-sm);
            overflow-x: auto;
        }
        .log-data pre {
            margin: 0;
            font-size: 11px;
            font-family: 'Consolas', 'Monaco', 'Courier New', monospace;
            color: var(--text-secondary);
            line-height: 1.5;
        }

        /* Log Item Info Header */
        .log-item-info {
            display: flex;
            flex-direction: column;
            gap: 8px;
            padding: 16px;
            background: var(--bg-elevated);
            border-radius: var(--radius-md);
            margin-bottom: 20px;
        }
        .log-item-keyword {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 16px;
            font-weight: 600;
            color: var(--text-primary);
        }
        .log-item-keyword i {
            color: var(--primary);
        }
        .log-item-meta {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 12px;
            color: var(--text-secondary);
        }
        .log-item-id {
            color: var(--text-muted);
        }
        .log-item-status {
            padding: 2px 8px;
            border-radius: var(--radius-sm);
            font-weight: 500;
            text-transform: capitalize;
            background: var(--bg-base);
        }
        .log-item-status.status-completed { background: var(--success-light); color: var(--success); }
        .log-item-status.status-processing { background: var(--primary-light); color: var(--primary); }
        .log-item-status.status-failed { background: var(--error-light); color: var(--error); }
        .log-item-status.status-pending { background: var(--warning-light); color: var(--warning); }
        .log-item-ai-status {
            padding: 2px 8px;
            border-radius: var(--radius-sm);
            font-weight: 500;
            background: var(--bg-base);
            color: var(--text-secondary);
        }

        /* Log Phases Progress Indicator */
        .log-phases {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 16px;
            background: var(--bg-elevated);
            border-radius: var(--radius-md);
            margin-bottom: 20px;
            overflow-x: auto;
        }
        .phase-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 8px;
            padding: 8px 16px;
            position: relative;
            flex: 1;
            min-width: 80px;
        }
        .phase-item:not(:last-child)::after {
            content: '';
            position: absolute;
            top: 16px;
            right: -50%;
            width: 100%;
            height: 2px;
            background: var(--border);
            z-index: 0;
        }
        .phase-item.phase-done:not(:last-child)::after {
            background: var(--success);
        }
        .phase-item .phase-icon {
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            background: var(--bg-base);
            border: 2px solid var(--border);
            color: var(--text-muted);
            font-size: 14px;
            z-index: 1;
            transition: all 0.2s ease;
        }
        .phase-item.phase-done .phase-icon {
            background: var(--success);
            border-color: var(--success);
            color: white;
        }
        .phase-item.phase-active .phase-icon {
            background: var(--primary);
            border-color: var(--primary);
            color: white;
            animation: pulse 1.5s infinite;
        }
        @keyframes pulse {
            0%, 100% { box-shadow: 0 0 0 0 rgba(var(--primary-rgb), 0.4); }
            50% { box-shadow: 0 0 0 6px rgba(var(--primary-rgb), 0); }
        }
        .phase-item .phase-label {
            font-size: 11px;
            font-weight: 500;
            color: var(--text-muted);
            text-transform: uppercase;
            text-align: center;
        }
        .phase-item.phase-done .phase-label,
        .phase-item.phase-active .phase-label {
            color: var(--text-primary);
            font-weight: 600;
        }
        .phase-connector {
            flex: 0 0 40px;
            height: 2px;
            background: var(--border);
            margin-top: -16px;
        }

        /* Log Phases Detail Sections */
        .log-phases-detail {
            display: flex;
            flex-direction: column;
            gap: 16px;
        }
        .log-phase-section {
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
            overflow: hidden;
        }
        .log-phase-header {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 12px 16px;
            background: var(--bg-elevated);
            border-bottom: 1px solid var(--border);
            cursor: pointer;
            font-size: 13px;
            font-weight: 600;
            color: var(--text-primary);
        }
        .log-phase-header:hover {
            background: var(--bg-hover);
        }
        .log-phase-header > i {
            font-size: 14px;
            color: var(--text-muted);
        }
        .log-phase-header > span:last-child {
            margin-left: auto;
        }
        .phase-count {
            font-size: 11px;
            font-weight: 500;
            color: var(--text-muted);
            padding: 2px 8px;
            background: var(--bg-base);
            border-radius: var(--radius-sm);
        }
        .log-phase-entries {
            padding: 12px;
            display: flex;
            flex-direction: column;
            gap: 8px;
            max-height: 300px;
            overflow-y: auto;
        }
        .log-phase-entry {
            padding: 10px 12px;
            background: var(--bg-base);
            border-radius: var(--radius-sm);
            border-left: 3px solid var(--border);
        }
        .log-phase-entry.success {
            border-left-color: var(--success);
        }
        .log-phase-entry.error {
            border-left-color: var(--error);
            background: var(--error-light);
        }
        .log-entry-meta {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 6px;
        }
        .log-step-badge {
            display: inline-block;
            padding: 2px 8px;
            font-size: 10px;
            font-weight: 600;
            text-transform: uppercase;
            background: var(--primary-light);
            color: var(--primary);
            border-radius: var(--radius-sm);
        }
        .log-step-badge.error {
            background: var(--error-light);
            color: var(--error);
        }
        .log-entry-message {
            font-size: 13px;
            color: var(--text-primary);
            line-height: 1.5;
        }
        .log-entry-data {
            margin-top: 8px;
            padding: 8px;
            background: var(--bg-elevated);
            border-radius: var(--radius-sm);
            font-size: 11px;
            font-family: 'Consolas', 'Monaco', 'Courier New', monospace;
            color: var(--text-secondary);
            overflow-x: auto;
        }
        .log-data-item {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            margin-right: 12px;
            margin-bottom: 4px;
        }
        .log-data-key {
            color: var(--text-muted);
            font-weight: 500;
        }
        .log-data-value {
            color: var(--text-primary);
        }

        /* Errors Section */
        .log-errors-section {
            margin-top: 16px;
            border: 1px solid var(--error);
            border-radius: var(--radius-md);
            overflow: hidden;
        }
        .log-errors-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 12px 16px;
            background: var(--error-light);
            color: var(--error);
        }
        .log-errors-title {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 13px;
            font-weight: 600;
        }
        .log-errors-entries {
            padding: 12px;
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
        .log-error-entry {
            padding: 10px 12px;
            background: white;
            border-radius: var(--radius-sm);
            border-left: 3px solid var(--error);
        }
        <?php
    }
}
