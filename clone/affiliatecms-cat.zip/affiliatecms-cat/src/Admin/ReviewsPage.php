<?php
/**
 * Product Reviews Admin Page
 *
 * @package AffiliateCMS\Categories
 */

declare(strict_types=1);

namespace AffiliateCMS\Categories\Admin;

use AffiliateCMS\Categories\Repositories\ReviewRepository;

class ReviewsPage
{
    private ReviewRepository $repo;

    public function __construct()
    {
        $this->repo = new ReviewRepository();
    }

    /**
     * Enqueue admin assets
     */
    public function enqueueAssets(): void
    {
        // Bootstrap Icons
        wp_enqueue_style(
            'bootstrap-icons',
            'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css',
            [],
            '1.11.3'
        );

        // Alpine.js
        wp_enqueue_script(
            'alpinejs',
            'https://cdn.jsdelivr.net/npm/alpinejs@3.14.3/dist/cdn.min.js',
            [],
            '3.14.3',
            true
        );

        // Add defer attribute to Alpine.js
        add_filter('script_loader_tag', function($tag, $handle) {
            if ($handle === 'alpinejs') {
                return str_replace(' src', ' defer src', $tag);
            }
            return $tag;
        }, 10, 2);
    }

    /**
     * Render the page
     */
    public function render(): void
    {
        $this->enqueueAssets();

        $counts = $this->repo->getStatusCounts();
        ?>
        <style>
            <?php $this->renderStyles(); ?>
        </style>

        <script>
        window.acmsReviewsConfig = {
            restUrl: '<?php echo esc_js(rest_url('acms-cat/v1/')); ?>',
            nonce: '<?php echo esc_js(wp_create_nonce('wp_rest')); ?>',
            counts: <?php echo wp_json_encode($counts); ?>
        };
        </script>

        <div id="acms-reviews-app" class="acms-admin" x-data="reviewsPage()">
            <div class="app-container">
                <!-- Page Header -->
                <header class="page-header">
                    <div class="header-left">
                        <h1 class="page-title">
                            <i class="bi bi-chat-square-text"></i>
                            <?php esc_html_e('Product Reviews', 'affiliatecms-cat'); ?>
                        </h1>
                        <div class="stats-inline">
                            <div class="stat-item total" title="Total reviews">
                                <span class="stat-item-dot"></span>
                                <span class="stat-item-value" x-text="counts.all">0</span>
                                <span class="stat-item-label">Total</span>
                            </div>
                            <div class="stat-item pending" title="Pending reviews">
                                <span class="stat-item-dot"></span>
                                <span class="stat-item-value" x-text="counts.pending">0</span>
                                <span class="stat-item-label">Pending</span>
                            </div>
                            <div class="stat-item approved" title="Approved reviews">
                                <span class="stat-item-dot"></span>
                                <span class="stat-item-value" x-text="counts.approved">0</span>
                                <span class="stat-item-label">Approved</span>
                            </div>
                            <div class="stat-item spam" title="Spam reviews">
                                <span class="stat-item-dot"></span>
                                <span class="stat-item-value" x-text="counts.spam">0</span>
                                <span class="stat-item-label">Spam</span>
                            </div>
                        </div>
                    </div>
                </header>

                <!-- Filters & Tabs -->
                <div class="toolbar">
                    <div class="toolbar-tabs">
                        <button class="tab-btn" :class="{ active: filter.status === null }" @click="filter.status = null; loadReviews()">
                            <?php esc_html_e('All', 'affiliatecms-cat'); ?> (<span x-text="counts.all">0</span>)
                        </button>
                        <button class="tab-btn" :class="{ active: filter.status === 'pending' }" @click="filter.status = 'pending'; loadReviews()">
                            <?php esc_html_e('Pending', 'affiliatecms-cat'); ?> (<span x-text="counts.pending">0</span>)
                        </button>
                        <button class="tab-btn" :class="{ active: filter.status === 'approved' }" @click="filter.status = 'approved'; loadReviews()">
                            <?php esc_html_e('Approved', 'affiliatecms-cat'); ?> (<span x-text="counts.approved">0</span>)
                        </button>
                        <button class="tab-btn" :class="{ active: filter.status === 'spam' }" @click="filter.status = 'spam'; loadReviews()">
                            <?php esc_html_e('Spam', 'affiliatecms-cat'); ?> (<span x-text="counts.spam">0</span>)
                        </button>
                        <button class="tab-btn" :class="{ active: filter.status === 'trash' }" @click="filter.status = 'trash'; loadReviews()">
                            <?php esc_html_e('Trash', 'affiliatecms-cat'); ?> (<span x-text="counts.trash">0</span>)
                        </button>
                    </div>

                    <div class="toolbar-actions">
                        <input type="text" class="search-input" placeholder="<?php esc_attr_e('Search reviews...', 'affiliatecms-cat'); ?>" x-model="filter.search" @keyup.enter="loadReviews()">
                        <button class="btn btn-sm" @click="loadReviews()" :disabled="loading">
                            <i class="bi bi-search"></i>
                        </button>
                    </div>
                </div>

                <!-- Bulk Actions -->
                <div class="bulk-actions" x-show="selectedIds.length > 0">
                    <span x-text="selectedIds.length + ' selected'"></span>
                    <button class="btn btn-sm btn-success" @click="bulkAction('approve')">
                        <i class="bi bi-check-circle"></i> <?php esc_html_e('Approve', 'affiliatecms-cat'); ?>
                    </button>
                    <button class="btn btn-sm btn-warning" @click="bulkAction('spam')">
                        <i class="bi bi-exclamation-triangle"></i> <?php esc_html_e('Spam', 'affiliatecms-cat'); ?>
                    </button>
                    <button class="btn btn-sm btn-danger" @click="bulkAction('trash')">
                        <i class="bi bi-trash"></i> <?php esc_html_e('Trash', 'affiliatecms-cat'); ?>
                    </button>
                    <template x-if="filter.status === 'trash'">
                        <button class="btn btn-sm btn-danger" @click="bulkAction('delete')">
                            <i class="bi bi-x-circle"></i> <?php esc_html_e('Delete Permanently', 'affiliatecms-cat'); ?>
                        </button>
                    </template>
                </div>

                <!-- Reviews Table -->
                <div class="table-wrapper">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th class="col-check">
                                    <input type="checkbox" @change="toggleSelectAll($event.target.checked)" :checked="selectedIds.length === reviews.length && reviews.length > 0">
                                </th>
                                <th class="col-author"><?php esc_html_e('Author', 'affiliatecms-cat'); ?></th>
                                <th class="col-rating"><?php esc_html_e('Rating', 'affiliatecms-cat'); ?></th>
                                <th class="col-content"><?php esc_html_e('Review', 'affiliatecms-cat'); ?></th>
                                <th class="col-product"><?php esc_html_e('Product', 'affiliatecms-cat'); ?></th>
                                <th class="col-date"><?php esc_html_e('Date', 'affiliatecms-cat'); ?></th>
                                <th class="col-actions"><?php esc_html_e('Actions', 'affiliatecms-cat'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <template x-if="loading">
                                <tr>
                                    <td colspan="7" class="loading-cell">
                                        <i class="bi bi-arrow-repeat spin"></i> <?php esc_html_e('Loading...', 'affiliatecms-cat'); ?>
                                    </td>
                                </tr>
                            </template>
                            <template x-if="!loading && reviews.length === 0">
                                <tr>
                                    <td colspan="7" class="empty-cell">
                                        <i class="bi bi-inbox"></i>
                                        <span><?php esc_html_e('No reviews found.', 'affiliatecms-cat'); ?></span>
                                    </td>
                                </tr>
                            </template>
                            <template x-for="review in reviews" :key="review.id">
                                <tr :class="{ 'is-pending': review.status === 'pending' }">
                                    <td class="col-check">
                                        <input type="checkbox" :value="review.id" x-model="selectedIds">
                                    </td>
                                    <td class="col-author">
                                        <strong x-text="review.author_name"></strong>
                                        <br>
                                        <small x-text="review.author_email" class="text-muted"></small>
                                    </td>
                                    <td class="col-rating">
                                        <div class="stars">
                                            <template x-for="star in 5" :key="star">
                                                <i class="bi" :class="star <= review.rating ? 'bi-star-fill text-warning' : 'bi-star text-muted'"></i>
                                            </template>
                                        </div>
                                    </td>
                                    <td class="col-content">
                                        <div class="review-content" x-text="review.content.substring(0, 150) + (review.content.length > 150 ? '...' : '')"></div>
                                    </td>
                                    <td class="col-product">
                                        <code x-text="review.asin"></code>
                                    </td>
                                    <td class="col-date">
                                        <span x-text="formatDate(review.created_at)"></span>
                                    </td>
                                    <td class="col-actions">
                                        <div class="action-btns">
                                            <template x-if="review.status !== 'approved'">
                                                <button class="btn-icon btn-success" @click="updateStatus(review.id, 'approved')" title="<?php esc_attr_e('Approve', 'affiliatecms-cat'); ?>">
                                                    <i class="bi bi-check-circle"></i>
                                                </button>
                                            </template>
                                            <template x-if="review.status !== 'spam'">
                                                <button class="btn-icon btn-warning" @click="updateStatus(review.id, 'spam')" title="<?php esc_attr_e('Mark as Spam', 'affiliatecms-cat'); ?>">
                                                    <i class="bi bi-exclamation-triangle"></i>
                                                </button>
                                            </template>
                                            <template x-if="review.status !== 'trash'">
                                                <button class="btn-icon btn-danger" @click="updateStatus(review.id, 'trash')" title="<?php esc_attr_e('Trash', 'affiliatecms-cat'); ?>">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </template>
                                            <template x-if="review.status === 'trash'">
                                                <button class="btn-icon btn-danger" @click="deleteReview(review.id)" title="<?php esc_attr_e('Delete Permanently', 'affiliatecms-cat'); ?>">
                                                    <i class="bi bi-x-circle"></i>
                                                </button>
                                            </template>
                                        </div>
                                    </td>
                                </tr>
                            </template>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <div class="pagination" x-show="totalPages > 1">
                    <button class="btn btn-sm" @click="goToPage(currentPage - 1)" :disabled="currentPage <= 1">
                        <i class="bi bi-chevron-left"></i>
                    </button>
                    <span class="page-info">
                        <?php esc_html_e('Page', 'affiliatecms-cat'); ?> <span x-text="currentPage"></span> / <span x-text="totalPages"></span>
                    </span>
                    <button class="btn btn-sm" @click="goToPage(currentPage + 1)" :disabled="currentPage >= totalPages">
                        <i class="bi bi-chevron-right"></i>
                    </button>
                </div>
            </div>
        </div>

        <script>
        document.addEventListener('alpine:init', () => {
            Alpine.data('reviewsPage', () => ({
                reviews: [],
                counts: window.acmsReviewsConfig.counts,
                loading: false,
                selectedIds: [],
                filter: {
                    status: null,
                    search: ''
                },
                currentPage: 1,
                totalPages: 1,
                perPage: 20,

                init() {
                    this.loadReviews();
                },

                async loadReviews() {
                    this.loading = true;
                    this.selectedIds = [];

                    try {
                        const params = new URLSearchParams({
                            page: this.currentPage,
                            per_page: this.perPage
                        });

                        if (this.filter.status) {
                            params.append('status', this.filter.status);
                        }
                        if (this.filter.search) {
                            params.append('search', this.filter.search);
                        }

                        const response = await fetch(
                            window.acmsReviewsConfig.restUrl + 'reviews?' + params.toString(),
                            {
                                headers: {
                                    'X-WP-Nonce': window.acmsReviewsConfig.nonce
                                }
                            }
                        );

                        if (response.ok) {
                            const data = await response.json();
                            this.reviews = data.items || [];
                            this.totalPages = data.pages || 1;
                        }
                    } catch (error) {
                        console.error('Failed to load reviews:', error);
                    } finally {
                        this.loading = false;
                    }
                },

                async loadCounts() {
                    try {
                        const response = await fetch(
                            window.acmsReviewsConfig.restUrl + 'reviews/counts',
                            {
                                headers: {
                                    'X-WP-Nonce': window.acmsReviewsConfig.nonce
                                }
                            }
                        );

                        if (response.ok) {
                            this.counts = await response.json();
                        }
                    } catch (error) {
                        console.error('Failed to load counts:', error);
                    }
                },

                async updateStatus(id, status) {
                    try {
                        const response = await fetch(
                            window.acmsReviewsConfig.restUrl + 'reviews/' + id,
                            {
                                method: 'PUT',
                                headers: {
                                    'Content-Type': 'application/json',
                                    'X-WP-Nonce': window.acmsReviewsConfig.nonce
                                },
                                body: JSON.stringify({ status })
                            }
                        );

                        if (response.ok) {
                            this.loadReviews();
                            this.loadCounts();
                        }
                    } catch (error) {
                        console.error('Failed to update status:', error);
                    }
                },

                async deleteReview(id) {
                    if (!confirm('<?php echo esc_js(__('Are you sure you want to permanently delete this review?', 'affiliatecms-cat')); ?>')) {
                        return;
                    }

                    try {
                        const response = await fetch(
                            window.acmsReviewsConfig.restUrl + 'reviews/' + id,
                            {
                                method: 'DELETE',
                                headers: {
                                    'X-WP-Nonce': window.acmsReviewsConfig.nonce
                                }
                            }
                        );

                        if (response.ok) {
                            this.loadReviews();
                            this.loadCounts();
                        }
                    } catch (error) {
                        console.error('Failed to delete review:', error);
                    }
                },

                async bulkAction(action) {
                    if (this.selectedIds.length === 0) return;

                    if (action === 'delete' && !confirm('<?php echo esc_js(__('Are you sure you want to permanently delete the selected reviews?', 'affiliatecms-cat')); ?>')) {
                        return;
                    }

                    try {
                        const response = await fetch(
                            window.acmsReviewsConfig.restUrl + 'reviews/bulk',
                            {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json',
                                    'X-WP-Nonce': window.acmsReviewsConfig.nonce
                                },
                                body: JSON.stringify({
                                    action: action,
                                    ids: this.selectedIds
                                })
                            }
                        );

                        if (response.ok) {
                            this.selectedIds = [];
                            this.loadReviews();
                            this.loadCounts();
                        }
                    } catch (error) {
                        console.error('Failed to perform bulk action:', error);
                    }
                },

                toggleSelectAll(checked) {
                    if (checked) {
                        this.selectedIds = this.reviews.map(r => r.id);
                    } else {
                        this.selectedIds = [];
                    }
                },

                goToPage(page) {
                    if (page >= 1 && page <= this.totalPages) {
                        this.currentPage = page;
                        this.loadReviews();
                    }
                },

                formatDate(dateStr) {
                    if (!dateStr) return '';
                    const date = new Date(dateStr);
                    return date.toLocaleDateString('en-US', {
                        month: 'short',
                        day: 'numeric',
                        year: 'numeric'
                    });
                }
            }));
        });
        </script>
        <?php
    }

    /**
     * Render inline styles
     */
    private function renderStyles(): void
    {
        ?>
        .acms-admin {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            padding: 20px;
        }

        .app-container {
            max-width: 1400px;
            margin: 0 auto;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
            padding-bottom: 16px;
            border-bottom: 1px solid #e5e7eb;
        }

        .page-title {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 24px;
            font-weight: 600;
            color: #1e293b;
            margin: 0 0 12px;
        }

        .page-title i {
            color: #6366f1;
        }

        .stats-inline {
            display: flex;
            gap: 16px;
        }

        .stat-item {
            display: flex;
            align-items: center;
            gap: 6px;
            font-size: 13px;
            color: #64748b;
        }

        .stat-item-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: #e2e8f0;
        }

        .stat-item.total .stat-item-dot { background: #6366f1; }
        .stat-item.pending .stat-item-dot { background: #f59e0b; }
        .stat-item.approved .stat-item-dot { background: #22c55e; }
        .stat-item.spam .stat-item-dot { background: #ef4444; }

        .stat-item-value {
            font-weight: 600;
            color: #1e293b;
        }

        .toolbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 16px;
            gap: 16px;
            flex-wrap: wrap;
        }

        .toolbar-tabs {
            display: flex;
            gap: 4px;
        }

        .tab-btn {
            padding: 8px 16px;
            background: transparent;
            border: 1px solid #e2e8f0;
            border-radius: 6px;
            font-size: 13px;
            color: #64748b;
            cursor: pointer;
            transition: all 0.15s;
        }

        .tab-btn:hover {
            background: #f1f5f9;
        }

        .tab-btn.active {
            background: #6366f1;
            border-color: #6366f1;
            color: white;
        }

        .toolbar-actions {
            display: flex;
            gap: 8px;
        }

        .search-input {
            padding: 8px 12px;
            border: 1px solid #e2e8f0;
            border-radius: 6px;
            font-size: 13px;
            width: 200px;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 8px 16px;
            background: #6366f1;
            border: none;
            border-radius: 6px;
            font-size: 13px;
            font-weight: 500;
            color: white;
            cursor: pointer;
            transition: all 0.15s;
        }

        .btn:hover:not(:disabled) {
            background: #4f46e5;
        }

        .btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        .btn-sm {
            padding: 6px 12px;
            font-size: 12px;
        }

        .btn-success { background: #22c55e; }
        .btn-success:hover:not(:disabled) { background: #16a34a; }
        .btn-warning { background: #f59e0b; }
        .btn-warning:hover:not(:disabled) { background: #d97706; }
        .btn-danger { background: #ef4444; }
        .btn-danger:hover:not(:disabled) { background: #dc2626; }

        .bulk-actions {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 16px;
            background: #f8fafc;
            border-radius: 8px;
            margin-bottom: 16px;
        }

        .table-wrapper {
            background: white;
            border-radius: 8px;
            border: 1px solid #e2e8f0;
            overflow: hidden;
        }

        .data-table {
            width: 100%;
            border-collapse: collapse;
        }

        .data-table th,
        .data-table td {
            padding: 12px 16px;
            text-align: left;
            border-bottom: 1px solid #e2e8f0;
        }

        .data-table th {
            background: #f8fafc;
            font-size: 12px;
            font-weight: 600;
            color: #64748b;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .data-table td {
            font-size: 13px;
            color: #1e293b;
        }

        .data-table tr:hover td {
            background: #f8fafc;
        }

        .data-table tr.is-pending td {
            background: #fef3c7;
        }

        .col-check { width: 40px; }
        .col-rating { width: 100px; }
        .col-product { width: 120px; }
        .col-date { width: 120px; }
        .col-actions { width: 140px; }

        .review-content {
            max-width: 400px;
            line-height: 1.5;
        }

        .stars {
            display: flex;
            gap: 2px;
        }

        .stars i {
            font-size: 14px;
        }

        .text-warning { color: #f59e0b; }
        .text-muted { color: #94a3b8; }

        .action-btns {
            display: flex;
            gap: 4px;
        }

        .btn-icon {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 28px;
            height: 28px;
            background: transparent;
            border: 1px solid #e2e8f0;
            border-radius: 4px;
            color: #64748b;
            cursor: pointer;
            transition: all 0.15s;
        }

        .btn-icon:hover {
            background: #f1f5f9;
        }

        .btn-icon.btn-success:hover { background: #dcfce7; color: #22c55e; border-color: #22c55e; }
        .btn-icon.btn-warning:hover { background: #fef3c7; color: #f59e0b; border-color: #f59e0b; }
        .btn-icon.btn-danger:hover { background: #fee2e2; color: #ef4444; border-color: #ef4444; }

        .loading-cell,
        .empty-cell {
            text-align: center;
            padding: 40px !important;
            color: #94a3b8;
        }

        .empty-cell i,
        .loading-cell i {
            font-size: 32px;
            margin-bottom: 8px;
            display: block;
        }

        .pagination {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            margin-top: 16px;
        }

        .page-info {
            font-size: 13px;
            color: #64748b;
        }

        .spin {
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
        <?php
    }
}
