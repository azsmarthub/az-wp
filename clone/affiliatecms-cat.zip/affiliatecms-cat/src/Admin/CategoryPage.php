<?php
/**
 * AffiliateCMS Categories - Category Manager Page
 */

declare(strict_types=1);

namespace AffiliateCMS\Cat\Admin;

class CategoryPage
{
    /**
     * Render the category manager page
     */
    public function render(): void
    {
        ?>
        <div class="wrap acms-admin" x-data="{ activeTab: 'tree' }">
            <!-- Header -->
            <div class="acms-page-header">
                <div class="acms-page-header__title">
                    <h1><?php esc_html_e('Category Manager', 'affiliatecms-cat'); ?></h1>
                    <span class="acms-badge acms-badge--primary">v<?php echo esc_html(ACMS_CAT_VERSION); ?></span>
                </div>

                <div class="acms-page-header__tabs">
                    <button
                        class="acms-tab"
                        :class="{ 'is-active': activeTab === 'tree' }"
                        @click="activeTab = 'tree'"
                    >
                        <i class="bi bi-folder-tree"></i>
                        <?php esc_html_e('Categories', 'affiliatecms-cat'); ?>
                    </button>
                    <button
                        class="acms-tab"
                        :class="{ 'is-active': activeTab === 'queue' }"
                        @click="activeTab = 'queue'"
                    >
                        <i class="bi bi-list-task"></i>
                        <?php esc_html_e('Queue', 'affiliatecms-cat'); ?>
                    </button>
                </div>
            </div>

            <!-- Categories Tab -->
            <div x-show="activeTab === 'tree'" x-cloak>
                <?php $this->renderCategoryTree(); ?>
            </div>

            <!-- Queue Tab -->
            <div x-show="activeTab === 'queue'" x-cloak>
                <?php $this->renderQueue(); ?>
            </div>
        </div>
        <?php
    }

    /**
     * Render category tree section
     */
    private function renderCategoryTree(): void
    {
        ?>
        <div class="acms-cat-manager" x-data="categoryTree">
            <!-- Main Content -->
            <div class="acms-cat-manager__main">
                <!-- Category Card -->
                <div class="acms-card">
                    <!-- Toolbar -->
                    <div class="acms-toolbar">
                        <div class="acms-toolbar__group">
                            <button class="acms-btn acms-btn--secondary acms-btn--sm" @click="refresh()">
                                <i class="bi bi-arrow-clockwise"></i>
                                <?php esc_html_e('Refresh', 'affiliatecms-cat'); ?>
                            </button>
                        </div>

                        <div class="acms-toolbar__spacer"></div>

                        <div class="acms-search" style="width: 300px;">
                            <i class="bi bi-search acms-search__icon"></i>
                            <input
                                type="text"
                                class="acms-search__input"
                                placeholder="<?php esc_attr_e('Search categories...', 'affiliatecms-cat'); ?>"
                                x-model="searchQuery"
                                @input.debounce.300ms="search()"
                            >
                            <button
                                class="acms-search__clear"
                                :class="{ 'is-visible': searchQuery }"
                                @click="clearSearch()"
                            >
                                <i class="bi bi-x"></i>
                            </button>
                        </div>
                    </div>

                    <!-- Breadcrumb -->
                    <div class="acms-breadcrumb" x-show="breadcrumb.length > 0">
                        <button class="acms-breadcrumb__back" @click="navigateBack()" title="<?php esc_attr_e('Go back', 'affiliatecms-cat'); ?>">
                            <i class="bi bi-arrow-left"></i>
                        </button>

                        <button class="acms-breadcrumb__link" @click="navigateToRoot()">
                            <i class="bi bi-house"></i>
                        </button>

                        <template x-for="(crumb, index) in breadcrumb" :key="crumb.term_id">
                            <div class="acms-breadcrumb__item">
                                <i class="bi bi-chevron-right acms-breadcrumb__separator"></i>
                                <button
                                    class="acms-breadcrumb__link"
                                    :class="{ 'acms-breadcrumb__current': index === breadcrumb.length - 1 }"
                                    @click="navigateTo(crumb, index)"
                                    x-text="crumb.name"
                                ></button>
                            </div>
                        </template>
                    </div>

                    <!-- Category List -->
                    <div class="acms-card__body acms-card__body--flush">
                        <!-- Loading State -->
                        <div class="acms-loading" x-show="loading && categories.length === 0">
                            <i class="bi bi-arrow-clockwise acms-loading__spinner"></i>
                            <span><?php esc_html_e('Loading categories...', 'affiliatecms-cat'); ?></span>
                        </div>

                        <!-- Empty State -->
                        <div class="acms-empty" x-show="!loading && categories.length === 0">
                            <div class="acms-empty__icon">
                                <i class="bi bi-folder-x"></i>
                            </div>
                            <div class="acms-empty__title"><?php esc_html_e('No categories found', 'affiliatecms-cat'); ?></div>
                            <div class="acms-empty__text">
                                <span x-show="searchQuery"><?php esc_html_e('Try adjusting your search query', 'affiliatecms-cat'); ?></span>
                                <span x-show="!searchQuery"><?php esc_html_e('Categories will appear here once created', 'affiliatecms-cat'); ?></span>
                            </div>
                        </div>

                        <!-- Category Items -->
                        <div class="acms-cat-list" x-show="categories.length > 0">
                            <template x-for="cat in categories" :key="cat.term_id">
                                <div
                                    class="acms-cat-item"
                                    :class="{ 'is-selected': selectedCategory?.term_id === cat.term_id }"
                                    @click="selectCategory(cat)"
                                >
                                    <!-- Icon -->
                                    <div class="acms-cat-item__icon" :class="cat.child_count > 0 ? 'acms-cat-item__icon--folder' : 'acms-cat-item__icon--file'">
                                        <i class="bi" :class="cat.child_count > 0 ? 'bi-folder-fill' : 'bi-file-earmark'"></i>
                                    </div>

                                    <!-- Info -->
                                    <div class="acms-cat-item__info">
                                        <div class="acms-cat-item__name" x-text="cat.name"></div>
                                        <div class="acms-cat-item__path" x-text="cat.amazon_category_path || cat.slug" x-show="cat.amazon_category_path || cat.slug"></div>
                                    </div>

                                    <!-- Stats -->
                                    <div class="acms-cat-item__stats">
                                        <div class="acms-cat-item__stat" x-show="cat.product_count > 0">
                                            <i class="bi bi-box-seam"></i>
                                            <span x-text="cat.product_count"></span>
                                        </div>
                                        <div class="acms-cat-item__stat" x-show="cat.child_count > 0">
                                            <i class="bi bi-folder"></i>
                                            <span x-text="cat.child_count"></span>
                                        </div>
                                    </div>

                                    <!-- Actions -->
                                    <div class="acms-cat-item__actions">
                                        <button
                                            class="acms-btn acms-btn--ghost acms-btn--sm"
                                            @click.stop="navigateInto(cat)"
                                            x-show="cat.child_count > 0"
                                            title="<?php esc_attr_e('View subcategories', 'affiliatecms-cat'); ?>"
                                        >
                                            <i class="bi bi-arrow-right"></i>
                                        </button>
                                    </div>
                                </div>
                            </template>
                        </div>

                        <!-- Load More -->
                        <div class="acms-load-more" x-show="hasMore && !loading">
                            <button class="acms-load-more__btn" @click="loadMore()">
                                <i class="bi bi-plus-circle"></i>
                                <?php esc_html_e('Load More', 'affiliatecms-cat'); ?>
                            </button>
                        </div>

                        <!-- Infinite scroll sentinel -->
                        <div class="acms-scroll-sentinel" x-intersect="loadMore()"></div>
                    </div>

                    <!-- Footer -->
                    <div class="acms-card__footer">
                        <span class="text-muted">
                            <?php esc_html_e('Showing', 'affiliatecms-cat'); ?>
                            <strong x-text="categories.length"></strong>
                            <?php esc_html_e('of', 'affiliatecms-cat'); ?>
                            <strong x-text="totalItems"></strong>
                            <?php esc_html_e('categories', 'affiliatecms-cat'); ?>
                        </span>
                    </div>
                </div>
            </div>

            <!-- Sidebar -->
            <div class="acms-cat-manager__sidebar">
                <!-- Stats Card -->
                <div class="acms-card" x-data="categoryStats">
                    <div class="acms-card__header">
                        <h3 class="acms-card__title">
                            <i class="bi bi-bar-chart"></i>
                            <?php esc_html_e('Overview', 'affiliatecms-cat'); ?>
                        </h3>
                    </div>
                    <div class="acms-card__body">
                        <div class="acms-stats">
                            <div class="acms-stat acms-stat--primary">
                                <div class="acms-stat__value" x-text="stats.totalCategories">0</div>
                                <div class="acms-stat__label"><?php esc_html_e('Categories', 'affiliatecms-cat'); ?></div>
                            </div>
                            <div class="acms-stat acms-stat--success">
                                <div class="acms-stat__value" x-text="stats.totalProducts">0</div>
                                <div class="acms-stat__label"><?php esc_html_e('Products', 'affiliatecms-cat'); ?></div>
                            </div>
                            <div class="acms-stat">
                                <div class="acms-stat__value" x-text="stats.queuePending">0</div>
                                <div class="acms-stat__label"><?php esc_html_e('Pending', 'affiliatecms-cat'); ?></div>
                            </div>
                            <div class="acms-stat">
                                <div class="acms-stat__value" x-text="stats.queueFailed">0</div>
                                <div class="acms-stat__label"><?php esc_html_e('Failed', 'affiliatecms-cat'); ?></div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Selected Category Detail -->
                <div class="acms-card" x-show="selectedCategory" x-data="categoryDetail" x-effect="if (selectedCategory) loadDetails(selectedCategory.term_id)">
                    <div class="acms-card__header">
                        <h3 class="acms-card__title">
                            <i class="bi bi-info-circle"></i>
                            <?php esc_html_e('Category Details', 'affiliatecms-cat'); ?>
                        </h3>
                        <div class="acms-card__actions">
                            <button
                                class="acms-btn acms-btn--ghost acms-btn--sm"
                                @click="editing = !editing"
                                x-show="!editing"
                            >
                                <i class="bi bi-pencil"></i>
                            </button>
                        </div>
                    </div>
                    <div class="acms-card__body">
                        <div class="acms-detail">
                            <!-- Header -->
                            <div class="acms-detail__header">
                                <div class="acms-detail__icon">
                                    <i class="bi bi-folder-fill"></i>
                                </div>
                                <div class="acms-detail__info">
                                    <div class="acms-detail__name" x-text="selectedCategory?.name"></div>
                                    <div class="acms-detail__path" x-text="selectedCategory?.slug"></div>
                                </div>
                            </div>

                            <!-- View Mode -->
                            <template x-if="!editing">
                                <div class="acms-detail__section">
                                    <div class="acms-detail__meta">
                                        <div class="acms-detail__meta-item">
                                            <div class="acms-detail__meta-value" x-text="category?.product_count || 0"></div>
                                            <div class="acms-detail__meta-label"><?php esc_html_e('Products', 'affiliatecms-cat'); ?></div>
                                        </div>
                                        <div class="acms-detail__meta-item">
                                            <div class="acms-detail__meta-value" x-text="category?.child_count || 0"></div>
                                            <div class="acms-detail__meta-label"><?php esc_html_e('Subcategories', 'affiliatecms-cat'); ?></div>
                                        </div>
                                    </div>
                                </div>
                            </template>

                            <!-- Edit Mode -->
                            <template x-if="editing">
                                <form @submit.prevent="save()">
                                    <div class="acms-form-group" style="margin-bottom: 12px;">
                                        <label class="acms-form-label"><?php esc_html_e('Name', 'affiliatecms-cat'); ?></label>
                                        <input type="text" x-model="formData.name" class="regular-text">
                                    </div>
                                    <div class="acms-form-group" style="margin-bottom: 12px;">
                                        <label class="acms-form-label"><?php esc_html_e('Slug', 'affiliatecms-cat'); ?></label>
                                        <input type="text" x-model="formData.slug" class="regular-text">
                                    </div>
                                    <div class="acms-form-group" style="margin-bottom: 12px;">
                                        <label class="acms-form-label"><?php esc_html_e('SEO Title', 'affiliatecms-cat'); ?></label>
                                        <input type="text" x-model="formData.seo_title" class="regular-text">
                                    </div>
                                    <div class="acms-form-group" style="margin-bottom: 16px;">
                                        <label class="acms-form-label"><?php esc_html_e('SEO Description', 'affiliatecms-cat'); ?></label>
                                        <textarea x-model="formData.seo_description" rows="3" class="large-text"></textarea>
                                    </div>
                                    <div style="display: flex; gap: 8px;">
                                        <button type="submit" class="acms-btn acms-btn--primary acms-btn--sm" :disabled="loading">
                                            <i class="bi bi-check"></i>
                                            <?php esc_html_e('Save', 'affiliatecms-cat'); ?>
                                        </button>
                                        <button type="button" class="acms-btn acms-btn--secondary acms-btn--sm" @click="cancelEdit()">
                                            <?php esc_html_e('Cancel', 'affiliatecms-cat'); ?>
                                        </button>
                                    </div>
                                </form>
                            </template>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Render queue section
     */
    private function renderQueue(): void
    {
        ?>
        <div class="acms-card" x-data="queueManager">
            <div class="acms-card__header">
                <h3 class="acms-card__title">
                    <i class="bi bi-list-task"></i>
                    <?php esc_html_e('Category Queue', 'affiliatecms-cat'); ?>
                </h3>
                <div class="acms-card__actions">
                    <button class="acms-btn acms-btn--primary acms-btn--sm" @click="showAddDialog = true">
                        <i class="bi bi-plus-lg"></i>
                        <?php esc_html_e('Add Keyword', 'affiliatecms-cat'); ?>
                    </button>
                </div>
            </div>

            <!-- Filters -->
            <div class="acms-toolbar">
                <div class="acms-toolbar__group">
                    <button
                        class="acms-btn acms-btn--sm"
                        :class="statusFilter === '' ? 'acms-btn--primary' : 'acms-btn--secondary'"
                        @click="filterByStatus('')"
                    >
                        <?php esc_html_e('All', 'affiliatecms-cat'); ?>
                    </button>
                    <button
                        class="acms-btn acms-btn--sm"
                        :class="statusFilter === 'pending' ? 'acms-btn--primary' : 'acms-btn--secondary'"
                        @click="filterByStatus('pending')"
                    >
                        <?php esc_html_e('Pending', 'affiliatecms-cat'); ?>
                    </button>
                    <button
                        class="acms-btn acms-btn--sm"
                        :class="statusFilter === 'processing' ? 'acms-btn--primary' : 'acms-btn--secondary'"
                        @click="filterByStatus('processing')"
                    >
                        <?php esc_html_e('Processing', 'affiliatecms-cat'); ?>
                    </button>
                    <button
                        class="acms-btn acms-btn--sm"
                        :class="statusFilter === 'failed' ? 'acms-btn--primary' : 'acms-btn--secondary'"
                        @click="filterByStatus('failed')"
                    >
                        <?php esc_html_e('Failed', 'affiliatecms-cat'); ?>
                    </button>
                </div>
            </div>

            <div class="acms-card__body acms-card__body--flush">
                <!-- Loading State -->
                <div class="acms-loading" x-show="loading && items.length === 0">
                    <i class="bi bi-arrow-clockwise acms-loading__spinner"></i>
                    <span><?php esc_html_e('Loading queue...', 'affiliatecms-cat'); ?></span>
                </div>

                <!-- Empty State -->
                <div class="acms-empty" x-show="!loading && items.length === 0">
                    <div class="acms-empty__icon">
                        <i class="bi bi-inbox"></i>
                    </div>
                    <div class="acms-empty__title"><?php esc_html_e('Queue is empty', 'affiliatecms-cat'); ?></div>
                    <div class="acms-empty__text"><?php esc_html_e('Add keywords to start processing categories', 'affiliatecms-cat'); ?></div>
                </div>

                <!-- Queue Table -->
                <table class="acms-queue-table" x-show="items.length > 0">
                    <thead>
                        <tr>
                            <th><?php esc_html_e('Keyword', 'affiliatecms-cat'); ?></th>
                            <th><?php esc_html_e('Status', 'affiliatecms-cat'); ?></th>
                            <th><?php esc_html_e('Categories', 'affiliatecms-cat'); ?></th>
                            <th><?php esc_html_e('Created', 'affiliatecms-cat'); ?></th>
                            <th style="width: 100px;"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <template x-for="item in items" :key="item.id">
                            <tr>
                                <td x-text="item.keyword"></td>
                                <td>
                                    <span class="acms-badge" :class="getStatusClass(item.status)" x-text="item.status"></span>
                                </td>
                                <td x-text="item.categories_found || '-'"></td>
                                <td x-text="item.created_at"></td>
                                <td>
                                    <div style="display: flex; gap: 4px;">
                                        <button
                                            class="acms-btn acms-btn--ghost acms-btn--sm acms-btn--icon"
                                            @click="retryItem(item.id)"
                                            x-show="item.status === 'failed'"
                                            title="<?php esc_attr_e('Retry', 'affiliatecms-cat'); ?>"
                                        >
                                            <i class="bi bi-arrow-clockwise"></i>
                                        </button>
                                        <button
                                            class="acms-btn acms-btn--ghost acms-btn--sm acms-btn--icon"
                                            @click="deleteItem(item.id)"
                                            title="<?php esc_attr_e('Delete', 'affiliatecms-cat'); ?>"
                                        >
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        </template>
                    </tbody>
                </table>
            </div>

            <!-- Add Keyword Dialog -->
            <div
                class="acms-modal-backdrop"
                :class="{ 'is-open': showAddDialog }"
                @click.self="showAddDialog = false"
            >
                <div class="acms-modal" @click.stop>
                    <div class="acms-modal__header">
                        <h3 class="acms-modal__title"><?php esc_html_e('Add Keyword', 'affiliatecms-cat'); ?></h3>
                        <button class="acms-modal__close" @click="showAddDialog = false">
                            <i class="bi bi-x"></i>
                        </button>
                    </div>
                    <div class="acms-modal__body">
                        <form @submit.prevent="addKeyword()">
                            <div class="acms-form-group">
                                <label class="acms-form-label"><?php esc_html_e('Keyword', 'affiliatecms-cat'); ?></label>
                                <input
                                    type="text"
                                    x-model="newKeyword"
                                    placeholder="<?php esc_attr_e('e.g., wireless headphones', 'affiliatecms-cat'); ?>"
                                    class="regular-text"
                                    required
                                >
                                <p class="acms-form-hint"><?php esc_html_e('Enter a product keyword to find and create categories', 'affiliatecms-cat'); ?></p>
                            </div>
                        </form>
                    </div>
                    <div class="acms-modal__footer">
                        <button class="acms-btn acms-btn--secondary" @click="showAddDialog = false">
                            <?php esc_html_e('Cancel', 'affiliatecms-cat'); ?>
                        </button>
                        <button class="acms-btn acms-btn--primary" @click="addKeyword()" :disabled="addLoading || !newKeyword.trim()">
                            <i class="bi bi-plus-lg"></i>
                            <?php esc_html_e('Add to Queue', 'affiliatecms-cat'); ?>
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
}
