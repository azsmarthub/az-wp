<?php
/**
 * SEO Categories Admin Page
 *
 * @package AffiliateCMS\Categories
 */

declare(strict_types=1);

namespace AffiliateCMS\Categories\Admin;

use AffiliateCMS\Categories\Repositories\CategoryRepository;

class CategoriesPage
{
    private CategoryRepository $repo;

    public function __construct(CategoryRepository $repo)
    {
        $this->repo = $repo;
    }

    /**
     * Enqueue admin assets
     */
    public function enqueueAssets(): void
    {
        // Bootstrap Icons
        wp_enqueue_style(
            'bootstrap-icons',
            'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css',
            [],
            '1.11.3'
        );

        // Alpine.js
        wp_enqueue_script(
            'alpinejs',
            'https://cdn.jsdelivr.net/npm/alpinejs@3.14.3/dist/cdn.min.js',
            [],
            '3.14.3',
            true
        );

        // Add defer attribute to Alpine.js
        add_filter('script_loader_tag', function($tag, $handle) {
            if ($handle === 'alpinejs') {
                return str_replace(' src', ' defer src', $tag);
            }
            return $tag;
        }, 10, 2);
    }

    /**
     * Render the page
     */
    public function render(): void
    {
        $this->enqueueAssets();

        // Get stats
        global $wpdb;
        $tables = \AffiliateCMS\Categories\Database\Schema::tables();
        $totalCategories = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$tables['categories']}");
        $totalProducts = (int) $wpdb->get_var("SELECT COUNT(DISTINCT product_id) FROM {$tables['category_products']}");
        $rootCategories = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$tables['categories']} WHERE parent_id = 0");

        ?>
        <style>
            <?php $this->renderStyles(); ?>
        </style>

        <script>
        window.acmsCatConfig = {
            restUrl: '<?php echo esc_js(rest_url('acms-cat/v1/')); ?>',
            nonce: '<?php echo esc_js(wp_create_nonce('wp_rest')); ?>',
            stats: {
                total: <?php echo $totalCategories; ?>,
                products: <?php echo $totalProducts; ?>,
                root: <?php echo $rootCategories; ?>
            }
        };
        </script>

        <div id="acms-cat-app" class="acms-admin" x-data="categoriesPage()">
            <div class="app-container">
                <!-- Page Header with Stats -->
                <header class="page-header">
                    <div class="header-left">
                        <div class="stats-inline">
                            <div class="stat-item" title="Total categories">
                                <span class="stat-item-dot total"></span>
                                <span class="stat-item-value" x-text="stats.total">0</span>
                                <span class="stat-item-label">Categories</span>
                            </div>
                            <div class="stat-item" title="Root categories">
                                <span class="stat-item-dot root"></span>
                                <span class="stat-item-value" x-text="stats.root">0</span>
                                <span class="stat-item-label">Root</span>
                            </div>
                            <div class="stat-item" title="Linked products">
                                <span class="stat-item-dot products"></span>
                                <span class="stat-item-value" x-text="stats.products">0</span>
                                <span class="stat-item-label">Products</span>
                            </div>
                        </div>
                    </div>

                    <div class="header-actions">
                        <!-- Search Box -->
                        <div class="search-box">
                            <i class="bi bi-search search-icon"></i>
                            <input type="search" class="search-input" placeholder="Search categories..."
                                   x-model="searchQuery" @input.debounce.300ms="searchCategories()">
                            <button type="button" class="search-clear" x-show="searchQuery" x-cloak @click="searchQuery = ''; searchCategories()">
                                <i class="bi bi-x-lg"></i>
                            </button>
                        </div>

                        <!-- Refresh -->
                        <button class="btn-icon" :class="{ 'refresh-success': refreshSuccess }" @click="loadCategories()" title="Refresh">
                            <i class="bi" :class="{ 'bi-arrow-clockwise': !refreshSuccess, 'animate-spin': isLoading, 'bi-check-lg': refreshSuccess }"></i>
                        </button>

                        <!-- Rebuild Directory Cache -->
                        <button class="btn-icon" :class="{ 'refresh-success': cacheRebuildSuccess }" @click="rebuildDirectoryCache()" :disabled="isCacheRebuilding" title="Rebuild /categories/ page cache">
                            <i class="bi" :class="{ 'bi-database-gear': !isCacheRebuilding && !cacheRebuildSuccess, 'animate-spin bi-arrow-clockwise': isCacheRebuilding, 'bi-check-lg': cacheRebuildSuccess }"></i>
                        </button>

                        <a href="<?php echo esc_url(admin_url('admin.php?page=acms-cat-queue')); ?>" class="btn-icon" title="Category Queue">
                            <i class="bi bi-collection"></i>
                        </a>
                        <div class="header-divider"></div>
                        <button class="btn btn-primary" @click="openAddModal()">
                            <i class="bi bi-plus-lg"></i>
                            Add Category
                        </button>
                    </div>
                </header>

                <!-- Data Table -->
                <div class="data-table-wrapper">
                    <!-- Loading State -->
                    <div class="data-table-loading" x-show="isLoading" x-cloak>
                        <div class="spinner"></div>
                        <span>Loading categories...</span>
                    </div>

                    <!-- Empty State -->
                    <div class="data-table-empty" x-show="!isLoading && currentCategories.length === 0" x-cloak>
                        <i class="bi bi-folder2-open"></i>
                        <span x-text="searchQuery ? 'No categories found matching your search' : 'No categories in this level'"></span>
                        <small>Click "Add Category" to create a new category</small>
                    </div>

                    <!-- Bulk Actions Bar -->
                    <div class="bulk-actions-bar" x-show="hasSelection" x-cloak x-transition>
                        <div class="bulk-actions-left">
                            <span class="selected-count">
                                <i class="bi bi-check2-square"></i>
                                <span><span x-text="selectedIds.length"></span> selected</span>
                            </span>
                            <button type="button" class="btn-link" @click="clearSelection()">Clear</button>
                        </div>
                        <div class="bulk-actions-right">
                            <!-- Custom Dropdown -->
                            <div class="custom-dropdown" @click.away="dropdownOpen = false">
                                <button type="button" class="dropdown-trigger" @click="dropdownOpen = !dropdownOpen">
                                    <span x-text="bulkAction ? bulkActionLabels[bulkAction] : 'Bulk Actions'"></span>
                                    <i class="bi bi-chevron-down"></i>
                                </button>
                                <div class="dropdown-menu" x-show="dropdownOpen" x-cloak x-transition>
                                    <button type="button" class="dropdown-item" :class="{ 'active': bulkAction === 'delete' }" @click="bulkAction = 'delete'; dropdownOpen = false">
                                        <i class="bi bi-trash"></i>
                                        <span>Delete</span>
                                    </button>
                                    <div class="dropdown-divider"></div>
                                    <button type="button" class="dropdown-item" :class="{ 'active': bulkAction === 'generate_ai' }" @click="bulkAction = 'generate_ai'; dropdownOpen = false">
                                        <i class="bi bi-robot"></i>
                                        <span>Generate AI Content</span>
                                    </button>
                                    <button type="button" class="dropdown-item" :class="{ 'active': bulkAction === 'regenerate_ai' }" @click="bulkAction = 'regenerate_ai'; dropdownOpen = false">
                                        <i class="bi bi-arrow-repeat"></i>
                                        <span>Regenerate AI Content</span>
                                    </button>
                                </div>
                            </div>
                            <button type="button" class="btn btn-sm btn-primary" @click="handleBulkApply()" :disabled="!bulkAction || isBulkProcessing">
                                <i class="bi bi-play-fill" x-show="!isBulkProcessing"></i>
                                <i class="bi bi-arrow-repeat animate-spin" x-show="isBulkProcessing"></i>
                                Apply
                            </button>
                        </div>
                    </div>

                    <!-- Delete Confirmation Modal -->
                    <div class="modal-overlay" x-show="showDeleteModal" x-cloak @click.self="showDeleteModal = false" x-transition.opacity>
                        <div class="modal-dialog" x-show="showDeleteModal" x-transition>
                            <div class="modal-header">
                                <h3>
                                    <i class="bi bi-exclamation-triangle" style="color: var(--error);"></i>
                                    <span x-text="deleteTargets.length > 1 ? 'Delete ' + deleteTargets.length + ' Categories' : 'Delete Category'"></span>
                                </h3>
                                <button type="button" class="modal-close" @click="showDeleteModal = false">
                                    <i class="bi bi-x-lg"></i>
                                </button>
                            </div>
                            <div class="modal-body">
                                <p class="modal-warning">
                                    <i class="bi bi-exclamation-circle"></i>
                                    <span x-text="deleteTargets.length > 1 ? `You are about to delete ${deleteTargets.length} categories. This action cannot be undone.` : `You are about to delete &quot;${deleteTargetName}&quot;. This action cannot be undone.`"></span>
                                </p>

                                <!-- Children Handling (shown when target has children) -->
                                <template x-if="deleteTargetHasChildren">
                                    <div class="delete-section">
                                        <div class="delete-section-label">
                                            <i class="bi bi-diagram-3"></i>
                                            <span x-text="'Child Categories (' + deleteTargetChildCount + ')'"></span>
                                        </div>
                                        <div class="delete-options">
                                            <label class="delete-option" :class="{ 'selected': childrenMode === 'reassign' }">
                                                <input type="radio" name="children_mode" value="reassign" x-model="childrenMode">
                                                <div class="option-content">
                                                    <div class="option-title">
                                                        <i class="bi bi-arrow-up-circle"></i>
                                                        Move to Parent
                                                    </div>
                                                    <div class="option-desc">Child categories will be moved up to the parent level. Their products and content are preserved.</div>
                                                </div>
                                            </label>
                                            <label class="delete-option" :class="{ 'selected': childrenMode === 'delete' }">
                                                <input type="radio" name="children_mode" value="delete" x-model="childrenMode">
                                                <div class="option-content">
                                                    <div class="option-title">
                                                        <i class="bi bi-trash3"></i>
                                                        Delete All Children
                                                    </div>
                                                    <div class="option-desc">All child categories (and their descendants) will be permanently deleted.</div>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </template>

                                <!-- Product Handling -->
                                <div class="delete-section">
                                    <div class="delete-section-label">
                                        <i class="bi bi-box-seam"></i>
                                        Product Data
                                    </div>
                                    <div class="delete-options">
                                        <label class="delete-option" :class="{ 'selected': deleteMode === 'category_only' }">
                                            <input type="radio" name="delete_mode" value="category_only" x-model="deleteMode">
                                            <div class="option-content">
                                                <div class="option-title">
                                                    <i class="bi bi-folder-x"></i>
                                                    Keep Products
                                                </div>
                                                <div class="option-desc">Remove category links only. Products remain in database.</div>
                                            </div>
                                        </label>
                                        <label class="delete-option" :class="{ 'selected': deleteMode === 'full_data' }">
                                            <input type="radio" name="delete_mode" value="full_data" x-model="deleteMode">
                                            <div class="option-content">
                                                <div class="option-title">
                                                    <i class="bi bi-trash3"></i>
                                                    Delete Orphaned Products
                                                </div>
                                                <div class="option-desc">Also delete products only linked to deleted categories. Products in other categories are kept.</div>
                                            </div>
                                        </label>
                                    </div>
                                </div>

                                <div class="delete-warning-box" x-show="deleteMode === 'full_data' || childrenMode === 'delete'" x-cloak>
                                    <i class="bi bi-exclamation-triangle-fill"></i>
                                    <span x-text="deleteMode === 'full_data' && childrenMode === 'delete'
                                        ? 'Warning: This will permanently delete all child categories AND orphaned products!'
                                        : (childrenMode === 'delete'
                                            ? 'Warning: All child categories and their descendants will be permanently deleted!'
                                            : 'Warning: Orphaned product data will be permanently deleted!')"></span>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" @click="showDeleteModal = false">Cancel</button>
                                <button type="button" class="btn btn-danger" @click="executeDelete()" :disabled="isDeleting">
                                    <i class="bi bi-trash" x-show="!isDeleting"></i>
                                    <i class="bi bi-arrow-repeat animate-spin" x-show="isDeleting"></i>
                                    <span x-text="isDeleting ? 'Deleting...' : 'Confirm Delete'"></span>
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- AI Generation Options Modal -->
                    <div class="modal-overlay" x-show="showAiModal" x-cloak @click.self="showAiModal = false" x-transition.opacity>
                        <div class="modal-dialog" x-show="showAiModal" x-transition>
                            <div class="modal-header">
                                <h3 x-text="bulkAction === 'generate_ai' ? 'Generate AI Content' : 'Regenerate AI Content'"></h3>
                                <button type="button" class="modal-close" @click="showAiModal = false">
                                    <i class="bi bi-x-lg"></i>
                                </button>
                            </div>
                            <div class="modal-body">
                                <p class="modal-info">
                                    <i class="bi bi-info-circle"></i>
                                    <span x-text="bulkAction === 'generate_ai'
                                        ? `Generate AI content for ${selectedIds.length} selected categories.`
                                        : `Regenerate AI content for ${selectedIds.length} selected categories. Existing content will be replaced.`"></span>
                                </p>

                                <div class="modal-option">
                                    <label class="option-checkbox">
                                        <input type="checkbox" x-model="includeChildren">
                                        <span class="checkmark"></span>
                                        <span class="option-label">Include children categories</span>
                                    </label>
                                    <p class="option-desc">Also generate content for all sub-categories of selected items</p>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" @click="showAiModal = false">Cancel</button>
                                <button type="button" class="btn btn-primary" @click="executeAiBulkAction()" :disabled="isBulkProcessing">
                                    <i class="bi bi-robot" x-show="!isBulkProcessing"></i>
                                    <i class="bi bi-arrow-repeat animate-spin" x-show="isBulkProcessing"></i>
                                    <span x-text="isBulkProcessing ? 'Processing...' : (bulkAction === 'generate_ai' ? 'Generate' : 'Regenerate')"></span>
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Breadcrumb Navigation (always visible when not at root) -->
                    <div class="breadcrumb-bar" x-show="currentParentId !== 0 && !isLoading" x-cloak>
                        <div class="breadcrumb">
                            <button type="button" class="breadcrumb-up" @click="goUp()" title="Go up one level">
                                <i class="bi bi-arrow-up"></i>
                            </button>
                            <a href="#" @click.prevent="navigateTo(0)" class="breadcrumb-item">
                                <i class="bi bi-house-door"></i>
                                Root
                            </a>
                            <template x-for="(crumb, index) in breadcrumb" :key="crumb.id">
                                <span class="breadcrumb-separator">
                                    <i class="bi bi-chevron-right"></i>
                                    <a href="#" @click.prevent="navigateTo(parseInt(crumb.id))" class="breadcrumb-item" :class="{ 'active': index === breadcrumb.length - 1 }" x-text="crumb.name"></a>
                                </span>
                            </template>
                            <span class="breadcrumb-depth" x-show="breadcrumb.length > 0" x-cloak>
                                Level <span x-text="breadcrumb.length"></span>
                            </span>
                        </div>
                    </div>

                    <!-- Empty State (when navigated to a level with no children) -->
                    <div class="empty-level" x-show="!isLoading && currentCategories.length === 0 && currentParentId !== 0 && !searchQuery" x-cloak>
                        <div class="empty-level-content">
                            <i class="bi bi-folder2-open"></i>
                            <p>No child categories at this level</p>
                            <div class="empty-level-actions">
                                <button type="button" class="btn btn-secondary btn-sm" @click="goUp()">
                                    <i class="bi bi-arrow-up"></i> Go Back
                                </button>
                                <button type="button" class="btn btn-primary btn-sm" @click="addForm.parentId = currentParentId; showAddModal = true">
                                    <i class="bi bi-plus-lg"></i> Add Child Category
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Table -->
                    <div class="data-table-container" x-show="!isLoading && currentCategories.length > 0">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th class="col-checkbox">
                                        <label class="checkbox-wrapper">
                                            <input type="checkbox" :checked="isAllSelected" @change="toggleSelectAll()">
                                            <span class="checkbox-custom"></span>
                                        </label>
                                    </th>
                                    <th class="col-name">Name</th>
                                    <th class="col-slug">Slug</th>
                                    <th class="col-ai">AI</th>
                                    <th class="col-children">Children</th>
                                    <th class="col-products">Products</th>
                                    <th class="col-depth">Depth</th>
                                    <th class="col-actions">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <template x-for="cat in currentCategories" :key="cat.id">
                                    <tr :class="{ 'row-selected': selectedIds.includes(parseInt(cat.id)) }">
                                        <td class="col-checkbox">
                                            <label class="checkbox-wrapper">
                                                <input type="checkbox" :checked="selectedIds.includes(parseInt(cat.id))" @change="toggleSelect(parseInt(cat.id))">
                                                <span class="checkbox-custom"></span>
                                            </label>
                                        </td>
                                        <td class="col-name">
                                            <div class="category-name-cell">
                                                <template x-if="parseInt(cat.child_count || 0) > 0">
                                                    <a href="#" @click.prevent="navigateTo(parseInt(cat.id))" class="category-name-link">
                                                        <i class="bi bi-folder-fill folder-icon"></i>
                                                        <span x-text="cat.name"></span>
                                                        <i class="bi bi-chevron-right nav-arrow"></i>
                                                    </a>
                                                </template>
                                                <template x-if="parseInt(cat.child_count || 0) === 0">
                                                    <span class="category-name-leaf">
                                                        <i class="bi bi-folder folder-icon"></i>
                                                        <span x-text="cat.name"></span>
                                                    </span>
                                                </template>
                                            </div>
                                        </td>
                                        <td class="col-slug">
                                            <code class="slug-code" x-text="cat.slug"></code>
                                        </td>
                                        <td class="col-ai">
                                            <span class="badge badge-sm"
                                                  :class="'badge-' + getAiStatusColor(cat.content_status)"
                                                  :title="getAiStatusTitle(cat)">
                                                <i class="bi" :class="getAiStatusIcon(cat.content_status)" style="font-size: 11px;"></i>
                                                <span x-text="getAiStatusLabel(cat.content_status)" style="font-size: 11px;"></span>
                                            </span>
                                        </td>
                                        <td class="col-children" x-text="cat.child_count || 0"></td>
                                        <td class="col-products" x-text="cat.product_count || 0"></td>
                                        <td class="col-depth">
                                            <span class="depth-badge" :data-depth="parseInt(cat.depth || 0)" x-text="'L' + cat.depth"></span>
                                        </td>
                                        <td class="col-actions">
                                            <div class="actions-cell">
                                                <a :href="'<?php echo esc_js(admin_url('admin.php?page=acms-categories&action=edit&id=')); ?>' + cat.id" class="btn-icon btn-icon-sm" title="Edit">
                                                    <i class="bi bi-pencil"></i>
                                                </a>
                                                <a :href="'/c/' + cat.slug + '/'" target="_blank" class="btn-icon btn-icon-sm" title="View">
                                                    <i class="bi bi-eye"></i>
                                                </a>
                                                <button class="btn-icon btn-icon-sm" title="Add Child" @click="openAddModal(cat)">
                                                    <i class="bi bi-plus"></i>
                                                </button>
                                                <button class="btn-icon btn-icon-sm btn-danger" title="Delete" @click="deleteCategory(cat)">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                </template>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Add Category Modal -->
            <div class="modal-backdrop" x-show="showAddModal" x-cloak
                 x-transition:enter="transition ease-out duration-200"
                 x-transition:enter-start="opacity-0"
                 x-transition:enter-end="opacity-100"
                 x-transition:leave="transition ease-in duration-150"
                 x-transition:leave-start="opacity-100"
                 x-transition:leave-end="opacity-0"
                 @keydown.escape.window="showAddModal = false">

                <div class="modal modal-md"
                     x-transition:enter="transition ease-out duration-200"
                     x-transition:enter-start="opacity-0 transform scale-95"
                     x-transition:enter-end="opacity-100 transform scale-100"
                     @click.outside="showAddModal = false">

                    <div class="modal-header">
                        <h3 class="modal-title">
                            <i class="bi bi-folder-plus"></i>
                            <span x-text="parseInt(addForm.parentId) > 0 ? 'Add Child Category' : 'Add Root Category'"></span>
                        </h3>
                        <button type="button" class="modal-close" @click="showAddModal = false">
                            <i class="bi bi-x-lg"></i>
                        </button>
                    </div>

                    <div class="modal-body">
                        <div class="form-group">
                            <label class="form-label">Parent Category</label>
                            <!-- Custom Searchable Dropdown -->
                            <div class="category-dropdown" x-data="{ open: false, search: '' }" @click.outside="open = false; search = ''">
                                <button type="button" class="category-dropdown-trigger" @click="open = !open; if(open) $nextTick(() => $refs.searchInput.focus())">
                                    <span class="category-dropdown-value">
                                        <template x-if="parseInt(addForm.parentId) === 0">
                                            <span class="dropdown-placeholder">— None (Root) —</span>
                                        </template>
                                        <template x-if="parseInt(addForm.parentId) > 0">
                                            <span x-text="getSelectedParentName()"></span>
                                        </template>
                                    </span>
                                    <i class="bi bi-chevron-down dropdown-arrow" :class="{ 'rotate': open }"></i>
                                </button>
                                <div class="category-dropdown-menu" x-show="open" x-cloak x-transition>
                                    <div class="dropdown-search">
                                        <i class="bi bi-search"></i>
                                        <input type="text" x-ref="searchInput" x-model="search" placeholder="Search categories..." @keydown.escape="open = false; search = ''">
                                        <button type="button" class="search-clear-btn" x-show="search" x-cloak @click="search = ''; $refs.searchInput.focus()">
                                            <i class="bi bi-x-lg"></i>
                                        </button>
                                    </div>
                                    <div class="dropdown-options">
                                        <button type="button" class="dropdown-option" :class="{ 'selected': parseInt(addForm.parentId) === 0 }" @click="addForm.parentId = 0; open = false; search = ''">
                                            <i class="bi bi-house-door"></i>
                                            <span>— None (Root) —</span>
                                        </button>
                                        <template x-for="cat in filteredParentOptions(search)" :key="cat.id">
                                            <button type="button" class="dropdown-option" :class="{ 'selected': parseInt(addForm.parentId) === parseInt(cat.id) }" :style="'padding-left: ' + (12 + parseInt(cat.depth) * 16) + 'px'" @click="addForm.parentId = parseInt(cat.id); open = false; search = ''">
                                                <i class="bi" :class="parseInt(cat.child_count || 0) > 0 ? 'bi-folder-fill' : 'bi-folder'"></i>
                                                <span x-text="cat.name"></span>
                                                <span class="option-depth" x-text="'L' + cat.depth"></span>
                                            </button>
                                        </template>
                                        <div class="dropdown-empty" x-show="filteredParentOptions(search).length === 0 && search">
                                            <i class="bi bi-search"></i>
                                            <span>No categories found</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="parent-path" x-show="parseInt(addForm.parentId) > 0" x-cloak>
                                <i class="bi bi-diagram-3"></i>
                                <span x-text="getParentPath(addForm.parentId)"></span>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Name <span class="required">*</span></label>
                            <input type="text" class="form-input" x-model="addForm.name" @input="generateSlug()" placeholder="Category name" required>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Slug <span class="form-hint">(auto-generated)</span></label>
                            <input type="text" class="form-input" x-model="addForm.slug" placeholder="category-slug">
                        </div>

                        <div class="form-group">
                            <label class="form-label">Description <span class="form-hint">(optional)</span></label>
                            <textarea class="form-textarea" rows="3" x-model="addForm.description" placeholder="Category description..."></textarea>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" @click="showAddModal = false">Cancel</button>
                        <button type="button" class="btn btn-primary" @click="createCategory()" :disabled="isSubmitting || !addForm.name.trim()">
                            <i class="bi" :class="isSubmitting ? 'bi-arrow-clockwise animate-spin' : 'bi-check-lg'"></i>
                            <span x-text="isSubmitting ? 'Creating...' : 'Create Category'"></span>
                        </button>
                    </div>
                </div>
            </div>

            <!-- Toast -->
            <div class="toast-container" x-show="showToast" x-cloak
                 x-transition:enter="transition ease-out duration-300"
                 x-transition:enter-start="opacity-0 transform translate-y-4"
                 x-transition:enter-end="opacity-100 transform translate-y-0"
                 x-transition:leave="transition ease-in duration-200"
                 x-transition:leave-start="opacity-100"
                 x-transition:leave-end="opacity-0">
                <div class="toast" :class="'toast-' + toastType">
                    <div class="toast-icon">
                        <i class="bi" :class="{
                            'bi-check-circle-fill': toastType === 'success',
                            'bi-exclamation-triangle-fill': toastType === 'warning',
                            'bi-x-circle-fill': toastType === 'error',
                            'bi-info-circle-fill': toastType === 'info'
                        }"></i>
                    </div>
                    <div class="toast-content">
                        <div class="toast-title" x-text="toastTitle"></div>
                        <div class="toast-message" x-text="toastMessage"></div>
                    </div>
                    <button class="toast-close" @click="showToast = false">
                        <i class="bi bi-x"></i>
                    </button>
                </div>
            </div>
        </div>

        <script>
        document.addEventListener('alpine:init', () => {
            Alpine.data('categoriesPage', () => ({
                // State
                currentCategories: [],
                breadcrumb: [],
                currentParentId: 0,
                stats: acmsCatConfig.stats || { total: 0, products: 0, root: 0 },
                isLoading: true,
                refreshSuccess: false,
                searchQuery: '',
                _searchTimer: null,
                _allCategoriesCache: null, // Lazy-loaded for dropdowns

                // Bulk Selection
                selectedIds: [],
                bulkAction: '',
                isBulkProcessing: false,
                includeChildren: false,
                dropdownOpen: false,
                showAiModal: false,
                bulkActionLabels: {
                    'delete': 'Delete',
                    'generate_ai': 'Generate AI Content',
                    'regenerate_ai': 'Regenerate AI Content'
                },

                // Delete Modal
                showDeleteModal: false,
                deleteMode: 'category_only',
                childrenMode: 'reassign',
                deleteTargets: [],
                deleteTargetName: '',
                deleteTargetHasChildren: false,
                deleteTargetChildCount: 0,
                isDeleting: false,

                // Modal
                showAddModal: false,
                isSubmitting: false,
                addForm: {
                    name: '',
                    slug: '',
                    parentId: 0,
                    description: ''
                },

                // Directory Cache
                isCacheRebuilding: false,
                cacheRebuildSuccess: false,

                // Toast
                showToast: false,
                toastType: 'success',
                toastTitle: '',
                toastMessage: '',

                init() {
                    // Check URL hash for parent navigation (e.g., #parent-123)
                    const hash = window.location.hash;
                    if (hash && hash.startsWith('#parent-')) {
                        const parentId = parseInt(hash.replace('#parent-', ''));
                        if (parentId > 0) {
                            this.currentParentId = parentId;
                            history.replaceState(null, '', window.location.pathname + window.location.search);
                        }
                    }
                    this.loadCategories();
                },

                async loadCategories() {
                    this.isLoading = true;
                    try {
                        let url;
                        if (this.searchQuery) {
                            url = acmsCatConfig.restUrl + 'categories?status=all&search=' + encodeURIComponent(this.searchQuery);
                        } else {
                            url = acmsCatConfig.restUrl + 'categories?status=all&parent_id=' + this.currentParentId;
                        }
                        const response = await fetch(url, {
                            headers: { 'X-WP-Nonce': acmsCatConfig.nonce }
                        });
                        const result = await response.json();
                        if (result.success) {
                            this.currentCategories = result.data || [];
                        }

                        // Load breadcrumb from server if navigating inside a category
                        if (this.currentParentId > 0 && !this.searchQuery) {
                            await this.loadBreadcrumb(this.currentParentId);
                        } else {
                            this.breadcrumb = [];
                        }
                    } catch (error) {
                        this.toast('error', 'Error', 'Failed to load categories');
                    } finally {
                        this.isLoading = false;
                        this.refreshSuccess = true;
                        setTimeout(() => { this.refreshSuccess = false; }, 2000);
                    }
                },

                async rebuildDirectoryCache() {
                    this.isCacheRebuilding = true;
                    this.cacheRebuildSuccess = false;
                    try {
                        const response = await fetch(acmsCatConfig.restUrl + 'cron/rebuild-category-cache', {
                            method: 'POST',
                            headers: { 'X-WP-Nonce': acmsCatConfig.nonce }
                        });
                        const result = await response.json();
                        if (result.success && !result.data?.skipped) {
                            const sizeKb = result.data?.file_size ? Math.round(result.data.file_size / 1024) : 0;
                            this.toast('success', 'Cache Rebuilt', `${result.data?.categories_count || 0} categories, ${sizeKb}KB, ${result.data?.duration_ms || 0}ms`);
                            this.cacheRebuildSuccess = true;
                            setTimeout(() => { this.cacheRebuildSuccess = false; }, 3000);
                        } else {
                            this.toast('info', 'Skipped', result.message || 'Cache rebuild skipped');
                        }
                    } catch (error) {
                        this.toast('error', 'Error', 'Failed to rebuild cache');
                    } finally {
                        this.isCacheRebuilding = false;
                    }
                },

                async loadBreadcrumb(parentId) {
                    try {
                        const response = await fetch(acmsCatConfig.restUrl + 'categories/' + parentId + '/breadcrumb', {
                            headers: { 'X-WP-Nonce': acmsCatConfig.nonce }
                        });
                        const result = await response.json();
                        if (result.success) {
                            this.breadcrumb = result.data || [];
                        }
                    } catch (error) {
                        this.breadcrumb = [];
                    }
                },

                navigateTo(parentId) {
                    this.currentParentId = parseInt(parentId) || 0;
                    this.searchQuery = '';
                    this.clearSelection();
                    this.loadCategories();
                },

                goUp() {
                    if (this.breadcrumb.length > 1) {
                        this.navigateTo(parseInt(this.breadcrumb[this.breadcrumb.length - 2].id));
                    } else if (this.breadcrumb.length === 1) {
                        this.navigateTo(0);
                    }
                },

                searchCategories() {
                    clearTimeout(this._searchTimer);
                    this._searchTimer = setTimeout(() => {
                        this.loadCategories();
                    }, 300);
                },

                async loadAllCategoriesForDropdown() {
                    if (this._allCategoriesCache) return;
                    try {
                        const response = await fetch(acmsCatConfig.restUrl + 'categories?status=all', {
                            headers: { 'X-WP-Nonce': acmsCatConfig.nonce }
                        });
                        const result = await response.json();
                        if (result.success) {
                            this._allCategoriesCache = result.data || [];
                        }
                    } catch (error) {
                        this._allCategoriesCache = [];
                    }
                },

                invalidateDropdownCache() {
                    this._allCategoriesCache = null;
                },

                generateSlug() {
                    if (!this.addForm.slug || this.addForm.slug === this.slugify(this.addForm.name.slice(0, -1))) {
                        this.addForm.slug = this.slugify(this.addForm.name);
                    }
                },

                slugify(text) {
                    return text.toLowerCase()
                        .replace(/[^a-z0-9]+/g, '-')
                        .replace(/^-+|-+$/g, '');
                },

                openAddModal(parent = null) {
                    this.addForm = {
                        name: '',
                        slug: '',
                        parentId: parent ? parseInt(parent.id) : this.currentParentId,
                        description: ''
                    };
                    this.loadAllCategoriesForDropdown();
                    this.showAddModal = true;
                },

                async createCategory() {
                    if (!this.addForm.name.trim()) return;

                    this.isSubmitting = true;
                    try {
                        const response = await fetch(acmsCatConfig.restUrl + 'categories', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-WP-Nonce': acmsCatConfig.nonce
                            },
                            body: JSON.stringify({
                                name: this.addForm.name,
                                slug: this.addForm.slug || this.slugify(this.addForm.name),
                                parent_id: parseInt(this.addForm.parentId) || 0,
                                description: this.addForm.description,
                                status: 'publish'
                            })
                        });

                        const result = await response.json();
                        if (result.success) {
                            this.toast('success', 'Created', 'Category created successfully');
                            this.showAddModal = false;
                            this.invalidateDropdownCache();
                            this.loadCategories();
                        } else {
                            this.toast('error', 'Error', result.message || 'Failed to create category');
                        }
                    } catch (error) {
                        this.toast('error', 'Error', 'Failed to create category');
                    } finally {
                        this.isSubmitting = false;
                    }
                },

                // Open delete modal for single category
                deleteCategory(cat) {
                    this.deleteTargets = [parseInt(cat.id)];
                    this.deleteTargetName = cat.name;
                    this.deleteMode = 'category_only';
                    this.childrenMode = 'reassign';

                    // Check if this category has children
                    const childCount = parseInt(cat.child_count || 0);
                    this.deleteTargetHasChildren = childCount > 0;
                    this.deleteTargetChildCount = childCount;

                    this.showDeleteModal = true;
                },

                // Execute delete action (from modal)
                async executeDelete() {
                    if (this.deleteTargets.length === 0) return;

                    this.isDeleting = true;
                    let deleted = 0;
                    let failed = 0;
                    let totalChildrenHandled = 0;
                    let totalOrphaned = 0;

                    for (const id of this.deleteTargets) {
                        try {
                            const params = new URLSearchParams({
                                delete_mode: this.deleteMode,
                                children_mode: this.childrenMode
                            });
                            const response = await fetch(acmsCatConfig.restUrl + 'categories/' + id + '?' + params.toString(), {
                                method: 'DELETE',
                                headers: { 'X-WP-Nonce': acmsCatConfig.nonce }
                            });
                            const result = await response.json();
                            if (result.success) {
                                deleted++;
                                totalChildrenHandled += (result.children_handled || 0);
                                totalOrphaned += (result.orphaned_products_deleted || 0);
                            } else {
                                failed++;
                            }
                        } catch (error) {
                            failed++;
                        }
                    }

                    this.isDeleting = false;
                    this.showDeleteModal = false;
                    this.clearSelection();
                    this.invalidateDropdownCache();
                    this.loadCategories();

                    // Build toast message
                    let msg = this.deleteTargets.length > 1
                        ? `${deleted} categories deleted`
                        : 'Category deleted';
                    if (totalChildrenHandled > 0) {
                        msg += this.childrenMode === 'reassign'
                            ? `, ${totalChildrenHandled} children moved`
                            : `, ${totalChildrenHandled} children removed`;
                    }
                    if (totalOrphaned > 0) {
                        msg += `, ${totalOrphaned} products cleaned`;
                    }
                    if (failed > 0) {
                        this.toast('warning', 'Partial Success', `${msg}, ${failed} failed`);
                    } else {
                        this.toast('success', 'Deleted', msg);
                    }

                    this.deleteTargets = [];
                    this.deleteTargetName = '';
                },

                // Bulk Selection
                toggleSelect(id) {
                    const idx = this.selectedIds.indexOf(id);
                    if (idx > -1) {
                        this.selectedIds.splice(idx, 1);
                    } else {
                        this.selectedIds.push(id);
                    }
                },

                toggleSelectAll() {
                    if (this.isAllSelected) {
                        this.selectedIds = [];
                    } else {
                        this.selectedIds = this.currentCategories.map(c => parseInt(c.id));
                    }
                },

                get isAllSelected() {
                    return this.currentCategories.length > 0 &&
                           this.selectedIds.length === this.currentCategories.length;
                },

                get hasSelection() {
                    return this.selectedIds.length > 0;
                },

                get sortedCategoriesForDropdown() {
                    const items = this._allCategoriesCache || [];
                    const buildTree = (items, parentId = 0) => {
                        return items
                            .filter(item => parseInt(item.parent_id || 0) === parentId)
                            .sort((a, b) => (parseInt(a.position) || 0) - (parseInt(b.position) || 0) || a.name.localeCompare(b.name))
                            .flatMap(item => [item, ...buildTree(items, parseInt(item.id))]);
                    };
                    return buildTree(items);
                },

                getParentOptionText(cat) {
                    const depth = parseInt(cat.depth) || 0;
                    const indent = depth > 0 ? '　'.repeat(depth) + '└─ ' : '';
                    return indent + cat.name + ' (L' + depth + ')';
                },

                getParentPath(parentId) {
                    const id = parseInt(parentId);
                    if (!id) return '';

                    const path = [];
                    let current = (this._allCategoriesCache || []).find(c => parseInt(c.id) === id);

                    while (current) {
                        path.unshift(current.name);
                        current = current.parent_id ? (this._allCategoriesCache || []).find(c => parseInt(c.id) === parseInt(current.parent_id)) : null;
                    }

                    return 'Root → ' + path.join(' → ');
                },

                getSelectedParentName() {
                    const id = parseInt(this.addForm.parentId);
                    if (!id) return '— None (Root) —';
                    const cat = (this._allCategoriesCache || []).find(c => parseInt(c.id) === id);
                    return cat ? cat.name + ' (L' + cat.depth + ')' : '— None (Root) —';
                },

                filteredParentOptions(search) {
                    const sorted = this.sortedCategoriesForDropdown;
                    if (!search || !search.trim()) return sorted;
                    const query = search.toLowerCase().trim();
                    return sorted.filter(cat =>
                        cat.name.toLowerCase().includes(query) ||
                        cat.slug.toLowerCase().includes(query)
                    );
                },

                clearSelection() {
                    this.selectedIds = [];
                    this.bulkAction = '';
                },

                // Handle Apply button click - shows modal for AI actions
                handleBulkApply() {
                    if (!this.bulkAction || this.selectedIds.length === 0) return;

                    // For AI actions, show modal
                    if (this.bulkAction === 'generate_ai' || this.bulkAction === 'regenerate_ai') {
                        this.includeChildren = false; // Reset option
                        this.showAiModal = true;
                        return;
                    }

                    // For delete, execute directly with confirmation
                    if (this.bulkAction === 'delete') {
                        this.executeDeleteBulkAction();
                    }
                },

                // Open delete modal for bulk action
                executeDeleteBulkAction() {
                    this.deleteTargets = [...this.selectedIds];
                    this.deleteTargetName = '';
                    this.deleteMode = 'category_only';
                    this.childrenMode = 'reassign';

                    // Check if any selected category has children
                    let totalChildren = 0;
                    for (const id of this.selectedIds) {
                        const cat = (this._allCategoriesCache || []).find(c => parseInt(c.id) === id);
                        if (cat) totalChildren += parseInt(cat.child_count || 0);
                    }
                    this.deleteTargetHasChildren = totalChildren > 0;
                    this.deleteTargetChildCount = totalChildren;

                    this.showDeleteModal = true;
                },

                // Execute AI bulk action (called from modal)
                async executeAiBulkAction() {
                    const action = this.bulkAction === 'generate_ai' ? 'generate' : 'regenerate';

                    this.isBulkProcessing = true;

                    try {
                        const response = await fetch(acmsCatConfig.restUrl + 'categories/bulk-ai', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-WP-Nonce': acmsCatConfig.nonce
                            },
                            body: JSON.stringify({
                                action: action,
                                category_ids: this.selectedIds,
                                include_children: this.includeChildren
                            })
                        });

                        const result = await response.json();

                        if (result.success) {
                            const title = action === 'generate' ? 'AI Generation Queued' : 'AI Regeneration Queued';
                            this.toast('success', title, result.message);
                            this.loadCategories();
                        } else {
                            this.toast('error', 'Error', result.message || 'Failed to queue AI generation');
                        }
                    } catch (error) {
                        this.toast('error', 'Error', 'Failed to queue AI generation');
                    } finally {
                        this.isBulkProcessing = false;
                        this.showAiModal = false;
                        this.clearSelection();
                        this.includeChildren = false;
                    }
                },

                toast(type, title, message) {
                    this.toastType = type;
                    this.toastTitle = title;
                    this.toastMessage = message;
                    this.showToast = true;
                    setTimeout(() => { this.showToast = false; }, 5000);
                },

                // AI Status helper functions (matches content_status ENUM values)
                getAiStatusColor(status) {
                    const colors = {
                        'empty': 'secondary',
                        'ai_generating': 'info',
                        'ai_generated': 'success',
                        'manual': 'primary',
                        'template': 'warning',
                        'failed': 'error'
                    };
                    return colors[status] || 'secondary';
                },

                getAiStatusIcon(status) {
                    const icons = {
                        'empty': 'bi-dash',
                        'ai_generating': 'bi-arrow-repeat animate-spin',
                        'ai_generated': 'bi-robot',
                        'manual': 'bi-pencil',
                        'template': 'bi-file-text',
                        'failed': 'bi-exclamation-triangle'
                    };
                    return icons[status] || 'bi-dash';
                },

                getAiStatusLabel(status) {
                    const labels = {
                        'empty': 'Empty',
                        'ai_generating': 'AI...',
                        'ai_generated': 'AI',
                        'manual': 'Manual',
                        'template': 'Template',
                        'failed': 'Failed'
                    };
                    return labels[status] || 'Empty';
                },

                getAiStatusTitle(cat) {
                    const status = cat.content_status || 'empty';
                    const titles = {
                        'empty': 'No AI content generated',
                        'ai_generating': 'AI is generating category content...',
                        'ai_generated': cat.content_updated_at ? `AI content generated on ${cat.content_updated_at}` : 'AI content generated',
                        'manual': 'Content was manually written',
                        'template': 'Using template content',
                        'failed': cat.ai_error_message ? `AI generation failed: ${cat.ai_error_message}` : 'AI generation failed'
                    };
                    return titles[status] || '';
                }
            }));
        });
        </script>
        <?php
    }

    /**
     * Render CSS styles
     */
    private function renderStyles(): void
    {
        ?>
        /* CSS Variables - Dark Theme */
        :root {
            --primary: #2271b1;
            --primary-hover: #135e96;
            --primary-light: rgba(34, 113, 177, 0.1);
            --bg-base: #0a0a0b;
            --bg-surface: #111113;
            --bg-elevated: #18181b;
            --bg-hover: #1f1f23;
            --border: #27272a;
            --border-hover: #3f3f46;
            --text-primary: #fafafa;
            --text-secondary: #a1a1aa;
            --text-muted: #71717a;
            --success: #22c55e;
            --success-light: rgba(34, 197, 94, 0.1);
            --warning: #f59e0b;
            --warning-light: rgba(245, 158, 11, 0.1);
            --error: #ef4444;
            --error-light: rgba(239, 68, 68, 0.1);
            --info: #3b82f6;
            --info-light: rgba(59, 130, 246, 0.1);
            --radius-sm: 6px;
            --radius-md: 8px;
            --radius-lg: 12px;
            --shadow-md: 0 4px 12px rgba(0, 0, 0, 0.4);
            --shadow-lg: 0 10px 40px rgba(0, 0, 0, 0.5);
            --wp-admin-bar-height: 32px;
        }

        /* WP Admin Z-Index Fix */
        #adminmenuback, #adminmenuwrap { z-index: 1001 !important; }

        /* Reset */
        .acms-admin, .acms-admin *, .acms-admin *::before, .acms-admin *::after { box-sizing: border-box; }
        .acms-admin {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif !important;
            font-size: 14px !important;
            line-height: 1.5 !important;
            color: var(--text-primary) !important;
            -webkit-font-smoothing: antialiased;
        }
        [x-cloak] { display: none !important; }

        /* Layout */
        html.wp-toolbar, body.wp-admin { overflow: hidden !important; height: 100vh !important; }
        .wrap:has(.acms-admin) { margin: 0 !important; padding: 0 !important; max-width: none !important; }
        .acms-admin {
            position: fixed;
            top: var(--wp-admin-bar-height);
            left: 160px;
            right: 0;
            bottom: 0;
            overflow-y: auto;
            background: var(--bg-base);
        }
        .folded .acms-admin { left: 36px; }
        @media (max-width: 960px) { .acms-admin { left: 36px; } }
        @media (max-width: 782px) { .acms-admin { left: 0; top: 46px; } }

        .app-container { max-width: 1600px; margin: 0 auto; padding: 16px; }

        /* Page Header */
        .page-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 16px;
            margin-bottom: 16px;
        }
        .header-left { display: flex; align-items: center; gap: 12px; }
        .header-actions { display: flex; align-items: center; gap: 8px; }
        .header-divider { width: 1px; height: 28px; background: var(--border); }

        /* Stats Inline */
        .stats-inline { display: flex; gap: 16px; }
        .stat-item {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 8px 12px;
            background: var(--bg-surface);
            border-radius: var(--radius-md);
            border: 1px solid var(--border);
        }
        .stat-item-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
        }
        .stat-item-dot.total { background: var(--primary); }
        .stat-item-dot.root { background: var(--info); }
        .stat-item-dot.products { background: var(--success); }
        .stat-item-value { font-size: 18px; font-weight: 600; color: var(--text-primary); }
        .stat-item-label { font-size: 12px; color: var(--text-muted); }

        /* Buttons */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 8px 16px;
            font-size: 13px;
            font-weight: 500;
            border-radius: var(--radius-md);
            border: 1px solid transparent;
            cursor: pointer;
            transition: all 0.15s ease;
            white-space: nowrap;
        }
        .btn:disabled { opacity: 0.5; cursor: not-allowed; }
        .btn-primary { background: var(--primary); color: white; border-color: var(--primary); }
        .btn-primary:hover:not(:disabled) { background: var(--primary-hover); }
        .btn-secondary { background: var(--bg-surface); color: var(--text-primary); border-color: var(--border); }
        .btn-secondary:hover:not(:disabled) { background: var(--bg-hover); border-color: var(--border-hover); }

        .btn-icon {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 36px;
            height: 36px;
            padding: 0;
            background: var(--bg-surface);
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
            color: var(--text-secondary);
            cursor: pointer;
            transition: all 0.15s ease;
            text-decoration: none;
        }
        .btn-icon:hover { background: var(--bg-hover); color: var(--text-primary); border-color: var(--border-hover); }
        .btn-icon-sm { width: 28px; height: 28px; font-size: 14px; }
        .btn-icon.btn-danger:hover { background: var(--error-light); color: var(--error); border-color: var(--error); }

        /* Toolbar */
        .toolbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 16px;
            padding: 12px 16px;
            background: var(--bg-surface);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            margin-bottom: 16px;
        }

        /* Breadcrumb Bar (standalone, always visible when navigated) */
        .breadcrumb-bar {
            display: flex;
            align-items: center;
            padding: 8px 12px;
            background: var(--bg-secondary);
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
            margin-bottom: 12px;
        }

        /* Empty Level State */
        .empty-level {
            display: flex;
            justify-content: center;
            padding: 48px 16px;
        }
        .empty-level-content {
            text-align: center;
            color: var(--text-muted);
        }
        .empty-level-content > i {
            font-size: 36px;
            opacity: 0.4;
            margin-bottom: 8px;
            display: block;
        }
        .empty-level-content > p {
            font-size: 13px;
            margin: 0 0 16px 0;
        }
        .empty-level-actions {
            display: flex;
            gap: 8px;
            justify-content: center;
        }

        /* Breadcrumb in Table Header */
        .breadcrumb { display: flex; align-items: center; gap: 4px; }
        .breadcrumb-item {
            display: flex;
            align-items: center;
            gap: 6px;
            padding: 4px 8px;
            color: var(--text-secondary);
            text-decoration: none;
            font-size: 12px;
            font-weight: 500;
            text-transform: none;
            letter-spacing: normal;
            border-radius: var(--radius-sm);
            transition: all 0.15s ease;
        }
        .breadcrumb-item:hover { background: var(--bg-hover); color: var(--text-primary); }
        .breadcrumb-item.active { color: var(--text-primary); font-weight: 600; }
        .breadcrumb-separator { display: flex; align-items: center; gap: 4px; color: var(--text-muted); }
        .breadcrumb-separator i { font-size: 10px; }
        .breadcrumb-up {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 24px;
            height: 24px;
            padding: 0;
            background: var(--bg-hover);
            border: 1px solid var(--border);
            border-radius: var(--radius-sm);
            color: var(--text-muted);
            cursor: pointer;
            transition: all 0.15s ease;
            margin-right: 4px;
        }
        .breadcrumb-up:hover { background: var(--primary-light); color: var(--primary); border-color: var(--primary); }
        .breadcrumb-up i { font-size: 12px; }
        .breadcrumb-depth {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            margin-left: 8px;
            padding: 2px 8px;
            font-size: 10px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: var(--text-muted);
            background: var(--bg-hover);
            border-radius: 10px;
        }

        /* Search Box */
        .search-box {
            position: relative;
            display: flex;
            align-items: center;
            width: 280px;
        }
        .search-box .search-icon {
            position: absolute;
            right: 12px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-muted);
            font-size: 14px;
            pointer-events: none;
            z-index: 1;
            line-height: 1;
        }
        .search-box .search-input {
            width: 100%;
            height: 36px;
            padding: 0 64px 0 14px !important;
            font-size: 13px !important;
            background: var(--bg-base) !important;
            border: 1px solid var(--border) !important;
            border-radius: var(--radius-md) !important;
            color: var(--text-primary) !important;
            transition: all 0.15s ease;
            line-height: 36px;
        }
        .search-box .search-input:focus {
            border-color: var(--primary) !important;
            box-shadow: 0 0 0 3px var(--primary-light) !important;
            outline: none !important;
        }
        .search-box .search-input::placeholder {
            color: var(--text-muted) !important;
        }
        .search-box .search-input::-webkit-search-cancel-button {
            -webkit-appearance: none;
            display: none;
        }
        .search-box .search-clear {
            position: absolute;
            right: 36px;
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: var(--bg-hover);
            border: none;
            border-radius: 50%;
            color: var(--text-muted);
            cursor: pointer;
            transition: all 0.15s ease;
            z-index: 2;
        }
        .search-box .search-clear:hover {
            background: var(--border);
            color: var(--text-primary);
        }
        .search-box .search-clear i {
            font-size: 10px;
        }

        /* Data Table */
        .data-table-wrapper {
            background: var(--bg-surface);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            overflow: hidden;
        }
        .data-table-loading, .data-table-empty {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 12px;
            padding: 60px 20px;
            color: var(--text-muted);
        }
        .data-table-empty i { font-size: 48px; opacity: 0.5; }
        .spinner {
            width: 32px;
            height: 32px;
            border: 3px solid var(--border);
            border-top-color: var(--primary);
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        @keyframes spin { to { transform: rotate(360deg); } }

        .data-table-container { overflow-x: auto; }
        .data-table {
            width: 100%;
            border-collapse: collapse;
        }
        .data-table th, .data-table td {
            padding: 12px 16px;
            text-align: left;
            border-bottom: 1px solid var(--border);
        }
        .data-table th {
            font-size: 12px;
            font-weight: 600;
            color: var(--text-muted);
            text-transform: uppercase;
            background: var(--bg-elevated);
        }
        .data-table tr:hover { background: var(--bg-hover); }

        .col-checkbox { width: 40px; text-align: center; }
        .col-name { min-width: 250px; }
        .col-slug { width: 200px; }
        .col-ai { width: 70px; text-align: center; }
        .col-children, .col-products, .col-depth { width: 80px; text-align: center; }
        .col-actions { width: 150px; }

        /* Badge Styles */
        .badge {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 4px;
            padding: 4px 8px;
            font-size: 12px;
            font-weight: 500;
            border-radius: var(--radius-sm);
            white-space: nowrap;
        }
        .badge-sm {
            padding: 2px 6px;
            font-size: 11px;
        }
        .badge-secondary {
            background: var(--bg-elevated);
            color: var(--text-muted);
        }
        .badge-info {
            background: var(--info-light);
            color: var(--info);
        }
        .badge-success {
            background: var(--success-light);
            color: var(--success);
        }
        .badge-error {
            background: var(--error-light);
            color: var(--error);
        }
        .badge-warning {
            background: var(--warning-light);
            color: var(--warning);
        }

        /* Checkbox */
        .checkbox-wrapper {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
        }
        .checkbox-wrapper input[type="checkbox"] {
            position: absolute;
            opacity: 0;
            width: 0;
            height: 0;
        }
        .checkbox-custom {
            width: 18px;
            height: 18px;
            border: 2px solid var(--border);
            border-radius: 4px;
            background: var(--bg-surface);
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.15s ease;
        }
        .checkbox-wrapper:hover .checkbox-custom {
            border-color: var(--primary);
        }
        .checkbox-wrapper input:checked + .checkbox-custom {
            background: var(--primary);
            border-color: var(--primary);
        }
        .checkbox-wrapper input:checked + .checkbox-custom::after {
            content: '';
            width: 5px;
            height: 9px;
            border: solid white;
            border-width: 0 2px 2px 0;
            transform: rotate(45deg);
            margin-bottom: 2px;
        }
        .row-selected {
            background: var(--primary-light) !important;
        }

        /* Bulk Actions Bar */
        .bulk-actions-bar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px 16px;
            background: var(--bg-elevated);
            border-bottom: 1px solid var(--border);
        }
        .bulk-actions-left {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .bulk-actions-right {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .selected-count {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            font-size: 13px;
            font-weight: 500;
            color: var(--text-primary);
            background: var(--primary-light);
            padding: 6px 12px;
            border-radius: var(--radius-md);
        }
        .selected-count i { font-size: 16px; color: var(--primary); }
        .selected-count span { color: var(--text-primary); }
        .btn-link {
            background: none;
            border: none;
            color: var(--text-muted);
            font-size: 13px;
            cursor: pointer;
            padding: 4px 8px;
            border-radius: var(--radius-sm);
            transition: all 0.15s ease;
        }
        .btn-link:hover {
            color: var(--text-primary);
            background: var(--bg-hover);
        }
        /* Custom Dropdown */
        .custom-dropdown {
            position: relative;
        }
        .dropdown-trigger {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 8px 14px;
            font-size: 13px;
            font-weight: 500;
            background: var(--bg-surface);
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
            color: var(--text-primary);
            cursor: pointer;
            transition: all 0.15s ease;
            min-width: 180px;
            justify-content: space-between;
        }
        .dropdown-trigger:hover {
            border-color: var(--primary);
            background: var(--bg-hover);
        }
        .dropdown-trigger i {
            font-size: 12px;
            color: var(--text-muted);
            transition: transform 0.2s ease;
        }
        .dropdown-menu {
            position: absolute;
            top: calc(100% + 4px);
            left: 0;
            min-width: 200px;
            background: var(--bg-elevated);
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.25);
            z-index: 100;
            padding: 6px;
        }
        .dropdown-item {
            display: flex;
            align-items: center;
            gap: 10px;
            width: 100%;
            padding: 10px 12px;
            font-size: 13px;
            color: var(--text-primary);
            background: none;
            border: none;
            border-radius: var(--radius-sm);
            cursor: pointer;
            text-align: left;
            transition: all 0.15s ease;
        }
        .dropdown-item:hover {
            background: var(--bg-hover);
        }
        .dropdown-item.active {
            background: var(--primary-light);
            color: var(--primary);
        }
        .dropdown-item i {
            font-size: 14px;
            width: 18px;
            text-align: center;
            color: var(--text-muted);
        }
        .dropdown-item.active i {
            color: var(--primary);
        }
        .dropdown-divider {
            height: 1px;
            background: var(--border);
            margin: 6px 0;
        }

        /* AI Options Modal */
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.6);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1000;
            backdrop-filter: blur(2px);
        }
        .modal-dialog {
            background: var(--bg-elevated);
            border-radius: var(--radius-lg);
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.4);
            width: 100%;
            max-width: 440px;
            animation: modalSlideIn 0.2s ease-out;
        }
        @keyframes modalSlideIn {
            from { opacity: 0; transform: translateY(-20px) scale(0.95); }
            to { opacity: 1; transform: translateY(0) scale(1); }
        }
        .modal-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 18px 20px;
            border-bottom: 1px solid var(--border);
        }
        .modal-header h3 {
            font-size: 16px;
            font-weight: 600;
            color: var(--text-primary);
            margin: 0;
        }
        .modal-close {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 32px;
            height: 32px;
            background: none;
            border: none;
            color: var(--text-muted);
            cursor: pointer;
            border-radius: var(--radius-sm);
            transition: all 0.15s ease;
        }
        .modal-close:hover {
            background: var(--bg-hover);
            color: var(--text-primary);
        }
        .modal-body {
            padding: 20px;
        }
        .modal-info {
            display: flex;
            gap: 10px;
            padding: 12px 14px;
            background: var(--info-light, rgba(59, 130, 246, 0.1));
            border-radius: var(--radius-md);
            font-size: 13px;
            color: var(--text-secondary);
            margin-bottom: 20px;
        }
        .modal-info i {
            color: var(--info, #3b82f6);
            font-size: 16px;
            flex-shrink: 0;
        }
        .modal-option {
            padding: 14px;
            background: var(--bg-surface);
            border-radius: var(--radius-md);
            border: 1px solid var(--border);
        }
        .option-checkbox {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            position: relative;
        }
        .option-checkbox input {
            width: 18px;
            height: 18px;
            cursor: pointer;
            accent-color: var(--primary);
        }
        .option-label {
            font-size: 14px;
            font-weight: 500;
            color: var(--text-primary);
        }
        .option-desc {
            margin: 8px 0 0 28px;
            font-size: 12px;
            color: var(--text-muted);
        }
        .modal-footer {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            padding: 16px 20px;
            border-top: 1px solid var(--border);
            background: var(--bg-surface);
            border-radius: 0 0 var(--radius-lg) var(--radius-lg);
        }

        /* Delete Modal Styles */
        .modal-warning {
            display: flex;
            gap: 10px;
            padding: 12px 14px;
            background: var(--error-light);
            border-radius: var(--radius-md);
            font-size: 13px;
            color: var(--text-secondary);
            margin-bottom: 20px;
        }
        .modal-warning i {
            color: var(--error);
            font-size: 16px;
            flex-shrink: 0;
        }
        .delete-section {
            margin-bottom: 16px;
        }
        .delete-section:last-of-type {
            margin-bottom: 0;
        }
        .delete-section-label {
            display: flex;
            align-items: center;
            gap: 6px;
            font-size: 12px;
            font-weight: 600;
            color: var(--text-secondary);
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 8px;
        }
        .delete-section-label i {
            font-size: 13px;
        }
        .delete-options {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
        .delete-option {
            display: flex;
            align-items: flex-start;
            gap: 12px;
            padding: 12px 14px;
            background: var(--bg-surface);
            border: 2px solid var(--border);
            border-radius: var(--radius-md);
            cursor: pointer;
            transition: all 0.15s ease;
        }
        .delete-option:hover {
            border-color: var(--border-hover);
            background: var(--bg-hover);
        }
        .delete-option.selected {
            border-color: var(--primary);
            background: var(--primary-light);
        }
        .delete-option input[type="radio"] {
            margin-top: 2px;
            accent-color: var(--primary);
        }
        .delete-option .option-content {
            flex: 1;
        }
        .delete-option .option-title {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 14px;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 4px;
        }
        .delete-option .option-title i {
            font-size: 16px;
            color: var(--text-muted);
        }
        .delete-option.selected .option-title i {
            color: var(--primary);
        }
        .delete-option .option-desc {
            font-size: 12px;
            color: var(--text-muted);
            line-height: 1.5;
        }
        .delete-warning-box {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-top: 16px;
            padding: 12px 14px;
            background: var(--warning-light);
            border: 1px solid var(--warning);
            border-radius: var(--radius-md);
            font-size: 12px;
            color: var(--warning);
            font-weight: 500;
        }
        .delete-warning-box i {
            font-size: 16px;
            flex-shrink: 0;
        }
        .btn-danger {
            background: var(--error) !important;
            border-color: var(--error) !important;
            color: white !important;
        }
        .btn-danger:hover:not(:disabled) {
            background: #dc2626 !important;
            border-color: #dc2626 !important;
        }

        .btn-sm {
            padding: 6px 12px;
            font-size: 12px;
        }

        .category-name-cell { display: flex; align-items: center; }
        .category-name-link, .category-name {
            display: flex;
            align-items: center;
            gap: 8px;
            color: var(--text-primary);
            text-decoration: none;
            font-weight: 500;
            cursor: pointer;
        }
        .category-name-link:hover, .category-name:hover { color: var(--primary); }
        .category-name-leaf {
            display: flex;
            align-items: center;
            gap: 8px;
            color: var(--text-secondary);
            font-weight: 500;
        }
        .folder-icon { color: var(--warning); font-size: 16px; }
        .category-name .folder-icon { color: var(--text-muted); }
        .category-name-leaf .folder-icon { color: var(--text-muted); opacity: 0.6; }
        .category-name:hover .folder-icon { color: var(--warning); }
        .nav-arrow { font-size: 12px; color: var(--text-muted); margin-left: 4px; }
        .category-name-link:hover .nav-arrow { color: var(--primary); }

        .slug-code {
            font-family: 'SF Mono', Monaco, Consolas, monospace;
            font-size: 12px;
            padding: 2px 6px;
            background: var(--bg-elevated);
            border-radius: var(--radius-sm);
            color: var(--text-secondary);
        }

        .depth-badge {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 24px;
            height: 24px;
            padding: 0 6px;
            font-size: 11px;
            font-weight: 600;
            background: var(--bg-elevated);
            border-radius: 12px;
            color: var(--text-muted);
        }
        .depth-badge[data-depth="0"] { background: var(--primary-light); color: var(--primary); }
        .depth-badge[data-depth="1"] { background: var(--info-light); color: var(--info); }
        .depth-badge[data-depth="2"] { background: var(--success-light); color: var(--success); }
        .depth-badge[data-depth="3"] { background: var(--warning-light); color: var(--warning); }
        .depth-badge[data-depth="4"] { background: #f0abfc30; color: #d946ef; }
        .depth-badge[data-depth="5"] { background: #fda4af30; color: #f43f5e; }

        .actions-cell { display: flex; gap: 4px; }

        /* Modal */
        .modal-backdrop {
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.7);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 10000;
            padding: 20px;
        }
        .modal {
            background: var(--bg-surface);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-lg);
            max-width: 100%;
            max-height: 90vh;
            overflow: visible;
            display: flex;
            flex-direction: column;
        }
        .modal-md { width: 480px; }
        .modal-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 16px 20px;
            border-bottom: 1px solid var(--border);
        }
        .modal-title {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 16px;
            font-weight: 600;
            color: var(--text-primary);
            margin: 0;
        }
        .modal-close {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 32px;
            height: 32px;
            padding: 0;
            background: transparent;
            border: none;
            border-radius: var(--radius-sm);
            color: var(--text-muted);
            cursor: pointer;
        }
        .modal-close:hover { background: var(--bg-hover); color: var(--text-primary); }
        .modal-body { padding: 20px; overflow: visible; }
        .modal-footer {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 12px;
            padding: 16px 20px;
            border-top: 1px solid var(--border);
        }

        /* Form */
        .form-group { margin-bottom: 16px; }
        .form-group:last-child { margin-bottom: 0; }
        .form-label {
            display: block;
            margin-bottom: 6px;
            font-size: 13px;
            font-weight: 500;
            color: var(--text-primary);
        }
        .form-hint { font-weight: 400; color: var(--text-muted); }
        .required { color: var(--error); }
        .form-input, .form-textarea, .form-select {
            width: 100%;
            padding: 10px 12px;
            font-size: 14px;
            color: var(--text-primary);
            background: var(--bg-base);
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
        }
        .form-input:focus, .form-textarea:focus, .form-select:focus {
            outline: none;
            border-color: var(--primary);
        }
        .form-input::placeholder, .form-textarea::placeholder { color: var(--text-muted); }
        .form-textarea { resize: vertical; }
        .form-select { cursor: pointer; }
        .form-select option { font-family: 'SF Mono', Monaco, Consolas, monospace; padding: 8px; }

        /* Custom Category Dropdown */
        .category-dropdown { position: relative; width: 100%; }
        .category-dropdown-trigger {
            display: flex;
            align-items: center;
            justify-content: space-between;
            width: 100%;
            padding: 10px 12px;
            font-size: 14px;
            color: var(--text-primary);
            background: var(--bg-base);
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
            cursor: pointer;
            transition: all 0.15s ease;
            text-align: left;
        }
        .category-dropdown-trigger:hover { border-color: var(--border-hover); }
        .category-dropdown-trigger:focus { outline: none; border-color: var(--primary); box-shadow: 0 0 0 3px var(--primary-light); }
        .category-dropdown-value { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .dropdown-placeholder { color: var(--text-muted); }
        .dropdown-arrow { font-size: 12px; color: var(--text-muted); transition: transform 0.2s ease; margin-left: 8px; }
        .dropdown-arrow.rotate { transform: rotate(180deg); }

        .category-dropdown-menu {
            position: absolute;
            top: calc(100% + 4px);
            left: 0;
            right: 0;
            background: var(--bg-surface);
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
            box-shadow: var(--shadow-lg);
            z-index: 10001;
            overflow: hidden;
        }
        .dropdown-search {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 8px 12px;
            border-bottom: 1px solid var(--border);
            background: var(--bg-elevated);
        }
        .dropdown-search i { color: var(--text-muted); font-size: 14px; }
        .dropdown-search input {
            flex: 1;
            background: transparent;
            border: none;
            outline: none;
            color: var(--text-primary);
            font-size: 13px;
        }
        .dropdown-search input::placeholder { color: var(--text-muted); }
        .search-clear-btn {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 20px;
            height: 20px;
            padding: 0;
            background: var(--bg-hover);
            border: none;
            border-radius: 50%;
            color: var(--text-muted);
            cursor: pointer;
            flex-shrink: 0;
            transition: all 0.15s ease;
        }
        .search-clear-btn:hover {
            background: var(--border);
            color: var(--text-primary);
        }
        .search-clear-btn i { font-size: 10px; }

        .dropdown-options {
            max-height: 280px;
            overflow-y: auto;
            padding: 4px 0;
        }
        .dropdown-option {
            display: flex;
            align-items: center;
            gap: 8px;
            width: 100%;
            padding: 8px 12px;
            font-size: 13px;
            color: var(--text-primary);
            background: transparent;
            border: none;
            cursor: pointer;
            text-align: left;
            transition: background 0.1s ease;
        }
        .dropdown-option:hover { background: var(--bg-hover); }
        .dropdown-option.selected { background: var(--primary-light); color: var(--primary); }
        .dropdown-option i { font-size: 14px; color: var(--warning); flex-shrink: 0; }
        .dropdown-option.selected i { color: var(--primary); }
        .dropdown-option i.bi-house-door { color: var(--text-muted); }
        .dropdown-option span { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .option-depth {
            flex-shrink: 0;
            font-size: 10px;
            font-weight: 600;
            padding: 2px 6px;
            background: var(--bg-elevated);
            border-radius: 10px;
            color: var(--text-muted);
        }
        .dropdown-option.selected .option-depth { background: var(--primary); color: white; }

        .dropdown-empty {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 8px;
            padding: 20px;
            color: var(--text-muted);
            font-size: 13px;
        }
        .dropdown-empty i { font-size: 24px; opacity: 0.5; }

        .parent-path {
            display: flex;
            align-items: center;
            gap: 6px;
            margin-top: 8px;
            padding: 8px 12px;
            font-size: 12px;
            color: var(--text-secondary);
            background: var(--bg-elevated);
            border-radius: var(--radius-sm);
            border-left: 3px solid var(--primary);
        }
        .parent-path i { color: var(--primary); font-size: 14px; }

        /* Toast */
        .toast-container {
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 10001;
        }
        .toast {
            display: flex;
            align-items: flex-start;
            gap: 12px;
            padding: 16px;
            background: var(--bg-elevated);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-lg);
            min-width: 300px;
            max-width: 400px;
        }
        .toast-icon { font-size: 20px; flex-shrink: 0; }
        .toast-success .toast-icon { color: var(--success); }
        .toast-warning .toast-icon { color: var(--warning); }
        .toast-error .toast-icon { color: var(--error); }
        .toast-info .toast-icon { color: var(--info); }
        .toast-content { flex: 1; }
        .toast-title { font-weight: 600; color: var(--text-primary); margin-bottom: 2px; }
        .toast-message { font-size: 13px; color: var(--text-secondary); }
        .toast-close {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 24px;
            height: 24px;
            padding: 0;
            background: transparent;
            border: none;
            color: var(--text-muted);
            cursor: pointer;
            border-radius: var(--radius-sm);
        }
        .toast-close:hover { background: var(--bg-hover); color: var(--text-primary); }

        /* Animations */
        .animate-spin { animation: spin 1s linear infinite; }
        .refresh-success i { color: var(--success) !important; }
        <?php
    }
}
