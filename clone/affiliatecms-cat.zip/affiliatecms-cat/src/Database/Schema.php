<?php
/**
 * Database Schema for SEO Categories
 *
 * Uses Materialized Path pattern for efficient hierarchy queries
 * Path format: /1/5/23/ (category IDs separated by slashes)
 *
 * @package AffiliateCMS\Categories
 */

declare(strict_types=1);

namespace AffiliateCMS\Categories\Database;

class Schema
{
    public const VERSION = '2.0.0';
    public const OPTION_KEY = 'acms_cat_db_version';

    /**
     * Get table names with prefix
     */
    public static function tables(): array
    {
        global $wpdb;
        return [
            'categories'        => $wpdb->prefix . 'acms_categories',
            'category_products' => $wpdb->prefix . 'acms_category_products',
            'category_meta'     => $wpdb->prefix . 'acms_category_meta',
            'queue'             => $wpdb->prefix . 'acms_cat_queue',
            'product_reviews'   => $wpdb->prefix . 'acms_product_reviews',
        ];
    }

    public static function reviewsTable(): string
    {
        global $wpdb;
        return $wpdb->prefix . 'acms_product_reviews';
    }

    public static function queueTable(): string
    {
        global $wpdb;
        return $wpdb->prefix . 'acms_cat_queue';
    }

    public static function categoriesTable(): string
    {
        global $wpdb;
        return $wpdb->prefix . 'acms_categories';
    }

    /**
     * Install/upgrade database tables
     */
    public static function install(): void
    {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        $tables = self::tables();

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        // Main Categories Table
        $sql_categories = "CREATE TABLE {$tables['categories']} (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            parent_id BIGINT(20) UNSIGNED DEFAULT 0,
            path VARCHAR(255) NOT NULL DEFAULT '/',
            depth TINYINT(3) UNSIGNED NOT NULL DEFAULT 0,
            position INT(11) NOT NULL DEFAULT 0,
            name VARCHAR(255) NOT NULL,
            slug VARCHAR(255) NOT NULL,
            description TEXT,
            seo_title VARCHAR(255) DEFAULT NULL,
            seo_description TEXT DEFAULT NULL,
            seo_keywords VARCHAR(500) DEFAULT NULL,
            content_intro LONGTEXT DEFAULT NULL,
            content_main LONGTEXT DEFAULT NULL,
            content_faq LONGTEXT DEFAULT NULL,
            content_status ENUM('empty', 'template', 'ai_generating', 'ai_generated', 'manual') DEFAULT 'empty',
            content_updated_at DATETIME DEFAULT NULL,
            ai_generating_at DATETIME DEFAULT NULL,
            ai_error_message TEXT DEFAULT NULL,
            featured_image_id BIGINT(20) UNSIGNED DEFAULT NULL,
            icon VARCHAR(100) DEFAULT NULL,
            color VARCHAR(7) DEFAULT NULL,
            template VARCHAR(100) DEFAULT 'default',
            product_count INT(11) UNSIGNED NOT NULL DEFAULT 0,
            child_count INT(11) UNSIGNED NOT NULL DEFAULT 0,
            view_count BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
            status ENUM('publish', 'draft', 'pending', 'trash') NOT NULL DEFAULT 'draft',
            brand_id BIGINT(20) UNSIGNED DEFAULT NULL,
            is_featured TINYINT(1) NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY slug (slug(191)),
            KEY parent_id (parent_id),
            KEY path (path(191)),
            KEY status (status),
            KEY is_featured (is_featured),
            KEY depth (depth),
            KEY position (position),
            KEY product_count (product_count),
            KEY path_status (path(191), status),
            KEY content_status (content_status),
            KEY parent_status (parent_id, status),
            KEY brand_id (brand_id)
        ) ENGINE=InnoDB $charset_collate;";

        // Category-Product Relationships (M2M)
        $sql_category_products = "CREATE TABLE {$tables['category_products']} (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            category_id BIGINT(20) UNSIGNED NOT NULL,
            product_id BIGINT(20) UNSIGNED NOT NULL,
            position INT(11) NOT NULL DEFAULT 0,
            is_primary TINYINT(1) NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY category_product (category_id, product_id),
            KEY product_id (product_id),
            KEY is_primary (is_primary),
            KEY position (position),
            KEY category_position (category_id, position, product_id)
        ) ENGINE=InnoDB $charset_collate;";

        // Category Meta (Flexible key-value storage)
        $sql_category_meta = "CREATE TABLE {$tables['category_meta']} (
            meta_id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            category_id BIGINT(20) UNSIGNED NOT NULL,
            meta_key VARCHAR(255) NOT NULL,
            meta_value LONGTEXT,
            PRIMARY KEY (meta_id),
            KEY category_id (category_id),
            KEY meta_key (meta_key(191))
        ) ENGINE=InnoDB $charset_collate;";

        // Category Queue (Keyword search queue)
        // v1.4.0: Added search_status, scrape_progress, ai_status, assigned_category_id, ai_analysis_result
        // v1.5.0: Added suggested_categories, cat_ai_generation_id for category standardization
        // v1.6.0: Added custom_category_path for manually assigned category path
        $sql_queue = "CREATE TABLE {$tables['queue']} (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            keyword VARCHAR(255) NOT NULL,
            search_limit SMALLINT(5) UNSIGNED NOT NULL DEFAULT 20,
            max_search_pages TINYINT(3) UNSIGNED NOT NULL DEFAULT 3,
            search_domain VARCHAR(20) DEFAULT 'amazon.com',
            status ENUM('pending', 'processing', 'searched', 'ready_for_ai', 'completed', 'failed') NOT NULL DEFAULT 'pending',
            search_status ENUM('not_searched', 'searching', 'completed', 'failed') NOT NULL DEFAULT 'not_searched',
            scrape_progress TINYINT(3) UNSIGNED NOT NULL DEFAULT 0,
            ai_status ENUM('not_started', 'waiting_scrape', 'analyzing_category', 'category_assigned', 'generating_content', 'completed', 'failed') NOT NULL DEFAULT 'not_started',
            assigned_category_id BIGINT(20) UNSIGNED DEFAULT NULL,
            ai_analysis_result JSON DEFAULT NULL,
            suggested_categories JSON DEFAULT NULL,
            cat_ai_generation_id VARCHAR(100) DEFAULT NULL,
            custom_category_path VARCHAR(500) DEFAULT NULL,
            attempts TINYINT(3) UNSIGNED NOT NULL DEFAULT 0,
            max_attempts TINYINT(3) UNSIGNED NOT NULL DEFAULT 3,
            products_found SMALLINT(5) UNSIGNED DEFAULT 0,
            categories_created SMALLINT(5) UNSIGNED DEFAULT 0,
            linked_asins JSON DEFAULT NULL,
            started_at DATETIME DEFAULT NULL,
            completed_at DATETIME DEFAULT NULL,
            error_message TEXT DEFAULT NULL,
            processing_log JSON DEFAULT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY status (status),
            KEY search_status (search_status),
            KEY ai_status (ai_status),
            KEY status_created (status, created_at),
            KEY keyword (keyword(100)),
            KEY assigned_category (assigned_category_id),
            KEY ai_status_created (ai_status, created_at)
        ) ENGINE=InnoDB $charset_collate;";

        // Product Reviews Table (v1.7.0)
        // User reviews for individual products (ASINs)
        $sql_product_reviews = "CREATE TABLE {$tables['product_reviews']} (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            product_id BIGINT(20) UNSIGNED NOT NULL,
            asin VARCHAR(20) NOT NULL,
            user_id BIGINT(20) UNSIGNED DEFAULT NULL,
            author_name VARCHAR(100) NOT NULL,
            author_email VARCHAR(100) DEFAULT NULL,
            rating TINYINT(1) UNSIGNED NOT NULL,
            title VARCHAR(255) DEFAULT NULL,
            content TEXT NOT NULL,
            pros JSON DEFAULT NULL,
            cons JSON DEFAULT NULL,
            verified_purchase TINYINT(1) NOT NULL DEFAULT 0,
            helpful_count INT(11) UNSIGNED NOT NULL DEFAULT 0,
            unhelpful_count INT(11) UNSIGNED NOT NULL DEFAULT 0,
            status ENUM('pending', 'approved', 'spam', 'trash') NOT NULL DEFAULT 'pending',
            ip_address VARCHAR(45) DEFAULT NULL,
            user_agent VARCHAR(255) DEFAULT NULL,
            admin_notes TEXT DEFAULT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY product_id (product_id),
            KEY asin (asin),
            KEY user_id (user_id),
            KEY status (status),
            KEY rating (rating),
            KEY created_at (created_at),
            KEY product_status (product_id, status),
            KEY asin_status (asin, status)
        ) ENGINE=InnoDB $charset_collate;";

        // Run dbDelta
        dbDelta($sql_categories);
        dbDelta($sql_category_products);
        dbDelta($sql_category_meta);
        dbDelta($sql_queue);
        dbDelta($sql_product_reviews);

        // Migration: Remove priority column if exists (v1.2.0)
        $current_version = get_option(self::OPTION_KEY, '0.0.0');
        if (version_compare($current_version, '1.2.0', '<')) {
            $column_exists = $wpdb->get_var("SHOW COLUMNS FROM {$tables['queue']} LIKE 'priority'");
            if ($column_exists) {
                $wpdb->query("ALTER TABLE {$tables['queue']} DROP COLUMN priority");
                $wpdb->query("ALTER TABLE {$tables['queue']} DROP INDEX priority_status");
            }
        }

        // Migration: Add AI tracking columns (v1.3.0)
        if (version_compare($current_version, '1.3.0', '<')) {
            // Add ai_generating_at column if not exists
            $column_exists = $wpdb->get_var("SHOW COLUMNS FROM {$tables['categories']} LIKE 'ai_generating_at'");
            if (!$column_exists) {
                $wpdb->query("ALTER TABLE {$tables['categories']} ADD COLUMN ai_generating_at DATETIME DEFAULT NULL AFTER content_updated_at");
            }

            // Add ai_error_message column if not exists
            $column_exists = $wpdb->get_var("SHOW COLUMNS FROM {$tables['categories']} LIKE 'ai_error_message'");
            if (!$column_exists) {
                $wpdb->query("ALTER TABLE {$tables['categories']} ADD COLUMN ai_error_message TEXT DEFAULT NULL AFTER ai_generating_at");
            }

            // Add content_status index if not exists
            $index_exists = $wpdb->get_var("SHOW INDEX FROM {$tables['categories']} WHERE Key_name = 'content_status'");
            if (!$index_exists) {
                $wpdb->query("ALTER TABLE {$tables['categories']} ADD INDEX content_status (content_status)");
            }

            // Update content_status ENUM to include 'ai_generating'
            $column = $wpdb->get_row("SHOW COLUMNS FROM {$tables['categories']} WHERE Field = 'content_status'");
            if ($column && strpos($column->Type, 'ai_generating') === false) {
                $wpdb->query("ALTER TABLE {$tables['categories']} MODIFY COLUMN content_status ENUM('empty', 'template', 'ai_generating', 'ai_generated', 'manual') DEFAULT 'empty'");
            }
        }

        // Migration: Add AI workflow columns to queue (v1.4.0)
        if (version_compare($current_version, '1.4.0', '<')) {
            // Add max_search_pages column if not exists
            $column_exists = $wpdb->get_var("SHOW COLUMNS FROM {$tables['queue']} LIKE 'max_search_pages'");
            if (!$column_exists) {
                $wpdb->query("ALTER TABLE {$tables['queue']} ADD COLUMN max_search_pages TINYINT(3) UNSIGNED NOT NULL DEFAULT 3 AFTER search_limit");
            }

            // Add search_status column if not exists
            $column_exists = $wpdb->get_var("SHOW COLUMNS FROM {$tables['queue']} LIKE 'search_status'");
            if (!$column_exists) {
                $wpdb->query("ALTER TABLE {$tables['queue']} ADD COLUMN search_status ENUM('not_searched', 'searching', 'completed', 'failed') NOT NULL DEFAULT 'not_searched' AFTER status");
                $wpdb->query("ALTER TABLE {$tables['queue']} ADD INDEX search_status (search_status)");
            }

            // Add scrape_progress column if not exists
            $column_exists = $wpdb->get_var("SHOW COLUMNS FROM {$tables['queue']} LIKE 'scrape_progress'");
            if (!$column_exists) {
                $wpdb->query("ALTER TABLE {$tables['queue']} ADD COLUMN scrape_progress TINYINT(3) UNSIGNED NOT NULL DEFAULT 0 AFTER search_status");
            }

            // Add ai_status column if not exists
            $column_exists = $wpdb->get_var("SHOW COLUMNS FROM {$tables['queue']} LIKE 'ai_status'");
            if (!$column_exists) {
                $wpdb->query("ALTER TABLE {$tables['queue']} ADD COLUMN ai_status ENUM('not_started', 'waiting_scrape', 'analyzing_category', 'category_assigned', 'generating_content', 'completed', 'failed') NOT NULL DEFAULT 'not_started' AFTER scrape_progress");
                $wpdb->query("ALTER TABLE {$tables['queue']} ADD INDEX ai_status (ai_status)");
            }

            // Add assigned_category_id column if not exists
            $column_exists = $wpdb->get_var("SHOW COLUMNS FROM {$tables['queue']} LIKE 'assigned_category_id'");
            if (!$column_exists) {
                $wpdb->query("ALTER TABLE {$tables['queue']} ADD COLUMN assigned_category_id BIGINT(20) UNSIGNED DEFAULT NULL AFTER ai_status");
                $wpdb->query("ALTER TABLE {$tables['queue']} ADD INDEX assigned_category (assigned_category_id)");
            }

            // Add ai_analysis_result column if not exists
            $column_exists = $wpdb->get_var("SHOW COLUMNS FROM {$tables['queue']} LIKE 'ai_analysis_result'");
            if (!$column_exists) {
                $wpdb->query("ALTER TABLE {$tables['queue']} ADD COLUMN ai_analysis_result JSON DEFAULT NULL AFTER assigned_category_id");
            }

            // Update status ENUM to include new values
            $column = $wpdb->get_row("SHOW COLUMNS FROM {$tables['queue']} WHERE Field = 'status'");
            if ($column && strpos($column->Type, 'searched') === false) {
                $wpdb->query("ALTER TABLE {$tables['queue']} MODIFY COLUMN status ENUM('pending', 'processing', 'searched', 'ready_for_ai', 'completed', 'failed') NOT NULL DEFAULT 'pending'");
            }

            // Migrate existing data: set search_status based on current status
            $wpdb->query("UPDATE {$tables['queue']} SET search_status = 'completed' WHERE status IN ('completed', 'processing') AND search_status = 'not_searched' AND linked_asins IS NOT NULL");
        }

        // Migration: Add category standardization columns to queue (v1.5.0)
        if (version_compare($current_version, '1.5.0', '<')) {
            // Add suggested_categories column if not exists
            $column_exists = $wpdb->get_var("SHOW COLUMNS FROM {$tables['queue']} LIKE 'suggested_categories'");
            if (!$column_exists) {
                $wpdb->query("ALTER TABLE {$tables['queue']} ADD COLUMN suggested_categories JSON DEFAULT NULL AFTER ai_analysis_result");
            }

            // Add cat_ai_generation_id column if not exists
            $column_exists = $wpdb->get_var("SHOW COLUMNS FROM {$tables['queue']} LIKE 'cat_ai_generation_id'");
            if (!$column_exists) {
                $wpdb->query("ALTER TABLE {$tables['queue']} ADD COLUMN cat_ai_generation_id VARCHAR(100) DEFAULT NULL AFTER suggested_categories");
            }
        }

        // Migration: Add custom_category_path column to queue (v1.6.0)
        if (version_compare($current_version, '1.6.0', '<')) {
            // Add custom_category_path column if not exists
            $column_exists = $wpdb->get_var("SHOW COLUMNS FROM {$tables['queue']} LIKE 'custom_category_path'");
            if (!$column_exists) {
                $wpdb->query("ALTER TABLE {$tables['queue']} ADD COLUMN custom_category_path VARCHAR(500) DEFAULT NULL AFTER cat_ai_generation_id");
            }
        }

        // Migration: Add product reviews table (v1.7.0)
        // Table is created by dbDelta above, no additional migration needed

        // Migration: Add brand_id column to categories (v2.0.0)
        // Brand-category pages are now regular categories with brand_id set
        if (version_compare($current_version, '2.0.0', '<')) {
            $column_exists = $wpdb->get_var("SHOW COLUMNS FROM {$tables['categories']} LIKE 'brand_id'");
            if (!$column_exists) {
                $wpdb->query("ALTER TABLE {$tables['categories']} ADD COLUMN brand_id BIGINT(20) UNSIGNED DEFAULT NULL AFTER is_featured");
                $wpdb->query("ALTER TABLE {$tables['categories']} ADD INDEX brand_id (brand_id)");
            }
        }

        // Migration: Add composite indexes for performance (v1.8.0)
        if (version_compare($current_version, '1.8.0', '<')) {
            // category_products: composite for JOIN + ORDER BY position
            $idx = $wpdb->get_var("SHOW INDEX FROM {$tables['category_products']} WHERE Key_name = 'category_position'");
            if (!$idx) {
                $wpdb->query("ALTER TABLE {$tables['category_products']} ADD INDEX category_position (category_id, position, product_id)");
            }
            // categories: composite for tree/navigation queries
            $idx = $wpdb->get_var("SHOW INDEX FROM {$tables['categories']} WHERE Key_name = 'parent_status'");
            if (!$idx) {
                $wpdb->query("ALTER TABLE {$tables['categories']} ADD INDEX parent_status (parent_id, status)");
            }
            // queue: composite for monitor cron queries
            $idx = $wpdb->get_var("SHOW INDEX FROM {$tables['queue']} WHERE Key_name = 'ai_status_created'");
            if (!$idx) {
                $wpdb->query("ALTER TABLE {$tables['queue']} ADD INDEX ai_status_created (ai_status, created_at)");
            }
        }

        // Update version
        update_option(self::OPTION_KEY, self::VERSION);

        // Flush rewrite rules
        flush_rewrite_rules();
    }

    /**
     * Uninstall - Remove all tables (use with caution!)
     */
    public static function uninstall(): void
    {
        global $wpdb;
        
        $tables = self::tables();
        
        foreach ($tables as $table) {
            $wpdb->query("DROP TABLE IF EXISTS {$table}");
        }
        
        delete_option(self::OPTION_KEY);
    }

    /**
     * Check if tables exist
     */
    public static function tablesExist(): bool
    {
        global $wpdb;
        
        $tables = self::tables();
        $main_table = $tables['categories'];
        
        return $wpdb->get_var("SHOW TABLES LIKE '{$main_table}'") === $main_table;
    }
}
