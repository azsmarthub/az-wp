<?php
/**
 * Category Queue Processor Cron
 *
 * Automatically processes pending items in the category queue.
 * Runs every 5 minutes to check for pending items and process them.
 *
 * @package AffiliateCMS\Categories\Core
 */

declare(strict_types=1);

namespace AffiliateCMS\Categories\Core;

use AffiliateCMS\Categories\Database\Schema;

class CatQueueProcessorCron
{
    private static ?self $instance = null;

    /**
     * Cron hook name
     */
    public const CRON_HOOK = 'acms_cat_queue_processor';

    /**
     * Cron interval (5 minutes)
     */
    public const CRON_INTERVAL = 300;

    /**
     * Max time (seconds) an item can stay in 'processing' before auto-reset
     */
    public const STUCK_TIMEOUT = 900; // 15 minutes

    /**
     * Items per batch (keep low to avoid PHP timeout: 5 items × ~30s = ~150s)
     */
    public const BATCH_SIZE = 5;

    /**
     * Get singleton instance
     */
    public static function instance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Register cron hook
     */
    public function register(): void
    {
        add_action(self::CRON_HOOK, [$this, 'run']);

        // WP-Cron as safety net (server cron is primary)
        if (!wp_next_scheduled(self::CRON_HOOK)) {
            wp_schedule_event(time(), 'acms_5min', self::CRON_HOOK);
        }
    }

    /**
     * Run the processor
     *
     * Called by server cron (curl) every 2 minutes. Multiple concurrent calls
     * are safe because QueueProcessor::processNext() uses atomic claim.
     *
     * @return array Result summary
     */
    public function run(): array
    {
        if (!Schema::tablesExist()) {
            return ['success' => true, 'message' => 'Tables not created yet', 'processed' => 0];
        }

        global $wpdb;
        $table = Schema::queueTable();

        // Auto-reset stuck items first (processing > STUCK_TIMEOUT)
        $resetCount = $this->resetStuckItems($table);

        // Count pending items
        $pendingCount = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$table} WHERE status = 'pending'"
        );

        if ($pendingCount === 0) {
            return [
                'success' => true,
                'message' => 'No pending items in queue',
                'processed' => 0,
                'reset' => $resetCount,
            ];
        }

        // Process batch — each item is atomically claimed, safe for concurrent calls
        $batchSize = self::BATCH_SIZE;
        $processed = 0;
        $failed = 0;
        $results = [];

        $processor = new QueueProcessor(true);

        for ($i = 0; $i < $batchSize; $i++) {
            $result = $processor->processNext();

            if ($result['queue_id'] === null) {
                // No more pending items available
                break;
            }

            if ($result['success']) {
                $processed++;
            } else {
                $failed++;
            }

            $results[] = [
                'queue_id' => $result['queue_id'],
                'status' => $result['success'] ? 'success' : 'failed',
                'message' => $result['message'],
            ];
        }

        error_log("[ACMS CatQueueProcessorCron] Batch done: {$processed} ok, {$failed} failed, {$pendingCount} were pending, {$resetCount} reset");

        return [
            'success' => true,
            'message' => "Processed {$processed} items" . ($failed > 0 ? ", {$failed} failed" : ''),
            'processed' => $processed,
            'failed' => $failed,
            'reset' => $resetCount,
            'pending_remaining' => max(0, $pendingCount - $processed),
            'results' => $results,
        ];
    }

    /**
     * Run manually (for admin use)
     *
     * @return array Result
     */
    public function runManually(): array
    {
        $startTime = microtime(true);
        $result = $this->run();
        $duration = round((microtime(true) - $startTime) * 1000);

        return array_merge($result, [
            'duration_ms' => $duration,
        ]);
    }

    /**
     * Get queue statistics
     *
     * @return array Stats
     */
    public function getStats(): array
    {
        global $wpdb;
        $table = Schema::queueTable();

        return [
            'pending' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE status = 'pending'"),
            'processing' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE status = 'processing'"),
            'completed' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE search_status = 'completed'"),
            'failed' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE status = 'failed'"),
        ];
    }

    /**
     * Auto-reset items stuck in 'processing' for too long
     *
     * When PHP gets killed (OOM, timeout) mid-processing, items stay stuck
     * in 'processing' status forever, blocking the entire queue.
     * This resets them to 'pending' (retry) or 'failed' (max attempts reached).
     */
    private function resetStuckItems(string $table): int
    {
        global $wpdb;

        $timeout = self::STUCK_TIMEOUT;

        // Find items stuck in processing beyond timeout
        // Use started_at if available, fall back to updated_at
        // Note: timestamps stored via current_time('mysql') (local), so compare with local threshold
        $stuckThreshold = gmdate('Y-m-d H:i:s', current_time('timestamp') - $timeout);
        $stuckItems = $wpdb->get_results($wpdb->prepare(
            "SELECT id, keyword, attempts, max_attempts, search_status
             FROM {$table}
             WHERE status = 'processing'
               AND (
                   (started_at IS NOT NULL AND started_at < %s)
                   OR (started_at IS NULL AND updated_at < %s)
               )",
            $stuckThreshold,
            $stuckThreshold
        ));

        if (empty($stuckItems)) {
            return 0;
        }

        foreach ($stuckItems as $item) {
            $attempts = (int) $item->attempts;
            $maxAttempts = (int) $item->max_attempts;
            $newStatus = ($attempts >= $maxAttempts) ? 'failed' : 'pending';

            $updateData = [
                'status' => $newStatus,
                'error_message' => "Auto-reset: stuck in processing for >{$timeout}s (attempt {$attempts}/{$maxAttempts})",
            ];

            // Also reset search_status if it was mid-search
            if ($item->search_status === 'searching') {
                $updateData['search_status'] = 'not_searched';
            }

            $wpdb->update($table, $updateData, ['id' => $item->id]);

            error_log("[ACMS CatQueueProcessorCron] Auto-reset stuck item #{$item->id} \"{$item->keyword}\" → {$newStatus} (attempt {$attempts}/{$maxAttempts})");
        }

        return count($stuckItems);
    }

    /**
     * Unschedule the cron
     */
    public function unschedule(): void
    {
        $timestamp = wp_next_scheduled(self::CRON_HOOK);
        if ($timestamp) {
            wp_unschedule_event($timestamp, self::CRON_HOOK);
        }
    }
}
