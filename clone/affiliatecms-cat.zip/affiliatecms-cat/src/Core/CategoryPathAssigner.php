<?php
/**
 * Category Path Assigner
 *
 * Handles automatic category assignment for queue items.
 * Uses majority voting from product category_path fields to determine hierarchy,
 * then replaces the last segment with the queue keyword.
 *
 * Flow:
 * 1. Majority voting finds the most common category path among linked products
 * 2. If keyword matches a path segment → truncate at that segment
 *    Otherwise → drop last segment, append keyword
 * 3. Create/find category hierarchy from the resulting path
 * 4. Link products to category
 * 5. Trigger CategoryAiCron for content generation
 *
 * Examples:
 *   Keyword: "Wireless Headphones"
 *   Winning path: "Electronics > Audio > Headphones > Over-Ear Headphones"
 *   Final path:   "Electronics > Audio > Headphones > Wireless Headphones"
 *
 *   Keyword: "Coffee Makers"
 *   Winning path: "Home & Kitchen > Kitchen & Dining > Coffee Makers > Coffee Machines"
 *   Final path:   "Home & Kitchen > Kitchen & Dining > Coffee Makers"
 *
 * @package AffiliateCMS\Categories\Core
 */

declare(strict_types=1);

namespace AffiliateCMS\Categories\Core;

use AffiliateCMS\Categories\Database\Schema;
use AffiliateCMS\Categories\Repositories\CategoryRepository;
use AffiliateCMS\Categories\Repositories\QueueRepository;

class CategoryPathAssigner
{
    private static ?CategoryPathAssigner $instance = null;
    private CategoryRepository $categoryRepo;
    private QueueRepository $queueRepo;

    /**
     * Get singleton instance
     */
    public static function instance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct()
    {
        $this->categoryRepo = new CategoryRepository();
        $this->queueRepo = new QueueRepository();
    }

    /**
     * Register hooks
     */
    public function register(): void
    {
        // Listen for when queue items are ready for AI processing
        add_action('acms_category_ready_for_ai', [$this, 'handleReadyForAi'], 10, 2);
    }

    /**
     * Handle queue item ready for category assignment
     *
     * Uses majority voting to determine parent path, then appends keyword as final category.
     *
     * @param int $queueId Queue item ID
     * @param array $linkedAsins List of linked ASINs
     */
    public function handleReadyForAi(int $queueId, array $linkedAsins): void
    {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("[ACMS CategoryPathAssigner] Processing queue {$queueId} with majority voting + keyword");
        }

        $this->assignByMajorityVoting($queueId, $linkedAsins);
    }

    /**
     * Assign category using majority voting from product category paths
     *
     * The winning path provides the parent hierarchy. If the keyword matches an existing
     * segment in the path, the path is truncated at that segment (preventing unwanted
     * children from being created). Otherwise, the last segment is dropped and replaced
     * with the queue keyword.
     *
     * Examples:
     *   Keyword: "Wireless Headphones"
     *   Winning path: "Electronics > Audio > Headphones > Over-Ear Headphones"
     *   (no match)    → Drop last, append keyword
     *   Final path:   "Electronics > Audio > Headphones > Wireless Headphones"
     *
     *   Keyword: "Coffee Makers"
     *   Winning path: "Home & Kitchen > Kitchen & Dining > Coffee Makers > Coffee Machines"
     *   (match at 2)  → Truncate at "Coffee Makers"
     *   Final path:   "Home & Kitchen > Kitchen & Dining > Coffee Makers"
     *
     * @param int $queueId Queue item ID
     * @param array $linkedAsins List of ASINs
     */
    public function assignByMajorityVoting(int $queueId, array $linkedAsins): void
    {
        global $wpdb;

        $queueTable = Schema::queueTable();

        try {
            // Get the queue item to get the keyword
            $queueItem = $this->queueRepo->find($queueId);
            $keyword = $queueItem['keyword'] ?? '';

            if (empty($keyword)) {
                $this->updateQueueStatus($queueId, 'failed', 'No keyword found in queue item');
                return;
            }

            // Get product category paths
            $categoryPaths = $this->getProductCategoryPaths($linkedAsins);

            if (empty($categoryPaths)) {
                $this->updateQueueStatus($queueId, 'failed', 'No category paths found in products');
                return;
            }

            // Find the most common full category path (majority voting)
            $winningPath = $this->findMajorityPath($categoryPaths);

            if (empty($winningPath)) {
                $this->updateQueueStatus($queueId, 'failed', 'Could not determine majority category path');
                return;
            }

            // Build final category path from winning path + keyword
            $segments = array_values(array_filter(array_map('trim', explode('>', $winningPath))));

            // Check if keyword already matches a segment in the path (case-insensitive)
            // e.g., keyword "Coffee Makers" in "...Coffee Makers > Coffee Machines" → truncate at "Coffee Makers"
            $keywordLower = mb_strtolower($keyword);
            $matchIndex = null;
            foreach ($segments as $i => $seg) {
                if (mb_strtolower($seg) === $keywordLower) {
                    $matchIndex = $i;
                    break;
                }
            }

            if ($matchIndex !== null) {
                // Keyword found in path → truncate at that segment (inclusive)
                // Prevents creating unwanted children after the keyword
                $segments = array_slice($segments, 0, $matchIndex + 1);
            } elseif (count($segments) > 1) {
                // Keyword not in path → drop Amazon's leaf category, append keyword
                array_pop($segments);
                $segments[] = $keyword;
            } else {
                // Single-segment path: use it as parent, keyword as child
                $segments[] = $keyword;
            }

            $finalPath = implode(' > ', $segments);

            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("[ACMS CategoryPathAssigner] Queue {$queueId}: voting path '{$winningPath}' → final '{$finalPath}'");
            }

            // Create/find the full category hierarchy
            $categoryId = $this->findOrCreateCategoryFromPath($finalPath);

            if (!$categoryId) {
                $this->updateQueueStatus($queueId, 'failed', 'Failed to create category from path: ' . $finalPath);
                return;
            }

            // IMPORTANT: Link products to the category and update their custom_category_paths
            $linkedCount = $this->linkProductsToCategory($categoryId, $linkedAsins, $finalPath);

            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("[ACMS CategoryPathAssigner] Linked {$linkedCount} products to category {$categoryId}");
            }

            // Update queue item with assigned category (clear any previous error)
            $this->queueRepo->update($queueId, [
                'custom_category_path' => $finalPath,
                'assigned_category_id' => $categoryId,
                'ai_status' => 'category_assigned',
                'status' => 'ready_for_ai',
                'error_message' => null,
            ]);

            // Append to processing log
            $this->appendLog($queueId, 'category_assigned', "Category assigned via majority voting: {$finalPath} (ID: {$categoryId}), {$linkedCount} products linked");

            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("[ACMS CategoryPathAssigner] Queue {$queueId} assigned to category {$categoryId}: {$finalPath}");
            }

            // Fire hook for further processing (e.g., content generation)
            do_action('acms_category_assigned', $queueId, $categoryId, $finalPath);

            // Trigger CategoryAiCron to process the newly assigned category
            $this->triggerCategoryAiCron();

        } catch (\Throwable $e) {
            $this->updateQueueStatus($queueId, 'failed', 'Error: ' . $e->getMessage());
            error_log("[ACMS CategoryPathAssigner] Error for queue {$queueId}: " . $e->getMessage());
        }
    }

    /**
     * Link products to category by their ASINs
     *
     * Also updates each product's `custom_category_paths` field so the
     * product edit modal shows the assigned category path.
     * Uses ProductRepository::appendCategoryPaths() to safely merge paths
     * (one ASIN can belong to multiple categories from different queue items).
     *
     * @param int $categoryId Category ID
     * @param array $asins List of ASINs
     * @param string|null $categoryPath The assigned category path (e.g. "Electronics > Audio > Headphones")
     * @return int Number of products linked
     */
    private function linkProductsToCategory(int $categoryId, array $asins, ?string $categoryPath = null): int
    {
        global $wpdb;

        if (empty($asins)) {
            return 0;
        }

        $productsTable = $wpdb->prefix . 'acms_products';
        $linkedCount = 0;

        // Get product IDs from ASINs
        $placeholders = implode(',', array_fill(0, count($asins), '%s'));
        $products = $wpdb->get_results($wpdb->prepare(
            "SELECT id, asin FROM {$productsTable} WHERE asin IN ({$placeholders}) AND status = 'scraped'",
            ...$asins
        ), ARRAY_A);

        if (empty($products)) {
            return 0;
        }

        // Get ProductRepository for path updates
        $productRepo = class_exists(\AffiliateCMS\Pro\Repositories\ProductRepository::class)
            ? \AffiliateCMS\Pro\Repositories\ProductRepository::instance()
            : null;

        // Link each product to the category
        foreach ($products as $index => $product) {
            $isPrimary = ($index === 0); // First product is primary
            $added = $this->categoryRepo->addProduct($categoryId, (int) $product['id'], $isPrimary);
            if ($added) {
                $linkedCount++;
            }

            // Append path to product's custom_category_paths (safe merge, no overwrite)
            if ($categoryPath !== null && $productRepo !== null) {
                $productRepo->appendCategoryPaths((int) $product['id'], [$categoryPath]);
            }
        }

        return $linkedCount;
    }

    /**
     * Trigger CategoryAiCron via API endpoint
     *
     * Uses non-blocking request to avoid waiting
     */
    private function triggerCategoryAiCron(): void
    {
        $apiToken = get_option('acms_api_token', '');

        if (empty($apiToken)) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('[ACMS CategoryPathAssigner] Cannot trigger CategoryAiCron - no API token');
            }
            return;
        }

        // Trigger Category AI cron endpoint
        $cronUrl = rest_url('acms-cat/v1/cron/category-ai') . '?token=' . urlencode($apiToken);

        wp_remote_post($cronUrl, [
            'timeout' => 0.5,
            'blocking' => false,
            'sslverify' => false,
            'headers' => [
                'User-Agent' => 'ACMS-CategoryAssigner/1.0',
            ],
        ]);

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[ACMS CategoryPathAssigner] Triggered CategoryAiCron via API');
        }
    }

    /**
     * Get category paths from products
     *
     * @param array $asins List of ASINs
     * @return array List of category paths
     */
    private function getProductCategoryPaths(array $asins): array
    {
        global $wpdb;

        if (empty($asins)) {
            return [];
        }

        $productsTable = $wpdb->prefix . 'acms_products';
        $placeholders = implode(',', array_fill(0, count($asins), '%s'));

        // Get category_path from scraped products
        $paths = $wpdb->get_col($wpdb->prepare(
            "SELECT category_path FROM {$productsTable}
             WHERE asin IN ({$placeholders})
             AND status = 'scraped'
             AND category_path IS NOT NULL
             AND category_path != ''",
            ...$asins
        ));

        return array_filter($paths);
    }

    /**
     * Find the most common category path using majority voting
     *
     * @param array $paths List of category paths
     * @return string|null The winning path
     */
    private function findMajorityPath(array $paths): ?string
    {
        if (empty($paths)) {
            return null;
        }

        // Normalize paths (trim, standardize separators)
        $normalized = [];
        foreach ($paths as $path) {
            // Normalize: trim, replace various separators with " > "
            $path = trim($path);
            // Handle different separator formats: " > ", " >> ", " / ", " | "
            $path = preg_replace('/\s*[>\|\/]+\s*/', ' > ', $path);
            $path = trim($path, ' >');

            if (!empty($path)) {
                $normalized[] = $path;
            }
        }

        if (empty($normalized)) {
            return null;
        }

        // Count occurrences
        $counts = array_count_values($normalized);

        // Sort by count descending
        arsort($counts);

        // Return the most common path
        return array_key_first($counts);
    }

    /**
     * Find or create a category hierarchy from a path string
     *
     * @param string $pathString Category path like "Electronics > Audio > Headphones"
     * @return int|null Category ID of the deepest (leaf) category
     */
    public function findOrCreateCategoryFromPath(string $pathString): ?int
    {
        global $wpdb;

        // Parse the path into segments
        $segments = array_map('trim', explode('>', $pathString));
        $segments = array_filter($segments);

        if (empty($segments)) {
            return null;
        }

        $parentId = 0;
        $lastCategoryId = null;

        foreach ($segments as $index => $segmentName) {
            // Try to find existing category with this name under this parent
            $existingCategory = $this->findCategoryByNameAndParent($segmentName, $parentId);

            if ($existingCategory) {
                // Category exists, use it
                $lastCategoryId = (int) $existingCategory['id'];
            } else {
                // Create new category — don't pass slug, let create() generate unique slug
                // (slug column has UNIQUE constraint, so "food" under different parents would collide)
                $newCategoryId = $this->categoryRepo->create([
                    'name' => $segmentName,
                    'parent_id' => $parentId,
                    'status' => 'publish',
                    'content_status' => 'empty',
                ]);

                if (!$newCategoryId) {
                    error_log("[ACMS CategoryPathAssigner] Failed to create category: {$segmentName} under parent {$parentId}, DB error: " . ($wpdb->last_error ?: 'none'));
                    return null;
                }

                $lastCategoryId = $newCategoryId;

                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log("[ACMS CategoryPathAssigner] Created category: {$segmentName} (ID: {$newCategoryId}) under parent {$parentId}");
                }
            }

            // Move to next level
            $parentId = $lastCategoryId;
        }

        return $lastCategoryId;
    }

    /**
     * Find a category by name and parent ID
     *
     * @param string $name Category name
     * @param int $parentId Parent category ID
     * @return array|null Category data
     */
    private function findCategoryByNameAndParent(string $name, int $parentId): ?array
    {
        global $wpdb;
        $table = Schema::categoriesTable();

        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table} WHERE name = %s AND parent_id = %d LIMIT 1",
            $name,
            $parentId
        ), ARRAY_A) ?: null;
    }

    /**
     * Update queue status with error
     *
     * @param int $queueId Queue item ID
     * @param string $status Status
     * @param string $message Error message
     */
    private function updateQueueStatus(int $queueId, string $status, string $message): void
    {
        $this->queueRepo->update($queueId, [
            'status' => $status,
            'ai_status' => $status === 'failed' ? 'failed' : 'category_assigned',
            'error_message' => $status === 'failed' ? $message : null,
        ]);

        $this->appendLog($queueId, 'category_assigner', $message);
    }

    /**
     * Append to processing log
     *
     * @param int $queueId Queue item ID
     * @param string $step Step name
     * @param string $message Log message
     */
    private function appendLog(int $queueId, string $step, string $message): void
    {
        global $wpdb;
        $table = Schema::queueTable();

        $currentLog = $wpdb->get_var($wpdb->prepare(
            "SELECT processing_log FROM {$table} WHERE id = %d",
            $queueId
        ));

        $logData = $currentLog ? json_decode($currentLog, true) : ['log' => [], 'errors' => []];

        $logData['log'][] = [
            'step' => $step,
            'timestamp' => current_time('mysql'),
            'message' => $message,
        ];

        $logData['last_updated'] = current_time('mysql');

        $wpdb->update($table, [
            'processing_log' => wp_json_encode($logData),
        ], ['id' => $queueId]);
    }

    /**
     * Manually trigger category assignment for a queue item
     * Used when user wants to bypass AI and use majority voting
     *
     * @param int $queueId Queue item ID
     * @return array Result
     */
    public function triggerManually(int $queueId): array
    {
        $item = $this->queueRepo->find($queueId);

        if (!$item) {
            return [
                'success' => false,
                'message' => 'Queue item not found',
            ];
        }

        $rawAsins = $item['linked_asins'] ?? '[]';
        $linkedAsins = is_array($rawAsins) ? $rawAsins : json_decode($rawAsins, true);

        if (empty($linkedAsins)) {
            return [
                'success' => false,
                'message' => 'No linked ASINs found',
            ];
        }

        // Clear previous assignment and error
        $this->queueRepo->update($queueId, [
            'suggested_categories' => null,
            'assigned_category_id' => null,
            'custom_category_path' => null,
            'ai_status' => 'analyzing_category',
            'status' => 'searched',
            'error_message' => null,
        ]);

        // Run majority voting
        $this->assignByMajorityVoting($queueId, $linkedAsins);

        // Check result
        $updatedItem = $this->queueRepo->find($queueId);

        if ($updatedItem && !empty($updatedItem['assigned_category_id'])) {
            return [
                'success' => true,
                'message' => 'Category assigned: ' . ($updatedItem['custom_category_path'] ?? 'Unknown'),
                'category_id' => (int) $updatedItem['assigned_category_id'],
                'category_path' => $updatedItem['custom_category_path'],
            ];
        }

        return [
            'success' => false,
            'message' => $updatedItem['error_message'] ?? 'Failed to assign category',
        ];
    }
}
