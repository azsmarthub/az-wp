<?php
/**
 * Category Queue Monitor
 *
 * Monitors the category queue for items that are waiting for scrape completion.
 * When scrape progress reaches threshold (default 50%), marks item as ready for AI processing.
 *
 * Workflow:
 * 1. Find items with ai_status='waiting_scrape'
 * 2. Calculate scrape progress for each item's linked_asins
 * 3. If progress >= threshold, update to 'ready_for_ai' and queue AI job
 * 4. Handle timeout (items waiting too long)
 *
 * @package AffiliateCMS\Categories\Core
 */

declare(strict_types=1);

namespace AffiliateCMS\Categories\Core;

use AffiliateCMS\Categories\Database\Schema;

class CategoryQueueMonitor
{
    private static ?CategoryQueueMonitor $instance = null;

    /**
     * Minimum scrape progress percentage to proceed with AI (0-100)
     */
    private const SCRAPE_THRESHOLD = 50;

    /**
     * Maximum wait time for scraping (in hours)
     */
    private const SCRAPE_TIMEOUT_HOURS = 24;

    /**
     * Cron hook name
     */
    public const CRON_HOOK = 'acms_cat_queue_monitor';

    /**
     * Cron interval (5 minutes)
     */
    public const CRON_INTERVAL = 300;

    /**
     * Get singleton instance
     */
    public static function instance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Register cron hook
     */
    public function register(): void
    {
        add_action(self::CRON_HOOK, [$this, 'run']);

        // WP-Cron as safety net (server cron is primary)
        if (!wp_next_scheduled(self::CRON_HOOK)) {
            wp_schedule_event(time(), 'acms_5min', self::CRON_HOOK);
        }
    }

    /**
     * Unschedule the cron
     */
    public function unschedule(): void
    {
        $timestamp = wp_next_scheduled(self::CRON_HOOK);
        if ($timestamp) {
            wp_unschedule_event($timestamp, self::CRON_HOOK);
        }
    }

    /**
     * Register custom cron interval
     */
    public static function registerCronInterval(array $schedules): array
    {
        if (!isset($schedules['acms_5min'])) {
            $schedules['acms_5min'] = [
                'interval' => self::CRON_INTERVAL,
                'display' => __('Every 5 Minutes', 'affiliatecms-cat'),
            ];
        }
        return $schedules;
    }

    /**
     * Run the monitor
     *
     * @return array Result summary
     */
    public function run(): array
    {
        if (!Schema::tablesExist()) {
            return ['success' => true, 'message' => 'Tables not created yet', 'processed' => 0];
        }

        global $wpdb;
        $table = Schema::queueTable();
        $productsTable = $wpdb->prefix . 'acms_products';

        $processed = 0;
        $readyForAi = 0;
        $timedOut = 0;
        $errors = [];

        // Always run housekeeping tasks first (independent of waiting_scrape items)
        // Refresh stale scrape_progress for items that moved past waiting_scrape
        $refreshed = $this->refreshStaleScrapeProgress($table, $productsTable);

        // Auto-retry items stuck at analyzing_category for > 5 minutes
        $retried = $this->retryStuckAnalyzing($table);

        // Fix orphaned items: status='searched' with linked_asins but search_status != 'completed'
        // This happens when processNext() overwrites search_status on retry and stepSearchAsins early-returns
        $fixedOrphans = $this->fixOrphanedSearchedItems($table);

        // Find items waiting for scrape
        $items = $wpdb->get_results(
            "SELECT * FROM {$table}
             WHERE ai_status = 'waiting_scrape'
             AND search_status = 'completed'
             ORDER BY created_at ASC
             LIMIT 50",
            ARRAY_A
        );

        if (!empty($items)) {
            foreach ($items as $item) {
                $processed++;
                $queueId = (int) $item['id'];

                try {
                    // Get linked ASINs (handle already-decoded JSON)
                    $rawAsins = $item['linked_asins'] ?? null;
                    $linkedAsins = $rawAsins
                        ? (is_array($rawAsins) ? $rawAsins : json_decode($rawAsins, true))
                        : [];

                    if (empty($linkedAsins)) {
                        // No ASINs - mark as failed
                        $this->markFailed($queueId, 'No ASINs linked');
                        $errors[] = "Queue {$queueId}: No ASINs linked";
                        continue;
                    }

                    // Calculate scrape progress
                    $totalAsins = count($linkedAsins);
                    $scrapedCount = $this->countScrapedAsins($linkedAsins, $productsTable);
                    $progress = $totalAsins > 0 ? (int) round(($scrapedCount / $totalAsins) * 100) : 0;

                    // Update progress in database
                    $wpdb->update($table, [
                        'scrape_progress' => $progress,
                    ], ['id' => $queueId]);

                    // Check if ready
                    $isReady = false;
                    $reason = '';

                    // Condition 1: Progress >= threshold
                    if ($progress >= self::SCRAPE_THRESHOLD) {
                        $isReady = true;
                        $reason = "Scrape progress {$progress}% >= threshold " . self::SCRAPE_THRESHOLD . "%";
                    }

                    // Condition 2: All ASINs scraped
                    if ($scrapedCount >= $totalAsins) {
                        $isReady = true;
                        $reason = "All {$totalAsins} ASINs scraped";
                    }

                    // Condition 3: Timeout
                    $startedAt = strtotime($item['started_at'] ?? $item['created_at']);
                    $hoursWaiting = (time() - $startedAt) / 3600;

                    if ($hoursWaiting >= self::SCRAPE_TIMEOUT_HOURS) {
                        $isReady = true;
                        $reason = "Timeout after {$hoursWaiting}h (threshold: " . self::SCRAPE_TIMEOUT_HOURS . "h)";
                        $timedOut++;
                    }

                    if ($isReady) {
                        // Mark as ready for AI
                        $this->markReadyForAi($queueId, $reason, $progress);
                        $readyForAi++;

                        // Fire hook for AI processing
                        do_action('acms_category_ready_for_ai', $queueId, $linkedAsins);
                    }

                } catch (\Exception $e) {
                    $errors[] = "Queue {$queueId}: " . $e->getMessage();
                }
            }
        }

        return [
            'success' => true,
            'message' => "Processed {$processed} items, {$readyForAi} ready for AI, {$timedOut} timed out, {$refreshed} refreshed, {$retried} analyzing retried, {$fixedOrphans} orphans fixed",
            'processed' => $processed,
            'ready_for_ai' => $readyForAi,
            'timed_out' => $timedOut,
            'refreshed' => $refreshed,
            'retried_analyzing' => $retried,
            'fixed_orphans' => $fixedOrphans,
            'errors' => $errors,
        ];
    }

    /**
     * Refresh scrape_progress for items no longer in waiting_scrape state
     * but whose stored progress is stale (< 100%).
     */
    private function refreshStaleScrapeProgress(string $table, string $productsTable): int
    {
        global $wpdb;

        $items = $wpdb->get_results(
            "SELECT id, linked_asins, scrape_progress FROM {$table}
             WHERE scrape_progress < 100
             AND ai_status != 'waiting_scrape'
             AND linked_asins IS NOT NULL
             AND linked_asins != '[]'
             LIMIT 50",
            ARRAY_A
        );

        if (empty($items)) {
            return 0;
        }

        $refreshed = 0;
        foreach ($items as $item) {
            $rawAsins = $item['linked_asins'] ?? null;
            $linkedAsins = $rawAsins
                ? (is_array($rawAsins) ? $rawAsins : json_decode($rawAsins, true))
                : [];

            if (empty($linkedAsins)) {
                continue;
            }

            $totalAsins = count($linkedAsins);
            $scrapedCount = $this->countScrapedAsins($linkedAsins, $productsTable);
            $progress = $totalAsins > 0 ? (int) round(($scrapedCount / $totalAsins) * 100) : 0;

            if ($progress !== (int) ($item['scrape_progress'] ?? 0)) {
                $wpdb->update($table, [
                    'scrape_progress' => $progress,
                ], ['id' => (int) $item['id']]);
                $refreshed++;
            }
        }

        return $refreshed;
    }

    /**
     * Count how many ASINs have been scraped
     *
     * @param array $asins List of ASINs
     * @param string $productsTable Products table name
     * @return int Count of scraped ASINs
     */
    private function countScrapedAsins(array $asins, string $productsTable): int
    {
        global $wpdb;

        if (empty($asins)) {
            return 0;
        }

        $placeholders = implode(',', array_fill(0, count($asins), '%s'));

        // Count ASINs that have status='scraped' (fully scraped)
        $count = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$productsTable}
             WHERE asin IN ({$placeholders})
             AND status = 'scraped'",
            ...$asins
        ));

        return $count;
    }

    /**
     * Mark queue item as ready for AI
     *
     * @param int $queueId Queue item ID
     * @param string $reason Reason for marking ready
     * @param int $progress Current scrape progress
     */
    private function markReadyForAi(int $queueId, string $reason, int $progress): void
    {
        global $wpdb;
        $table = Schema::queueTable();

        $wpdb->update($table, [
            'status' => 'ready_for_ai',
            'ai_status' => 'analyzing_category',
            'scrape_progress' => $progress,
            'processing_log' => $this->appendLog($queueId, 'monitor', "Ready for AI: {$reason}"),
        ], ['id' => $queueId]);
    }

    /**
     * Fix orphaned items that have linked_asins and status='searched' but
     * search_status is not 'completed' or ai_status is not 'waiting_scrape'.
     *
     * This happens when processNext() overwrites search_status='searching' on retry
     * and stepSearchAsins() early-returns without restoring it (pre-fix items).
     */
    private function fixOrphanedSearchedItems(string $table): int
    {
        global $wpdb;

        $fixed = (int) $wpdb->query(
            "UPDATE {$table}
             SET search_status = 'completed',
                 ai_status = 'waiting_scrape'
             WHERE status = 'searched'
               AND linked_asins IS NOT NULL
               AND linked_asins != '[]'
               AND (search_status != 'completed' OR ai_status != 'waiting_scrape')"
        );

        if ($fixed > 0) {
            error_log("[ACMS Monitor] Fixed {$fixed} orphaned searched items (search_status/ai_status mismatch)");
        }

        return $fixed;
    }

    /**
     * Auto-retry items stuck at analyzing_category for > 5 minutes.
     * Re-fires acms_category_ready_for_ai hook so CategoryPathAssigner processes them.
     */
    private function retryStuckAnalyzing(string $table): int
    {
        global $wpdb;

        $localTs = current_time('timestamp');
        $threshold = date('Y-m-d H:i:s', $localTs - 300); // 5 min

        $stuckItems = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, linked_asins
                 FROM {$table}
                 WHERE status = 'ready_for_ai'
                 AND ai_status = 'analyzing_category'
                 AND (updated_at < %s OR updated_at IS NULL)
                 AND linked_asins IS NOT NULL
                 AND linked_asins != '[]'
                 LIMIT 20",
                $threshold
            ),
            ARRAY_A
        );

        if (empty($stuckItems)) {
            return 0;
        }

        $retried = 0;
        foreach ($stuckItems as $item) {
            $queueId = (int) $item['id'];
            $linkedAsins = is_array($item['linked_asins'])
                ? $item['linked_asins']
                : json_decode($item['linked_asins'] ?? '[]', true);

            if (!empty($linkedAsins)) {
                error_log("[ACMS Monitor] Retrying stuck analyzing_category queue #{$queueId}");
                do_action('acms_category_ready_for_ai', $queueId, $linkedAsins);
                $retried++;
            }
        }

        if ($retried > 0) {
            error_log("[ACMS Monitor] Auto-retried {$retried} items stuck at analyzing_category");
        }

        return $retried;
    }

    /**
     * Mark queue item as failed
     *
     * @param int $queueId Queue item ID
     * @param string $reason Failure reason
     */
    private function markFailed(int $queueId, string $reason): void
    {
        global $wpdb;
        $table = Schema::queueTable();

        $wpdb->update($table, [
            'status' => 'failed',
            'ai_status' => 'failed',
            'error_message' => $reason,
            'processing_log' => $this->appendLog($queueId, 'monitor', "Failed: {$reason}"),
        ], ['id' => $queueId]);
    }

    /**
     * Append to processing log
     *
     * @param int $queueId Queue item ID
     * @param string $step Step name
     * @param string $message Log message
     * @return string Updated JSON log
     */
    private function appendLog(int $queueId, string $step, string $message): string
    {
        global $wpdb;
        $table = Schema::queueTable();

        $currentLog = $wpdb->get_var($wpdb->prepare(
            "SELECT processing_log FROM {$table} WHERE id = %d",
            $queueId
        ));

        $logData = $currentLog ? json_decode($currentLog, true) : ['log' => [], 'errors' => []];

        $logData['log'][] = [
            'step' => $step,
            'timestamp' => current_time('mysql'),
            'message' => $message,
        ];

        $logData['last_updated'] = current_time('mysql');

        return wp_json_encode($logData);
    }

    /**
     * Run manually (for admin use)
     *
     * @return array Result
     */
    public function runManually(): array
    {
        $startTime = microtime(true);
        $result = $this->run();
        $duration = round((microtime(true) - $startTime) * 1000);

        return array_merge($result, [
            'duration_ms' => $duration,
        ]);
    }

    /**
     * Get queue items waiting for scrape with progress info
     *
     * @return array List of items with scrape progress
     */
    public function getWaitingItems(): array
    {
        global $wpdb;
        $table = Schema::queueTable();

        return $wpdb->get_results(
            "SELECT id, keyword, products_found, scrape_progress, created_at, started_at
             FROM {$table}
             WHERE ai_status = 'waiting_scrape'
             ORDER BY created_at ASC",
            ARRAY_A
        );
    }
}
