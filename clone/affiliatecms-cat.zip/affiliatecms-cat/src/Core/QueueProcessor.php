<?php
/**
 * Category Queue Processor
 *
 * Processes keyword queue items to find and save Amazon products.
 * Processing steps:
 * 1. init - Set status to processing
 * 2. search_asins - Find products from Amazon (supports multiple pages)
 * 3. save_products - Save ASINs to acms_products table (status=pending)
 * 4. finalize - Mark as completed
 *
 * Note: Scraping and category creation happen separately later.
 *
 * @package AffiliateCMS\Categories
 */

declare(strict_types=1);

namespace AffiliateCMS\Categories\Core;

use AffiliateCMS\Categories\Database\Schema;
use AffiliateCMS\Categories\Repositories\CategoryRepository;
use AffiliateCMS\Pro\Core\ProviderManager;
use AffiliateCMS\Pro\Services\SearchService;
use AffiliateCMS\Pro\Repositories\ProductRepository;

class QueueProcessor
{
    /**
     * Processing steps in order
     */
    private const STEPS = [
        'init',
        'search_asins',
        'save_products',
        'finalize'
    ];

    private int $queueId = 0;
    private array $item = [];
    private array $log = [];
    private array $errors = [];
    private int $currentStepIndex = 0;
    private bool $debug = false;

    private ?ProviderManager $providerManager = null;
    private ?SearchService $searchService = null;
    private ?ProductRepository $productRepository = null;
    private CategoryRepository $categoryRepository;

    /** @var array Search products data (keyed by ASIN) passed from stepSearchAsins to stepSaveProducts */
    private array $searchProducts = [];
    private string $lastSearchProvider = '';

    /**
     * Constructor
     */
    public function __construct(bool $debug = false)
    {
        $this->debug = $debug || (defined('WP_DEBUG') && WP_DEBUG);

        // Initialize repositories
        if (class_exists('AffiliateCMS\Pro\Repositories\ProductRepository')) {
            $this->productRepository = ProductRepository::instance();
        }

        $this->categoryRepository = new CategoryRepository();
    }

    /**
     * Process next pending item in queue
     *
     * Uses atomic claim (UPDATE...WHERE status='pending') to prevent
     * two concurrent cron calls from grabbing the same item.
     */
    public function processNext(): array
    {
        global $wpdb;
        $table = Schema::queueTable();

        // Step 1: Find next pending item
        $itemId = $wpdb->get_var(
            "SELECT id FROM {$table}
             WHERE status = 'pending'
             ORDER BY created_at ASC
             LIMIT 1"
        );

        if (!$itemId) {
            return [
                'success' => true,
                'message' => 'No pending items in queue',
                'queue_id' => null,
                'categories_created' => 0
            ];
        }

        // Step 2: Atomic claim — only succeeds if item is still 'pending'
        // Prevents double-processing when multiple cron calls run concurrently
        $claimed = $wpdb->query($wpdb->prepare(
            "UPDATE {$table}
             SET status = 'processing', search_status = 'searching', started_at = %s, error_message = NULL
             WHERE id = %d AND status = 'pending'",
            current_time('mysql'),
            $itemId
        ));

        if (!$claimed) {
            // Another cron already claimed this item — not an error
            return [
                'success' => true,
                'message' => 'Item already claimed by another process',
                'queue_id' => null,
                'categories_created' => 0
            ];
        }

        return $this->processItem((int) $itemId);
    }

    /**
     * Process specific queue item by ID
     */
    public function processItem(int $queueId): array
    {
        global $wpdb;
        $table = Schema::queueTable();

        // Load item
        $this->item = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $queueId),
            ARRAY_A
        );

        if (!$this->item) {
            return [
                'success' => false,
                'message' => 'Queue item not found',
                'queue_id' => $queueId,
                'categories_created' => 0
            ];
        }

        $this->queueId = $queueId;
        $this->log = [];
        $this->errors = [];

        // Execute all steps
        $result = $this->executeSteps();

        // Save final log
        $this->saveProcessingLog();

        return array_merge($result, [
            'queue_id' => $queueId,
            'log' => $this->log,
            'errors' => $this->errors
        ]);
    }

    /**
     * Execute all processing steps
     */
    private function executeSteps(): array
    {
        $categoriesCreated = 0;

        foreach (self::STEPS as $index => $step) {
            $this->currentStepIndex = $index;

            $stepResult = $this->executeStep($step);

            if (!$stepResult['success']) {
                // Step failed
                $this->handleFailure($stepResult['message']);
                return [
                    'success' => false,
                    'message' => "Failed at step '{$step}': " . $stepResult['message'],
                    'categories_created' => 0
                ];
            }

            // Capture categories created
            if ($step === 'create_categories' && isset($stepResult['created'])) {
                $categoriesCreated = $stepResult['created'];
            }

            // Save log after each step
            $this->saveProcessingLog();
        }

        return [
            'success' => true,
            'message' => 'Processing completed successfully',
            'categories_created' => $categoriesCreated
        ];
    }

    /**
     * Execute a single step
     */
    private function executeStep(string $step): array
    {
        $startTime = microtime(true);
        $this->log($step, "Starting step: {$step}");

        try {
            $result = match ($step) {
                'init' => $this->stepInit(),
                'search_asins' => $this->stepSearchAsins(),
                'save_products' => $this->stepSaveProducts(),
                'finalize' => $this->stepFinalize(),
                default => ['success' => false, 'message' => 'Unknown step']
            };

            $duration = round((microtime(true) - $startTime) * 1000);
            $this->log($step, "Step completed in {$duration}ms", [
                'success' => $result['success'],
                'duration_ms' => $duration
            ]);

            return $result;
        } catch (\Exception $e) {
            $this->logError($step, $e->getMessage());
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }

    // =========================================================================
    // STEP IMPLEMENTATIONS
    // =========================================================================

    /**
     * Step 1: Initialize processing
     *
     * If already claimed by processNext() (status=processing), just increment attempts.
     * If called directly via processItem() (status=pending), set full status.
     */
    private function stepInit(): array
    {
        global $wpdb;
        $table = Schema::queueTable();

        if ($this->item['status'] === 'processing') {
            // Pre-claimed by processNext() — just increment attempts
            $wpdb->update($table, [
                'attempts' => (int) $this->item['attempts'] + 1,
            ], ['id' => $this->queueId]);

            $this->log('init', 'Processing initialized', [
                'keyword' => $this->item['keyword'],
                'attempt' => (int) $this->item['attempts'] + 1,
                'search_limit' => $this->item['search_limit'],
                'max_search_pages' => $this->item['max_search_pages'] ?? 3
            ]);

            return ['success' => true, 'message' => 'Initialized'];
        }

        // Direct call via processItem() — set full status
        $updated = $wpdb->update($table, [
            'status' => 'processing',
            'search_status' => 'searching',
            'started_at' => current_time('mysql'),
            'attempts' => (int) $this->item['attempts'] + 1,
        ], ['id' => $this->queueId]);

        if ($updated === false) {
            return ['success' => false, 'message' => 'Failed to update status'];
        }

        $this->log('init', 'Processing initialized', [
            'keyword' => $this->item['keyword'],
            'attempt' => (int) $this->item['attempts'] + 1,
            'search_limit' => $this->item['search_limit'],
            'max_search_pages' => $this->item['max_search_pages'] ?? 3
        ]);

        return ['success' => true, 'message' => 'Initialized'];
    }

    /**
     * Step 2: Search ASINs from Amazon (with pagination support)
     *
     * Uses SearchService for unified search with pagination.
     * Fetches up to maxPages to get the desired number of ASINs.
     */
    private function stepSearchAsins(): array
    {
        // Check if already has ASINs (handle already-decoded JSON)
        $rawAsins = $this->item['linked_asins'] ?? null;
        $linkedAsins = $rawAsins
            ? (is_array($rawAsins) ? $rawAsins : json_decode($rawAsins, true))
            : [];

        if (!empty($linkedAsins)) {
            // Ensure correct status on retry — processNext() may have overwritten
            // search_status to 'searching' when re-claiming a retried item
            global $wpdb;
            $wpdb->update(Schema::queueTable(), [
                'search_status' => 'completed',
                'ai_status' => 'waiting_scrape',
                'products_found' => count($linkedAsins),
            ], ['id' => $this->queueId]);

            $this->log('search_asins', 'ASINs already found, restoring status', [
                'existing_count' => count($linkedAsins)
            ]);
            return ['success' => true, 'message' => 'Skipped - already has ASINs'];
        }

        $keyword = $this->item['keyword'];
        $limit = (int) ($this->item['search_limit'] ?? 20);
        $maxPages = (int) ($this->item['max_search_pages'] ?? 3);
        $domain = $this->item['search_domain'] ?? 'amazon.com';

        $this->log('search_asins', "Searching ASINs for: {$keyword}", [
            'limit' => $limit,
            'max_pages' => $maxPages,
            'domain' => $domain
        ]);

        // Initialize SearchService
        if (!class_exists('AffiliateCMS\\Pro\\Services\\SearchService')) {
            // Fallback to ProviderManager if SearchService not available
            return $this->stepSearchAsinsLegacy();
        }

        $this->searchService = $this->searchService ?? SearchService::instance();

        // Search with pagination support
        $searchResult = $this->searchService->searchAsins($keyword, $limit, $maxPages, $domain);

        if (empty($searchResult['asins'])) {
            $error = $this->searchService->getLastError() ?? 'No results found';
            $this->logError('search_asins', $error);
            return ['success' => false, 'message' => $error];
        }

        $asins = $searchResult['asins'];
        $provider = $searchResult['provider'] ?? 'unknown';

        // Store products data (keyed by ASIN) for stepSaveProducts to use
        foreach ($searchResult['products'] ?? [] as $product) {
            if (!empty($product['asin'])) {
                $this->searchProducts[$product['asin']] = $product;
            }
        }
        $this->lastSearchProvider = $provider;

        // Save ASINs to queue item and update status
        global $wpdb;
        $wpdb->update(Schema::queueTable(), [
            'linked_asins' => wp_json_encode($asins),
            'products_found' => count($asins),
            'search_status' => 'completed',
            'ai_status' => 'waiting_scrape',  // Now waiting for products to be scraped
        ], ['id' => $this->queueId]);

        // Update in-memory item
        $this->item['linked_asins'] = wp_json_encode($asins);
        $this->item['products_found'] = count($asins);

        $this->log('search_asins', 'ASINs found', [
            'count' => count($asins),
            'pages_fetched' => $searchResult['pages_fetched'] ?? 1,
            'provider' => $provider,
            'asins' => $asins
        ]);

        return [
            'success' => true,
            'message' => count($asins) . ' ASINs found',
            'asins' => $asins
        ];
    }

    /**
     * Legacy search method (fallback if SearchService not available)
     */
    private function stepSearchAsinsLegacy(): array
    {
        $keyword = $this->item['keyword'];
        $limit = (int) ($this->item['search_limit'] ?? 20);

        $this->providerManager = $this->providerManager ?? ProviderManager::instance();

        $results = $this->providerManager->searchProducts($keyword);

        if (empty($results)) {
            $error = $this->providerManager->getLastError() ?? 'No results found';
            $this->logError('search_asins', $error);
            // Update search_status to failed
            global $wpdb;
            $wpdb->update(Schema::queueTable(), [
                'search_status' => 'failed',
            ], ['id' => $this->queueId]);
            return ['success' => false, 'message' => $error];
        }

        $results = array_slice($results, 0, $limit);
        $asins = array_column($results, 'asin');

        // Store products data for stepSaveProducts
        foreach ($results as $product) {
            if (!empty($product['asin'])) {
                $this->searchProducts[$product['asin']] = $product;
            }
        }
        $this->lastSearchProvider = $this->providerManager->getLastUsedProvider() ?? 'unknown';

        global $wpdb;
        $wpdb->update(Schema::queueTable(), [
            'linked_asins' => wp_json_encode($asins),
            'products_found' => count($asins),
            'search_status' => 'completed',
            'ai_status' => 'waiting_scrape',
        ], ['id' => $this->queueId]);

        $this->log('search_asins', 'ASINs found (legacy)', [
            'count' => count($asins),
            'asins' => $asins
        ]);

        return [
            'success' => true,
            'message' => count($asins) . ' ASINs found',
            'asins' => $asins
        ];
    }

    /**
     * Step 3: Save products to database
     *
     * Uses createOrUpdateFromSearch() to save full search data (title, price,
     * rating, image, etc.) instead of bare ASIN-only records.
     * Falls back to minimal insert if search data is not available.
     */
    private function stepSaveProducts(): array
    {
        if ($this->productRepository === null) {
            return ['success' => false, 'message' => 'ProductRepository not available'];
        }

        $rawAsins = $this->item['linked_asins'] ?? null;
        $linkedAsins = $rawAsins ? (is_array($rawAsins) ? $rawAsins : json_decode($rawAsins, true)) : [];
        if (empty($linkedAsins)) {
            return ['success' => false, 'message' => 'No ASINs to save'];
        }

        $saved = 0;
        $skipped = 0;
        $provider = $this->lastSearchProvider ?: null;

        foreach ($linkedAsins as $asin) {
            try {
                // Check if product already exists
                $existing = $this->productRepository->findByAsin($asin);
                if ($existing) {
                    $skipped++;
                    continue;
                }

                // Use search data if available (from stepSearchAsins)
                $searchData = $this->searchProducts[$asin] ?? null;

                if ($searchData !== null) {
                    // Full save with search data (title, price, rating, image, etc.)
                    $productId = $this->productRepository->createOrUpdateFromSearch(
                        $asin,
                        $searchData,
                        $provider
                    );
                } else {
                    // Fallback: no search data (e.g. manually added ASINs)
                    $productId = $this->productRepository->create([
                        'asin' => $asin,
                        'status' => 'pending',
                        'title' => '',
                    ]);
                }

                if ($productId) {
                    $saved++;
                }
            } catch (\Exception $e) {
                $this->log('save_products', "Failed to save ASIN: {$asin}", [
                    'error' => $e->getMessage()
                ]);
            }
        }

        $this->log('save_products', 'Products saved to database', [
            'saved' => $saved,
            'skipped' => $skipped,
            'total' => count($linkedAsins),
            'had_search_data' => count($this->searchProducts),
        ]);

        return [
            'success' => true,
            'message' => "{$saved} products saved, {$skipped} skipped",
            'saved' => $saved
        ];
    }

    /**
     * Step 4: Finalize processing
     *
     * Sets status to 'searched' (not 'completed' - that happens after AI processing)
     * Triggers immediate scrape for pending products.
     * The CategoryQueueMonitor cron will check scrape progress and trigger AI when ready.
     */
    private function stepFinalize(): array
    {
        global $wpdb;
        $table = Schema::queueTable();

        // Set to 'searched' - waiting for scrape progress check
        // Full completion happens after AI processing
        $wpdb->update($table, [
            'status' => 'searched',
            // Note: completed_at will be set when AI processing finishes
        ], ['id' => $this->queueId]);

        // Trigger immediate scrape for the linked ASINs
        $rawAsins = $this->item['linked_asins'] ?? '[]';
        $linkedAsins = is_array($rawAsins) ? $rawAsins : json_decode($rawAsins, true);
        $scrapeTriggered = false;

        if (!empty($linkedAsins)) {
            $scrapeTriggered = $this->triggerImmediateScrape($linkedAsins);
        }

        $this->log('finalize', 'Search phase finalized - scrape triggered', [
            'status' => 'searched',
            'ai_status' => 'waiting_scrape',
            'scrape_triggered' => $scrapeTriggered,
            'asins_count' => count($linkedAsins),
            'next_step' => 'CategoryQueueMonitor will check scrape progress'
        ]);

        return ['success' => true, 'message' => 'Search phase finalized, scrape triggered'];
    }

    /**
     * Trigger immediate scrape for ASINs
     *
     * Uses the Pro plugin's parallel worker system for efficient scraping:
     * 1. Primary: Bootstrap::spawnParallelWorkers() - spawns 3-5 parallel workers
     * 2. Fallback: Automation endpoint - marks pending and spawns workers
     *
     * Note: BackgroundRunner::scheduleScrapeAsins() is single-threaded, so we don't use it.
     *
     * @param array $asins List of ASINs to scrape
     * @return bool True if scrape was triggered
     */
    private function triggerImmediateScrape(array $asins): bool
    {
        if (empty($asins)) {
            return false;
        }

        // Method 1: Direct parallel worker spawn (preferred - uses Pro's parallel system)
        if (class_exists('AffiliateCMS\\Pro\\Core\\Bootstrap')) {
            try {
                $bootstrap = \AffiliateCMS\Pro\Core\Bootstrap::instance();

                // First trigger the scrape which marks pending → scheduled
                $request = new \WP_REST_Request('POST', '/acms/v1/automation/scrape');
                $request->set_param('_wp_cron', true);
                $response = rest_do_request($request);

                if (!$response->is_error()) {
                    $data = $response->get_data();
                    $scheduled = $data['data']['scheduled'] ?? 0;

                    $this->log('scrape_trigger', 'Triggered parallel scrape via Pro plugin', [
                        'asins_count' => count($asins),
                        'scheduled' => $scheduled,
                        'workers' => $bootstrap->getWorkerCount()
                    ]);

                    return true;
                }
            } catch (\Exception $e) {
                $this->logError('scrape_trigger', 'Pro parallel scrape failed: ' . $e->getMessage());
            }
        }

        // Method 2: Direct REST call as fallback
        try {
            $request = new \WP_REST_Request('POST', '/acms/v1/automation/scrape');
            $request->set_param('_wp_cron', true);

            $response = rest_do_request($request);

            if (!$response->is_error()) {
                $data = $response->get_data();
                $this->log('scrape_trigger', 'Triggered scrape via automation endpoint', [
                    'scheduled' => $data['data']['scheduled'] ?? 0
                ]);
                return true;
            }
        } catch (\Exception $e) {
            $this->logError('scrape_trigger', 'Automation endpoint failed: ' . $e->getMessage());
        }

        return false;
    }

    // =========================================================================
    // HELPER METHODS
    // =========================================================================

    /**
     * Add log entry
     */
    private function log(string $step, string $message, array $data = []): void
    {
        $entry = [
            'step' => $step,
            'timestamp' => current_time('mysql'),
            'message' => $message
        ];

        if (!empty($data)) {
            $entry['data'] = $data;
        }

        $this->log[] = $entry;
    }

    /**
     * Add error to log
     */
    private function logError(string $step, string $message): void
    {
        $this->errors[] = [
            'step' => $step,
            'timestamp' => current_time('mysql'),
            'message' => $message
        ];

        $this->log($step, "ERROR: {$message}");
    }

    /**
     * Handle processing failure
     */
    private function handleFailure(string $message): void
    {
        global $wpdb;
        $table = Schema::queueTable();

        $attempts = (int) $this->item['attempts'] + 1;
        $maxAttempts = (int) $this->item['max_attempts'];

        $status = ($attempts >= $maxAttempts) ? 'failed' : 'pending';

        $wpdb->update($table, [
            'status' => $status,
            'error_message' => $message,
            'attempts' => $attempts
        ], ['id' => $this->queueId]);

        $this->log('error', "Processing failed: {$message}", [
            'attempts' => $attempts,
            'max_attempts' => $maxAttempts,
            'final_status' => $status
        ]);
    }

    /**
     * Save processing log to database
     */
    private function saveProcessingLog(): void
    {
        global $wpdb;
        $table = Schema::queueTable();

        $wpdb->update($table, [
            'processing_log' => wp_json_encode([
                'log' => $this->log,
                'errors' => $this->errors,
                'last_updated' => current_time('mysql')
            ])
        ], ['id' => $this->queueId]);
    }

    /**
     * Get processing log for queue item
     */
    public static function getProcessingLog(int $queueId): array
    {
        global $wpdb;
        $table = Schema::queueTable();

        $log = $wpdb->get_var(
            $wpdb->prepare("SELECT processing_log FROM {$table} WHERE id = %d", $queueId)
        );

        if (!$log) {
            return ['log' => [], 'errors' => []];
        }

        return json_decode($log, true) ?: ['log' => [], 'errors' => []];
    }
}
