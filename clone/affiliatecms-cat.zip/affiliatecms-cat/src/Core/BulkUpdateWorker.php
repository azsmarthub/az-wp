<?php

declare(strict_types=1);

namespace AffiliateCMS\Categories\Core;

/**
 * Background bulk update worker for "Update ASINs" operations.
 *
 * Server cron calls the worker endpoint every minute.
 * Each call processes up to ITEMS_PER_RUN items from the active batch.
 * Batch state stored in wp_options (autoload=false).
 */
class BulkUpdateWorker
{
    private const BATCH_PREFIX = 'acms_bulk_update_batch_';
    private const MAX_ERRORS = 10;

    /** Max items processed per cron invocation */
    private const ITEMS_PER_RUN = 3;

    private static ?self $instance = null;

    public static function instance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Create a new batch. Server cron will pick it up on next tick.
     *
     * @return string Batch UUID
     */
    public function createBatch(array $ids, string $mode, int $searchPages, int $searchLimit): string
    {
        $batchId = wp_generate_uuid4();

        $batch = [
            'ids'             => array_values($ids),
            'mode'            => $mode,
            'search_pages'    => $searchPages,
            'search_limit'    => $searchLimit,
            'status'          => 'running',
            'current_index'   => 0,
            'total'           => count($ids),
            'success'         => 0,
            'failed'          => 0,
            'errors'          => [],
            'current_keyword' => '',
            'started_at'      => current_time('mysql'),
            'updated_at'      => current_time('mysql'),
        ];

        update_option(self::BATCH_PREFIX . $batchId, $batch, false);

        error_log("[ACMS BulkUpdateWorker] Batch {$batchId} created: {$batch['total']} items, mode={$mode}");

        return $batchId;
    }

    /**
     * Process up to ITEMS_PER_RUN items from the active batch.
     *
     * Called by server cron every minute via:
     *   CronController::runBulkUpdateWorker()
     *
     * If no batch_id is provided, auto-detects the running batch.
     *
     * @return array{processed: int, remaining: int, status: string}
     */
    public function processBatch(?string $batchId = null): array
    {
        if (function_exists('ignore_user_abort')) {
            ignore_user_abort(true);
        }
        @set_time_limit(300);
        @ini_set('max_execution_time', '300');

        // Auto-detect running batch if not specified
        if ($batchId === null) {
            $batchId = $this->hasRunningBatch();
        }

        if ($batchId === null) {
            return ['processed' => 0, 'remaining' => 0, 'status' => 'no_batch'];
        }

        $batch = get_option(self::BATCH_PREFIX . $batchId);
        if (!$batch || $batch['status'] !== 'running') {
            return ['processed' => 0, 'remaining' => 0, 'status' => 'not_running'];
        }

        // Ensure admin context for REST permission check (cron has no user)
        if (!current_user_can('manage_options')) {
            $admins = get_users(['role' => 'administrator', 'number' => 1, 'fields' => 'ID']);
            if (!empty($admins)) {
                wp_set_current_user($admins[0]);
            }
        }

        $repo = new \AffiliateCMS\Categories\Repositories\QueueRepository();
        $processed = 0;

        for ($i = 0; $i < self::ITEMS_PER_RUN; $i++) {
            // Re-read batch each iteration (in case cancelled mid-run)
            $batch = get_option(self::BATCH_PREFIX . $batchId);
            if (!$batch || $batch['status'] !== 'running') {
                break;
            }

            $index = $batch['current_index'];
            if ($index >= $batch['total']) {
                $batch['status'] = 'completed';
                $batch['updated_at'] = current_time('mysql');
                update_option(self::BATCH_PREFIX . $batchId, $batch, false);
                break;
            }

            $id = (int) $batch['ids'][$index];

            // Update current keyword for display
            $item = $repo->find($id);
            $batch['current_keyword'] = $item['keyword'] ?? "ID #{$id}";
            $batch['updated_at'] = current_time('mysql');
            update_option(self::BATCH_PREFIX . $batchId, $batch, false);

            // Process this item
            try {
                $result = $this->updateAsinsForItem($id, $batch['mode'], $batch['search_pages'], $batch['search_limit']);
                if ($result['success']) {
                    $batch['success']++;
                } else {
                    $batch['failed']++;
                    $batch['errors'][] = "#{$id} ({$batch['current_keyword']}): " . ($result['error'] ?? 'Unknown error');
                }
            } catch (\Throwable $e) {
                $batch['failed']++;
                $batch['errors'][] = "#{$id} ({$batch['current_keyword']}): " . $e->getMessage();
                error_log("[ACMS BulkUpdateWorker] Error processing #{$id}: " . $e->getMessage());
            }

            // Keep only last N errors
            if (count($batch['errors']) > self::MAX_ERRORS) {
                $batch['errors'] = array_slice($batch['errors'], -self::MAX_ERRORS);
            }

            // Advance index
            $batch['current_index'] = $index + 1;
            $batch['updated_at'] = current_time('mysql');
            $processed++;

            // Check if batch is now complete
            if ($batch['current_index'] >= $batch['total']) {
                $batch['status'] = 'completed';
                update_option(self::BATCH_PREFIX . $batchId, $batch, false);
                error_log("[ACMS BulkUpdateWorker] Batch {$batchId} completed: {$batch['success']} success, {$batch['failed']} failed");
                break;
            }

            // Save progress before next item
            update_option(self::BATCH_PREFIX . $batchId, $batch, false);
        }

        $remaining = max(0, ($batch['total'] ?? 0) - ($batch['current_index'] ?? 0));

        return [
            'processed' => $processed,
            'remaining' => $remaining,
            'status'    => $batch['status'] ?? 'unknown',
            'batch_id'  => $batchId,
        ];
    }

    /**
     * Get batch status for polling.
     */
    public function getStatus(string $batchId): ?array
    {
        $batch = get_option(self::BATCH_PREFIX . $batchId);
        if (!$batch) {
            return null;
        }

        return [
            'batch_id'        => $batchId,
            'status'          => $batch['status'],
            'current'         => $batch['current_index'],
            'total'           => $batch['total'],
            'success'         => $batch['success'],
            'failed'          => $batch['failed'],
            'errors'          => $batch['errors'],
            'current_keyword' => $batch['current_keyword'],
            'started_at'      => $batch['started_at'],
            'updated_at'      => $batch['updated_at'],
        ];
    }

    /**
     * Cancel a running batch. Next cron call will skip it.
     */
    public function cancelBatch(string $batchId): bool
    {
        $batch = get_option(self::BATCH_PREFIX . $batchId);
        if (!$batch || $batch['status'] !== 'running') {
            return false;
        }

        $batch['status'] = 'cancelled';
        $batch['updated_at'] = current_time('mysql');
        update_option(self::BATCH_PREFIX . $batchId, $batch, false);

        error_log("[ACMS BulkUpdateWorker] Batch {$batchId} cancelled at {$batch['current_index']}/{$batch['total']}");

        return true;
    }

    /**
     * Find the currently running batch (if any).
     */
    public function hasRunningBatch(): ?string
    {
        global $wpdb;

        $row = $wpdb->get_row(
            "SELECT option_name, option_value FROM {$wpdb->options}
             WHERE option_name LIKE 'acms_bulk_update_batch_%'
             ORDER BY option_id DESC LIMIT 1",
            ARRAY_A
        );

        if (!$row) {
            return null;
        }

        $batch = maybe_unserialize($row['option_value']);
        if (is_array($batch) && ($batch['status'] ?? '') === 'running') {
            return str_replace(self::BATCH_PREFIX, '', $row['option_name']);
        }

        return null;
    }

    /**
     * Delete batch option (cleanup).
     */
    public function cleanup(string $batchId): void
    {
        delete_option(self::BATCH_PREFIX . $batchId);
    }

    /**
     * Process a single queue item by calling the existing update-asins endpoint internally.
     */
    private function updateAsinsForItem(int $id, string $mode, int $searchPages, int $searchLimit): array
    {
        $request = new \WP_REST_Request('POST', '/acms-cat/v1/queue/' . $id . '/update-asins');
        $request->set_param('mode', $mode);
        if ($searchPages > 0) {
            $request->set_param('search_pages', $searchPages);
        }
        if ($searchLimit > 0) {
            $request->set_param('search_limit', $searchLimit);
        }

        $response = rest_do_request($request);
        $data = $response->get_data();

        if ($response->get_status() >= 400 || empty($data['success'])) {
            $error = $data['message'] ?? ($data['data']['message'] ?? 'HTTP ' . $response->get_status());
            return ['success' => false, 'error' => $error];
        }

        return ['success' => true, 'data' => $data['data'] ?? []];
    }
}
