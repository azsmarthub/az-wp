<?php
/**
 * Bootstrap Class - Plugin Entry Point
 *
 * @package AffiliateCMS\Categories
 */

declare(strict_types=1);

namespace AffiliateCMS\Categories\Core;

use AffiliateCMS\Categories\Api\CategoryController;
use AffiliateCMS\Categories\Api\QueueController;
use AffiliateCMS\Categories\Api\CronController;
use AffiliateCMS\Categories\Api\ReviewController;
use AffiliateCMS\Categories\Admin\CategoriesPage;
use AffiliateCMS\Categories\Admin\CategoryEditPage;
use AffiliateCMS\Categories\Admin\QueuePage;
use AffiliateCMS\Categories\Admin\ReviewsPage;
use AffiliateCMS\Categories\Repositories\CategoryRepository;
use AffiliateCMS\Categories\Core\CategoryQueueMonitor;
use AffiliateCMS\Categories\Core\CategoryPathAssigner;
use AffiliateCMS\Categories\Core\BrandCategoryAiCron;

class Bootstrap
{
    private static ?self $instance = null;
    private CategoryRepository $repository;

    private function __construct()
    {
        $this->repository = new CategoryRepository();
    }

    public static function init(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
            self::$instance->registerHooks();
        }
        return self::$instance;
    }

    public static function getInstance(): ?self
    {
        return self::$instance;
    }

    public function getRepository(): CategoryRepository
    {
        return $this->repository;
    }

    private function registerHooks(): void
    {
        // REST API
        add_action('rest_api_init', [$this, 'registerRestRoutes']);

        // Admin menu (priority 20 to run after affiliatecms-pro's menu)
        if (is_admin()) {
            add_action('admin_menu', [$this, 'registerAdminMenu'], 20);
        }

        // Rewrite rules for category URLs
        add_action('init', [$this, 'registerRewriteRules']);

        // Template redirect for category pages
        add_action('template_redirect', [$this, 'handleCategoryTemplate']);

        // Cache invalidation hooks
        add_action('acms_cat_created', [$this, 'invalidateCacheOnCreate'], 10, 2);
        add_action('acms_cat_updated', [$this, 'invalidateCache']);
        add_action('acms_cat_deleted', [$this, 'invalidateCache']);

        // Register Category AI Cron (every 30 minutes for category content generation)
        add_action('init', [$this, 'registerCronJobs']);

        // Register custom cron intervals
        add_filter('cron_schedules', [CategoryQueueMonitor::class, 'registerCronInterval']);

        // Listen for queue item ready for AI - trigger immediate AI generation
        add_action('acms_category_ready_for_ai', [$this, 'onCategoryReadyForAi'], 10, 2);
    }

    /**
     * Register cron jobs for category operations
     */
    public function registerCronJobs(): void
    {
        // Skip cron registration if database tables haven't been created yet
        // (prevents SQL errors during plugin activation on a fresh install)
        if (!\AffiliateCMS\Categories\Database\Schema::tablesExist()) {
            return;
        }

        // Category queue processor (auto-processes pending items every 5 minutes)
        CatQueueProcessorCron::instance()->register();

        // Category AI content generation cron
        CategoryAiCron::instance()->register();

        // Category queue monitor (checks scrape progress)
        CategoryQueueMonitor::instance()->register();

        // Category path assigner (handles AI and non-AI category assignment)
        CategoryPathAssigner::instance()->register();

        // Brand-category AI cron (auto-create + content generation)
        BrandCategoryAiCron::instance()->register();

        // Category directory JSON cache (deferred rebuild)
        CategoryDirectoryCache::instance()->register();
    }

    public function registerRestRoutes(): void
    {
        $categoryController = new CategoryController($this->repository);
        $categoryController->registerRoutes();

        $queueController = new QueueController();
        $queueController->register_routes();

        // Cron endpoints (token-authenticated for server cron)
        $cronController = new CronController();
        $cronController->register_routes();

        // Product reviews
        $reviewController = new ReviewController();
        $reviewController->register_routes();
    }

    public function registerAdminMenu(): void
    {
        add_submenu_page(
            'acms-pro', // Parent slug from affiliatecms-pro
            __('SEO Categories', 'affiliatecms-cat'),
            __('SEO Categories', 'affiliatecms-cat'),
            'manage_options',
            'acms-categories',
            [$this, 'renderAdminPage']
        );

        add_submenu_page(
            'acms-pro',
            __('Category Queue', 'affiliatecms-cat'),
            __('Category Queue', 'affiliatecms-cat'),
            'manage_options',
            'acms-cat-queue',
            [$this, 'renderQueuePage']
        );

        // Hidden page for category editing (accessible via URL, no menu item)
        add_submenu_page(
            '',
            __('Edit Category', 'affiliatecms-cat'),
            __('Edit Category', 'affiliatecms-cat'),
            'manage_options',
            'acms-category-edit',
            [$this, 'renderEditPage']
        );

        // Product Reviews - under WordPress Comments menu
        add_submenu_page(
            'edit-comments.php',
            __('Product Reviews', 'affiliatecms-cat'),
            __('Product Reviews', 'affiliatecms-cat'),
            'manage_options',
            'acms-reviews',
            [$this, 'renderReviewsPage']
        );
    }

    public function renderAdminPage(): void
    {
        $action = isset($_GET['action']) ? sanitize_text_field($_GET['action']) : '';

        if ($action === 'edit' || $action === 'new') {
            $page = new CategoryEditPage($this->repository);
            $page->render();
        } else {
            $page = new CategoriesPage($this->repository);
            $page->render();
        }
    }

    /**
     * Render the hidden category edit page (admin.php?page=acms-category-edit&id=X)
     * Sets menu highlighting to SEO Categories submenu
     */
    public function renderEditPage(): void
    {
        global $parent_file, $submenu_file;
        $parent_file = 'acms-pro';
        $submenu_file = 'acms-categories';

        $page = new CategoryEditPage($this->repository);
        $page->render();
    }

    public function renderQueuePage(): void
    {
        $page = new QueuePage();
        $page->render();
    }

    public function renderReviewsPage(): void
    {
        $page = new ReviewsPage();
        $page->render();
    }

    public function registerRewriteRules(): void
    {
        // /c/category-slug/ -> category page
        add_rewrite_rule(
            '^c/([^/]+)/?$',
            'index.php?acms_category=$matches[1]',
            'top'
        );

        // /c/category-slug/page/2/ -> category page with pagination
        add_rewrite_rule(
            '^c/([^/]+)/page/([0-9]+)/?$',
            'index.php?acms_category=$matches[1]&paged=$matches[2]',
            'top'
        );

        // Register query vars
        add_filter('query_vars', function (array $vars): array {
            $vars[] = 'acms_category';
            return $vars;
        });
    }

    public function handleCategoryTemplate(): void
    {
        $category_slug = get_query_var('acms_category');

        if (empty($category_slug)) {
            return;
        }

        $category = $this->repository->findBySlug($category_slug);

        if (!$category) {
            global $wp_query;
            $wp_query->set_404();
            status_header(404);
            return;
        }

        // Set global for template use
        $GLOBALS['acms_current_category'] = $category;

        // Enqueue Alpine.js for frontend (check if not already registered)
        add_action('wp_enqueue_scripts', [$this, 'enqueueFrontendAssets'], 5);

        // Load template
        $template = locate_template(['acms-category.php', 'templates/acms-category.php']);

        if (!$template) {
            $template = ACMS_CAT_PATH . 'templates/category.php';
        }

        if (file_exists($template)) {
            include $template;
            exit;
        }
    }

    /**
     * Enqueue frontend assets for category pages
     */
    public function enqueueFrontendAssets(): void
    {
        // Only enqueue Alpine.js if not already registered by theme/other plugins
        if (!wp_script_is('alpinejs', 'registered') && !wp_script_is('alpine', 'registered')) {
            wp_enqueue_script(
                'alpinejs',
                ACMS_CAT_URL . 'assets/js/alpine.min.js',
                [],
                '3.14.3',
                ['strategy' => 'defer', 'in_footer' => false]
            );
        } elseif (wp_script_is('alpinejs', 'registered')) {
            wp_enqueue_script('alpinejs');
        } elseif (wp_script_is('alpine', 'registered')) {
            wp_enqueue_script('alpine');
        }

        // Prevent LiteSpeed Cache from combining/minifying Alpine.js
        // Alpine must load as a standalone script before components initialize
        add_filter('script_loader_tag', function (string $tag, string $handle): string {
            if ($handle === 'alpinejs' || $handle === 'alpine') {
                $tag = str_replace('<script ', '<script data-no-optimize="1" ', $tag);
            }
            return $tag;
        }, 10, 2);
    }

    public function invalidateCacheOnCreate(int $category_id, array $data): void
    {
        // Clear all category caches
        wp_cache_delete('acms_cat_tree', 'acms_categories');
        wp_cache_delete('acms_cat_tree_all', 'acms_categories');
        wp_cache_delete('acms_cat_all', 'acms_categories');
        wp_cache_delete('acms_cat_all_all', 'acms_categories');
        wp_cache_delete('acms_cat_all_publish', 'acms_categories');

        // Clear parent cache if this is a child category
        if (!empty($data['parent_id']) && (int) $data['parent_id'] > 0) {
            $parent_id = (int) $data['parent_id'];
            wp_cache_delete("acms_cat_{$parent_id}", 'acms_categories');
        }

        // Clear Redis if available
        if (function_exists('wp_cache_flush_group')) {
            wp_cache_flush_group('acms_categories');
        }

        // Schedule directory cache rebuild (debounced)
        CategoryDirectoryCache::instance()->scheduleRebuild();
    }

    public function invalidateCache(int $category_id = 0): void
    {
        // Clear category cache
        wp_cache_delete('acms_cat_tree', 'acms_categories');
        wp_cache_delete('acms_cat_all', 'acms_categories');

        if ($category_id > 0) {
            wp_cache_delete("acms_cat_{$category_id}", 'acms_categories');

            // Get category to clear slug cache
            $category = $this->repository->find($category_id);
            if ($category) {
                wp_cache_delete("acms_cat_slug_{$category['slug']}", 'acms_categories');
            }
        }

        // Clear Redis if available
        if (function_exists('wp_cache_flush_group')) {
            wp_cache_flush_group('acms_categories');
        }

        // Schedule directory cache rebuild (debounced)
        CategoryDirectoryCache::instance()->scheduleRebuild();
    }

    /**
     * Handle when a category queue item is ready for AI processing
     * Triggers immediate AI generation instead of waiting for CategoryAiCron
     *
     * @param int $queueId Queue item ID
     * @param array $linkedAsins ASINs linked to this queue item
     */
    public function onCategoryReadyForAi(int $queueId, array $linkedAsins): void
    {
        global $wpdb;

        // Get queue item to find category_id
        $queueTable = $wpdb->prefix . 'acms_cat_queue';
        $queueItem = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$queueTable} WHERE id = %d",
            $queueId
        ), ARRAY_A);

        if (!$queueItem) {
            return;
        }

        $categoryId = (int) ($queueItem['category_id'] ?? 0);
        if ($categoryId <= 0) {
            return;
        }

        // Check if category exists and needs AI content
        $category = $this->repository->find($categoryId);
        if (!$category) {
            return;
        }

        // Only trigger if category content is empty
        $contentStatus = $category['content_status'] ?? 'empty';
        if ($contentStatus !== 'empty') {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("[ACMS Bootstrap] Category {$categoryId} already has content status: {$contentStatus}");
            }
            return;
        }

        // Check if AI plugin is available
        $jobsTable = $wpdb->prefix . 'acms_ai_jobs';
        $tableExists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $jobsTable));
        if ($tableExists !== $jobsTable) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("[ACMS Bootstrap] AI jobs table not available, deferring to CategoryAiCron");
            }
            return;
        }

        // Check if job already exists for this category
        $existingJob = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$jobsTable}
             WHERE type = 'generate_seo_category'
             AND target_type = 'seo_category'
             AND target_id = %s
             AND status IN ('pending', 'processing')",
            (string) $categoryId
        ));

        if ($existingJob) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("[ACMS Bootstrap] AI job already exists for category {$categoryId}");
            }
            return;
        }

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("[ACMS Bootstrap] Creating immediate AI job for category {$categoryId} from queue {$queueId}");
        }

        // Get products for context
        $products = $this->getCategoryProductsForAi($categoryId);

        // Get parent categories
        $parentCategories = $this->getParentCategoryNames($categoryId);

        // Build path
        $categoryPath = !empty($parentCategories)
            ? implode(' > ', $parentCategories) . ' > ' . $category['name']
            : $category['name'];

        // Create AI job with queue_id for tracking
        $inputData = [
            'category_id' => $categoryId,
            'category_name' => $category['name'],
            'category_slug' => $category['slug'] ?? '',
            'category_path' => $categoryPath,
            'parent_categories' => $parentCategories,
            'products' => $products,
            'current_description' => $category['description'] ?? '',
            'queue_id' => $queueId, // Track originating queue item
        ];

        // Add brand context if this is a brand-category
        if (!empty($category['brand_id'])) {
            $brandsTable = $wpdb->prefix . 'acms_brands';
            $brand = $wpdb->get_row($wpdb->prepare(
                "SELECT name FROM {$brandsTable} WHERE id = %d",
                (int) $category['brand_id']
            ), ARRAY_A);
            if ($brand) {
                $inputData['brand_name'] = $brand['name'];
                $inputData['brand_id'] = (int) $category['brand_id'];
            }
        }

        $wpdb->insert($jobsTable, [
            'type' => 'generate_seo_category',
            'status' => 'pending',
            'priority' => 35, // Higher priority for immediate trigger
            'target_type' => 'seo_category',
            'target_id' => (string) $categoryId,
            'input_data' => wp_json_encode($inputData),
            'created_at' => current_time('mysql'),
        ]);

        // Mark category as generating
        $this->repository->update($categoryId, [
            'content_status' => 'ai_generating',
            'ai_generating_at' => current_time('mysql'),
            'ai_error_message' => null,
        ]);

        // Update queue ai_status
        $wpdb->update(
            $queueTable,
            ['ai_status' => 'generating_content'],
            ['id' => $queueId],
            ['%s'],
            ['%d']
        );

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("[ACMS Bootstrap] AI job created for category {$categoryId}, queue {$queueId}");
        }
    }

    /**
     * Get products in a category for AI context
     */
    private function getCategoryProductsForAi(int $categoryId): array
    {
        global $wpdb;

        $junctionTable = $wpdb->prefix . 'acms_category_products';
        $productsTable = $wpdb->prefix . 'acms_products';

        $tableExists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $junctionTable));
        if ($tableExists !== $junctionTable) {
            return [];
        }

        return $wpdb->get_results($wpdb->prepare(
            "SELECT p.asin, p.title, p.brand, p.category_path, p.rating, p.reviews_count
             FROM {$productsTable} p
             INNER JOIN {$junctionTable} cp ON cp.product_id = p.id
             WHERE cp.category_id = %d AND p.status = 'scraped'
             ORDER BY cp.is_primary DESC, p.rating DESC
             LIMIT 15",
            $categoryId
        ), ARRAY_A) ?: [];
    }

    /**
     * Get parent category names for context
     */
    private function getParentCategoryNames(int $categoryId): array
    {
        global $wpdb;

        $categoriesTable = $wpdb->prefix . 'acms_categories';
        $category = $wpdb->get_row($wpdb->prepare(
            "SELECT path FROM {$categoriesTable} WHERE id = %d",
            $categoryId
        ), ARRAY_A);

        if (!$category || empty($category['path']) || $category['path'] === '/') {
            return [];
        }

        $pathIds = array_filter(explode('/', trim($category['path'], '/')));
        if (empty($pathIds)) {
            return [];
        }

        $placeholders = implode(',', array_fill(0, count($pathIds), '%d'));
        $names = $wpdb->get_results($wpdb->prepare(
            "SELECT id, name FROM {$categoriesTable} WHERE id IN ({$placeholders}) ORDER BY depth ASC",
            ...$pathIds
        ), ARRAY_A);

        $nameMap = [];
        foreach ($names as $cat) {
            $nameMap[$cat['id']] = $cat['name'];
        }

        $parentCategories = [];
        foreach ($pathIds as $id) {
            if (isset($nameMap[$id])) {
                $parentCategories[] = $nameMap[$id];
            }
        }

        return $parentCategories;
    }
}
