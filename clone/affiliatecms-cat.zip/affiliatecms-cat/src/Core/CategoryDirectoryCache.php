<?php
/**
 * Category Directory Static Cache
 *
 * Pre-generates a JSON file with minimal category data for the /categories/ page.
 * Avoids loading all 2500+ categories with LONGTEXT columns into PHP memory.
 *
 * @package AffiliateCMS\Categories
 */

declare(strict_types=1);

namespace AffiliateCMS\Categories\Core;

use AffiliateCMS\Categories\Database\Schema;

class CategoryDirectoryCache
{
    private static ?self $instance = null;

    private const DEBOUNCE_KEY = 'acms_cat_dir_cache_pending';
    private const DEBOUNCE_SECONDS = 30;
    public const CRON_HOOK = 'acms_cat_directory_cache_rebuild';

    public static function instance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {}

    /**
     * Get the cache file path.
     */
    public static function getCacheFilePath(): string
    {
        return WP_CONTENT_DIR . '/cache/acms/categories-directory.json';
    }

    /**
     * Register the deferred rebuild cron hook.
     */
    public function register(): void
    {
        add_action(self::CRON_HOOK, [$this, 'rebuild']);
    }

    /**
     * Schedule a debounced rebuild.
     *
     * When categories change rapidly (bulk import, AI generation),
     * only one rebuild fires after the burst is done.
     */
    public function scheduleRebuild(): void
    {
        if (get_transient(self::DEBOUNCE_KEY)) {
            return;
        }

        set_transient(self::DEBOUNCE_KEY, '1', self::DEBOUNCE_SECONDS);

        if (!wp_next_scheduled(self::CRON_HOOK)) {
            wp_schedule_single_event(time() + self::DEBOUNCE_SECONDS, self::CRON_HOOK);
        }
    }

    /**
     * Rebuild the cache file.
     *
     * Uses optimized SQL (only 6 columns, no LONGTEXT) and O(n) tree building.
     *
     * @return array{success: bool, message: string, file_size?: int, categories_count?: int}
     */
    public function rebuild(): array
    {
        delete_transient(self::DEBOUNCE_KEY);

        if (!Schema::tablesExist()) {
            return ['success' => false, 'message' => 'Tables do not exist'];
        }

        global $wpdb;
        $tables = Schema::tables();

        // Minimal columns only — NO content_main, content_intro, content_faq, description
        $categories = $wpdb->get_results(
            "SELECT id, parent_id, name, slug, icon, product_count
             FROM {$tables['categories']}
             WHERE status = 'publish'
             ORDER BY position ASC, name ASC",
            ARRAY_A
        );

        if ($categories === null) {
            return ['success' => false, 'message' => 'Query failed: ' . $wpdb->last_error];
        }

        // Stats
        $total_categories = count($categories);
        $total_products = (int) $wpdb->get_var(
            "SELECT COUNT(DISTINCT product_id) FROM {$tables['category_products']}"
        );

        // O(n) indexed tree building
        $indexed = [];
        $roots = [];
        $rootsList = [];

        foreach ($categories as &$cat) {
            $cat['id'] = (int) $cat['id'];
            $cat['parent_id'] = (int) $cat['parent_id'];
            $cat['product_count'] = (int) $cat['product_count'];
            $cat['children'] = [];
            $indexed[$cat['id']] = &$cat;
        }
        unset($cat);

        foreach ($indexed as &$cat) {
            if ($cat['parent_id'] === 0) {
                $roots[] = &$cat;
                $rootsList[] = [
                    'id'   => $cat['id'],
                    'name' => $cat['name'],
                    'icon' => $cat['icon'],
                ];
            } elseif (isset($indexed[$cat['parent_id']])) {
                $indexed[$cat['parent_id']]['children'][] = &$cat;
            }
        }
        unset($cat);

        // A-Z flat list (pre-computed, grouped by first letter)
        $azList = [];
        foreach ($categories as $cat) {
            $azList[] = [
                'id'            => (int) $cat['id'],
                'name'          => $cat['name'],
                'slug'          => $cat['slug'],
                'icon'          => $cat['icon'],
                'product_count' => (int) $cat['product_count'],
            ];
        }
        usort($azList, fn($a, $b) => strcasecmp($a['name'], $b['name']));

        $azGrouped = [];
        foreach ($azList as $cat) {
            $letter = mb_strtoupper(mb_substr($cat['name'], 0, 1));
            $azGrouped[$letter][] = $cat;
        }
        ksort($azGrouped);

        // Clean tree for output (remove parent_id, keep only needed fields)
        $cleanTree = $this->cleanTree($roots);

        $data = [
            'generated_at'    => current_time('c'),
            'stats'           => [
                'total_categories' => $total_categories,
                'total_products'   => $total_products,
            ],
            'tree'            => $cleanTree,
            'az_grouped'      => $azGrouped,
            'root_categories' => $rootsList,
        ];

        $json = wp_json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($json === false) {
            return ['success' => false, 'message' => 'JSON encode failed: ' . json_last_error_msg()];
        }

        // Ensure directory exists
        $dir = dirname(self::getCacheFilePath());
        if (!is_dir($dir)) {
            wp_mkdir_p($dir);
        }

        // Atomic write: temp file → rename
        $tmpFile = $dir . '/categories-directory-' . uniqid() . '.tmp';
        $written = file_put_contents($tmpFile, $json);

        if ($written === false) {
            return ['success' => false, 'message' => 'Failed to write temp file'];
        }

        rename($tmpFile, self::getCacheFilePath());

        return [
            'success'          => true,
            'message'          => 'Cache rebuilt successfully',
            'file_size'        => $written,
            'categories_count' => $total_categories,
        ];
    }

    /**
     * Clean tree nodes: keep only id/name/slug/icon/product_count/children.
     */
    private function cleanTree(array $nodes): array
    {
        $result = [];
        foreach ($nodes as $node) {
            $clean = [
                'id'            => $node['id'],
                'name'          => $node['name'],
                'slug'          => $node['slug'],
                'icon'          => $node['icon'],
                'product_count' => $node['product_count'],
            ];
            if (!empty($node['children'])) {
                $clean['children'] = $this->cleanTree($node['children']);
            }
            $result[] = $clean;
        }
        return $result;
    }

    /**
     * Load cached data. Returns null if cache unavailable.
     */
    public static function load(): ?array
    {
        $file = self::getCacheFilePath();

        if (!is_file($file)) {
            return null;
        }

        $json = file_get_contents($file);
        if ($json === false) {
            return null;
        }

        $data = json_decode($json, true);
        if (!is_array($data)) {
            return null;
        }

        return $data;
    }

    /**
     * Delete the cache file.
     */
    public static function invalidate(): void
    {
        $file = self::getCacheFilePath();
        if (is_file($file)) {
            @unlink($file);
        }
    }
}
