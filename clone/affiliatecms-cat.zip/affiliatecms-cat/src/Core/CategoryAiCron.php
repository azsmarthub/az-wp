<?php
/**
 * Category AI Content Generation Cron Job
 *
 * Uses parallel worker pattern to process categories needing AI content.
 * Each worker atomically claims one category, creates an AI job, processes
 * it inline via OpenRouter, and self-spawns the next worker.
 *
 * This is part of the 3-tier AI generation system:
 * 1. ProductAiCron - Product content (affiliatecms-pro)
 * 2. PostAiCron - Review post generation (affiliatecms-pro)
 * 3. CategoryAiCron - Category content generation (affiliatecms-cat)
 *
 * Output Fields:
 * - content_intro - Intro paragraph
 * - content_main - Main content (comprehensive guide)
 * - content_faq - FAQ section (JSON)
 * - seo_title - SEO optimized title
 * - seo_description - Meta description
 *
 * @package AffiliateCMS\Categories\Core
 * @see docs/ai-generation-architecture.md
 */

declare(strict_types=1);

namespace AffiliateCMS\Categories\Core;

use AffiliateCMS\Categories\Repositories\CategoryRepository;

class CategoryAiCron
{
    /**
     * Hook name for the cron job
     */
    public const CRON_HOOK = 'acms_category_ai_generation';

    /**
     * Default number of category AI workers
     */
    private const DEFAULT_CATEGORY_AI_WORKERS = 2;

    /**
     * Maximum number of category AI workers
     */
    private const MAX_CATEGORY_AI_WORKERS = 4;

    /**
     * Singleton instance
     */
    private static ?CategoryAiCron $instance = null;

    private CategoryRepository $categoryRepo;

    /**
     * Get singleton instance
     */
    public static function instance(): CategoryAiCron
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Private constructor for singleton
     */
    private function __construct()
    {
        $this->categoryRepo = new CategoryRepository();
    }

    /**
     * Register the cron job
     */
    public function register(): void
    {
        add_filter('cron_schedules', [$this, 'registerSchedule']);
        add_action(self::CRON_HOOK, [$this, 'generateContent']);

        // WP-Cron as safety net (server cron is primary)
        if (!wp_next_scheduled(self::CRON_HOOK)) {
            wp_schedule_event(time(), 'every_30_minutes', self::CRON_HOOK);
        }
    }

    /**
     * Register custom cron schedule
     *
     * @param array $schedules Existing schedules
     * @return array Modified schedules
     */
    public function registerSchedule(array $schedules): array
    {
        if (!isset($schedules['every_30_minutes'])) {
            $schedules['every_30_minutes'] = [
                'interval' => 30 * 60,
                'display' => __('Every 30 minutes', 'affiliatecms-cat'),
            ];
        }
        return $schedules;
    }

    /**
     * Get configurable category AI worker count
     *
     * Uses acms_automation settings. Default 2, max 4 — category AI calls
     * are heavier than product AI (more context, longer content).
     */
    public function getCategoryAiWorkerCount(): int
    {
        $settings = get_option('acms_automation', []);
        $count = (int) ($settings['category_ai_worker_count'] ?? self::DEFAULT_CATEGORY_AI_WORKERS);
        return max(1, min(self::MAX_CATEGORY_AI_WORKERS, $count));
    }

    /**
     * Spawn parallel category AI workers to process queued categories
     *
     * Follows the same pattern as ProductAiCron::spawnAiWorkers().
     * Each worker claims one category atomically, processes it, then self-spawns
     * the next worker — creating a continuous processing chain until queue is empty.
     *
     * @param int|null $count Number of workers to spawn (null = use setting)
     */
    public function spawnCategoryAiWorkers(?int $count = null): void
    {
        if (!\AffiliateCMS\Categories\Database\Schema::tablesExist()) {
            return;
        }

        $count = $count ?? $this->getCategoryAiWorkerCount();
        $queued = $this->categoryRepo->countQueuedForCategoryAi();

        $workersToSpawn = min($count, $queued);

        if ($workersToSpawn <= 0) {
            return;
        }

        for ($i = 0; $i < $workersToSpawn; $i++) {
            $this->spawnCategoryAiWorker();

            // Small delay between spawns to avoid thundering herd
            if ($i < $workersToSpawn - 1) {
                usleep(100000); // 100ms
            }
        }
    }

    /**
     * Spawn a single category AI worker via non-blocking HTTP request
     *
     * Mirrors ProductAiCron::spawnAiWorker() pattern — fires and forgets.
     * The worker endpoint handles claiming, processing, and self-spawning.
     */
    private function spawnCategoryAiWorker(): void
    {
        $apiToken = get_option('acms_api_token', '');
        $endpoint = rest_url('acms/v1/cron/category-ai-worker');

        wp_remote_post($endpoint, [
            'timeout'   => 0.01,
            'blocking'  => false,
            'sslverify' => false,
            'headers'   => [
                'X-ACMS-Token' => $apiToken,
            ],
        ]);
    }

    /**
     * Process the next queued category (single worker execution)
     *
     * Called by the /cron/category-ai-worker REST endpoint. Each invocation:
     * 1. Atomically claims one category (claimQueuedCategoryForAi)
     * 2. Creates AI job (generate_seo_category)
     * 3. Processes inline (OpenRouter API call, 15-60s)
     * 4. If more queued → self-spawns next worker (chain continues)
     *
     * @return array Result with status info
     */
    public function processNextQueuedCategoryAi(): array
    {
        // Extend PHP execution time for AI API calls
        @set_time_limit(300);
        @ini_set('max_execution_time', '300');

        // Step 1: Atomically claim one category
        $category = $this->categoryRepo->claimQueuedCategoryForAi();

        if (!$category) {
            return ['status' => 'idle', 'message' => 'No categories queued for AI'];
        }

        $categoryId = (int) $category['id'];
        // Step 2: Create AI job
        $result = $this->createCategoryAiJob($category);

        if (is_string($result)) {
            // Job creation failed
            error_log("[ACMS Category AI Worker] Job creation FAILED for category #{$categoryId}: {$result}");
            $this->categoryRepo->update($categoryId, [
                'content_status' => 'empty',
                'ai_error_message' => $result,
            ]);
            $this->spawnNextCategoryIfNeeded();
            return ['status' => 'failed', 'category_id' => $categoryId, 'error' => $result];
        }

        if ($result === 0) {
            // Duplicate pending job exists — adopt and process it instead of skipping
            global $wpdb;
            $jobsTable = $wpdb->prefix . 'acms_ai_jobs';
            $pendingJobId = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$jobsTable}
                 WHERE type = 'generate_seo_category'
                 AND target_id = %s
                 AND status = 'pending'
                 ORDER BY id DESC LIMIT 1",
                (string) $categoryId
            ));

            if ($pendingJobId > 0) {
                error_log("[ACMS Category AI Worker] Adopting pending job #{$pendingJobId} for category #{$categoryId}");
                $this->processJobInline($pendingJobId, $categoryId);
                $this->spawnNextCategoryIfNeeded();
                return ['status' => 'adopted', 'category_id' => $categoryId, 'job_id' => $pendingJobId];
            }

            // No pending job found (maybe processing) — skip
            error_log("[ACMS Category AI Worker] Duplicate job for category #{$categoryId}, skipping");
            $this->spawnNextCategoryIfNeeded();
            return ['status' => 'skipped', 'category_id' => $categoryId, 'reason' => 'duplicate job'];
        }

        // Step 3: Process inline (this is the main AI API call, 15-60s)
        $this->processJobInline($result, $categoryId);

        // Step 4: Self-spawn next worker if more categories queued
        $this->spawnNextCategoryIfNeeded();

        return ['status' => 'processed', 'category_id' => $categoryId, 'job_id' => $result];
    }

    /**
     * Spawn next category AI worker if more categories are queued
     */
    private function spawnNextCategoryIfNeeded(): void
    {
        $remaining = $this->categoryRepo->countQueuedForCategoryAi();

        if ($remaining > 0) {
            $this->spawnCategoryAiWorker();
        }
    }

    /**
     * Generate AI content for categories that need it (safety net)
     *
     * This is now a lightweight dispatcher that spawns category AI workers.
     * No longer processes inline — workers handle everything.
     *
     * Runs periodically to catch categories missed by the immediate trigger.
     */
    public function generateContent(): void
    {
        if (!\AffiliateCMS\Categories\Database\Schema::tablesExist()) {
            return;
        }

        // Reset stuck processing jobs so they can be retried
        $resetCount = $this->resetStuckProcessingJobs();
        if ($resetCount > 0) {
            error_log("[ACMS CategoryAiCron] Reset {$resetCount} stuck processing jobs");
        }

        $queued = $this->categoryRepo->countQueuedForCategoryAi();

        if ($queued === 0) {
            return;
        }

        error_log("[ACMS CategoryAiCron] Spawning workers for {$queued} queued categories");
        $this->spawnCategoryAiWorkers();
    }

    /**
     * Reset stuck processing jobs for category AI generation
     *
     * When a job stays at 'processing' for > 10 minutes (PHP killed, timeout, etc.),
     * it blocks new job creation via the duplicate check in createCategoryAiJob().
     * This method resets them to 'failed' and also updates corresponding queue items.
     *
     * @return int Number of jobs reset
     */
    private function resetStuckProcessingJobs(): int
    {
        global $wpdb;

        $jobsTable = $wpdb->prefix . 'acms_ai_jobs';
        $tableExists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $jobsTable));
        if ($tableExists !== $jobsTable) {
            return 0;
        }

        $stuckThreshold = date('Y-m-d H:i:s', current_time('timestamp') - 600); // 10 min

        // Find stuck processing jobs for category AI
        $stuckJobs = $wpdb->get_results($wpdb->prepare(
            "SELECT id, target_id, input_data FROM {$jobsTable}
             WHERE type = 'generate_seo_category'
             AND status = 'processing'
             AND processing_at < %s",
            $stuckThreshold
        ), ARRAY_A);

        if (empty($stuckJobs)) {
            return 0;
        }

        $queueTable = $wpdb->prefix . 'acms_cat_queue';
        $categoriesTable = $wpdb->prefix . 'acms_categories';
        $resetCount = 0;

        foreach ($stuckJobs as $job) {
            // Reset job to failed
            $wpdb->update(
                $jobsTable,
                [
                    'status' => 'failed',
                    'error_message' => 'Reset: stuck processing > 10 min (PHP timeout/killed)',
                ],
                ['id' => (int) $job['id']]
            );

            // Reset category content_status back to empty
            $categoryId = (int) $job['target_id'];
            if ($categoryId > 0) {
                $wpdb->update(
                    $categoriesTable,
                    [
                        'content_status' => 'empty',
                        'ai_error_message' => 'Job stuck processing > 10 min, reset for retry',
                    ],
                    ['id' => $categoryId],
                    ['%s', '%s'],
                    ['%d']
                );
            }

            // Reset queue item ai_status if still generating_content
            $inputData = is_array($job['input_data'])
                ? $job['input_data']
                : json_decode($job['input_data'] ?? '', true);

            $queueId = (int) ($inputData['queue_id'] ?? 0);
            if ($queueId > 0) {
                $wpdb->update(
                    $queueTable,
                    ['ai_status' => 'category_assigned'],
                    ['id' => $queueId, 'ai_status' => 'generating_content'],
                    ['%s'],
                    ['%d', '%s']
                );
            }

            $resetCount++;
            error_log("[ACMS CategoryAiCron] Reset stuck job #{$job['id']} for category #{$categoryId}" . ($queueId > 0 ? " (queue #{$queueId})" : ''));
        }

        return $resetCount;
    }

    /**
     * Create an AI job for a single category
     *
     * Builds input data (products, parents, brand context, related categories)
     * and inserts a generate_seo_category job into acms_ai_jobs.
     *
     * @param array $category Category data (from atomic claim)
     * @return int|string Job ID on success, error string on failure, 0 if duplicate exists
     */
    private function createCategoryAiJob(array $category): int|string
    {
        global $wpdb;

        $categoryId = (int) $category['id'];

        // Check if affiliatecms-ai plugin is available
        $jobsTable = $wpdb->prefix . 'acms_ai_jobs';
        $tableExists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $jobsTable));
        if ($tableExists !== $jobsTable) {
            return 'AI jobs table not found - affiliatecms-ai plugin may not be active';
        }

        // Check if job already exists for this category
        $existingJob = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$jobsTable}
             WHERE type = 'generate_seo_category'
             AND target_type = 'seo_category'
             AND target_id = %s
             AND status IN ('pending', 'processing')",
            (string) $categoryId
        ));

        if ($existingJob) {
            return 0; // Duplicate exists
        }

        // Get products in this category
        $products = $this->getCategoryProducts($categoryId);

        // Get parent categories for context
        $parentCategories = $this->getParentCategoryNames($categoryId);

        // Build category path
        $categoryPath = !empty($parentCategories)
            ? implode(' > ', $parentCategories) . ' > ' . $category['name']
            : $category['name'];

        // Try to find originating queue item for this category
        $queueTable = $wpdb->prefix . 'acms_cat_queue';
        $queueTableExists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $queueTable));
        $queueId = 0;
        if ($queueTableExists === $queueTable) {
            $queueId = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$queueTable}
                 WHERE assigned_category_id = %d
                 AND status != 'completed'
                 ORDER BY id DESC LIMIT 1",
                $categoryId
            ));
        }

        // Gather related categories for internal linking
        $relatedCategories = $this->categoryRepo->getInternalLinkContext($categoryId);

        // Gather brand link context (SEO brand pages + brand sub-categories)
        $brandLinks = $this->categoryRepo->getBrandLinkContext($categoryId, $products);

        // Prepare job input data
        $inputData = [
            'category_id' => $categoryId,
            'category_name' => $category['name'],
            'category_slug' => $category['slug'] ?? '',
            'category_path' => $categoryPath,
            'parent_categories' => $parentCategories,
            'products' => $products,
            'current_description' => $category['description'] ?? '',
            'queue_id' => $queueId,
            'related_categories' => $relatedCategories,
            'brand_links' => $brandLinks,
        ];

        // Add brand context if this is a brand-category
        if (!empty($category['brand_id'])) {
            $brandsTable = $wpdb->prefix . 'acms_brands';
            $brand = $wpdb->get_row($wpdb->prepare(
                "SELECT name FROM {$brandsTable} WHERE id = %d",
                (int) $category['brand_id']
            ), ARRAY_A);
            if ($brand) {
                $inputData['brand_name'] = $brand['name'];
                $inputData['brand_id'] = (int) $category['brand_id'];
            }
        }

        // Sanitize input data to ensure valid UTF-8 (prevents wp_json_encode failures)
        $inputData = $this->sanitizeForJson($inputData);
        $encodedInput = wp_json_encode($inputData, JSON_INVALID_UTF8_IGNORE);

        if ($encodedInput === false) {
            // Retry with aggressive cleaning
            $inputData = $this->sanitizeForJson($inputData, true);
            $encodedInput = wp_json_encode($inputData, JSON_INVALID_UTF8_IGNORE);

            if ($encodedInput === false) {
                return 'JSON encoding failed even after sanitization: ' . json_last_error_msg();
            }
        }

        // Create the job
        $inserted = $wpdb->insert($jobsTable, [
            'type' => 'generate_seo_category',
            'status' => 'pending',
            'priority' => 40,
            'target_type' => 'seo_category',
            'target_id' => (string) $categoryId,
            'input_data' => $encodedInput,
            'created_at' => current_time('mysql'),
        ]);

        if (!$inserted) {
            return 'DB insert failed: ' . $wpdb->last_error;
        }

        $jobId = (int) $wpdb->insert_id;

        return $jobId;
    }

    /**
     * Sanitize data for JSON encoding — ensures valid UTF-8
     *
     * Matches ProductAiCron::sanitizeForJson() to prevent wp_json_encode failures
     * when product titles/descriptions contain invalid UTF-8 characters.
     *
     * @param mixed $data Data to sanitize
     * @param bool $aggressive If true, strip invalid chars instead of converting
     * @return mixed Sanitized data
     */
    private function sanitizeForJson(mixed $data, bool $aggressive = false): mixed
    {
        if (is_string($data)) {
            if ($aggressive) {
                return mb_convert_encoding($data, 'UTF-8', 'UTF-8');
            }
            $encoding = mb_detect_encoding($data, 'UTF-8, ISO-8859-1, WINDOWS-1252', true);
            return $encoding ? mb_convert_encoding($data, 'UTF-8', $encoding) : mb_convert_encoding($data, 'UTF-8');
        }

        if (is_array($data)) {
            $sanitized = [];
            foreach ($data as $key => $value) {
                $sanitized[$key] = $this->sanitizeForJson($value, $aggressive);
            }
            return $sanitized;
        }

        if (is_object($data)) {
            return $this->sanitizeForJson((array) $data, $aggressive);
        }

        return $data;
    }

    /**
     * Process a job inline using JobProcessor (same as AS handler but synchronous)
     *
     * Uses atomic claim (UPDATE WHERE status=pending) to prevent double-processing
     * if AS runner also picks up the same job concurrently.
     */
    private function processJobInline(int $jobId, int $categoryId): void
    {
        if (!class_exists(\AffiliateCMS\AI\Core\JobProcessor::class)) {
            error_log("[ACMS CategoryAiCron] JobProcessor not available, relying on AS for job #{$jobId}");
            return;
        }

        global $wpdb;
        $table = $wpdb->prefix . 'acms_ai_jobs';

        // Atomic claim — prevents race condition if AS runner also tries to process
        $claimed = $wpdb->query($wpdb->prepare(
            "UPDATE {$table} SET status = 'processing', processing_at = %s
             WHERE id = %d AND status = 'pending'",
            current_time('mysql'),
            $jobId
        ));

        if ($claimed === 0) {
            error_log("[ACMS CategoryAiCron] Job #{$jobId} already claimed by AS runner, skipping inline");
            return;
        }

        try {
            $job = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$table} WHERE id = %d",
                $jobId
            ), ARRAY_A);

            if (!$job) {
                error_log("[ACMS CategoryAiCron] Job #{$jobId} not found after claim");
                return;
            }

            $processor = new \AffiliateCMS\AI\Core\JobProcessor();
            $processor->processSingleJob($job);
        } catch (\Throwable $e) {
            error_log("[ACMS CategoryAiCron] Inline processing failed for job #{$jobId}: " . $e->getMessage());

            $wpdb->update($table, [
                'status' => 'failed',
                'error_message' => 'Inline error: ' . substr($e->getMessage(), 0, 500),
            ], ['id' => $jobId]);

            // Reset category on failure so it can be retried
            $this->categoryRepo->update($categoryId, [
                'content_status' => 'empty',
                'ai_error_message' => substr($e->getMessage(), 0, 500),
            ]);
        }
    }

    /**
     * Get products in a category for AI context
     *
     * @param int $categoryId Category ID
     * @return array Product data array
     */
    private function getCategoryProducts(int $categoryId): array
    {
        global $wpdb;

        $junctionTable = $wpdb->prefix . 'acms_category_products';
        $productsTable = $wpdb->prefix . 'acms_products';

        // Check if junction table exists
        $tableExists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $junctionTable));
        if ($tableExists !== $junctionTable) {
            return [];
        }

        $products = $wpdb->get_results($wpdb->prepare(
            "SELECT p.asin, p.title, p.brand, p.category_path, p.rating, p.reviews_count
             FROM {$productsTable} p
             INNER JOIN {$junctionTable} cp ON cp.product_id = p.id
             WHERE cp.category_id = %d AND p.status = 'scraped'
             ORDER BY cp.is_primary DESC, p.rating DESC
             LIMIT 15",
            $categoryId
        ), ARRAY_A);

        return $products ?: [];
    }

    /**
     * Get parent category names for breadcrumb/context
     *
     * @param int $categoryId Category ID
     * @return array Parent category names from root to direct parent
     */
    private function getParentCategoryNames(int $categoryId): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'acms_categories';

        // Get current category's path
        $category = $wpdb->get_row($wpdb->prepare(
            "SELECT path, parent_id FROM {$table} WHERE id = %d",
            $categoryId
        ), ARRAY_A);

        if (!$category || empty($category['path']) || $category['path'] === '/') {
            return [];
        }

        // Extract parent IDs from path (e.g., "/1/5/23/" -> [1, 5, 23])
        $pathIds = array_filter(explode('/', trim($category['path'], '/')));
        if (empty($pathIds)) {
            return [];
        }

        // Get parent category names in order
        $placeholders = implode(',', array_fill(0, count($pathIds), '%d'));
        $names = $wpdb->get_results($wpdb->prepare(
            "SELECT id, name FROM {$table} WHERE id IN ({$placeholders}) ORDER BY depth ASC",
            ...$pathIds
        ), ARRAY_A);

        // Return names in correct order
        $nameMap = [];
        foreach ($names as $cat) {
            $nameMap[$cat['id']] = $cat['name'];
        }

        $result = [];
        foreach ($pathIds as $id) {
            if (isset($nameMap[$id])) {
                $result[] = $nameMap[$id];
            }
        }

        return $result;
    }

    /**
     * Unschedule the cron job
     */
    public function unschedule(): void
    {
        $timestamp = wp_next_scheduled(self::CRON_HOOK);
        if ($timestamp) {
            wp_unschedule_event($timestamp, self::CRON_HOOK);
        }
    }

    /**
     * Run the generation manually (for testing or manual trigger)
     *
     * Spawns category AI workers to process queued categories.
     *
     * @return array Result with count info
     */
    public function runManually(): array
    {
        $startTime = microtime(true);

        $queued = $this->categoryRepo->countQueuedForCategoryAi();

        if ($queued > 0) {
            $this->spawnCategoryAiWorkers();
        }

        $duration = round((microtime(true) - $startTime) * 1000);

        return [
            'success' => true,
            'message' => $queued > 0
                ? "Spawned category AI workers for {$queued} queued categories"
                : 'No categories queued for AI',
            'duration_ms' => $duration,
            'queued' => $queued,
            'workers' => $queued > 0 ? min($this->getCategoryAiWorkerCount(), $queued) : 0,
        ];
    }

    /**
     * Get next scheduled run time
     *
     * @return int|false Unix timestamp or false if not scheduled
     */
    public function getNextRun()
    {
        return wp_next_scheduled(self::CRON_HOOK);
    }

    /**
     * Get statistics about categories needing AI content
     *
     * @return array Statistics
     */
    public function getStats(): array
    {
        if (!\AffiliateCMS\Categories\Database\Schema::tablesExist()) {
            return ['empty' => 0, 'generating' => 0, 'generated' => 0, 'manual' => 0, 'template' => 0, 'failed' => 0, 'next_run' => false, 'category_ai_worker_count' => 0, 'claimable' => 0];
        }

        global $wpdb;
        $tables = \AffiliateCMS\Categories\Database\Schema::tables();
        $table = $tables['categories'];

        $empty = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$table}
             WHERE content_status = 'empty' AND product_count > 0 AND status = 'publish'"
        );

        $generating = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$table} WHERE content_status = 'ai_generating'"
        );

        $generated = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$table} WHERE content_status = 'ai_generated'"
        );

        $manual = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$table} WHERE content_status = 'manual'"
        );

        $template = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$table} WHERE content_status = 'template'"
        );

        $failed = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$table}
             WHERE content_status = 'empty' AND ai_error_message IS NOT NULL"
        );

        return [
            'empty' => (int) $empty,
            'generating' => (int) $generating,
            'generated' => (int) $generated,
            'manual' => (int) $manual,
            'template' => (int) $template,
            'failed' => (int) $failed,
            'next_run' => $this->getNextRun(),
            'category_ai_worker_count' => $this->getCategoryAiWorkerCount(),
            'claimable' => $this->categoryRepo->countQueuedForCategoryAi(),
        ];
    }
}
