<?php
/**
 * Brand-Category Auto-Creation Cron Job
 *
 * Self-contained cron that auto-creates brand-category records as regular
 * categories (with brand_id column set). These appear as child categories
 * of the source category and use the existing generate_seo_category job
 * type for AI content generation.
 *
 * @package AffiliateCMS\Categories\Core
 */

declare(strict_types=1);

namespace AffiliateCMS\Categories\Core;

use AffiliateCMS\Categories\Repositories\CategoryRepository;

class BrandCategoryAiCron
{
    public const CRON_HOOK = 'acms_brand_category_ai_generation';

    private const MIN_PRODUCT_COUNT = 1;
    private const AUTO_CREATE_LIMIT = 20;

    private static ?self $instance = null;

    public static function instance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct()
    {
    }

    public function register(): void
    {
        add_action(self::CRON_HOOK, [$this, 'generateContent']);
    }

    /**
     * Main entry point — called by server cron every 5 minutes.
     *
     * Only auto-creates brand-category records. AI content generation is
     * handled by the existing CategoryAiCron (generate_seo_category).
     */
    public function generateContent(): void
    {
        if (!\AffiliateCMS\Categories\Database\Schema::tablesExist()) {
            return;
        }

        // Check if feature is enabled
        if (!get_option('acms_ai_seo_brand_category_enabled', true)) {
            return;
        }

        // Auto-create brand-category records (throttled every 30 min)
        $this->autoCreateBrandCategories();
    }

    /**
     * Auto-create brand-category records as regular categories with brand_id set.
     *
     * Scans the category_products + products tables to find qualifying combinations.
     * Creates them as child categories of the source category.
     * Throttled to every 30 minutes.
     */
    private function autoCreateBrandCategories(): void
    {
        global $wpdb;

        $lastRun = get_transient('acms_bc_auto_create_last');
        if ($lastRun) {
            return;
        }
        set_transient('acms_bc_auto_create_last', time(), 1800); // 30 min

        $categoriesTable = $wpdb->prefix . 'acms_categories';
        $catProductsTable = $wpdb->prefix . 'acms_category_products';
        $productsTable = $wpdb->prefix . 'acms_products';
        $brandsTable = $wpdb->prefix . 'acms_brands';

        // Check if brands table exists
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $brandsTable)) !== $brandsTable) {
            return;
        }

        // Find brand/category combos with >= MIN_PRODUCT_COUNT products
        // that don't yet exist as brand-categories (child categories with brand_id set)
        // Only consider source categories WITHOUT brand_id
        $combos = $wpdb->get_results($wpdb->prepare(
            "SELECT cp.category_id, b.id as brand_id, b.name as brand_name,
                    c.name as category_name,
                    COUNT(DISTINCT p.id) as product_count
             FROM {$catProductsTable} cp
             JOIN {$productsTable} p ON cp.product_id = p.id
             JOIN {$brandsTable} b ON p.brand = b.name
             JOIN {$categoriesTable} c ON cp.category_id = c.id
             WHERE p.status = 'scraped'
             AND p.brand IS NOT NULL AND p.brand != ''
             AND c.status = 'publish'
             AND c.brand_id IS NULL
             AND b.status = 'publish'
             AND NOT EXISTS (
                 SELECT 1 FROM {$categoriesTable} bc
                 WHERE bc.parent_id = cp.category_id AND bc.brand_id = b.id
             )
             GROUP BY cp.category_id, b.id
             HAVING product_count >= %d
             ORDER BY product_count DESC
             LIMIT %d",
            self::MIN_PRODUCT_COUNT,
            self::AUTO_CREATE_LIMIT
        ), ARRAY_A);

        if (empty($combos)) {
            return;
        }

        $catRepo = new CategoryRepository();
        $created = 0;

        foreach ($combos as $combo) {
            $name = $combo['brand_name'] . ' ' . $combo['category_name'];
            $slug = $catRepo->generateUniqueSlug($name);
            $parentId = (int) $combo['category_id'];
            $brandId = (int) $combo['brand_id'];

            // Create as child category of the source category
            $categoryId = $catRepo->create([
                'parent_id' => $parentId,
                'name' => $name,
                'slug' => $slug,
                'brand_id' => $brandId,
                'status' => 'publish',
                'content_status' => 'empty',
            ]);

            if (!$categoryId) {
                continue;
            }

            // Assign brand-filtered products to the new category
            $this->assignBrandProducts($categoryId, $parentId, $combo['brand_name']);

            // Update product count
            $catRepo->updateProductCount($categoryId);

            $created++;
        }

        error_log("[ACMS BrandCategoryAiCron] Auto-created {$created} brand-category record(s) from " . count($combos) . " qualifying combos");
    }

    /**
     * Create brand-categories for a specific parent category (event-driven).
     *
     * Called immediately after a category's AI content is generated.
     * Bypasses the 30-minute transient throttle used by the periodic safety net.
     *
     * Only creates brand-categories for parent categories (brand_id IS NULL).
     * Returns the IDs of newly created brand-categories so the caller can
     * spawn category AI workers for them.
     *
     * @param int $parentCategoryId Parent category ID
     * @return array Created brand-category IDs
     */
    public function createBrandCategoriesForParent(int $parentCategoryId): array
    {
        if (!\AffiliateCMS\Categories\Database\Schema::tablesExist()) {
            return [];
        }

        global $wpdb;

        $categoriesTable = $wpdb->prefix . 'acms_categories';
        $catProductsTable = $wpdb->prefix . 'acms_category_products';
        $productsTable = $wpdb->prefix . 'acms_products';
        $brandsTable = $wpdb->prefix . 'acms_brands';

        // Check if brands table exists
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $brandsTable)) !== $brandsTable) {
            return [];
        }

        // Verify parent is valid: must exist, be published, and NOT be a brand-category itself
        $parent = $wpdb->get_row($wpdb->prepare(
            "SELECT id, name, brand_id, status FROM {$categoriesTable} WHERE id = %d",
            $parentCategoryId
        ), ARRAY_A);

        if (!$parent || $parent['brand_id'] !== null || $parent['status'] !== 'publish') {
            return [];
        }

        // Find brand combos for this specific parent
        $combos = $wpdb->get_results($wpdb->prepare(
            "SELECT b.id as brand_id, b.name as brand_name,
                    COUNT(DISTINCT p.id) as product_count
             FROM {$catProductsTable} cp
             JOIN {$productsTable} p ON cp.product_id = p.id
             JOIN {$brandsTable} b ON p.brand = b.name
             WHERE cp.category_id = %d
             AND p.status = 'scraped'
             AND p.brand IS NOT NULL AND p.brand != ''
             AND b.status = 'publish'
             AND NOT EXISTS (
                 SELECT 1 FROM {$categoriesTable} bc
                 WHERE bc.parent_id = %d AND bc.brand_id = b.id
             )
             GROUP BY b.id
             HAVING product_count >= %d
             ORDER BY product_count DESC
             LIMIT %d",
            $parentCategoryId,
            $parentCategoryId,
            self::MIN_PRODUCT_COUNT,
            self::AUTO_CREATE_LIMIT
        ), ARRAY_A);

        if (empty($combos)) {
            return [];
        }

        $catRepo = new CategoryRepository();
        $createdIds = [];

        foreach ($combos as $combo) {
            $name = $combo['brand_name'] . ' ' . $parent['name'];
            $slug = $catRepo->generateUniqueSlug($name);
            $brandId = (int) $combo['brand_id'];

            $categoryId = $catRepo->create([
                'parent_id' => $parentCategoryId,
                'name' => $name,
                'slug' => $slug,
                'brand_id' => $brandId,
                'status' => 'publish',
                'content_status' => 'empty',
            ]);

            if (!$categoryId) {
                continue;
            }

            // Assign brand-filtered products to the new category
            $this->assignBrandProducts($categoryId, $parentCategoryId, $combo['brand_name']);

            // Update product count
            $catRepo->updateProductCount($categoryId);

            $createdIds[] = $categoryId;
        }

        if (!empty($createdIds)) {
            error_log("[ACMS BrandCategoryAiCron] Created " . count($createdIds) . " brand-categories for parent #{$parentCategoryId} ({$parent['name']})");
        }

        return $createdIds;
    }

    /**
     * Assign products from the parent category (filtered by brand) to the new brand-category.
     */
    private function assignBrandProducts(int $categoryId, int $parentCategoryId, string $brandName): void
    {
        global $wpdb;

        $categoriesTable = $wpdb->prefix . 'acms_categories';
        $catProductsTable = $wpdb->prefix . 'acms_category_products';
        $productsTable = $wpdb->prefix . 'acms_products';

        // Get parent category path for descendant query
        $parent = $wpdb->get_row($wpdb->prepare(
            "SELECT path FROM {$categoriesTable} WHERE id = %d",
            $parentCategoryId
        ), ARRAY_A);

        if (!$parent) {
            return;
        }

        $parentPath = rtrim($parent['path'], '/');
        $descendantPattern = $parentPath . '/' . $parentCategoryId . '/%';

        // Get all products from parent + descendants filtered by brand
        // Exclude children that are themselves brand-categories
        $productIds = $wpdb->get_col($wpdb->prepare(
            "SELECT DISTINCT p.id
             FROM {$productsTable} p
             INNER JOIN {$catProductsTable} cp ON p.id = cp.product_id
             WHERE (cp.category_id = %d
                OR cp.category_id IN (SELECT id FROM {$categoriesTable} WHERE path LIKE %s AND brand_id IS NULL))
             AND p.brand = %s
             AND p.status = 'scraped'
             LIMIT 200",
            $parentCategoryId,
            $descendantPattern,
            $brandName
        ));

        if (empty($productIds)) {
            return;
        }

        // Bulk insert into category_products
        $values = [];
        $position = 0;
        foreach ($productIds as $productId) {
            $values[] = $wpdb->prepare("(%d, %d, %d, 0)", $categoryId, (int) $productId, $position++);
        }

        if (!empty($values)) {
            $wpdb->query(
                "INSERT IGNORE INTO {$catProductsTable} (category_id, product_id, position, is_primary) VALUES " . implode(',', $values)
            );
        }
    }
}
