<?php
/**
 * Review Repository for Product Reviews
 *
 * @package AffiliateCMS\Categories
 */

declare(strict_types=1);

namespace AffiliateCMS\Categories\Repositories;

use AffiliateCMS\Categories\Database\Schema;

class ReviewRepository
{
    private string $table;

    public function __construct()
    {
        $this->table = Schema::reviewsTable();
    }

    /**
     * Find a review by ID
     */
    public function find(int $id): ?array
    {
        global $wpdb;

        return $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$this->table} WHERE id = %d", $id),
            ARRAY_A
        ) ?: null;
    }

    /**
     * Get reviews for a product by product_id
     */
    public function getByProductId(int $productId, array $args = []): array
    {
        global $wpdb;

        $defaults = [
            'status' => 'approved',
            'orderby' => 'created_at',
            'order' => 'DESC',
            'limit' => 20,
            'offset' => 0,
        ];
        $args = array_merge($defaults, $args);

        $where = ['product_id = %d'];
        $params = [$productId];

        if (!empty($args['status'])) {
            $where[] = 'status = %s';
            $params[] = $args['status'];
        }

        $where_sql = implode(' AND ', $where);
        $orderby = sanitize_sql_orderby($args['orderby'] . ' ' . $args['order']) ?: 'created_at DESC';

        $sql = $wpdb->prepare(
            "SELECT * FROM {$this->table}
            WHERE {$where_sql}
            ORDER BY {$orderby}
            LIMIT %d OFFSET %d",
            array_merge($params, [(int) $args['limit'], (int) $args['offset']])
        );

        return $wpdb->get_results($sql, ARRAY_A) ?: [];
    }

    /**
     * Get reviews for a product by ASIN
     */
    public function getByAsin(string $asin, array $args = []): array
    {
        global $wpdb;

        $defaults = [
            'status' => 'approved',
            'orderby' => 'created_at',
            'order' => 'DESC',
            'limit' => 20,
            'offset' => 0,
        ];
        $args = array_merge($defaults, $args);

        $where = ['asin = %s'];
        $params = [$asin];

        if (!empty($args['status'])) {
            $where[] = 'status = %s';
            $params[] = $args['status'];
        }

        $where_sql = implode(' AND ', $where);
        $orderby = sanitize_sql_orderby($args['orderby'] . ' ' . $args['order']) ?: 'created_at DESC';

        $sql = $wpdb->prepare(
            "SELECT * FROM {$this->table}
            WHERE {$where_sql}
            ORDER BY {$orderby}
            LIMIT %d OFFSET %d",
            array_merge($params, [(int) $args['limit'], (int) $args['offset']])
        );

        return $wpdb->get_results($sql, ARRAY_A) ?: [];
    }

    /**
     * Get aggregate rating stats for a product
     */
    public function getProductStats(int $productId): array
    {
        global $wpdb;

        $stats = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT
                    COUNT(*) as review_count,
                    AVG(rating) as avg_rating,
                    SUM(CASE WHEN rating = 5 THEN 1 ELSE 0 END) as rating_5,
                    SUM(CASE WHEN rating = 4 THEN 1 ELSE 0 END) as rating_4,
                    SUM(CASE WHEN rating = 3 THEN 1 ELSE 0 END) as rating_3,
                    SUM(CASE WHEN rating = 2 THEN 1 ELSE 0 END) as rating_2,
                    SUM(CASE WHEN rating = 1 THEN 1 ELSE 0 END) as rating_1
                FROM {$this->table}
                WHERE product_id = %d AND status = 'approved'",
                $productId
            ),
            ARRAY_A
        );

        return [
            'review_count' => (int) ($stats['review_count'] ?? 0),
            'avg_rating' => round((float) ($stats['avg_rating'] ?? 0), 1),
            'distribution' => [
                5 => (int) ($stats['rating_5'] ?? 0),
                4 => (int) ($stats['rating_4'] ?? 0),
                3 => (int) ($stats['rating_3'] ?? 0),
                2 => (int) ($stats['rating_2'] ?? 0),
                1 => (int) ($stats['rating_1'] ?? 0),
            ],
        ];
    }

    /**
     * Get aggregate rating stats for a product by ASIN
     */
    public function getProductStatsByAsin(string $asin): array
    {
        global $wpdb;

        $stats = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT
                    COUNT(*) as review_count,
                    AVG(rating) as avg_rating,
                    SUM(CASE WHEN rating = 5 THEN 1 ELSE 0 END) as rating_5,
                    SUM(CASE WHEN rating = 4 THEN 1 ELSE 0 END) as rating_4,
                    SUM(CASE WHEN rating = 3 THEN 1 ELSE 0 END) as rating_3,
                    SUM(CASE WHEN rating = 2 THEN 1 ELSE 0 END) as rating_2,
                    SUM(CASE WHEN rating = 1 THEN 1 ELSE 0 END) as rating_1
                FROM {$this->table}
                WHERE asin = %s AND status = 'approved'",
                $asin
            ),
            ARRAY_A
        );

        return [
            'review_count' => (int) ($stats['review_count'] ?? 0),
            'avg_rating' => round((float) ($stats['avg_rating'] ?? 0), 1),
            'distribution' => [
                5 => (int) ($stats['rating_5'] ?? 0),
                4 => (int) ($stats['rating_4'] ?? 0),
                3 => (int) ($stats['rating_3'] ?? 0),
                2 => (int) ($stats['rating_2'] ?? 0),
                1 => (int) ($stats['rating_1'] ?? 0),
            ],
        ];
    }

    /**
     * Create a new review
     */
    public function create(array $data): int
    {
        global $wpdb;

        $defaults = [
            'product_id' => 0,
            'asin' => '',
            'user_id' => null,
            'author_name' => '',
            'author_email' => '',
            'rating' => 5,
            'title' => '',
            'content' => '',
            'pros' => null,
            'cons' => null,
            'verified_purchase' => 0,
            'helpful_count' => 0,
            'unhelpful_count' => 0,
            'status' => 'pending',
            'ip_address' => null,
            'user_agent' => null,
        ];

        $data = array_merge($defaults, $data);

        // Sanitize
        $insert_data = [
            'product_id' => (int) $data['product_id'],
            'asin' => sanitize_text_field($data['asin']),
            'user_id' => $data['user_id'] ? (int) $data['user_id'] : null,
            'author_name' => sanitize_text_field($data['author_name']),
            'author_email' => sanitize_email($data['author_email']),
            'rating' => max(1, min(5, (int) $data['rating'])),
            'title' => sanitize_text_field($data['title']),
            'content' => wp_kses_post($data['content']),
            'pros' => $data['pros'] ? wp_json_encode($data['pros']) : null,
            'cons' => $data['cons'] ? wp_json_encode($data['cons']) : null,
            'verified_purchase' => (int) $data['verified_purchase'],
            'helpful_count' => (int) $data['helpful_count'],
            'unhelpful_count' => (int) $data['unhelpful_count'],
            'status' => in_array($data['status'], ['pending', 'approved', 'spam', 'trash']) ? $data['status'] : 'pending',
            'ip_address' => $data['ip_address'] ? sanitize_text_field($data['ip_address']) : null,
            'user_agent' => $data['user_agent'] ? sanitize_text_field(substr($data['user_agent'], 0, 255)) : null,
        ];

        $wpdb->insert($this->table, $insert_data);

        return (int) $wpdb->insert_id;
    }

    /**
     * Update a review
     */
    public function update(int $id, array $data): bool
    {
        global $wpdb;

        $update_data = [];

        if (isset($data['rating'])) {
            $update_data['rating'] = max(1, min(5, (int) $data['rating']));
        }
        if (isset($data['title'])) {
            $update_data['title'] = sanitize_text_field($data['title']);
        }
        if (isset($data['content'])) {
            $update_data['content'] = wp_kses_post($data['content']);
        }
        if (isset($data['pros'])) {
            $update_data['pros'] = $data['pros'] ? wp_json_encode($data['pros']) : null;
        }
        if (isset($data['cons'])) {
            $update_data['cons'] = $data['cons'] ? wp_json_encode($data['cons']) : null;
        }
        if (isset($data['status'])) {
            $update_data['status'] = in_array($data['status'], ['pending', 'approved', 'spam', 'trash']) ? $data['status'] : 'pending';
        }
        if (isset($data['helpful_count'])) {
            $update_data['helpful_count'] = (int) $data['helpful_count'];
        }
        if (isset($data['unhelpful_count'])) {
            $update_data['unhelpful_count'] = (int) $data['unhelpful_count'];
        }
        if (isset($data['admin_notes'])) {
            $update_data['admin_notes'] = sanitize_textarea_field($data['admin_notes']);
        }

        if (empty($update_data)) {
            return false;
        }

        $result = $wpdb->update($this->table, $update_data, ['id' => $id]);

        return $result !== false;
    }

    /**
     * Delete a review
     */
    public function delete(int $id): bool
    {
        global $wpdb;

        return (bool) $wpdb->delete($this->table, ['id' => $id]);
    }

    /**
     * Increment helpful count
     */
    public function incrementHelpful(int $id): bool
    {
        global $wpdb;

        return (bool) $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$this->table} SET helpful_count = helpful_count + 1 WHERE id = %d",
                $id
            )
        );
    }

    /**
     * Increment unhelpful count
     */
    public function incrementUnhelpful(int $id): bool
    {
        global $wpdb;

        return (bool) $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$this->table} SET unhelpful_count = unhelpful_count + 1 WHERE id = %d",
                $id
            )
        );
    }

    /**
     * Check if user has already reviewed a product
     */
    public function hasUserReviewed(int $productId, ?int $userId = null, ?string $email = null): bool
    {
        global $wpdb;

        if ($userId) {
            $exists = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT id FROM {$this->table} WHERE product_id = %d AND user_id = %d LIMIT 1",
                    $productId,
                    $userId
                )
            );
            if ($exists) return true;
        }

        if ($email) {
            $exists = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT id FROM {$this->table} WHERE product_id = %d AND author_email = %s LIMIT 1",
                    $productId,
                    $email
                )
            );
            if ($exists) return true;
        }

        return false;
    }

    /**
     * Get all reviews with pagination (admin)
     */
    public function getAll(array $args = []): array
    {
        global $wpdb;

        $defaults = [
            'status' => null,
            'product_id' => null,
            'asin' => null,
            'search' => null,
            'orderby' => 'created_at',
            'order' => 'DESC',
            'limit' => 20,
            'offset' => 0,
        ];
        $args = array_merge($defaults, $args);

        $where = ['1=1'];
        $params = [];

        if ($args['status']) {
            $where[] = 'status = %s';
            $params[] = $args['status'];
        }
        if ($args['product_id']) {
            $where[] = 'product_id = %d';
            $params[] = (int) $args['product_id'];
        }
        if ($args['asin']) {
            $where[] = 'asin = %s';
            $params[] = $args['asin'];
        }
        if ($args['search']) {
            $where[] = '(title LIKE %s OR content LIKE %s OR author_name LIKE %s)';
            $search = '%' . $wpdb->esc_like($args['search']) . '%';
            $params[] = $search;
            $params[] = $search;
            $params[] = $search;
        }

        $where_sql = implode(' AND ', $where);
        $orderby = sanitize_sql_orderby($args['orderby'] . ' ' . $args['order']) ?: 'created_at DESC';

        // Get total count
        $count_sql = "SELECT COUNT(*) FROM {$this->table} WHERE {$where_sql}";
        if (!empty($params)) {
            $count_sql = $wpdb->prepare($count_sql, $params);
        }
        $total = (int) $wpdb->get_var($count_sql);

        // Get results
        $sql = "SELECT * FROM {$this->table} WHERE {$where_sql} ORDER BY {$orderby} LIMIT %d OFFSET %d";
        $all_params = array_merge($params, [(int) $args['limit'], (int) $args['offset']]);
        $results = $wpdb->get_results($wpdb->prepare($sql, $all_params), ARRAY_A) ?: [];

        return [
            'items' => $results,
            'total' => $total,
            'pages' => ceil($total / max(1, $args['limit'])),
        ];
    }

    /**
     * Get counts by status (for admin tabs)
     */
    public function getStatusCounts(): array
    {
        global $wpdb;

        $results = $wpdb->get_results(
            "SELECT status, COUNT(*) as count FROM {$this->table} GROUP BY status",
            ARRAY_A
        );

        $counts = [
            'all' => 0,
            'pending' => 0,
            'approved' => 0,
            'spam' => 0,
            'trash' => 0,
        ];

        foreach ($results as $row) {
            $counts[$row['status']] = (int) $row['count'];
            $counts['all'] += (int) $row['count'];
        }

        return $counts;
    }

    /**
     * Bulk update status
     */
    public function bulkUpdateStatus(array $ids, string $status): int
    {
        global $wpdb;

        if (empty($ids) || !in_array($status, ['pending', 'approved', 'spam', 'trash'])) {
            return 0;
        }

        $ids = array_map('intval', $ids);
        $placeholders = implode(',', array_fill(0, count($ids), '%d'));

        return (int) $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$this->table} SET status = %s WHERE id IN ({$placeholders})",
                array_merge([$status], $ids)
            )
        );
    }

    /**
     * Bulk delete reviews
     */
    public function bulkDelete(array $ids): int
    {
        global $wpdb;

        if (empty($ids)) {
            return 0;
        }

        $ids = array_map('intval', $ids);
        $placeholders = implode(',', array_fill(0, count($ids), '%d'));

        return (int) $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$this->table} WHERE id IN ({$placeholders})",
                $ids
            )
        );
    }
}
