<?php
/**
 * Queue Repository for Category Keywords
 *
 * @package AffiliateCMS\Categories
 */

declare(strict_types=1);

namespace AffiliateCMS\Categories\Repositories;

use AffiliateCMS\Categories\Database\Schema;

class QueueRepository
{
    private string $table;

    public function __construct()
    {
        $this->table = Schema::queueTable();
    }

    public function find(int $id): ?array
    {
        global $wpdb;

        return $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$this->table} WHERE id = %d", $id),
            ARRAY_A
        ) ?: null;
    }

    public function create(array $data): int
    {
        global $wpdb;

        $defaults = [
            'keyword' => '',
            'search_limit' => 20,
            'search_domain' => 'amazon.com',
            'status' => 'pending',
            'attempts' => 0,
            'max_attempts' => 3,
        ];

        $data = array_merge($defaults, $data);

        $wpdb->insert($this->table, [
            'keyword' => sanitize_text_field($data['keyword']),
            'search_limit' => (int) $data['search_limit'],
            'search_domain' => sanitize_text_field($data['search_domain']),
            'status' => $data['status'],
            'attempts' => (int) $data['attempts'],
            'max_attempts' => (int) $data['max_attempts'],
        ]);

        return (int) $wpdb->insert_id;
    }

    public function bulkCreate(array $keywords, array $settings = []): int
    {
        global $wpdb;

        $defaults = [
            'search_limit' => 20,
            'max_search_pages' => 3,
            'search_domain' => 'amazon.com',
            'linked_asins' => null,
            'search_status' => 'not_searched',
            'status' => 'pending',
            'products_found' => 0,
            'custom_category_path' => null,
        ];

        $settings = array_merge($defaults, $settings);
        $inserted = 0;

        foreach ($keywords as $keyword) {
            $keyword = trim($keyword);
            if (empty($keyword)) continue;

            // Skip if keyword already exists (any active status)
            $exists = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$this->table} WHERE keyword = %s AND status != 'failed'",
                $keyword
            ));

            if ($exists) continue;

            // Build insert data
            $insertData = [
                'keyword' => sanitize_text_field($keyword),
                'search_limit' => (int) $settings['search_limit'],
                'max_search_pages' => (int) $settings['max_search_pages'],
                'search_domain' => sanitize_text_field($settings['search_domain']),
                'status' => $settings['status'],
                'search_status' => $settings['search_status'],
                'ai_status' => 'not_started',
            ];

            // Add linked_asins if provided
            if (!empty($settings['linked_asins'])) {
                $insertData['linked_asins'] = wp_json_encode($settings['linked_asins']);
                $insertData['products_found'] = (int) $settings['products_found'];
                $insertData['ai_status'] = 'waiting_scrape';  // Set to waiting since ASINs provided
            }

            // Add custom category path if provided
            if (!empty($settings['custom_category_path'])) {
                $insertData['custom_category_path'] = sanitize_text_field($settings['custom_category_path']);
            }

            $wpdb->insert($this->table, $insertData);

            if ($wpdb->insert_id) $inserted++;
        }

        return $inserted;
    }

    public function update(int $id, array $data): bool
    {
        global $wpdb;

        $data['updated_at'] = current_time('mysql');

        return $wpdb->update($this->table, $data, ['id' => $id]) !== false;
    }

    public function delete(int $id): bool
    {
        global $wpdb;
        return $wpdb->delete($this->table, ['id' => $id]) !== false;
    }

    public function getNextPending(): ?array
    {
        global $wpdb;

        return $wpdb->get_row(
            "SELECT * FROM {$this->table}
             WHERE status = 'pending'
             ORDER BY created_at ASC
             LIMIT 1",
            ARRAY_A
        ) ?: null;
    }

    /**
     * Atomically claim next pending item for processing
     * Prevents race conditions in concurrent processing
     */
    public function claimNext(): ?array
    {
        global $wpdb;

        $wpdb->query(
            "UPDATE {$this->table}
             SET status = 'processing',
                 started_at = '" . current_time('mysql') . "',
                 attempts = attempts + 1,
                 id = LAST_INSERT_ID(id)
             WHERE status = 'pending'
             ORDER BY created_at ASC
             LIMIT 1"
        );

        if ($wpdb->rows_affected === 0) {
            return null;
        }

        $id = $wpdb->get_var("SELECT LAST_INSERT_ID()");
        return $id ? $this->find((int) $id) : null;
    }

    public function markCompleted(int $id, array $results = []): bool
    {
        return $this->update($id, [
            'status' => 'completed',
            'completed_at' => current_time('mysql'),
            'products_found' => (int) ($results['products_found'] ?? 0),
            'categories_created' => (int) ($results['categories_created'] ?? 0),
            'linked_asins' => isset($results['linked_asins']) ? wp_json_encode($results['linked_asins']) : null,
            'error_message' => null,
        ]);
    }

    public function markFailed(int $id, string $error): bool
    {
        $item = $this->find($id);
        if (!$item) return false;

        $attempts = (int) $item['attempts'];
        $maxAttempts = (int) $item['max_attempts'];

        if ($attempts >= $maxAttempts) {
            return $this->update($id, [
                'status' => 'failed',
                'error_message' => $error,
            ]);
        }

        // Reset to pending for retry
        return $this->update($id, [
            'status' => 'pending',
            'error_message' => $error,
        ]);
    }

    public function updateLog(int $id, array $log): bool
    {
        global $wpdb;

        return $wpdb->update($this->table, [
            'processing_log' => wp_json_encode($log),
        ], ['id' => $id]) !== false;
    }

    public function getAll(array $args = []): array
    {
        global $wpdb;

        $defaults = [
            'status' => '',
            'search' => '',
            'page' => 1,
            'per_page' => 20,
            'orderby' => 'created_at',
            'order' => 'DESC',
        ];

        $args = array_merge($defaults, $args);

        $where = ['1=1'];
        $params = [];

        if (!empty($args['status'])) {
            $where[] = 'q.status = %s';
            $params[] = $args['status'];
        }

        if (!empty($args['search'])) {
            $like = '%' . $wpdb->esc_like($args['search']) . '%';
            $where[] = '(q.keyword LIKE %s OR q.error_message LIKE %s)';
            $params[] = $like;
            $params[] = $like;
        }

        $where_clause = implode(' AND ', $where);

        $categoriesTable = $wpdb->prefix . 'acms_categories';

        // Count total (with JOIN for consistency)
        $count_query = "SELECT COUNT(*) FROM {$this->table} q
                        LEFT JOIN {$categoriesTable} c ON q.assigned_category_id = c.id
                        WHERE {$where_clause}";
        $total = (int) $wpdb->get_var(
            empty($params) ? $count_query : $wpdb->prepare($count_query, ...$params)
        );

        // Get items
        $sortableColumns = [
            'id', 'keyword', 'status', 'created_at', 'scrape_progress',
            'ai_status', 'products_found', 'search_status',
        ];
        $orderby = in_array($args['orderby'], $sortableColumns, true)
            ? $args['orderby'] : 'created_at';
        $order = strtoupper($args['order']) === 'ASC' ? 'ASC' : 'DESC';

        $page = max(1, (int) $args['page']);
        $per_page = max(1, min(100, (int) $args['per_page']));
        $offset = ($page - 1) * $per_page;

        // LEFT JOIN with categories to get category info
        $query = "SELECT q.*, c.product_count as category_count, c.content_status as category_content_status, c.name as category_name, c.slug as category_slug, c.parent_id as category_parent_id
                  FROM {$this->table} q
                  LEFT JOIN {$categoriesTable} c ON q.assigned_category_id = c.id
                  WHERE {$where_clause}
                  ORDER BY q.{$orderby} {$order}
                  LIMIT {$per_page} OFFSET {$offset}";

        $items = $wpdb->get_results(
            empty($params) ? $query : $wpdb->prepare($query, ...$params),
            ARRAY_A
        ) ?: [];

        return [
            'items' => $items,
            'total' => $total,
            'page' => $page,
            'per_page' => $per_page,
            'total_pages' => (int) ceil($total / $per_page),
        ];
    }

    public function getStats(): array
    {
        global $wpdb;

        $results = $wpdb->get_results(
            "SELECT status, COUNT(*) as count FROM {$this->table} GROUP BY status",
            ARRAY_A
        );

        $stats = [
            'total' => 0,
            'pending' => 0,
            'processing' => 0,
            'searched' => 0,
            'ready_for_ai' => 0,
            'completed' => 0,
            'failed' => 0,
        ];

        foreach ($results as $row) {
            if (isset($stats[$row['status']])) {
                $stats[$row['status']] = (int) $row['count'];
            }
            $stats['total'] += (int) $row['count'];
        }

        return $stats;
    }

    public function clearCompleted(): int
    {
        global $wpdb;

        return (int) $wpdb->query(
            "DELETE FROM {$this->table} WHERE status = 'completed'"
        );
    }

    public function resetFailed(): int
    {
        global $wpdb;

        return (int) $wpdb->query(
            "UPDATE {$this->table}
             SET status = 'pending',
                 search_status = 'not_searched',
                 ai_status = 'not_started',
                 scrape_progress = 0,
                 attempts = 0,
                 error_message = NULL,
                 ai_analysis_result = NULL,
                 suggested_categories = NULL,
                 cat_ai_generation_id = NULL,
                 assigned_category_id = NULL
             WHERE status = 'failed'"
        );
    }

    /**
     * Reset stuck processing items (processing for more than X minutes)
     */
    public function resetStuckProcessing(int $minutes = 10): int
    {
        global $wpdb;

        return (int) $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$this->table}
                 SET status = 'pending',
                     search_status = 'not_searched',
                     ai_status = 'not_started',
                     scrape_progress = 0,
                     started_at = NULL,
                     error_message = 'Reset: stuck in processing'
                 WHERE status = 'processing'
                 AND started_at < DATE_SUB(NOW(), INTERVAL %d MINUTE)",
                $minutes
            )
        );
    }

    /**
     * Force reset a specific item regardless of status
     */
    public function forceReset(int $id): bool
    {
        global $wpdb;

        return $wpdb->update($this->table, [
            'status' => 'pending',
            'search_status' => 'not_searched',
            'ai_status' => 'not_started',
            'scrape_progress' => 0,
            'attempts' => 0,
            'started_at' => null,
            'completed_at' => null,
            'error_message' => null,
            'linked_asins' => null,
            'products_found' => 0,
            'categories_created' => 0,
            'processing_log' => null,
            'ai_analysis_result' => null,
            'suggested_categories' => null,
            'cat_ai_generation_id' => null,
            'assigned_category_id' => null,
        ], ['id' => $id]) !== false;
    }

    /**
     * Force delete a specific item regardless of status
     */
    public function forceDelete(int $id): bool
    {
        global $wpdb;
        return $wpdb->delete($this->table, ['id' => $id]) !== false;
    }

    /**
     * Get queue items ready for category AI standardization
     * Items with scrape_progress >= threshold that haven't been processed by category AI yet
     *
     * @param int $scrapeThreshold Minimum scrape progress percentage (default 50)
     * @param int $limit Maximum items to return
     */
    public function getReadyForCategoryAi(int $scrapeThreshold = 50, int $limit = 10): array
    {
        global $wpdb;

        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$this->table}
                 WHERE scrape_progress >= %d
                 AND ai_status IN ('waiting_scrape', 'analyzing_category')
                 AND suggested_categories IS NULL
                 AND linked_asins IS NOT NULL
                 ORDER BY scrape_progress DESC, created_at ASC
                 LIMIT %d",
                $scrapeThreshold,
                $limit
            ),
            ARRAY_A
        ) ?: [];
    }

    /**
     * Update category AI results for a queue item
     */
    public function updateCategoryAiResult(int $id, array $suggestedCategories, string $generationId): bool
    {
        return $this->update($id, [
            'suggested_categories' => wp_json_encode($suggestedCategories),
            'cat_ai_generation_id' => $generationId,
            'ai_status' => 'category_assigned',
        ]);
    }
}
