<?php
/**
 * Category Repository - Data Access Layer
 *
 * Handles all database operations for categories
 * Implements Materialized Path pattern for hierarchy
 *
 * @package AffiliateCMS\Categories
 */

declare(strict_types=1);

namespace AffiliateCMS\Categories\Repositories;

use AffiliateCMS\Categories\Database\Schema;

class CategoryRepository
{
    private string $table;
    private string $products_table;
    private string $meta_table;

    public function __construct()
    {
        $tables = Schema::tables();
        $this->table = $tables['categories'];
        $this->products_table = $tables['category_products'];
        $this->meta_table = $tables['category_meta'];
    }

    public function find(int $id): ?array
    {
        global $wpdb;

        $cache_key = "acms_cat_{$id}";
        $cached = wp_cache_get($cache_key, 'acms_categories');

        if ($cached !== false) {
            return $cached ?: null;
        }

        $result = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$this->table} WHERE id = %d", $id),
            ARRAY_A
        );

        wp_cache_set($cache_key, $result ?: [], 'acms_categories', 3600);
        return $result ?: null;
    }

    public function findBySlug(string $slug): ?array
    {
        global $wpdb;

        $cache_key = "acms_cat_slug_{$slug}";
        $cached = wp_cache_get($cache_key, 'acms_categories');

        if ($cached !== false) {
            return $cached ?: null;
        }

        $result = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$this->table} WHERE slug = %s", $slug),
            ARRAY_A
        );

        wp_cache_set($cache_key, $result ?: [], 'acms_categories', 3600);
        return $result ?: null;
    }

    /**
     * Invalidate object cache for a category (by ID and slug)
     */
    private function invalidateCache(int $id, ?string $slug = null): void
    {
        wp_cache_delete("acms_cat_{$id}", 'acms_categories');
        if ($slug) {
            wp_cache_delete("acms_cat_slug_{$slug}", 'acms_categories');
        }
    }

    public function create(array $data): int
    {
        global $wpdb;

        if (empty($data['slug'])) {
            $data['slug'] = $this->generateUniqueSlug($data['name']);
        } else {
            // Ensure provided slug is unique (slug column has UNIQUE constraint)
            $data['slug'] = $this->generateUniqueSlug($data['slug']);
        }

        $parent_id = (int) ($data['parent_id'] ?? 0);
        if ($parent_id > 0) {
            $parent = $this->find($parent_id);
            if ($parent) {
                $data['path'] = $parent['path'] . $parent['id'] . '/';
                $data['depth'] = $parent['depth'] + 1;
            }
        } else {
            $data['path'] = '/';
            $data['depth'] = 0;
        }

        if (!isset($data['position'])) {
            $data['position'] = $this->getNextPosition($parent_id);
        }

        $wpdb->insert($this->table, $data);
        $id = (int) $wpdb->insert_id;

        if ($parent_id > 0) {
            $this->updateChildCount($parent_id);
        }

        do_action('acms_cat_created', $id, $data);
        return $id;
    }

    public function update(int $id, array $data): bool
    {
        global $wpdb;

        $old_category = $this->find($id);
        if (!$old_category) {
            return false;
        }

        $parent_changed = isset($data['parent_id']) && (int) $data['parent_id'] !== (int) $old_category['parent_id'];

        if ($parent_changed) {
            $this->moveCategory($id, (int) $data['parent_id']);
            unset($data['parent_id'], $data['path'], $data['depth']);
        }

        if (isset($data['slug']) && $data['slug'] !== $old_category['slug']) {
            $data['slug'] = $this->generateUniqueSlug($data['slug'], $id);
        }

        $data['updated_at'] = current_time('mysql');
        $result = $wpdb->update($this->table, $data, ['id' => $id]);

        // Invalidate object cache (critical with Redis persistent cache)
        $this->invalidateCache($id, $old_category['slug'] ?? null);
        if (isset($data['slug']) && $data['slug'] !== ($old_category['slug'] ?? '')) {
            $this->invalidateCache($id, $data['slug']);
        }

        do_action('acms_cat_updated', $id, $data, $old_category);
        return $result !== false;
    }

    public function delete(int $id, bool $reassign_children = true): bool
    {
        global $wpdb;

        $category = $this->find($id);
        if (!$category) {
            return false;
        }

        // Use 'all' status to catch children in any status (publish, draft, etc.)
        $children = $this->getChildren($id, 'all');
        if (!empty($children)) {
            if ($reassign_children) {
                foreach ($children as $child) {
                    $this->moveCategory((int) $child['id'], (int) $category['parent_id']);
                }
            } else {
                foreach ($children as $child) {
                    $this->delete((int) $child['id'], false);
                }
            }
        }

        $wpdb->delete($this->products_table, ['category_id' => $id]);
        $wpdb->delete($this->meta_table, ['category_id' => $id]);
        $result = $wpdb->delete($this->table, ['id' => $id]);

        // Invalidate object cache
        $this->invalidateCache($id, $category['slug'] ?? null);

        if ($category['parent_id'] > 0) {
            $this->updateChildCount((int) $category['parent_id']);
        }

        do_action('acms_cat_deleted', $id, $category);
        return $result !== false;
    }

    public function getChildren(int $parent_id, string $status = 'publish'): array
    {
        global $wpdb;

        $where = ['parent_id = %d'];
        $params = [$parent_id];

        if ($status !== 'all') {
            $where[] = 'status = %s';
            $params[] = $status;
        }

        $where_clause = implode(' AND ', $where);

        return $wpdb->get_results(
            $wpdb->prepare("SELECT * FROM {$this->table} WHERE {$where_clause} ORDER BY position ASC, name ASC", ...$params),
            ARRAY_A
        ) ?: [];
    }

    /**
     * Lightweight children query for tree navigation (no LONGTEXT fields).
     */
    public function getChildrenNav(int $parent_id, string $status = 'publish'): array
    {
        global $wpdb;

        $where = ['parent_id = %d'];
        $params = [$parent_id];

        if ($status !== 'all') {
            $where[] = 'status = %s';
            $params[] = $status;
        }

        $where_clause = implode(' AND ', $where);

        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, name, slug, parent_id, icon, product_count, child_count, brand_id
                 FROM {$this->table}
                 WHERE {$where_clause}
                 ORDER BY position ASC, name ASC",
                ...$params
            ),
            ARRAY_A
        ) ?: [];
    }

    public function getDescendants(int $category_id, string $status = 'publish'): array
    {
        global $wpdb;

        $category = $this->find($category_id);
        if (!$category) {
            return [];
        }

        $path_pattern = $category['path'] . $category_id . '/%';
        $where = ['path LIKE %s'];
        $params = [$path_pattern];

        if ($status !== 'all') {
            $where[] = 'status = %s';
            $params[] = $status;
        }

        $where_clause = implode(' AND ', $where);

        return $wpdb->get_results(
            $wpdb->prepare("SELECT * FROM {$this->table} WHERE {$where_clause} ORDER BY path ASC, position ASC", ...$params),
            ARRAY_A
        ) ?: [];
    }

    public function getAncestors(int $category_id): array
    {
        global $wpdb;

        $category = $this->find($category_id);
        if (!$category || $category['path'] === '/') {
            return [];
        }

        $path = trim($category['path'], '/');
        if (empty($path)) {
            return [];
        }

        $ancestor_ids = array_map('intval', explode('/', $path));
        $placeholders = implode(',', array_fill(0, count($ancestor_ids), '%d'));

        return $wpdb->get_results(
            $wpdb->prepare("SELECT * FROM {$this->table} WHERE id IN ({$placeholders}) ORDER BY depth ASC", ...$ancestor_ids),
            ARRAY_A
        ) ?: [];
    }

    public function getBreadcrumb(int $category_id): array
    {
        $ancestors = $this->getAncestors($category_id);
        $current = $this->find($category_id);

        if ($current) {
            $ancestors[] = $current;
        }
        return $ancestors;
    }

    public function moveCategory(int $category_id, int $new_parent_id): bool
    {
        global $wpdb;

        $category = $this->find($category_id);
        if (!$category || $new_parent_id === $category_id) {
            return false;
        }

        $descendants = $this->getDescendants($category_id, 'all');
        foreach ($descendants as $desc) {
            if ((int) $desc['id'] === $new_parent_id) {
                return false;
            }
        }

        $old_path = $category['path'];
        $old_full_path = $old_path . $category_id . '/';

        if ($new_parent_id > 0) {
            $new_parent = $this->find($new_parent_id);
            if (!$new_parent) {
                return false;
            }
            $new_path = $new_parent['path'] . $new_parent_id . '/';
            $new_depth = $new_parent['depth'] + 1;
        } else {
            $new_path = '/';
            $new_depth = 0;
        }

        $new_full_path = $new_path . $category_id . '/';
        $depth_diff = $new_depth - $category['depth'];

        $wpdb->update($this->table, ['parent_id' => $new_parent_id, 'path' => $new_path, 'depth' => $new_depth], ['id' => $category_id]);
        $this->invalidateCache($category_id, $category['slug'] ?? null);

        foreach ($descendants as $desc) {
            $desc_new_path = str_replace($old_full_path, $new_full_path, $desc['path']);
            $wpdb->update($this->table, ['path' => $desc_new_path, 'depth' => $desc['depth'] + $depth_diff], ['id' => $desc['id']]);
            $this->invalidateCache((int) $desc['id'], $desc['slug'] ?? null);
        }

        if ($category['parent_id'] > 0) {
            $this->updateChildCount((int) $category['parent_id']);
        }
        if ($new_parent_id > 0) {
            $this->updateChildCount($new_parent_id);
        }

        do_action('acms_cat_moved', $category_id, $new_parent_id, $category['parent_id']);
        return true;
    }

    public function getTree(string $status = 'publish'): array
    {
        $cache_key = "acms_cat_tree_{$status}";
        $cached = wp_cache_get($cache_key, 'acms_categories');

        if ($cached !== false) {
            return $cached;
        }

        $all = $this->getAll($status);
        $tree = $this->buildTree($all);

        wp_cache_set($cache_key, $tree, 'acms_categories', 3600);
        return $tree;
    }

    private function buildTree(array $categories, int $parent_id = 0): array
    {
        $tree = [];
        foreach ($categories as $category) {
            if ((int) $category['parent_id'] === $parent_id) {
                $category['children'] = $this->buildTree($categories, (int) $category['id']);
                $tree[] = $category;
            }
        }
        return $tree;
    }

    public function getAll(string $status = 'publish'): array
    {
        global $wpdb;

        $cache_key = "acms_cat_all_{$status}";
        $cached = wp_cache_get($cache_key, 'acms_categories');

        if ($cached !== false) {
            return $cached;
        }

        $where = $status !== 'all' ? $wpdb->prepare(' WHERE status = %s', $status) : '';

        $results = $wpdb->get_results("SELECT * FROM {$this->table}{$where} ORDER BY path ASC, position ASC, name ASC", ARRAY_A) ?: [];

        wp_cache_set($cache_key, $results, 'acms_categories', 3600);
        return $results;
    }

    /**
     * Get lightweight category list for dropdowns/selects.
     * Only fetches fields needed for parent selection UI — avoids loading
     * heavy content_main/description fields (avg ~5KB each × 100K rows = OOM).
     */
    public function getAllForSelect(string $status = 'all'): array
    {
        global $wpdb;

        $cache_key = "acms_cat_select_{$status}";
        $cached = wp_cache_get($cache_key, 'acms_categories');

        if ($cached !== false) {
            return $cached;
        }

        $where = $status !== 'all' ? $wpdb->prepare(' WHERE status = %s', $status) : '';

        $results = $wpdb->get_results(
            "SELECT id, name, slug, parent_id, path, depth, position, status FROM {$this->table}{$where} ORDER BY path ASC, position ASC, name ASC",
            ARRAY_A
        ) ?: [];

        wp_cache_set($cache_key, $results, 'acms_categories', 3600);
        return $results;
    }

    public function getRoots(string $status = 'publish'): array
    {
        return $this->getChildren(0, $status);
    }

    public function getFeatured(int $limit = 10): array
    {
        global $wpdb;

        return $wpdb->get_results(
            $wpdb->prepare("SELECT * FROM {$this->table} WHERE status = 'publish' AND is_featured = 1 ORDER BY position ASC, product_count DESC LIMIT %d", $limit),
            ARRAY_A
        ) ?: [];
    }

    /**
     * Search categories by keyword
     *
     * Searches in: name, slug, seo_title
     * Returns with breadcrumb path and URL for autocomplete/search UIs
     *
     * @param string $term Search keyword
     * @param int $limit Max results (default 15)
     * @param string $status Filter by status (default 'publish')
     * @return array Categories with id, name, slug, url, breadcrumb_path, product_count
     */
    public function search(string $term, int $limit = 15, string $status = 'publish'): array
    {
        global $wpdb;

        $like = '%' . $wpdb->esc_like($term) . '%';
        $exact = $wpdb->esc_like($term);

        // Search in name, slug, seo_title
        $where = ['(name LIKE %s OR slug LIKE %s OR seo_title LIKE %s)'];
        $params = [$like, $like, $like];

        if ($status !== 'all') {
            $where[] = 'status = %s';
            $params[] = $status;
        }

        $where_clause = implode(' AND ', $where);

        // Order by: exact match in name → starts with term → partial match → product_count DESC
        $params[] = $exact;
        $params[] = $term . '%';
        $params[] = $limit;

        $results = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, name, slug, path, depth, product_count, parent_id
                 FROM {$this->table}
                 WHERE {$where_clause}
                 ORDER BY
                    CASE WHEN name = %s THEN 0 ELSE 1 END,
                    CASE WHEN name LIKE %s THEN 0 ELSE 1 END,
                    product_count DESC
                 LIMIT %d",
                ...$params
            ),
            ARRAY_A
        ) ?: [];

        // Enhance results with breadcrumb_path and url
        return array_map(function ($cat) {
            $breadcrumb = $this->getBreadcrumbPath((int) $cat['id']);
            return [
                'id' => (int) $cat['id'],
                'name' => $cat['name'],
                'slug' => $cat['slug'],
                'url' => home_url('/c/' . $cat['slug'] . '/'),
                'breadcrumb_path' => $breadcrumb,
                'product_count' => (int) $cat['product_count'],
            ];
        }, $results);
    }

    /**
     * Get breadcrumb path as string (e.g., "Electronics > Audio > Headphones")
     *
     * @param int $category_id Category ID
     * @return string Breadcrumb path
     */
    private function getBreadcrumbPath(int $category_id): string
    {
        $breadcrumb = $this->getBreadcrumb($category_id);
        return implode(' > ', array_column($breadcrumb, 'name'));
    }

    public function count(string $status = 'all'): int
    {
        global $wpdb;

        if ($status === 'all') {
            return (int) $wpdb->get_var("SELECT COUNT(*) FROM {$this->table}");
        }

        return (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$this->table} WHERE status = %s", $status));
    }

    public function addProduct(int $category_id, int $product_id, bool $is_primary = false): bool
    {
        global $wpdb;

        $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$this->products_table} WHERE category_id = %d AND product_id = %d", $category_id, $product_id));

        if ($exists) {
            if ($is_primary) {
                $this->setPrimaryCategory($product_id, $category_id);
            }
            return true;
        }

        if ($is_primary) {
            $wpdb->update($this->products_table, ['is_primary' => 0], ['product_id' => $product_id, 'is_primary' => 1]);
        }

        $result = $wpdb->insert($this->products_table, [
            'category_id' => $category_id,
            'product_id' => $product_id,
            'is_primary' => $is_primary ? 1 : 0,
            'position' => $this->getNextProductPosition($category_id),
        ]);

        if ($result) {
            $this->updateProductCount($category_id);
            do_action('acms_cat_product_added', $category_id, $product_id);
        }
        return $result !== false;
    }

    public function removeProduct(int $category_id, int $product_id): bool
    {
        global $wpdb;

        $result = $wpdb->delete($this->products_table, ['category_id' => $category_id, 'product_id' => $product_id]);

        if ($result) {
            $this->updateProductCount($category_id);
            do_action('acms_cat_product_removed', $category_id, $product_id);
        }
        return $result !== false;
    }

    public function setPrimaryCategory(int $product_id, int $category_id): bool
    {
        global $wpdb;

        $wpdb->update($this->products_table, ['is_primary' => 0], ['product_id' => $product_id]);

        return $wpdb->update($this->products_table, ['is_primary' => 1], ['product_id' => $product_id, 'category_id' => $category_id]) !== false;
    }

    public function getProducts(int $category_id, int $limit = 20, int $offset = 0): array
    {
        global $wpdb;

        $products_table = $wpdb->prefix . 'acms_products';

        return $wpdb->get_results(
            $wpdb->prepare("SELECT p.*, cp.is_primary, cp.position as category_position FROM {$products_table} p INNER JOIN {$this->products_table} cp ON p.id = cp.product_id WHERE cp.category_id = %d ORDER BY cp.position ASC, p.rating DESC LIMIT %d OFFSET %d", $category_id, $limit, $offset),
            ARRAY_A
        ) ?: [];
    }

    public function getProductCategories(int $product_id): array
    {
        global $wpdb;

        return $wpdb->get_results(
            $wpdb->prepare("SELECT c.*, cp.is_primary FROM {$this->table} c INNER JOIN {$this->products_table} cp ON c.id = cp.category_id WHERE cp.product_id = %d ORDER BY cp.is_primary DESC, c.name ASC", $product_id),
            ARRAY_A
        ) ?: [];
    }

    public function getMeta(int $category_id, string $key = ''): mixed
    {
        global $wpdb;

        if ($key) {
            return $wpdb->get_var($wpdb->prepare("SELECT meta_value FROM {$this->meta_table} WHERE category_id = %d AND meta_key = %s", $category_id, $key));
        }

        $results = $wpdb->get_results($wpdb->prepare("SELECT meta_key, meta_value FROM {$this->meta_table} WHERE category_id = %d", $category_id), ARRAY_A);

        $meta = [];
        foreach ($results as $row) {
            $meta[$row['meta_key']] = maybe_unserialize($row['meta_value']);
        }
        return $meta;
    }

    public function updateMeta(int $category_id, string $key, mixed $value): bool
    {
        global $wpdb;

        $value = maybe_serialize($value);

        $exists = $wpdb->get_var($wpdb->prepare("SELECT meta_id FROM {$this->meta_table} WHERE category_id = %d AND meta_key = %s", $category_id, $key));

        if ($exists) {
            return $wpdb->update($this->meta_table, ['meta_value' => $value], ['category_id' => $category_id, 'meta_key' => $key]) !== false;
        }

        return $wpdb->insert($this->meta_table, ['category_id' => $category_id, 'meta_key' => $key, 'meta_value' => $value]) !== false;
    }

    public function deleteMeta(int $category_id, string $key = ''): bool
    {
        global $wpdb;

        $where = ['category_id' => $category_id];
        if ($key) {
            $where['meta_key'] = $key;
        }
        return $wpdb->delete($this->meta_table, $where) !== false;
    }

    /**
     * Get related categories context for AI internal linking
     *
     * Returns siblings, children, and ancestors with name/slug/product_count
     * for use in AI prompts to generate natural internal links.
     */
    public function getInternalLinkContext(int $categoryId): array
    {
        global $wpdb;

        $empty = ['siblings' => [], 'children' => [], 'ancestors' => [], 'popular' => []];

        $category = $this->find($categoryId);
        if (!$category) {
            return $empty;
        }

        $parentId = (int) ($category['parent_id'] ?? 0);
        $depth = (int) ($category['depth'] ?? 0);

        // 1. Sibling categories: same parent, exclude self, published
        $siblings = $wpdb->get_results($wpdb->prepare(
            "SELECT name, slug, product_count FROM {$this->table}
             WHERE parent_id = %d AND id != %d AND status = 'publish'
             ORDER BY product_count DESC LIMIT 10",
            $parentId,
            $categoryId
        ), ARRAY_A) ?: [];

        // 2. Child categories: direct children, published
        $children = $wpdb->get_results($wpdb->prepare(
            "SELECT name, slug, product_count FROM {$this->table}
             WHERE parent_id = %d AND status = 'publish'
             ORDER BY product_count DESC LIMIT 10",
            $categoryId
        ), ARRAY_A) ?: [];

        // 3. Ancestor categories with slugs
        $ancestors = [];
        $rawAncestors = $this->getAncestors($categoryId);
        foreach ($rawAncestors as $anc) {
            $ancestors[] = [
                'name' => $anc['name'],
                'slug' => $anc['slug'],
                'product_count' => (int) ($anc['product_count'] ?? 0),
            ];
        }

        // 4. Popular categories fallback — ensures AI always has links to work with
        //    Only categories with products (product_count > 0) and not already in above lists
        $existingSlugs = array_merge(
            array_column($siblings, 'slug'),
            array_column($children, 'slug'),
            array_column($ancestors, 'slug'),
            [$category['slug'] ?? '']
        );

        $totalLinks = count($siblings) + count($children) + count($ancestors);
        $popular = [];

        if ($totalLinks < 5) {
            // Need more links — fetch popular categories from same branch or globally
            $needed = 10 - $totalLinks;
            $excludePlaceholders = implode(',', array_fill(0, count($existingSlugs), '%s'));

            // First try: categories in the same depth range (±1 level) — more likely to be relevant
            $popular = $wpdb->get_results($wpdb->prepare(
                "SELECT name, slug, product_count FROM {$this->table}
                 WHERE status = 'publish' AND product_count > 0
                 AND slug NOT IN ({$excludePlaceholders})
                 AND depth BETWEEN %d AND %d
                 ORDER BY product_count DESC LIMIT %d",
                ...array_merge($existingSlugs, [$depth > 0 ? $depth - 1 : 0, $depth + 1, $needed])
            ), ARRAY_A) ?: [];

            // If still not enough, get top categories globally
            if (count($popular) < $needed) {
                $alreadySlugs = array_merge($existingSlugs, array_column($popular, 'slug'));
                $excludePlaceholders2 = implode(',', array_fill(0, count($alreadySlugs), '%s'));
                $stillNeeded = $needed - count($popular);

                $globalPopular = $wpdb->get_results($wpdb->prepare(
                    "SELECT name, slug, product_count FROM {$this->table}
                     WHERE status = 'publish' AND product_count > 0
                     AND slug NOT IN ({$excludePlaceholders2})
                     ORDER BY product_count DESC LIMIT %d",
                    ...array_merge($alreadySlugs, [$stillNeeded])
                ), ARRAY_A) ?: [];

                $popular = array_merge($popular, $globalPopular);
            }
        }

        return [
            'siblings' => $siblings,
            'children' => $children,
            'ancestors' => $ancestors,
            'popular' => $popular,
        ];
    }

    /**
     * Get brand link context for AI prompt — both SEO brand pages and brand sub-categories.
     *
     * Gathers:
     * 1. Existing brand sub-categories under this parent
     * 2. SEO brand pages (/brand/slug/) for brands found in products
     * 3. Predicted brand sub-categories (brands with products but no sub-cat yet)
     *
     * @param int   $categoryId Parent category ID
     * @param array $products   Products already fetched for AI context (with 'brand' key)
     * @return array ['seo_brands' => [...], 'brand_categories' => [...]]
     */
    public function getBrandLinkContext(int $categoryId, array $products = []): array
    {
        global $wpdb;

        $brandsTable = $wpdb->prefix . 'acms_brands';
        $result = ['seo_brands' => [], 'brand_categories' => []];

        // Collect unique brand names from products
        $productBrands = [];
        foreach ($products as $p) {
            $brand = trim($p['brand'] ?? '');
            if ($brand !== '') {
                $productBrands[$brand] = ($productBrands[$brand] ?? 0) + 1;
            }
        }

        if (empty($productBrands)) {
            return $result;
        }

        // 1. SEO brand pages for these brands
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $brandsTable)) === $brandsTable) {
            $brandNames = array_keys($productBrands);
            $placeholders = implode(',', array_fill(0, count($brandNames), '%s'));
            $seoBrands = $wpdb->get_results($wpdb->prepare(
                "SELECT name, slug, product_count FROM {$brandsTable}
                 WHERE name IN ({$placeholders}) AND status = 'publish'
                 ORDER BY product_count DESC",
                ...$brandNames
            ), ARRAY_A) ?: [];

            foreach ($seoBrands as $b) {
                $result['seo_brands'][] = [
                    'name' => $b['name'],
                    'slug' => $b['slug'],
                    'url' => '/brand/' . $b['slug'] . '/',
                    'product_count' => (int) ($b['product_count'] ?? 0),
                ];
            }
        }

        // 2. Existing brand sub-categories under this parent
        $existingBrandCats = $wpdb->get_results($wpdb->prepare(
            "SELECT c.name, c.slug, c.brand_id, c.product_count,
                    b.name as brand_name
             FROM {$this->table} c
             LEFT JOIN {$brandsTable} b ON c.brand_id = b.id
             WHERE c.parent_id = %d AND c.brand_id IS NOT NULL AND c.status = 'publish'
             ORDER BY c.product_count DESC",
            $categoryId
        ), ARRAY_A) ?: [];

        $existingBrandIds = [];
        foreach ($existingBrandCats as $bc) {
            $existingBrandIds[(int) $bc['brand_id']] = true;
            $result['brand_categories'][] = [
                'name' => $bc['name'],
                'slug' => $bc['slug'],
                'url' => '/c/' . $bc['slug'] . '/',
                'brand_name' => $bc['brand_name'] ?? '',
                'product_count' => (int) ($bc['product_count'] ?? 0),
                'exists' => true,
            ];
        }

        // 3. Predict brand sub-categories that will be created
        // (brands with 2+ products in this category but no existing sub-category)
        $category = $this->find($categoryId);
        $categoryName = $category['name'] ?? '';

        foreach ($productBrands as $brandName => $count) {
            if ($count < 2) {
                continue; // Need at least 2 products for brand sub-cat
            }

            // Check if this brand already has a sub-category
            $alreadyExists = false;
            foreach ($existingBrandCats as $bc) {
                if (($bc['brand_name'] ?? '') === $brandName) {
                    $alreadyExists = true;
                    break;
                }
            }

            if ($alreadyExists) {
                continue;
            }

            // Predict the slug: "Sony Headphones" → "sony-headphones"
            $predictedName = $brandName . ' ' . $categoryName;
            $predictedSlug = sanitize_title($predictedName);

            $result['brand_categories'][] = [
                'name' => $predictedName,
                'slug' => $predictedSlug,
                'url' => '/c/' . $predictedSlug . '/',
                'brand_name' => $brandName,
                'product_count' => $count,
                'exists' => false,
            ];
        }

        return $result;
    }

    public function generateUniqueSlug(string $name, int $exclude_id = 0): string
    {
        global $wpdb;

        $slug = sanitize_title($name);
        $original_slug = $slug;
        $counter = 1;

        while (true) {
            $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$this->table} WHERE slug = %s AND id != %d", $slug, $exclude_id));

            if (!$exists) {
                break;
            }
            $slug = $original_slug . '-' . $counter;
            $counter++;
        }
        return $slug;
    }

    private function getNextPosition(int $parent_id): int
    {
        global $wpdb;

        return (int) $wpdb->get_var($wpdb->prepare("SELECT COALESCE(MAX(position), 0) + 1 FROM {$this->table} WHERE parent_id = %d", $parent_id));
    }

    private function getNextProductPosition(int $category_id): int
    {
        global $wpdb;

        return (int) $wpdb->get_var($wpdb->prepare("SELECT COALESCE(MAX(position), 0) + 1 FROM {$this->products_table} WHERE category_id = %d", $category_id));
    }

    /**
     * Update product_count for a category (counts entire subtree: direct + descendant products)
     * Also propagates the count update to all ancestor categories.
     */
    public function updateProductCount(int $category_id): void
    {
        $this->recalcProductCount($category_id);

        // Also update all ancestor categories
        $category = $this->find($category_id);
        if ($category && !empty($category['path']) && $category['path'] !== '/') {
            $pathIds = array_filter(explode('/', trim($category['path'], '/')));
            foreach ($pathIds as $ancestorId) {
                $this->recalcProductCount((int) $ancestorId);
            }
        }
    }

    /**
     * Recalculate product_count for a single category (subtree total)
     * Counts products linked to this category + all its descendants.
     */
    private function recalcProductCount(int $category_id): void
    {
        global $wpdb;

        $category = $this->find($category_id);
        if (!$category) {
            return;
        }

        // Build descendant path pattern (same as template logic)
        $currentPath = rtrim($category['path'] ?? '', '/');
        $descendantPattern = $currentPath . '/' . $category_id . '/%';

        // Count DISTINCT products from this category + all descendants
        $count = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(DISTINCT cp.product_id)
             FROM {$this->products_table} cp
             WHERE cp.category_id = %d
                OR cp.category_id IN (
                    SELECT c.id FROM {$this->table} c WHERE c.path LIKE %s
                )",
            $category_id,
            $descendantPattern
        ));

        $wpdb->update($this->table, ['product_count' => $count], ['id' => $category_id]);
        $this->invalidateCache($category_id);
    }

    /**
     * Recount product_count for ALL categories (subtree totals).
     * Use this to fix existing data after switching to subtree counting.
     *
     * @return int Number of categories updated
     */
    public function recountAllProductCounts(): int
    {
        global $wpdb;

        $categories = $wpdb->get_results(
            "SELECT id, path FROM {$this->table} ORDER BY depth DESC",
            ARRAY_A
        );

        $updated = 0;
        foreach ($categories as $cat) {
            $categoryId = (int) $cat['id'];
            $currentPath = rtrim($cat['path'] ?? '', '/');
            $descendantPattern = $currentPath . '/' . $categoryId . '/%';

            $count = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(DISTINCT cp.product_id)
                 FROM {$this->products_table} cp
                 WHERE cp.category_id = %d
                    OR cp.category_id IN (
                        SELECT c.id FROM {$this->table} c WHERE c.path LIKE %s
                    )",
                $categoryId,
                $descendantPattern
            ));

            $wpdb->update($this->table, ['product_count' => $count], ['id' => $categoryId]);
            $this->invalidateCache($categoryId);
            $updated++;
        }

        return $updated;
    }

    public function updateChildCount(int $category_id): void
    {
        global $wpdb;

        $count = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$this->table} WHERE parent_id = %d", $category_id));

        $wpdb->update($this->table, ['child_count' => $count], ['id' => $category_id]);
        $this->invalidateCache($category_id);
    }

    public function incrementViewCount(int $category_id): void
    {
        global $wpdb;

        $wpdb->query($wpdb->prepare("UPDATE {$this->table} SET view_count = view_count + 1 WHERE id = %d", $category_id));
        $this->invalidateCache($category_id);
    }

    /**
     * Atomically claim the next category queued for AI content generation.
     *
     * Uses MySQL LAST_INSERT_ID(id) trick for race-condition-free claiming
     * across concurrent workers.
     *
     * Handles:
     * - Fresh categories: content_status='empty', no error
     * - Stuck categories: content_status='ai_generating' for > 10 minutes
     * - Failed retries: content_status='empty' with error, > 1 hour old
     *
     * @return array|null Claimed category data or null if queue empty
     */
    public function claimQueuedCategoryForAi(): ?array
    {
        global $wpdb;

        $now = current_time('mysql');
        $localTs = current_time('timestamp');
        $stuckThreshold = date('Y-m-d H:i:s', $localTs - 600);   // 10 min
        $retryThreshold = date('Y-m-d H:i:s', $localTs - 3600);  // 1 hour

        $result = $wpdb->query($wpdb->prepare(
            "UPDATE {$this->table}
             SET content_status = 'ai_generating',
                 ai_generating_at = %s,
                 ai_error_message = NULL,
                 updated_at = %s,
                 id = LAST_INSERT_ID(id)
             WHERE status = 'publish'
             AND product_count > 0
             AND (
                 (content_status = 'empty' AND (ai_error_message IS NULL OR ai_generating_at < %s))
                 OR (content_status = 'ai_generating' AND ai_generating_at < %s)
             )
             ORDER BY
                 CASE
                     WHEN content_status = 'empty' AND ai_error_message IS NULL THEN 0
                     WHEN content_status = 'ai_generating' THEN 1
                     ELSE 2
                 END ASC,
                 product_count DESC,
                 id ASC
             LIMIT 1",
            $now,
            $now,
            $retryThreshold,
            $stuckThreshold
        ));

        if (!$result || $wpdb->rows_affected === 0) {
            return null;
        }

        $claimedId = $wpdb->get_var("SELECT LAST_INSERT_ID()");
        if (!$claimedId) {
            return null;
        }

        // Bypass cache — get fresh data after claim
        return $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$this->table} WHERE id = %d", (int) $claimedId),
            ARRAY_A
        );
    }

    /**
     * Count categories eligible for AI content generation.
     *
     * Includes fresh (empty), stuck (generating > 10min), and failed retries (> 1h).
     */
    public function countQueuedForCategoryAi(): int
    {
        global $wpdb;

        $localTs = current_time('timestamp');
        $stuckThreshold = date('Y-m-d H:i:s', $localTs - 600);
        $retryThreshold = date('Y-m-d H:i:s', $localTs - 3600);

        return (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$this->table}
             WHERE status = 'publish'
             AND product_count > 0
             AND (
                 (content_status = 'empty' AND (ai_error_message IS NULL OR ai_generating_at < %s))
                 OR (content_status = 'ai_generating' AND ai_generating_at < %s)
             )",
            $retryThreshold,
            $stuckThreshold
        ));
    }
}
