<?php
/**
 * Site Configuration — EDIT THIS FILE
 *
 * This is the ONLY config file you need to edit.
 * Constants defined here override parent theme defaults.
 * Only add constants you want to change — omitted ones use parent defaults.
 *
 * To restore a default: delete or comment out the define() line.
 * Full list of available constants: see parent theme inc/config.php
 *
 * @package AffiliateCMS-Child
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

// Site Identity
define('ACMS_SITE_NAME', 'AmericanReviews.org');
define('ACMS_SITE_TAGLINE', 'Honest Reviews. Smart Choices.');

// Header
define('ACMS_HEADER_LOGO_URL', '/wp-content/uploads/2026/02/logo.png');

// Score Tooltip
define('ACMS_SCORE_TOOLTIP', "AmericanReviews.org score rating is a scoring system developed by our experts. The score is from 0 to 10 based on the data collected by the AmericanReviews.org tool. This score doesn't impact from any manufacturer or sales agent websites. We encourage you to write a review of your experiences with these products.");

// Footer
define('ACMS_FOOTER_DESCRIPTION', 'Get product reviews at AmericanReviews.org: expert insights + real American user ratings. Unbiased pros/cons, verified feedback, and smart U.S. shopping guides.');

// Contact
define('ACMS_CONTACT_EMAIL', 'contact@americanreviews.org');

// Social Media (empty = hidden)
define('ACMS_SOCIAL_FACEBOOK', '');
define('ACMS_SOCIAL_TWITTER', '');
define('ACMS_SOCIAL_LINKEDIN', '');

// Hero Section
define('ACMS_HERO_BADGE', 'Over 3 million products analyzed daily across 5,000 category comparison pages.');
define('ACMS_HERO_TITLE', 'AmericanReviews.org<br><span class="hero__title-highlight">Best Reviews and Ratings</span>');
define('ACMS_HERO_DESCRIPTION', 'Research. Compare. Buy with Confidence.');

// About Section
define('ACMS_ABOUT_TAGLINE', 'Get product reviews at AmericanReviews.org: expert insights + real American user ratings. Unbiased pros/cons, verified feedback, and smart U.S. shopping guides.');
define('ACMS_ABOUT_DESCRIPTION', 'We offer expert reviews and guides on Electronics, Home Improvement, Kitchen Appliances, Lawn & Garden, Automotive, and Daily Deals. Our goal is to simplify your buying decisions with clear, reliable insights.');
