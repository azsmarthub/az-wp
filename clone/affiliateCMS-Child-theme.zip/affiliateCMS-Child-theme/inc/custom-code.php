<?php
/**
 * Custom Code Injection - Header, Body, Footer
 *
 * Add tracking scripts, analytics, custom CSS/JS, or any code snippets
 * that should be injected into the theme without modifying the parent theme.
 *
 * This file is safe from parent theme updates.
 *
 * @package AffiliateCMS-Child
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Code injected into <head> (before </head>)
 * Use for: Google Analytics, Google Tag Manager <head> snippet, meta tags,
 *          custom CSS, preload hints, verification tags, etc.
 *
 * Fires via: wp_head action hook
 */
add_action('wp_head', function () {
    ?>
    <!-- Child Theme: Custom Head Code -->

    <!-- Example: Google Analytics -->
    <!-- <script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', 'G-XXXXXXXXXX');
    </script> -->

    <!-- Example: Site verification -->
    <!-- <meta name="google-site-verification" content="your-verification-code" /> -->

    <!-- Example: Custom CSS -->
    <!-- <style>
        .custom-style { color: red; }
    </style> -->

    <?php
}, 99); // Priority 99 = after all other wp_head hooks

/**
 * Code injected right after <body> tag
 * Use for: Google Tag Manager <body> snippet, noscript tags,
 *          loading overlays, skip-to-content links, etc.
 *
 * Fires via: wp_body_open action hook
 */
add_action('wp_body_open', function () {
    ?>
    <!-- Child Theme: Custom Body Open Code -->

    <!-- Example: Google Tag Manager (noscript) -->
    <!-- <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-XXXXXXX"
    height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript> -->

    <?php
}, 10);

/**
 * Code injected before </body> (at the bottom)
 * Use for: Chat widgets, tracking pixels, custom JS,
 *          deferred scripts, popup scripts, etc.
 *
 * Fires via: wp_footer action hook
 */
add_action('wp_footer', function () {
    ?>
    <!-- Child Theme: Custom Footer Code -->

    <!-- Example: Chat widget -->
    <!-- <script src="https://widget.example.com/chat.js" defer></script> -->

    <!-- Example: Custom JavaScript -->
    <!-- <script>
        document.addEventListener('DOMContentLoaded', function() {
            console.log('Custom footer JS loaded');
        });
    </script> -->

    <?php
}, 99); // Priority 99 = after all other wp_footer hooks
