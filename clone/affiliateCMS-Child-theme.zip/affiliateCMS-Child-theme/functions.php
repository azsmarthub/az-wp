<?php
/**
 * AffiliateCMS Child Theme - AmericanReviews.org
 *
 * Override parent theme config constants BEFORE parent loads them.
 * WordPress loads child functions.php first, then parent functions.php.
 *
 * @package AffiliateCMS-Child
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Load site-specific configuration overrides.
 * These constants are defined BEFORE parent config.php loads,
 * so the parent's defined() checks will skip its defaults.
 */
require_once get_stylesheet_directory() . '/config.php';

/**
 * Load custom code injection (header, body open, footer).
 * Add tracking scripts, analytics, or any code without editing parent theme.
 */
require_once get_stylesheet_directory() . '/custom-code.php';

/**
 * Enqueue parent + child stylesheets
 */
add_action('wp_enqueue_scripts', function () {
    // Parent styles are already enqueued by parent theme's enqueue.php
    // Only enqueue child stylesheet if it has custom CSS
    $child_css = get_stylesheet_directory() . '/style.css';
    if (filesize($child_css) > 500) {
        wp_enqueue_style(
            'affiliatecms-child-style',
            get_stylesheet_uri(),
            ['affiliatecms-main'],
            filemtime($child_css)
        );
    }
}, 20);
