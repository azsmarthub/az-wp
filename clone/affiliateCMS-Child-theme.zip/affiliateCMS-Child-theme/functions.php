<?php
/**
 * AffiliateCMS Child Theme
 *
 * Single file for all child theme customizations:
 * 1. Site config constants (override parent defaults)
 * 2. Custom code injection (header, body, footer)
 * 3. Child stylesheet enqueue
 *
 * @package AffiliateCMS-Child
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

// ─── SITE CONFIGURATION ────────────────────────────────────────

// Site Identity
define('ACMS_SITE_NAME', 'ProductReviews.org');
define('ACMS_SITE_TAGLINE', 'Smart Shopping. Smart Savings.');

// Header
define('ACMS_HEADER_CTA_TEXT', 'Sign-in');
define('ACMS_HEADER_CTA_URL', '/#');
define('ACMS_HEADER_LOGO_URL', '/wp-content/uploads/logo.png');
define('ACMS_HEADER_LOGO_TEXT', 'AZ');
define('ACMS_HEADER_MENU', [
    ['text' => 'Categories', 'url' => '/categories/'],
    ['text' => 'Blog', 'url' => '/blog/'],
    ['text' => 'About', 'url' => '/about-us/'],
    ['text' => 'Contact', 'url' => '/contact/'],
    ['text' => 'Log in', 'url' => '/wp-login.php'],
    ['text' => 'Register', 'url' => '/wp-login.php?action=register'],
]);

// Disclosure Bar
define('ACMS_DISCLOSURE_SHOW', true);
define('ACMS_DISCLOSURE_TEXT', 'We independently review everything we recommend. When you buy through our links, we may earn a commission at no additional cost to you.');
define('ACMS_DISCLOSURE_LINK_TEXT', 'Learn more');
define('ACMS_DISCLOSURE_LINK_URL', '/affiliate-disclosure/');

// Product List Disclosure
define('ACMS_LIST_DISCLOSURE_SHOW', true);
define('ACMS_LIST_DISCLOSURE_TEXT', 'As an Amazon Associate I earn from qualifying purchases.');

// Score Display
define('ACMS_SCORE_LABEL', 'Score');
define('ACMS_SCORE_TOOLTIP', "AmericanReviews.org score rating is a scoring system developed by our experts. The score is from 0 to 10 based on the data collected by the AmericanReviews.org tool. This score doesn't impact from any manufacturer or sales agent websites. We encourage you to write a review of your experiences with these products.");
define('ACMS_SCORE_TOOLTIP_LINK_TEXT', 'Learn more');
define('ACMS_SCORE_TOOLTIP_LINK_URL', '/about-us/');

// Update Info
define('ACMS_SHOW_UPDATE', true);
define('ACMS_UPDATE_TOOLTIP', 'Last update on {date}. Affiliate links, prices, images, product titles, and highlights from Amazon Product Advertising API.');

// Footer
define('ACMS_FAVICON_URL', '/wp-content/uploads/2026/02/favicon.png');
define('ACMS_FOOTER_LOGO_ID', 0);
define('ACMS_FOOTER_LOGO_ICON', 'bi-bag-check');
define('ACMS_FOOTER_DESCRIPTION', 'Get product reviews at ProductReviews.org: expert insights + real American user ratings. Unbiased pros/cons, verified feedback, and smart U.S. shopping guides.');
define('ACMS_FOOTER_DISCLOSURE', 'As Amazon Associates, we earn from qualifying purchases. This means we may receive a small commission at no extra cost to you if you click through and make a purchase.');
define('ACMS_FOOTER_DISCLOSURE_LINK_TEXT', 'Affiliate Disclosure');
define('ACMS_FOOTER_DISCLOSURE_LINK_URL', '/affiliate-disclosure/');
define('ACMS_FOOTER_COPYRIGHT', '');
define('ACMS_FOOTER_POLICY_LINKS', [
    ['text' => 'About', 'url' => '/about-us/'],
    ['text' => 'Categories', 'url' => 'categories/'],
    ['text' => 'Privacy Policy', 'url' => '/privacy-policy/'],
    ['text' => 'Terms of Service', 'url' => '/terms-of-service/'],
    ['text' => 'Guidelines for Reviewers', 'url' => 'guidelines-for-reviewers/'],
    ['text' => 'Affiliate Disclosure', 'url' => '/affiliate-disclosure/'],
    ['text' => 'DMCA', 'url' => '/dmca/'],
    ['text' => 'Contact', 'url' => '/contact/'],
]);

// Contact
define('ACMS_CONTACT_EMAIL', 'contact@americanreviews.org');

// Social Media
define('ACMS_SOCIAL_FACEBOOK', '');
define('ACMS_SOCIAL_TWITTER', '');
define('ACMS_SOCIAL_INSTAGRAM', '');
define('ACMS_SOCIAL_YOUTUBE', '');
define('ACMS_SOCIAL_PINTEREST', '');
define('ACMS_SOCIAL_LINKEDIN', '');
define('ACMS_SOCIAL_TIKTOK', '');

// Hero Section
define('ACMS_HERO_BADGE', 'Over 3 million products analyzed daily across 5,000 category comparison pages.');
define('ACMS_HERO_TITLE', 'American Reviews<br><span class="hero__title-highlight">Expert Reviews by Americans, for Americans</span>');
define('ACMS_HERO_DESCRIPTION', 'Real ratings. Honest insights. Smarter shopping.');
define('ACMS_HERO_PLACEHOLDER', 'Search for a product or category...');
define('ACMS_HERO_PROMPTS', [
    '"Best walking pad for small apartments"',
    '"Compare top air purifiers"',
    '"Budget-friendly soundbars"',
]);
define('ACMS_HERO_TAGS_LABEL', 'Top Rated:');
define('ACMS_HERO_TAGS', [
    ['name' => 'Air Fryers', 'url' => '/c/air-fryers/'],
    ['name' => 'Electric Toothbrushes', 'url' => '/c/electric-toothbrushes/'],
    ['name' => 'Mattresses', 'url' => '/c/mattresses/'],
    ['name' => 'Espresso Machines', 'url' => '/c/espresso-machines/'],
    ['name' => 'Pillows', 'url' => '/c/pillows/'],
    ['name' => 'Running Shoes', 'url' => '/c/running-shoes/'],
]);
define('ACMS_HERO_STATS', [
    ['number' => '', 'label' => 'Product Reviews'],
    ['number' => '2.5M+', 'label' => 'Visitors'],
    ['number' => '$50M+', 'label' => 'Saved for Users'],
]);
if (!defined('ACMS_CAT_COUNT')) {
    define('ACMS_CAT_COUNT', 16);
}
/**
 * Latest Posts Section Settings (Homepage)
 */
if (!defined('ACMS_LATEST_ICON')) {
    define('ACMS_LATEST_ICON', 'bi-lightning-fill');
}
if (!defined('ACMS_LATEST_TITLE')) {
    define('ACMS_LATEST_TITLE', 'Latest');
}
if (!defined('ACMS_LATEST_SUBTITLE')) {
    define('ACMS_LATEST_SUBTITLE', 'Expert opinions on the newest products');
}
if (!defined('ACMS_LATEST_VIEWALL_TEXT')) {
    define('ACMS_LATEST_VIEWALL_TEXT', 'View All');
}
if (!defined('ACMS_LATEST_VIEWALL_URL')) {
    define('ACMS_LATEST_VIEWALL_URL', '/categories/');
}
if (!defined('ACMS_LATEST_COUNT')) {
    define('ACMS_LATEST_COUNT', 12);
}
if (!defined('ACMS_LATEST_LOAD_MORE')) {
    define('ACMS_LATEST_LOAD_MORE', true);
}
if (!defined('ACMS_LATEST_LAYOUT')) {
    define('ACMS_LATEST_LAYOUT', 'grid');
}
if (!defined('ACMS_LATEST_POST_TYPES')) {
    define('ACMS_LATEST_POST_TYPES', 'post');
}
// About Section
define('ACMS_ABOUT_BADGE', 'Trusted Since 2022');
define('ACMS_ABOUT_TITLE_PREFIX', 'About');
define('ACMS_ABOUT_TAGLINE', 'Get product reviews at AmericanReviews.org: expert insights + real American user ratings. Unbiased pros/cons, verified feedback, and smart U.S. shopping guides.');
define('ACMS_ABOUT_DESCRIPTION', 'We offer expert reviews and guides on Electronics, Home Improvement, Kitchen Appliances, Lawn & Garden, Automotive, and Daily Deals. Our goal is to simplify your buying decisions with clear, reliable insights.');
define('ACMS_ABOUT_CTA1_TEXT', 'All Categories');
define('ACMS_ABOUT_CTA1_URL', '/categories/');
define('ACMS_ABOUT_CTA2_TEXT', 'How We Review');
define('ACMS_ABOUT_CTA2_URL', '/about-us/');


// ─── CUSTOM CODE INJECTION ─────────────────────────────────────
// Migrated from parent theme header.php (backup 2026-04-10)

/**
 * Inject into <head>
 * - Google Tag Manager (GTM-54X8F3XC)
 * - Google AdSense (ca-pub-5112600229338056)
 */
add_action('wp_head', function () {
    ?>
    <!-- Google Tag Manager -->
    <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
    'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','GTM-XXXXXXC');</script>
    <!-- End Google Tag Manager -->
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-5112600229338056"
         crossorigin="anonymous"></script>
    <?php
}, 99);

/**
 * Inject after <body> tag - GTM noscript fallback
 */
add_action('wp_body_open', function () {
    ?>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-XXXXXX"
    height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->
    <?php
}, 10);


// ─── CHILD STYLESHEET ──────────────────────────────────────────
add_action('wp_enqueue_scripts', function () {
    $child_css = get_stylesheet_directory() . '/style.css';
    if (file_exists($child_css) && filesize($child_css) > 500) {
        wp_enqueue_style(
            'affiliatecms-child-style',
            get_stylesheet_uri(),
            ['affiliatecms-main'],
            filemtime($child_css)
        );
    }
}, 20);

// ─── FIX: Author dropdown in post editor ───────────────────────
// WP REST API /users?who=authors defaults to has_published_posts filter,
// which hides users who haven't published yet. This restores the full
// list of users with edit_posts capability (admins + contributors).
add_filter('rest_user_query', function ($prepared_args, $request) {
    if (isset($prepared_args['has_published_posts'])) {
        unset($prepared_args['has_published_posts']);
    }
    return $prepared_args;
}, 10, 2);
