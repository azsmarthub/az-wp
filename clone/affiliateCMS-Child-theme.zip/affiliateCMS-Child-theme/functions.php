<?php
/**
 * AffiliateCMS Child Theme
 *
 * Single file for all child theme customizations:
 * 1. Site config constants (override parent defaults)
 * 2. Custom code injection (header, body, footer)
 * 3. Child stylesheet enqueue
 *
 * WordPress loads this BEFORE parent functions.php,
 * so constants defined here take priority.
 *
 * @package AffiliateCMS-Child
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

// ─── SITE CONFIGURATION ────────────────────────────────────────
// Override parent theme defaults. Omitted constants use parent values.
// Full list: see parent theme inc/config.php

// Site Identity
define('ACMS_SITE_NAME', 'AmericanReviews.org');
define('ACMS_SITE_TAGLINE', 'Honest Reviews. Smart Choices.');

// Header
define('ACMS_HEADER_CTA_TEXT', 'Sign-in');
define('ACMS_HEADER_CTA_URL', '/wp-login.php');
define('ACMS_HEADER_LOGO_URL', '/wp-content/uploads/logo.png');

// Score Tooltip
define('ACMS_SCORE_TOOLTIP', "AmericanReviews.org score rating is a scoring system developed by our experts. The score is from 0 to 10 based on the data collected by the AmericanReviews.org tool. This score doesn't impact from any manufacturer or sales agent websites. We encourage you to write a review of your experiences with these products.");

// Footer
define('ACMS_FOOTER_DESCRIPTION', 'Expert product reviews with real American user ratings. Unbiased pros/cons, verified feedback, and smart U.S. shopping guides to help you buy smarter.');

// Contact
define('ACMS_CONTACT_EMAIL', 'contact@americanreviews.org');

// Social Media (empty = hidden)
define('ACMS_SOCIAL_FACEBOOK', '');
define('ACMS_SOCIAL_TWITTER', '');
define('ACMS_SOCIAL_LINKEDIN', '');

// Hero Section
define('ACMS_HERO_BADGE', 'Over 3 million products analyzed daily across 5,000 category comparison pages.');
define('ACMS_HERO_TITLE', 'American Reviews<br><span class="hero__title-highlight">Expert Reviews by Americans, for Americans</span>');
define('ACMS_HERO_DESCRIPTION', 'Real ratings. Honest insights. Smarter shopping.');

// About Section
define('ACMS_ABOUT_TAGLINE', 'Get product reviews at AmericanReviews.org: expert insights + real American user ratings. Unbiased pros/cons, verified feedback, and smart U.S. shopping guides.');
define('ACMS_ABOUT_DESCRIPTION', 'We offer expert reviews and guides on Electronics, Home Improvement, Kitchen Appliances, Lawn & Garden, Automotive, and Daily Deals. Our goal is to simplify your buying decisions with clear, reliable insights.');


// ─── CUSTOM CODE INJECTION ─────────────────────────────────────
// Add tracking scripts, analytics, or any code snippets here.
// These hooks inject into the parent theme without modifying it.

/**
 * Inject into <head> (before </head>)
 * Use for: Google Analytics, GTM, meta tags, custom CSS, verification tags
 */
add_action('wp_head', function () {
    // Uncomment and edit as needed:
    // <!-- Google Analytics -->
    // <script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"></script>
    // <script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','G-XXXXXXXXXX');</script>

    // <!-- Site verification -->
    // <meta name="google-site-verification" content="your-code" />
}, 99);

/**
 * Inject after <body> tag
 * Use for: GTM noscript, loading overlays
 */
add_action('wp_body_open', function () {
    // Uncomment and edit as needed:
    // <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-XXXXXXX" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
}, 10);

/**
 * Inject before </body>
 * Use for: Chat widgets, tracking pixels, custom JS
 */
add_action('wp_footer', function () {
    // Uncomment and edit as needed:
    // <script src="https://widget.example.com/chat.js" defer></script>
}, 99);


// ─── CHILD STYLESHEET ──────────────────────────────────────────
add_action('wp_enqueue_scripts', function () {
    $child_css = get_stylesheet_directory() . '/style.css';
    if (filesize($child_css) > 500) {
        wp_enqueue_style(
            'affiliatecms-child-style',
            get_stylesheet_uri(),
            ['affiliatecms-main'],
            filemtime($child_css)
        );
    }
}, 20);
