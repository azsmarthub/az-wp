<?php
/**
 * PSR-4 Autoloader for AffiliateCMS Pro
 *
 * Maps namespace AffiliateCMS\Pro to src/ directory
 * Replaces Composer autoloader when vendor not available
 */

declare(strict_types=1);

spl_autoload_register(function (string $class): void {
    // Only handle AffiliateCMS\Pro namespace
    $prefix = 'AffiliateCMS\\Pro\\';
    $baseDir = __DIR__ . '/src/';

    // Check if class uses our namespace prefix
    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }

    // Get relative class name
    $relativeClass = substr($class, $len);

    // Replace namespace separators with directory separators
    $file = $baseDir . str_replace('\\', '/', $relativeClass) . '.php';

    // Load the file if it exists
    if (file_exists($file)) {
        require $file;
    }
});
