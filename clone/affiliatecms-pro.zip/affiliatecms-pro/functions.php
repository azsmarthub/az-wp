<?php
/**
 * Global Helper Functions
 *
 * This file contains global functions that can be used by themes and other plugins.
 * These functions are NOT namespaced for easy access.
 *
 * @package AffiliateCMS\Pro
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Get effective modified date for a post
 *
 * Returns the more recent of:
 * - Post modified date
 * - Latest product scrape time (from products in post content)
 *
 * @param int|null $postId Post ID (defaults to current post)
 * @param string $format Date format (default: 'M j, Y')
 * @return string Formatted date
 */
function acms_get_effective_modified_date(?int $postId = null, string $format = 'M j, Y'): string
{
    if (!class_exists('AffiliateCMS\Pro\Frontend\SeoDateModifier')) {
        // Plugin not loaded, fallback to WordPress modified date
        return get_the_modified_date($format, $postId);
    }

    return \AffiliateCMS\Pro\Frontend\SeoDateModifier::instance()
        ->getEffectiveModifiedDateFormatted($postId, $format);
}

/**
 * Get effective modified date as ISO 8601 string
 *
 * Useful for schema markup and meta tags.
 *
 * @param int|null $postId Post ID (defaults to current post)
 * @return string|null ISO 8601 datetime string
 */
function acms_get_effective_modified_date_iso(?int $postId = null): ?string
{
    if (!class_exists('AffiliateCMS\Pro\Frontend\SeoDateModifier')) {
        // Plugin not loaded, fallback to WordPress modified date
        $post = get_post($postId);
        if (!$post) {
            return null;
        }
        return gmdate('c', strtotime($post->post_modified_gmt));
    }

    return \AffiliateCMS\Pro\Frontend\SeoDateModifier::instance()
        ->getEffectiveModifiedDate($postId);
}
