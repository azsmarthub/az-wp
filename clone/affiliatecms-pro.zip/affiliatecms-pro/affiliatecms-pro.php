<?php
/**
 * Plugin Name: AffiliateCMS Pro
 * Plugin URI: https://affiliatecms.com
 * Description: Professional Amazon affiliate product management
 * Version: 1.1.2
 * Requires at least: 6.0
 * Requires PHP: 8.0
 * Author: AffiliateCMS
 * Author URI: https://affiliatecms.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: affiliatecms-pro
 * Domain Path: /languages
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Plugin constants
define('ACMS_VERSION', '1.1.4');
define('ACMS_PLUGIN_FILE', __FILE__);
define('ACMS_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('ACMS_PLUGIN_URL', plugin_dir_url(__FILE__));
define('ACMS_PLUGIN_BASENAME', plugin_basename(__FILE__));

// Autoloader - use Composer if available, otherwise custom autoloader
if (file_exists(ACMS_PLUGIN_DIR . 'vendor/autoload.php')) {
    require_once ACMS_PLUGIN_DIR . 'vendor/autoload.php';
} else {
    require_once ACMS_PLUGIN_DIR . 'autoload.php';
}

// Global helper functions
require_once ACMS_PLUGIN_DIR . 'functions.php';

/**
 * Plugin activation callback
 */
function acms_activate(): void
{
    // Suppress any output during activation - use multiple levels for safety
    $bufferLevel = ob_get_level();
    ob_start();

    try {
        // Temporarily suppress errors from being displayed during activation
        $displayErrors = ini_get('display_errors');
        @ini_set('display_errors', '0');

        // Create database tables
        Database\Schema::instance()->install();

        // Set plugin version
        update_option('acms_version', ACMS_VERSION);

        // Register CPTs and taxonomies before flushing so rewrite rules include them
        $postTypeManager = new Core\PostTypeManager();
        $postTypeManager->registerPostTypes();
        $postTypeManager->registerTaxonomies();

        // Flush rewrite rules (now includes CPT rules)
        flush_rewrite_rules();

        // Restore error display setting
        @ini_set('display_errors', $displayErrors);
    } finally {
        // Clean all output buffers we created
        while (ob_get_level() > $bufferLevel) {
            ob_end_clean();
        }
    }
}

/**
 * Plugin deactivation callback
 */
function acms_deactivate(): void
{
    // Cleanup transients
    global $wpdb;
    $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_acms_%'");
    $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_acms_%'");

    // Flush rewrite rules
    flush_rewrite_rules();
}

// Register activation/deactivation hooks
register_activation_hook(__FILE__, __NAMESPACE__ . '\acms_activate');
register_deactivation_hook(__FILE__, __NAMESPACE__ . '\acms_deactivate');

// Initialize plugin on plugins_loaded
add_action('plugins_loaded', function (): void {
    // Load text domain for translations
    load_plugin_textdomain(
        'affiliatecms-pro',
        false,
        dirname(ACMS_PLUGIN_BASENAME) . '/languages'
    );

    // Check for version upgrade and run migrations if needed
    $savedVersion = get_option('acms_version', '0.0.0');
    if (version_compare($savedVersion, ACMS_VERSION, '<')) {
        // Run database migrations for upgrades
        Database\Schema::instance()->install();
        update_option('acms_version', ACMS_VERSION);

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("[ACMS] Upgraded from {$savedVersion} to " . ACMS_VERSION . " - migrations applied");
        }
    }

    // Initialize the plugin core
    Core\Bootstrap::instance()->init();
}, 5);
