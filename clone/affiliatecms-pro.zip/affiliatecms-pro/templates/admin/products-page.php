<?php
/**
 * Products Admin Page Template
 *
 * @package AffiliateCMS\Pro
 */

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}
?>
<!-- Global Config (must be before Alpine.js runs) -->
<script>
window.acmsConfig = {
    restUrl: '<?php echo esc_js(rest_url('acms/v1/')); ?>',
    nonce: '<?php echo esc_js(wp_create_nonce('wp_rest')); ?>',
    pluginUrl: '<?php echo esc_js(ACMS_PLUGIN_URL); ?>',
    i18n: {
        success: '<?php echo esc_js(__('Success', 'affiliatecms-pro')); ?>',
        error: '<?php echo esc_js(__('Error', 'affiliatecms-pro')); ?>',
        confirm_delete: '<?php echo esc_js(__('Are you sure you want to delete?', 'affiliatecms-pro')); ?>',
        no_results: '<?php echo esc_js(__('No results found', 'affiliatecms-pro')); ?>'
    }
};
</script>

<div id="acms-admin-app" class="acms-admin" x-data="productsPage()"
     @selection-changed.window="selectedCount = $event.detail.count; selectedProducts = $event.detail.products"
     @filtered-count-changed.window="filteredCount = $event.detail.count; hasFilters = $event.detail.hasFilters; totalProducts = $event.detail.total">
    <div class="app-container">
        <!-- Page Header with Stats -->
        <header class="page-header">
            <!-- Left: Stats -->
            <div class="header-left">
                <!-- Product Stats -->
                <div class="stats-inline">
                    <div class="stat-item total clickable" :class="{ 'active': filters.status === '' }" title="Total products" @click="filters.status = ''" style="cursor:pointer">
                        <span class="stat-item-dot"></span>
                        <span class="stat-item-value" x-text="stats.total">0</span>
                        <span class="stat-item-label">Total</span>
                    </div>
                    <div class="stat-item scraped clickable" :class="{ 'active': filters.status === 'scraped' }" title="Scraped products" @click="filters.status = 'scraped'" style="cursor:pointer">
                        <span class="stat-item-dot"></span>
                        <span class="stat-item-value" x-text="stats.scraped">0</span>
                        <span class="stat-item-label">Scraped</span>
                    </div>
                    <div class="stat-item scheduled clickable" :class="{ 'active': filters.status === 'scheduled' }" title="Scheduled products" @click="filters.status = 'scheduled'" style="cursor:pointer" x-show="stats.scheduled > 0">
                        <span class="stat-item-dot"></span>
                        <span class="stat-item-value" x-text="stats.scheduled">0</span>
                        <span class="stat-item-label">Scheduled</span>
                    </div>
                    <div class="stat-item processing clickable" :class="{ 'active': filters.status === 'processing' }" title="Processing products" @click="filters.status = 'processing'" style="cursor:pointer" x-show="stats.processing > 0">
                        <span class="stat-item-dot"></span>
                        <span class="stat-item-value" x-text="stats.processing">0</span>
                        <span class="stat-item-label">Processing</span>
                    </div>
                    <div class="stat-item pending clickable" :class="{ 'active': filters.status === 'pending' }" title="Pending products" @click="filters.status = 'pending'" style="cursor:pointer" x-show="stats.pending > 0">
                        <span class="stat-item-dot"></span>
                        <span class="stat-item-value" x-text="stats.pending">0</span>
                        <span class="stat-item-label">Pending</span>
                    </div>
                    <div class="stat-item failed clickable" :class="{ 'active': filters.status === 'failed' }" title="Failed products" @click="filters.status = 'failed'" style="cursor:pointer" x-show="stats.failed > 0">
                        <span class="stat-item-dot"></span>
                        <span class="stat-item-value" x-text="stats.failed">0</span>
                        <span class="stat-item-label">Failed</span>
                    </div>
                </div>
            </div>

            <!-- Header Actions -->
            <div class="flex items-center gap-2">
                <!-- Quick Actions -->
                <a class="btn-icon tooltip" data-tooltip="Cache" href="<?php echo esc_url(admin_url('admin.php?page=acms-pro-cache')); ?>">
                    <i class="bi bi-hdd-stack"></i>
                </a>
                <button class="btn-icon tooltip" data-tooltip="Cron Settings" @click="showCronModal = true">
                    <i class="bi bi-clock-history"></i>
                </button>
                <button class="btn-icon tooltip" data-tooltip="Settings" @click="showSettingsModal = true">
                    <i class="bi bi-gear"></i>
                </button>

                <div class="header-divider"></div>

                <button class="btn btn-secondary" @click="$store.app.showScanModal = true" title="Scan posts for ASINs">
                    <i class="bi bi-search-heart"></i>
                    Scan Posts
                </button>
                <button class="btn btn-primary" @click="showAddModal = true">
                    <i class="bi bi-plus-lg"></i>
                    Add ASINs
                </button>
            </div>
        </header>

        <!-- Toolbar -->
        <div class="toolbar">
            <!-- Left: Actions -->
            <div class="toolbar-section toolbar-left">
                <!-- Bulk Actions Dropdown -->
                <div class="dropdown" x-data="{ open: false }">
                    <button class="btn btn-secondary" @click="open = !open" :disabled="selectedCount === 0">
                        <i class="bi bi-grid-3x3-gap"></i>
                        Actions
                        <i class="bi bi-chevron-down" style="font-size:12px;margin-left:4px;"></i>
                    </button>
                    <div class="dropdown-menu" x-show="open" @click.outside="open = false" x-cloak>
                        <button class="dropdown-item" @click="$dispatch('bulk-scrape'); open = false">
                            <i class="bi bi-arrow-clockwise"></i>
                            Re-scrape
                        </button>
                        <button class="dropdown-item" @click="$dispatch('bulk-quick-update'); open = false">
                            <i class="bi bi-lightning"></i>
                            Quick Update
                        </button>
                        <button class="dropdown-item" @click="$dispatch('bulk-regenerate-ai'); open = false">
                            <i class="bi bi-stars"></i>
                            Regenerate AI
                        </button>
                        <button class="dropdown-item" @click="$dispatch('bulk-reset-ai'); open = false">
                            <i class="bi bi-arrow-counterclockwise"></i>
                            Reset Stuck AI
                        </button>
                        <div class="dropdown-divider"></div>
                        <button class="dropdown-item danger" @click="$dispatch('bulk-delete'); open = false">
                            <i class="bi bi-trash"></i>
                            Delete
                        </button>
                    </div>
                </div>

                <!-- Template Builder Button -->
                <button class="btn btn-secondary" @click="openTemplateBuilder()" :disabled="selectedCount === 0" title="Generate shortcode">
                    <i class="bi bi-code-square"></i>
                    Shortcode
                </button>

                <!-- Selected Count -->
                <span class="selected-count" x-show="selectedCount > 0" x-cloak>
                    <span class="selected-count-number" x-text="selectedCount"></span>
                </span>
            </div>

            <!-- Center: Search -->
            <div class="toolbar-section toolbar-center">
                <form class="search-box" autocomplete="off" @submit.prevent>
                    <!-- Hidden honeypot to trick autocomplete -->
                    <input type="text" name="prevent_autofill" id="prevent_autofill" value="" style="display:none;" tabindex="-1" autocomplete="new-password">
                    <i class="bi bi-search search-icon"></i>
                    <input type="search" class="search-input" placeholder="Search ASIN, title, brand..."
                           x-model="searchQuery" @input.debounce.300ms="$dispatch('update-search', { query: searchQuery })"
                           autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false"
                           data-lpignore="true" data-form-type="other" data-1p-ignore="true" aria-label="Search products">
                    <button type="button" class="search-clear" x-show="searchQuery" x-cloak @click="searchQuery = ''; $dispatch('update-search', { query: '' })">
                        <i class="bi bi-x-lg"></i>
                    </button>
                </form>
            </div>

            <!-- Right: Filters & View -->
            <div class="toolbar-section toolbar-right">
                <!-- Filtered Count -->
                <span class="filtered-count" x-show="hasFilters" x-cloak>
                    <span class="filtered-count-number" x-text="filteredCount"></span>
                </span>

                <!-- Filter Button with Dropdown -->
                <div class="dropdown" @click.outside="filterDropdownOpen = false">
                    <button class="btn-icon" :class="{ 'active': hasFilters, 'filter-active': hasFilters }" @click="filterDropdownOpen = !filterDropdownOpen" title="Filters">
                        <i class="bi" :class="hasFilters ? 'bi-funnel-fill' : 'bi-funnel'"></i>
                    </button>
                    <div class="dropdown-menu right" style="min-width: 260px; padding: 16px;" x-show="filterDropdownOpen" x-cloak>
                        <!-- Status Filter -->
                        <div class="form-group" x-data="{ statusOpen: false }">
                            <label class="form-label">Status</label>
                            <div class="custom-select" @click.outside="statusOpen = false">
                                <button type="button" class="custom-select-trigger" :class="{ 'open': statusOpen }" @click="statusOpen = !statusOpen">
                                    <span class="custom-select-value" x-text="{'': 'All Status', 'pending': 'Pending', 'processing': 'Processing', 'scheduled': 'Scheduled', 'scraped': 'Scraped', 'failed': 'Failed', 'update': 'Update', 'updating': 'Updating'}[filters.status] || 'All Status'"></span>
                                    <i class="bi bi-chevron-down"></i>
                                </button>
                                <div class="custom-select-dropdown" x-show="statusOpen" x-cloak x-transition @click.stop>
                                    <button type="button" class="custom-select-option" :class="{ 'selected': filters.status === '' }" @click="filters.status = ''; statusOpen = false">All Status</button>
                                    <button type="button" class="custom-select-option" :class="{ 'selected': filters.status === 'pending' }" @click="filters.status = 'pending'; statusOpen = false">Pending</button>
                                    <button type="button" class="custom-select-option" :class="{ 'selected': filters.status === 'processing' }" @click="filters.status = 'processing'; statusOpen = false">Processing</button>
                                    <button type="button" class="custom-select-option" :class="{ 'selected': filters.status === 'scheduled' }" @click="filters.status = 'scheduled'; statusOpen = false">Scheduled</button>
                                    <button type="button" class="custom-select-option" :class="{ 'selected': filters.status === 'scraped' }" @click="filters.status = 'scraped'; statusOpen = false">Scraped</button>
                                    <button type="button" class="custom-select-option" :class="{ 'selected': filters.status === 'update' }" @click="filters.status = 'update'; statusOpen = false">Update</button>
                                    <button type="button" class="custom-select-option" :class="{ 'selected': filters.status === 'updating' }" @click="filters.status = 'updating'; statusOpen = false">Updating</button>
                                    <button type="button" class="custom-select-option" :class="{ 'selected': filters.status === 'failed' }" @click="filters.status = 'failed'; statusOpen = false">Failed</button>
                                </div>
                            </div>
                        </div>

                        <!-- Stock Filter -->
                        <div class="form-group" x-data="{ stockOpen: false }">
                            <label class="form-label">Stock</label>
                            <div class="custom-select" @click.outside="stockOpen = false">
                                <button type="button" class="custom-select-trigger" :class="{ 'open': stockOpen }" @click="stockOpen = !stockOpen">
                                    <span class="custom-select-value" x-text="filters.stock === '' ? 'All Stock' : (filters.stock === 'in' ? 'In Stock' : 'Out of Stock')"></span>
                                    <i class="bi bi-chevron-down"></i>
                                </button>
                                <div class="custom-select-dropdown" x-show="stockOpen" x-cloak x-transition @click.stop>
                                    <button type="button" class="custom-select-option" :class="{ 'selected': filters.stock === '' }" @click="filters.stock = ''; stockOpen = false">All Stock</button>
                                    <button type="button" class="custom-select-option" :class="{ 'selected': filters.stock === 'in' }" @click="filters.stock = 'in'; stockOpen = false">In Stock</button>
                                    <button type="button" class="custom-select-option" :class="{ 'selected': filters.stock === 'out' }" @click="filters.stock = 'out'; stockOpen = false">Out of Stock</button>
                                </div>
                            </div>
                        </div>

                        <!-- AI Status Filter -->
                        <div class="form-group" x-data="{ aiOpen: false }">
                            <label class="form-label">AI Status</label>
                            <div class="custom-select" @click.outside="aiOpen = false">
                                <button type="button" class="custom-select-trigger" :class="{ 'open': aiOpen }" @click="aiOpen = !aiOpen">
                                    <span class="custom-select-value" x-text="{'': 'All AI Status', 'not_generated': 'Not Generated', 'queued': 'Queued', 'generating': 'Generating', 'generated': 'Generated', 'failed': 'Failed'}[filters.ai_status] || 'All AI Status'"></span>
                                    <i class="bi bi-chevron-down"></i>
                                </button>
                                <div class="custom-select-dropdown" x-show="aiOpen" x-cloak x-transition @click.stop>
                                    <button type="button" class="custom-select-option" :class="{ 'selected': filters.ai_status === '' }" @click="filters.ai_status = ''; aiOpen = false">All AI Status</button>
                                    <button type="button" class="custom-select-option" :class="{ 'selected': filters.ai_status === 'not_generated' }" @click="filters.ai_status = 'not_generated'; aiOpen = false">Not Generated</button>
                                    <button type="button" class="custom-select-option" :class="{ 'selected': filters.ai_status === 'queued' }" @click="filters.ai_status = 'queued'; aiOpen = false">Queued</button>
                                    <button type="button" class="custom-select-option" :class="{ 'selected': filters.ai_status === 'generating' }" @click="filters.ai_status = 'generating'; aiOpen = false">Generating</button>
                                    <button type="button" class="custom-select-option" :class="{ 'selected': filters.ai_status === 'generated' }" @click="filters.ai_status = 'generated'; aiOpen = false">Generated</button>
                                    <button type="button" class="custom-select-option" :class="{ 'selected': filters.ai_status === 'failed' }" @click="filters.ai_status = 'failed'; aiOpen = false">Failed</button>
                                </div>
                            </div>
                        </div>

                        <!-- Filter Actions -->
                        <div style="display: flex; gap: 8px; margin-top: 12px;">
                            <button class="btn btn-secondary" style="flex: 1;" @click="clearFilters()">
                                <i class="bi bi-x-lg"></i>
                                Clear
                            </button>
                            <button class="btn btn-primary" style="flex: 1;" @click="applyFilters()">
                                <i class="bi bi-check2"></i>
                                Apply
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Refresh -->
                <button class="btn-icon" :class="{ 'refresh-success': refreshSuccess }" @click="refreshProducts()" title="Refresh">
                    <i class="bi" :class="{ 'bi-arrow-clockwise': !refreshSuccess, 'animate-spin': isRefreshing, 'bi-check-lg': refreshSuccess }"></i>
                </button>
            </div>
        </div>

        <!-- Products Table -->
        <div class="data-table-wrapper" x-data="productsTable()" x-init="init()">
            <!-- Loading State -->
            <div class="data-table-loading" x-show="isLoading" x-cloak>
                <div class="spinner"></div>
                <span>Loading products...</span>
            </div>

            <!-- Empty State -->
            <div class="data-table-empty" x-show="!isLoading && products.length === 0" x-cloak>
                <i class="bi bi-inbox"></i>
                <span>No products found</span>
                <small>Click "Add ASINs" to add your first product</small>
            </div>

            <!-- Table -->
            <div class="data-table-container" x-show="!isLoading && products.length > 0">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th class="col-checkbox">
                                <input type="checkbox" @change="toggleSelectAll($event.target.checked)"
                                       :checked="selectedIds.length > 0 && selectedIds.length === products.length"
                                       :indeterminate="selectedIds.length > 0 && selectedIds.length < products.length">
                            </th>
                            <th class="col-product sortable" :class="{ 'sorted': sortColumn === 'title', 'desc': sortColumn === 'title' && sortDirection === 'desc' }" @click="sortBy('title')">
                                <span>Product</span>
                                <i class="bi bi-chevron-expand sort-icon"></i>
                            </th>
                            <th class="col-category">Category</th>
                            <th class="col-price sortable" :class="{ 'sorted': sortColumn === 'price', 'desc': sortColumn === 'price' && sortDirection === 'desc' }" @click="sortBy('price')">
                                <span>Price</span>
                                <i class="bi bi-chevron-expand sort-icon"></i>
                            </th>
                            <th class="col-rating sortable" :class="{ 'sorted': sortColumn === 'rating', 'desc': sortColumn === 'rating' && sortDirection === 'desc' }" @click="sortBy('rating')">
                                <span>Rating</span>
                                <i class="bi bi-chevron-expand sort-icon"></i>
                            </th>
                            <th class="col-score sortable" :class="{ 'sorted': sortColumn === 'score', 'desc': sortColumn === 'score' && sortDirection === 'desc' }" @click="sortBy('score')">
                                <span>Score</span>
                                <i class="bi bi-chevron-expand sort-icon"></i>
                            </th>
                            <th class="col-posts">Links</th>
                            <th class="col-stock">Stock</th>
                            <th class="col-status sortable" :class="{ 'sorted': sortColumn === 'status', 'desc': sortColumn === 'status' && sortDirection === 'desc' }" @click="sortBy('status')">
                                <span>Status</span>
                                <i class="bi bi-chevron-expand sort-icon"></i>
                            </th>
                            <th class="col-ai sortable" :class="{ 'sorted': sortColumn === 'ai_status', 'desc': sortColumn === 'ai_status' && sortDirection === 'desc' }" @click="sortBy('ai_status')">
                                <span>AI</span>
                                <i class="bi bi-chevron-expand sort-icon"></i>
                            </th>
                            <th class="col-actions">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <template x-for="product in products" :key="product.id">
                            <tr :class="{ 'selected': selectedIds.includes(product.id) }" @click="toggleSelect(product.id)" style="cursor: pointer;">
                                <td class="col-checkbox" @click.stop>
                                    <input type="checkbox" :value="product.id" :checked="selectedIds.includes(product.id)" @change="toggleSelect(product.id)">
                                </td>
                                <td class="col-product">
                                    <div class="product-cell">
                                        <div class="product-thumb" @click="openLightbox(product)">
                                            <img :src="product.image_url || ''" :alt="product.title || ''" onerror="this.src='data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 48 48%22><rect fill=%22%2318181b%22 width=%2248%22 height=%2248%22/><text x=%2224%22 y=%2228%22 fill=%22%2371717a%22 font-size=%2212%22 text-anchor=%22middle%22>No img</text></svg>'">
                                        </div>
                                        <div class="product-info">
                                            <a class="product-title" :href="'https://www.amazon.com/dp/' + product.asin + '/'" target="_blank" @click.stop :title="product.title" x-text="product.title || 'Untitled'"></a>
                                            <div class="product-meta">
                                                <code class="product-asin asin-copy" :class="{ 'copied': product._copied }"
                                                      @click.stop="copyAsin(product)" title="Click to copy ASIN">
                                                    <i class="bi bi-copy asin-copy-icon" x-show="!product._copied"></i>
                                                    <i class="bi bi-check2 asin-copied-icon" x-show="product._copied"></i>
                                                    <span x-text="product.asin"></span>
                                                </code>
                                                <a class="brand-tag" :href="product.brand ? '/reviews-brand/' + product.brand.toLowerCase().replace(/\s+/g, '-').replace(/[^\w-]/g, '') + '/' : '#'" target="_blank" @click.stop :title="product.brand || 'No brand'">
                                                    <i class="bi bi-tag brand-icon"></i>
                                                    <span class="brand-name" x-text="product.brand || '-'"></span>
                                                </a>
                                                <span class="prime-badge" x-show="product.is_prime">
                                                    <i class="bi bi-check-circle-fill"></i>
                                                    Prime
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td class="col-category">
                                    <div class="category-cell">
                                        <span class="category-name" :title="product.category" x-text="product.category || '-'"></span>
                                        <span class="category-path" :title="product.category_path" x-text="product.category_path || ''"></span>
                                    </div>
                                </td>
                                <td class="col-price">
                                    <div class="price-cell">
                                        <span class="price-current" x-text="product.price ? '$' + parseFloat(product.price).toFixed(2) : '-'"></span>
                                        <template x-if="product.original_price && parseFloat(product.original_price) > parseFloat(product.price)">
                                            <span class="price-original" x-text="'$' + parseFloat(product.original_price).toFixed(2)"></span>
                                        </template>
                                        <template x-if="product.original_price && parseFloat(product.original_price) > parseFloat(product.price)">
                                            <span class="price-discount" x-text="'-' + Math.round((1 - parseFloat(product.price) / parseFloat(product.original_price)) * 100) + '%'"></span>
                                        </template>
                                    </div>
                                </td>
                                <td class="col-rating">
                                    <div class="rating-cell">
                                        <div class="rating-row">
                                            <i class="bi bi-star-fill rating-star"></i>
                                            <span class="rating-value" x-text="product.rating ? parseFloat(product.rating).toFixed(1) : '-'"></span>
                                        </div>
                                        <span class="rating-count" x-text="product.reviews_count ? formatNumber(product.reviews_count) : ''"></span>
                                    </div>
                                </td>
                                <td class="col-score">
                                    <div class="score-cell">
                                        <span class="score-value" x-text="product.score ? (product.score / 10).toFixed(1) : '-'"></span>
                                        <span class="score-max">/10</span>
                                    </div>
                                </td>
                                <td class="col-posts" @click.stop>
                                    <button class="posts-count-btn"
                                            :class="{ 'has-posts': (product.post_count || 0) + (product.linked_category_count || 0) > 0 }"
                                            @click="$dispatch('show-posts-modal', product)"
                                            :disabled="(product.post_count || 0) + (product.linked_category_count || 0) === 0"
                                            :title="((product.post_count || 0) + (product.linked_category_count || 0)) > 0 ? 'View links using this product' : 'No links using this product'">
                                        <span x-text="(product.post_count || 0) + (product.linked_category_count || 0)"></span>
                                    </button>
                                </td>
                                <td class="col-stock">
                                    <span class="stock-dot"
                                          :class="product.in_stock === null || product.in_stock === undefined ? 'unknown' : (product.in_stock ? 'in-stock' : 'out-of-stock')"
                                          :title="product.in_stock === null || product.in_stock === undefined ? 'Unknown' : (product.in_stock ? 'In Stock' : 'Out of Stock')"></span>
                                </td>
                                <td class="col-status">
                                    <span class="badge" :class="'badge-' + getStatusColor(product.status)">
                                        <i class="bi"
                                           :class="{
                                               'bi-bug': product.last_provider?.toLowerCase() === 'crawlbase',
                                               'bi-amazon': product.last_provider?.toLowerCase() === 'paapi',
                                               'bi-globe': product.last_provider && !['crawlbase','paapi'].includes(product.last_provider?.toLowerCase())
                                           }"
                                           x-show="product.last_provider && ['scraped','failed','update','updating'].includes(product.status)"
                                           :title="'Provider: ' + product.last_provider"></i>
                                        <span x-text="product.status || 'pending'"></span>
                                    </span>
                                </td>
                                <td class="col-ai">
                                    <span class="badge" :class="'badge-' + getAiStatusColor(product.ai_status)"
                                          :title="getAiStatusTitle(product)">
                                        <i class="bi" :class="getAiStatusIcon(product.ai_status)"></i>
                                        <span x-text="getAiStatusLabel(product.ai_status)"></span>
                                    </span>
                                </td>
                                <td class="col-actions">
                                    <div class="actions-cell">
                                        <!-- Default: Date (hidden on hover) -->
                                        <span class="actions-placeholder">
                                            <span class="actions-date"
                                                  x-text="(() => { const s = product.last_scraped_at, q = product.quick_update_at; if (!s && !q) return '-'; const d = (q && (!s || q > s)) ? q : s; return formatDate(d); })()"
                                                  :title="(() => { const parts = []; if (product.last_scraped_at) parts.push('Scraped: ' + formatDateTime(product.last_scraped_at)); if (product.quick_update_at) parts.push('Quick Update: ' + formatDateTime(product.quick_update_at) + (product.quick_update_count > 0 ? ' (' + product.quick_update_count + 'x)' : '')); return parts.join('\n') || ''; })()"
                                                  :style="product.quick_update_at && (!product.last_scraped_at || product.quick_update_at > product.last_scraped_at) ? 'color: var(--primary);' : ''"></span>
                                        </span>
                                        <!-- Hover: Show action buttons -->
                                        <div class="actions-buttons">
                                            <button class="btn-icon btn-icon-sm" title="Scrape Log" @click.stop="$dispatch('show-scrape-diagnostics', product)" x-show="product.status === 'scraped' || product.status === 'failed'">
                                                <i class="bi bi-file-text"></i>
                                            </button>
                                            <button class="btn-icon btn-icon-sm" title="Re-scrape" @click.stop="$dispatch('rescrape-product', product)" :disabled="$store.app.scraping && $store.app.scrapeAsin === product.asin">
                                                <i class="bi" :class="$store.app.scraping && $store.app.scrapeAsin === product.asin ? 'bi-arrow-clockwise animate-spin' : 'bi-arrow-clockwise'"></i>
                                            </button>
                                            <button class="btn-icon btn-icon-sm" title="Edit" @click.stop="$dispatch('edit-product', product)">
                                                <i class="bi bi-pencil"></i>
                                            </button>
                                            <button class="btn-icon btn-icon-sm btn-danger" title="Delete" @click.stop="$dispatch('delete-product', product)">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        </template>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <div class="data-table-pagination" x-show="!isLoading && products.length > 0">
                <div class="pagination-info">
                    <span x-text="totalItems > 0 ? 'Showing ' + ((currentPage - 1) * pageSize + 1) + ' - ' + Math.min(currentPage * pageSize, totalItems) + ' of ' + totalItems + ' products' : '0 products'"></span>
                </div>
                <div class="pagination-controls">
                    <div class="custom-select custom-select-sm" x-data="{ pageSizeOpen: false }" @click.outside="pageSizeOpen = false">
                        <button type="button" class="custom-select-trigger" :class="{ 'open': pageSizeOpen }" @click="pageSizeOpen = !pageSizeOpen">
                            <span class="custom-select-value" x-text="pageSize"></span>
                            <i class="bi bi-chevron-down"></i>
                        </button>
                        <div class="custom-select-dropdown dropdown-up" x-show="pageSizeOpen" x-cloak x-transition @click.stop>
                            <button type="button" class="custom-select-option" :class="{ 'selected': pageSize === 100 }" @click="changePageSize(100); pageSizeOpen = false">100</button>
                            <button type="button" class="custom-select-option" :class="{ 'selected': pageSize === 200 }" @click="changePageSize(200); pageSizeOpen = false">200</button>
                            <button type="button" class="custom-select-option" :class="{ 'selected': pageSize === 500 }" @click="changePageSize(500); pageSizeOpen = false">500</button>
                            <button type="button" class="custom-select-option" :class="{ 'selected': pageSize === 1000 }" @click="changePageSize(1000); pageSizeOpen = false">1000</button>
                        </div>
                    </div>
                    <div class="pagination-buttons">
                        <button class="pagination-btn" :disabled="currentPage === 1" @click="currentPage = 1" title="First">
                            <i class="bi bi-chevron-double-left"></i>
                        </button>
                        <button class="pagination-btn" :disabled="currentPage === 1" @click="currentPage--" title="Previous">
                            <i class="bi bi-chevron-left"></i>
                        </button>
                        <template x-for="page in visiblePages" :key="page">
                            <button class="pagination-btn" :class="{ 'active': page === currentPage }" @click="currentPage = page" x-text="page"></button>
                        </template>
                        <button class="pagination-btn" :disabled="currentPage === totalPages" @click="currentPage++" title="Next">
                            <i class="bi bi-chevron-right"></i>
                        </button>
                        <button class="pagination-btn" :disabled="currentPage === totalPages" @click="currentPage = totalPages" title="Last">
                            <i class="bi bi-chevron-double-right"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modals -->
    <?php include __DIR__ . '/modals/add-asin-modal.php'; ?>
    <?php include __DIR__ . '/modals/settings-modal.php'; ?>
    <?php include __DIR__ . '/modals/cron-settings-modal.php'; ?>
    <?php include __DIR__ . '/modals/edit-product-modal.php'; ?>
    <?php include __DIR__ . '/modals/delete-modal.php'; ?>
    <?php include __DIR__ . '/modals/scrape-log-modal.php'; ?>
    <?php include __DIR__ . '/modals/scrape-diagnostics-modal.php'; ?>
    <?php include __DIR__ . '/modals/template-builder-modal.php'; ?>
    <?php include __DIR__ . '/modals/scan-posts-modal.php'; ?>
    <?php include __DIR__ . '/modals/posts-modal.php'; ?>

    <!-- Components -->
    <?php include __DIR__ . '/components/toast.php'; ?>
    <?php include __DIR__ . '/components/processing-overlay.php'; ?>
    <?php include __DIR__ . '/components/lightbox.php'; ?>
</div>

<script>
document.addEventListener('alpine:init', () => {
    // Global app store
    Alpine.store('app', {
        lightbox: {
            open: false,
            image: '',
            title: ''
        },
        // Scraping state (shared between components)
        scraping: false,
        scrapeAsin: null,
        // Posts modal state (shared between components)
        showPostsModal: false,
        selectedProductForPosts: null,
        // Modal states (global for cross-scope access)
        showScanModal: false,
        openLightbox(image, title) {
            this.lightbox.image = image;
            this.lightbox.title = title;
            this.lightbox.open = true;
        },
        closeLightbox() {
            this.lightbox.open = false;
        },
        showNotification(message, type = 'info') {
            window.dispatchEvent(new CustomEvent('show-toast', {
                detail: { message, type, title: type.charAt(0).toUpperCase() + type.slice(1) }
            }));
        },
        startScraping(asin) {
            this.scraping = true;
            this.scrapeAsin = asin;
        },
        stopScraping() {
            this.scraping = false;
            this.scrapeAsin = null;
        }
    });

    // Products page component
    Alpine.data('productsPage', () => ({
        // State
        stats: {
            total: <?php echo (int) ($stats['total'] ?? 0); ?>,
            scraped: <?php echo (int) ($stats['scraped'] ?? 0); ?>,
            scheduled: <?php echo (int) ($stats['scheduled'] ?? 0); ?>,
            processing: <?php echo (int) ($stats['processing'] ?? 0); ?>,
            pending: <?php echo (int) ($stats['pending'] ?? 0); ?>,
            failed: <?php echo (int) ($stats['failed'] ?? 0); ?>
        },
        loading: false,
        selectedCount: 0,
        selectedProducts: [],
        searchQuery: '',
        filteredCount: 0,
        totalProducts: 0,
        hasFilters: false,
        isRefreshing: false,
        refreshSuccess: false,
        filterDropdownOpen: false,

        // Filters
        filters: {
            status: '',
            stock: '',
            ai_status: ''
        },

        // Modals (showScanModal is in $store.app)
        showAddModal: false,
        showSettingsModal: false,
        showCronModal: false,
        showDeleteModal: false,
        showEditModal: false,
        showScrapeLogModal: false,
        showDiagnosticsModal: false,
        diagnosticsProduct: null,
        diagData: null,
        diagLoading: false,
        diagCopied: false,
        showTemplateBuilder: false,
        showPostsModal: false,
        selectedProductForPosts: null,

        // Edit modal tab state
        editProductTab: 'custom',

        // Template Builder state
        scTemplate: 'list',
        scBadges: [],
        scColumns: { xs: 1, sm: 1, md: 2, lg: 3, xl: 4 },
        scOptions: {
            show_price: true,
            show_rating: true,
            show_image: true,
            show_prime: true,
            button_text: 'Buy on Amazon'
        },
        scQuickBadges: [
            { name: 'Best Seller', icon: 'bi-trophy' },
            { name: "Editor's Choice", icon: 'bi-star' },
            { name: 'Limited Time', icon: 'bi-clock' },
            { name: 'Top Rated', icon: 'bi-hand-thumbs-up' }
        ],
        scCustomAsins: '',
        scEditMode: false,
        scCopied: false,

        // Scrape log state
        scrapeLogProduct: null,
        scrapeLogs: [],
        scraping: false,
        scrapeSuccess: false,
        logCopied: false,

        // Current item for edit/delete
        currentProduct: null,
        editForm: {},

        // Toast
        showToast: false,
        toastType: 'success',
        toastTitle: '',
        toastMessage: '',

        // Processing overlay
        showProcessing: false,
        processingTitle: '',
        processingSubtitle: '',
        processingProgress: 0,
        processingCurrent: 0,
        processingTotal: 0,
        processingCancellable: false,

        init() {
            // Listen for stats updates from productsTable
            window.addEventListener('stats-updated', (e) => {
                this.stats = e.detail || this.stats;
            });

            // Listen for events
            this.$watch('showAddModal', (value) => {
                if (!value) {
                    // Refresh table when modal closes
                    window.dispatchEvent(new CustomEvent('products-updated'));
                }
            });

            // Listen for toast events from child components
            window.addEventListener('show-toast', (e) => {
                this.toast(e.detail.type, e.detail.title, e.detail.message);
            });

            // Listen for bulk actions
            window.addEventListener('bulk-scrape', () => {
                this.bulkRescrape();
            });

            window.addEventListener('bulk-delete', () => {
                if (this.selectedProducts.length > 0) {
                    this.openDeleteModal(this.selectedProducts);
                }
            });

            window.addEventListener('bulk-regenerate-ai', () => {
                this.bulkRegenerateAi();
            });

            window.addEventListener('bulk-reset-ai', () => {
                this.bulkResetAi();
            });

            window.addEventListener('bulk-quick-update', () => {
                this.bulkQuickUpdate();
            });

            // Listen for single product actions
            window.addEventListener('delete-product', (e) => {
                this.openDeleteModal(e.detail);
            });

            // Listen for rescrape-product event
            window.addEventListener('rescrape-product', (e) => {
                this.rescrapeProduct(e.detail);
            });

            // Listen for edit-product event
            window.addEventListener('edit-product', (e) => {
                this.openEditModal(e.detail);
            });

            // Listen for show-posts-modal event
            window.addEventListener('show-posts-modal', (e) => {
                this.openPostsModal(e.detail);
            });

            // Listen for show-scrape-diagnostics event
            window.addEventListener('show-scrape-diagnostics', (e) => {
                this.openDiagnostics(e.detail);
            });

            // Listen for close-posts-modal event
            window.addEventListener('close-posts-modal', () => {
                this.showPostsModal = false;
                this.selectedProductForPosts = null;
            });
        },

        refreshProducts() {
            // Dispatch event to refresh the table component
            window.dispatchEvent(new CustomEvent('products-updated'));
            this.refreshSuccess = true;
            setTimeout(() => { this.refreshSuccess = false; }, 2000);
        },

        clearFilters() {
            this.filters.status = '';
            this.filters.stock = '';
            this.filters.ai_status = '';
            this.hasFilters = false;
            this.$dispatch('filters-cleared');
        },

        applyFilters() {
            this.hasFilters = this.filters.status !== '' || this.filters.stock !== '' || this.filters.ai_status !== '';
            this.$dispatch('filters-applied', this.filters);
            this.filterDropdownOpen = false;
        },

        openEditModal(product) {
            this.currentProduct = product;
            // Deep clone to prevent reference issues with nested arrays
            this.editForm = JSON.parse(JSON.stringify(product));
            this.showEditModal = true;
        },

        /**
         * Fetch full product details from API (includes linked_category_ids)
         * Called when edit modal opens to get data not included in list view
         */
        async fetchFullProductDetails(productId) {
            if (!productId) return;

            try {
                const response = await fetch(acmsConfig.restUrl + 'products/' + productId, {
                    method: 'GET',
                    headers: {
                        'X-WP-Nonce': acmsConfig.nonce
                    }
                });
                const result = await response.json();
                if (result.success && result.data) {
                    // Merge ALL full product data into editForm
                    // (listing only has 28 columns; full data includes description, features,
                    // custom_title, custom_description, custom_pros, custom_cons, custom_faq, etc.)
                    Object.assign(this.editForm, result.data);
                }
            } catch (error) {
                console.error('[ACMS] Failed to fetch full product details:', error);
            }
        },

        openDeleteModal(products) {
            this.selectedProducts = Array.isArray(products) ? products : [products];
            this.selectedCount = this.selectedProducts.length;
            this.showDeleteModal = true;
        },

        openPostsModal(product) {
            this.selectedProductForPosts = product;
            this.showPostsModal = true;
            // Also set in store for modal component access
            if (Alpine.store('app')) {
                Alpine.store('app').selectedProductForPosts = product;
                Alpine.store('app').showPostsModal = true;
            }
        },

        async openDiagnostics(product) {
            this.diagnosticsProduct = product;
            this.diagData = null;
            this.diagLoading = true;
            this.diagCopied = false;
            this.showDiagnosticsModal = true;

            try {
                const response = await fetch(
                    acmsConfig.restUrl + 'products/' + product.id + '/scrape-log',
                    { headers: { 'X-WP-Nonce': acmsConfig.nonce } }
                );
                const result = await response.json();
                if (result.success) {
                    this.diagData = result.data;
                }
            } catch (error) {
                console.error('Failed to load scrape diagnostics:', error);
            } finally {
                this.diagLoading = false;
            }
        },

        async copyAllDiagnostics() {
            if (!this.diagData) return;
            const text = JSON.stringify(this.diagData, null, 2);
            try {
                await navigator.clipboard.writeText(text);
                this.diagCopied = true;
                setTimeout(() => { this.diagCopied = false; }, 2000);
                this.toast('success', 'Copied', 'Diagnostics copied to clipboard');
            } catch (e) {
                // Fallback for older browsers
                const textarea = document.createElement('textarea');
                textarea.value = text;
                document.body.appendChild(textarea);
                textarea.select();
                document.execCommand('copy');
                document.body.removeChild(textarea);
                this.diagCopied = true;
                setTimeout(() => { this.diagCopied = false; }, 2000);
            }
        },

        async deleteProducts() {
            if (this.selectedProducts.length === 0) return;

            try {
                const ids = this.selectedProducts.map(p => p.id);
                const response = await fetch(acmsConfig.restUrl + 'products/bulk', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': acmsConfig.nonce
                    },
                    body: JSON.stringify({
                        action: 'delete',
                        ids: ids
                    })
                });
                const result = await response.json();
                if (result.success) {
                    this.toast('success', 'Success', result.message || 'Products deleted successfully');
                } else {
                    this.toast('error', 'Error', result.message || 'Failed to delete products');
                }
            } catch (error) {
                this.toast('error', 'Error', 'Failed to delete products');
            } finally {
                this.showDeleteModal = false;
                this.selectedProducts = [];
                this.selectedCount = 0;
                window.dispatchEvent(new CustomEvent('products-updated'));
            }
        },

        async saveProduct() {
            if (!this.editForm.id) return;

            try {
                const response = await fetch(acmsConfig.restUrl + 'products/' + this.editForm.id, {
                    method: 'PATCH',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': acmsConfig.nonce
                    },
                    body: JSON.stringify({
                        title: this.editForm.title,
                        brand: this.editForm.brand,
                        image_url: this.editForm.image_url,
                        price: this.editForm.price ? parseFloat(this.editForm.price) : null,
                        original_price: this.editForm.original_price ? parseFloat(this.editForm.original_price) : null,
                        rating: this.editForm.rating ? parseFloat(this.editForm.rating) : null,
                        reviews_count: this.editForm.reviews_count ? parseInt(this.editForm.reviews_count) : null,
                        category: this.editForm.category,
                        category_path: this.editForm.category_path,
                        status: this.editForm.status,
                        in_stock: this.editForm.in_stock ? 1 : 0,
                        is_prime: this.editForm.is_prime ? 1 : 0,
                        description: this.editForm.description || null,
                        features: Array.isArray(this.editForm.features) ? this.editForm.features : null,
                        images_gallery: Array.isArray(this.editForm.images_gallery) ? this.editForm.images_gallery : null,
                        // Custom content fields (AI populates these too)
                        custom_title: this.editForm.custom_title || null,
                        custom_description: this.editForm.custom_description || null,
                        custom_features: Array.isArray(this.editForm.custom_features) ? this.editForm.custom_features : null,
                        custom_pros: Array.isArray(this.editForm.custom_pros) ? this.editForm.custom_pros : null,
                        custom_cons: Array.isArray(this.editForm.custom_cons) ? this.editForm.custom_cons : null,
                        custom_tabs: Array.isArray(this.editForm.custom_tabs) ? this.editForm.custom_tabs : null,
                        // AI short review (unique field, not in custom_*)
                        ai_short_review: this.editForm.ai_short_review || null,
                        // Custom category paths for SEO categories
                        custom_category_paths: Array.isArray(this.editForm.custom_category_paths) ? this.editForm.custom_category_paths : null,
                        // Linked SEO category IDs (synced via junction table)
                        linked_category_ids: this.editForm.linked_category_ids || ''
                    })
                });
                const result = await response.json();
                if (result.success) {
                    this.toast('success', 'Success', 'Product updated successfully');
                } else {
                    this.toast('error', 'Error', result.message || 'Failed to update product');
                }
            } catch (error) {
                this.toast('error', 'Error', 'Failed to save product');
            } finally {
                this.showEditModal = false;
                window.dispatchEvent(new CustomEvent('products-updated'));
            }
        },

        async queueForAi(forceRegenerate = false) {
            if (!this.editForm.id || this.editForm.status !== 'scraped') return;

            const isRegenerate = this.editForm.ai_status === 'generated' || forceRegenerate;

            // If regenerating (or forcing), process immediately; otherwise just queue
            if (isRegenerate) {
                // Process immediately
                this.editForm.ai_status = 'generating';
                try {
                    const response = await fetch(acmsConfig.restUrl + 'products/' + this.editForm.id + '/generate-ai', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-WP-Nonce': acmsConfig.nonce
                        }
                    });
                    const result = await response.json();
                    if (result.success) {
                        // Refresh product data
                        if (result.data) {
                            Object.assign(this.editForm, result.data);
                        }
                        this.toast('success', 'Generated', 'AI content regenerated successfully');
                        window.dispatchEvent(new CustomEvent('products-updated'));
                    } else {
                        this.editForm.ai_status = 'failed';
                        this.toast('error', 'Error', result.message || 'Failed to regenerate AI content');
                    }
                } catch (error) {
                    this.editForm.ai_status = 'failed';
                    this.toast('error', 'Error', 'Failed to regenerate AI content');
                }
            } else {
                // Just queue for cron processing
                try {
                    const response = await fetch(acmsConfig.restUrl + 'products/' + this.editForm.id, {
                        method: 'PATCH',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-WP-Nonce': acmsConfig.nonce
                        },
                        body: JSON.stringify({
                            ai_status: 'queued'
                        })
                    });
                    const result = await response.json();
                    if (result.success) {
                        this.editForm.ai_status = 'queued';
                        this.toast('success', 'Queued', 'Product queued for AI content generation');
                    } else {
                        this.toast('error', 'Error', result.message || 'Failed to queue product');
                    }
                } catch (error) {
                    this.toast('error', 'Error', 'Failed to queue product for AI');
                }
            }
        },

        /**
         * Reset AI status for stuck or failed products
         * @param {string} newStatus - 'queued', 'not_generated', or null to clear
         */
        async resetAiStatus(newStatus) {
            if (!this.editForm.id) return;

            const statusLabels = {
                'queued': 'Re-queued',
                'not_generated': 'Cleared',
                null: 'Reset'
            };

            try {
                const response = await fetch(acmsConfig.restUrl + 'products/' + this.editForm.id + '/reset-ai', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': acmsConfig.nonce
                    },
                    body: JSON.stringify({
                        ai_status: newStatus
                    })
                });
                const result = await response.json();
                if (result.success) {
                    // Update local form data
                    this.editForm.ai_status = newStatus;
                    this.editForm.ai_error_message = null;
                    if (result.data) {
                        Object.assign(this.editForm, result.data);
                    }
                    this.toast('success', statusLabels[newStatus] || 'Reset', 'AI status has been updated');
                    window.dispatchEvent(new CustomEvent('products-updated'));
                } else {
                    this.toast('error', 'Error', result.message || 'Failed to reset AI status');
                }
            } catch (error) {
                this.toast('error', 'Error', 'Failed to reset AI status');
            }
        },

        async bulkRescrape() {
            if (this.selectedProducts.length === 0) return;

            const count = this.selectedProducts.length;
            const ids = this.selectedProducts.map(p => p.id);

            console.log('[ACMS] Bulk rescrape started:', { count, ids });

            // Show immediate notification that scraping is starting
            this.toast('info', 'Scraping', `Re-scraping ${count} product${count > 1 ? 's' : ''}... This may take a while.`);

            // Clear selection (table will refresh after API call)
            this.selectedProducts = [];
            this.selectedCount = 0;

            try {
                console.log('[ACMS] Sending request to:', acmsConfig.restUrl + 'products/bulk');
                const response = await fetch(acmsConfig.restUrl + 'products/bulk', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': acmsConfig.nonce
                    },
                    body: JSON.stringify({
                        action: 'rescrape',
                        ids: ids
                    })
                });

                console.log('[ACMS] Response status:', response.status);
                const result = await response.json();
                console.log('[ACMS] Response data:', result);

                if (result.success) {
                    this.toast('success', 'Completed', result.message || 'Products re-scraped successfully');
                } else {
                    this.toast('error', 'Error', result.message || 'Failed to re-scrape products');
                }
            } catch (error) {
                console.error('[ACMS] Bulk rescrape error:', error);
                this.toast('error', 'Error', 'Request failed: ' + (error.message || 'Unknown error'));
            } finally {
                window.dispatchEvent(new CustomEvent('products-updated'));
            }
        },

        async bulkRegenerateAi() {
            if (this.selectedProducts.length === 0) return;

            const count = this.selectedProducts.length;
            const ids = this.selectedProducts.map(p => p.id);

            this.toast('info', 'AI', `Queuing ${count} product${count > 1 ? 's' : ''} for AI regeneration...`);
            this.selectedProducts = [];
            this.selectedCount = 0;

            try {
                const response = await fetch(acmsConfig.restUrl + 'products/bulk', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': acmsConfig.nonce
                    },
                    body: JSON.stringify({ action: 'regenerate-ai', ids })
                });

                const result = await response.json();
                if (result.success) {
                    this.toast('success', 'AI', result.message || 'Products queued for AI regeneration');
                } else {
                    this.toast('error', 'Error', result.message || 'Failed to queue AI regeneration');
                }
            } catch (error) {
                this.toast('error', 'Error', 'Request failed: ' + (error.message || 'Unknown error'));
            } finally {
                window.dispatchEvent(new CustomEvent('products-updated'));
            }
        },

        async bulkResetAi() {
            if (this.selectedProducts.length === 0) return;

            const count = this.selectedProducts.length;
            const ids = this.selectedProducts.map(p => p.id);

            this.toast('info', 'AI Reset', `Resetting ${count} stuck product(s)...`);
            this.selectedProducts = [];
            this.selectedCount = 0;

            try {
                const response = await fetch(acmsConfig.restUrl + 'products/bulk', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': acmsConfig.nonce
                    },
                    body: JSON.stringify({ action: 'reset-ai', ids })
                });

                const result = await response.json();
                if (result.success) {
                    this.toast('success', 'AI Reset', result.message || 'Stuck AI products reset and re-queued');
                } else {
                    this.toast('error', 'Error', result.message || 'Failed to reset AI status');
                }
            } catch (error) {
                this.toast('error', 'Error', 'Request failed: ' + (error.message || 'Unknown error'));
            } finally {
                window.dispatchEvent(new CustomEvent('products-updated'));
            }
        },

        async bulkQuickUpdate() {
            if (this.selectedProducts.length === 0) return;

            const count = this.selectedProducts.length;
            const ids = this.selectedProducts.map(p => p.id);

            this.toast('info', 'Quick Update', `Updating ${count} product${count > 1 ? 's' : ''}... This may take a moment.`);
            this.selectedProducts = [];
            this.selectedCount = 0;

            try {
                const response = await fetch(acmsConfig.restUrl + 'products/bulk', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': acmsConfig.nonce
                    },
                    body: JSON.stringify({ action: 'quick-update', ids })
                });

                const result = await response.json();
                if (result.success) {
                    const d = result.data || {};
                    if (d.queued) {
                        // Async queue mode (> 10 products)
                        this.toast('info', 'Quick Update', result.message || `${d.queued} products queued for background update`);
                    } else {
                        // Sync mode (≤ 10 products)
                        const type = d.failed > 0 && d.updated === 0 ? 'error' : (d.failed > 0 ? 'warning' : 'success');
                        let msg = result.message || 'Products updated successfully';
                        if (d.errors && d.errors.length > 0) {
                            msg += '\n' + d.errors.slice(0, 3).join('\n');
                        }
                        this.toast(type, 'Quick Update', msg);
                    }
                } else {
                    this.toast('error', 'Error', result.message || 'Failed to update products');
                }
            } catch (error) {
                this.toast('error', 'Error', 'Request failed: ' + (error.message || 'Unknown error'));
            } finally {
                window.dispatchEvent(new CustomEvent('products-updated'));
            }
        },

        toast(type, title, message) {
            this.toastType = type;
            this.toastTitle = title;
            this.toastMessage = message;
            this.showToast = true;
            setTimeout(() => { this.showToast = false; }, 5000);
        },

        // Template Builder functions
        openTemplateBuilder() {
            this.scEditMode = false;
            this.scCopied = false;
            this.scCustomAsins = '';
            this.showTemplateBuilder = true;
        },

        get scSelectedAsins() {
            if (this.scEditMode || this.selectedProducts.length === 0) {
                // Parse custom ASINs from textarea
                const text = this.scCustomAsins || '';
                const asins = text.split(/[\s,]+/).filter(a => /^[A-Z0-9]{10}$/i.test(a.trim()));
                return asins.map(a => a.toUpperCase());
            }
            return this.selectedProducts.map(p => p.asin);
        },

        get scGeneratedShortcode() {
            if (this.scSelectedAsins.length === 0) return '';

            const asins = this.scSelectedAsins.join(',');
            let shortcode = '';

            switch (this.scTemplate) {
                case 'grid':
                    shortcode = `[acms_grid asin="${asins}"`;
                    shortcode += ` columns="${this.scColumns.lg}"`;
                    if (this.scBadges.length > 0) {
                        shortcode += ` show_badges="true"`;
                    }
                    break;

                case 'list':
                default:
                    shortcode = `[acms_list asin="${asins}"`;
                    if (this.scBadges.length > 0) {
                        shortcode += ` show_badges="true"`;
                    }
                    // Display options (only add if different from default true)
                    if (!this.scOptions.show_price) shortcode += ` show_price="false"`;
                    if (!this.scOptions.show_rating) shortcode += ` show_rating="false"`;
                    if (!this.scOptions.show_image) shortcode += ` show_image="false"`;
                    if (!this.scOptions.show_prime) shortcode += ` show_prime="false"`;
                    // Button text (only add if different from default)
                    if (this.scOptions.button_text && this.scOptions.button_text !== 'Buy on Amazon') {
                        shortcode += ` button_text="${this.scOptions.button_text}"`;
                    }
                    break;
            }

            shortcode += ']';
            return shortcode;
        },

        scToggleBadge(badge) {
            const index = this.scBadges.indexOf(badge);
            if (index > -1) {
                this.scBadges.splice(index, 1);
            } else {
                this.scBadges.push(badge);
            }
        },

        scRemoveBadge(badge) {
            const index = this.scBadges.indexOf(badge);
            if (index > -1) {
                this.scBadges.splice(index, 1);
            }
        },

        scCopyShortcode() {
            if (this.scSelectedAsins.length === 0) return;
            navigator.clipboard.writeText(this.scGeneratedShortcode).then(() => {
                this.scCopied = true;
                setTimeout(() => {
                    this.scCopied = false;
                }, 2000);
                this.toast('success', 'Copied', 'Shortcode copied to clipboard');
            });
        },

        scEnableEdit() {
            this.scCustomAsins = this.selectedProducts.map(p => p.asin).join(', ');
        },

        scResetBuilder() {
            this.scTemplate = 'list';
            this.scBadges = [];
            this.scColumns = { xs: 1, sm: 1, md: 2, lg: 3, xl: 4 };
            this.scOptions = {
                show_price: true,
                show_rating: true,
                show_image: true,
                show_prime: true,
                button_text: 'Buy on Amazon'
            };
            this.scCopied = false;
            this.scCustomAsins = '';
            this.scEditMode = false;
        },

        // Scrape log functions
        async rescrapeProduct(product) {
            // Reset state
            this.scrapeLogProduct = product;
            this.scrapeLogs = [];
            this.scraping = true;
            this.scrapeSuccess = false;
            this.logCopied = false;
            this.showScrapeLogModal = true;

            // Update global store for cross-component access
            Alpine.store('app').startScraping(product.asin);

            // Add initial log
            this.addScrapeLog(`Starting scrape for ASIN: ${product.asin}`, 'info');
            this.addScrapeLog(`API URL: ${acmsConfig.restUrl}products/scrape`, 'info');
            this.addScrapeLog(`Nonce: ${acmsConfig.nonce ? 'present' : 'MISSING'}`, acmsConfig.nonce ? 'info' : 'error');

            // First test if API is accessible with GET request
            this.addScrapeLog('Testing API connection (GET /products/stats)...', 'info');
            try {
                const testResponse = await fetch(acmsConfig.restUrl + 'products/stats', {
                    headers: { 'X-WP-Nonce': acmsConfig.nonce }
                });
                if (testResponse.ok) {
                    this.addScrapeLog('API connection OK', 'success');
                } else {
                    this.addScrapeLog(`API test failed: ${testResponse.status}`, 'error');
                }
            } catch (testError) {
                this.addScrapeLog(`API test error: ${testError.message}`, 'error');
            }

            this.addScrapeLog('Sending scrape request...', 'info');

            try {
                const response = await fetch(acmsConfig.restUrl + 'products/scrape', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': acmsConfig.nonce
                    },
                    body: JSON.stringify({
                        asin: product.asin
                    })
                });

                this.addScrapeLog(`Response status: ${response.status} ${response.statusText}`, response.ok ? 'info' : 'error');
                const contentType = response.headers.get('content-type');
                this.addScrapeLog(`Content-Type: ${contentType}`, 'info');

                // Always read as text first to debug
                const responseText = await response.text();
                this.addScrapeLog(`Response length: ${responseText.length} chars`, 'info');

                // Check if it looks like HTML
                if (responseText.trim().startsWith('<')) {
                    this.addScrapeLog(`Response is HTML (not JSON)!`, 'error');
                    this.addScrapeLog(`Preview: ${responseText.substring(0, 300)}`, 'error');
                    this.scrapeSuccess = false;
                    this.scraping = false;
                    Alpine.store('app').stopScraping();
                    return;
                }

                // Try to parse as JSON
                let result;
                try {
                    result = JSON.parse(responseText);
                } catch (parseError) {
                    this.addScrapeLog(`JSON parse error: ${parseError.message}`, 'error');
                    this.addScrapeLog(`Raw response: ${responseText.substring(0, 500)}`, 'error');
                    this.scrapeSuccess = false;
                    this.scraping = false;
                    Alpine.store('app').stopScraping();
                    return;
                }

                if (result.success && result.data?.results?.[product.asin]) {
                    const scrapeResult = result.data.results[product.asin];

                    // Add logs from server if available
                    if (scrapeResult.log && Array.isArray(scrapeResult.log)) {
                        scrapeResult.log.forEach(logLine => {
                            // Parse server log format: "[HH:MM:SS] message"
                            const match = logLine.match(/^\[(\d{2}:\d{2}:\d{2})\]\s*(.+)$/);
                            if (match) {
                                const msg = match[2];
                                let type = 'info';
                                if (msg.includes('SUCCESS') || msg.includes('SUCCESS via')) {
                                    type = 'success';
                                } else if (msg.includes('FAILED') || msg.includes('ERROR')) {
                                    type = 'error';
                                } else if (msg.includes('DATA') || msg.includes('title:')) {
                                    type = 'data';
                                }
                                this.addScrapeLog(msg, type);
                            } else {
                                this.addScrapeLog(logLine, 'info');
                            }
                        });
                    }

                    if (scrapeResult.success) {
                        this.scrapeSuccess = true;

                        // Update scrapeLogProduct with new data from scrape result
                        if (scrapeResult.title) {
                            this.scrapeLogProduct.title = scrapeResult.title;
                        }
                        this.scrapeLogProduct.status = 'scraped';
                        if (scrapeResult.provider) {
                            this.scrapeLogProduct.last_provider = scrapeResult.provider;
                        }

                        this.addScrapeLog(`Scrape completed successfully`, 'success');
                        if (scrapeResult.title) {
                            this.addScrapeLog(`Product: ${scrapeResult.title.substring(0, 60)}...`, 'data');
                        }
                        if (scrapeResult.provider) {
                            this.addScrapeLog(`Provider: ${scrapeResult.provider}`, 'data');
                        }
                        // Show database update status
                        if (scrapeResult.db_update) {
                            this.addScrapeLog(`Database update: ${scrapeResult.db_update}`, scrapeResult.db_update === 'success' ? 'success' : 'error');
                        }
                        if (scrapeResult.fields_received) {
                            this.addScrapeLog(`Fields: ${scrapeResult.fields_received.join(', ')}`, 'info');
                        }
                        // Refresh products list
                        window.dispatchEvent(new CustomEvent('products-updated'));
                    } else {
                        this.scrapeSuccess = false;
                        // Update status to failed
                        this.scrapeLogProduct.status = 'failed';
                        this.addScrapeLog(`Scrape failed: ${scrapeResult.error || 'Unknown error'}`, 'error');
                    }
                } else {
                    this.scrapeSuccess = false;
                    // Update status to failed
                    this.scrapeLogProduct.status = 'failed';
                    const errorMsg = result.message || result.error || 'Unknown error';
                    this.addScrapeLog(`API Error: ${errorMsg}`, 'error');
                    if (result.file && result.line) {
                        this.addScrapeLog(`Location: ${result.file}:${result.line}`, 'error');
                    }
                    if (result.trace) {
                        this.addScrapeLog(`Trace: ${result.trace.substring(0, 500)}`, 'error');
                    }
                }
            } catch (error) {
                this.scrapeSuccess = false;
                // Update status to failed
                this.scrapeLogProduct.status = 'failed';
                this.addScrapeLog(`Network error: ${error.message}`, 'error');
            } finally {
                this.scraping = false;
                Alpine.store('app').stopScraping();
            }
        },

        addScrapeLog(msg, type = 'info') {
            const now = new Date();
            const time = now.toLocaleTimeString('en-US', { hour12: false });
            this.scrapeLogs.push({ time, msg, type });

            // Auto-scroll to bottom
            this.$nextTick(() => {
                const terminal = document.querySelector('.scrape-log-terminal');
                if (terminal) {
                    terminal.scrollTop = terminal.scrollHeight;
                }
            });
        },

        closeScrapeLog() {
            if (!this.scraping) {
                this.showScrapeLogModal = false;
                this.scrapeLogs = [];
                this.scrapeLogProduct = null;
            }
        },

        async copyLogToClipboard() {
            if (this.scrapeLogs.length === 0) return;

            const logText = this.scrapeLogs.map(log => `[${log.time}] [${log.type.toUpperCase()}] ${log.msg}`).join('\n');
            try {
                await navigator.clipboard.writeText(logText);
                this.logCopied = true;
                setTimeout(() => { this.logCopied = false; }, 2000);
            } catch (error) {
            }
        },

        cancelProcessing() {
            this.showProcessing = false;
            this.processingProgress = 0;
            this.processingCurrent = 0;
            this.processingTotal = 0;
        },

        startProcessing(title, total = 0, cancellable = false) {
            this.showProcessing = true;
            this.processingTitle = title;
            this.processingSubtitle = '';
            this.processingProgress = 0;
            this.processingCurrent = 0;
            this.processingTotal = total;
            this.processingCancellable = cancellable;
        },

        updateProcessing(current, subtitle = '') {
            this.processingCurrent = current;
            this.processingSubtitle = subtitle;
            if (this.processingTotal > 0) {
                this.processingProgress = Math.round((current / this.processingTotal) * 100);
            }
        },

        finishProcessing() {
            this.processingProgress = 100;
            setTimeout(() => {
                this.showProcessing = false;
            }, 500);
        }
    }));

    // Custom Alpine.js Products Table Component (Server-Side Pagination/Search/Filter)
    Alpine.data('productsTable', () => ({
        // State
        isLoading: true,
        products: [],
        selectedIds: [],
        searchQuery: '',

        // Sorting
        sortColumn: 'id',
        sortDirection: 'desc',

        // Pagination
        currentPage: 1,
        pageSize: 100,
        totalItems: 0,
        totalPages: 1,

        // Filters from parent
        statusFilter: '',
        stockFilter: '',
        aiStatusFilter: '',

        // Debounce
        _searchTimer: null,
        _skipPageWatch: false,

        // Computed: visible page numbers
        get visiblePages() {
            const pages = [];
            const total = this.totalPages;
            const current = this.currentPage;

            let start = Math.max(1, current - 2);
            let end = Math.min(total, current + 2);

            // Adjust to show 5 pages when possible
            if (end - start < 4) {
                if (start === 1) {
                    end = Math.min(total, start + 4);
                } else if (end === total) {
                    start = Math.max(1, end - 4);
                }
            }

            for (let i = start; i <= end; i++) {
                pages.push(i);
            }

            return pages;
        },

        init() {
            this.loadData();

            // Listen for search updates (debounced)
            window.addEventListener('update-search', (e) => {
                this.searchQuery = e.detail.query;
                clearTimeout(this._searchTimer);
                this._searchTimer = setTimeout(() => {
                    this._resetPageAndLoad();
                }, 300);
            });

            // Listen for filter updates
            window.addEventListener('filters-applied', (e) => {
                this.statusFilter = e.detail.status || '';
                this.stockFilter = e.detail.stock || '';
                this.aiStatusFilter = e.detail.ai_status || '';
                this._resetPageAndLoad();
            });

            window.addEventListener('filters-cleared', () => {
                this.statusFilter = '';
                this.stockFilter = '';
                this.aiStatusFilter = '';
                this._resetPageAndLoad();
            });

            // Watch for page changes to load new data (pagination clicks)
            this.$watch('currentPage', (newVal, oldVal) => {
                if (this._skipPageWatch) return;
                this.selectedIds = [];
                this.dispatchSelectionChange();
                this.loadData();
            });

            // Listen for products-updated event
            window.addEventListener('products-updated', () => {
                this.selectedIds = [];
                this.dispatchSelectionChange();
                this.loadData();
            });
        },

        async loadData() {
            this.isLoading = true;
            try {
                const params = new URLSearchParams({
                    page: this.currentPage,
                    per_page: this.pageSize,
                    orderby: this.sortColumn,
                    order: this.sortDirection,
                });
                if (this.searchQuery) params.set('search', this.searchQuery);
                if (this.statusFilter) params.set('status', this.statusFilter);
                if (this.stockFilter === 'in') params.set('in_stock', '1');
                else if (this.stockFilter === 'out') params.set('in_stock', '0');
                if (this.aiStatusFilter) params.set('ai_status', this.aiStatusFilter);

                const response = await fetch(acmsConfig.restUrl + 'products?' + params.toString(), {
                    headers: { 'X-WP-Nonce': acmsConfig.nonce }
                });
                const result = await response.json();
                if (result.success) {
                    this.products = result.data.products || [];
                    this.totalItems = result.data.total || 0;
                    this.totalPages = result.data.total_pages || 1;

                    // Dispatch stats if available
                    if (result.data.stats) {
                        window.dispatchEvent(new CustomEvent('stats-updated', {
                            detail: result.data.stats
                        }));
                    }
                    this.dispatchFilteredCount();
                }
            } catch (error) {
                console.error('Failed to load products:', error);
            } finally {
                this.isLoading = false;
            }
        },

        changePageSize(size) {
            this.pageSize = size;
            this._skipPageWatch = true;
            this.currentPage = 1;
            this.$nextTick(() => {
                this._skipPageWatch = false;
                this.loadData();
            });
        },

        _resetPageAndLoad() {
            this._skipPageWatch = true;
            this.currentPage = 1;
            this.selectedIds = [];
            this.dispatchSelectionChange();
            this.$nextTick(() => {
                this._skipPageWatch = false;
                this.loadData();
            });
        },

        sortBy(column) {
            if (this.sortColumn === column) {
                this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
            } else {
                this.sortColumn = column;
                this.sortDirection = 'asc';
            }
            this._skipPageWatch = true;
            this.currentPage = 1;
            this.$nextTick(() => {
                this._skipPageWatch = false;
                this.loadData();
            });
        },

        toggleSelect(id) {
            const idx = this.selectedIds.indexOf(id);
            if (idx === -1) {
                this.selectedIds.push(id);
            } else {
                this.selectedIds.splice(idx, 1);
            }
            this.dispatchSelectionChange();
        },

        toggleSelectAll(checked) {
            if (checked) {
                this.selectedIds = this.products.map(p => p.id);
            } else {
                this.selectedIds = [];
            }
            this.dispatchSelectionChange();
        },

        dispatchSelectionChange() {
            const selectedProducts = this.products.filter(p => this.selectedIds.includes(p.id));
            window.dispatchEvent(new CustomEvent('selection-changed', {
                detail: { count: this.selectedIds.length, products: selectedProducts }
            }));
        },

        dispatchFilteredCount() {
            const hasFilters = this.searchQuery || this.statusFilter || this.stockFilter;
            window.dispatchEvent(new CustomEvent('filtered-count-changed', {
                detail: {
                    count: this.totalItems,
                    hasFilters: hasFilters,
                    total: this.totalItems
                }
            }));
        },

        getStatusColor(status) {
            const colors = {
                pending: 'primary',
                processing: 'info',
                scheduled: 'warning',
                scraped: 'success',
                failed: 'error',
                update: 'warning',
                updating: 'info'
            };
            return colors[status] || 'secondary';
        },

        getAiStatusColor(aiStatus) {
            const colors = {
                'not_generated': 'secondary',
                'queued': 'primary',
                'generating': 'info',
                'generated': 'success',
                'failed': 'error'
            };
            return colors[aiStatus] || 'secondary';
        },

        getAiStatusIcon(aiStatus) {
            const icons = {
                'not_generated': 'bi-dash',
                'queued': 'bi-clock',
                'generating': 'bi-arrow-repeat animate-spin',
                'generated': 'bi-robot',
                'failed': 'bi-exclamation-triangle'
            };
            return icons[aiStatus] || 'bi-dash';
        },

        getAiStatusLabel(aiStatus) {
            const labels = {
                'not_generated': '-',
                'queued': 'Queued',
                'generating': 'AI...',
                'generated': 'AI',
                'failed': 'Failed'
            };
            return labels[aiStatus] || '-';
        },

        getAiStatusTitle(product) {
            if (!product.ai_status || product.ai_status === 'not_generated') {
                return 'AI content not generated';
            }
            if (product.ai_status === 'queued') {
                return 'Queued for AI generation';
            }
            if (product.ai_status === 'generating') {
                return 'AI is generating content...';
            }
            if (product.ai_status === 'generated') {
                const date = product.ai_generated_at ? this.formatDate(product.ai_generated_at) : '';
                return 'AI content generated' + (date ? ' on ' + date : '');
            }
            if (product.ai_status === 'failed') {
                return 'AI generation failed: ' + (product.ai_error_message || 'Unknown error');
            }
            return '';
        },

        openLightbox(product) {
            if (product.image_url) {
                Alpine.store('app').openLightbox(product.image_url, product.title || 'Product Image');
            }
        },

        copyAsin(product) {
            navigator.clipboard.writeText(product.asin).then(() => {
                product._copied = true;
                setTimeout(() => { product._copied = false; }, 2000);
            });
        },

        formatNumber(num) {
            if (!num) return '';
            const n = parseInt(num);
            if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M';
            if (n >= 1000) return (n / 1000).toFixed(1) + 'K';
            return n.toLocaleString();
        },

        formatDate(dateStr) {
            if (!dateStr) return '-';
            const d = new Date(dateStr);
            const day = String(d.getDate()).padStart(2, '0');
            const month = String(d.getMonth() + 1).padStart(2, '0');
            const year = d.getFullYear();
            return `${day}/${month}/${year}`;
        },

        formatDateTime(dateStr) {
            if (!dateStr) return '';
            const d = new Date(dateStr);
            const hours = String(d.getHours()).padStart(2, '0');
            const minutes = String(d.getMinutes()).padStart(2, '0');
            const seconds = String(d.getSeconds()).padStart(2, '0');
            return `${hours}:${minutes}:${seconds}`;
        }
    }));
});
</script>
