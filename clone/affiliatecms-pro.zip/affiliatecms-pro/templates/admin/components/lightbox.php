<?php
/**
 * Lightbox Component
 * Image preview overlay
 *
 * @package AffiliateCMS\Pro
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<!-- Lightbox -->
<div x-show="$store.app.lightbox.open"
     x-transition:enter="transition ease-out duration-200"
     x-transition:enter-start="opacity-0"
     x-transition:enter-end="opacity-100"
     x-transition:leave="transition ease-in duration-150"
     x-transition:leave-start="opacity-100"
     x-transition:leave-end="opacity-0"
     @click="$store.app.closeLightbox()"
     @keydown.escape.window="$store.app.closeLightbox()"
     @open-lightbox.window="$store.app.openLightbox($event.detail.image, $event.detail.title)"
     class="lightbox-overlay"
     style="display: none; position: fixed; inset: 0; z-index: 99999; background: rgba(0,0,0,0.9); display: flex; align-items: center; justify-content: center;"
     x-cloak>

    <div class="lightbox-content" @click.stop style="position: relative; max-width: 90vw; max-height: 90vh;">
        <!-- Close button -->
        <button class="lightbox-close" @click="$store.app.closeLightbox()" title="Close"
                style="position: absolute; top: -40px; right: 0; background: none; border: none; color: white; font-size: 24px; cursor: pointer; padding: 8px;">
            <i class="bi bi-x-lg"></i>
        </button>

        <!-- Image -->
        <img :src="$store.app.lightbox.image"
             :alt="$store.app.lightbox.title"
             class="lightbox-image"
             style="max-width: 100%; max-height: 85vh; object-fit: contain; border-radius: 8px;">

        <!-- Title -->
        <div class="lightbox-title" x-show="$store.app.lightbox.title" x-text="$store.app.lightbox.title"
             style="color: white; text-align: center; margin-top: 16px; font-size: 14px; opacity: 0.8;"></div>
    </div>
</div>
