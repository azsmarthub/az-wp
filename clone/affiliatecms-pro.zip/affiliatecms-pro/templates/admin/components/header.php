<?php
/**
 * Page Header Component
 *
 * @package AffiliateCMS\Pro
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<!-- Page Header Component -->
<header class="page-header">
    <!-- Left: Title & Stats -->
    <div class="header-left">
        <h1 class="page-title">
            <?php if (!empty($icon)): ?>
                <i class="bi <?php echo esc_attr($icon); ?>"></i>
            <?php endif; ?>
            <?php echo esc_html($title ?? 'Products'); ?>
        </h1>

        <?php if (!empty($stats)): ?>
            <div class="header-divider"></div>
            <div class="stats-inline">
                <?php foreach ($stats as $stat): ?>
                    <div class="stat-item <?php echo esc_attr($stat['class'] ?? ''); ?>" title="<?php echo esc_attr($stat['title'] ?? ''); ?>">
                        <span class="stat-item-dot"></span>
                        <span class="stat-item-value"><?php echo esc_html($stat['value']); ?></span>
                        <span class="stat-item-label"><?php echo esc_html($stat['label']); ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- Right: Actions -->
    <div class="header-right flex items-center gap-2">
        <?php if (!empty($actions)): ?>
            <?php foreach ($actions as $action): ?>
                <?php if ($action['type'] === 'icon'): ?>
                    <button class="btn-icon tooltip <?php echo esc_attr($action['class'] ?? ''); ?>"
                            data-tooltip="<?php echo esc_attr($action['tooltip'] ?? ''); ?>"
                            <?php if (!empty($action['alpine'])): ?>
                                @click="<?php echo esc_attr($action['alpine']); ?>"
                            <?php endif; ?>>
                        <i class="bi <?php echo esc_attr($action['icon']); ?>"></i>
                    </button>
                <?php elseif ($action['type'] === 'button'): ?>
                    <button class="btn <?php echo esc_attr($action['class'] ?? 'btn-primary'); ?>"
                            <?php if (!empty($action['alpine'])): ?>
                                @click="<?php echo esc_attr($action['alpine']); ?>"
                            <?php endif; ?>>
                        <?php if (!empty($action['icon'])): ?>
                            <i class="bi <?php echo esc_attr($action['icon']); ?>"></i>
                        <?php endif; ?>
                        <?php echo esc_html($action['label']); ?>
                    </button>
                <?php elseif ($action['type'] === 'divider'): ?>
                    <div class="header-divider"></div>
                <?php endif; ?>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</header>
