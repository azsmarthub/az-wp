<?php
/**
 * Processing Overlay Component - Shows during batch operations
 *
 * @package AffiliateCMS\Pro
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<!-- Processing Overlay -->
<div class="modal-backdrop" x-show="showProcessing" x-cloak
     x-transition:enter="transition ease-out duration-200"
     x-transition:enter-start="opacity-0"
     x-transition:enter-end="opacity-100"
     x-transition:leave="transition ease-in duration-150"
     x-transition:leave-start="opacity-100"
     x-transition:leave-end="opacity-0"
     style="background: rgba(0,0,0,0.9); position: fixed; inset: 0; z-index: 99999; display: flex; align-items: center; justify-content: center;">
    <div style="text-align: center;">
        <!-- Spinner -->
        <div class="spinner spinner-lg" style="width: 48px; height: 48px; border-width: 3px; margin: 0 auto 24px;"></div>

        <!-- Title -->
        <div style="font-size: 18px; font-weight: 600; margin-bottom: 8px; color: white;" x-text="processingTitle || 'Processing...'"></div>

        <!-- Subtitle -->
        <div style="font-size: 14px; margin-bottom: 24px; color: rgba(255,255,255,0.7);" x-text="processingSubtitle || ''"></div>

        <!-- Progress Bar -->
        <div class="progress" style="width: 300px; margin: 0 auto; height: 8px; background: rgba(255,255,255,0.2); border-radius: 4px; overflow: hidden;">
            <div class="progress-bar" :style="'width: ' + processingProgress + '%'"
                 style="height: 100%; background: var(--primary); transition: width 0.3s;"></div>
        </div>

        <!-- Progress Text -->
        <div style="font-size: 12px; margin-top: 12px; color: rgba(255,255,255,0.5);">
            <span x-text="processingCurrent || 0"></span> of <span x-text="processingTotal || 0"></span> completed
        </div>

        <!-- Cancel Button (optional) -->
        <button x-show="processingCancellable" class="btn btn-secondary" style="margin-top: 24px;" @click="cancelProcessing()">
            <i class="bi bi-x-lg"></i>
            Cancel
        </button>
    </div>
</div>
