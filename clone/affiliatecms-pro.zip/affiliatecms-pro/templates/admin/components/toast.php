<?php
/**
 * Toast Notifications Component
 *
 * @package AffiliateCMS\Pro
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<!-- Toast Notifications -->
<div class="toast-container"
     x-show="showToast"
     x-cloak
     x-transition:enter="transition ease-out duration-300"
     x-transition:enter-start="opacity-0 transform translate-y-2"
     x-transition:enter-end="opacity-100 transform translate-y-0"
     x-transition:leave="transition ease-in duration-200"
     x-transition:leave-start="opacity-100 transform translate-y-0"
     x-transition:leave-end="opacity-0 transform translate-y-2"
     @show-toast.window="showToast = true; toastType = $event.detail.type; toastTitle = $event.detail.title; toastMessage = $event.detail.message; setTimeout(() => showToast = false, 5000)"
     style="position: fixed; bottom: 24px; right: 24px; z-index: 10000;">
    <div class="toast" :class="toastType"
         style="display: flex; align-items: flex-start; gap: 12px; padding: 16px 20px; background: var(--bg-surface); border: 1px solid var(--border); border-radius: var(--radius-lg); box-shadow: 0 10px 40px rgba(0,0,0,0.3); min-width: 320px; max-width: 420px;">
        <!-- Icon -->
        <i class="bi toast-icon" style="font-size: 18px;"
           :class="{
               'bi-check-circle-fill text-success': toastType === 'success',
               'bi-x-circle-fill text-error': toastType === 'error',
               'bi-exclamation-triangle-fill text-warning': toastType === 'warning',
               'bi-info-circle-fill text-info': toastType === 'info'
           }"></i>
        <!-- Content -->
        <div class="toast-content" style="flex: 1;">
            <div class="toast-title" style="font-weight: 600; margin-bottom: 2px;" x-text="toastTitle"></div>
            <div class="toast-message" style="font-size: 13px; color: var(--text-secondary);" x-text="toastMessage"></div>
        </div>
        <!-- Close Button -->
        <button class="btn-icon btn-icon-sm btn-ghost" @click="showToast = false" style="margin: -4px -8px -4px 0;">
            <i class="bi bi-x-lg"></i>
        </button>
    </div>
</div>
