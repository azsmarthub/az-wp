<?php
/**
 * Cache Management Admin Page Template
 *
 * Full-page cache preload management with URL tracking table.
 * Uses Alpine.js component pattern (same as brands-page.php).
 *
 * @package AffiliateCMS\Pro
 */

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}
?>
<!-- Cache Page Styles -->
<style>
    #acms-cache-app .sort-btn {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        padding: 0;
        margin: 0;
        border: none;
        background: none;
        font-size: 12px;
        font-weight: 600;
        font-family: inherit;
        color: var(--text-secondary);
        cursor: pointer;
        white-space: nowrap;
        line-height: 1;
        transition: color 0.15s ease;
    }
    #acms-cache-app .sort-btn:hover {
        color: var(--text-primary);
    }
    #acms-cache-app .sort-btn:focus {
        outline: none;
    }
    #acms-cache-app .sort-btn .bi {
        font-size: 10px;
        opacity: 0.5;
        transition: opacity 0.15s ease;
    }
    #acms-cache-app .sort-btn:hover .bi {
        opacity: 0.8;
    }
    #acms-cache-app .data-table th {
        font-size: 12px;
        font-weight: 600;
        color: var(--text-secondary);
        padding: 8px 12px;
        white-space: nowrap;
    }
    /* Toast type colors (matching admin.css pattern) */
    .toast-success { border-left: 3px solid var(--success); }
    .toast-success .bi { color: var(--success); }
    .toast-error { border-left: 3px solid var(--error, var(--danger)); }
    .toast-error .bi { color: var(--error, var(--danger)); }
    .toast-info { border-left: 3px solid var(--primary); }
    .toast-info .bi { color: var(--primary); }
</style>

<!-- Global Config -->
<script>
    window.acmsCacheConfig = {
        restUrl: '<?php echo esc_js(rest_url('acms/v1/')); ?>',
        nonce: '<?php echo esc_js(wp_create_nonce('wp_rest')); ?>'
    };
</script>

<div id="acms-cache-app" class="acms-admin" x-data="cachePage()">
    <div class="app-container">
        <!-- Page Header -->
        <header class="page-header">
            <div class="header-left">
                <div class="stats-inline">
                    <div class="stat-item total" title="Total URLs in queue"
                         @click="filterStatus = ''; page = 1; loadUrls()" style="cursor:pointer;">
                        <span class="stat-item-dot"></span>
                        <span class="stat-item-value" x-text="formatNum(stats.total)">0</span>
                        <span class="stat-item-label">Total</span>
                    </div>
                    <div class="stat-item scraped" title="Cached URLs"
                         @click="filterStatus = 'cached'; page = 1; loadUrls()" style="cursor:pointer;">
                        <span class="stat-item-dot"></span>
                        <span class="stat-item-value" x-text="formatNum(stats.cached)">0</span>
                        <span class="stat-item-label">Cached</span>
                    </div>
                    <div class="stat-item pending" title="Pending URLs"
                         @click="filterStatus = 'pending'; page = 1; loadUrls()" style="cursor:pointer;">
                        <span class="stat-item-dot"></span>
                        <span class="stat-item-value" x-text="formatNum(stats.pending)">0</span>
                        <span class="stat-item-label">Pending</span>
                    </div>
                    <div class="stat-item failed" title="Failed URLs"
                         @click="filterStatus = 'failed'; page = 1; loadUrls()" style="cursor:pointer;">
                        <span class="stat-item-dot"></span>
                        <span class="stat-item-value" x-text="formatNum(stats.failed + stats.timeout)">0</span>
                        <span class="stat-item-label">Failed</span>
                    </div>
                    <div class="stat-item" title="Nginx cache files / disk">
                        <span class="stat-item-dot"></span>
                        <span class="stat-item-value" x-text="formatNum(cacheFiles)">0</span>
                        <span class="stat-item-label" x-text="cacheSize">Files</span>
                    </div>
                </div>
            </div>

            <div class="flex items-center gap-2">
                <button class="btn btn-secondary" @click="smartRefresh()" :disabled="isPreloading"
                    title="Smart Refresh — purge+warm ~10K important URLs (posts, pages, top categories)">
                    <i class="bi" :class="isPreloading ? 'bi-arrow-repeat animate-spin' : 'bi-arrow-clockwise'"></i>
                    Smart Refresh
                </button>
                <button class="btn btn-secondary" @click="resumeQueue()" :disabled="isPreloading"
                    title="Resume stalled queue — re-spawn chunk worker if pending URLs exist">
                    <i class="bi" :class="isResuming ? 'bi-arrow-repeat animate-spin' : 'bi-play-circle'"></i>
                    Resume
                </button>
                <button class="btn btn-secondary" @click="cleanOrphans()" :disabled="isPreloading"
                    title="Clean orphan URLs — remove deleted posts/pages/categories from cache queue">
                    <i class="bi" :class="isCleaning ? 'bi-arrow-repeat animate-spin' : 'bi-eraser'"></i>
                    Clean Orphans
                </button>
                <button class="btn btn-primary" @click="fullPreload()" :disabled="isPreloading || inProgress"
                    title="Full preload — build queue from sitemap + start warming">
                    <i class="bi" :class="inProgress ? 'bi-arrow-repeat animate-spin' : 'bi-play-fill'"></i>
                    <span x-text="inProgress ? 'Running...' : 'Full Preload'"></span>
                </button>
                <button class="btn btn-secondary" @click="stopPreload()" :disabled="!inProgress"
                    title="Stop running preload">
                    <i class="bi bi-stop-fill"></i>
                    Stop
                </button>

                <!-- More Actions Dropdown -->
                <div class="dropdown" x-data="{ open: false }" style="position:relative;z-index:200;">
                    <button class="btn btn-secondary" @click="open = !open">
                        <i class="bi bi-three-dots-vertical"></i>
                    </button>
                    <div class="dropdown-menu" x-show="open" @click.outside="open = false" x-cloak
                         style="right:0;left:auto;min-width:180px;z-index:201;">
                        <button class="dropdown-item" @click="purgeAll(); open = false">
                            <i class="bi bi-trash3"></i>
                            Purge All Cache
                        </button>
                        <div class="dropdown-divider"></div>
                        <button class="dropdown-item" @click="resetFailed(); open = false">
                            <i class="bi bi-arrow-counterclockwise"></i>
                            Reset Failed URLs
                        </button>
                    </div>
                </div>

                <button class="btn btn-secondary" @click="refreshAll()" :disabled="isRefreshing" title="Refresh">
                    <i class="bi" :class="isRefreshing ? 'bi-arrow-repeat animate-spin' : 'bi-arrow-repeat'"></i>
                </button>
                <button class="btn btn-secondary" @click="showSettings = true" title="Cache Settings">
                    <i class="bi bi-gear"></i>
                </button>
            </div>
        </header>

        <!-- Progress Bar (visible during preload) -->
        <div x-show="inProgress" x-cloak
             style="margin-bottom:16px;padding:14px;background:var(--bg-base);border:1px solid var(--border);border-radius:var(--radius-md);">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;">
                <span style="font-weight:600;font-size:13px;color:var(--text-primary);">
                    <i class="bi bi-arrow-repeat animate-spin" style="color:var(--primary);"></i> Preloading...
                </span>
                <span style="font-size:12px;color:var(--text-muted);">
                    CPU: <span x-text="progress.cpu != null ? progress.cpu + '%' : '?'"></span> |
                    Batch: <span x-text="progress.batch_size || '?'"></span> |
                    Chunk: <span x-text="progress.chunk_size || '?'"></span> |
                    Delay: <span x-text="progress.delay_ms ? progress.delay_ms + 'ms' : '?'"></span>
                </span>
            </div>
            <div style="width:100%;height:8px;background:var(--bg-surface);border-radius:4px;overflow:hidden;">
                <div :style="'width:' + progressPercent + '%;background:' + progressColor + ';height:100%;border-radius:4px;transition:width 0.5s ease, background 0.5s ease;'"></div>
            </div>
            <div style="display:flex;justify-content:space-between;margin-top:6px;font-size:11px;color:var(--text-muted);">
                <span x-text="formatNum(progress.preloaded) + ' / ' + formatNum(progress.total) + ' cached'"></span>
                <span x-text="progressPercent + '%'"></span>
            </div>
        </div>

        <!-- Toolbar -->
        <div class="toolbar">
            <!-- Left: Info -->
            <div class="toolbar-section toolbar-left">
                <span style="font-size:12px;color:var(--text-muted);" x-show="totalItems > 0">
                    <span x-text="formatNum(totalItems)"></span> URLs
                    <template x-if="filterStatus || filterType || searchQuery">
                        <span> (filtered)</span>
                    </template>
                </span>
            </div>

            <!-- Center: Search -->
            <div class="toolbar-section toolbar-center">
                <form class="search-box" @submit.prevent>
                    <i class="bi bi-search search-icon"></i>
                    <input type="search" class="search-input" placeholder="Search URLs..." x-model="searchQuery"
                        @input.debounce.500ms="page = 1; loadUrls()" autocomplete="off">
                    <button type="button" class="search-clear" x-show="searchQuery" x-cloak
                        @click="searchQuery = ''; page = 1; loadUrls()">
                        <i class="bi bi-x-lg"></i>
                    </button>
                </form>
            </div>

            <!-- Right: Filters & Per Page -->
            <div class="toolbar-section toolbar-right" style="gap:8px;">
                <select class="form-select form-select-sm" x-model="filterType" @change="page = 1; loadUrls()"
                    style="width:auto;min-width:100px;">
                    <option value="">All Types</option>
                    <template x-for="(count, type) in byType" :key="type">
                        <option :value="type" x-text="type + ' (' + formatNum(count) + ')'"></option>
                    </template>
                </select>
                <select class="form-select form-select-sm" x-model="filterStatus" @change="page = 1; loadUrls()"
                    style="width:auto;min-width:100px;">
                    <option value="">All Status</option>
                    <option value="cached">Cached</option>
                    <option value="pending">Pending</option>
                    <option value="failed">Failed</option>
                    <option value="timeout">Timeout</option>
                    <option value="skipped">Skipped</option>
                </select>
                <select class="form-select form-select-sm" x-model="perPage" @change="page = 1; loadUrls()"
                    style="width:auto;min-width:70px;">
                    <option value="50">50</option>
                    <option value="100">100</option>
                    <option value="200">200</option>
                </select>
            </div>
        </div>

        <!-- Loading State -->
        <div class="empty-state" x-show="isLoading">
            <i class="bi bi-arrow-repeat animate-spin" style="font-size:32px;"></i>
            <p>Loading URLs...</p>
        </div>

        <!-- Empty State -->
        <div class="empty-state" x-show="!isLoading && urls.length === 0">
            <i class="bi bi-hdd-stack" style="font-size:48px;opacity:0.5;"></i>
            <p x-text="stats.total > 0 ? 'No URLs match your filters' : 'No URLs in queue'"></p>
            <p class="text-muted" style="font-size:13px;margin-top:8px;"
               x-show="stats.total === 0">Click "Full Preload" to build the URL queue from sitemap.</p>
        </div>

        <!-- URL Table -->
        <div class="data-table-wrapper" x-show="!isLoading && urls.length > 0">
            <table class="data-table">
                <thead>
                    <tr>
                        <th style="width:45%;">
                            <button class="sort-btn" @click="toggleSort('url')">
                                URL
                                <i class="bi" :class="sortIcon('url')"></i>
                            </button>
                        </th>
                        <th style="width:80px;text-align:center;">
                            <button class="sort-btn" @click="toggleSort('url_type')">
                                Type
                                <i class="bi" :class="sortIcon('url_type')"></i>
                            </button>
                        </th>
                        <th style="width:80px;text-align:center;">
                            <button class="sort-btn" @click="toggleSort('status')">
                                Status
                                <i class="bi" :class="sortIcon('status')"></i>
                            </button>
                        </th>
                        <th style="width:60px;text-align:center;">
                            <button class="sort-btn" @click="toggleSort('priority')">
                                Pri
                                <i class="bi" :class="sortIcon('priority')"></i>
                            </button>
                        </th>
                        <th style="width:60px;text-align:center;">
                            <button class="sort-btn" @click="toggleSort('http_code')">
                                HTTP
                                <i class="bi" :class="sortIcon('http_code')"></i>
                            </button>
                        </th>
                        <th style="width:70px;text-align:center;">
                            <button class="sort-btn" @click="toggleSort('response_time_ms')">
                                Time
                                <i class="bi" :class="sortIcon('response_time_ms')"></i>
                            </button>
                        </th>
                        <th style="width:50px;text-align:center;">Tries</th>
                        <th style="width:120px;text-align:right;">Last Warmed</th>
                        <th style="width:40px;"></th>
                    </tr>
                </thead>
                <tbody>
                    <template x-for="row in urls" :key="row.id">
                        <tr>
                            <td>
                                <a :href="row.url" target="_blank" rel="noopener"
                                   style="font-size:12px;color:var(--text-primary);text-decoration:none;word-break:break-all;"
                                   @mouseenter="$el.style.color='var(--primary)'"
                                   @mouseleave="$el.style.color='var(--text-primary)'"
                                   x-text="shortenUrl(row.url)"></a>
                            </td>
                            <td style="text-align:center;">
                                <span class="badge badge-muted" style="font-size:10px;padding:2px 6px;"
                                      x-text="row.url_type"></span>
                            </td>
                            <td style="text-align:center;">
                                <span class="badge" style="font-size:10px;padding:2px 6px;"
                                      :class="statusBadge(row.status)"
                                      x-text="row.status"></span>
                            </td>
                            <td style="text-align:center;font-size:12px;color:var(--text-muted);"
                                x-text="row.priority"></td>
                            <td style="text-align:center;">
                                <span style="font-size:12px;" :style="httpColor(row.http_code)"
                                      x-text="row.http_code || '—'"></span>
                            </td>
                            <td style="text-align:center;font-size:12px;color:var(--text-muted);"
                                x-text="row.response_time_ms !== null ? row.response_time_ms + 'ms' : '—'"></td>
                            <td style="text-align:center;font-size:12px;color:var(--text-muted);"
                                x-text="row.attempts"></td>
                            <td style="text-align:right;font-size:11px;color:var(--text-muted);"
                                x-text="row.last_warmed_at ? shortDate(row.last_warmed_at) : '—'"></td>
                            <td style="text-align:center;">
                                <button class="btn btn-secondary" style="padding:2px 6px;font-size:11px;line-height:1;"
                                    @click="purgeOneUrl(row)" title="Purge this URL cache">
                                    <i class="bi bi-x-lg" style="font-size:10px;"></i>
                                </button>
                            </td>
                        </tr>
                    </template>
                </tbody>
            </table>

            <!-- Pagination -->
            <div class="data-table-pagination" x-show="totalPages > 1">
                <div class="pagination-info">
                    Page <span x-text="page"></span> of <span x-text="totalPages"></span>
                </div>
                <div class="pagination-controls">
                    <div class="pagination-buttons">
                        <button class="pagination-btn" @click="goToPage(1)" :disabled="page <= 1" title="First">
                            <i class="bi bi-chevron-double-left"></i>
                        </button>
                        <button class="pagination-btn" @click="goToPage(page - 1)" :disabled="page <= 1" title="Previous">
                            <i class="bi bi-chevron-left"></i>
                        </button>
                        <template x-for="p in getPageNumbers()" :key="p">
                            <button class="pagination-btn" :class="{ 'active': p === page }" @click="goToPage(p)"
                                x-text="p"></button>
                        </template>
                        <button class="pagination-btn" @click="goToPage(page + 1)" :disabled="page >= totalPages" title="Next">
                            <i class="bi bi-chevron-right"></i>
                        </button>
                        <button class="pagination-btn" @click="goToPage(totalPages)" :disabled="page >= totalPages" title="Last">
                            <i class="bi bi-chevron-double-right"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Settings Modal (uses admin.css .modal-backdrop/.modal pattern) -->
        <div class="modal-backdrop" x-show="showSettings" x-cloak @click.self="showSettings = false"
             x-transition:enter="transition ease-out duration-200"
             x-transition:enter-start="opacity-0"
             x-transition:enter-end="opacity-100"
             x-transition:leave="transition ease-in duration-150"
             x-transition:leave-start="opacity-100"
             x-transition:leave-end="opacity-0">
            <div class="modal" @click.stop>
                <div class="modal-header">
                    <h2 class="modal-title">
                        <i class="bi bi-gear"></i> Cache Settings
                    </h2>
                    <button class="btn-icon" @click="showSettings = false">
                        <i class="bi bi-x-lg"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label class="form-label">Nginx FastCGI Cache Path</label>
                        <input type="text" class="form-control" x-model="settingsCachePath"
                               placeholder="/home/productreviewsorg/cache/fastcgi/"
                               style="font-family:monospace;">
                        <p style="font-size:11px;color:var(--text-muted);margin-top:6px;">
                            Directory where Nginx stores FastCGI cache files. Must be readable/writable by PHP.
                        </p>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" @click="showSettings = false">Cancel</button>
                    <button class="btn btn-primary" @click="saveSettings()">
                        <i class="bi bi-check-lg"></i> Save
                    </button>
                </div>
            </div>
        </div>

        <!-- Toast Notification -->
        <div class="toast-container" x-show="showToast" x-cloak
             x-transition:enter="transition ease-out duration-300"
             x-transition:enter-start="opacity-0 translate-y-4"
             x-transition:enter-end="opacity-100 translate-y-0"
             x-transition:leave="transition ease-in duration-200"
             x-transition:leave-start="opacity-100 translate-y-0"
             x-transition:leave-end="opacity-0 translate-y-4">
            <div class="toast" :class="'toast-' + toastType">
                <i class="bi" :class="toastType === 'success' ? 'bi-check-circle' : (toastType === 'info' ? 'bi-arrow-repeat animate-spin' : 'bi-exclamation-circle')"></i>
                <span x-text="toastMessage"></span>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('alpine:init', () => {
        Alpine.data('cachePage', () => ({
            // Data
            urls: [],
            stats: { total: 0, cached: 0, pending: 0, failed: 0, timeout: 0, skipped: 0 },
            byType: {},
            cacheFiles: 0,
            cacheSize: 'Files',
            isLoading: true,
            isRefreshing: false,
            isPreloading: false,
            isResuming: false,
            isCleaning: false,

            // Pagination
            page: 1,
            perPage: 50,
            totalPages: 1,
            totalItems: 0,

            // Filters & Sort
            searchQuery: '',
            filterStatus: '',
            filterType: '',
            orderby: 'priority',
            order: 'DESC',

            // Progress
            inProgress: false,
            progress: {},
            pollTimer: null,

            // Toast
            showToast: false,
            toastType: 'success',
            toastMessage: '',

            // Settings
            showSettings: false,
            settingsCachePath: '<?php echo esc_js(\AffiliateCMS\Pro\Core\CachePreload::getCachePath()); ?>',

            get progressPercent() {
                if (!this.progress.total || this.progress.total === 0) return 0;
                return Math.round((this.progress.preloaded / this.progress.total) * 100);
            },

            get progressColor() {
                const p = this.progressPercent;
                if (p < 25) return '#e67e22';
                if (p < 50) return '#f1c40f';
                if (p < 75) return '#3498db';
                return '#2ecc71';
            },

            init() {
                this.loadUrls();
                this.loadStatus();
            },

            destroy() {
                this.stopPoll();
            },

            // ─── Data Loading ─────────────────────────────

            async loadUrls() {
                this.isLoading = true;
                try {
                    const params = new URLSearchParams({
                        page: this.page,
                        per_page: this.perPage,
                        orderby: this.orderby,
                        order: this.order
                    });
                    if (this.filterStatus) params.set('status', this.filterStatus);
                    if (this.filterType) params.set('url_type', this.filterType);
                    if (this.searchQuery) params.set('search', this.searchQuery);

                    const resp = await this.api('cache/urls?' + params);
                    if (resp.success) {
                        this.urls = resp.data;
                        this.totalPages = resp.pages;
                        this.totalItems = resp.total;
                    }
                } catch (e) {
                    console.error('Failed to load URLs:', e);
                    this.toast('error', 'Failed to load URLs');
                } finally {
                    this.isLoading = false;
                }
            },

            async loadStatus() {
                try {
                    const resp = await this.api('cache/status');
                    if (resp.success) {
                        this.cacheFiles = resp.cache_files || 0;
                        this.cacheSize = resp.cache_size || '0 B';
                        this.stats = resp.url_stats || this.stats;
                        this.byType = resp.by_type || {};
                        this.inProgress = resp.in_progress || false;
                        this.progress = resp.progress || {};

                        if (this.inProgress && !this.pollTimer) {
                            this.startPoll();
                        } else if (!this.inProgress && this.pollTimer) {
                            this.stopPoll();
                        }
                    }
                } catch (e) {
                    console.error('Failed to load status:', e);
                }
            },

            async loadStats() {
                try {
                    const resp = await this.api('cache/urls/stats');
                    if (resp.success) {
                        const s = resp.by_status || {};
                        this.stats = {
                            total: resp.total || 0,
                            cached: s.cached || 0,
                            pending: s.pending || 0,
                            failed: s.failed || 0,
                            timeout: s.timeout || 0,
                            skipped: s.skipped || 0
                        };
                        this.byType = resp.by_type || {};
                    }
                } catch (e) {
                    console.error('Failed to load stats:', e);
                }
            },

            // ─── Actions ──────────────────────────────────

            async smartRefresh() {
                this.isPreloading = true;
                try {
                    const resp = await this.api('cache/smart-refresh', 'POST');
                    this.toast('success', 'Smart Refresh: ' + (resp.queued || 0) + ' URLs queued for refresh');
                    this.refreshAll();
                } catch (e) {
                    this.toast('error', 'Smart Refresh failed');
                } finally {
                    this.isPreloading = false;
                }
            },

            async resumeQueue() {
                this.isResuming = true;
                try {
                    const resp = await this.api('cache/resume-queue', 'POST');
                    this.toast(resp.resumed ? 'success' : 'info', resp.message);
                    this.refreshAll();
                } catch (e) {
                    this.toast('error', 'Resume queue failed');
                } finally {
                    this.isResuming = false;
                }
            },

            async cleanOrphans() {
                this.isCleaning = true;
                try {
                    const resp = await this.api('cache/clean-orphans', 'POST');
                    this.toast('success', resp.message);
                    this.refreshAll();
                } catch (e) {
                    this.toast('error', 'Clean orphans failed');
                } finally {
                    this.isCleaning = false;
                }
            },

            async fullPreload() {
                this.isPreloading = true;
                try {
                    await this.api('cache/preload', 'POST');
                    this.toast('success', 'Full preload started');
                    this.inProgress = true;
                    this.startPoll();
                    // Reload URLs after a short delay to show new queue
                    setTimeout(() => { this.loadUrls(); this.loadStats(); }, 2000);
                } catch (e) {
                    this.toast('error', 'Failed to start preload');
                } finally {
                    this.isPreloading = false;
                }
            },

            async stopPreload() {
                this.toast('info', 'Stopping preload...');
                try {
                    const resp = await this.api('cache/stop', 'POST');
                    this.toast('success', resp.message || 'Preload stopped');
                    this.inProgress = false;
                    this.stopPoll();
                    this.loadUrls();
                    this.loadStats();
                } catch (e) {
                    this.toast('error', 'Failed to stop preload');
                }
            },

            async purgeAll() {
                if (!confirm('Purge all cache files and reset all URLs to pending?')) return;
                this.toast('info', 'Purging cache...');
                try {
                    const resp = await this.api('cache/purge-all', 'POST');
                    this.toast('success', resp.message || 'Cache purged');
                    this.inProgress = false;
                    this.stopPoll();
                    this.refreshAll();
                } catch (e) {
                    this.toast('error', 'Purge failed');
                }
            },

            async flushRedis() {
                this.toast('info', 'Flushing object cache...');
                try {
                    const resp = await this.api('cache/flush-redis', 'POST');
                    this.toast('success', resp.message || 'Object cache flushed');
                } catch (e) {
                    this.toast('error', 'Flush failed');
                }
            },

            async resetFailed() {
                try {
                    const resp = await this.api('cache/urls/reset', 'POST');
                    this.toast('success', resp.message || 'Failed URLs reset');
                    this.loadUrls();
                    this.loadStats();
                } catch (e) {
                    this.toast('error', 'Reset failed');
                }
            },

            async syncFromDisk() {
                this.toast('info', 'Syncing DB with disk cache...');
                try {
                    const resp = await this.api('cache/sync', 'POST');
                    this.toast('success', resp.message || 'Sync complete');
                    this.refreshAll();
                } catch (e) {
                    this.toast('error', 'Sync failed');
                }
            },

            async purgeOneUrl(row) {
                try {
                    const resp = await fetch(acmsCacheConfig.restUrl + 'cache/purge-url', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-WP-Nonce': acmsCacheConfig.nonce
                        },
                        body: JSON.stringify({ url: row.url })
                    }).then(r => r.json());
                    row.status = 'pending';
                    row.http_code = null;
                    row.response_time_ms = null;
                    this.toast('success', resp.message || 'URL purged');
                    this.loadStats();
                } catch (e) {
                    this.toast('error', 'Purge failed');
                }
            },

            async saveSettings() {
                try {
                    const settingsResp = await fetch(acmsCacheConfig.restUrl + 'settings', {
                        method: 'GET',
                        headers: { 'X-WP-Nonce': acmsCacheConfig.nonce }
                    }).then(r => r.json());

                    const current = settingsResp.data?.general || {};
                    current.cache_path = this.settingsCachePath;

                    await fetch(acmsCacheConfig.restUrl + 'settings', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-WP-Nonce': acmsCacheConfig.nonce
                        },
                        body: JSON.stringify({ general: current })
                    });

                    this.showSettings = false;
                    this.toast('success', 'Settings saved');
                    this.loadStatus();
                } catch (e) {
                    this.toast('error', 'Failed to save settings');
                }
            },

            async refreshAll() {
                this.isRefreshing = true;
                try {
                    await Promise.all([this.loadUrls(), this.loadStatus(), this.loadStats()]);
                } finally {
                    this.isRefreshing = false;
                }
            },

            // ─── Polling ──────────────────────────────────

            startPoll() {
                this.stopPoll();
                this.pollTimer = setInterval(() => {
                    this.loadStatus();
                    // Also refresh the table periodically during preload
                    this.loadUrls();
                }, 5000);
            },

            stopPoll() {
                if (this.pollTimer) {
                    clearInterval(this.pollTimer);
                    this.pollTimer = null;
                }
            },

            // ─── Sorting ─────────────────────────────────

            toggleSort(column) {
                if (this.orderby === column) {
                    this.order = this.order === 'DESC' ? 'ASC' : 'DESC';
                } else {
                    this.orderby = column;
                    this.order = column === 'url' || column === 'url_type' || column === 'status' ? 'ASC' : 'DESC';
                }
                this.page = 1;
                this.loadUrls();
            },

            sortIcon(column) {
                if (this.orderby !== column) return 'bi-chevron-expand';
                return this.order === 'ASC' ? 'bi-chevron-up' : 'bi-chevron-down';
            },

            // ─── Pagination ──────────────────────────────

            goToPage(p) {
                if (p < 1 || p > this.totalPages) return;
                this.page = p;
                this.loadUrls();
            },

            getPageNumbers() {
                const pages = [];
                const total = this.totalPages;
                const current = this.page;
                let start = Math.max(1, current - 2);
                let end = Math.min(total, current + 2);

                if (end - start < 4) {
                    if (start === 1) end = Math.min(total, start + 4);
                    else start = Math.max(1, end - 4);
                }

                for (let i = start; i <= end; i++) pages.push(i);
                return pages;
            },

            // ─── Helpers ─────────────────────────────────

            async api(endpoint, method = 'GET') {
                const opts = {
                    method,
                    headers: { 'X-WP-Nonce': acmsCacheConfig.nonce }
                };
                const resp = await fetch(acmsCacheConfig.restUrl + endpoint, opts);
                return await resp.json();
            },

            formatNum(n) {
                return (n || 0).toLocaleString();
            },

            shortenUrl(url) {
                try {
                    const u = new URL(url);
                    return u.pathname + u.search;
                } catch {
                    return url;
                }
            },

            statusBadge(status) {
                const map = {
                    cached: 'badge-success',
                    pending: 'badge-warning',
                    failed: 'badge-danger',
                    timeout: 'badge-danger',
                    skipped: 'badge-muted'
                };
                return map[status] || 'badge-muted';
            },

            httpColor(code) {
                if (!code) return 'color:var(--text-muted)';
                if (code >= 200 && code < 300) return 'color:var(--success)';
                if (code >= 300 && code < 400) return 'color:var(--warning)';
                return 'color:var(--danger)';
            },

            shortDate(dateStr) {
                if (!dateStr) return '—';
                const d = new Date(dateStr + 'Z');
                const now = new Date();
                const diffMs = now - d;
                const diffMin = Math.floor(diffMs / 60000);

                if (diffMin < 1) return 'Just now';
                if (diffMin < 60) return diffMin + 'm ago';
                if (diffMin < 1440) return Math.floor(diffMin / 60) + 'h ago';
                return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
            },

            toast(type, message) {
                this.toastType = type;
                this.toastMessage = message;
                this.showToast = true;
                setTimeout(() => { this.showToast = false; }, 3000);
            }
        }));
    });
</script>
