<?php
/**
 * Brands Admin Page Template
 *
 * Uses shared admin.css styles (same as Products/Queue pages)
 *
 * @package AffiliateCMS\Pro
 */

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}
?>
<!-- Global Config -->
<script>
    window.acmsBrandsConfig = {
        restUrl: '<?php echo esc_js(rest_url('acms/v1/')); ?>',
        nonce: '<?php echo esc_js(wp_create_nonce('wp_rest')); ?>',
        stats: <?php echo wp_json_encode($stats); ?>,
        brandPageUrl: '<?php echo esc_js(home_url('/brand/')); ?>'
    };
</script>

<div id="acms-brands-app" class="acms-admin" x-data="brandsPage()">
    <div class="app-container">
        <!-- Page Header -->
        <header class="page-header">
            <div class="header-left">
                <div class="stats-inline">
                    <div class="stat-item total" title="Total brands">
                        <span class="stat-item-dot"></span>
                        <span class="stat-item-value" x-text="stats.total">0</span>
                        <span class="stat-item-label">Total</span>
                    </div>
                    <div class="stat-item scraped" title="Published brands">
                        <span class="stat-item-dot"></span>
                        <span class="stat-item-value" x-text="stats.published">0</span>
                        <span class="stat-item-label">Published</span>
                    </div>
                    <div class="stat-item pending" title="With AI content">
                        <span class="stat-item-dot"></span>
                        <span class="stat-item-value" x-text="stats.with_content">0</span>
                        <span class="stat-item-label">With AI</span>
                    </div>
                    <div class="stat-item failed" title="Empty content (needs AI)"
                        @click="filterContentStatus = 'empty'; page = 1; loadBrands()" style="cursor:pointer;">
                        <span class="stat-item-dot"></span>
                        <span class="stat-item-value" x-text="stats.empty_content">0</span>
                        <span class="stat-item-label">Empty</span>
                    </div>
                    <div class="stat-item" title="Total products">
                        <span class="stat-item-dot"></span>
                        <span class="stat-item-value" x-text="stats.total_products">0</span>
                        <span class="stat-item-label">Products</span>
                    </div>
                </div>
            </div>

            <div class="flex items-center gap-2">
                <button class="btn btn-secondary" @click="syncProducts()" :disabled="isSyncing"
                    title="Import brands from products">
                    <i class="bi" :class="isSyncing ? 'bi-arrow-repeat animate-spin' : 'bi-arrow-clockwise'"></i>
                    Sync
                </button>
                <button class="btn btn-secondary" @click="runAiNow()" :disabled="isRunningAi"
                    title="Manually trigger brand AI generation">
                    <i class="bi" :class="isRunningAi ? 'bi-arrow-repeat animate-spin' : 'bi-robot'"></i>
                    Run AI
                </button>
                <button class="btn btn-secondary" @click="openDebugModal()" title="Debug AI processing">
                    <i class="bi bi-bug"></i>
                </button>
                <button class="btn btn-secondary" @click="refreshData()" :disabled="isRefreshing" title="Refresh data">
                    <i class="bi" :class="isRefreshing ? 'bi-arrow-repeat animate-spin' : 'bi-arrow-repeat'"></i>
                </button>
                <button class="btn btn-primary" @click="openAddModal()">
                    <i class="bi bi-plus-lg"></i>
                    Add Brand
                </button>
            </div>
        </header>

        <!-- Toolbar -->
        <div class="toolbar">
            <!-- Left: Bulk Actions -->
            <div class="toolbar-section toolbar-left">
                <div class="dropdown" x-data="{ open: false }">
                    <button class="btn btn-secondary" @click="open = !open" :disabled="selectedIds.length === 0">
                        <i class="bi bi-grid-3x3-gap"></i>
                        Actions
                        <i class="bi bi-chevron-down" style="font-size:12px;margin-left:4px;"></i>
                    </button>
                    <div class="dropdown-menu" x-show="open" @click.outside="open = false" x-cloak>
                        <button class="dropdown-item"
                            @click="bulkAction = 'generate_ai'; showAiModal = true; open = false">
                            <i class="bi bi-robot"></i>
                            Generate AI Content
                        </button>
                        <button class="dropdown-item"
                            @click="bulkAction = 'regenerate_ai'; showAiModal = true; open = false">
                            <i class="bi bi-arrow-repeat"></i>
                            Regenerate AI Content
                        </button>
                        <div class="dropdown-divider"></div>
                        <button class="dropdown-item danger"
                            @click="bulkAction = 'delete'; confirmBulkDelete(); open = false">
                            <i class="bi bi-trash"></i>
                            Delete
                        </button>
                    </div>
                </div>

                <span class="selected-count" x-show="selectedIds.length > 0" x-cloak>
                    <span class="selected-count-number" x-text="selectedIds.length"></span>
                </span>
            </div>

            <!-- Center: Search -->
            <div class="toolbar-section toolbar-center">
                <form class="search-box" @submit.prevent>
                    <i class="bi bi-search search-icon"></i>
                    <input type="search" class="search-input" placeholder="Search brands..." x-model="searchQuery"
                        @input.debounce.300ms="page = 1; loadBrands()" autocomplete="off">
                    <button type="button" class="search-clear" x-show="searchQuery" x-cloak
                        @click="searchQuery = ''; page = 1; loadBrands()">
                        <i class="bi bi-x-lg"></i>
                    </button>
                </form>
            </div>

            <!-- Right: Filters & Per Page -->
            <div class="toolbar-section toolbar-right" style="gap:8px;">
                <select class="form-select form-select-sm" x-model="filterStatus" @change="page = 1; loadBrands()"
                    style="width:auto;min-width:90px;">
                    <option value="">All Status</option>
                    <option value="publish">Published</option>
                    <option value="draft">Draft</option>
                </select>
                <select class="form-select form-select-sm" x-model="filterContentStatus"
                    @change="page = 1; loadBrands()" style="width:auto;min-width:100px;">
                    <option value="">All Content</option>
                    <option value="empty">Empty</option>
                    <option value="ai_generating">Generating</option>
                    <option value="ai_generated">AI Generated</option>
                    <option value="manual">Manual</option>
                </select>
                <select class="form-select form-select-sm" x-model="perPage" @change="page = 1; loadBrands()"
                    style="width:auto;min-width:70px;">
                    <option value="20">20</option>
                    <option value="50">50</option>
                    <option value="100">100</option>
                </select>
            </div>
        </div>

        <!-- Loading State -->
        <div class="empty-state" x-show="isLoading">
            <i class="bi bi-arrow-repeat animate-spin" style="font-size:32px;"></i>
            <p>Loading brands...</p>
        </div>

        <!-- Empty State -->
        <div class="empty-state" x-show="!isLoading && brands.length === 0">
            <i class="bi bi-building" style="font-size:48px;opacity:0.5;"></i>
            <p>No brands found</p>
            <p class="text-muted" style="font-size:13px;margin-top:8px;">Click "Sync Products" to import brands from
                existing products.</p>
        </div>

        <!-- Brands Table -->
        <div class="data-table-wrapper" x-show="!isLoading && brands.length > 0">
            <table class="data-table">
                <thead>
                    <tr>
                        <th class="col-checkbox" style="width:40px;">
                            <label class="checkbox-wrapper">
                                <input type="checkbox" :checked="isAllSelected" @change="toggleSelectAll()">
                                <span class="checkbox-indicator"></span>
                            </label>
                        </th>
                        <th>Brand</th>
                        <th style="width:120px;text-align:center;">Products</th>
                        <th style="width:120px;text-align:center;">Status</th>
                        <th style="width:130px;text-align:center;">AI Content</th>
                        <th style="width:170px;text-align:right;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <template x-for="brand in brands" :key="brand.id">
                        <tr :class="{ 'row-selected': selectedIds.includes(parseInt(brand.id)) }">
                            <td class="col-checkbox">
                                <label class="checkbox-wrapper">
                                    <input type="checkbox" :checked="selectedIds.includes(parseInt(brand.id))"
                                        @change="toggleSelect(parseInt(brand.id))">
                                    <span class="checkbox-indicator"></span>
                                </label>
                            </td>
                            <td>
                                <div class="product-title-cell">
                                    <span class="product-title" x-text="brand.name"></span>
                                    <span class="text-muted" style="font-size:12px;" x-text="'/' + brand.slug"></span>
                                </div>
                            </td>
                            <td style="text-align:center;">
                                <span class="badge badge-muted" x-text="brand.product_count"></span>
                            </td>
                            <td style="text-align:center;">
                                <span class="badge"
                                    :class="brand.status === 'publish' ? 'badge-success' : 'badge-muted'"
                                    x-text="brand.status === 'publish' ? 'Published' : 'Draft'"></span>
                            </td>
                            <td style="text-align:center;">
                                <span class="badge" :class="getAiStatusClass(brand.content_status)"
                                    x-text="getAiStatusLabel(brand.content_status)"></span>
                            </td>
                            <td style="text-align:right;">
                                <div class="action-buttons">
                                    <button class="btn-icon btn-icon-sm" @click="generateAiForBrand(brand)"
                                        :disabled="brand.content_status === 'ai_generating'"
                                        :title="brand.content_status === 'ai_generating' ? 'AI is generating...' : (brand.content_status === 'ai_generated' ? 'Regenerate AI' : 'Generate AI')">
                                        <i class="bi"
                                            :class="brand.content_status === 'ai_generating' ? 'bi-arrow-repeat animate-spin' : 'bi-robot'"></i>
                                    </button>
                                    <a class="btn-icon btn-icon-sm" :href="getBrandUrl(brand)" target="_blank"
                                        title="View on site">
                                        <i class="bi bi-box-arrow-up-right"></i>
                                    </a>
                                    <button class="btn-icon btn-icon-sm" @click="openEditModal(brand)" title="Edit">
                                        <i class="bi bi-pencil"></i>
                                    </button>
                                    <button class="btn-icon btn-icon-sm" @click="deleteBrand(brand.id)" title="Delete">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    </template>
                </tbody>
            </table>

            <!-- Pagination -->
            <div class="data-table-pagination" x-show="totalPages > 1">
                <div class="pagination-info">
                    Page <span x-text="page"></span> of <span x-text="totalPages"></span>
                </div>
                <div class="pagination-controls">
                    <div class="pagination-buttons">
                        <button class="pagination-btn" @click="goToPage(1)" :disabled="page <= 1" title="First">
                            <i class="bi bi-chevron-double-left"></i>
                        </button>
                        <button class="pagination-btn" @click="goToPage(page - 1)" :disabled="page <= 1"
                            title="Previous">
                            <i class="bi bi-chevron-left"></i>
                        </button>
                        <template x-for="p in getPageNumbers()" :key="p">
                            <button class="pagination-btn" :class="{ 'active': p === page }" @click="goToPage(p)"
                                x-text="p"></button>
                        </template>
                        <button class="pagination-btn" @click="goToPage(page + 1)" :disabled="page >= totalPages"
                            title="Next">
                            <i class="bi bi-chevron-right"></i>
                        </button>
                        <button class="pagination-btn" @click="goToPage(totalPages)" :disabled="page >= totalPages"
                            title="Last">
                            <i class="bi bi-chevron-double-right"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Brand Modal (Simple) -->
    <div class="modal-backdrop" x-show="showAddModal" x-cloak @click.self="showAddModal = false"
        x-transition:enter="transition ease-out duration-200" x-transition:enter-start="opacity-0"
        x-transition:enter-end="opacity-100" x-transition:leave="transition ease-in duration-150"
        x-transition:leave-start="opacity-100" x-transition:leave-end="opacity-0">
        <div class="modal" @click.stop style="max-width:500px;">
            <div class="modal-header">
                <h2 class="modal-title">
                    <i class="bi bi-plus-circle"></i>
                    Add New Brand
                </h2>
                <button class="btn-icon btn-icon-sm" @click="showAddModal = false">
                    <i class="bi bi-x-lg"></i>
                </button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label class="form-label">Brand Name *</label>
                    <input type="text" class="form-input" x-model="addForm.name" placeholder="e.g., Apple"
                        @keydown.enter="createBrand()">
                </div>
                <div class="form-group">
                    <label class="form-label">Slug <span class="text-muted" style="font-weight:normal;">(auto-generated
                            if empty)</span></label>
                    <input type="text" class="form-input" x-model="addForm.slug" placeholder="apple">
                </div>
                <div class="form-group">
                    <label class="form-label">Website URL</label>
                    <input type="url" class="form-input" x-model="addForm.website_url" placeholder="https://...">
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" @click="showAddModal = false">Cancel</button>
                <button class="btn btn-primary" @click="createBrand()" :disabled="isSubmitting || !addForm.name.trim()">
                    <i class="bi" :class="isSubmitting ? 'bi-arrow-repeat animate-spin' : 'bi-check-lg'"></i>
                    Create Brand
                </button>
            </div>
        </div>
    </div>

    <!-- Edit Brand Modal -->
    <div class="modal-backdrop" x-show="showEditModal" x-cloak @click.self="closeEditModal()"
        x-transition:enter="transition ease-out duration-200" x-transition:enter-start="opacity-0"
        x-transition:enter-end="opacity-100" x-transition:leave="transition ease-in duration-150"
        x-transition:leave-start="opacity-100" x-transition:leave-end="opacity-0">
        <div class="modal modal-xl" @click.stop>
            <div class="modal-header">
                <div style="display:flex;align-items:center;gap:10px;">
                    <h2 class="modal-title">
                        <i class="bi bi-building"></i>
                        Edit Brand
                    </h2>
                    <div class="content-status-bar" :class="'status-' + (editForm.content_status || 'empty')"
                        style="margin:0;padding:6px 12px;font-size:12px;">
                        <i class="bi" style="font-size:12px;" :class="{
                            'bi-hourglass-split': editForm.content_status === 'ai_generating',
                            'bi-robot': editForm.content_status === 'ai_generated',
                            'bi-pencil': editForm.content_status === 'manual',
                            'bi-dash-circle': !editForm.content_status || editForm.content_status === 'empty'
                        }"></i>
                        <span x-text="getContentStatusText(editForm.content_status)"></span>
                    </div>
                </div>
                <button class="btn-icon btn-icon-sm" @click="closeEditModal()">
                    <i class="bi bi-x-lg"></i>
                </button>
            </div>

            <div class="modal-body" style="max-height:70vh;overflow-y:auto;">
                <!-- Basic Info: 3 columns -->
                <div class="form-row form-row-3">
                    <div class="form-group">
                        <label class="form-label">Brand Name *</label>
                        <input type="text" class="form-input" x-model="editForm.name">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Slug</label>
                        <input type="text" class="form-input" x-model="editForm.slug">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Website URL</label>
                        <input type="url" class="form-input" x-model="editForm.website_url" placeholder="https://...">
                    </div>
                </div>

                <div class="form-row form-row-3">
                    <div class="form-group">
                        <label class="form-label">Status</label>
                        <select class="form-input" x-model="editForm.status">
                            <option value="draft">Draft</option>
                            <option value="publish">Published</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Logo URL</label>
                        <input type="url" class="form-input" x-model="editForm.logo_url" placeholder="https://...">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Banner URL</label>
                        <input type="url" class="form-input" x-model="editForm.banner_url" placeholder="https://...">
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Description</label>
                    <textarea class="form-input" x-model="editForm.description" rows="2"
                        placeholder="Brief brand description..."></textarea>
                </div>

                <!-- Content -->
                <div class="form-section-title">Content</div>

                <div class="form-group">
                    <label class="form-label">Main Content</label>
                    <div class="wp-editor-wrapper" id="brand-editor-container">
                        <textarea id="brand_content_main" rows="16"></textarea>
                    </div>
                </div>

                <!-- SEO -->
                <div class="form-section-title">SEO</div>

                <div class="form-row" style="grid-template-columns:2fr 1fr;">
                    <div class="form-group">
                        <label class="form-label">
                            SEO Title
                            <span class="char-count" :class="{ 'warning': (editForm.seo_title || '').length > 60 }">
                                <span x-text="(editForm.seo_title || '').length"></span>/60
                            </span>
                        </label>
                        <input type="text" class="form-input" x-model="editForm.seo_title"
                            placeholder="Brand Name - Best Products & Reviews">
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">
                        SEO Description
                        <span class="char-count" :class="{ 'warning': (editForm.seo_description || '').length > 160 }">
                            <span x-text="(editForm.seo_description || '').length"></span>/160
                        </span>
                    </label>
                    <textarea class="form-input" x-model="editForm.seo_description" rows="2"
                        placeholder="Meta description for search engines..."></textarea>
                </div>

                <div class="form-info">
                    <i class="bi bi-info-circle"></i>
                    <span>Products: <strong x-text="editForm.product_count || 0"></strong> | Created: <span
                            x-text="formatDate(editForm.created_at)"></span></span>
                </div>
            </div>

            <div class="modal-footer">
                <button class="btn btn-secondary" @click="closeEditModal()">Cancel</button>
                <button class="btn btn-primary" @click="saveBrand()"
                    :disabled="isSubmitting || !(editForm.name || '').trim()">
                    <i class="bi" :class="isSubmitting ? 'bi-arrow-repeat animate-spin' : 'bi-check-lg'"></i>
                    <span x-text="isSubmitting ? 'Saving...' : 'Save Changes'"></span>
                </button>
            </div>
        </div>
    </div>

    <!-- AI Generation Modal -->
    <div class="modal-backdrop" x-show="showAiModal" x-cloak @click.self="showAiModal = false"
        x-transition:enter="transition ease-out duration-200" x-transition:enter-start="opacity-0"
        x-transition:enter-end="opacity-100">
        <div class="modal" @click.stop style="max-width:450px;">
            <div class="modal-header">
                <h2 class="modal-title"
                    x-text="bulkAction === 'generate_ai' ? 'Generate AI Content' : 'Regenerate AI Content'"></h2>
                <button class="btn-icon btn-icon-sm" @click="showAiModal = false">
                    <i class="bi bi-x-lg"></i>
                </button>
            </div>
            <div class="modal-body">
                <div class="info-box">
                    <i class="bi bi-info-circle"></i>
                    <span
                        x-text="bulkAction === 'generate_ai'
                        ? `Generate AI content for ${selectedIds.length} selected brand(s). Brands that already have content will be skipped.`
                        : `Regenerate AI content for ${selectedIds.length} selected brand(s). Existing content will be replaced.`"></span>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" @click="showAiModal = false">Cancel</button>
                <button class="btn btn-primary" @click="executeAiBulkAction()" :disabled="isBulkProcessing">
                    <i class="bi" :class="isBulkProcessing ? 'bi-arrow-repeat animate-spin' : 'bi-robot'"></i>
                    <span
                        x-text="isBulkProcessing ? 'Processing...' : (bulkAction === 'generate_ai' ? 'Generate' : 'Regenerate')"></span>
                </button>
            </div>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div class="modal-backdrop" x-show="showDeleteModal" x-cloak @click.self="showDeleteModal = false"
        x-transition:enter="transition ease-out duration-200" x-transition:enter-start="opacity-0"
        x-transition:enter-end="opacity-100">
        <div class="modal" @click.stop style="max-width:400px;">
            <div class="modal-header">
                <h2 class="modal-title">Confirm Delete</h2>
                <button class="btn-icon btn-icon-sm" @click="showDeleteModal = false">
                    <i class="bi bi-x-lg"></i>
                </button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete <strong x-text="selectedIds.length"></strong> brand(s)?</p>
                <p class="text-muted" style="font-size:13px;margin-top:8px;">This action cannot be undone.</p>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" @click="showDeleteModal = false">Cancel</button>
                <button class="btn btn-danger" @click="executeBulkDelete()" :disabled="isBulkProcessing">
                    <i class="bi" :class="isBulkProcessing ? 'bi-arrow-repeat animate-spin' : 'bi-trash'"></i>
                    Delete
                </button>
            </div>
        </div>
    </div>

    <!-- Debug AI Modal -->
    <div class="modal-backdrop" x-show="showDebugModal" x-cloak @click.self="showDebugModal = false"
        x-transition:enter="transition ease-out duration-200" x-transition:enter-start="opacity-0"
        x-transition:enter-end="opacity-100" x-transition:leave="transition ease-in duration-150"
        x-transition:leave-start="opacity-100" x-transition:leave-end="opacity-0">
        <div class="modal" @click.stop style="max-width:800px;max-height:85vh;overflow-y:auto;">
            <div class="modal-header">
                <h3 class="modal-title"><i class="bi bi-bug"></i> Brand AI Debug</h3>
                <button class="btn-icon btn-icon-sm" @click="showDebugModal = false">
                    <i class="bi bi-x-lg"></i>
                </button>
            </div>
            <div class="modal-body" style="padding:16px;">
                <template x-if="debugLoading">
                    <div style="text-align:center;padding:40px;color:var(--text-muted);">
                        <i class="bi bi-arrow-repeat animate-spin" style="font-size:24px;"></i>
                        <p style="margin-top:8px;">Loading debug info...</p>
                    </div>
                </template>
                <template x-if="!debugLoading && debugData">
                    <div style="display:flex;flex-direction:column;gap:16px;">

                        <!-- Config Check -->
                        <div class="debug-section">
                            <h4 class="debug-section-title">API Config</h4>
                            <div class="debug-grid">
                                <div class="debug-item">
                                    <span class="debug-label">API Key</span>
                                    <span class="debug-value"
                                        :class="debugData.config?.api_key_set ? 'text-success' : 'text-error'">
                                        <i class="bi"
                                            :class="debugData.config?.api_key_set ? 'bi-check-circle' : 'bi-x-circle'"></i>
                                        <span x-text="debugData.config?.api_key_set ? 'Set' : 'NOT SET'"></span>
                                    </span>
                                </div>
                                <div class="debug-item">
                                    <span class="debug-label">Model</span>
                                    <span class="debug-value" x-text="debugData.config?.model || '-'"></span>
                                </div>
                                <div class="debug-item">
                                    <span class="debug-label">Brand AI</span>
                                    <span class="debug-value"
                                        :class="debugData.config?.brand_ai_enabled ? 'text-success' : 'text-error'">
                                        <span
                                            x-text="debugData.config?.brand_ai_enabled ? 'Enabled' : 'Disabled'"></span>
                                    </span>
                                </div>
                            </div>
                        </div>

                        <!-- Queue Status -->
                        <div class="debug-section">
                            <h4 class="debug-section-title">
                                AS Queue
                                <span class="debug-badge"
                                    :class="debugData.queue_blocked ? 'debug-badge-error' : 'debug-badge-success'"
                                    x-text="debugData.queue_blocked ? 'BLOCKED' : 'OK'"></span>
                            </h4>
                            <template x-if="debugData.queue_blocked && debugData.blocking_actions">
                                <div style="margin-bottom:8px;">
                                    <div class="debug-alert debug-alert-error">
                                        <i class="bi bi-exclamation-triangle"></i>
                                        Queue blocked by in-progress action(s):
                                        <template x-for="a in debugData.blocking_actions" :key="a.action_id">
                                            <div style="margin-top:4px;font-size:12px;">
                                                #<span x-text="a.action_id"></span>
                                                <strong x-text="a.hook"></strong>
                                                - stuck <span x-text="a.minutes_stuck"></span> min
                                            </div>
                                        </template>
                                    </div>
                                </div>
                            </template>
                            <div class="debug-grid">
                                <div class="debug-item">
                                    <span class="debug-label">In Progress</span>
                                    <span class="debug-value"
                                        :class="debugData.in_progress_count > 0 ? 'text-warning' : ''"
                                        x-text="debugData.in_progress_count || 0"></span>
                                </div>
                            </div>
                        </div>

                        <!-- Brand Stats -->
                        <div class="debug-section">
                            <h4 class="debug-section-title">Brand Content Stats</h4>
                            <div class="debug-grid">
                                <div class="debug-item">
                                    <span class="debug-label">Empty</span>
                                    <span class="debug-value" x-text="debugData.brand_stats?.empty || 0"></span>
                                </div>
                                <div class="debug-item">
                                    <span class="debug-label">Generating</span>
                                    <span class="debug-value"
                                        :class="(debugData.brand_stats?.ai_generating || 0) > 0 ? 'text-warning' : ''"
                                        x-text="debugData.brand_stats?.ai_generating || 0"></span>
                                </div>
                                <div class="debug-item">
                                    <span class="debug-label">Generated</span>
                                    <span class="debug-value text-success"
                                        x-text="debugData.brand_stats?.ai_generated || 0"></span>
                                </div>
                                <div class="debug-item">
                                    <span class="debug-label">With 3+ Products</span>
                                    <span class="debug-value"
                                        x-text="debugData.brand_stats?.with_products_gte3 || 0"></span>
                                </div>
                            </div>
                        </div>

                        <!-- Job Stats -->
                        <div class="debug-section" x-show="debugData.job_stats">
                            <h4 class="debug-section-title">AI Jobs (generate_seo_brand)</h4>
                            <div class="debug-grid">
                                <div class="debug-item">
                                    <span class="debug-label">Pending</span>
                                    <span class="debug-value" x-text="debugData.job_stats?.pending || 0"></span>
                                </div>
                                <div class="debug-item">
                                    <span class="debug-label">Processing</span>
                                    <span class="debug-value"
                                        :class="(debugData.job_stats?.processing || 0) > 0 ? 'text-warning' : ''"
                                        x-text="debugData.job_stats?.processing || 0"></span>
                                </div>
                                <div class="debug-item">
                                    <span class="debug-label">Completed</span>
                                    <span class="debug-value text-success"
                                        x-text="debugData.job_stats?.completed || 0"></span>
                                </div>
                                <div class="debug-item">
                                    <span class="debug-label">Failed</span>
                                    <span class="debug-value"
                                        :class="(debugData.job_stats?.failed || 0) > 0 ? 'text-error' : ''"
                                        x-text="debugData.job_stats?.failed || 0"></span>
                                </div>
                            </div>
                        </div>

                        <!-- Stuck Brands -->
                        <div class="debug-section" x-show="debugData.stuck_brands?.length > 0">
                            <h4 class="debug-section-title">
                                <i class="bi bi-exclamation-triangle" style="color:var(--warning);"></i>
                                Stuck Brands (ai_generating)
                            </h4>
                            <div class="debug-table-wrap">
                                <table class="debug-table">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Name</th>
                                            <th>Since</th>
                                            <th>Error</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <template x-for="b in debugData.stuck_brands" :key="b.id">
                                            <tr>
                                                <td x-text="b.id"></td>
                                                <td x-text="b.name"></td>
                                                <td x-text="b.ai_generating_at || '-'"></td>
                                                <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;"
                                                    x-text="b.ai_error_message || '-'"></td>
                                            </tr>
                                        </template>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <!-- Recent Jobs -->
                        <div class="debug-section" x-show="debugData.recent_jobs?.length > 0">
                            <h4 class="debug-section-title">Recent Jobs</h4>
                            <div class="debug-table-wrap">
                                <table class="debug-table">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Brand</th>
                                            <th>Status</th>
                                            <th>Created</th>
                                            <th>Duration</th>
                                            <th>Error</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <template x-for="j in debugData.recent_jobs" :key="j.id">
                                            <tr
                                                :class="j.status === 'failed' ? 'row-error' : (j.status === 'processing' ? 'row-warning' : '')">
                                                <td x-text="j.id"></td>
                                                <td x-text="j.target_id"></td>
                                                <td>
                                                    <span class="debug-status" :class="'debug-status-' + j.status"
                                                        x-text="j.status"></span>
                                                </td>
                                                <td style="font-size:11px;white-space:nowrap;"
                                                    x-text="j.created_at?.substring(5) || '-'"></td>
                                                <td
                                                    x-text="j.processing_seconds ? (j.status === 'processing' ? j.processing_seconds + 's (running)' : '-') : '-'">
                                                </td>
                                                <td style="max-width:180px;overflow:hidden;text-overflow:ellipsis;font-size:11px;color:var(--error);"
                                                    x-text="j.error_message || ''"></td>
                                            </tr>
                                        </template>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <!-- Diagnostics -->
                        <div class="debug-section" x-show="debugData.diagnostics">
                            <h4 class="debug-section-title">Diagnostics</h4>
                            <div class="debug-grid">
                                <div class="debug-item">
                                    <span class="debug-label">Jobs Table</span>
                                    <span class="debug-value"
                                        :class="debugData.diagnostics?.job_table_writable ? 'text-success' : 'text-error'">
                                        <i class="bi"
                                            :class="debugData.diagnostics?.job_table_writable ? 'bi-check-circle' : 'bi-x-circle'"></i>
                                        <span
                                            x-text="debugData.diagnostics?.job_table_writable ? 'Writable' : 'FAIL'"></span>
                                    </span>
                                </div>
                                <div class="debug-item">
                                    <span class="debug-label">API Connection</span>
                                    <span class="debug-value"
                                        :class="debugData.diagnostics?.api_connection ? 'text-success' : 'text-error'">
                                        <i class="bi"
                                            :class="debugData.diagnostics?.api_connection ? 'bi-check-circle' : 'bi-x-circle'"></i>
                                        <span x-text="debugData.diagnostics?.api_connection ? 'OK' : 'FAIL'"></span>
                                    </span>
                                </div>
                            </div>
                            <template x-if="debugData.diagnostics?.job_table_error">
                                <div class="debug-alert debug-alert-error" style="margin-top:8px;">
                                    <strong>Table Error:</strong> <span
                                        x-text="debugData.diagnostics.job_table_error"></span>
                                </div>
                            </template>
                            <template x-if="debugData.diagnostics?.api_error">
                                <div class="debug-alert debug-alert-error" style="margin-top:8px;">
                                    <strong>API Error:</strong> <span x-text="debugData.diagnostics.api_error"></span>
                                    <template x-if="debugData.diagnostics?.api_http_code">
                                        <span> (HTTP <span x-text="debugData.diagnostics.api_http_code"></span>)</span>
                                    </template>
                                </div>
                            </template>
                        </div>

                        <!-- Recent Error Logs -->
                        <div class="debug-section" x-show="debugData.diagnostics?.recent_logs?.length > 0">
                            <h4 class="debug-section-title">Recent Logs (BrandAiCron)</h4>
                            <div
                                style="max-height:200px;overflow-y:auto;background:var(--bg-base);border-radius:var(--radius-sm);padding:8px 12px;">
                                <template x-for="(log, i) in debugData.diagnostics?.recent_logs || []" :key="i">
                                    <div style="font-family:monospace;font-size:11px;color:var(--text-muted);padding:2px 0;border-bottom:1px solid var(--border);word-break:break-all;white-space:pre-wrap;"
                                        :class="log.includes('FAIL') || log.includes('ERROR') || log.includes('EXCEPTION') ? 'text-error' : ''"
                                        x-text="log"></div>
                                </template>
                            </div>
                        </div>
                        <div class="debug-section" x-show="!debugData.diagnostics?.recent_logs?.length">
                            <h4 class="debug-section-title">Recent Logs</h4>
                            <p style="color:var(--text-muted);font-size:13px;margin:0;">No recent BrandAiCron logs
                                found. Click "Run AI" to trigger and check again.</p>
                        </div>

                    </div>
                </template>
            </div>
            <div class="modal-footer" style="display:flex;gap:8px;">
                <button class="btn btn-danger" @click="resetStuckBrands()" :disabled="isResetting"
                    title="Reset all stuck generating brands, jobs and AS actions">
                    <i class="bi"
                        :class="isResetting ? 'bi-arrow-repeat animate-spin' : 'bi-arrow-counterclockwise'"></i>
                    Reset Stuck
                </button>
                <button class="btn btn-secondary" @click="openDebugModal()" title="Refresh debug data">
                    <i class="bi bi-arrow-clockwise"></i>
                    Refresh
                </button>
                <div style="flex:1;"></div>
                <button class="btn btn-secondary" @click="showDebugModal = false">Close</button>
            </div>
        </div>
    </div>

    <!-- Toast Notification -->
    <div class="toast-container" x-show="showToast" x-cloak x-transition:enter="transition ease-out duration-300"
        x-transition:enter-start="opacity-0 transform translate-y-2"
        x-transition:enter-end="opacity-100 transform translate-y-0"
        x-transition:leave="transition ease-in duration-200" x-transition:leave-start="opacity-100"
        x-transition:leave-end="opacity-0">
        <div class="toast" :class="'toast-' + toastType">
            <i class="bi" :class="toastType === 'success' ? 'bi-check-circle' : 'bi-exclamation-circle'"></i>
            <span x-text="toastMessage"></span>
        </div>
    </div>
</div>

<script>
    document.addEventListener('alpine:init', () => {
        Alpine.data('brandsPage', () => ({
            // Data
            brands: [],
            stats: acmsBrandsConfig.stats || {},
            isLoading: true,
            page: 1,
            perPage: 50,
            totalPages: 1,
            totalItems: 0,
            searchQuery: '',

            // Filters
            filterStatus: '',
            filterContentStatus: '',

            // Selection
            selectedIds: [],
            bulkAction: '',
            isBulkProcessing: false,

            // Modals
            showAddModal: false,
            showEditModal: false,
            showAiModal: false,
            showDeleteModal: false,
            isSubmitting: false,
            isSyncing: false,
            isRunningAi: false,
            isRefreshing: false,
            showDebugModal: false,
            debugData: null,
            debugLoading: false,
            isResetting: false,

            // Toast
            showToast: false,
            toastType: 'success',
            toastMessage: '',

            // Forms
            addForm: {
                name: '',
                slug: '',
                website_url: ''
            },
            editForm: {},

            get isAllSelected() {
                return this.brands.length > 0 && this.brands.every(b => this.selectedIds.includes(parseInt(b.id)));
            },

            init() {
                this.loadBrands();
            },

            async loadBrands() {
                this.isLoading = true;
                try {
                    const params = new URLSearchParams({
                        page: this.page,
                        per_page: this.perPage,
                        search: this.searchQuery,
                        orderby: 'name',
                        order: 'ASC'
                    });
                    if (this.filterStatus) params.set('status', this.filterStatus);
                    if (this.filterContentStatus) params.set('content_status', this.filterContentStatus);

                    const response = await fetch(acmsBrandsConfig.restUrl + 'brands?' + params, {
                        headers: { 'X-WP-Nonce': acmsBrandsConfig.nonce }
                    });
                    const result = await response.json();

                    if (result.success) {
                        this.brands = result.data.items;
                        this.totalPages = result.data.total_pages;
                        this.totalItems = result.data.total;
                    }
                    // Refresh stats alongside brands
                    this.loadStats();
                } catch (error) {
                    console.error('Failed to load brands:', error);
                    this.toast('error', 'Failed to load brands');
                } finally {
                    this.isLoading = false;
                }
            },

            async loadStats() {
                try {
                    const response = await fetch(acmsBrandsConfig.restUrl + 'brands/stats', {
                        headers: { 'X-WP-Nonce': acmsBrandsConfig.nonce }
                    });
                    const result = await response.json();
                    if (result.success) {
                        this.stats = result.data;
                    }
                } catch (error) { }
            },

            // Pagination
            goToPage(p) {
                if (p < 1 || p > this.totalPages || p === this.page) return;
                this.page = p;
                this.loadBrands();
                document.getElementById('acms-brands-app').scrollIntoView({ behavior: 'smooth', block: 'start' });
            },

            getPageNumbers() {
                const pages = [];
                const maxVisible = 5;
                let start = Math.max(1, this.page - Math.floor(maxVisible / 2));
                let end = Math.min(this.totalPages, start + maxVisible - 1);
                if (end - start < maxVisible - 1) {
                    start = Math.max(1, end - maxVisible + 1);
                }
                for (let i = start; i <= end; i++) {
                    pages.push(i);
                }
                return pages;
            },

            // Selection
            toggleSelect(id) {
                const idx = this.selectedIds.indexOf(id);
                if (idx > -1) {
                    this.selectedIds.splice(idx, 1);
                } else {
                    this.selectedIds.push(id);
                }
            },

            toggleSelectAll() {
                if (this.isAllSelected) {
                    this.selectedIds = [];
                } else {
                    this.selectedIds = this.brands.map(b => parseInt(b.id));
                }
            },

            // Sync products
            async syncProducts() {
                this.isSyncing = true;
                try {
                    const response = await fetch(acmsBrandsConfig.restUrl + 'brands/sync-products', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-WP-Nonce': acmsBrandsConfig.nonce
                        }
                    });
                    const result = await response.json();

                    if (result.success) {
                        this.toast('success', result.message);
                        this.loadBrands();
                        this.loadStats();
                    } else {
                        throw new Error(result.message || 'Sync failed');
                    }
                } catch (error) {
                    this.toast('error', error.message);
                } finally {
                    this.isSyncing = false;
                }
            },

            // Run AI Now (manual trigger - processes synchronously on server)
            async runAiNow() {
                this.isRunningAi = true;
                this.toast('success', 'Processing brands with AI... This may take a minute.');
                try {
                    const controller = new AbortController();
                    const timeoutId = setTimeout(() => controller.abort(), 300000); // 5 min timeout

                    const response = await fetch(acmsBrandsConfig.restUrl + 'brands/run-ai', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-WP-Nonce': acmsBrandsConfig.nonce
                        },
                        signal: controller.signal
                    });
                    clearTimeout(timeoutId);
                    const result = await response.json();

                    if (result.success) {
                        this.toast('success', result.message);
                        this.loadBrands();
                        this.loadStats();
                    } else {
                        throw new Error(result.message || 'Run AI failed');
                    }
                } catch (error) {
                    if (error.name === 'AbortError') {
                        this.toast('error', 'Request timed out. Check debug.log for details.');
                    } else {
                        this.toast('error', error.message);
                    }
                    this.loadBrands();
                } finally {
                    this.isRunningAi = false;
                }
            },

            // Refresh data without page reload
            async refreshData() {
                this.isRefreshing = true;
                await Promise.all([this.loadBrands(), this.loadStats()]);
                this.isRefreshing = false;
            },

            // Add Modal
            openAddModal() {
                this.addForm = { name: '', slug: '', website_url: '' };
                this.showAddModal = true;
            },

            async createBrand() {
                if (!this.addForm.name.trim()) return;

                this.isSubmitting = true;
                try {
                    const response = await fetch(acmsBrandsConfig.restUrl + 'brands', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-WP-Nonce': acmsBrandsConfig.nonce
                        },
                        body: JSON.stringify(this.addForm)
                    });
                    const result = await response.json();

                    if (result.success) {
                        this.toast('success', 'Brand created');
                        this.showAddModal = false;
                        this.loadBrands();
                        this.loadStats();
                    } else {
                        throw new Error(result.message || 'Create failed');
                    }
                } catch (error) {
                    this.toast('error', error.message);
                } finally {
                    this.isSubmitting = false;
                }
            },

            // TinyMCE editor management
            initBrandEditor(content) {
                const editorId = 'brand_content_main';

                // Destroy previous instance if exists
                this.destroyBrandEditor();

                // Ensure textarea exists (wp.editor.remove deletes it)
                const container = document.getElementById('brand-editor-container');
                let textarea = document.getElementById(editorId);
                if (!textarea && container) {
                    textarea = document.createElement('textarea');
                    textarea.id = editorId;
                    textarea.rows = 16;
                    container.appendChild(textarea);
                }
                if (textarea) textarea.value = content || '';

                // Wait for DOM then init
                this.$nextTick(() => {
                    if (typeof wp === 'undefined' || typeof wp.editor === 'undefined') {
                        return; // fallback to plain textarea
                    }
                    wp.editor.initialize(editorId, {
                        tinymce: {
                            wpautop: true,
                            plugins: 'charmap,colorpicker,hr,lists,media,paste,tabfocus,textcolor,fullscreen,wordpress,wplink,wptextpattern',
                            toolbar1: 'formatselect,bold,italic,bullist,numlist,blockquote,alignleft,aligncenter,alignright,link,fullscreen,wp_adv',
                            toolbar2: 'strikethrough,hr,forecolor,pastetext,removeformat,charmap,outdent,indent,undo,redo',
                            content_style: 'body{background:#0a0a0b!important;color:#fafafa!important;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;font-size:14px;line-height:1.6;padding:16px}a{color:#3b82f6}h1,h2,h3,h4,h5,h6{color:#fafafa}blockquote{border-left:3px solid #3b82f6;margin-left:0;padding-left:16px;color:#a1a1aa}',
                            height: 380,
                            setup: (editor) => {
                                editor.on('init', () => {
                                    if (editor.getBody()) {
                                        editor.getBody().style.background = '#0a0a0b';
                                        editor.getBody().style.color = '#fafafa';
                                    }
                                    container.classList.add('acms-editor-ready');
                                    // Fix: @click.stop on modal blocks document-level switchEditors handler
                                    // Bind direct click handlers on Visual/Text tabs
                                    const wrap = document.getElementById('wp-' + editorId + '-wrap');
                                    if (wrap) {
                                        wrap.querySelectorAll('.wp-switch-editor').forEach(btn => {
                                            btn.addEventListener('click', (e) => {
                                                e.preventDefault();
                                                const mode = btn.classList.contains('switch-tmce') ? 'tmce' : 'html';
                                                switchEditors.go(editorId, mode);
                                            });
                                        });
                                    }
                                });
                            }
                        },
                        quicktags: true,
                        mediaButtons: false
                    });

                });
            },

            destroyBrandEditor() {
                const editorId = 'brand_content_main';
                if (typeof tinymce !== 'undefined' && tinymce.get(editorId)) {
                    wp.editor.remove(editorId);
                }
            },

            syncBrandEditorContent() {
                const editorId = 'brand_content_main';
                const wrap = document.getElementById('wp-' + editorId + '-wrap');
                const isTextMode = wrap && wrap.classList.contains('html-active');

                if (!isTextMode && typeof tinymce !== 'undefined') {
                    const editor = tinymce.get(editorId);
                    if (editor) {
                        this.editForm.content_main = editor.getContent();
                        return;
                    }
                }
                // Text/HTML mode — read from textarea
                const textarea = document.getElementById(editorId);
                if (textarea) {
                    this.editForm.content_main = textarea.value;
                }
            },

            // Edit Modal
            openEditModal(brand) {
                this.editForm = { ...brand };
                this.showEditModal = true;
                this.initBrandEditor(brand.content_main || '');
            },

            closeEditModal() {
                this.destroyBrandEditor();
                this.showEditModal = false;
            },

            async saveBrand() {
                if (!this.editForm.name.trim()) return;

                // Sync TinyMCE content to Alpine data
                this.syncBrandEditorContent();

                this.isSubmitting = true;
                try {
                    const payload = {
                        name: this.editForm.name,
                        slug: this.editForm.slug,
                        description: this.editForm.description,
                        website_url: this.editForm.website_url,
                        logo_url: this.editForm.logo_url,
                        banner_url: this.editForm.banner_url,
                        status: this.editForm.status,
                        seo_title: this.editForm.seo_title,
                        seo_description: this.editForm.seo_description,
                        content_main: this.editForm.content_main,
                    };

                    const response = await fetch(acmsBrandsConfig.restUrl + 'brands/' + this.editForm.id, {
                        method: 'PUT',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-WP-Nonce': acmsBrandsConfig.nonce
                        },
                        body: JSON.stringify(payload)
                    });
                    const result = await response.json();

                    if (result.success) {
                        this.toast('success', 'Brand updated');
                        this.closeEditModal();
                        this.loadBrands();
                        this.loadStats();
                    } else {
                        throw new Error(result.message || 'Save failed');
                    }
                } catch (error) {
                    this.toast('error', error.message);
                } finally {
                    this.isSubmitting = false;
                }
            },

            async deleteBrand(id) {
                if (!confirm('Delete this brand?')) return;

                try {
                    const response = await fetch(acmsBrandsConfig.restUrl + 'brands/' + id, {
                        method: 'DELETE',
                        headers: { 'X-WP-Nonce': acmsBrandsConfig.nonce }
                    });
                    const result = await response.json();

                    if (result.success) {
                        this.toast('success', 'Brand deleted');
                        this.loadBrands();
                        this.loadStats();
                    }
                } catch (error) {
                    this.toast('error', 'Delete failed');
                }
            },

            // Single brand AI generation (processes synchronously)
            async generateAiForBrand(brand) {
                const action = brand.content_status === 'ai_generated' ? 'regenerate' : 'generate';
                const brandId = parseInt(brand.id);

                // Optimistic UI update
                brand.content_status = 'ai_generating';
                this.toast('success', `Generating AI content for "${brand.name}"...`);

                try {
                    const controller = new AbortController();
                    const timeoutId = setTimeout(() => controller.abort(), 300000); // 5 min

                    const response = await fetch(acmsBrandsConfig.restUrl + 'brands/bulk-ai', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-WP-Nonce': acmsBrandsConfig.nonce
                        },
                        body: JSON.stringify({
                            action: action,
                            brand_ids: [brandId]
                        }),
                        signal: controller.signal
                    });
                    clearTimeout(timeoutId);
                    const result = await response.json();

                    if (result.success) {
                        this.toast('success', result.message);
                        this.loadBrands();
                        this.loadStats();
                    } else {
                        brand.content_status = 'empty';
                        throw new Error(result.message || 'Failed');
                    }
                } catch (error) {
                    brand.content_status = 'empty';
                    if (error.name === 'AbortError') {
                        this.toast('error', 'Request timed out.');
                    } else {
                        this.toast('error', error.message);
                    }
                    this.loadBrands();
                }
            },

            // Bulk actions
            confirmBulkDelete() {
                if (this.selectedIds.length === 0) return;
                this.showDeleteModal = true;
            },

            async executeBulkDelete() {
                this.isBulkProcessing = true;
                let deleted = 0;

                try {
                    for (const id of this.selectedIds) {
                        const response = await fetch(acmsBrandsConfig.restUrl + 'brands/' + id, {
                            method: 'DELETE',
                            headers: { 'X-WP-Nonce': acmsBrandsConfig.nonce }
                        });
                        if ((await response.json()).success) deleted++;
                    }

                    this.toast('success', `${deleted} brand(s) deleted`);
                    this.selectedIds = [];
                    this.showDeleteModal = false;
                    this.loadBrands();
                    this.loadStats();
                } catch (error) {
                    this.toast('error', 'Bulk delete failed');
                } finally {
                    this.isBulkProcessing = false;
                }
            },

            async executeAiBulkAction() {
                if (this.selectedIds.length === 0) return;

                // Limit check (synced with backend)
                if (this.selectedIds.length > 10) {
                    this.toast('error', 'Maximum 10 brands per batch. Please select fewer brands.');
                    return;
                }

                this.isBulkProcessing = true;
                this.toast('success', `Processing ${this.selectedIds.length} brand(s) with AI... This may take a few minutes.`);

                try {
                    const controller = new AbortController();
                    const timeoutId = setTimeout(() => controller.abort(), 300000); // 5 min timeout

                    const response = await fetch(acmsBrandsConfig.restUrl + 'brands/bulk-ai', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-WP-Nonce': acmsBrandsConfig.nonce
                        },
                        body: JSON.stringify({
                            action: this.bulkAction === 'regenerate_ai' ? 'regenerate' : 'generate',
                            brand_ids: this.selectedIds
                        }),
                        signal: controller.signal
                    });
                    clearTimeout(timeoutId);
                    const result = await response.json();

                    if (result.success) {
                        this.toast('success', result.message);
                        this.showAiModal = false;
                        this.selectedIds = [];
                        this.loadBrands();
                        this.loadStats();
                    } else {
                        throw new Error(result.message || 'AI generation failed');
                    }
                } catch (error) {
                    if (error.name === 'AbortError') {
                        this.toast('error', 'Request timed out. Check debug.log for details.');
                    } else {
                        this.toast('error', error.message);
                    }
                    this.loadBrands();
                } finally {
                    this.isBulkProcessing = false;
                }
            },

            // Helpers
            getBrandUrl(brand) {
                return acmsBrandsConfig.brandPageUrl + brand.slug + '/';
            },

            getAiStatusClass(status) {
                const classes = {
                    'empty': 'badge-muted',
                    'ai_generating': 'badge-warning',
                    'ai_generated': 'badge-success',
                    'manual': 'badge-success',
                    'template': 'badge-info'
                };
                return classes[status] || 'badge-muted';
            },

            getAiStatusLabel(status) {
                const labels = {
                    'empty': 'Empty',
                    'ai_generating': 'Generating...',
                    'ai_generated': 'AI Generated',
                    'manual': 'Manual',
                    'template': 'Template'
                };
                return labels[status] || status || 'Empty';
            },

            getContentStatusText(status) {
                const texts = {
                    'empty': 'No content yet',
                    'ai_generating': 'AI is generating content...',
                    'ai_generated': 'Content generated by AI',
                    'manual': 'Manually edited content',
                    'template': 'Using template'
                };
                return texts[status] || 'No content';
            },

            formatDate(dateStr) {
                if (!dateStr) return '-';
                const date = new Date(dateStr);
                return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
            },

            // Debug AI Modal
            async openDebugModal() {
                this.showDebugModal = true;
                this.debugLoading = true;
                try {
                    const response = await fetch(acmsBrandsConfig.restUrl + 'brands/debug-ai', {
                        headers: { 'X-WP-Nonce': acmsBrandsConfig.nonce }
                    });
                    const result = await response.json();
                    if (result.success) {
                        this.debugData = result.data;
                    } else {
                        this.toast('error', 'Failed to load debug info');
                    }
                } catch (error) {
                    this.toast('error', error.message);
                } finally {
                    this.debugLoading = false;
                }
            },

            async resetStuckBrands() {
                this.isResetting = true;
                try {
                    const response = await fetch(acmsBrandsConfig.restUrl + 'brands/reset-stuck', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-WP-Nonce': acmsBrandsConfig.nonce
                        }
                    });
                    const result = await response.json();
                    if (result.success) {
                        this.toast('success', result.message);
                        this.openDebugModal(); // Refresh debug data
                        this.loadBrands();
                        this.loadStats();
                    } else {
                        throw new Error(result.message || 'Reset failed');
                    }
                } catch (error) {
                    this.toast('error', error.message);
                } finally {
                    this.isResetting = false;
                }
            },

            toast(type, message) {
                this.toastType = type;
                this.toastMessage = message;
                this.showToast = true;
                setTimeout(() => { this.showToast = false; }, 4000);
            }
        }));
    });
</script>

<style>
    /* Brands-specific styles */
    #acms-brands-app .info-box {
        display: flex;
        align-items: flex-start;
        gap: 12px;
        padding: 14px 16px;
        background: var(--info-light);
        border: 1px solid rgba(59, 130, 246, 0.2);
        border-radius: var(--radius-md);
        color: var(--text-secondary);
        font-size: 14px;
    }

    #acms-brands-app .info-box i {
        color: var(--info);
        font-size: 18px;
        flex-shrink: 0;
    }

    #acms-brands-app .btn-danger {
        background: var(--error);
        color: white;
        border-color: var(--error);
    }

    #acms-brands-app .btn-danger:hover {
        background: #dc2626;
        border-color: #dc2626;
    }

    /* Wider modal for Edit Brand */
    #acms-brands-app .modal-xl {
        max-width: 900px;
    }

    /* Form improvements */
    #acms-brands-app .form-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 16px;
        margin-bottom: 16px;
    }

    #acms-brands-app .form-row-3 {
        grid-template-columns: 1fr 1fr 1fr;
    }

    #acms-brands-app .form-section-title {
        font-weight: 600;
        font-size: 13px;
        color: var(--text-secondary);
        text-transform: uppercase;
        letter-spacing: 0.5px;
        margin: 24px 0 12px;
        padding-bottom: 8px;
        border-bottom: 1px solid var(--border);
    }

    #acms-brands-app .form-info {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 12px 14px;
        background: var(--bg-elevated);
        border-radius: var(--radius-md);
        font-size: 13px;
        color: var(--text-secondary);
        margin-top: 16px;
    }

    #acms-brands-app .form-info i {
        color: var(--text-muted);
    }

    #acms-brands-app .form-hint {
        font-size: 12px;
        color: var(--text-muted);
        margin-top: 4px;
    }

    #acms-brands-app .char-count {
        font-size: 11px;
        color: var(--text-muted);
        font-weight: normal;
        margin-left: 8px;
    }

    #acms-brands-app .char-count.warning {
        color: var(--warning);
    }

    /* Content status bar */
    #acms-brands-app .content-status-bar {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 10px 14px;
        border-radius: var(--radius-md);
        font-size: 13px;
        margin-bottom: 20px;
    }

    #acms-brands-app .content-status-bar.status-empty {
        background: var(--bg-elevated);
        color: var(--text-muted);
    }

    #acms-brands-app .content-status-bar.status-ai_generating {
        background: rgba(251, 191, 36, 0.1);
        color: var(--warning);
    }

    #acms-brands-app .content-status-bar.status-ai_generated {
        background: rgba(34, 197, 94, 0.1);
        color: var(--success);
    }

    #acms-brands-app .content-status-bar.status-manual {
        background: rgba(59, 130, 246, 0.1);
        color: var(--primary);
    }

    #acms-brands-app .content-status-bar .status-date {
        margin-left: auto;
        font-size: 12px;
        opacity: 0.8;
    }

    /* Content editor */
    #acms-brands-app .content-editor {
        font-family: 'SF Mono', 'Monaco', 'Inconsolata', monospace;
        font-size: 13px;
        line-height: 1.5;
    }

    /* WordPress TinyMCE Editor - Dark Mode */
    #acms-brands-app .wp-editor-wrapper {
        display: block !important;
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        overflow: visible;
    }

    #acms-brands-app .wp-editor-wrapper>textarea {
        width: 100%;
        min-height: 400px;
        padding: 16px;
        font-size: 14px;
        font-family: inherit;
        background: var(--bg-base);
        color: var(--text-primary);
        border: none;
        resize: vertical;
    }

    #acms-brands-app .wp-editor-wrapper .wp-editor-wrap {
        display: block !important;
    }

    /* WP Editor tabs (Visual/Text) - dark mode */
    #acms-brands-app .wp-editor-wrapper .wp-switch-editor {
        background: var(--bg-surface) !important;
        border-color: var(--border) !important;
        color: var(--text-muted) !important;
        font-size: 13px !important;
        height: auto !important;
        line-height: 1.4 !important;
        padding: 6px 14px !important;
    }

    #acms-brands-app .wp-editor-wrapper .wp-switch-editor:hover {
        color: var(--text-secondary) !important;
    }

    #acms-brands-app .wp-editor-wrapper .wp-switch-editor.switch-tmce.active,
    #acms-brands-app .wp-editor-wrapper .wp-switch-editor.switch-html.active,
    #acms-brands-app .wp-editor-wrapper .html-active .switch-html,
    #acms-brands-app .wp-editor-wrapper .tmce-active .switch-tmce {
        background: var(--bg-elevated) !important;
        border-bottom-color: var(--bg-elevated) !important;
        color: var(--text-primary) !important;
    }

    #acms-brands-app .wp-editor-wrapper .wp-editor-tools {
        background: var(--bg-surface) !important;
        border-bottom: 1px solid var(--border) !important;
        padding: 0 !important;
    }

    #acms-brands-app .wp-editor-wrapper .wp-media-buttons {
        display: none !important;
    }

    #acms-brands-app .wp-editor-wrapper .wp-editor-container {
        display: block !important;
        width: 100% !important;
        border: none !important;
        background: var(--bg-elevated) !important;
    }

    #acms-brands-app .wp-editor-wrapper .mce-tinymce {
        border: none !important;
        box-shadow: none !important;
    }

    #acms-brands-app .wp-editor-wrapper .mce-panel {
        background: var(--bg-surface) !important;
        border-color: var(--border) !important;
    }

    /* Toolbar */
    #acms-brands-app .wp-editor-wrapper .mce-toolbar-grp {
        background: var(--bg-elevated) !important;
        border-bottom: 1px solid var(--border) !important;
        padding: 8px 12px !important;
        text-align: center !important;
    }

    #acms-brands-app .wp-editor-wrapper .mce-toolbar-grp .mce-stack-layout {
        display: flex !important;
        flex-direction: column !important;
        align-items: center !important;
    }

    #acms-brands-app .wp-editor-wrapper .mce-toolbar-grp .mce-stack-layout-item {
        text-align: center !important;
        float: none !important;
        display: flex !important;
        justify-content: center !important;
    }

    #acms-brands-app .wp-editor-wrapper .mce-toolbar-grp .mce-toolbar {
        display: inline-flex !important;
        float: none !important;
    }

    #acms-brands-app .wp-editor-wrapper .mce-toolbar-grp .mce-toolbar[style*="display: none"] {
        display: none !important;
    }

    #acms-brands-app .wp-editor-wrapper .mce-toolbar-grp .mce-flow-layout {
        display: flex !important;
        flex-wrap: wrap !important;
        justify-content: center !important;
    }

    #acms-brands-app .wp-editor-wrapper .mce-toolbar-grp .mce-flow-layout-item {
        float: none !important;
    }

    /* Toolbar Buttons */
    #acms-brands-app .wp-editor-wrapper .mce-edit-area {
        border-top: none !important;
    }

    #acms-brands-app .wp-editor-wrapper .mce-btn,
    #acms-brands-app .wp-editor-wrapper .mce-btn button {
        background: transparent !important;
        border-color: transparent !important;
        color: var(--text-secondary) !important;
    }

    #acms-brands-app .wp-editor-wrapper .mce-btn:hover,
    #acms-brands-app .wp-editor-wrapper .mce-btn.mce-active {
        background: var(--bg-hover) !important;
        border-color: var(--border) !important;
        color: var(--text-primary) !important;
    }

    #acms-brands-app .wp-editor-wrapper .mce-btn i,
    #acms-brands-app .wp-editor-wrapper .mce-ico {
        color: var(--text-secondary) !important;
    }

    #acms-brands-app .wp-editor-wrapper .mce-btn:hover i,
    #acms-brands-app .wp-editor-wrapper .mce-btn.mce-active i,
    #acms-brands-app .wp-editor-wrapper .mce-btn:hover .mce-ico,
    #acms-brands-app .wp-editor-wrapper .mce-btn.mce-active .mce-ico {
        color: var(--text-primary) !important;
    }

    #acms-brands-app .wp-editor-wrapper .mce-menubtn.mce-fixed-width span {
        color: var(--text-secondary) !important;
    }

    #acms-brands-app .wp-editor-wrapper .mce-edit-area iframe {
        background: var(--bg-base) !important;
    }

    /* Quicktags toolbar (Code mode) */
    #acms-brands-app .wp-editor-wrapper .quicktags-toolbar {
        background: var(--bg-elevated) !important;
        border: none !important;
        border-bottom: 1px solid var(--border) !important;
        padding: 8px 12px !important;
        text-align: center !important;
    }

    #acms-brands-app .wp-editor-wrapper .quicktags-toolbar .ed_button,
    #acms-brands-app .wp-editor-wrapper .quicktags-toolbar>input.ed_button {
        float: none !important;
        display: inline-block !important;
    }

    #acms-brands-app .wp-editor-wrapper .ed_button {
        background: var(--bg-surface) !important;
        border: 1px solid var(--border) !important;
        color: var(--text-secondary) !important;
        padding: 4px 10px !important;
        border-radius: var(--radius-sm) !important;
        font-size: 12px !important;
        height: auto !important;
        line-height: 1.4 !important;
    }

    #acms-brands-app .wp-editor-wrapper .ed_button:hover {
        background: var(--bg-hover) !important;
        color: var(--text-primary) !important;
        border-color: var(--border-hover) !important;
    }

    #acms-brands-app .wp-editor-wrapper .ed_button:focus {
        outline: none !important;
        box-shadow: none !important;
    }

    #acms-brands-app .wp-editor-wrapper textarea.wp-editor-area {
        background: var(--bg-base) !important;
        color: var(--text-primary) !important;
        border: none !important;
        font-family: 'SF Mono', Monaco, Consolas, monospace !important;
        font-size: 13px !important;
        padding: 16px !important;
    }

    /* Status bar */
    #acms-brands-app .wp-editor-wrapper .mce-statusbar {
        background: var(--bg-elevated) !important;
        border-top: 1px solid var(--border) !important;
    }

    #acms-brands-app .wp-editor-wrapper .mce-path,
    #acms-brands-app .wp-editor-wrapper .mce-path-item {
        color: var(--text-muted) !important;
    }

    #acms-brands-app .wp-editor-wrapper .mce-wordcount {
        color: var(--text-muted) !important;
    }

    /* TinyMCE Floating Panels & Menus (rendered outside wrapper - global scope) */
    .mce-floatpanel,
    .mce-menu,
    .mce-popover {
        background: #18181b !important;
        border: 1px solid #27272a !important;
        box-shadow: 0 10px 40px rgba(0, 0, 0, 0.5) !important;
    }

    .mce-menu-item {
        background: transparent !important;
        color: #fafafa !important;
    }

    .mce-menu-item:hover,
    .mce-menu-item.mce-selected,
    .mce-menu-item:focus {
        background: #1f1f23 !important;
        color: #fafafa !important;
    }

    .mce-menu-item .mce-text {
        color: #fafafa !important;
    }

    .mce-menu-item .mce-ico {
        color: #a1a1aa !important;
    }

    .mce-menu-item:hover .mce-text,
    .mce-menu-item:hover .mce-ico {
        color: #fafafa !important;
    }

    .mce-menu-item-sep,
    .mce-menu .mce-menu-item-sep {
        background: #27272a !important;
        border: none !important;
    }

    .mce-listbox,
    .mce-menubtn {
        background: #111113 !important;
        border-color: #27272a !important;
    }

    .mce-listbox button,
    .mce-menubtn button {
        color: #a1a1aa !important;
    }

    .mce-listbox:hover,
    .mce-menubtn:hover {
        background: #1f1f23 !important;
        border-color: #3f3f46 !important;
    }

    .mce-listbox:hover button,
    .mce-menubtn:hover button {
        color: #fafafa !important;
    }

    .mce-open {
        border-left-color: #27272a !important;
    }

    .mce-caret {
        border-top-color: #a1a1aa !important;
    }

    .mce-panel {
        background: #111113 !important;
        border-color: #27272a !important;
    }

    .mce-toolbar-grp {
        background: #18181b !important;
        border-bottom: 1px solid #27272a !important;
    }

    .mce-btn {
        background: transparent !important;
        border-color: transparent !important;
    }

    .mce-btn button {
        color: #a1a1aa !important;
    }

    .mce-btn:hover,
    .mce-btn.mce-active {
        background: #1f1f23 !important;
        border-color: #27272a !important;
    }

    .mce-btn:hover button,
    .mce-btn.mce-active button {
        color: #fafafa !important;
    }

    .mce-ico {
        color: #a1a1aa !important;
    }

    .mce-btn:hover .mce-ico,
    .mce-btn.mce-active .mce-ico {
        color: #fafafa !important;
    }

    .mce-menu .mce-menu-item-preview {
        color: #fafafa !important;
    }

    .mce-colorbutton-grid {
        background: #18181b !important;
        border-color: #27272a !important;
    }

    /* Link dialog */
    .mce-window {
        background: #18181b !important;
        border: 1px solid #27272a !important;
        box-shadow: 0 10px 40px rgba(0, 0, 0, 0.5) !important;
    }

    .mce-window-head {
        background: #111113 !important;
        border-bottom: 1px solid #27272a !important;
    }

    .mce-window-head .mce-title {
        color: #fafafa !important;
    }

    .mce-window-body {
        background: #18181b !important;
    }

    .mce-textbox {
        background: #0a0a0b !important;
        border-color: #27272a !important;
        color: #fafafa !important;
    }

    .mce-label {
        color: #a1a1aa !important;
        text-shadow: none !important;
    }

    .mce-foot {
        background: #111113 !important;
        border-top: 1px solid #27272a !important;
    }

    .mce-primary {
        background: #2271b1 !important;
        border-color: #2271b1 !important;
    }

    .mce-primary button {
        color: #fff !important;
    }

    .mce-close {
        color: #a1a1aa !important;
    }

    .mce-close:hover {
        color: #fafafa !important;
    }

    /* Toast */
    #acms-brands-app .toast-container {
        position: fixed;
        bottom: 24px;
        right: 24px;
        z-index: 10001;
    }

    #acms-brands-app .toast {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 12px 20px;
        background: var(--bg-elevated);
        border-radius: var(--radius-md);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        font-size: 14px;
    }

    #acms-brands-app .toast-success {
        border-left: 3px solid var(--success);
    }

    #acms-brands-app .toast-success i {
        color: var(--success);
    }

    #acms-brands-app .toast-error {
        border-left: 3px solid var(--error);
    }

    #acms-brands-app .toast-error i {
        color: var(--error);
    }

    /* Debug Modal */
    #acms-brands-app .debug-section {
        background: var(--bg-elevated);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        padding: 12px 16px;
    }

    #acms-brands-app .debug-section-title {
        font-size: 13px;
        font-weight: 600;
        color: var(--text-primary);
        margin: 0 0 10px 0;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    #acms-brands-app .debug-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
        gap: 8px;
    }

    #acms-brands-app .debug-item {
        display: flex;
        flex-direction: column;
        gap: 2px;
    }

    #acms-brands-app .debug-label {
        font-size: 11px;
        color: var(--text-muted);
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    #acms-brands-app .debug-value {
        font-size: 14px;
        font-weight: 600;
        color: var(--text-primary);
        display: flex;
        align-items: center;
        gap: 4px;
    }

    #acms-brands-app .debug-badge {
        font-size: 10px;
        font-weight: 700;
        padding: 2px 8px;
        border-radius: 10px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    #acms-brands-app .debug-badge-success {
        background: rgba(34, 197, 94, 0.15);
        color: var(--success);
    }

    #acms-brands-app .debug-badge-error {
        background: rgba(239, 68, 68, 0.15);
        color: var(--error);
    }

    #acms-brands-app .debug-alert {
        padding: 10px 14px;
        border-radius: var(--radius-sm);
        font-size: 13px;
        display: flex;
        flex-direction: column;
        gap: 2px;
    }

    #acms-brands-app .debug-alert i {
        margin-right: 4px;
    }

    #acms-brands-app .debug-alert-error {
        background: rgba(239, 68, 68, 0.1);
        border: 1px solid rgba(239, 68, 68, 0.2);
        color: var(--error);
    }

    #acms-brands-app .debug-table-wrap {
        overflow-x: auto;
    }

    #acms-brands-app .debug-table {
        width: 100%;
        font-size: 12px;
        border-collapse: collapse;
    }

    #acms-brands-app .debug-table th {
        text-align: left;
        padding: 6px 8px;
        color: var(--text-muted);
        font-weight: 600;
        border-bottom: 1px solid var(--border);
        font-size: 11px;
        text-transform: uppercase;
    }

    #acms-brands-app .debug-table td {
        padding: 6px 8px;
        color: var(--text-secondary);
        border-bottom: 1px solid var(--border);
        white-space: nowrap;
    }

    #acms-brands-app .debug-table .row-error td {
        background: rgba(239, 68, 68, 0.05);
    }

    #acms-brands-app .debug-table .row-warning td {
        background: rgba(245, 158, 11, 0.05);
    }

    #acms-brands-app .debug-status {
        display: inline-block;
        padding: 2px 8px;
        border-radius: 10px;
        font-size: 11px;
        font-weight: 600;
    }

    #acms-brands-app .debug-status-pending {
        background: rgba(245, 158, 11, 0.15);
        color: var(--warning);
    }

    #acms-brands-app .debug-status-processing {
        background: rgba(59, 130, 246, 0.15);
        color: var(--info);
    }

    #acms-brands-app .debug-status-completed {
        background: rgba(34, 197, 94, 0.15);
        color: var(--success);
    }

    #acms-brands-app .debug-status-failed {
        background: rgba(239, 68, 68, 0.15);
        color: var(--error);
    }

    #acms-brands-app .text-success {
        color: var(--success) !important;
    }

    #acms-brands-app .text-error {
        color: var(--error) !important;
    }

    #acms-brands-app .text-warning {
        color: var(--warning) !important;
    }

    #acms-brands-app .btn-danger {
        background: var(--error);
        color: #fff;
        border: none;
    }

    #acms-brands-app .btn-danger:hover {
        background: #dc2626;
    }
</style>