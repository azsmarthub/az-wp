<?php
/**
 * Queue Admin Page Template
 *
 * @package AffiliateCMS\Pro
 */

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}
?>
<!-- Global Config (must be before Alpine.js runs) -->
<script>
// Store postTypes in a separate variable (acmsConfig.postTypes gets overwritten by admin.js)
window._acmsPostTypes = <?php echo wp_json_encode($postTypes ?? []); ?>;

window.acmsConfig = {
    restUrl: '<?php echo esc_js(rest_url('acms/v1/')); ?>',
    nonce: '<?php echo esc_js(wp_create_nonce('wp_rest')); ?>',
    pluginUrl: '<?php echo esc_js(ACMS_PLUGIN_URL); ?>',
    postTypes: <?php echo wp_json_encode($postTypes ?? []); ?>,
    i18n: {
        success: '<?php echo esc_js(__('Success', 'affiliatecms-pro')); ?>',
        error: '<?php echo esc_js(__('Error', 'affiliatecms-pro')); ?>',
        confirm_delete: '<?php echo esc_js(__('Are you sure you want to delete?', 'affiliatecms-pro')); ?>',
        no_results: '<?php echo esc_js(__('No results found', 'affiliatecms-pro')); ?>'
    }
};
</script>

<div id="acms-queue-app" class="acms-admin" x-data="queuePage()"
     @selection-changed.window="selectedCount = $event.detail.count; selectedItems = $event.detail.items"
     @filtered-count-changed.window="filteredCount = $event.detail.count; hasFilters = $event.detail.hasFilters; totalItems = $event.detail.total">
    <div class="app-container">
        <!-- Page Header with Stats -->
        <header class="page-header">
            <!-- Left: Stats -->
            <div class="header-left">
                <!-- Queue Stats -->
                <div class="stats-inline">
                    <div class="stat-item total" title="Total keywords">
                        <span class="stat-item-dot"></span>
                        <span class="stat-item-value" x-text="stats.total">0</span>
                        <span class="stat-item-label">Total</span>
                    </div>
                    <div class="stat-item pending" title="Pending keywords">
                        <span class="stat-item-dot"></span>
                        <span class="stat-item-value" x-text="stats.pending">0</span>
                        <span class="stat-item-label">Pending</span>
                    </div>
                    <div class="stat-item processing" title="Processing keywords">
                        <span class="stat-item-dot"></span>
                        <span class="stat-item-value" x-text="stats.processing">0</span>
                        <span class="stat-item-label">Processing</span>
                    </div>
                    <div class="stat-item scraped" title="Completed keywords">
                        <span class="stat-item-dot"></span>
                        <span class="stat-item-value" x-text="stats.completed">0</span>
                        <span class="stat-item-label">Completed</span>
                    </div>
                    <div class="stat-item failed" title="Failed keywords">
                        <span class="stat-item-dot"></span>
                        <span class="stat-item-value" x-text="stats.failed">0</span>
                        <span class="stat-item-label">Failed</span>
                    </div>
                </div>
            </div>

            <!-- Header Actions -->
            <div class="flex items-center gap-2">
                <a href="<?php echo esc_url(admin_url('admin.php?page=acms-pro')); ?>" class="btn-icon tooltip" data-tooltip="Products">
                    <i class="bi bi-box-seam"></i>
                </a>

                <div class="header-divider"></div>

                <button class="btn btn-secondary" @click="showTemplateModal = true" title="Content Templates">
                    <i class="bi bi-file-earmark-code"></i>
                    Templates
                </button>

                <button class="btn btn-primary" @click="showAddModal = true">
                    <i class="bi bi-plus-lg"></i>
                    Add Keywords
                </button>
            </div>
        </header>

        <!-- Toolbar -->
        <div class="toolbar">
            <!-- Left: Actions -->
            <div class="toolbar-section toolbar-left">
                <!-- Bulk Actions Dropdown -->
                <div class="dropdown" x-data="{ open: false }">
                    <button class="btn btn-secondary" @click="open = !open" :disabled="selectedCount === 0">
                        <i class="bi bi-grid-3x3-gap"></i>
                        Actions
                        <i class="bi bi-chevron-down" style="font-size:12px;margin-left:4px;"></i>
                    </button>
                    <div class="dropdown-menu" x-show="open" @click.outside="open = false" x-cloak>
                        <button class="dropdown-item" @click="bulkProcess(); open = false">
                            <i class="bi bi-play-fill"></i>
                            Process
                        </button>
                        <button class="dropdown-item" @click="bulkPause(); open = false">
                            <i class="bi bi-pause-fill"></i>
                            Pause
                        </button>
                        <button class="dropdown-item" @click="bulkReset(); open = false">
                            <i class="bi bi-arrow-counterclockwise"></i>
                            Reset
                        </button>
                        <div class="dropdown-divider"></div>
                        <button class="dropdown-item danger" @click="openDeleteModal(); open = false">
                            <i class="bi bi-trash"></i>
                            Delete
                        </button>
                    </div>
                </div>

                <!-- Selected Count -->
                <span class="selected-count" x-show="selectedCount > 0" x-cloak>
                    <span class="selected-count-number" x-text="selectedCount"></span>
                </span>
            </div>

            <!-- Center: Search -->
            <div class="toolbar-section toolbar-center">
                <form class="search-box" autocomplete="off" @submit.prevent>
                    <input type="text" name="prevent_autofill" value="" style="display:none;" tabindex="-1" autocomplete="new-password">
                    <i class="bi bi-search search-icon"></i>
                    <input type="search" class="search-input" placeholder="Search keywords..."
                           x-model="searchQuery" @input.debounce.300ms="$dispatch('update-search', { query: searchQuery })"
                           autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false"
                           data-lpignore="true" data-form-type="other" data-1p-ignore="true" aria-label="Search keywords">
                    <button type="button" class="search-clear" x-show="searchQuery" x-cloak @click="searchQuery = ''; $dispatch('update-search', { query: '' })">
                        <i class="bi bi-x-lg"></i>
                    </button>
                </form>
            </div>

            <!-- Right: Filters & View -->
            <div class="toolbar-section toolbar-right">
                <!-- Filtered Count -->
                <span class="filtered-count" x-show="hasFilters" x-cloak>
                    <span class="filtered-count-number" x-text="filteredCount"></span>
                </span>

                <!-- Filter Button with Dropdown -->
                <div class="dropdown" @click.outside="filterDropdownOpen = false">
                    <button class="btn-icon" :class="{ 'active': hasFilters, 'filter-active': hasFilters }" @click="filterDropdownOpen = !filterDropdownOpen" title="Filters">
                        <i class="bi" :class="hasFilters ? 'bi-funnel-fill' : 'bi-funnel'"></i>
                    </button>
                    <div class="dropdown-menu right" style="min-width: 260px; padding: 16px;" x-show="filterDropdownOpen" x-cloak>
                        <!-- Status Filter -->
                        <div class="form-group" x-data="{ statusOpen: false }">
                            <label class="form-label">Status</label>
                            <div class="custom-select" @click.outside="statusOpen = false">
                                <button type="button" class="custom-select-trigger" :class="{ 'open': statusOpen }" @click="statusOpen = !statusOpen">
                                    <span class="custom-select-value" x-text="getStatusLabel(filters.status)"></span>
                                    <i class="bi bi-chevron-down"></i>
                                </button>
                                <div class="custom-select-dropdown" x-show="statusOpen" x-cloak x-transition @click.stop>
                                    <button type="button" class="custom-select-option" :class="{ 'selected': filters.status === '' }" @click="filters.status = ''; statusOpen = false">All Status</button>
                                    <button type="button" class="custom-select-option" :class="{ 'selected': filters.status === 'pending' }" @click="filters.status = 'pending'; statusOpen = false">Pending</button>
                                    <button type="button" class="custom-select-option" :class="{ 'selected': filters.status === 'processing' }" @click="filters.status = 'processing'; statusOpen = false">Processing</button>
                                    <button type="button" class="custom-select-option" :class="{ 'selected': filters.status === 'completed' }" @click="filters.status = 'completed'; statusOpen = false">Completed</button>
                                    <button type="button" class="custom-select-option" :class="{ 'selected': filters.status === 'failed' }" @click="filters.status = 'failed'; statusOpen = false">Failed</button>
                                    <button type="button" class="custom-select-option" :class="{ 'selected': filters.status === 'paused' }" @click="filters.status = 'paused'; statusOpen = false">Paused</button>
                                </div>
                            </div>
                        </div>

                        <!-- Post Type Filter -->
                        <div class="form-group" x-data="{ typeOpen: false }" x-show="postTypes.length > 0">
                            <label class="form-label">Post Type</label>
                            <div class="custom-select" @click.outside="typeOpen = false">
                                <button type="button" class="custom-select-trigger" :class="{ 'open': typeOpen }" @click="typeOpen = !typeOpen">
                                    <span class="custom-select-value" x-text="getPostTypeLabel(filters.post_type)"></span>
                                    <i class="bi bi-chevron-down"></i>
                                </button>
                                <div class="custom-select-dropdown" x-show="typeOpen" x-cloak x-transition @click.stop>
                                    <button type="button" class="custom-select-option" :class="{ 'selected': filters.post_type === '' }" @click="filters.post_type = ''; typeOpen = false">All Types</button>
                                    <template x-for="pt in postTypes" :key="pt.value">
                                        <button type="button" class="custom-select-option" :class="{ 'selected': filters.post_type === pt.value }" @click="filters.post_type = pt.value; typeOpen = false" x-text="pt.label"></button>
                                    </template>
                                </div>
                            </div>
                        </div>

                        <!-- Filter Actions -->
                        <div style="display: flex; gap: 8px; margin-top: 12px;">
                            <button class="btn btn-secondary" style="flex: 1;" @click="clearFilters()">
                                <i class="bi bi-x-lg"></i>
                                Clear
                            </button>
                            <button class="btn btn-primary" style="flex: 1;" @click="applyFilters()">
                                <i class="bi bi-check2"></i>
                                Apply
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Refresh -->
                <button class="btn-icon" :class="{ 'refresh-success': refreshSuccess }" @click="refreshQueue()" title="Refresh">
                    <i class="bi" :class="{ 'bi-arrow-clockwise': !refreshSuccess, 'animate-spin': isRefreshing, 'bi-check-lg': refreshSuccess }"></i>
                </button>
            </div>
        </div>

        <!-- Queue Table -->
        <div class="data-table-wrapper" x-data="queueTable()" x-init="init()">
            <!-- Loading State -->
            <div class="data-table-loading" x-show="isLoading" x-cloak>
                <div class="spinner"></div>
                <span>Loading keywords...</span>
            </div>

            <!-- Empty State -->
            <div class="data-table-empty" x-show="!isLoading && items.length === 0" x-cloak>
                <i class="bi bi-inbox"></i>
                <span>No keywords found</span>
                <small>Click "Add Keywords" to add your first keyword</small>
            </div>

            <!-- Table -->
            <div class="data-table-container" x-show="!isLoading && items.length > 0">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th class="col-checkbox">
                                <input type="checkbox" @change="toggleSelectAll($event.target.checked)"
                                       :checked="selectedIds.length > 0 && selectedIds.length === items.length"
                                       :indeterminate="selectedIds.length > 0 && selectedIds.length < items.length">
                            </th>
                            <th class="col-keyword sortable" :class="{ 'sorted': sortColumn === 'keyword', 'desc': sortColumn === 'keyword' && sortDirection === 'desc' }" @click="sortBy('keyword')">
                                <span>Keyword</span>
                                <i class="bi bi-chevron-expand sort-icon"></i>
                            </th>
                            <th class="col-category">Category</th>
                            <th class="col-asins">ASINs</th>
                            <th class="col-post-type">Post Type</th>
                            <th class="col-template">Template</th>
                            <th class="col-status sortable" :class="{ 'sorted': sortColumn === 'status', 'desc': sortColumn === 'status' && sortDirection === 'desc' }" @click="sortBy('status')">
                                <span>Status</span>
                                <i class="bi bi-chevron-expand sort-icon"></i>
                            </th>
                            <th class="col-ai" title="AI Content Generation Status">AI</th>
                            <th class="col-index">Index</th>
                            <th class="col-date sortable" :class="{ 'sorted': sortColumn === 'created_at', 'desc': sortColumn === 'created_at' && sortDirection === 'desc' }" @click="sortBy('created_at')">
                                <span>Created</span>
                                <i class="bi bi-chevron-expand sort-icon"></i>
                            </th>
                            <th class="col-actions">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <template x-for="item in items" :key="item.id">
                            <tr :class="{ 'selected': selectedIds.includes(item.id) }">
                                <td class="col-checkbox">
                                    <input type="checkbox" :value="item.id" :checked="selectedIds.includes(item.id)" @change="toggleSelect(item.id)">
                                </td>
                                <td class="col-keyword">
                                    <div class="keyword-cell">
                                        <div class="keyword-row">
                                            <template x-if="item.generated_post_id">
                                                <a :href="getEditPostUrl(item.generated_post_id)"
                                                   class="keyword-text keyword-link"
                                                   :title="'Edit post: ' + item.keyword"
                                                   x-text="item.keyword"
                                                   @click.stop></a>
                                            </template>
                                            <template x-if="!item.generated_post_id">
                                                <span class="keyword-text" :title="item.keyword" x-text="item.keyword"></span>
                                            </template>
                                            <!-- Post status dot -->
                                            <span class="post-status-dot"
                                                  :class="{
                                                      'status-published': item.post_status === 'publish',
                                                      'status-draft': item.post_status === 'draft',
                                                      'status-pending': item.post_status === 'pending',
                                                      'status-other': item.post_status && !['publish', 'draft', 'pending'].includes(item.post_status)
                                                  }"
                                                  x-show="item.post_status"
                                                  :title="item.post_status === 'publish' ? 'Published' : (item.post_status || '').charAt(0).toUpperCase() + (item.post_status || '').slice(1)"></span>
                                            <button type="button" class="copy-btn" @click.stop="copyToClipboard(item.keyword)" title="Copy keyword">
                                                <i class="bi bi-clipboard"></i>
                                            </button>
                                        </div>
                                        <!-- Post slug/view link when completed -->
                                        <div class="keyword-post-link" x-show="item.generated_post_id">
                                            <a :href="getViewPostUrl(item.generated_post_id)"
                                               target="_blank"
                                               class="post-slug-link"
                                               :title="'View post'"
                                               @click.stop>
                                                <i class="bi bi-box-arrow-up-right"></i>
                                                <span x-text="getPostSlug(item)"></span>
                                            </a>
                                        </div>
                                    </div>
                                </td>
                                <td class="col-category">
                                    <span class="category-tag" x-show="item.category_id">
                                        <span class="category-id" x-text="'#' + item.category_id"></span>
                                        <span class="category-name" x-text="item.category_name || ''"></span>
                                    </span>
                                    <span class="empty-value" x-show="!item.category_id">—</span>
                                </td>
                                <td class="col-asins" x-data="{ expanded: false }">
                                    <div class="asins-cell" x-show="item.asins && item.asins.length > 0">
                                        <div class="asins-list" :class="{ 'expanded': expanded }">
                                            <span class="asin-text" x-text="formatAsins(item.asins, expanded)"></span>
                                            <button type="button" class="expand-btn" x-show="item.asins && item.asins.length > 3" @click.stop="expanded = !expanded" :title="expanded ? 'Collapse' : 'Expand'">
                                                <span x-text="expanded ? '−' : '+' + (item.asins.length - 3)"></span>
                                            </button>
                                        </div>
                                        <button type="button" class="copy-btn" @click.stop="copyToClipboard(item.asins.join(', '))" title="Copy ASINs">
                                            <i class="bi bi-clipboard"></i>
                                        </button>
                                    </div>
                                    <span class="empty-value" x-show="!item.asins || item.asins.length === 0">—</span>
                                </td>
                                <td class="col-post-type">
                                    <span class="post-type-tag" x-text="getPostTypeName(item.post_type)"></span>
                                </td>
                                <td class="col-template">
                                    <button type="button" class="template-tag template-tag-btn"
                                            x-text="getTemplateName(item)"
                                            :title="item.content_settings?.template_id ? 'Click to edit template' : 'Default template'"
                                            @click.stop="editTemplate(item.content_settings?.template_id)">
                                    </button>
                                </td>
                                <td class="col-status">
                                    <span class="badge" :class="'badge-' + getStatusColor(item.status)">
                                        <span x-text="item.status"></span>
                                    </span>
                                </td>
                                <td class="col-ai">
                                    <span class="badge badge-sm"
                                          :class="'badge-' + getAiStatusColor(item)"
                                          :title="getAiStatusTitle(item)"
                                          @click="item.ai_post_status === 'generating' && isJobStuck(item.ai_post_generating_at, 10) && retryAiGeneration(item)"
                                          :style="item.ai_post_status === 'generating' && isJobStuck(item.ai_post_generating_at, 10) ? 'cursor: pointer;' : ''">
                                        <i class="bi" :class="getAiStatusIcon(item)" style="font-size: 11px;"></i>
                                        <span x-text="getAiStatusLabel(item.ai_post_status)" style="font-size: 11px;"></span>
                                    </span>
                                </td>
                                <td class="col-index">
                                    <button type="button" class="index-toggle"
                                            :class="{ 'indexed': !getNoIndex(item) }"
                                            @click.stop="toggleIndex(item)"
                                            :title="getNoIndex(item) ? 'No-Index (hidden from search engines)' : 'Indexed (visible to search engines)'">
                                        <i class="bi" :class="getNoIndex(item) ? 'bi-eye-slash' : 'bi-eye'"></i>
                                    </button>
                                </td>
                                <td class="col-date">
                                    <span class="date-value" x-text="formatDate(item.created_at)" :title="item.created_at"></span>
                                </td>
                                <td class="col-actions">
                                    <div class="actions-cell">
                                        <span class="actions-placeholder">
                                            <i class="bi bi-three-dots"></i>
                                        </span>
                                        <div class="actions-buttons">
                                            <button class="btn-icon btn-icon-sm" title="Process" @click.stop="processItem(item)" :disabled="item.status === 'processing' || processingItemId === item.id">
                                                <i class="bi" :class="processingItemId === item.id ? 'bi-arrow-clockwise animate-spin' : 'bi-play-fill'"></i>
                                            </button>
                                            <button class="btn-icon btn-icon-sm" title="View Log" @click.stop="$dispatch('view-log', item)" x-show="item.status !== 'pending'">
                                                <i class="bi bi-journal-text"></i>
                                            </button>
                                            <button class="btn-icon btn-icon-sm" title="Edit" @click.stop="$dispatch('edit-item', item)">
                                                <i class="bi bi-pencil"></i>
                                            </button>
                                            <button class="btn-icon btn-icon-sm btn-danger" title="Delete" @click.stop="$dispatch('delete-item', item)">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        </template>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <div class="data-table-pagination" x-show="!isLoading && items.length > 0">
                <div class="pagination-info">
                    <span x-text="totalItems > 0 ? 'Showing ' + ((currentPage - 1) * pageSize + 1) + ' - ' + Math.min(currentPage * pageSize, totalItems) + ' of ' + totalItems + ' keywords' : '0 keywords'"></span>
                </div>
                <div class="pagination-controls">
                    <div class="custom-select custom-select-sm" x-data="{ pageSizeOpen: false }" @click.outside="pageSizeOpen = false">
                        <button type="button" class="custom-select-trigger" :class="{ 'open': pageSizeOpen }" @click="pageSizeOpen = !pageSizeOpen">
                            <span class="custom-select-value" x-text="pageSize"></span>
                            <i class="bi bi-chevron-down"></i>
                        </button>
                        <div class="custom-select-dropdown dropdown-up" x-show="pageSizeOpen" x-cloak x-transition @click.stop>
                            <button type="button" class="custom-select-option" :class="{ 'selected': pageSize === 50 }" @click="changePageSize(50); pageSizeOpen = false">50</button>
                            <button type="button" class="custom-select-option" :class="{ 'selected': pageSize === 100 }" @click="changePageSize(100); pageSizeOpen = false">100</button>
                            <button type="button" class="custom-select-option" :class="{ 'selected': pageSize === 200 }" @click="changePageSize(200); pageSizeOpen = false">200</button>
                            <button type="button" class="custom-select-option" :class="{ 'selected': pageSize === 500 }" @click="changePageSize(500); pageSizeOpen = false">500</button>
                        </div>
                    </div>
                    <div class="pagination-buttons">
                        <button class="pagination-btn" :disabled="currentPage === 1" @click="currentPage = 1" title="First">
                            <i class="bi bi-chevron-double-left"></i>
                        </button>
                        <button class="pagination-btn" :disabled="currentPage === 1" @click="currentPage--" title="Previous">
                            <i class="bi bi-chevron-left"></i>
                        </button>
                        <template x-for="page in visiblePages" :key="page">
                            <button class="pagination-btn" :class="{ 'active': page === currentPage }" @click="currentPage = page" x-text="page"></button>
                        </template>
                        <button class="pagination-btn" :disabled="currentPage === totalPages" @click="currentPage++" title="Next">
                            <i class="bi bi-chevron-right"></i>
                        </button>
                        <button class="pagination-btn" :disabled="currentPage === totalPages" @click="currentPage = totalPages" title="Last">
                            <i class="bi bi-chevron-double-right"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modals -->
    <?php include __DIR__ . '/modals/add-keywords-modal.php'; ?>
    <?php include __DIR__ . '/modals/edit-keyword-modal.php'; ?>
    <?php include __DIR__ . '/modals/queue-delete-modal.php'; ?>
    <?php include __DIR__ . '/modals/content-template-modal.php'; ?>
    <?php include __DIR__ . '/modals/processing-log-modal.php'; ?>

    <!-- Components -->
    <?php include __DIR__ . '/components/toast.php'; ?>
</div>

<script>
document.addEventListener('alpine:init', () => {
    // Queue page component
    Alpine.data('queuePage', () => ({
        // State
        stats: {
            total: <?php echo (int) ($stats['total'] ?? 0); ?>,
            pending: <?php echo (int) ($stats['pending'] ?? 0); ?>,
            processing: <?php echo (int) ($stats['processing'] ?? 0); ?>,
            completed: <?php echo (int) ($stats['completed'] ?? 0); ?>,
            failed: <?php echo (int) ($stats['failed'] ?? 0); ?>,
            paused: <?php echo (int) ($stats['paused'] ?? 0); ?>
        },
        postTypes: acmsConfig.postTypes || [],
        loading: false,
        selectedCount: 0,
        selectedItems: [],
        searchQuery: '',
        filteredCount: 0,
        totalItems: 0,
        hasFilters: false,
        isRefreshing: false,
        refreshSuccess: false,
        filterDropdownOpen: false,
        processingItemId: null,

        // Filters
        filters: {
            status: '',
            post_type: ''
        },

        // Modals
        showAddModal: false,
        showDeleteModal: false,
        showEditModal: false,
        showTemplateModal: false,
        showLogModal: false,

        // Current item for edit/delete/log
        currentItem: null,
        currentLogItem: null,

        // Toast
        showToast: false,
        toastType: 'success',
        toastTitle: '',
        toastMessage: '',

        init() {
            // Listen for stats updates from queueTable
            window.addEventListener('stats-updated', (e) => {
                this.stats = e.detail || this.stats;
            });

            // Listen for modal close → refresh table
            this.$watch('showAddModal', (value) => {
                if (!value) window.dispatchEvent(new CustomEvent('items-updated'));
            });

            // Listen for toast events
            window.addEventListener('show-toast', (e) => {
                this.toast(e.detail.type, e.detail.title, e.detail.message);
            });

            // Listen for delete event
            window.addEventListener('delete-item', (e) => {
                this.openDeleteModal(e.detail);
            });

            // Listen for edit event
            window.addEventListener('edit-item', (e) => {
                this.openEditModal(e.detail);
            });

            // Listen for view-log event
            window.addEventListener('view-log', (e) => {
                this.openLogModal(e.detail);
            });

            // Listen for start-queue-processing event (from Process Now button)
            window.addEventListener('start-queue-processing', () => {
                this.startProcessing();
            });

            // Listen for open-template-builder event (from queue table template column)
            window.addEventListener('open-template-builder', (e) => {
                this.showTemplateModal = true;
                const templateId = e.detail?.templateId;
                if (templateId) {
                    setTimeout(() => {
                        window.dispatchEvent(new CustomEvent('edit-template', {
                            detail: { templateId }
                        }));
                    }, 100);
                }
            });
        },

        // Process queue items
        async startProcessing(ids = null) {
            try {
                const payload = ids ? { ids } : { limit: 1 };

                // Optimistic UI: update items to processing
                if (ids) {
                    window.dispatchEvent(new CustomEvent('update-items-status', {
                        detail: { ids, status: 'processing' }
                    }));
                }

                // Show immediate notification
                this.toast('info', 'Processing', 'Processing started...');

                const response = await fetch(acmsConfig.restUrl + 'queue/process', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': acmsConfig.nonce
                    },
                    body: JSON.stringify(payload)
                });

                const result = await response.json();

                if (result.success) {
                    this.toast('success', 'Completed', result.message || 'Processing completed');
                } else {
                    this.toast('error', 'Error', result.message || 'Processing failed');
                }
            } catch (error) {
                this.toast('error', 'Error', 'Failed to process queue');
            } finally {
                window.dispatchEvent(new CustomEvent('items-updated'));
            }
        },

        // View processing log for an item
        async viewProcessingLog(itemId) {
            try {
                const response = await fetch(`${acmsConfig.restUrl}queue/${itemId}/log`, {
                    headers: { 'X-WP-Nonce': acmsConfig.nonce }
                });

                const result = await response.json();
                if (result.success) {
                    return result.data;
                }
            } catch (error) {
            }
            return null;
        },

        refreshQueue() {
            window.dispatchEvent(new CustomEvent('items-updated'));
            this.refreshSuccess = true;
            setTimeout(() => { this.refreshSuccess = false; }, 2000);
        },

        getStatusLabel(status) {
            const labels = {
                '': 'All Status',
                'pending': 'Pending',
                'processing': 'Processing',
                'completed': 'Completed',
                'failed': 'Failed',
                'paused': 'Paused'
            };
            return labels[status] || status;
        },

        getPostTypeLabel(value) {
            if (!value) return 'All Types';
            const pt = this.postTypes.find(p => p.value === value);
            return pt ? pt.label : value;
        },

        clearFilters() {
            this.filters.status = '';
            this.filters.post_type = '';
            this.hasFilters = false;
            this.$dispatch('filters-cleared');
        },

        applyFilters() {
            this.hasFilters = this.filters.status !== '' || this.filters.post_type !== '';
            this.$dispatch('filters-applied', this.filters);
            this.filterDropdownOpen = false;
        },

        openDeleteModal(items = null) {
            // If items provided, use them; otherwise use existing selectedItems from checkbox selection
            if (items !== null) {
                this.selectedItems = Array.isArray(items) ? items : [items];
                this.selectedCount = this.selectedItems.length;
            }
            // Only open modal if there are items to delete
            if (this.selectedItems.length > 0) {
                this.showDeleteModal = true;
            }
        },

        openEditModal(item) {
            this.currentItem = item;
            this.showEditModal = true;

            // Dispatch event to modal to load the item
            this.$nextTick(() => {
                window.dispatchEvent(new CustomEvent('open-edit-modal', {
                    detail: item
                }));
            });
        },

        openLogModal(item) {
            this.currentLogItem = item;
            this.showLogModal = true;

            // Dispatch event to modal to load the log
            this.$nextTick(() => {
                window.dispatchEvent(new CustomEvent('open-log-modal', {
                    detail: { id: item.id, keyword: item.keyword }
                }));
            });
        },

        /**
         * Delete queue items with specified mode
         * @param {string} deleteMode - 'basic' (queue only) or 'full' (queue + post + orphaned ASINs)
         */
        async deleteQueueItems(deleteMode = 'basic') {
            if (this.selectedItems.length === 0) return;

            try {
                const ids = this.selectedItems.map(i => i.id);
                const response = await fetch(acmsConfig.restUrl + 'queue/bulk', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': acmsConfig.nonce
                    },
                    body: JSON.stringify({
                        action: 'delete',
                        ids: ids,
                        delete_mode: deleteMode
                    })
                });
                const result = await response.json();
                if (result.success) {
                    this.toast('success', 'Deleted', result.message || 'Items deleted successfully');
                    window.dispatchEvent(new CustomEvent('items-updated'));
                } else {
                    this.toast('error', 'Error', result.message || 'Failed to delete items');
                }
            } catch (error) {
                this.toast('error', 'Error', 'Failed to delete items');
            } finally {
                this.showDeleteModal = false;
                this.selectedItems = [];
                this.selectedCount = 0;
            }
        },

        // Legacy alias for backward compatibility
        async deleteItems() {
            return this.deleteQueueItems('basic');
        },

        async deleteProducts() {
            return this.deleteQueueItems('basic');
        },

        async bulkProcess() {
            if (this.selectedItems.length === 0) return;

            const ids = this.selectedItems.map(i => i.id);
            const count = ids.length;

            // Optimistic UI: immediately update items to "processing" status
            window.dispatchEvent(new CustomEvent('update-items-status', {
                detail: { ids, status: 'processing' }
            }));

            // Show immediate notification
            this.toast('info', 'Processing', `Processing ${count} item${count > 1 ? 's' : ''}...`);

            // Clear selection immediately
            this.selectedItems = [];
            this.selectedCount = 0;

            try {
                const response = await fetch(acmsConfig.restUrl + 'queue/process', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': acmsConfig.nonce
                    },
                    body: JSON.stringify({ ids: ids })
                });
                const result = await response.json();
                if (result.success) {
                    this.toast('success', 'Completed', result.message || 'Processing completed');
                } else {
                    this.toast('error', 'Error', result.message || 'Failed to process items');
                }
            } catch (error) {
                this.toast('error', 'Error', 'Failed to process items');
            } finally {
                // Reload to get actual statuses
                window.dispatchEvent(new CustomEvent('items-updated'));
            }
        },

        async bulkPause() {
            if (this.selectedItems.length === 0) return;

            try {
                const ids = this.selectedItems.map(i => i.id);
                const response = await fetch(acmsConfig.restUrl + 'queue/bulk', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': acmsConfig.nonce
                    },
                    body: JSON.stringify({
                        action: 'update_status',
                        status: 'paused',
                        ids: ids
                    })
                });
                const result = await response.json();
                if (result.success) {
                    this.toast('success', 'Success', result.message || 'Items paused');
                    window.dispatchEvent(new CustomEvent('items-updated'));
                } else {
                    this.toast('error', 'Error', result.message || 'Failed to pause items');
                }
            } catch (error) {
                this.toast('error', 'Error', 'Failed to pause items');
            } finally {
                this.selectedItems = [];
                this.selectedCount = 0;
            }
        },

        async bulkReset() {
            if (this.selectedItems.length === 0) return;

            try {
                const ids = this.selectedItems.map(i => i.id);
                const response = await fetch(acmsConfig.restUrl + 'queue/bulk', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': acmsConfig.nonce
                    },
                    body: JSON.stringify({
                        action: 'reset',
                        ids: ids
                    })
                });
                const result = await response.json();
                if (result.success) {
                    this.toast('success', 'Success', result.message || 'Items reset to pending');
                    window.dispatchEvent(new CustomEvent('items-updated'));
                } else {
                    this.toast('error', 'Error', result.message || 'Failed to reset items');
                }
            } catch (error) {
                this.toast('error', 'Error', 'Failed to reset items');
            } finally {
                this.selectedItems = [];
                this.selectedCount = 0;
            }
        },

        toast(type, title, message) {
            this.toastType = type;
            this.toastTitle = title;
            this.toastMessage = message;
            this.showToast = true;
            setTimeout(() => { this.showToast = false; }, 5000);
        }
    }));

    // Queue table component (Server-Side Pagination/Search/Filter)
    Alpine.data('queueTable', () => ({
        // State
        isLoading: true,
        items: [],
        categories: [],
        templates: [],
        selectedIds: [],
        searchQuery: '',

        // Sorting
        sortColumn: 'created_at',
        sortDirection: 'desc',

        // Pagination
        currentPage: 1,
        pageSize: 100,
        totalItems: 0,
        totalPages: 1,

        // Filters from parent
        statusFilter: '',
        postTypeFilter: '',

        // Debounce
        _searchTimer: null,
        _skipPageWatch: false,

        // Computed: visible page numbers
        get visiblePages() {
            const pages = [];
            const total = this.totalPages;
            const current = this.currentPage;

            let start = Math.max(1, current - 2);
            let end = Math.min(total, current + 2);

            if (end - start < 4) {
                if (start === 1) {
                    end = Math.min(total, start + 4);
                } else if (end === total) {
                    start = Math.max(1, end - 4);
                }
            }

            for (let i = start; i <= end; i++) {
                pages.push(i);
            }

            return pages;
        },

        init() {
            this.loadData();
            this.loadCategories();
            this.loadTemplates();

            // Listen for search updates (debounced)
            window.addEventListener('update-search', (e) => {
                this.searchQuery = e.detail.query;
                clearTimeout(this._searchTimer);
                this._searchTimer = setTimeout(() => {
                    this._resetPageAndLoad();
                }, 300);
            });

            // Listen for filter updates
            window.addEventListener('filters-applied', (e) => {
                this.statusFilter = e.detail.status || '';
                this.postTypeFilter = e.detail.post_type || '';
                this._resetPageAndLoad();
            });

            window.addEventListener('filters-cleared', () => {
                this.statusFilter = '';
                this.postTypeFilter = '';
                this._resetPageAndLoad();
            });

            // Watch for page changes to load new data (pagination clicks)
            this.$watch('currentPage', (newVal, oldVal) => {
                if (this._skipPageWatch) return;
                this.selectedIds = [];
                this.dispatchSelectionChange();
                this.loadData();
            });

            // Listen for items-updated event
            window.addEventListener('items-updated', () => {
                this.selectedIds = [];
                this.dispatchSelectionChange();
                this.loadData();
            });

            // Listen for optimistic status updates (from bulk process)
            window.addEventListener('update-items-status', (e) => {
                const { ids, status } = e.detail;
                if (!ids || !status) return;
                this.items.forEach(item => {
                    if (ids.includes(item.id)) {
                        item.status = status;
                    }
                });
            });

            // Refresh templates list when a template is saved/deleted
            window.addEventListener('template-saved', () => {
                this.loadTemplates();
            });
        },

        async loadData() {
            this.isLoading = true;
            try {
                const params = new URLSearchParams({
                    page: this.currentPage,
                    per_page: this.pageSize,
                    orderby: this.sortColumn,
                    order: this.sortDirection,
                });
                if (this.searchQuery) params.set('search', this.searchQuery);
                if (this.statusFilter) params.set('status', this.statusFilter);
                if (this.postTypeFilter) params.set('post_type', this.postTypeFilter);

                const response = await fetch(acmsConfig.restUrl + 'queue?' + params.toString(), {
                    headers: { 'X-WP-Nonce': acmsConfig.nonce }
                });
                const result = await response.json();
                if (result.success) {
                    this.items = result.data.items || [];
                    this.totalItems = result.data.total || 0;
                    this.totalPages = result.data.total_pages || 1;

                    // Dispatch stats if available
                    if (result.data.stats) {
                        window.dispatchEvent(new CustomEvent('stats-updated', {
                            detail: result.data.stats
                        }));
                    }
                    this.dispatchFilteredCount();
                }
            } catch (error) {
                console.error('Failed to load queue items:', error);
            } finally {
                this.isLoading = false;
            }
        },

        changePageSize(size) {
            this.pageSize = size;
            this._skipPageWatch = true;
            this.currentPage = 1;
            this.$nextTick(() => {
                this._skipPageWatch = false;
                this.loadData();
            });
        },

        _resetPageAndLoad() {
            this._skipPageWatch = true;
            this.currentPage = 1;
            this.selectedIds = [];
            this.dispatchSelectionChange();
            this.$nextTick(() => {
                this._skipPageWatch = false;
                this.loadData();
            });
        },

        async loadCategories() {
            try {
                // Load categories from all post types
                const postTypes = acmsConfig.postTypes || [];
                const allCategories = [];

                for (const pt of postTypes) {
                    const taxonomy = pt.value.replace('acms_', '') + '_category';
                    try {
                        const response = await fetch(`${window.location.origin}/wp-json/wp/v2/${taxonomy}?per_page=100`, {
                            headers: { 'X-WP-Nonce': acmsConfig.nonce }
                        });
                        if (response.ok) {
                            const cats = await response.json();
                            allCategories.push(...cats);
                        }
                    } catch (e) {
                        // Taxonomy might not exist, ignore
                    }
                }

                this.categories = allCategories;
            } catch (error) {
            }
        },

        async loadTemplates() {
            try {
                const response = await fetch(acmsConfig.restUrl + 'templates', {
                    headers: { 'X-WP-Nonce': acmsConfig.nonce }
                });
                if (response.ok) {
                    const result = await response.json();
                    if (result.success) {
                        this.templates = result.data || [];
                    }
                }
            } catch (error) {
            }
        },

        sortBy(column) {
            if (this.sortColumn === column) {
                this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
            } else {
                this.sortColumn = column;
                this.sortDirection = 'asc';
            }
            this._skipPageWatch = true;
            this.currentPage = 1;
            this.$nextTick(() => {
                this._skipPageWatch = false;
                this.loadData();
            });
        },

        toggleSelect(id) {
            const idx = this.selectedIds.indexOf(id);
            if (idx === -1) {
                this.selectedIds.push(id);
            } else {
                this.selectedIds.splice(idx, 1);
            }
            this.dispatchSelectionChange();
        },

        toggleSelectAll(checked) {
            if (checked) {
                this.selectedIds = this.items.map(i => i.id);
            } else {
                this.selectedIds = [];
            }
            this.dispatchSelectionChange();
        },

        dispatchSelectionChange() {
            const selectedItems = this.items.filter(i => this.selectedIds.includes(i.id));
            window.dispatchEvent(new CustomEvent('selection-changed', {
                detail: { count: this.selectedIds.length, items: selectedItems }
            }));
        },

        dispatchFilteredCount() {
            const hasFilters = this.searchQuery || this.statusFilter || this.postTypeFilter;
            window.dispatchEvent(new CustomEvent('filtered-count-changed', {
                detail: {
                    count: this.totalItems,
                    hasFilters: hasFilters,
                    total: this.totalItems
                }
            }));
        },

        getStatusColor(status) {
            const colors = {
                pending: 'primary',
                processing: 'info',
                completed: 'success',
                failed: 'error',
                paused: 'secondary'
            };
            return colors[status] || 'secondary';
        },

        getPostTypeName(postType) {
            if (!postType) return '-';
            const pt = acmsConfig.postTypes?.find(p => p.value === postType);
            return pt ? pt.label : postType.replace('acms_', '');
        },

        formatDate(dateStr) {
            if (!dateStr) return '-';
            const d = new Date(dateStr);
            const day = String(d.getDate()).padStart(2, '0');
            const month = String(d.getMonth() + 1).padStart(2, '0');
            const year = d.getFullYear();
            return `${day}/${month}/${year}`;
        },

        getCategoryName(categoryId) {
            if (!categoryId) return '';
            // Try to find category name from cached categories
            const cat = this.categories?.find(c => c.id == categoryId || c.term_id == categoryId);
            return cat ? cat.name : '';
        },

        getEditPostUrl(postId) {
            if (!postId) return '#';
            return `${window.location.origin}/wp-admin/post.php?post=${postId}&action=edit`;
        },

        getViewPostUrl(postId) {
            if (!postId) return '#';
            return `${window.location.origin}/?p=${postId}`;
        },

        getPostSlug(item) {
            // Try to get slug from item or generate from keyword
            if (item.post_slug) return item.post_slug;
            if (item.keyword) {
                return item.keyword.toLowerCase()
                    .replace(/[^a-z0-9]+/g, '-')
                    .replace(/^-+|-+$/g, '')
                    .substring(0, 50);
            }
            return 'view';
        },

        getTemplateName(item) {
            const templateId = item.content_settings?.template_id;
            if (!templateId) return 'Default';
            const tpl = this.templates?.find(t => t.id === templateId);
            return tpl ? tpl.name : 'Default';
        },

        editTemplate(templateId) {
            // Open template modal
            window.dispatchEvent(new CustomEvent('open-template-builder', {
                detail: { templateId }
            }));
        },

        formatAsins(asins, expanded) {
            if (!asins || asins.length === 0) return '';
            if (expanded || asins.length <= 3) {
                return asins.join(', ');
            }
            return asins.slice(0, 3).join(', ');
        },

        async copyToClipboard(text) {
            if (!text) return;
            try {
                await navigator.clipboard.writeText(text);
                window.dispatchEvent(new CustomEvent('show-toast', {
                    detail: { type: 'success', title: 'Copied', message: 'Copied to clipboard' }
                }));
            } catch (err) {
                // Fallback for older browsers
                const textarea = document.createElement('textarea');
                textarea.value = text;
                textarea.style.position = 'fixed';
                textarea.style.opacity = '0';
                document.body.appendChild(textarea);
                textarea.select();
                document.execCommand('copy');
                document.body.removeChild(textarea);
                window.dispatchEvent(new CustomEvent('show-toast', {
                    detail: { type: 'success', title: 'Copied', message: 'Copied to clipboard' }
                }));
            }
        },

        async processItem(item) {
            // Prevent double-click
            if (this.processingItemId === item.id) return;

            this.processingItemId = item.id;

            // Optimistic UI: immediately show processing status
            item.status = 'processing';

            // Show immediate notification
            window.dispatchEvent(new CustomEvent('show-toast', {
                detail: { type: 'info', title: 'Processing', message: `Processing "${item.keyword}"...` }
            }));

            try {
                const response = await fetch(acmsConfig.restUrl + 'queue/process', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': acmsConfig.nonce
                    },
                    body: JSON.stringify({ ids: [item.id] })
                });
                const result = await response.json();
                if (result.success) {
                    window.dispatchEvent(new CustomEvent('show-toast', {
                        detail: { type: 'success', title: 'Completed', message: result.message || 'Item processed successfully' }
                    }));
                } else {
                    window.dispatchEvent(new CustomEvent('show-toast', {
                        detail: { type: 'error', title: 'Error', message: result.message || 'Failed to process item' }
                    }));
                }
            } catch (error) {
                window.dispatchEvent(new CustomEvent('show-toast', {
                    detail: { type: 'error', title: 'Error', message: 'Failed to process item' }
                }));
            } finally {
                this.processingItemId = null;
                // Reload to get actual status
                window.dispatchEvent(new CustomEvent('items-updated'));
            }
        },

        getNoIndex(item) {
            // Get no_index from content_settings, default to true (noindex)
            return item.content_settings?.no_index ?? true;
        },

        // AI Status helper functions (matches ai_post_status ENUM values)
        getAiStatusColor(item) {
            const status = typeof item === 'string' ? item : (item?.ai_post_status || 'not_generated');

            // Check for stuck generating job
            if (status === 'generating' && typeof item === 'object' && this.isJobStuck(item.ai_post_generating_at, 10)) {
                return 'warning'; // Show warning color for stuck jobs
            }

            const colors = {
                'not_generated': 'secondary',
                'queued': 'warning',
                'generating': 'info',
                'generated': 'success',
                'failed': 'error'
            };
            return colors[status] || 'secondary';
        },

        getAiStatusIcon(item) {
            const status = typeof item === 'string' ? item : (item?.ai_post_status || 'not_generated');

            // Check for stuck generating job
            if (status === 'generating' && typeof item === 'object' && this.isJobStuck(item.ai_post_generating_at, 10)) {
                return 'bi-exclamation-circle'; // Show warning icon for stuck jobs
            }

            const icons = {
                'not_generated': 'bi-dash',
                'queued': 'bi-clock',
                'generating': 'bi-arrow-repeat animate-spin',
                'generated': 'bi-robot',
                'failed': 'bi-exclamation-triangle'
            };
            return icons[status] || 'bi-dash';
        },

        getAiStatusLabel(status) {
            const labels = {
                'not_generated': '-',
                'queued': 'Queued',
                'generating': 'AI...',
                'generated': 'AI',
                'failed': 'Failed'
            };
            return labels[status] || '-';
        },

        /**
         * Calculate elapsed time string from a datetime
         */
        getElapsedTime(datetimeStr) {
            if (!datetimeStr) return null;
            const startTime = new Date(datetimeStr.replace(' ', 'T'));
            const now = new Date();
            const diffMs = now - startTime;
            const diffMins = Math.floor(diffMs / 60000);
            const diffHours = Math.floor(diffMins / 60);

            if (diffMins < 1) return 'just started';
            if (diffMins < 60) return `${diffMins} min`;
            if (diffHours < 24) return `${diffHours}h ${diffMins % 60}m`;
            return `${Math.floor(diffHours / 24)}d ${diffHours % 24}h`;
        },

        /**
         * Check if a job appears stuck (generating for too long)
         */
        isJobStuck(datetimeStr, thresholdMins = 10) {
            if (!datetimeStr) return false;
            const startTime = new Date(datetimeStr.replace(' ', 'T'));
            const now = new Date();
            const diffMins = (now - startTime) / 60000;
            return diffMins > thresholdMins;
        },

        getAiStatusTitle(item) {
            const status = item.ai_post_status || 'not_generated';

            // Special handling for generating status - show elapsed time and stuck warning
            if (status === 'generating') {
                const elapsed = this.getElapsedTime(item.ai_post_generating_at);
                const isStuck = this.isJobStuck(item.ai_post_generating_at, 10);

                if (isStuck) {
                    return `AI generation may be stuck (${elapsed}). Click to retry if needed.`;
                }
                if (elapsed) {
                    return `AI is generating post content... (${elapsed})`;
                }
                return 'AI is generating post content...';
            }

            const titles = {
                'not_generated': 'AI post not generated',
                'queued': 'Queued for AI post generation (waiting for products)',
                'generated': item.ai_post_generated_at ? `AI post generated on ${item.ai_post_generated_at}` : 'AI post generated',
                'failed': item.ai_post_error ? `AI generation failed: ${item.ai_post_error}` : 'AI generation failed'
            };
            return titles[status] || '';
        },

        /**
         * Retry AI generation for stuck jobs
         * Resets status to 'queued' so PostAiCron picks it up again
         */
        async retryAiGeneration(item) {
            if (!confirm('This job appears stuck. Do you want to reset it for retry?')) {
                return;
            }

            try {
                const response = await fetch(`${acmsConfig.restUrl}queue/${item.id}`, {
                    method: 'PATCH',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': acmsConfig.nonce
                    },
                    body: JSON.stringify({
                        ai_post_status: 'queued',
                        ai_post_generating_at: null,
                        ai_post_error: null
                    })
                });

                const result = await response.json();
                if (result.success) {
                    // Update local item
                    item.ai_post_status = 'queued';
                    item.ai_post_generating_at = null;
                    item.ai_post_error = null;

                    window.dispatchEvent(new CustomEvent('show-toast', {
                        detail: {
                            type: 'success',
                            title: 'Reset',
                            message: 'AI generation reset - will retry on next cron run'
                        }
                    }));
                } else {
                    window.dispatchEvent(new CustomEvent('show-toast', {
                        detail: { type: 'error', title: 'Error', message: result.message || 'Failed to reset' }
                    }));
                }
            } catch (error) {
                window.dispatchEvent(new CustomEvent('show-toast', {
                    detail: { type: 'error', title: 'Error', message: 'Failed to reset AI generation' }
                }));
            }
        },

        async toggleIndex(item) {
            const currentNoIndex = this.getNoIndex(item);
            const newNoIndex = !currentNoIndex;

            try {
                const response = await fetch(`${acmsConfig.restUrl}queue/${item.id}`, {
                    method: 'PATCH',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': acmsConfig.nonce
                    },
                    body: JSON.stringify({
                        content_settings: {
                            ...item.content_settings,
                            no_index: newNoIndex
                        }
                    })
                });

                const result = await response.json();
                if (result.success) {
                    // Update local item
                    if (!item.content_settings) item.content_settings = {};
                    item.content_settings.no_index = newNoIndex;

                    window.dispatchEvent(new CustomEvent('show-toast', {
                        detail: {
                            type: 'success',
                            title: 'Updated',
                            message: newNoIndex ? 'Set to No-Index' : 'Set to Index'
                        }
                    }));
                } else {
                    window.dispatchEvent(new CustomEvent('show-toast', {
                        detail: { type: 'error', title: 'Error', message: result.message || 'Failed to update' }
                    }));
                }
            } catch (error) {
                window.dispatchEvent(new CustomEvent('show-toast', {
                    detail: { type: 'error', title: 'Error', message: 'Failed to update index status' }
                }));
            }
        }
    }));
});
</script>

<style>
/* Queue-specific styles */
.col-keyword {
    min-width: 200px;
}

.keyword-cell {
    display: flex;
    flex-direction: column;
    gap: 2px;
}

.keyword-row {
    display: flex;
    align-items: center;
    gap: 4px;
}

.keyword-text {
    font-weight: 500;
    color: var(--text-primary);
}

.keyword-link {
    color: var(--color-primary);
    text-decoration: none;
    transition: color 0.15s ease;
}

.keyword-link:hover {
    color: var(--color-primary);
    text-decoration: underline;
    opacity: 0.8;
}

/* Post status dot */
.post-status-dot {
    display: inline-block;
    width: 6px;
    height: 6px;
    border-radius: 50%;
    flex-shrink: 0;
}

.post-status-dot.status-published {
    background-color: #22c55e;
}

.post-status-dot.status-draft {
    background-color: #f59e0b;
}

.post-status-dot.status-pending {
    background-color: #3b82f6;
}

.post-status-dot.status-other {
    background-color: #71717a;
}

.keyword-post-link {
    display: flex;
    align-items: center;
    margin-top: 2px;
}

.post-slug-link {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    font-size: 11px;
    color: #6b7280 !important;
    text-decoration: none;
    transition: color 0.15s ease, opacity 0.15s ease;
    max-width: 180px;
    opacity: 0.8;
}

.post-slug-link:hover {
    color: var(--color-primary) !important;
    opacity: 1;
}

.post-slug-link i {
    font-size: 10px;
    flex-shrink: 0;
}

.post-slug-link span {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

/* Copy button */
.copy-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 22px;
    height: 22px;
    padding: 0;
    border: none;
    background: transparent;
    color: var(--text-muted);
    cursor: pointer;
    border-radius: 4px;
    opacity: 0;
    transition: all 0.15s ease;
    flex-shrink: 0;
}

.copy-btn:hover {
    background: var(--bg-secondary);
    color: var(--text-primary);
}

tr:hover .copy-btn,
.keyword-row:hover .copy-btn,
.asins-cell:hover .copy-btn {
    opacity: 1;
}

/* Category column */
.col-category {
    width: 120px;
}

.category-tag {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    max-width: 100%;
    padding: 2px 8px;
    border-radius: 4px;
    font-size: 12px;
    background: var(--bg-secondary);
    color: var(--text-secondary);
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.category-id {
    color: var(--text-muted);
    font-size: 10px;
    font-weight: 500;
}

.category-name {
    overflow: hidden;
    text-overflow: ellipsis;
}

/* ASINs column */
.col-asins {
    min-width: 180px;
    max-width: 250px;
}

.asins-cell {
    display: flex;
    align-items: flex-start;
    gap: 6px;
}

.asins-list {
    display: flex;
    align-items: center;
    gap: 4px;
    flex-wrap: wrap;
}

.asins-list.expanded {
    flex-wrap: wrap;
}

.asin-text {
    font-size: 12px;
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    color: var(--text-secondary);
    word-break: break-all;
}

.expand-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 2px 6px;
    border: none;
    background: var(--bg-tertiary);
    color: var(--text-muted);
    font-size: 11px;
    font-weight: 500;
    cursor: pointer;
    border-radius: 4px;
    transition: all 0.15s ease;
    flex-shrink: 0;
}

.expand-btn:hover {
    background: var(--color-primary);
    color: white;
}

.empty-value {
    color: var(--text-muted);
    font-size: 12px;
}

.col-post-type {
    width: 120px;
}

.post-type-tag {
    display: inline-block;
    padding: 2px 8px;
    border-radius: 4px;
    font-size: 12px;
    background: var(--bg-secondary);
    color: var(--text-secondary);
}

.col-template {
    width: 100px;
}

.template-tag {
    display: inline-block;
    padding: 2px 8px;
    border-radius: 4px;
    font-size: 11px;
    background: var(--bg-tertiary);
    color: var(--text-muted);
    max-width: 90px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.template-tag-btn {
    border: 1px solid transparent;
    cursor: pointer;
    transition: all 0.15s ease;
}

.template-tag-btn:hover {
    background: var(--bg-secondary);
    border-color: var(--primary);
    color: var(--primary);
}

.col-date {
    width: 100px;
}

.date-value {
    font-size: 12px;
    color: var(--text-secondary);
}

/* Processing indicator */
.stat-item.processing .stat-item-dot {
    background: var(--color-info);
}

/* Index column */
.col-index {
    width: 60px;
    text-align: center;
}

.index-toggle {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 28px;
    height: 28px;
    padding: 0;
    border: none;
    background: var(--bg-secondary);
    color: var(--text-muted);
    border-radius: 6px;
    cursor: pointer;
    transition: all 0.15s ease;
}

.index-toggle:hover {
    background: var(--bg-tertiary);
}

.index-toggle i {
    font-size: 14px;
}

.index-toggle.indexed {
    background: rgba(16, 185, 129, 0.15);
    color: var(--success, #10b981);
}

.index-toggle.indexed:hover {
    background: rgba(16, 185, 129, 0.25);
}

/* Queue table - 4 buttons need more width than products table (3 buttons) */
#acms-queue-app .data-table .col-actions,
#acms-queue-app .data-table th.col-actions,
#acms-queue-app .data-table td.col-actions {
    width: 170px;
    min-width: 170px;
}

/* AI Status column */
.col-ai {
    width: 90px;
    min-width: 90px;
    text-align: center;
}

.col-ai .badge {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    white-space: nowrap;
}

/* Hide AI column on smaller screens */
@media (max-width: 1400px) {
    .col-ai {
        display: none;
    }
}
</style>
