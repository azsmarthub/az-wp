<?php
/**
 * Scrape Diagnostics Modal - Terminal Log Style
 *
 * @package AffiliateCMS\Pro
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<!-- Scrape Diagnostics Modal -->
<div class="modal-backdrop" x-show="showDiagnosticsModal" x-cloak @click.self="showDiagnosticsModal = false"
     x-transition:enter="transition ease-out duration-200"
     x-transition:enter-start="opacity-0"
     x-transition:enter-end="opacity-100"
     x-transition:leave="transition ease-in duration-150"
     x-transition:leave-start="opacity-100"
     x-transition:leave-end="opacity-0">
    <div class="modal scrape-diagnostics-modal" @click.stop>
        <!-- Header -->
        <div class="dlog-header">
            <div style="display: flex; align-items: center; gap: 8px;">
                <i class="bi bi-terminal" style="font-size: 14px; color: #7c8aff;"></i>
                <span style="font-size: 13px; font-weight: 600; color: #e0e0e0;">Scrape Log</span>
                <code class="dlog-asin" x-text="diagnosticsProduct?.asin"></code>
                <span class="dlog-status"
                      :class="diagData?.status === 'scraped' ? 'dlog-status--ok' : (diagData?.status === 'failed' ? 'dlog-status--err' : 'dlog-status--warn')"
                      x-text="diagData?.status"></span>
            </div>
            <div style="display: flex; align-items: center; gap: 4px;">
                <button class="btn-icon btn-icon-sm" @click="copyAllDiagnostics()" title="Copy JSON" style="color: #9ca3af;">
                    <i class="bi" :class="diagCopied ? 'bi-check-lg' : 'bi-clipboard'" :style="diagCopied ? 'color: #22c55e' : ''"></i>
                </button>
                <button class="btn-icon btn-icon-sm" @click="showDiagnosticsModal = false" title="Close" style="color: #9ca3af;">
                    <i class="bi bi-x-lg"></i>
                </button>
            </div>
        </div>

        <!-- Terminal Body -->
        <div class="dlog-body">
            <!-- Loading -->
            <div x-show="diagLoading" style="padding: 40px; text-align: center;">
                <i class="bi bi-arrow-clockwise animate-spin" style="font-size: 18px; color: #7c8aff;"></i>
                <p style="margin-top: 6px; color: #6b7280; font-size: 12px;">Loading...</p>
            </div>

            <!-- No Data -->
            <div x-show="!diagLoading && !diagData?.scrape_log" style="padding: 32px 16px; text-align: center;">
                <p style="color: #6b7280; font-size: 12px;">No scrape log. Re-scrape to generate.</p>
            </div>

            <!-- Log Content -->
            <div x-show="!diagLoading && diagData?.scrape_log" class="dlog-content">
                <!-- Meta -->
                <div class="dlog-section-sep">── meta ──────────────────────────────────</div>
                <div class="dlog-row">
                    <span class="dlog-k">provider</span>
                    <span class="dlog-v" x-text="diagData?.scrape_log?.provider || '-'"></span>
                </div>
                <div class="dlog-row">
                    <span class="dlog-k">scraped_at</span>
                    <span class="dlog-v" x-text="diagData?.scrape_log?.scraped_at || diagData?.last_scraped_at || '-'"></span>
                </div>
                <div class="dlog-row">
                    <span class="dlog-k">asin</span>
                    <span class="dlog-v" x-text="diagData?.scrape_log?.asin || diagnosticsProduct?.asin || '-'"></span>
                </div>
                <template x-if="diagData?.error_message">
                    <div class="dlog-row">
                        <span class="dlog-k">error</span>
                        <span class="dlog-v dlog-c-err" x-text="diagData.error_message"></span>
                    </div>
                </template>

                <!-- Summary -->
                <template x-if="diagData?.scrape_log?.summary">
                    <div>
                        <div class="dlog-section-sep">── summary ───────────────────────────────</div>
                        <template x-for="(val, key) in (diagData?.scrape_log?.summary || {})" :key="key">
                            <div class="dlog-row">
                                <span class="dlog-k" x-text="key"></span>
                                <span :class="val === true ? 'dlog-c-ok' : (val === false ? 'dlog-c-err' : 'dlog-v')"
                                      x-text="val === true ? '✓ yes' : (val === false ? '✗ no' : val)"></span>
                            </div>
                        </template>
                    </div>
                </template>

                <!-- Field Diagnostics -->
                <template x-if="diagData?.scrape_log?.field_diagnostics?.length > 0">
                    <div>
                        <div class="dlog-section-sep">── field diagnostics ─────────────────────</div>
                        <template x-for="(f, idx) in (diagData?.scrape_log?.field_diagnostics || [])" :key="idx">
                            <div class="dlog-field-row" :class="{ 'dlog-field-row--warn': !f.parsed && f.parsed !== 0 && f.parsed !== false && f.field[0] !== '_' }">
                                <span class="dlog-f-name" x-text="f.field"></span>
                                <span class="dlog-f-src" x-text="f.source || ''"></span>
                                <span class="dlog-f-val" x-text="f.parsed !== null && f.parsed !== undefined ? String(f.parsed).substring(0, 80) : '—'"></span>
                                <template x-if="f.notes">
                                    <span class="dlog-f-note" x-text="f.notes"></span>
                                </template>
                            </div>
                        </template>
                    </div>
                </template>

                <!-- Provider Log -->
                <template x-if="diagData?.scrape_log?.provider_log?.length > 0">
                    <div>
                        <div class="dlog-section-sep">── provider log ──────────────────────────</div>
                        <template x-for="(line, i) in (diagData?.scrape_log?.provider_log || [])" :key="i">
                            <div class="dlog-logline" :class="{
                                'dlog-logline--ok': line.includes('SUCCESS'),
                                'dlog-logline--err': line.includes('FAILED') || line.includes('Error') || line.includes('HTTP')
                            }" x-text="line"></div>
                        </template>
                    </div>
                </template>

                <!-- Fields Received -->
                <template x-if="diagData?.scrape_log?.fields_received?.length > 0">
                    <div>
                        <div class="dlog-section-sep">── fields received ───────────────────────</div>
                        <div class="dlog-row">
                            <span class="dlog-v" x-text="(diagData?.scrape_log?.fields_received || []).join(', ')"></span>
                        </div>
                    </div>
                </template>

                <div class="dlog-section-sep" style="margin-top: 4px;">──────────────────────────────────────────</div>
            </div>
        </div>

        <!-- Footer -->
        <div class="dlog-footer">
            <button class="btn btn-secondary btn-sm" @click="copyAllDiagnostics()" style="font-size: 11px;">
                <i class="bi" :class="diagCopied ? 'bi-check-lg' : 'bi-clipboard'"></i>
                <span x-text="diagCopied ? 'Copied!' : 'Copy JSON'"></span>
            </button>
            <button class="btn btn-secondary btn-sm" @click="showDiagnosticsModal = false" style="font-size: 11px;">Close</button>
        </div>
    </div>
</div>
