<?php
/**
 * Edit Keyword Modal
 *
 * @package AffiliateCMS\Pro
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<!-- Edit Keyword Modal -->
<div class="modal-backdrop" x-show="showEditModal" x-cloak
     x-transition:enter="transition ease-out duration-200"
     x-transition:enter-start="opacity-0"
     x-transition:enter-end="opacity-100"
     x-transition:leave="transition ease-in duration-150"
     x-transition:leave-start="opacity-100"
     x-transition:leave-end="opacity-0"
     @keydown.escape.window="showEditModal = false"
     @close-edit-modal.window="showEditModal = false">

    <div class="modal modal-md edit-keyword-modal" x-data="editKeywordModal()"
         @open-edit-modal.window="loadItem($event.detail)"
         x-transition:enter="transition ease-out duration-200"
         x-transition:enter-start="opacity-0 transform scale-95"
         x-transition:enter-end="opacity-100 transform scale-100"
         x-transition:leave="transition ease-in duration-150"
         x-transition:leave-start="opacity-100 transform scale-100"
         x-transition:leave-end="opacity-0 transform scale-95">

        <!-- Modal Header -->
        <div class="modal-header">
            <h3 class="modal-title">
                <i class="bi bi-pencil"></i>
                Edit Keyword
            </h3>
            <button type="button" class="modal-close" @click="$dispatch('close-edit-modal')">
                <i class="bi bi-x-lg"></i>
            </button>
        </div>

        <!-- Loading State -->
        <div class="modal-loading" x-show="isLoading">
            <div class="loading-spinner">
                <i class="bi bi-arrow-clockwise animate-spin"></i>
            </div>
            <span>Loading...</span>
        </div>

        <!-- Modal Body -->
        <div class="modal-body" x-show="!isLoading">
            <!-- Row 1: Keyword | Status -->
            <div class="form-row">
                <div class="form-group flex-1">
                    <label class="form-label">Keyword</label>
                    <input type="text" class="form-input" x-model="form.keyword" placeholder="Enter keyword...">
                </div>

                <div class="form-group" style="width: 160px;">
                    <label class="form-label">Status</label>
                    <div class="custom-select status-select" x-data="{ open: false }" @click.outside="open = false">
                        <button type="button" class="custom-select-trigger" :class="{ 'open': open }" @click="open = !open">
                            <span class="custom-select-value status-value" :class="'status-' + form.status">
                                <i class="bi" :class="getStatusIcon(form.status)"></i>
                                <span x-text="getStatusLabel(form.status)"></span>
                            </span>
                            <i class="bi bi-chevron-down"></i>
                        </button>
                        <div class="custom-select-dropdown status-dropdown" x-show="open" x-cloak x-transition @click.stop>
                            <template x-for="status in statuses" :key="status.value">
                                <button type="button" class="custom-select-option status-option-item"
                                        :class="{ 'selected': form.status === status.value, ['status-' + status.value]: true }"
                                        @click="form.status = status.value; open = false">
                                    <i class="bi" :class="status.icon"></i>
                                    <span x-text="status.label"></span>
                                </button>
                            </template>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Row 2: Post Type | Category -->
            <div class="form-row">
                <div class="form-group flex-1">
                    <label class="form-label">Post Type</label>
                    <div class="custom-select" x-data="{ open: false }" @click.outside="open = false">
                        <button type="button" class="custom-select-trigger" :class="{ 'open': open }" @click="open = !open">
                            <span class="custom-select-value" x-text="getPostTypeLabel(form.postType)"></span>
                            <i class="bi bi-chevron-down"></i>
                        </button>
                        <div class="custom-select-dropdown" x-show="open" x-cloak x-transition @click.stop>
                            <template x-for="pt in enabledPostTypes" :key="pt.value">
                                <button type="button" class="custom-select-option"
                                        :class="{ 'selected': form.postType === pt.value }"
                                        @click="selectPostType(pt.value); open = false"
                                        x-text="pt.label"></button>
                            </template>
                        </div>
                    </div>
                </div>

                <div class="form-group flex-1">
                    <label class="form-label">Category</label>
                    <div class="custom-select searchable-select" x-data="{ open: false, search: '' }" @click.outside="open = false; search = ''">
                        <button type="button" class="custom-select-trigger" :class="{ 'open': open, 'loading': isLoadingCategories }" @click="open = !open" :disabled="isLoadingCategories || !form.postType">
                            <span class="custom-select-value">
                                <template x-if="isLoadingCategories">
                                    <span class="loading-text"><i class="bi bi-arrow-clockwise animate-spin"></i></span>
                                </template>
                                <template x-if="!isLoadingCategories">
                                    <span x-text="getCategoryLabel(form.categoryId)"></span>
                                </template>
                            </span>
                            <i class="bi bi-chevron-down"></i>
                        </button>
                        <div class="custom-select-dropdown" x-show="open && !isLoadingCategories" x-cloak x-transition @click.stop>
                            <div class="select-search-box">
                                <i class="bi bi-search"></i>
                                <input type="text" class="select-search-input" placeholder="Search..." x-model="search" @click.stop>
                            </div>
                            <div class="custom-select-options">
                                <button type="button" class="custom-select-option" :class="{ 'selected': form.categoryId === null }" @click="form.categoryId = null; open = false; search = ''" x-show="!search">None</button>
                                <template x-for="cat in categories.filter(c => !search || c.name.toLowerCase().includes(search.toLowerCase()))" :key="cat.id">
                                    <button type="button" class="custom-select-option" :class="{ 'selected': form.categoryId === cat.id }" @click="form.categoryId = cat.id; open = false; search = ''">
                                        <span class="cat-id">#<span x-text="cat.id"></span></span>
                                        <span x-text="cat.name" :style="cat.parent ? 'padding-left: 8px' : ''"></span>
                                    </button>
                                </template>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Row 3: Author | Template -->
            <div class="form-row">
                <div class="form-group flex-1">
                    <label class="form-label">Author</label>
                    <div class="custom-select" x-data="{ open: false }" @click.outside="open = false">
                        <button type="button" class="custom-select-trigger" :class="{ 'open': open, 'loading': isLoadingAuthors }" @click="open = !open" :disabled="isLoadingAuthors">
                            <span class="custom-select-value">
                                <template x-if="isLoadingAuthors">
                                    <span class="loading-text"><i class="bi bi-arrow-clockwise animate-spin"></i></span>
                                </template>
                                <template x-if="!isLoadingAuthors">
                                    <span x-text="getAuthorLabel()"></span>
                                </template>
                            </span>
                            <i class="bi bi-chevron-down"></i>
                        </button>
                        <div class="custom-select-dropdown" x-show="open && !isLoadingAuthors" x-cloak x-transition @click.stop>
                            <button type="button" class="custom-select-option" :class="{ 'selected': form.authorId === 'random' }" @click="form.authorId = 'random'; open = false">
                                <i class="bi bi-shuffle"></i> Random
                            </button>
                            <div class="custom-select-divider"></div>
                            <template x-for="author in authors" :key="author.id">
                                <button type="button" class="custom-select-option" :class="{ 'selected': form.authorId === author.id }" @click="form.authorId = author.id; open = false">
                                    <span x-text="author.name"></span>
                                </button>
                            </template>
                        </div>
                    </div>
                </div>

                <div class="form-group flex-1">
                    <label class="form-label">Template</label>
                    <div class="custom-select" x-data="{ open: false }" @click.outside="open = false">
                        <button type="button" class="custom-select-trigger" :class="{ 'open': open, 'loading': isLoadingTemplates }" @click="open = !open" :disabled="isLoadingTemplates">
                            <span class="custom-select-value">
                                <template x-if="isLoadingTemplates">
                                    <span class="loading-text"><i class="bi bi-arrow-clockwise animate-spin"></i></span>
                                </template>
                                <template x-if="!isLoadingTemplates">
                                    <span x-text="getTemplateLabel()"></span>
                                </template>
                            </span>
                            <i class="bi bi-chevron-down"></i>
                        </button>
                        <div class="custom-select-dropdown" x-show="open && !isLoadingTemplates" x-cloak x-transition @click.stop>
                            <button type="button" class="custom-select-option" :class="{ 'selected': form.templateId === null }" @click="form.templateId = null; open = false">
                                <i class="bi bi-file-earmark"></i> Default
                            </button>
                            <template x-if="templates.length > 0">
                                <div class="custom-select-divider"></div>
                            </template>
                            <template x-for="tpl in templates" :key="tpl.id">
                                <button type="button" class="custom-select-option" :class="{ 'selected': form.templateId === tpl.id }" @click="form.templateId = tpl.id; open = false">
                                    <span x-text="tpl.name"></span>
                                </button>
                            </template>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Row 4: Tags (100%) -->
            <div class="form-group">
                <label class="form-label">Tags <span class="form-hint">(comma separated)</span></label>
                <input type="text" class="form-input" x-model="form.tags" placeholder="tag1, tag2, tag3...">
            </div>

            <!-- Row 5: Linked ASINs (100% - plaintext) -->
            <div class="form-group">
                <label class="form-label">
                    Linked ASINs
                    <span class="form-hint">(<span x-text="getAsinCount()"></span> items)</span>
                </label>
                <textarea class="form-input asin-textarea"
                          x-model="asinsText"
                          placeholder="B0FK2HPNCB,B0FKH1RW65,B0DWXBCQVP or one per line"
                          rows="4"
                          @input="parseAsinsText()"></textarea>
                <div class="form-help text-muted">Comma-separated or one per line</div>
            </div>

            <!-- Row 6: Options -->
            <div class="options-section">
                <!-- Search ASIN -->
                <div class="option-card" :class="{ 'option-card-expanded': form.searchAsin }">
                    <div class="option-header">
                        <span class="option-icon"><i class="bi bi-search"></i></span>
                        <span class="option-title">Search ASIN</span>
                        <label class="switch">
                            <input type="checkbox" x-model="form.searchAsin">
                            <span class="switch-slider"></span>
                        </label>
                    </div>
                    <span class="option-desc">Auto find products from Amazon</span>
                    <div class="search-limit-row" x-show="form.searchAsin" x-transition x-cloak>
                        <span class="search-limit-label">Max results:</span>
                        <div class="stepper">
                            <button type="button" class="stepper-btn" @click="form.searchLimit = Math.max(1, form.searchLimit - 1)" :disabled="form.searchLimit <= 1">
                                <i class="bi bi-dash"></i>
                            </button>
                            <input type="number" class="stepper-input" x-model.number="form.searchLimit" min="1" max="25">
                            <button type="button" class="stepper-btn" @click="form.searchLimit = Math.min(25, form.searchLimit + 1)" :disabled="form.searchLimit >= 25">
                                <i class="bi bi-plus"></i>
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Auto Publish -->
                <div class="option-card">
                    <div class="option-header">
                        <span class="option-icon"><i class="bi bi-globe2"></i></span>
                        <span class="option-title">Auto Publish</span>
                        <label class="switch">
                            <input type="checkbox" x-model="form.autoPublish">
                            <span class="switch-slider"></span>
                        </label>
                    </div>
                    <span class="option-desc" x-text="form.autoPublish ? 'Will be published' : 'Will be saved as draft'"></span>
                </div>

                <!-- No-Index -->
                <div class="option-card">
                    <div class="option-header">
                        <span class="option-icon"><i class="bi bi-eye-slash"></i></span>
                        <span class="option-title">No-Index</span>
                        <label class="switch">
                            <input type="checkbox" x-model="form.noIndex">
                            <span class="switch-slider"></span>
                        </label>
                    </div>
                    <span class="option-desc" x-text="form.noIndex ? 'Hidden from search engines' : 'Visible to search engines'"></span>
                </div>
            </div>

            <!-- Row 7: Generated Post Info -->
            <div class="generated-section" x-show="generatedPostId">
                <div class="generated-post-box">
                    <div class="info-icon">
                        <i class="bi bi-file-earmark-check"></i>
                    </div>
                    <div class="info-content">
                        <span class="info-label">Generated Post</span>
                        <div class="info-actions">
                            <a :href="getEditPostUrl(generatedPostId)" target="_blank" class="info-link">
                                <i class="bi bi-pencil"></i> Edit
                            </a>
                            <a :href="getViewPostUrl(generatedPostId)" target="_blank" class="info-link">
                                <i class="bi bi-eye"></i> View
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Modal Footer -->
        <div class="modal-footer" x-show="!isLoading">
            <button type="button" class="btn btn-secondary" @click="$dispatch('close-edit-modal')">
                Cancel
            </button>
            <button type="button" class="btn btn-primary" @click="save()" :disabled="isSaving || !form.keyword.trim()">
                <i class="bi" :class="isSaving ? 'bi-arrow-clockwise animate-spin' : 'bi-check-lg'"></i>
                <span x-text="isSaving ? 'Saving...' : 'Save Changes'"></span>
            </button>
        </div>
    </div>
</div>

<script>
document.addEventListener('alpine:init', () => {
    Alpine.data('editKeywordModal', () => ({
        // State
        itemId: null,
        isLoading: false,
        isSaving: false,
        isLoadingCategories: false,
        isLoadingAuthors: false,
        isLoadingTemplates: false,

        // Data
        postTypes: [],
        categories: [],
        authors: [],
        templates: [],
        linkedAsins: [],
        generatedPostId: null,
        asinsText: '',

        // Form data
        form: {
            keyword: '',
            status: 'pending',
            postType: null,
            categoryId: null,
            authorId: 'random',
            templateId: null,
            tags: '',
            searchAsin: true,
            searchLimit: 15,
            autoPublish: false,
            noIndex: true
        },

        // Status options
        statuses: [
            { value: 'pending', label: 'Pending', icon: 'bi-clock' },
            { value: 'paused', label: 'Paused', icon: 'bi-pause-circle' },
            { value: 'processing', label: 'Processing', icon: 'bi-arrow-repeat' },
            { value: 'completed', label: 'Completed', icon: 'bi-check-circle' },
            { value: 'failed', label: 'Failed', icon: 'bi-x-circle' }
        ],

        init() {
            this.postTypes = window._acmsPostTypes || window.acmsConfig?.postTypes || [];
            this.loadAuthors();
            this.loadTemplates();
        },

        get enabledPostTypes() {
            return this.postTypes.filter(pt => pt.enabled);
        },

        async loadItem(item) {
            if (!item || !item.id) return;

            this.isLoading = true;
            this.itemId = item.id;

            // Parse content_settings
            const settings = item.content_settings || {};

            // Populate form
            this.form = {
                keyword: item.keyword || '',
                status: item.status || 'pending',
                postType: item.post_type || null,
                categoryId: item.category_id ? parseInt(item.category_id) : null,
                authorId: settings.author_id || 'random',
                templateId: settings.template_id || null,
                tags: item.tags || '',
                searchAsin: item.auto_search_asins == 1,
                searchLimit: item.search_limit || 15,
                autoPublish: settings.auto_publish || false,
                noIndex: settings.no_index ?? true
            };

            this.linkedAsins = item.asins || [];
            this.asinsText = this.linkedAsins.join('\n');
            this.generatedPostId = item.generated_post_id || null;

            // Load categories for the post type
            if (this.form.postType) {
                await this.loadCategories(this.form.postType);
            }

            this.isLoading = false;
        },

        async loadAuthors() {
            this.isLoadingAuthors = true;
            try {
                const response = await fetch(`${window.location.origin}/wp-json/wp/v2/users?per_page=100&context=edit`, {
                    headers: { 'X-WP-Nonce': acmsConfig.nonce }
                });

                if (response.ok) {
                    const data = await response.json();
                    this.authors = data.map(user => ({
                        id: user.id,
                        name: user.name
                    }));
                }
            } catch (error) {
            } finally {
                this.isLoadingAuthors = false;
            }
        },

        async loadTemplates() {
            this.isLoadingTemplates = true;
            try {
                const response = await fetch(acmsConfig.restUrl + 'templates', {
                    headers: { 'X-WP-Nonce': acmsConfig.nonce }
                });

                if (response.ok) {
                    const result = await response.json();
                    if (result.success) {
                        this.templates = result.data || [];
                    }
                }
            } catch (error) {
            } finally {
                this.isLoadingTemplates = false;
            }
        },

        async loadCategories(postType) {
            if (!postType) {
                this.categories = [];
                return;
            }

            this.isLoadingCategories = true;

            try {
                const taxonomy = postType + '_category';
                const response = await fetch(`${window.location.origin}/wp-json/wp/v2/${taxonomy}?per_page=100&hide_empty=false`, {
                    headers: { 'X-WP-Nonce': acmsConfig.nonce }
                });

                if (response.ok) {
                    const data = await response.json();
                    this.categories = data.map(cat => ({
                        id: cat.id,
                        name: cat.name,
                        parent: cat.parent || 0
                    }));

                    this.categories.sort((a, b) => {
                        if (a.parent === 0 && b.parent !== 0) return -1;
                        if (a.parent !== 0 && b.parent === 0) return 1;
                        return a.name.localeCompare(b.name);
                    });
                }
            } catch (error) {
            } finally {
                this.isLoadingCategories = false;
            }
        },

        selectPostType(value) {
            this.form.postType = value;
            this.form.categoryId = null;
            this.loadCategories(value);
        },

        getPostTypeLabel(value) {
            if (!value) return 'Select...';
            const pt = this.postTypes.find(p => p.value === value);
            return pt ? pt.label : value;
        },

        getCategoryLabel(id) {
            if (id === null) return 'None';
            const cat = this.categories.find(c => c.id === id);
            return cat ? cat.name : 'None';
        },

        getAuthorLabel() {
            if (this.form.authorId === 'random') return 'Random';
            const author = this.authors.find(a => a.id === this.form.authorId);
            return author ? author.name : 'Select...';
        },

        getTemplateLabel() {
            if (this.form.templateId === null) return 'Default';
            const tpl = this.templates.find(t => t.id === this.form.templateId);
            return tpl ? tpl.name : 'Default';
        },

        getStatusIcon(status) {
            const s = this.statuses.find(st => st.value === status);
            return s ? s.icon : 'bi-circle';
        },

        getStatusLabel(status) {
            const s = this.statuses.find(st => st.value === status);
            return s ? s.label : status;
        },

        getEditPostUrl(postId) {
            if (!postId) return '#';
            return `${window.location.origin}/wp-admin/post.php?post=${postId}&action=edit`;
        },

        getViewPostUrl(postId) {
            if (!postId) return '#';
            return `${window.location.origin}/?p=${postId}`;
        },

        // ASIN Management (plaintext)
        getAsinCount() {
            return this.linkedAsins.length;
        },

        parseAsinsText() {
            // Parse textarea content to array of valid ASINs
            const lines = this.asinsText.split(/[\n,]+/);
            const validAsins = [];

            lines.forEach(line => {
                const asin = line.trim().toUpperCase();
                if (/^[A-Z0-9]{10}$/.test(asin) && !validAsins.includes(asin)) {
                    validAsins.push(asin);
                }
            });

            this.linkedAsins = validAsins;
        },

        async save() {
            if (!this.form.keyword.trim()) return;

            this.isSaving = true;

            // Parse ASINs from textarea before saving
            this.parseAsinsText();

            try {
                // Build content_settings
                const contentSettings = {
                    author_id: this.form.authorId,
                    template_id: this.form.templateId,
                    auto_publish: this.form.autoPublish,
                    no_index: this.form.noIndex
                };

                const payload = {
                    keyword: this.form.keyword.trim(),
                    status: this.form.status,
                    post_type: this.form.postType,
                    category_id: this.form.categoryId,
                    tags: this.form.tags,
                    auto_search_asins: this.form.searchAsin ? 1 : 0,
                    search_limit: this.form.searchLimit,
                    linked_asins: this.linkedAsins,
                    content_settings: contentSettings
                };

                const response = await fetch(`${acmsConfig.restUrl}queue/${this.itemId}`, {
                    method: 'PATCH',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': acmsConfig.nonce
                    },
                    body: JSON.stringify(payload)
                });

                const result = await response.json();

                if (result.success) {
                    window.dispatchEvent(new CustomEvent('show-toast', {
                        detail: {
                            type: 'success',
                            title: 'Success',
                            message: 'Keyword updated successfully'
                        }
                    }));

                    // Close modal and refresh list
                    this.$dispatch('close-edit-modal');
                    window.dispatchEvent(new CustomEvent('items-updated'));
                } else {
                    window.dispatchEvent(new CustomEvent('show-toast', {
                        detail: {
                            type: 'error',
                            title: 'Error',
                            message: result.message || 'Failed to update keyword'
                        }
                    }));
                }
            } catch (error) {
                window.dispatchEvent(new CustomEvent('show-toast', {
                    detail: {
                        type: 'error',
                        title: 'Error',
                        message: 'Failed to update keyword'
                    }
                }));
            } finally {
                this.isSaving = false;
            }
        }
    }));
});
</script>

<style>
.edit-keyword-modal {
    max-width: 600px;
}

.edit-keyword-modal .modal-close {
    position: absolute;
    top: 16px;
    right: 16px;
    width: 32px;
    height: 32px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: transparent;
    border: none;
    border-radius: 6px;
    color: var(--text-muted);
    cursor: pointer;
    transition: all 0.15s ease;
}

.edit-keyword-modal .modal-close:hover {
    background: var(--bg-hover);
    color: var(--text-primary);
}

.edit-keyword-modal .modal-header {
    position: relative;
}

.edit-keyword-modal .modal-body {
    display: flex;
    flex-direction: column;
    gap: 16px;
}

/* Loading State */
.modal-loading {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 12px;
    padding: 60px 20px;
    color: var(--text-muted);
}

.modal-loading .loading-spinner {
    font-size: 32px;
    color: var(--primary);
}

/* Form Row */
.form-row {
    display: flex;
    gap: 12px;
}

.flex-1 {
    flex: 1;
}

/* Category select with ID */
.cat-id {
    font-size: 10px;
    color: var(--text-muted);
    margin-right: 4px;
}

/* ASIN Textarea */
.asin-textarea {
    font-family: ui-monospace, SFMono-Regular, 'SF Mono', Menlo, Consolas, monospace;
    font-size: 12px;
    text-transform: uppercase;
    resize: vertical;
    min-height: 100px;
}

/* Options Section */
.options-section {
    display: flex;
    flex-direction: column;
    gap: 12px;
    padding-top: 16px;
    border-top: 1px solid var(--border);
}

.option-card {
    padding: 12px;
    background: var(--bg-secondary);
    border-radius: 8px;
    display: flex;
    flex-direction: column;
    gap: 6px;
}

.option-card-expanded {
    gap: 8px;
}

.option-header {
    display: flex;
    align-items: center;
    gap: 8px;
}

.option-icon {
    width: 24px;
    height: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--text-muted);
}

.option-icon i {
    font-size: 14px;
}

.option-title {
    flex: 1;
    font-size: 13px;
    font-weight: 500;
    color: var(--text-primary);
}

.option-desc {
    font-size: 11px;
    color: var(--text-muted);
    padding-left: 32px;
}

/* Switch */
.switch {
    position: relative;
    display: inline-block;
    width: 40px;
    height: 22px;
    flex-shrink: 0;
}

.switch input {
    opacity: 0;
    width: 0;
    height: 0;
}

.switch-slider {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: var(--bg-tertiary);
    border: 1px solid var(--border);
    transition: 0.2s;
    border-radius: 22px;
}

.switch-slider:before {
    position: absolute;
    content: "";
    height: 16px;
    width: 16px;
    left: 2px;
    bottom: 2px;
    background-color: var(--text-muted);
    transition: 0.2s;
    border-radius: 50%;
}

.switch input:checked + .switch-slider {
    background-color: var(--primary);
    border-color: var(--primary);
}

.switch input:checked + .switch-slider:before {
    transform: translateX(18px);
    background-color: white;
}

/* Search Limit Row with Stepper */
.search-limit-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px 0 0 0;
    border-top: 1px dashed var(--border);
    margin-top: 8px;
}

.search-limit-label {
    font-size: 12px;
    color: var(--text-muted);
}

.stepper {
    position: relative;
    display: inline-flex;
    align-items: center;
}

.stepper-input {
    width: 100px;
    height: 32px;
    padding: 0 28px;
    border: 1px solid var(--border);
    border-radius: 6px;
    background: var(--bg-primary);
    text-align: center;
    font-size: 14px;
    font-weight: 600;
    color: var(--text-primary);
    -moz-appearance: textfield;
}

.stepper-input:focus {
    outline: none;
    border-color: var(--primary);
}

.stepper-input::-webkit-outer-spin-button,
.stepper-input::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
}

.stepper-btn {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    width: 24px;
    height: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: transparent;
    border: none;
    color: var(--text-muted);
    cursor: pointer;
    transition: all 0.15s ease;
}

.stepper-btn:first-child {
    left: 4px;
}

.stepper-btn:last-child {
    right: 4px;
}

.stepper-btn:hover:not(:disabled) {
    color: var(--text-primary);
}

.stepper-btn:disabled {
    opacity: 0.3;
    cursor: not-allowed;
}

.stepper-btn i {
    font-size: 14px;
}

/* Generated Section */
.generated-section {
    padding-top: 12px;
    border-top: 1px solid var(--border);
}

/* Generated Post Box */
.generated-post-box {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px;
    background: linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(16, 185, 129, 0.05));
    border: 1px solid rgba(16, 185, 129, 0.2);
    border-radius: 8px;
}

.generated-post-box .info-icon {
    width: 36px;
    height: 36px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(16, 185, 129, 0.15);
    border-radius: 8px;
    color: var(--success, #10b981);
    font-size: 16px;
}

.generated-post-box .info-content {
    display: flex;
    flex-direction: column;
    gap: 4px;
    flex: 1;
}

.generated-post-box .info-label {
    font-size: 10px;
    color: var(--text-muted);
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.generated-post-box .info-actions {
    display: flex;
    gap: 12px;
}

.generated-post-box .info-link {
    display: flex;
    align-items: center;
    gap: 4px;
    font-size: 12px;
    font-weight: 500;
    color: var(--success, #10b981);
    text-decoration: none;
}

.generated-post-box .info-link:hover {
    text-decoration: underline;
}

.generated-post-box .info-link i {
    font-size: 11px;
}

/* Status Select */
.status-select .custom-select-trigger {
    min-width: 140px;
}

.status-value {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 3px 8px;
    border-radius: 6px;
    font-weight: 500;
    font-size: 12px;
}

.status-value i {
    font-size: 13px;
}

/* Status colors */
.status-value.status-pending {
    background: rgba(245, 158, 11, 0.15);
    color: var(--warning, #f59e0b);
}

.status-value.status-paused {
    background: rgba(107, 114, 128, 0.15);
    color: var(--text-muted);
}

.status-value.status-processing {
    background: rgba(59, 130, 246, 0.15);
    color: var(--primary, #3b82f6);
}

.status-value.status-completed {
    background: rgba(16, 185, 129, 0.15);
    color: var(--success, #10b981);
}

.status-value.status-failed {
    background: rgba(239, 68, 68, 0.15);
    color: var(--danger, #ef4444);
}

/* Status dropdown */
.status-dropdown {
    min-width: 160px;
}

.status-option-item {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 12px !important;
    border-left: 3px solid transparent;
    transition: all 0.15s ease;
}

.status-option-item i {
    font-size: 13px;
    width: 16px;
    text-align: center;
}

.status-option-item.status-pending { border-left-color: var(--warning, #f59e0b); }
.status-option-item.status-pending i { color: var(--warning, #f59e0b); }

.status-option-item.status-paused { border-left-color: var(--text-muted); }
.status-option-item.status-paused i { color: var(--text-muted); }

.status-option-item.status-processing { border-left-color: var(--primary, #3b82f6); }
.status-option-item.status-processing i { color: var(--primary, #3b82f6); }

.status-option-item.status-completed { border-left-color: var(--success, #10b981); }
.status-option-item.status-completed i { color: var(--success, #10b981); }

.status-option-item.status-failed { border-left-color: var(--danger, #ef4444); }
.status-option-item.status-failed i { color: var(--danger, #ef4444); }

.status-option-item.selected {
    background: var(--bg-tertiary);
    font-weight: 500;
}

.status-option-item:hover {
    background: var(--bg-hover);
}

/* Custom select styles */
.edit-keyword-modal .custom-select-divider {
    height: 1px;
    background: var(--border);
    margin: 4px 0;
}

.edit-keyword-modal .custom-select-option i {
    margin-right: 6px;
    opacity: 0.7;
}

.edit-keyword-modal .loading-text {
    display: flex;
    align-items: center;
    gap: 6px;
    color: var(--text-muted);
}

/* Searchable select */
.edit-keyword-modal .searchable-select .custom-select-dropdown {
    max-height: 240px;
    display: flex;
    flex-direction: column;
}

.edit-keyword-modal .select-search-box {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 12px;
    border-bottom: 1px solid var(--border);
    background: var(--bg-secondary);
    flex-shrink: 0;
}

.edit-keyword-modal .select-search-box i {
    color: var(--text-muted);
    font-size: 13px;
}

.edit-keyword-modal .select-search-input {
    flex: 1;
    border: none;
    background: transparent;
    font-size: 12px;
    color: var(--text-primary);
    outline: none;
}

.edit-keyword-modal .custom-select-options {
    flex: 1;
    overflow-y: auto;
    max-height: 180px;
}

@keyframes spin {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}

.animate-spin {
    animation: spin 1s linear infinite;
}

/* Responsive */
@media (max-width: 640px) {
    .form-row {
        flex-direction: column;
    }

    .edit-keyword-modal {
        max-width: 95vw;
    }
}
</style>
