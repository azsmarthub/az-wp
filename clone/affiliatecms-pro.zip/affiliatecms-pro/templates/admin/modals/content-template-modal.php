<?php
/**
 * Content Template Builder Modal
 *
 * @package AffiliateCMS\Pro
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<!-- Content Template Builder Modal -->
<div class="modal-backdrop" x-show="showTemplateModal" x-cloak
     x-transition:enter="transition ease-out duration-200"
     x-transition:enter-start="opacity-0"
     x-transition:enter-end="opacity-100"
     x-transition:leave="transition ease-in duration-150"
     x-transition:leave-start="opacity-100"
     x-transition:leave-end="opacity-0"
     @keydown.escape.window="showTemplateModal = false"
     @close-template-modal.window="showTemplateModal = false"
     x-effect="if (showTemplateModal) { $dispatch('open-template-modal'); }">

    <div class="modal modal-xl content-template-modal" x-data="contentTemplateBuilder()"
         x-transition:enter="transition ease-out duration-200"
         x-transition:enter-start="opacity-0 transform scale-95"
         x-transition:enter-end="opacity-100 transform scale-100"
         x-transition:leave="transition ease-in duration-150"
         x-transition:leave-start="opacity-100 transform scale-100"
         x-transition:leave-end="opacity-0 transform scale-95"
         x-init="$nextTick(() => loadSavedTemplates())">

        <!-- Modal Header -->
        <div class="modal-header">
            <h3 class="modal-title">
                <i class="bi bi-file-earmark-code"></i>
                Content Template Builder
            </h3>
            <button type="button" class="modal-close" @click="$dispatch('close-template-modal')">
                <i class="bi bi-x-lg"></i>
            </button>
        </div>

        <!-- Modal Body -->
        <div class="modal-body template-builder-body">
            <div class="template-builder-layout">
                <!-- Left: Editor -->
                <div class="template-editor-section">
                    <!-- Template Name, Load & Post Type Row -->
                    <div class="template-meta-row">
                        <div class="form-group flex-1">
                            <label class="form-label">Template Name</label>
                            <input type="text" class="form-input" placeholder="My Review Template" x-model="templateName">
                        </div>
                        <div class="form-group template-load-group">
                            <label class="form-label">Load Template</label>
                            <div class="template-load-row">
                                <div class="custom-select template-select" x-data="{ open: false }" @click.outside="open = false">
                                    <button type="button" class="custom-select-trigger"
                                            :class="{ 'open': open, 'loading': isLoadingTemplate }"
                                            @click="open = !open"
                                            :disabled="isLoadingTemplate">
                                        <span class="custom-select-value">
                                            <template x-if="isLoadingTemplate">
                                                <span class="loading-text"><i class="bi bi-arrow-clockwise animate-spin"></i> Loading...</span>
                                            </template>
                                            <template x-if="!isLoadingTemplate">
                                                <span x-text="selectedTemplateId ? (savedTemplates.find(t => t.id === selectedTemplateId)?.name || 'Select...') : '-- New Template --'"></span>
                                            </template>
                                        </span>
                                        <i class="bi bi-chevron-down"></i>
                                    </button>
                                    <div class="custom-select-dropdown" x-show="open && !isLoadingTemplate" x-cloak x-transition @click.stop>
                                        <button type="button" class="custom-select-option"
                                                :class="{ 'selected': !selectedTemplateId }"
                                                @click="selectedTemplateId = ''; loadSavedTemplate(''); open = false">
                                            <i class="bi bi-file-earmark-plus"></i> New Template
                                        </button>
                                        <template x-if="savedTemplates.length > 0">
                                            <div class="custom-select-divider"></div>
                                        </template>
                                        <template x-for="tpl in savedTemplates" :key="tpl.id">
                                            <button type="button" class="custom-select-option"
                                                    :class="{ 'selected': selectedTemplateId === tpl.id }"
                                                    @click="selectedTemplateId = tpl.id; loadSavedTemplate(tpl.id); open = false"
                                                    style="display: flex; align-items: center; gap: 8px;">
                                                <i class="bi bi-file-earmark-code"></i>
                                                <span x-text="tpl.name" style="flex: 1;"></span>
                                                <i class="bi"
                                                   :class="defaultTemplateId === tpl.id ? 'bi-star-fill' : 'bi-star'"
                                                   :style="(defaultTemplateId === tpl.id ? 'color: #dba617;' : 'color: #8c8f94;') + ' cursor: pointer; font-size: 16px;'"
                                                   :title="defaultTemplateId === tpl.id ? 'Default Template' : 'Set as Default'"
                                                   @click.stop="setDefaultTemplate(tpl.id)"></i>
                                            </button>
                                        </template>
                                        <div class="custom-select-empty" x-show="savedTemplates.length === 0">
                                            No saved templates
                                        </div>
                                    </div>
                                </div>
                                <button type="button" class="btn btn-danger btn-icon-sm"
                                        x-show="selectedTemplateId && !isLoadingTemplate"
                                        @click="deleteTemplate(selectedTemplateId)"
                                        title="Delete Template">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </div>
                        </div>
                        <div class="form-group" style="width: 180px;">
                            <label class="form-label">Post Type</label>
                            <div class="custom-select" x-data="{ open: false }" @click.outside="open = false">
                                <button type="button" class="custom-select-trigger" :class="{ 'open': open }" @click="open = !open">
                                    <span class="custom-select-value" x-text="postTypes.find(pt => pt.value === postType)?.label || 'Select...'"></span>
                                    <i class="bi bi-chevron-down"></i>
                                </button>
                                <div class="custom-select-dropdown" x-show="open" x-cloak x-transition @click.stop>
                                    <template x-for="pt in postTypes" :key="pt.value">
                                        <button type="button" class="custom-select-option"
                                                :class="{ 'selected': postType === pt.value, 'disabled': !pt.enabled }"
                                                :disabled="!pt.enabled"
                                                @click="if(pt.enabled) { postType = pt.value; open = false; }">
                                            <span x-text="pt.label"></span>
                                        </button>
                                    </template>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Scrollable Form Content -->
                    <div class="template-form-content">
                        <!-- Title -->
                        <div class="form-group">
                            <label class="form-label">Title</label>
                            <input type="text" class="form-input template-input"
                                   id="title-input"
                                   placeholder="Best %Keyword% in %year% - Top %product_count% Picks"
                                   x-model="template.title"
                                   @focus="currentField = 'title'">
                        </div>

                        <!-- Description (Sapo) -->
                        <div class="form-group">
                            <label class="form-label">Description (Sapo)</label>
                            <textarea class="form-textarea template-input"
                                      id="description-input"
                                      rows="2"
                                      placeholder="Looking for the best %keyword%? We've reviewed %product_count% top products..."
                                      x-model="template.description"
                                      @focus="currentField = 'description'"></textarea>
                        </div>

                        <!-- Meta Title & Description Row -->
                        <div class="form-row">
                            <div class="form-group flex-1">
                                <label class="form-label">Meta Title</label>
                                <input type="text" class="form-input template-input"
                                       id="meta-title-input"
                                       placeholder="%Keyword% - Best %product_count% Picks in %year%"
                                       x-model="template.metaTitle"
                                       @focus="currentField = 'metaTitle'">
                                <div class="char-count" x-text="(template.metaTitle || '').length + '/60'"></div>
                            </div>
                            <div class="form-group flex-1">
                                <label class="form-label">Meta Description</label>
                                <input type="text" class="form-input template-input"
                                       id="meta-desc-input"
                                       placeholder="Discover the best %keyword% in %year%..."
                                       x-model="template.metaDescription"
                                       @focus="currentField = 'metaDescription'">
                                <div class="char-count" x-text="(template.metaDescription || '').length + '/160'"></div>
                            </div>
                        </div>

                        <!-- Before Product List -->
                        <div class="form-group">
                            <label class="form-label">Before Product List</label>
                            <div class="html-editor">
                                <div class="html-editor-toolbar">
                                    <button type="button" class="toolbar-btn" @click="insertTag('beforeProducts', 'b')" title="Bold"><i class="bi bi-type-bold"></i></button>
                                    <button type="button" class="toolbar-btn" @click="insertTag('beforeProducts', 'i')" title="Italic"><i class="bi bi-type-italic"></i></button>
                                    <span class="toolbar-divider"></span>
                                    <button type="button" class="toolbar-btn" @click="insertTag('beforeProducts', 'ul')" title="List"><i class="bi bi-list-ul"></i></button>
                                    <button type="button" class="toolbar-btn" @click="insertTag('beforeProducts', 'ol')" title="Numbered List"><i class="bi bi-list-ol"></i></button>
                                    <span class="toolbar-divider"></span>
                                    <button type="button" class="toolbar-btn" @click="insertLink('beforeProducts')" title="Link"><i class="bi bi-link-45deg"></i></button>
                                    <button type="button" class="toolbar-btn" @click="insertTag('beforeProducts', 'p')" title="Paragraph"><i class="bi bi-paragraph"></i></button>
                                </div>
                                <textarea class="html-editor-area template-input"
                                          id="before-products-input"
                                          rows="6"
                                          placeholder="<p>Looking for the best %keyword%? We've researched and compared the top products...</p>"
                                          x-model="template.beforeProducts"
                                          @focus="currentField = 'beforeProducts'"></textarea>
                            </div>
                        </div>

                        <!-- Product Display Template -->
                        <div class="form-group product-display-section">
                            <label class="form-label">Product Display</label>
                            <div class="product-display-box">
                                <div class="display-options">
                                    <label class="display-option active">
                                        <input type="radio" name="display_type" value="list" x-model="template.displayType" checked>
                                        <i class="bi bi-list-ul"></i>
                                        <span>List</span>
                                    </label>
                                    <!-- Grid template disabled - focusing on List template only
                                    <label class="display-option" :class="{ 'active': template.displayType === 'grid' }">
                                        <input type="radio" name="display_type" value="grid" x-model="template.displayType">
                                        <i class="bi bi-grid-3x3-gap"></i>
                                        <span>Grid</span>
                                    </label>
                                    -->
                                </div>

                                <div class="shortcode-preview">
                                    <label>Generated Shortcode:</label>
                                    <code class="shortcode-output" x-text="getProductShortcode()"></code>
                                    <button type="button" class="btn-copy" @click="copyShortcode()" title="Copy">
                                        <i class="bi bi-clipboard"></i>
                                    </button>
                                </div>

                                <div class="display-note">
                                    <i class="bi bi-info-circle"></i>
                                    <span>ASINs will be auto-inserted from keyword search during queue processing</span>
                                </div>
                            </div>
                        </div>

                        <!-- After Product List -->
                        <div class="form-group">
                            <label class="form-label">After Product List (Main Content)</label>
                            <div class="html-editor">
                                <div class="html-editor-toolbar">
                                    <select class="toolbar-select" @change="insertHeading('afterProducts', $event.target.value); $event.target.value = ''">
                                        <option value="">Heading</option>
                                        <option value="h2">H2</option>
                                        <option value="h3">H3</option>
                                        <option value="h4">H4</option>
                                    </select>
                                    <span class="toolbar-divider"></span>
                                    <button type="button" class="toolbar-btn" @click="insertTag('afterProducts', 'b')" title="Bold"><i class="bi bi-type-bold"></i></button>
                                    <button type="button" class="toolbar-btn" @click="insertTag('afterProducts', 'i')" title="Italic"><i class="bi bi-type-italic"></i></button>
                                    <span class="toolbar-divider"></span>
                                    <button type="button" class="toolbar-btn" @click="insertTag('afterProducts', 'ul')" title="List"><i class="bi bi-list-ul"></i></button>
                                    <button type="button" class="toolbar-btn" @click="insertTag('afterProducts', 'ol')" title="Numbered List"><i class="bi bi-list-ol"></i></button>
                                    <button type="button" class="toolbar-btn" @click="insertTag('afterProducts', 'blockquote')" title="Quote"><i class="bi bi-quote"></i></button>
                                    <span class="toolbar-divider"></span>
                                    <button type="button" class="toolbar-btn" @click="insertLink('afterProducts')" title="Link"><i class="bi bi-link-45deg"></i></button>
                                    <button type="button" class="toolbar-btn" @click="insertTag('afterProducts', 'p')" title="Paragraph"><i class="bi bi-paragraph"></i></button>
                                </div>
                                <textarea class="html-editor-area template-input"
                                          id="after-products-input"
                                          rows="10"
                                          placeholder="<h2>Buying Guide for %Keyword%</h2>&#10;<p>When shopping for %keyword%, consider these factors...</p>"
                                          x-model="template.afterProducts"
                                          @focus="currentField = 'afterProducts'"></textarea>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Right: Shortcode Panel -->
                <div class="shortcode-panel">
                    <div class="shortcode-panel-header">
                        <h4><i class="bi bi-code-square"></i> Shortcodes</h4>
                        <input type="text" class="shortcode-search" placeholder="Search..."
                               x-model="shortcodeSearch">
                    </div>
                    <div class="shortcode-accordion">
                        <template x-for="(group, index) in filteredShortcodeGroups" :key="group.name">
                            <div class="accordion-item">
                                <button type="button" class="accordion-header"
                                        :class="{ 'expanded': expandedGroup === index }"
                                        @click="expandedGroup = expandedGroup === index ? null : index">
                                    <span class="accordion-title" x-text="group.name"></span>
                                    <span class="accordion-count" x-text="group.items.length"></span>
                                    <i class="bi" :class="expandedGroup === index ? 'bi-chevron-up' : 'bi-chevron-down'"></i>
                                </button>
                                <div class="accordion-content" x-show="expandedGroup === index"
                                     x-transition:enter="accordion-enter"
                                     x-transition:enter-start="accordion-enter-start"
                                     x-transition:enter-end="accordion-enter-end"
                                     x-transition:leave="accordion-leave"
                                     x-transition:leave-start="accordion-leave-start"
                                     x-transition:leave-end="accordion-leave-end">
                                    <template x-for="item in group.items" :key="item.code">
                                        <div class="shortcode-item" @click="insertShortcode(item.code)">
                                            <code x-text="item.code"></code>
                                            <span x-text="item.description"></span>
                                        </div>
                                    </template>
                                </div>
                            </div>
                        </template>
                    </div>
                </div>
            </div>
        </div>

        <!-- Modal Footer -->
        <div class="modal-footer">
            <div class="footer-left">
                <button type="button" class="btn btn-secondary btn-sm" @click="resetTemplate()" title="Reset">
                    <i class="bi bi-arrow-counterclockwise"></i>
                </button>
                <button type="button" class="btn btn-secondary btn-sm" @click="loadTemplate()" title="Import">
                    <i class="bi bi-upload"></i>
                </button>
                <button type="button" class="btn btn-secondary btn-sm" @click="exportTemplate()" title="Export">
                    <i class="bi bi-download"></i>
                </button>
            </div>
            <div class="footer-right">
                <button type="button" class="btn btn-secondary" @click="$dispatch('close-template-modal')">
                    Cancel
                </button>
                <button type="button" class="btn btn-primary" @click="saveTemplate()" :disabled="!templateName || isSaving">
                    <i class="bi" :class="isSaving ? 'bi-arrow-clockwise animate-spin' : 'bi-check-lg'"></i>
                    <span x-text="isSaving ? 'Saving...' : 'Save Template'"></span>
                </button>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('alpine:init', () => {
    Alpine.data('contentTemplateBuilder', () => ({
        templateId: null,
        templateName: '',
        postType: 'acms_reviews',
        postTypes: [],
        currentField: 'title',
        isSaving: false,
        isLoadingTemplate: false,
        shortcodeSearch: '',
        expandedGroup: 0,
        savedTemplates: [],
        selectedTemplateId: '',
        defaultTemplateId: '',

        template: {
            title: '',
            description: '',
            metaTitle: '',
            metaDescription: '',
            beforeProducts: '',
            afterProducts: '',
            displayType: 'list'
        },

        shortcodeGroups: [
            {
                name: 'Date & Time',
                items: [
                    { code: '%year%', description: 'Current year' },
                    { code: '%month%', description: 'Month (1-12)' },
                    { code: '%month_text%', description: 'Month name' },
                    { code: '%day%', description: 'Day of month' }
                ]
            },
            {
                name: 'Keyword',
                items: [
                    { code: '%keyword%', description: 'lowercase' },
                    { code: '%Keyword%', description: 'Title Case' },
                    { code: '%KEYWORD%', description: 'UPPERCASE' },
                    { code: '%keyword_slug%', description: 'url-slug' }
                ]
            },
            {
                name: 'Product',
                items: [
                    { code: '%product_count%', description: 'Total products' },
                    { code: '%product:1:name%', description: 'Product 1 name' },
                    { code: '%product:1:brand%', description: 'Product 1 brand' },
                    { code: '%product:1:price%', description: 'Product 1 price' },
                    { code: '%product:1:rating%', description: 'Product 1 rating' },
                    { code: '%product:1:image%', description: 'Product 1 image' },
                    { code: '%product:1:features%', description: 'Product 1 features' },
                    { code: '%product:1:cta%', description: 'Product 1 CTA button' }
                ]
            },
            {
                name: 'Price Stats',
                items: [
                    { code: '%price_min%', description: 'Lowest price' },
                    { code: '%price_max%', description: 'Highest price' },
                    { code: '%price_avg%', description: 'Average price' }
                ]
            },
            {
                name: 'Site Info',
                items: [
                    { code: '%author%', description: 'Author name' },
                    { code: '%site_name%', description: 'Site name' },
                    { code: '%site_url%', description: 'Site URL' }
                ]
            }
        ],

        get filteredShortcodeGroups() {
            if (!this.shortcodeSearch) return this.shortcodeGroups;

            const search = this.shortcodeSearch.toLowerCase();
            return this.shortcodeGroups.map(group => ({
                ...group,
                items: group.items.filter(item =>
                    item.code.toLowerCase().includes(search) ||
                    item.description.toLowerCase().includes(search)
                )
            })).filter(group => group.items.length > 0);
        },

        init() {
            this.postTypes = window._acmsPostTypes || window.acmsConfig?.postTypes || [];

            // Load templates immediately on init
            this.loadSavedTemplates();

            // Listen for modal open event (dispatched from parent)
            window.addEventListener('open-template-modal', () => {
                this.loadSavedTemplates();
            });

            // Listen for template saved event to refresh list
            window.addEventListener('template-saved', () => this.loadSavedTemplates());

            // Listen for edit template request from queue table
            window.addEventListener('edit-template', async (e) => {
                const templateId = e.detail?.templateId;
                if (templateId) {
                    await this.loadSavedTemplates();
                    await this.loadSavedTemplate(templateId);
                }
            });
        },

        async loadSavedTemplates() {
            try {
                const response = await fetch(acmsConfig.restUrl + 'templates', {
                    headers: { 'X-WP-Nonce': acmsConfig.nonce }
                });
                const result = await response.json();
                if (result.success) {
                    this.savedTemplates = result.data || [];

                    // Load default template ID
                    this.defaultTemplateId = result.default_template_id || '';

                    // Auto-load default template if available and no template currently selected
                    if (this.defaultTemplateId && !this.selectedTemplateId && !this.templateId) {
                        await this.loadSavedTemplate(this.defaultTemplateId);
                    }

                    return this.savedTemplates;
                }
            } catch (error) {
            }
            return [];
        },

        async loadSavedTemplate(templateId) {
            // If empty string selected (New Template), reset form
            if (!templateId) {
                this.resetTemplate();
                return;
            }

            this.isLoadingTemplate = true;

            try {
                const response = await fetch(acmsConfig.restUrl + 'templates/' + templateId, {
                    headers: { 'X-WP-Nonce': acmsConfig.nonce }
                });
                const result = await response.json();

                if (result.success && result.data) {
                    // Apply template data (this also updates selectedTemplateId)
                    this.applyTemplateData(result.data);

                    window.dispatchEvent(new CustomEvent('show-toast', {
                        detail: { type: 'success', title: 'Loaded', message: `Template "${result.data.name}" loaded` }
                    }));
                } else {
                    // Don't reset selection - keep it so user can retry
                    window.dispatchEvent(new CustomEvent('show-toast', {
                        detail: { type: 'error', title: 'Error', message: result.message || 'Template not found' }
                    }));
                }
            } catch (error) {
                // Don't reset selection on network error
                window.dispatchEvent(new CustomEvent('show-toast', {
                    detail: { type: 'error', title: 'Error', message: 'Failed to load template' }
                }));
            } finally {
                this.isLoadingTemplate = false;
            }
        },

        async deleteTemplate(templateId) {
            if (!templateId) return;

            if (!confirm('Are you sure you want to delete this template?')) return;

            try {
                const response = await fetch(acmsConfig.restUrl + 'templates/' + templateId, {
                    method: 'DELETE',
                    headers: { 'X-WP-Nonce': acmsConfig.nonce }
                });
                const result = await response.json();

                if (result.success) {
                    window.dispatchEvent(new CustomEvent('show-toast', {
                        detail: { type: 'success', title: 'Success', message: 'Template deleted' }
                    }));

                    // Reset form if deleted template was currently loaded
                    if (this.templateId === templateId || this.selectedTemplateId === templateId) {
                        this.resetTemplate();
                    }

                    // Refresh templates list
                    this.loadSavedTemplates();
                    window.dispatchEvent(new CustomEvent('template-saved'));
                } else {
                    throw new Error(result.message || 'Failed to delete');
                }
            } catch (error) {
                window.dispatchEvent(new CustomEvent('show-toast', {
                    detail: { type: 'error', title: 'Error', message: error.message }
                }));
            }
        },

        async setDefaultTemplate(templateId) {
            if (!templateId) return;

            try {
                const response = await fetch(acmsConfig.restUrl + 'templates/default', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': acmsConfig.nonce
                    },
                    body: JSON.stringify({ template_id: templateId })
                });
                const result = await response.json();

                if (result.success) {
                    this.defaultTemplateId = templateId;

                    window.dispatchEvent(new CustomEvent('show-toast', {
                        detail: {
                            type: 'success',
                            title: 'Success',
                            message: 'Default template updated'
                        }
                    }));

                    // Refresh templates list to update UI
                    this.loadSavedTemplates();
                } else {
                    throw new Error(result.message || 'Failed to set default template');
                }
            } catch (error) {
                window.dispatchEvent(new CustomEvent('show-toast', {
                    detail: {
                        type: 'error',
                        title: 'Error',
                        message: error.message
                    }
                }));
            }
        },

        getTextareaId(field) {
            const map = {
                'beforeProducts': 'before-products-input',
                'afterProducts': 'after-products-input'
            };
            return map[field] || null;
        },

        insertTag(field, tag) {
            const textarea = document.getElementById(this.getTextareaId(field));
            if (!textarea) return;

            const start = textarea.selectionStart;
            const end = textarea.selectionEnd;
            const selectedText = textarea.value.substring(start, end);
            const text = textarea.value;

            let insertion = '';
            if (tag === 'ul' || tag === 'ol') {
                const items = selectedText ? selectedText.split('\n').map(line => `  <li>${line}</li>`).join('\n') : '  <li></li>';
                insertion = `<${tag}>\n${items}\n</${tag}>`;
            } else {
                insertion = `<${tag}>${selectedText}</${tag}>`;
            }

            this.template[field] = text.substring(0, start) + insertion + text.substring(end);

            this.$nextTick(() => {
                textarea.focus();
                const newPos = start + insertion.length;
                textarea.setSelectionRange(newPos, newPos);
            });
        },

        insertHeading(field, tag) {
            if (!tag) return;
            const textarea = document.getElementById(this.getTextareaId(field));
            if (!textarea) return;

            const start = textarea.selectionStart;
            const end = textarea.selectionEnd;
            const selectedText = textarea.value.substring(start, end);
            const text = textarea.value;

            const insertion = `<${tag}>${selectedText || 'Heading'}</${tag}>`;
            this.template[field] = text.substring(0, start) + insertion + text.substring(end);

            this.$nextTick(() => {
                textarea.focus();
                const newPos = start + insertion.length;
                textarea.setSelectionRange(newPos, newPos);
            });
        },

        insertLink(field) {
            const url = prompt('Enter URL:');
            if (!url) return;

            const textarea = document.getElementById(this.getTextareaId(field));
            if (!textarea) return;

            const start = textarea.selectionStart;
            const end = textarea.selectionEnd;
            const selectedText = textarea.value.substring(start, end) || 'Link text';
            const text = textarea.value;

            const insertion = `<a href="${url}">${selectedText}</a>`;
            this.template[field] = text.substring(0, start) + insertion + text.substring(end);

            this.$nextTick(() => {
                textarea.focus();
                const newPos = start + insertion.length;
                textarea.setSelectionRange(newPos, newPos);
            });
        },

        insertShortcode(code) {
            const fieldMap = {
                'title': 'title-input',
                'description': 'description-input',
                'metaTitle': 'meta-title-input',
                'metaDescription': 'meta-desc-input',
                'beforeProducts': 'before-products-input',
                'afterProducts': 'after-products-input'
            };

            const target = fieldMap[this.currentField];
            if (!target) return;

            const input = document.getElementById(target);
            if (!input) return;

            const start = input.selectionStart;
            const end = input.selectionEnd;
            const text = this.template[this.currentField] || '';

            this.template[this.currentField] = text.substring(0, start) + code + text.substring(end);

            this.$nextTick(() => {
                input.focus();
                input.setSelectionRange(start + code.length, start + code.length);
            });
        },

        getProductShortcode() {
            const type = this.template.displayType;
            const shortcodes = {
                'list': '[acms_list asin="%auto_asins%"]',
                'grid': '[acms_grid asin="%auto_asins%" columns="3"]'
            };
            return shortcodes[type] || shortcodes['list'];
        },

        copyShortcode() {
            navigator.clipboard.writeText(this.getProductShortcode());
            window.dispatchEvent(new CustomEvent('show-toast', {
                detail: { type: 'success', title: 'Copied', message: 'Shortcode copied to clipboard' }
            }));
        },

        syncEditors() {
            // No longer needed - textareas sync via x-model
        },

        async saveTemplate() {
            this.syncEditors();

            if (!this.templateName) {
                window.dispatchEvent(new CustomEvent('show-toast', {
                    detail: { type: 'error', title: 'Error', message: 'Please enter a template name' }
                }));
                return;
            }

            this.isSaving = true;

            try {
                const response = await fetch(acmsConfig.restUrl + 'templates', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': acmsConfig.nonce
                    },
                    body: JSON.stringify({
                        id: this.templateId || null,
                        name: this.templateName,
                        postType: this.postType,
                        title: this.template.title,
                        description: this.template.description,
                        metaTitle: this.template.metaTitle,
                        metaDescription: this.template.metaDescription,
                        beforeProducts: this.template.beforeProducts,
                        afterProducts: this.template.afterProducts,
                        displayType: this.template.displayType
                    })
                });

                const result = await response.json();

                if (result.success) {
                    // Store the new ID if this was a new template
                    if (result.data?.id) {
                        this.templateId = result.data.id;
                        this.selectedTemplateId = result.data.id;
                    }
                    window.dispatchEvent(new CustomEvent('show-toast', {
                        detail: { type: 'success', title: 'Success', message: result.message || 'Template saved' }
                    }));
                    window.dispatchEvent(new CustomEvent('template-saved', { detail: result.data }));

                    // Refresh templates list to include the newly saved template
                    this.loadSavedTemplates();
                } else {
                    throw new Error(result.message || 'Failed to save');
                }
            } catch (error) {
                window.dispatchEvent(new CustomEvent('show-toast', {
                    detail: { type: 'error', title: 'Error', message: error.message }
                }));
            } finally {
                this.isSaving = false;
            }
        },

        loadTemplate() {
            const input = document.createElement('input');
            input.type = 'file';
            input.accept = '.json';
            input.onchange = (e) => {
                const file = e.target.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = (event) => {
                        try {
                            const data = JSON.parse(event.target.result);
                            this.applyTemplateData(data);
                            window.dispatchEvent(new CustomEvent('show-toast', {
                                detail: { type: 'success', title: 'Success', message: 'Template loaded' }
                            }));
                        } catch (error) {
                            window.dispatchEvent(new CustomEvent('show-toast', {
                                detail: { type: 'error', title: 'Error', message: 'Invalid file' }
                            }));
                        }
                    };
                    reader.readAsText(file);
                }
            };
            input.click();
        },

        applyTemplateData(data) {
            // Apply template metadata (use null coalescing to preserve empty strings)
            this.templateId = data.id ?? null;
            this.templateName = data.name ?? '';
            this.postType = data.postType || 'acms_reviews';

            // Update selectedTemplateId to keep dropdown in sync
            if (data.id) {
                this.selectedTemplateId = data.id;
            }

            // Get source data (handle both flat format from API and nested format from export)
            const src = data.template || data;

            // Update fields individually for proper Alpine reactivity
            this.template.title = src.title ?? '';
            this.template.description = src.description ?? '';
            this.template.metaTitle = src.metaTitle ?? '';
            this.template.metaDescription = src.metaDescription ?? '';
            this.template.beforeProducts = this.decodeHtml(src.beforeProducts ?? '');
            this.template.afterProducts = this.decodeHtml(src.afterProducts ?? '');
            this.template.displayType = src.displayType || 'list';

            // Force Alpine to re-render
            this.$nextTick(() => {
                // Focus on template name if empty (new import)
                if (!this.templateName) {
                    const nameInput = document.querySelector('.template-meta-row input[type="text"]');
                    if (nameInput) nameInput.focus();
                }
            });
        },

        decodeHtml(html) {
            if (!html) return '';
            const txt = document.createElement('textarea');
            txt.innerHTML = html;
            return txt.value;
        },

        resetTemplate() {
            this.templateId = null;
            this.templateName = '';
            this.selectedTemplateId = '';

            // Reset fields individually for proper reactivity
            this.template.title = '';
            this.template.description = '';
            this.template.metaTitle = '';
            this.template.metaDescription = '';
            this.template.beforeProducts = '';
            this.template.afterProducts = '';
            this.template.displayType = 'list';
        },

        exportTemplate() {
            this.syncEditors();

            const data = {
                name: this.templateName,
                postType: this.postType,
                template: this.template,
                exportedAt: new Date().toISOString()
            };

            const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `template-${this.templateName || 'untitled'}.json`;
            a.click();
            URL.revokeObjectURL(url);
        }
    }));
});
</script>

<style>
.content-template-modal {
    max-width: 1100px;
    width: 95vw;
    max-height: 90vh;
}

.content-template-modal .modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    position: relative;
}

/* Modal Close Button */
.content-template-modal .modal-close {
    width: 32px;
    height: 32px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: transparent;
    border: none;
    border-radius: 6px;
    color: var(--text-muted);
    cursor: pointer;
    transition: all 0.15s ease;
}

.content-template-modal .modal-close:hover {
    background: var(--bg-hover);
    color: var(--text-primary);
}

.content-template-modal .modal-close i {
    font-size: 18px;
}

/* Template Load Group */
.template-load-group {
    width: 250px;
}

.template-load-row {
    display: flex;
    align-items: center;
    gap: 6px;
}

.template-load-row .template-select {
    flex: 1;
}

/* Custom Select Tweaks for this modal */
.content-template-modal .custom-select {
    position: relative;
    width: 100%;
}

.content-template-modal .custom-select-trigger {
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
    padding: 8px 12px;
    background: var(--bg-secondary);
    border: 1px solid var(--border);
    border-radius: 6px;
    font-size: 13px;
    color: var(--text-primary);
    cursor: pointer;
    transition: all 0.15s ease;
}

.content-template-modal .custom-select-trigger:hover {
    border-color: var(--primary);
}

.content-template-modal .custom-select-trigger.open {
    border-color: var(--primary);
    box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.15);
}

.content-template-modal .custom-select-trigger.loading {
    opacity: 0.7;
    cursor: wait;
}

.content-template-modal .custom-select-trigger i.bi-chevron-down {
    font-size: 12px;
    color: var(--text-muted);
    transition: transform 0.15s ease;
}

.content-template-modal .custom-select-trigger.open i.bi-chevron-down {
    transform: rotate(180deg);
}

.content-template-modal .custom-select-value {
    flex: 1;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    text-align: left;
}

.content-template-modal .custom-select-dropdown {
    position: absolute;
    top: 100%;
    left: 0;
    right: 0;
    margin-top: 4px;
    background: #1a1a1f;
    border: 1px solid var(--border);
    border-radius: 8px;
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.4);
    z-index: 100;
    max-height: 250px;
    overflow-y: auto;
}

.content-template-modal .custom-select-option {
    display: flex;
    align-items: center;
    gap: 8px;
    width: 100%;
    padding: 10px 12px;
    background: #1a1a1f;
    border: none;
    font-size: 13px;
    color: var(--text-primary);
    cursor: pointer;
    text-align: left;
    transition: background 0.1s ease;
}

.content-template-modal .custom-select-option:hover {
    background: #252530;
}

.content-template-modal .custom-select-option.selected {
    background: rgba(59, 130, 246, 0.1);
    color: var(--primary);
}

.content-template-modal .custom-select-option.disabled {
    opacity: 0.5;
    cursor: not-allowed;
}

.content-template-modal .custom-select-option i {
    font-size: 14px;
    opacity: 0.7;
}

.content-template-modal .custom-select-divider {
    height: 1px;
    background: var(--border);
    margin: 4px 0;
}

.content-template-modal .custom-select-empty {
    padding: 12px 16px;
    color: var(--text-muted);
    font-size: 13px;
    text-align: center;
}

.content-template-modal .loading-text {
    display: flex;
    align-items: center;
    gap: 6px;
    color: var(--text-muted);
}

.btn-icon-sm {
    width: 36px;
    height: 36px;
    padding: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.template-builder-body {
    padding: 0 !important;
    overflow: hidden;
}

.template-builder-layout {
    display: flex;
    height: calc(90vh - 130px);
    min-height: 500px;
}

/* Left Editor Section */
.template-editor-section {
    flex: 1;
    display: flex;
    flex-direction: column;
    overflow: hidden;
    background: var(--bg-surface);
}

.template-meta-row {
    display: flex;
    gap: 12px;
    padding: 16px 20px;
    background: var(--bg-secondary);
    border-bottom: 1px solid var(--border);
}

.template-meta-row .flex-1 { flex: 1; }

.template-form-content {
    flex: 1;
    overflow-y: auto;
    padding: 20px;
}

.form-group {
    margin-bottom: 16px;
}

.form-label {
    display: block;
    font-size: 13px;
    font-weight: 600;
    color: var(--text-primary);
    margin-bottom: 6px;
}

.form-row {
    display: flex;
    gap: 12px;
}

.form-row .flex-1 { flex: 1; }

.template-input {
    font-family: 'Monaco', 'Menlo', 'Consolas', monospace;
    font-size: 12px;
    background: var(--bg-secondary);
}

.char-count {
    font-size: 11px;
    color: var(--text-muted);
    text-align: right;
    margin-top: 4px;
}

/* HTML Editor - Dark mode compatible */
.html-editor {
    border: 1px solid var(--border);
    border-radius: 6px;
    overflow: hidden;
    background: var(--bg-secondary);
}

.html-editor-toolbar {
    display: flex;
    align-items: center;
    gap: 2px;
    padding: 6px 8px;
    background: var(--bg-surface);
    border-bottom: 1px solid var(--border);
}

.toolbar-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 28px;
    height: 28px;
    padding: 0;
    background: transparent;
    border: 1px solid transparent;
    border-radius: 4px;
    color: var(--text-secondary);
    cursor: pointer;
    transition: all 0.15s ease;
}

.toolbar-btn:hover {
    background: var(--bg-hover);
    border-color: var(--border);
    color: var(--text-primary);
}

.toolbar-btn:active {
    background: var(--primary);
    color: #fff;
}

.toolbar-btn i {
    font-size: 14px;
}

.toolbar-select {
    padding: 4px 8px;
    font-size: 11px;
    background: var(--bg-secondary);
    border: 1px solid var(--border);
    border-radius: 4px;
    color: var(--text-primary);
    cursor: pointer;
}

.toolbar-select:hover {
    border-color: var(--primary);
}

.toolbar-select:focus {
    outline: none;
    border-color: var(--primary);
}

.toolbar-divider {
    width: 1px;
    height: 18px;
    background: var(--border);
    margin: 0 4px;
}

.html-editor-area {
    width: 100%;
    min-height: 120px;
    padding: 12px;
    font-family: 'Monaco', 'Menlo', 'Consolas', monospace;
    font-size: 12px;
    line-height: 1.6;
    background: var(--bg-secondary);
    border: none;
    color: var(--text-primary);
    resize: vertical;
}

.html-editor-area:focus {
    outline: none;
    background: var(--bg-surface);
}

.html-editor-area::placeholder {
    color: var(--text-muted);
}

/* Product Display Section */
.product-display-section {
    margin: 20px 0;
}

.product-display-box {
    background: var(--bg-secondary);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 16px;
}

.display-options {
    display: flex;
    gap: 8px;
    margin-bottom: 16px;
}

.display-option {
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 6px;
    padding: 12px;
    background: var(--bg-surface);
    border: 2px solid var(--border);
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.15s ease;
}

.display-option input { display: none; }

.display-option i {
    font-size: 20px;
    color: var(--text-secondary);
}

.display-option span {
    font-size: 12px;
    font-weight: 500;
    color: var(--text-secondary);
}

.display-option:hover {
    border-color: var(--primary);
}

.display-option.active {
    background: rgba(59, 130, 246, 0.08);
    border-color: var(--primary);
}

.display-option.active i,
.display-option.active span {
    color: var(--primary);
}

.shortcode-preview {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 12px;
    background: var(--bg-surface);
    border: 1px solid var(--border);
    border-radius: 6px;
    margin-bottom: 12px;
}

.shortcode-preview label {
    font-size: 11px;
    font-weight: 500;
    color: var(--text-muted);
    white-space: nowrap;
}

.shortcode-output {
    flex: 1;
    font-size: 12px;
    color: var(--primary);
    background: transparent;
    word-break: break-all;
}

.btn-copy {
    padding: 6px 10px;
    background: var(--bg-secondary);
    border: 1px solid var(--border);
    border-radius: 4px;
    cursor: pointer;
    color: var(--text-secondary);
}

.btn-copy:hover {
    background: var(--bg-hover);
    color: var(--primary);
}

.display-note {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 11px;
    color: var(--text-muted);
}

.display-note i {
    color: var(--color-info);
}

/* Shortcode Panel */
.shortcode-panel {
    width: 260px;
    border-left: 1px solid var(--border);
    display: flex;
    flex-direction: column;
    background: #1e293b;
}

.shortcode-panel-header {
    padding: 12px;
    border-bottom: 1px solid rgba(255,255,255,0.1);
}

.shortcode-panel-header h4 {
    margin: 0 0 10px 0;
    font-size: 13px;
    font-weight: 600;
    color: #fff;
    display: flex;
    align-items: center;
    gap: 6px;
}

.shortcode-search {
    width: 100%;
    padding: 8px 10px;
    background: rgba(255,255,255,0.08);
    border: 1px solid rgba(255,255,255,0.15);
    border-radius: 4px;
    font-size: 12px;
    color: #fff;
}

.shortcode-search::placeholder {
    color: rgba(255,255,255,0.4);
}

.shortcode-search:focus {
    outline: none;
    border-color: var(--primary);
    background: rgba(255,255,255,0.12);
}

/* Accordion */
.shortcode-accordion {
    flex: 1;
    overflow-y: auto;
}

.accordion-item {
    border-bottom: 1px solid rgba(255,255,255,0.08);
}

.accordion-header {
    width: 100%;
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px 12px;
    background: transparent;
    border: none;
    cursor: pointer;
    color: rgba(255,255,255,0.7);
    font-size: 12px;
    text-align: left;
    transition: all 0.15s ease;
}

.accordion-header:hover {
    background: rgba(255,255,255,0.05);
    color: #fff;
}

.accordion-header.expanded {
    background: rgba(255,255,255,0.08);
    color: #fff;
}

.accordion-title {
    flex: 1;
    font-weight: 600;
}

.accordion-count {
    font-size: 10px;
    padding: 2px 6px;
    background: rgba(255,255,255,0.15);
    border-radius: 10px;
}

.accordion-header i {
    font-size: 10px;
    opacity: 0.5;
}

.accordion-content {
    background: rgba(0,0,0,0.2);
    overflow: hidden;
}

.shortcode-item {
    display: flex;
    flex-direction: column;
    gap: 2px;
    padding: 8px 12px 8px 20px;
    cursor: pointer;
    border-left: 2px solid transparent;
    transition: all 0.15s ease;
}

.shortcode-item:hover {
    background: rgba(255,255,255,0.05);
    border-left-color: var(--primary);
}

.shortcode-item code {
    font-size: 11px;
    font-weight: 600;
    color: #60a5fa;
    background: transparent;
}

.shortcode-item span {
    font-size: 10px;
    color: rgba(255,255,255,0.5);
}

/* Footer */
.modal-footer {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 16px;
    background: var(--bg-secondary);
    border-top: 1px solid var(--border);
}

.footer-left,
.footer-right {
    display: flex;
    gap: 6px;
}

.btn-sm {
    padding: 6px 10px;
    font-size: 12px;
}

/* Animation */
@keyframes spin {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}

.animate-spin {
    animation: spin 1s linear infinite;
}

/* Accordion animation */
.accordion-enter {
    transition: all 0.15s ease-out;
}
.accordion-enter-start {
    opacity: 0;
    max-height: 0;
}
.accordion-enter-end {
    opacity: 1;
    max-height: 500px;
}
.accordion-leave {
    transition: all 0.1s ease-in;
}
.accordion-leave-start {
    opacity: 1;
    max-height: 500px;
}
.accordion-leave-end {
    opacity: 0;
    max-height: 0;
}

</style>
