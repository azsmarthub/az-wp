<?php
/**
 * Cron Settings Modal - Consolidated Cron Management
 *
 * Layout:
 * 1. System Status — compact queue + AI stats
 * 2. Server Cron Jobs (expanded) — 14 HTTP endpoints in 3 tiers
 * 3. Cron Logs — 12 tabs grouped by Pipeline / AI Gen / Maintenance (20 entries each)
 *
 * @package AffiliateCMS\Pro
 */

if (!defined('ABSPATH')) {
    exit;
}

// Get or generate unified API token for all cron endpoints
$api_token = get_option('acms_api_token', '');
if (empty($api_token)) {
    $api_token = wp_generate_password(32, false, false);
    update_option('acms_api_token', $api_token);
}

$rest_url = rest_url('acms/v1/');
$rest_url_cat = rest_url('acms-cat/v1/');

// Base URLs without token (for dynamic generation in JS)
$cron_base_urls = [
    'scrape' => $rest_url . 'automation/scrape',
    'process' => $rest_url . 'automation/process-scheduled',
    'product_ai' => $rest_url . 'cron/product-ai',
    'post_ai' => $rest_url . 'cron/post-ai',
    'quick_update' => $rest_url . 'cron/quick-update',
    'scrape_monitor' => $rest_url . 'cron/scrape-monitor',
    'cat_queue_processor' => $rest_url_cat . 'cron/queue-processor',
    'cat_queue_monitor' => $rest_url_cat . 'cron/queue-monitor',
    'category_ai' => $rest_url_cat . 'cron/category-ai',
    'brand_ai' => $rest_url . 'cron/brand-ai',
    'process_category_ai' => $rest_url_cat . 'cron/process-category-ai',
    'brand_category_ai' => $rest_url_cat . 'cron/brand-category-ai',
    'retry_stuck' => $rest_url_cat . 'cron/retry-stuck',
    'date_update' => $rest_url . 'cron/date-update',
    'backfill_links' => $rest_url_cat . 'cron/backfill-category-links',
    'cache_preload' => $rest_url . 'cache/preload',
    'smart_refresh' => $rest_url . 'cache/smart-refresh',
    'resume_queue' => $rest_url . 'cache/resume-queue',
    'bulk_update_worker' => $rest_url_cat . 'cron/bulk-update-worker',
];
?>
<!-- Cron Settings Modal -->
<div class="modal-backdrop" x-show="showCronModal" x-cloak @click.self="showCronModal = false"
     x-transition:enter="transition ease-out duration-200"
     x-transition:enter-start="opacity-0"
     x-transition:enter-end="opacity-100"
     x-transition:leave="transition ease-in duration-150"
     x-transition:leave-start="opacity-100"
     x-transition:leave-end="opacity-0">
    <div class="modal modal-xl" @click.stop x-data="cronSettingsModal()" x-init="init()" style="max-width: 900px;">
        <div class="modal-header">
            <h2 class="modal-title">
                <i class="bi bi-clock-history"></i>
                Cron & Queue Management
            </h2>
            <button class="btn-icon" @click="showCronModal = false">
                <i class="bi bi-x-lg"></i>
            </button>
        </div>
        <div class="modal-body" style="max-height: 75vh; overflow-y: auto;">
            <div>
                <!-- ============================================
                     COMBINED STATUS (Queue + AI) - Compact
                     ============================================ -->
                <div class="combined-status-section" style="margin-bottom: 20px; padding: 14px; background: var(--bg-base); border: 1px solid var(--border); border-radius: var(--radius-md);">
                    <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px;">
                        <span style="font-weight: 600; font-size: 13px; color: var(--text-primary);">
                            <i class="bi bi-activity" style="color: var(--primary);"></i> System Status
                        </span>
                        <button type="button" class="btn btn-sm btn-secondary" @click="refreshStatus()" :disabled="isRefreshing" style="padding: 4px 8px; font-size: 11px;">
                            <i class="bi" :class="isRefreshing ? 'bi-arrow-repeat animate-spin' : 'bi-arrow-clockwise'"></i>
                        </button>
                    </div>

                    <!-- Row 1: Queue + Product (2 columns) -->
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 10px; padding-bottom: 10px; border-bottom: 1px solid var(--border);">
                        <!-- Queue Stats -->
                        <div style="display: flex; gap: 12px; flex-wrap: wrap; align-items: start;">
                            <span style="font-size: 11px; color: var(--text-muted); min-width: 50px; padding-top: 2px;">Queue:</span>
                            <div style="display: flex; gap: 8px; flex-wrap: wrap; flex: 1;">
                                <span style="font-size: 12px;"><strong x-text="queueStats.pending || 0"></strong> <span style="color: var(--text-muted);">pending</span></span>
                                <span style="font-size: 12px;"><strong x-text="queueStats.scheduled || 0"></strong> <span style="color: var(--text-muted);">scheduled</span></span>
                                <span style="font-size: 12px; color: var(--info);"><strong x-text="queueStats.processing || 0"></strong> processing</span>
                                <span style="font-size: 12px; color: var(--success);"><strong x-text="queueStats.scraped || 0"></strong> scraped</span>
                                <span style="font-size: 12px; color: var(--error);"><strong x-text="queueStats.failed || 0"></strong> failed</span>
                                <span x-show="(queueStats.update || 0) + (queueStats.updating || 0) > 0" style="font-size: 12px; color: var(--warning);"><strong x-text="(queueStats.update || 0) + (queueStats.updating || 0)"></strong> updating</span>
                            </div>
                        </div>
                        <!-- Product AI -->
                        <div style="display: flex; gap: 12px; flex-wrap: wrap; align-items: start;">
                            <span style="font-size: 11px; color: var(--text-muted); min-width: 60px; padding-top: 2px;">Product:</span>
                            <div style="display: flex; gap: 8px; flex-wrap: wrap; flex: 1;">
                                <span style="font-size: 12px; color: var(--warning);"><strong x-text="aiStats.product?.queued || 0"></strong> queued</span>
                                <span style="font-size: 12px; color: var(--success);"><strong x-text="aiStats.product?.generated || 0"></strong> generated</span>
                                <span style="font-size: 12px; color: var(--error);"><strong x-text="aiStats.product?.failed || 0"></strong> failed</span>
                            </div>
                        </div>
                    </div>

                    <!-- Row 2: Post + Category (2 columns) -->
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                        <!-- Post AI -->
                        <div style="display: flex; gap: 12px; flex-wrap: wrap; align-items: start;">
                            <span style="font-size: 11px; color: var(--text-muted); min-width: 50px; padding-top: 2px;">Post:</span>
                            <div style="display: flex; gap: 8px; flex-wrap: wrap; flex: 1;">
                                <span style="font-size: 12px; color: var(--warning);"><strong x-text="aiStats.post?.queued || 0"></strong> queued</span>
                                <span style="font-size: 12px; color: var(--success);"><strong x-text="aiStats.post?.generated || 0"></strong> generated</span>
                                <span style="font-size: 12px; color: var(--error);"><strong x-text="aiStats.post?.failed || 0"></strong> failed</span>
                            </div>
                        </div>
                        <!-- Category AI -->
                        <div style="display: flex; gap: 12px; flex-wrap: wrap; align-items: start;">
                            <span style="font-size: 11px; color: var(--text-muted); min-width: 60px; padding-top: 2px;">Category:</span>
                            <div style="display: flex; gap: 8px; flex-wrap: wrap; flex: 1;">
                                <span style="font-size: 12px;"><strong x-text="aiStats.category?.empty || 0"></strong> <span style="color: var(--text-muted);">pending</span></span>
                                <span style="font-size: 12px; color: var(--success);"><strong x-text="aiStats.category?.generated || 0"></strong> generated</span>
                                <span style="font-size: 12px; color: var(--error);"><strong x-text="aiStats.category?.failed || 0"></strong> failed</span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- ============================================
                     CRON ENDPOINTS ACCORDION
                     ============================================ -->
                <div class="automation-accordion">
                    <!-- SERVER CRON JOBS (expanded by default) -->
                    <div class="accordion-section" :class="{ 'is-expanded': expandedSection === 'cron-jobs' }">
                        <button type="button" class="accordion-trigger" @click="toggleSection('cron-jobs')">
                            <div class="accordion-trigger-content">
                                <i class="bi bi-terminal accordion-icon"></i>
                                <div class="accordion-trigger-text">
                                    <span class="accordion-title">Server Cron Jobs</span>
                                    <span class="accordion-desc">15 HTTP endpoints managed by external cron server</span>
                                </div>
                            </div>
                            <i class="bi bi-chevron-down accordion-arrow"></i>
                        </button>
                        <div class="accordion-content" x-show="expandedSection === 'cron-jobs'" x-collapse>
                            <div class="accordion-body">
                                <!-- Tier 1: Pipeline (Critical Path) -->
                                <div style="margin-top: 8px; margin-bottom: 4px; font-size: 11px; font-weight: 600; text-transform: uppercase; color: var(--error); letter-spacing: 0.5px;">Tier 1: Pipeline (*/2 min, lock=90s)</div>
                                <div class="cron-jobs-list" style="display: flex; flex-direction: column; gap: 6px;">
                                    <!-- Check & Mark -->
                                    <div class="cron-job-item" style="display: flex; align-items: center; justify-content: space-between; padding: 12px 14px; background: var(--bg-base); border: 1px solid var(--border); border-radius: var(--radius-md);">
                                        <div style="display: flex; align-items: center; gap: 12px;">
                                            <i class="bi bi-search" style="font-size: 16px; color: var(--primary);"></i>
                                            <div>
                                                <div style="font-weight: 500; font-size: 13px;">Check & Mark</div>
                                                <code style="font-size: 11px; color: var(--text-secondary);">*/2 * * * *</code>
                                            </div>
                                        </div>
                                        <div style="display: flex; gap: 6px;">
                                            <button class="btn btn-secondary btn-sm" @click="runCron('scrape')" :disabled="runningCron === 'scrape'" title="Run now">
                                                <i class="bi" :class="runningCron === 'scrape' ? 'bi-arrow-repeat animate-spin' : 'bi-play'"></i>
                                            </button>
                                            <button class="btn btn-secondary btn-sm" @click="copyUrl(cronUrls.scrape, 'checkMark')" :class="{ 'btn-success': copied.checkMark }" title="Copy URL">
                                                <i class="bi" :class="copied.checkMark ? 'bi-check' : 'bi-copy'"></i>
                                            </button>
                                        </div>
                                    </div>

                                    <!-- Process Scrape -->
                                    <div class="cron-job-item" style="display: flex; align-items: center; justify-content: space-between; padding: 12px 14px; background: var(--bg-base); border: 1px solid var(--border); border-radius: var(--radius-md);">
                                        <div style="display: flex; align-items: center; gap: 12px;">
                                            <i class="bi bi-cloud-download" style="font-size: 16px; color: var(--warning);"></i>
                                            <div>
                                                <div style="font-weight: 500; font-size: 13px;">Process Scrape</div>
                                                <code style="font-size: 11px; color: var(--text-secondary);">*/2 * * * *</code>
                                            </div>
                                        </div>
                                        <div style="display: flex; gap: 6px;">
                                            <button class="btn btn-secondary btn-sm" @click="runCron('process')" :disabled="runningCron === 'process'" title="Run now">
                                                <i class="bi" :class="runningCron === 'process' ? 'bi-arrow-repeat animate-spin' : 'bi-play'"></i>
                                            </button>
                                            <button class="btn btn-secondary btn-sm" @click="copyUrl(cronUrls.process, 'process')" :class="{ 'btn-success': copied.process }" title="Copy URL">
                                                <i class="bi" :class="copied.process ? 'bi-check' : 'bi-copy'"></i>
                                            </button>
                                        </div>
                                    </div>

                                    <!-- Scrape Monitor -->
                                    <div class="cron-job-item" style="display: flex; align-items: center; justify-content: space-between; padding: 12px 14px; background: var(--bg-base); border: 1px solid var(--border); border-radius: var(--radius-md);">
                                        <div style="display: flex; align-items: center; gap: 12px;">
                                            <i class="bi bi-binoculars" style="font-size: 16px; color: var(--info);"></i>
                                            <div>
                                                <div style="font-weight: 500; font-size: 13px;">Scrape Monitor</div>
                                                <code style="font-size: 11px; color: var(--text-secondary);">*/2 * * * *</code>
                                            </div>
                                        </div>
                                        <div style="display: flex; gap: 6px;">
                                            <button class="btn btn-secondary btn-sm" @click="runCron('scrape-monitor')" :disabled="runningCron === 'scrape-monitor'" title="Run now">
                                                <i class="bi" :class="runningCron === 'scrape-monitor' ? 'bi-arrow-repeat animate-spin' : 'bi-play'"></i>
                                            </button>
                                            <button class="btn btn-secondary btn-sm" @click="copyUrl(cronUrls.scrape_monitor, 'scrapeMonitor')" :class="{ 'btn-success': copied.scrapeMonitor }" title="Copy URL">
                                                <i class="bi" :class="copied.scrapeMonitor ? 'bi-check' : 'bi-copy'"></i>
                                            </button>
                                        </div>
                                    </div>

                                    <!-- Cat Queue Processor -->
                                    <div class="cron-job-item" style="display: flex; align-items: center; justify-content: space-between; padding: 12px 14px; background: var(--bg-base); border: 1px solid var(--border); border-radius: var(--radius-md);">
                                        <div style="display: flex; align-items: center; gap: 12px;">
                                            <i class="bi bi-list-task" style="font-size: 16px; color: var(--success);"></i>
                                            <div>
                                                <div style="font-weight: 500; font-size: 13px;">Cat Queue Processor</div>
                                                <code style="font-size: 11px; color: var(--text-secondary);">*/2 * * * *</code>
                                            </div>
                                        </div>
                                        <div style="display: flex; gap: 6px;">
                                            <button class="btn btn-secondary btn-sm" @click="runCron('cat-queue-processor')" :disabled="runningCron === 'cat-queue-processor'" title="Run now">
                                                <i class="bi" :class="runningCron === 'cat-queue-processor' ? 'bi-arrow-repeat animate-spin' : 'bi-play'"></i>
                                            </button>
                                            <button class="btn btn-secondary btn-sm" @click="copyUrl(cronUrls.cat_queue_processor, 'catQueueProcessor')" :class="{ 'btn-success': copied.catQueueProcessor }" title="Copy URL">
                                                <i class="bi" :class="copied.catQueueProcessor ? 'bi-check' : 'bi-copy'"></i>
                                            </button>
                                        </div>
                                    </div>

                                    <!-- Cat Queue Monitor -->
                                    <div class="cron-job-item" style="display: flex; align-items: center; justify-content: space-between; padding: 12px 14px; background: var(--bg-base); border: 1px solid var(--border); border-radius: var(--radius-md);">
                                        <div style="display: flex; align-items: center; gap: 12px;">
                                            <i class="bi bi-clipboard-check" style="font-size: 16px; color: var(--warning);"></i>
                                            <div>
                                                <div style="font-weight: 500; font-size: 13px;">Cat Queue Monitor</div>
                                                <code style="font-size: 11px; color: var(--text-secondary);">*/2 * * * *</code>
                                            </div>
                                        </div>
                                        <div style="display: flex; gap: 6px;">
                                            <button class="btn btn-secondary btn-sm" @click="runCron('cat-queue-monitor')" :disabled="runningCron === 'cat-queue-monitor'" title="Run now">
                                                <i class="bi" :class="runningCron === 'cat-queue-monitor' ? 'bi-arrow-repeat animate-spin' : 'bi-play'"></i>
                                            </button>
                                            <button class="btn btn-secondary btn-sm" @click="copyUrl(cronUrls.cat_queue_monitor, 'catQueueMonitor')" :class="{ 'btn-success': copied.catQueueMonitor }" title="Copy URL">
                                                <i class="bi" :class="copied.catQueueMonitor ? 'bi-check' : 'bi-copy'"></i>
                                            </button>
                                        </div>
                                    </div>

                                    <!-- Process Category AI -->
                                    <div class="cron-job-item" style="display: flex; align-items: center; justify-content: space-between; padding: 12px 14px; background: var(--bg-base); border: 1px solid var(--border); border-radius: var(--radius-md);">
                                        <div style="display: flex; align-items: center; gap: 12px;">
                                            <i class="bi bi-diagram-3" style="font-size: 16px; color: var(--accent);"></i>
                                            <div>
                                                <div style="font-weight: 500; font-size: 13px;">Process Category AI</div>
                                                <code style="font-size: 11px; color: var(--text-secondary);">*/2 * * * *</code>
                                            </div>
                                        </div>
                                        <div style="display: flex; gap: 6px;">
                                            <button class="btn btn-secondary btn-sm" @click="runCron('process-category-ai')" :disabled="runningCron === 'process-category-ai'" title="Run now">
                                                <i class="bi" :class="runningCron === 'process-category-ai' ? 'bi-arrow-repeat animate-spin' : 'bi-play'"></i>
                                            </button>
                                            <button class="btn btn-secondary btn-sm" @click="copyUrl(cronUrls.process_category_ai, 'processCategoryAi')" :class="{ 'btn-success': copied.processCategoryAi }" title="Copy URL">
                                                <i class="bi" :class="copied.processCategoryAi ? 'bi-check' : 'bi-copy'"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>

                                <!-- Tier 2: AI Generation -->
                                <div style="margin-top: 16px; margin-bottom: 4px; font-size: 11px; font-weight: 600; text-transform: uppercase; color: var(--warning); letter-spacing: 0.5px;">Tier 2: AI Generation (*/5 min, lock=240s)</div>
                                <div class="cron-jobs-list" style="display: flex; flex-direction: column; gap: 6px;">
                                    <!-- Product AI -->
                                    <div class="cron-job-item" style="display: flex; align-items: center; justify-content: space-between; padding: 12px 14px; background: var(--bg-base); border: 1px solid var(--border); border-radius: var(--radius-md);">
                                        <div style="display: flex; align-items: center; gap: 12px;">
                                            <i class="bi bi-box-seam" style="font-size: 16px; color: var(--accent);"></i>
                                            <div>
                                                <div style="font-weight: 500; font-size: 13px;">Product AI</div>
                                                <code style="font-size: 11px; color: var(--text-secondary);">*/5 * * * *</code>
                                            </div>
                                        </div>
                                        <div style="display: flex; gap: 6px;">
                                            <button class="btn btn-secondary btn-sm" @click="runCron('product-ai')" :disabled="runningCron === 'product-ai'" title="Run now">
                                                <i class="bi" :class="runningCron === 'product-ai' ? 'bi-arrow-repeat animate-spin' : 'bi-play'"></i>
                                            </button>
                                            <button class="btn btn-secondary btn-sm" @click="copyUrl(cronUrls.product_ai, 'productAi')" :class="{ 'btn-success': copied.productAi }" title="Copy URL">
                                                <i class="bi" :class="copied.productAi ? 'bi-check' : 'bi-copy'"></i>
                                            </button>
                                        </div>
                                    </div>

                                    <!-- Post AI -->
                                    <div class="cron-job-item" style="display: flex; align-items: center; justify-content: space-between; padding: 12px 14px; background: var(--bg-base); border: 1px solid var(--border); border-radius: var(--radius-md);">
                                        <div style="display: flex; align-items: center; gap: 12px;">
                                            <i class="bi bi-file-earmark-post" style="font-size: 16px; color: var(--info);"></i>
                                            <div>
                                                <div style="font-weight: 500; font-size: 13px;">Post AI</div>
                                                <code style="font-size: 11px; color: var(--text-secondary);">*/5 * * * *</code>
                                            </div>
                                        </div>
                                        <div style="display: flex; gap: 6px;">
                                            <button class="btn btn-secondary btn-sm" @click="runCron('post-ai')" :disabled="runningCron === 'post-ai'" title="Run now">
                                                <i class="bi" :class="runningCron === 'post-ai' ? 'bi-arrow-repeat animate-spin' : 'bi-play'"></i>
                                            </button>
                                            <button class="btn btn-secondary btn-sm" @click="copyUrl(cronUrls.post_ai, 'postAi')" :class="{ 'btn-success': copied.postAi }" title="Copy URL">
                                                <i class="bi" :class="copied.postAi ? 'bi-check' : 'bi-copy'"></i>
                                            </button>
                                        </div>
                                    </div>

                                    <!-- Category AI -->
                                    <div class="cron-job-item" style="display: flex; align-items: center; justify-content: space-between; padding: 12px 14px; background: var(--bg-base); border: 1px solid var(--border); border-radius: var(--radius-md);">
                                        <div style="display: flex; align-items: center; gap: 12px;">
                                            <i class="bi bi-folder-symlink" style="font-size: 16px; color: var(--accent);"></i>
                                            <div>
                                                <div style="font-weight: 500; font-size: 13px;">Category AI</div>
                                                <code style="font-size: 11px; color: var(--text-secondary);">*/5 * * * *</code>
                                            </div>
                                        </div>
                                        <div style="display: flex; gap: 6px;">
                                            <button class="btn btn-secondary btn-sm" @click="runCron('category-ai')" :disabled="runningCron === 'category-ai'" title="Run now">
                                                <i class="bi" :class="runningCron === 'category-ai' ? 'bi-arrow-repeat animate-spin' : 'bi-play'"></i>
                                            </button>
                                            <button class="btn btn-secondary btn-sm" @click="copyUrl(cronUrls.category_ai, 'categoryAi')" :class="{ 'btn-success': copied.categoryAi }" title="Copy URL">
                                                <i class="bi" :class="copied.categoryAi ? 'bi-check' : 'bi-copy'"></i>
                                            </button>
                                        </div>
                                    </div>

                                    <!-- Brand AI -->
                                    <div class="cron-job-item" style="display: flex; align-items: center; justify-content: space-between; padding: 12px 14px; background: var(--bg-base); border: 1px solid var(--border); border-radius: var(--radius-md);">
                                        <div style="display: flex; align-items: center; gap: 12px;">
                                            <i class="bi bi-tag" style="font-size: 16px; color: var(--primary);"></i>
                                            <div>
                                                <div style="font-weight: 500; font-size: 13px;">Brand AI</div>
                                                <code style="font-size: 11px; color: var(--text-secondary);">*/5 * * * *</code>
                                            </div>
                                        </div>
                                        <div style="display: flex; gap: 6px;">
                                            <button class="btn btn-secondary btn-sm" @click="runCron('brand-ai')" :disabled="runningCron === 'brand-ai'" title="Run now">
                                                <i class="bi" :class="runningCron === 'brand-ai' ? 'bi-arrow-repeat animate-spin' : 'bi-play'"></i>
                                            </button>
                                            <button class="btn btn-secondary btn-sm" @click="copyUrl(cronUrls.brand_ai, 'brandAi')" :class="{ 'btn-success': copied.brandAi }" title="Copy URL">
                                                <i class="bi" :class="copied.brandAi ? 'bi-check' : 'bi-copy'"></i>
                                            </button>
                                        </div>
                                    </div>

                                    <!-- Brand-Category AI -->
                                    <div class="cron-job-item" style="display: flex; align-items: center; justify-content: space-between; padding: 12px 14px; background: var(--bg-base); border: 1px solid var(--border); border-radius: var(--radius-md);">
                                        <div style="display: flex; align-items: center; gap: 12px;">
                                            <i class="bi bi-collection" style="font-size: 16px; color: var(--success);"></i>
                                            <div>
                                                <div style="font-weight: 500; font-size: 13px;">Brand-Category AI</div>
                                                <code style="font-size: 11px; color: var(--text-secondary);">*/5 * * * *</code>
                                            </div>
                                        </div>
                                        <div style="display: flex; gap: 6px;">
                                            <button class="btn btn-secondary btn-sm" @click="runCron('brand-category-ai')" :disabled="runningCron === 'brand-category-ai'" title="Run now">
                                                <i class="bi" :class="runningCron === 'brand-category-ai' ? 'bi-arrow-repeat animate-spin' : 'bi-play'"></i>
                                            </button>
                                            <button class="btn btn-secondary btn-sm" @click="copyUrl(cronUrls.brand_category_ai, 'brandCategoryAi')" :class="{ 'btn-success': copied.brandCategoryAi }" title="Copy URL">
                                                <i class="bi" :class="copied.brandCategoryAi ? 'bi-check' : 'bi-copy'"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>

                                <!-- Tier 3: Maintenance -->
                                <div style="margin-top: 16px; margin-bottom: 4px; font-size: 11px; font-weight: 600; text-transform: uppercase; color: var(--text-secondary); letter-spacing: 0.5px;">Tier 3: Maintenance</div>
                                <div class="cron-jobs-list" style="display: flex; flex-direction: column; gap: 6px;">
                                    <!-- Auto Update (price/rating/stock) -->
                                    <div class="cron-job-item" style="display: flex; align-items: center; justify-content: space-between; padding: 12px 14px; background: var(--bg-base); border: 1px solid var(--border); border-radius: var(--radius-md);">
                                        <div style="display: flex; align-items: center; gap: 12px;">
                                            <i class="bi bi-arrow-repeat" style="font-size: 16px; color: var(--success);"></i>
                                            <div>
                                                <div style="font-weight: 500; font-size: 13px;">Auto Update</div>
                                                <code style="font-size: 11px; color: var(--text-secondary);">*/30 * * * *</code>
                                            </div>
                                        </div>
                                        <div style="display: flex; gap: 6px;">
                                            <button class="btn btn-secondary btn-sm" @click="runCron('quick-update')" :disabled="runningCron === 'quick-update'" title="Run now">
                                                <i class="bi" :class="runningCron === 'quick-update' ? 'bi-arrow-repeat animate-spin' : 'bi-play'"></i>
                                            </button>
                                            <button class="btn btn-secondary btn-sm" @click="copyUrl(cronUrls.quick_update, 'quickUpdate')" :class="{ 'btn-success': copied.quickUpdate }" title="Copy URL">
                                                <i class="bi" :class="copied.quickUpdate ? 'bi-check' : 'bi-copy'"></i>
                                            </button>
                                        </div>
                                    </div>

                                    <!-- Retry Stuck -->
                                    <div class="cron-job-item" style="display: flex; align-items: center; justify-content: space-between; padding: 12px 14px; background: var(--bg-base); border: 1px solid var(--border); border-radius: var(--radius-md);">
                                        <div style="display: flex; align-items: center; gap: 12px;">
                                            <i class="bi bi-bandaid" style="font-size: 16px; color: var(--error);"></i>
                                            <div>
                                                <div style="font-weight: 500; font-size: 13px;">Retry Stuck</div>
                                                <code style="font-size: 11px; color: var(--text-secondary);">*/10 * * * *</code>
                                            </div>
                                        </div>
                                        <div style="display: flex; gap: 6px;">
                                            <button class="btn btn-secondary btn-sm" @click="runCron('retry-stuck')" :disabled="runningCron === 'retry-stuck'" title="Run now">
                                                <i class="bi" :class="runningCron === 'retry-stuck' ? 'bi-arrow-repeat animate-spin' : 'bi-play'"></i>
                                            </button>
                                            <button class="btn btn-secondary btn-sm" @click="copyUrl(cronUrls.retry_stuck, 'retryStuck')" :class="{ 'btn-success': copied.retryStuck }" title="Copy URL">
                                                <i class="bi" :class="copied.retryStuck ? 'bi-check' : 'bi-copy'"></i>
                                            </button>
                                        </div>
                                    </div>

                                    <!-- Date Update (daily) -->
                                    <div class="cron-job-item" style="display: flex; align-items: center; justify-content: space-between; padding: 12px 14px; background: var(--bg-base); border: 1px solid var(--border); border-radius: var(--radius-md);">
                                        <div style="display: flex; align-items: center; gap: 12px;">
                                            <i class="bi bi-calendar-date" style="font-size: 16px; color: var(--info);"></i>
                                            <div>
                                                <div style="font-weight: 500; font-size: 13px;">Date Update</div>
                                                <code style="font-size: 11px; color: var(--text-secondary);">0 3 * * *</code>
                                            </div>
                                        </div>
                                        <div style="display: flex; gap: 6px;">
                                            <button class="btn btn-secondary btn-sm" @click="runCron('date-update')" :disabled="runningCron === 'date-update'" title="Run now">
                                                <i class="bi" :class="runningCron === 'date-update' ? 'bi-arrow-repeat animate-spin' : 'bi-play'"></i>
                                            </button>
                                            <button class="btn btn-secondary btn-sm" @click="copyUrl(cronUrls.date_update, 'dateUpdate')" :class="{ 'btn-success': copied.dateUpdate }" title="Copy URL">
                                                <i class="bi" :class="copied.dateUpdate ? 'bi-check' : 'bi-copy'"></i>
                                            </button>
                                        </div>
                                    </div>

                                    <!-- Backfill Category Links (on-demand) -->
                                    <div class="cron-job-item" style="display: flex; align-items: center; justify-content: space-between; padding: 12px 14px; background: var(--bg-base); border: 1px solid var(--border); border-radius: var(--radius-md);">
                                        <div style="display: flex; align-items: center; gap: 12px;">
                                            <i class="bi bi-link-45deg" style="font-size: 16px; color: var(--accent);"></i>
                                            <div>
                                                <div style="font-weight: 500; font-size: 13px;">Backfill Links</div>
                                                <code style="font-size: 11px; color: var(--text-secondary);">on-demand</code>
                                            </div>
                                        </div>
                                        <div style="display: flex; gap: 6px;">
                                            <button class="btn btn-secondary btn-sm" @click="runCron('backfill-links')" :disabled="runningCron === 'backfill-links'" title="Run now">
                                                <i class="bi" :class="runningCron === 'backfill-links' ? 'bi-arrow-repeat animate-spin' : 'bi-play'"></i>
                                            </button>
                                            <button class="btn btn-secondary btn-sm" @click="copyUrl(cronUrls.backfill_links, 'backfillLinks')" :class="{ 'btn-success': copied.backfillLinks }" title="Copy URL">
                                                <i class="bi" :class="copied.backfillLinks ? 'bi-check' : 'bi-copy'"></i>
                                            </button>
                                        </div>
                                    </div>

                                    <!-- Cache Full Rebuild (weekly) -->
                                    <div class="cron-job-item" style="display: flex; align-items: center; justify-content: space-between; padding: 12px 14px; background: var(--bg-base); border: 1px solid var(--border); border-radius: var(--radius-md);">
                                        <div style="display: flex; align-items: center; gap: 12px;">
                                            <i class="bi bi-hdd-stack" style="font-size: 16px; color: var(--success);"></i>
                                            <div>
                                                <div style="font-weight: 500; font-size: 13px;">Cache Full Rebuild</div>
                                                <code style="font-size: 11px; color: var(--text-secondary);">0 3 * * 0</code>
                                            </div>
                                        </div>
                                        <div style="display: flex; gap: 6px;">
                                            <button class="btn btn-secondary btn-sm" @click="runCron('cache-preload')" :disabled="runningCron === 'cache-preload'" title="Run now">
                                                <i class="bi" :class="runningCron === 'cache-preload' ? 'bi-arrow-repeat animate-spin' : 'bi-play'"></i>
                                            </button>
                                            <button class="btn btn-secondary btn-sm" @click="copyUrl(cronUrls.cache_preload, 'cachePreload')" :class="{ 'btn-success': copied.cachePreload }" title="Copy URL">
                                                <i class="bi" :class="copied.cachePreload ? 'bi-check' : 'bi-copy'"></i>
                                            </button>
                                        </div>
                                    </div>

                                    <!-- Smart Refresh (every 4 hours) -->
                                    <div class="cron-job-item" style="display: flex; align-items: center; justify-content: space-between; padding: 12px 14px; background: var(--bg-base); border: 1px solid var(--border); border-radius: var(--radius-md);">
                                        <div style="display: flex; align-items: center; gap: 12px;">
                                            <i class="bi bi-arrow-clockwise" style="font-size: 16px; color: var(--info);"></i>
                                            <div>
                                                <div style="font-weight: 500; font-size: 13px;">Smart Refresh</div>
                                                <code style="font-size: 11px; color: var(--text-secondary);">0 */4 * * *</code>
                                            </div>
                                        </div>
                                        <div style="display: flex; gap: 6px;">
                                            <button class="btn btn-secondary btn-sm" @click="runCron('smart-refresh')" :disabled="runningCron === 'smart-refresh'" title="Run now">
                                                <i class="bi" :class="runningCron === 'smart-refresh' ? 'bi-arrow-repeat animate-spin' : 'bi-play'"></i>
                                            </button>
                                            <button class="btn btn-secondary btn-sm" @click="copyUrl(cronUrls.smart_refresh, 'smartRefresh')" :class="{ 'btn-success': copied.smartRefresh }" title="Copy URL">
                                                <i class="bi" :class="copied.smartRefresh ? 'bi-check' : 'bi-copy'"></i>
                                            </button>
                                        </div>
                                    </div>

                                    <!-- Cache Resume Queue (every 30 min) -->
                                    <div class="cron-job-item" style="display: flex; align-items: center; justify-content: space-between; padding: 12px 14px; background: var(--bg-base); border: 1px solid var(--border); border-radius: var(--radius-md);">
                                        <div style="display: flex; align-items: center; gap: 12px;">
                                            <i class="bi bi-play-circle" style="font-size: 16px; color: var(--warning);"></i>
                                            <div>
                                                <div style="font-weight: 500; font-size: 13px;">Cache Resume Queue</div>
                                                <code style="font-size: 11px; color: var(--text-secondary);">*/30 * * * *</code>
                                            </div>
                                        </div>
                                        <div style="display: flex; gap: 6px;">
                                            <button class="btn btn-secondary btn-sm" @click="runCron('resume-queue')" :disabled="runningCron === 'resume-queue'" title="Run now">
                                                <i class="bi" :class="runningCron === 'resume-queue' ? 'bi-arrow-repeat animate-spin' : 'bi-play'"></i>
                                            </button>
                                            <button class="btn btn-secondary btn-sm" @click="copyUrl(cronUrls.resume_queue, 'resumeQueue')" :class="{ 'btn-success': copied.resumeQueue }" title="Copy URL">
                                                <i class="bi" :class="copied.resumeQueue ? 'bi-check' : 'bi-copy'"></i>
                                            </button>
                                        </div>
                                    </div>

                                    <!-- Bulk Update ASINs Worker (every minute when batch active) -->
                                    <div class="cron-job-item" style="display: flex; align-items: center; justify-content: space-between; padding: 12px 14px; background: var(--bg-base); border: 1px solid var(--border); border-radius: var(--radius-md);">
                                        <div style="display: flex; align-items: center; gap: 12px;">
                                            <i class="bi bi-arrow-repeat" style="font-size: 16px; color: var(--primary);"></i>
                                            <div>
                                                <div style="font-weight: 500; font-size: 13px;">Bulk Update ASINs</div>
                                                <code style="font-size: 11px; color: var(--text-secondary);">* * * * *</code>
                                            </div>
                                        </div>
                                        <div style="display: flex; gap: 6px;">
                                            <button class="btn btn-secondary btn-sm" @click="runCron('bulk-update-worker')" :disabled="runningCron === 'bulk-update-worker'" title="Run now">
                                                <i class="bi" :class="runningCron === 'bulk-update-worker' ? 'bi-arrow-repeat animate-spin' : 'bi-play'"></i>
                                            </button>
                                            <button class="btn btn-secondary btn-sm" @click="copyUrl(cronUrls.bulk_update_worker, 'bulkUpdateWorker')" :class="{ 'btn-success': copied.bulkUpdateWorker }" title="Copy URL">
                                                <i class="bi" :class="copied.bulkUpdateWorker ? 'bi-check' : 'bi-copy'"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>

                                <!-- API Token -->
                                <div class="form-group" style="margin-top: 20px;">
                                    <label class="form-label" style="font-size: 14px; margin-bottom: 8px;">API Token</label>
                                    <div class="input-group">
                                        <input :type="showApiToken ? 'text' : 'password'" class="input" readonly :value="apiToken" style="font-family: monospace; font-size: 13px;">
                                        <button type="button" class="btn btn-secondary" @click="showApiToken = !showApiToken" title="Show/Hide">
                                            <i class="bi" :class="showApiToken ? 'bi-eye-slash' : 'bi-eye'"></i>
                                        </button>
                                        <button type="button" class="btn btn-secondary" @click="copyUrl(apiToken, 'apiToken')" :class="{ 'btn-success': copied.apiToken }" title="Copy">
                                            <i class="bi" :class="copied.apiToken ? 'bi-check-lg' : 'bi-clipboard'"></i>
                                        </button>
                                        <button type="button" class="btn btn-secondary" @click="regenerateToken()" :disabled="regeneratingToken" title="Regenerate">
                                            <i class="bi" :class="regeneratingToken ? 'bi-arrow-repeat animate-spin' : 'bi-arrow-clockwise'"></i>
                                        </button>
                                    </div>
                                </div>

                                <!-- Unified Crontab -->
                                <div style="margin-top: 20px; position: relative;">
                                    <label class="form-label" style="font-size: 14px; margin-bottom: 8px;">Crontab</label>
                                    <pre style="background: var(--bg-surface); padding: 16px; border-radius: var(--radius-md); font-size: 12px; line-height: 1.8; border: 1px solid var(--border); margin: 0; overflow-x: auto;"><code style="color: var(--text-secondary);" x-text="getAllCrontabText()"></code></pre>
                                    <button class="btn btn-secondary btn-sm" style="position: absolute; top: 36px; right: 12px;" @click="copyAllCrontab()" :class="{ 'btn-success': copied.allCrontab }">
                                        <i class="bi" :class="copied.allCrontab ? 'bi-check' : 'bi-copy'"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- CRON LOGS -->
                    <div class="accordion-section" :class="{ 'is-expanded': expandedSection === 'logs' }">
                        <button type="button" class="accordion-trigger" @click="toggleSection('logs')">
                            <div class="accordion-trigger-content">
                                <i class="bi bi-journal-text accordion-icon"></i>
                                <div class="accordion-trigger-text">
                                    <span class="accordion-title">Cron Logs</span>
                                    <span class="accordion-desc">Recent execution history (20 entries per type)</span>
                                </div>
                            </div>
                            <i class="bi bi-chevron-down accordion-arrow"></i>
                        </button>
                        <div class="accordion-content" x-show="expandedSection === 'logs'" x-collapse>
                            <div class="accordion-body">
                                <!-- Log Group: Pipeline -->
                                <div style="margin-bottom: 6px; font-size: 10px; font-weight: 600; text-transform: uppercase; color: var(--text-muted); letter-spacing: 0.5px; padding-top: 4px;">Pipeline</div>
                                <div class="log-tabs" style="display: flex; gap: 4px; margin-bottom: 6px; flex-wrap: wrap;">
                                    <button type="button" class="btn btn-sm" style="font-size: 11px; padding: 3px 8px;" :class="logTab === 'scraping' ? 'btn-primary' : 'btn-secondary'" @click="logTab = 'scraping'">
                                        Scraping
                                        <span x-show="cronLogs.scraping?.length" style="font-size: 9px; opacity: 0.7;" x-text="'(' + (cronLogs.scraping?.length || 0) + ')'"></span>
                                    </button>
                                    <button type="button" class="btn btn-sm" style="font-size: 11px; padding: 3px 8px;" :class="logTab === 'scrape_monitor' ? 'btn-primary' : 'btn-secondary'" @click="logTab = 'scrape_monitor'">
                                        Scrape Monitor
                                        <span x-show="cronLogs.scrape_monitor?.length" style="font-size: 9px; opacity: 0.7;" x-text="'(' + (cronLogs.scrape_monitor?.length || 0) + ')'"></span>
                                    </button>
                                    <button type="button" class="btn btn-sm" style="font-size: 11px; padding: 3px 8px;" :class="logTab === 'cat_queue' ? 'btn-primary' : 'btn-secondary'" @click="logTab = 'cat_queue'">
                                        Cat Queue
                                        <span x-show="cronLogs.cat_queue?.length" style="font-size: 9px; opacity: 0.7;" x-text="'(' + (cronLogs.cat_queue?.length || 0) + ')'"></span>
                                    </button>
                                    <button type="button" class="btn btn-sm" style="font-size: 11px; padding: 3px 8px;" :class="logTab === 'cat_monitor' ? 'btn-primary' : 'btn-secondary'" @click="logTab = 'cat_monitor'">
                                        Cat Monitor
                                        <span x-show="cronLogs.cat_monitor?.length" style="font-size: 9px; opacity: 0.7;" x-text="'(' + (cronLogs.cat_monitor?.length || 0) + ')'"></span>
                                    </button>
                                    <button type="button" class="btn btn-sm" style="font-size: 11px; padding: 3px 8px;" :class="logTab === 'process_category_ai' ? 'btn-primary' : 'btn-secondary'" @click="logTab = 'process_category_ai'">
                                        Process Cat AI
                                        <span x-show="cronLogs.process_category_ai?.length" style="font-size: 9px; opacity: 0.7;" x-text="'(' + (cronLogs.process_category_ai?.length || 0) + ')'"></span>
                                    </button>
                                </div>

                                <!-- Log Group: AI Generation -->
                                <div style="margin-bottom: 6px; font-size: 10px; font-weight: 600; text-transform: uppercase; color: var(--text-muted); letter-spacing: 0.5px;">AI Generation</div>
                                <div class="log-tabs" style="display: flex; gap: 4px; margin-bottom: 6px; flex-wrap: wrap;">
                                    <button type="button" class="btn btn-sm" style="font-size: 11px; padding: 3px 8px;" :class="logTab === 'product_ai' ? 'btn-primary' : 'btn-secondary'" @click="logTab = 'product_ai'">
                                        Product AI
                                        <span x-show="cronLogs.product_ai?.length" style="font-size: 9px; opacity: 0.7;" x-text="'(' + (cronLogs.product_ai?.length || 0) + ')'"></span>
                                    </button>
                                    <button type="button" class="btn btn-sm" style="font-size: 11px; padding: 3px 8px;" :class="logTab === 'post_ai' ? 'btn-primary' : 'btn-secondary'" @click="logTab = 'post_ai'">
                                        Post AI
                                        <span x-show="cronLogs.post_ai?.length" style="font-size: 9px; opacity: 0.7;" x-text="'(' + (cronLogs.post_ai?.length || 0) + ')'"></span>
                                    </button>
                                    <button type="button" class="btn btn-sm" style="font-size: 11px; padding: 3px 8px;" :class="logTab === 'category_ai' ? 'btn-primary' : 'btn-secondary'" @click="logTab = 'category_ai'">
                                        Category AI
                                        <span x-show="cronLogs.category_ai?.length" style="font-size: 9px; opacity: 0.7;" x-text="'(' + (cronLogs.category_ai?.length || 0) + ')'"></span>
                                    </button>
                                    <button type="button" class="btn btn-sm" style="font-size: 11px; padding: 3px 8px;" :class="logTab === 'brand_ai' ? 'btn-primary' : 'btn-secondary'" @click="logTab = 'brand_ai'">
                                        Brand AI
                                        <span x-show="cronLogs.brand_ai?.length" style="font-size: 9px; opacity: 0.7;" x-text="'(' + (cronLogs.brand_ai?.length || 0) + ')'"></span>
                                    </button>
                                    <button type="button" class="btn btn-sm" style="font-size: 11px; padding: 3px 8px;" :class="logTab === 'brand_category_ai' ? 'btn-primary' : 'btn-secondary'" @click="logTab = 'brand_category_ai'">
                                        Brand-Cat AI
                                        <span x-show="cronLogs.brand_category_ai?.length" style="font-size: 9px; opacity: 0.7;" x-text="'(' + (cronLogs.brand_category_ai?.length || 0) + ')'"></span>
                                    </button>
                                </div>

                                <!-- Log Group: Maintenance -->
                                <div style="margin-bottom: 6px; font-size: 10px; font-weight: 600; text-transform: uppercase; color: var(--text-muted); letter-spacing: 0.5px;">Maintenance</div>
                                <div class="log-tabs" style="display: flex; gap: 4px; margin-bottom: 12px; flex-wrap: wrap; padding-bottom: 8px; border-bottom: 1px solid var(--border);">
                                    <button type="button" class="btn btn-sm" style="font-size: 11px; padding: 3px 8px;" :class="logTab === 'quick_update' ? 'btn-primary' : 'btn-secondary'" @click="logTab = 'quick_update'">
                                        Auto Update
                                        <span x-show="cronLogs.quick_update?.length" style="font-size: 9px; opacity: 0.7;" x-text="'(' + (cronLogs.quick_update?.length || 0) + ')'"></span>
                                    </button>
                                    <button type="button" class="btn btn-sm" style="font-size: 11px; padding: 3px 8px;" :class="logTab === 'retry_stuck' ? 'btn-primary' : 'btn-secondary'" @click="logTab = 'retry_stuck'">
                                        Retry Stuck
                                        <span x-show="cronLogs.retry_stuck?.length" style="font-size: 9px; opacity: 0.7;" x-text="'(' + (cronLogs.retry_stuck?.length || 0) + ')'"></span>
                                    </button>
                                    <button type="button" class="btn btn-sm" style="font-size: 11px; padding: 3px 8px;" :class="logTab === 'backfill_links' ? 'btn-primary' : 'btn-secondary'" @click="logTab = 'backfill_links'">
                                        Backfill Links
                                        <span x-show="cronLogs.backfill_links?.length" style="font-size: 9px; opacity: 0.7;" x-text="'(' + (cronLogs.backfill_links?.length || 0) + ')'"></span>
                                    </button>
                                </div>

                                <!-- Log Container -->
                                <div class="cron-logs-container" style="max-height: 340px; overflow-y: auto; background: var(--bg-surface); border: 1px solid var(--border); border-radius: var(--radius-sm); padding: 0; font-family: monospace; font-size: 11px;">
                                    <template x-if="cronLogs[logTab] && cronLogs[logTab].length > 0">
                                        <table style="width: 100%; border-collapse: collapse;">
                                            <template x-for="(log, index) in cronLogs[logTab]" :key="index">
                                                <tr style="border-bottom: 1px solid var(--border-subtle);" :style="log.status === 'error' ? 'background: rgba(239,68,68,0.04)' : ''">
                                                    <td style="padding: 5px 8px; white-space: nowrap; color: var(--text-tertiary); font-size: 10px; width: 60px;" x-text="log.time ? log.time.substring(11) : ''"></td>
                                                    <td style="padding: 5px 4px; width: 56px;">
                                                        <span style="padding: 1px 5px; border-radius: 3px; font-size: 9px; text-transform: uppercase; font-weight: 600;"
                                                              :style="{
                                                                  background: log.status === 'success' ? 'var(--success-bg, rgba(34,197,94,0.1))' : (log.status === 'error' ? 'var(--error-bg, rgba(239,68,68,0.1))' : (log.status === 'warning' ? 'var(--warning-bg, rgba(245,158,11,0.1))' : 'var(--info-bg, rgba(59,130,246,0.1))')),
                                                                  color: log.status === 'success' ? 'var(--success)' : (log.status === 'error' ? 'var(--error)' : (log.status === 'warning' ? 'var(--warning)' : 'var(--info)'))
                                                              }"
                                                              x-text="log.status === 'success' ? 'OK' : (log.status === 'error' ? 'ERR' : (log.status === 'warning' ? 'WARN' : 'INFO'))"></span>
                                                    </td>
                                                    <td style="padding: 5px 8px; color: var(--text-primary); font-size: 11px;">
                                                        <span x-text="log.message"></span>
                                                        <span x-show="log.details" style="color: var(--text-tertiary); font-size: 10px; margin-left: 6px;" x-text="log.details"></span>
                                                    </td>
                                                </tr>
                                            </template>
                                        </table>
                                    </template>
                                    <template x-if="!cronLogs[logTab] || cronLogs[logTab].length === 0">
                                        <div style="color: var(--text-tertiary); padding: 24px; text-align: center;">
                                            <i class="bi bi-journal-x" style="font-size: 20px; display: block; margin-bottom: 6px;"></i>
                                            <span style="font-size: 12px;">No logs yet</span>
                                        </div>
                                    </template>
                                </div>

                                <!-- Log Footer: count + clear -->
                                <div style="margin-top: 8px; display: flex; align-items: center; justify-content: space-between;">
                                    <span style="font-size: 11px; color: var(--text-muted);" x-show="cronLogs[logTab]?.length">
                                        <span x-text="cronLogs[logTab]?.length || 0"></span> entries (max 20)
                                    </span>
                                    <button type="button" class="btn btn-sm btn-secondary" style="font-size: 11px; padding: 3px 10px;" @click="clearLogs(logTab)" :disabled="!cronLogs[logTab] || cronLogs[logTab].length === 0">
                                        <i class="bi bi-trash" style="font-size: 11px;"></i> Clear
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" @click="showCronModal = false">Close</button>
        </div>
    </div>
</div>

<script>
document.addEventListener('alpine:init', () => {
    Alpine.data('cronSettingsModal', () => ({
        isLoading: false,
        isRefreshing: false,
        isScraping: false,
        runningCron: null,
        showApiToken: false,
        regeneratingToken: false,
        apiToken: '<?php echo esc_js($api_token); ?>',

        // Base URLs (without token)
        baseUrls: {
            scrape: '<?php echo esc_js($cron_base_urls['scrape']); ?>',
            process: '<?php echo esc_js($cron_base_urls['process']); ?>',
            product_ai: '<?php echo esc_js($cron_base_urls['product_ai']); ?>',
            post_ai: '<?php echo esc_js($cron_base_urls['post_ai']); ?>',
            quick_update: '<?php echo esc_js($cron_base_urls['quick_update']); ?>',
            scrape_monitor: '<?php echo esc_js($cron_base_urls['scrape_monitor']); ?>',
            cat_queue_processor: '<?php echo esc_js($cron_base_urls['cat_queue_processor']); ?>',
            cat_queue_monitor: '<?php echo esc_js($cron_base_urls['cat_queue_monitor']); ?>',
            category_ai: '<?php echo esc_js($cron_base_urls['category_ai']); ?>',
            brand_ai: '<?php echo esc_js($cron_base_urls['brand_ai']); ?>',
            process_category_ai: '<?php echo esc_js($cron_base_urls['process_category_ai']); ?>',
            brand_category_ai: '<?php echo esc_js($cron_base_urls['brand_category_ai']); ?>',
            retry_stuck: '<?php echo esc_js($cron_base_urls['retry_stuck']); ?>',
            date_update: '<?php echo esc_js($cron_base_urls['date_update']); ?>',
            backfill_links: '<?php echo esc_js($cron_base_urls['backfill_links']); ?>',
            cache_preload: '<?php echo esc_js($cron_base_urls['cache_preload']); ?>',
            smart_refresh: '<?php echo esc_js($cron_base_urls['smart_refresh']); ?>',
            resume_queue: '<?php echo esc_js($cron_base_urls['resume_queue']); ?>',
            bulk_update_worker: '<?php echo esc_js($cron_base_urls['bulk_update_worker']); ?>'
        },

        // Computed URLs (with token)
        get cronUrls() {
            return {
                scrape: this.baseUrls.scrape + '?token=' + this.apiToken,
                process: this.baseUrls.process + '?token=' + this.apiToken,
                product_ai: this.baseUrls.product_ai + '?token=' + this.apiToken,
                post_ai: this.baseUrls.post_ai + '?token=' + this.apiToken,
                quick_update: this.baseUrls.quick_update + '?token=' + this.apiToken,
                scrape_monitor: this.baseUrls.scrape_monitor + '?token=' + this.apiToken,
                cat_queue_processor: this.baseUrls.cat_queue_processor + '?token=' + this.apiToken,
                cat_queue_monitor: this.baseUrls.cat_queue_monitor + '?token=' + this.apiToken,
                category_ai: this.baseUrls.category_ai + '?token=' + this.apiToken,
                brand_ai: this.baseUrls.brand_ai + '?token=' + this.apiToken,
                process_category_ai: this.baseUrls.process_category_ai + '?token=' + this.apiToken,
                brand_category_ai: this.baseUrls.brand_category_ai + '?token=' + this.apiToken,
                retry_stuck: this.baseUrls.retry_stuck + '?token=' + this.apiToken,
                date_update: this.baseUrls.date_update + '?token=' + this.apiToken,
                backfill_links: this.baseUrls.backfill_links + '?token=' + this.apiToken,
                cache_preload: this.baseUrls.cache_preload + '?token=' + this.apiToken,
                smart_refresh: this.baseUrls.smart_refresh + '?token=' + this.apiToken,
                resume_queue: this.baseUrls.resume_queue + '?token=' + this.apiToken,
                bulk_update_worker: this.baseUrls.bulk_update_worker + '?token=' + this.apiToken
            };
        },

        // Accordion — Server Cron Jobs expanded by default
        expandedSection: 'cron-jobs',

        // Logs
        logTab: 'scraping',

        // Copy states
        copied: {
            checkMark: false,
            process: false,
            apiToken: false,
            productAi: false,
            postAi: false,
            quickUpdate: false,
            scrapeMonitor: false,
            catQueueProcessor: false,
            catQueueMonitor: false,
            categoryAi: false,
            brandAi: false,
            processCategoryAi: false,
            brandCategoryAi: false,
            retryStuck: false,
            dateUpdate: false,
            backfillLinks: false,
            cachePreload: false,
            bulkUpdateWorker: false,
            allCrontab: false
        },

        // Stats
        queueStats: {
            pending: 0,
            scheduled: 0,
            processing: 0,
            scraped: 0,
            failed: 0,
            update: 0,
            updating: 0
        },
        aiStats: {
            product: { pending: 0, queued: 0, generating: 0, generated: 0, failed: 0 },
            post: { pending: 0, queued: 0, generating: 0, generated: 0, failed: 0 },
            category: { empty: 0, generating: 0, generated: 0, failed: 0 }
        },
        cronLogs: {
            scraping: [],
            scrape_monitor: [],
            cat_queue: [],
            cat_monitor: [],
            process_category_ai: [],
            product_ai: [],
            post_ai: [],
            category_ai: [],
            brand_ai: [],
            brand_category_ai: [],
            quick_update: [],
            retry_stuck: [],
            backfill_links: []
        },

        init() {
            this.loadStatus();
        },

        loadStatus() {
            const headers = { 'X-WP-Nonce': acmsConfig.nonce };

            // Fire all 3 fetches in parallel — each updates its own section independently
            fetch(acmsConfig.restUrl + 'automation/status', { headers })
                .then(r => r.json())
                .then(result => {
                    if (result.success && result.data) {
                        this.queueStats = result.data.queue || this.queueStats;
                        if (result.data.logs?.server) {
                            this.cronLogs.scraping = result.data.logs.server;
                        }
                    }
                })
                .catch(e => console.error('Failed to load queue status:', e));

            fetch(acmsConfig.restUrl + 'cron/stats', { headers })
                .then(r => r.json())
                .then(result => {
                    if (result.success && result.data) {
                        this.aiStats = result.data;
                    }
                })
                .catch(e => console.error('Failed to load AI stats:', e));

            fetch(acmsConfig.restUrl + 'cron/logs', { headers })
                .then(r => r.json())
                .then(result => {
                    if (result.success && result.data) {
                        this.cronLogs = { ...this.cronLogs, ...result.data };
                    }
                })
                .catch(e => console.error('Failed to load cron logs:', e));
        },

        refreshStatus() {
            this.isRefreshing = true;
            const headers = { 'X-WP-Nonce': acmsConfig.nonce };

            Promise.allSettled([
                fetch(acmsConfig.restUrl + 'automation/status', { headers }).then(r => r.json()).then(result => {
                    if (result.success && result.data) {
                        this.queueStats = result.data.queue || this.queueStats;
                        if (result.data.logs?.server) this.cronLogs.scraping = result.data.logs.server;
                    }
                }),
                fetch(acmsConfig.restUrl + 'cron/stats', { headers }).then(r => r.json()).then(result => {
                    if (result.success && result.data) this.aiStats = result.data;
                }),
                fetch(acmsConfig.restUrl + 'cron/logs', { headers }).then(r => r.json()).then(result => {
                    if (result.success && result.data) this.cronLogs = { ...this.cronLogs, ...result.data };
                })
            ]).finally(() => {
                this.isRefreshing = false;
            });
        },

        async runCron(cronType) {
            this.runningCron = cronType;
            try {
                // External endpoints (use token-based auth via full URL)
                const externalEndpoints = {
                    'cat-queue-processor': this.cronUrls.cat_queue_processor,
                    'cat-queue-monitor': this.cronUrls.cat_queue_monitor,
                    'category-ai': this.cronUrls.category_ai,
                    'brand-ai': this.cronUrls.brand_ai,
                    'process-category-ai': this.cronUrls.process_category_ai,
                    'brand-category-ai': this.cronUrls.brand_category_ai,
                    'retry-stuck': this.cronUrls.retry_stuck,
                    'date-update': this.cronUrls.date_update,
                    'backfill-links': this.cronUrls.backfill_links,
                    'cache-preload': this.cronUrls.cache_preload,
                    'smart-refresh': this.cronUrls.smart_refresh,
                    'resume-queue': this.cronUrls.resume_queue,
                    'bulk-update-worker': this.cronUrls.bulk_update_worker
                };

                // Internal endpoints (use nonce-based auth)
                const internalEndpoints = {
                    'scrape': 'automation/scrape',
                    'process': 'automation/process-scheduled',
                    'product-ai': 'cron/run/product-ai',
                    'post-ai': 'cron/run/post-ai',
                    'quick-update': 'cron/run/quick-update',
                    'scrape-monitor': 'cron/run/scrape-monitor'
                };

                let response;
                if (externalEndpoints[cronType]) {
                    // Call external endpoint with token
                    response = await fetch(externalEndpoints[cronType], {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' }
                    });
                } else {
                    // Call internal endpoint with nonce
                    const endpoint = internalEndpoints[cronType] || `cron/run/${cronType}`;
                    response = await fetch(acmsConfig.restUrl + endpoint, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-WP-Nonce': acmsConfig.nonce
                        }
                    });
                }
                const result = await response.json();
                if (result.success) {
                    window.dispatchEvent(new CustomEvent('show-toast', {
                        detail: { type: 'success', title: 'Success', message: result.message || 'Job executed' }
                    }));
                    setTimeout(() => this.refreshStatus(), 1500);
                } else {
                    window.dispatchEvent(new CustomEvent('show-toast', {
                        detail: { type: 'error', title: 'Error', message: result.message || 'Failed to run job' }
                    }));
                }
            } catch (error) {
                window.dispatchEvent(new CustomEvent('show-toast', {
                    detail: { type: 'error', title: 'Error', message: 'Failed to run job' }
                }));
            } finally {
                this.runningCron = null;
            }
        },

        async runAiCron(cronType) {
            this.runningCron = cronType;
            try {
                const response = await fetch(acmsConfig.restUrl + 'cron/run/' + cronType, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': acmsConfig.nonce
                    }
                });
                const result = await response.json();
                if (result.success) {
                    window.dispatchEvent(new CustomEvent('show-toast', {
                        detail: { type: 'success', title: 'Success', message: result.message || 'Cron executed' }
                    }));
                    await this.refreshStatus();
                } else {
                    window.dispatchEvent(new CustomEvent('show-toast', {
                        detail: { type: 'error', title: 'Error', message: result.message || 'Failed to run cron' }
                    }));
                }
            } catch (error) {
                window.dispatchEvent(new CustomEvent('show-toast', {
                    detail: { type: 'error', title: 'Error', message: 'Failed to run cron' }
                }));
            } finally {
                this.runningCron = null;
            }
        },

        async clearLogs(logType) {
            try {
                const response = await fetch(acmsConfig.restUrl + 'cron/logs/' + logType, {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': acmsConfig.nonce
                    }
                });
                const result = await response.json();
                if (result.success) {
                    this.cronLogs[logType] = [];
                    window.dispatchEvent(new CustomEvent('show-toast', {
                        detail: { type: 'success', title: 'Success', message: 'Logs cleared' }
                    }));
                }
            } catch (error) {
                window.dispatchEvent(new CustomEvent('show-toast', {
                    detail: { type: 'error', title: 'Error', message: 'Failed to clear logs' }
                }));
            }
        },

        async regenerateToken() {
            if (!confirm('Regenerating the token will invalidate all existing cron URLs. Continue?')) {
                return;
            }
            this.regeneratingToken = true;
            try {
                const response = await fetch(acmsConfig.restUrl + 'cron/regenerate-token', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': acmsConfig.nonce
                    }
                });
                const result = await response.json();
                if (result.success && result.data?.token) {
                    this.apiToken = result.data.token;
                    window.dispatchEvent(new CustomEvent('show-toast', {
                        detail: { type: 'success', title: 'Success', message: 'Token regenerated. Please update your cron jobs with the new URLs.' }
                    }));
                } else {
                    window.dispatchEvent(new CustomEvent('show-toast', {
                        detail: { type: 'error', title: 'Error', message: result.message || 'Failed to regenerate token' }
                    }));
                }
            } catch (error) {
                window.dispatchEvent(new CustomEvent('show-toast', {
                    detail: { type: 'error', title: 'Error', message: 'Failed to regenerate token' }
                }));
            } finally {
                this.regeneratingToken = false;
            }
        },

        copyUrl(url, key) {
            navigator.clipboard.writeText(url).then(() => {
                this.copied[key] = true;
                setTimeout(() => { this.copied[key] = false; }, 2000);
            });
        },

        getAllCrontabText() {
            return `# AffiliateCMS Cron Jobs
# Tier 1: Pipeline (critical path - every 2 min, lock=90s prevents overlap)
*/2 * * * *  curl -s "${this.cronUrls.scrape}" >/dev/null 2>&1
*/2 * * * *  curl -s "${this.cronUrls.process}" >/dev/null 2>&1
*/2 * * * *  curl -s "${this.cronUrls.scrape_monitor}" >/dev/null 2>&1
*/2 * * * *  curl -s "${this.cronUrls.cat_queue_processor}" >/dev/null 2>&1
*/2 * * * *  curl -s "${this.cronUrls.cat_queue_monitor}" >/dev/null 2>&1
*/2 * * * *  curl -s "${this.cronUrls.process_category_ai}" >/dev/null 2>&1

# Tier 2: AI Generation (important - every 5 min, lock=240s)
*/5 * * * *  curl -s "${this.cronUrls.product_ai}" >/dev/null 2>&1
*/5 * * * *  curl -s "${this.cronUrls.post_ai}" >/dev/null 2>&1
*/5 * * * *  curl -s "${this.cronUrls.category_ai}" >/dev/null 2>&1
*/5 * * * *  curl -s "${this.cronUrls.brand_ai}" >/dev/null 2>&1
*/5 * * * *  curl -s "${this.cronUrls.brand_category_ai}" >/dev/null 2>&1

# Tier 3: Maintenance (background - less frequent)
*/30 * * * * curl -s "${this.cronUrls.quick_update}" >/dev/null 2>&1  # Auto Update (price/rating/stock)
*/10 * * * * curl -s "${this.cronUrls.retry_stuck}" >/dev/null 2>&1
0 3 * * *   curl -s "${this.cronUrls.date_update}" >/dev/null 2>&1   # Date Update (daily at 3am)
0 3 * * 0   curl -s -X POST "${this.cronUrls.cache_preload}" >/dev/null 2>&1  # Cache Full Rebuild (weekly Sunday 3am)
0 */4 * * * curl -s -X POST "${this.cronUrls.smart_refresh}" >/dev/null 2>&1  # Smart Refresh (every 4h, ~10K important URLs)
*/30 * * * * curl -s -X POST "${this.cronUrls.resume_queue}" >/dev/null 2>&1  # Resume stalled cache queue
* * * * *   curl -s "${this.cronUrls.bulk_update_worker}" >/dev/null 2>&1  # Bulk Update ASINs (every min, processes batch)`;
        },

        copyAllCrontab() {
            this.copyUrl(this.getAllCrontabText(), 'allCrontab');
        },

        toggleSection(section) {
            this.expandedSection = this.expandedSection === section ? null : section;
        }
    }));
});
</script>
