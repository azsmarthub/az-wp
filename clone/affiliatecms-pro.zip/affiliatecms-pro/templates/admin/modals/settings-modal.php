<?php
/**
 * Settings Modal - 3 Tabs: General, API Keys, Display
 *
 * @package AffiliateCMS\Pro
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<!-- Settings Modal -->
<div class="modal-backdrop" x-show="showSettingsModal" x-cloak @click.self="showSettingsModal = false"
     x-transition:enter="transition ease-out duration-200"
     x-transition:enter-start="opacity-0"
     x-transition:enter-end="opacity-100"
     x-transition:leave="transition ease-in duration-150"
     x-transition:leave-start="opacity-100"
     x-transition:leave-end="opacity-0">
    <div class="modal modal-lg" @click.stop x-data="settingsModal()" x-init="init()">
        <div class="modal-header">
            <h2 class="modal-title">
                <i class="bi bi-gear"></i>
                Settings
            </h2>
            <button class="btn-icon" @click="showSettingsModal = false">
                <i class="bi bi-x-lg"></i>
            </button>
        </div>
        <div class="modal-body">
            <!-- Tabs -->
            <div class="settings-tabs">
                <button class="settings-tab" :class="{ 'active': activeTab === 'general' }" @click="activeTab = 'general'">
                    <i class="bi bi-sliders"></i>
                    General
                </button>
                <button class="settings-tab" :class="{ 'active': activeTab === 'api' }" @click="activeTab = 'api'">
                    <i class="bi bi-key"></i>
                    API Keys
                </button>
                <button class="settings-tab" :class="{ 'active': activeTab === 'display' }" @click="activeTab = 'display'">
                    <i class="bi bi-palette"></i>
                    Display
                </button>
                <button class="settings-tab" :class="{ 'active': activeTab === 'database' }" @click="activeTab = 'database'">
                    <i class="bi bi-database"></i>
                    Database
                </button>
                <!-- Post Types tab hidden — not used currently -->
                <!-- <button class="settings-tab" :class="{ 'active': activeTab === 'post-types' }" @click="activeTab = 'post-types'">
                    <i class="bi bi-file-earmark-post"></i>
                    Post Types
                </button> -->
            </div>

            <!-- Loading State -->
            <div x-show="isLoading" class="settings-loading">
                <div class="spinner"></div>
                <span>Loading settings...</span>
            </div>

            <!-- ============================================
                 GENERAL TAB
                 ============================================ -->
            <div class="settings-panel" x-show="activeTab === 'general' && !isLoading" x-cloak>
                <!-- Provider Settings -->
                <div class="settings-section">
                    <div class="settings-section-header">
                        <div>
                            <h3 class="settings-section-title">
                                <i class="bi bi-cpu"></i>
                                Data Provider
                            </h3>
                            <p class="settings-section-desc">Configure how product data is fetched</p>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Primary Provider</label>
                            <div class="custom-select" @click.outside="primaryProviderOpen = false">
                                <button type="button" class="custom-select-trigger" :class="{ 'open': primaryProviderOpen }" @click="primaryProviderOpen = !primaryProviderOpen">
                                    <span class="custom-select-value" x-text="settings.default_provider === 'crawlbase' ? 'Crawlbase (Recommended)' : 'Amazon PA-API'"></span>
                                    <i class="bi bi-chevron-down"></i>
                                </button>
                                <div class="custom-select-dropdown" x-show="primaryProviderOpen" x-cloak x-transition @click.stop>
                                    <button type="button" class="custom-select-option" :class="{ 'selected': settings.default_provider === 'crawlbase' }" @click="settings.default_provider = 'crawlbase'; if(settings.fallback_provider === 'crawlbase') settings.fallback_provider = 'none'; primaryProviderOpen = false">
                                        Crawlbase (Recommended)
                                    </button>
                                    <button type="button" class="custom-select-option" :class="{ 'selected': settings.default_provider === 'paapi' }" @click="settings.default_provider = 'paapi'; if(settings.fallback_provider === 'paapi') settings.fallback_provider = 'none'; primaryProviderOpen = false">
                                        Amazon PA-API
                                    </button>
                                </div>
                            </div>
                            <p class="form-hint">Main source for fetching product data</p>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Fallback Provider</label>
                            <div class="custom-select" @click.outside="fallbackProviderOpen = false">
                                <button type="button" class="custom-select-trigger" :class="{ 'open': fallbackProviderOpen }" @click="fallbackProviderOpen = !fallbackProviderOpen">
                                    <span class="custom-select-value" x-text="settings.fallback_provider === 'none' ? 'None - No fallback' : (settings.fallback_provider === 'crawlbase' ? 'Crawlbase' : 'Amazon PA-API')"></span>
                                    <i class="bi bi-chevron-down"></i>
                                </button>
                                <div class="custom-select-dropdown" x-show="fallbackProviderOpen" x-cloak x-transition @click.stop>
                                    <button type="button" class="custom-select-option" :class="{ 'selected': settings.fallback_provider === 'none' }" @click="settings.fallback_provider = 'none'; fallbackProviderOpen = false">
                                        None - No fallback
                                    </button>
                                    <button type="button" class="custom-select-option" :class="{ 'selected': settings.fallback_provider === 'crawlbase' }" @click="settings.fallback_provider = 'crawlbase'; fallbackProviderOpen = false" x-show="settings.default_provider !== 'crawlbase'">
                                        Crawlbase
                                    </button>
                                    <button type="button" class="custom-select-option" :class="{ 'selected': settings.fallback_provider === 'paapi' }" @click="settings.fallback_provider = 'paapi'; fallbackProviderOpen = false" x-show="settings.default_provider !== 'paapi'">
                                        Amazon PA-API
                                    </button>
                                </div>
                            </div>
                            <p class="form-hint">Used when primary provider fails</p>
                        </div>
                    </div>
                </div>

                <!-- Scraping + Auto Re-scrape (2 columns) -->
                <div style="display: flex; gap: 16px; border-bottom: 1px solid var(--border); padding: 16px 20px;">
                    <!-- Left: Scraping -->
                    <div style="flex: 1; background: var(--bg-surface); border: 1px solid var(--border); border-radius: var(--radius-md); padding: 16px;">
                        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 4px;">
                            <h3 class="settings-section-title" style="margin: 0;">
                                <i class="bi bi-download"></i>
                                Scraping
                            </h3>
                        </div>
                        <p class="settings-section-desc" style="margin-bottom: 12px;">Controls how products are scraped</p>
                        <label class="form-label">Parallel Workers</label>
                        <div class="input-with-suffix">
                            <input type="number" class="input" x-model="settings.worker_count" min="1" max="50" style="width: 80px;">
                            <span class="input-suffix">workers</span>
                        </div>
                        <p class="form-hint">Parallel workers (1-50). More = faster but higher server load.</p>
                    </div>

                    <!-- Right: Auto Update -->
                    <div style="flex: 1; background: var(--bg-surface); border: 1px solid var(--border); border-radius: var(--radius-md); padding: 16px;">
                        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 4px;">
                            <h3 class="settings-section-title" style="margin: 0;">
                                <i class="bi bi-arrow-repeat"></i>
                                Auto Update
                            </h3>
                            <label class="switch">
                                <input type="checkbox" x-model="settings.update_enabled">
                                <span class="switch-slider"></span>
                            </label>
                        </div>
                        <p class="settings-section-desc" style="margin-bottom: 12px;">Automatically update prices, ratings &amp; stock</p>
                        <div x-show="settings.update_enabled" x-collapse>
                            <label class="form-label">Update Interval</label>
                            <div class="input-with-suffix">
                                <input type="number" class="input" x-model="settings.update_interval" min="1" max="168" style="width: 100px;">
                                <span class="input-suffix">hours</span>
                            </div>
                            <p class="form-hint">Update products older than this (1-168h).</p>
                            <label class="form-label" style="margin-top: 10px;">Parallel Workers</label>
                            <div class="input-with-suffix">
                                <input type="number" class="input" x-model="settings.update_worker_count" min="1" max="50" style="width: 80px;">
                                <span class="input-suffix">workers</span>
                            </div>
                            <p class="form-hint">Parallel update workers (1-50).</p>
                        </div>
                    </div>
                </div>

            </div>

            <!-- ============================================
                 API KEYS TAB
                 ============================================ -->
            <div class="settings-panel" x-show="activeTab === 'api' && !isLoading" x-cloak>
                <!-- Crawlbase Section - Collapsible -->
                <div class="settings-accordion" :class="{ 'is-open': crawlbaseExpanded }">
                    <button type="button" class="settings-accordion-header" @click="crawlbaseExpanded = !crawlbaseExpanded">
                        <div class="settings-accordion-title">
                            <div class="settings-accordion-icon crawlbase">
                                <i class="bi bi-bug"></i>
                            </div>
                            <div class="settings-accordion-info">
                                <h3>Crawlbase</h3>
                                <p>Web scraping API for Amazon product data</p>
                            </div>
                        </div>
                        <div class="settings-accordion-status">
                            <span class="api-status" :class="{
                                'connected': crawlbaseStatus === 'success',
                                'error': crawlbaseStatus === 'error',
                                'configured': crawlbaseToken && !crawlbaseStatus
                            }">
                                <span class="api-status-dot"></span>
                                <span x-text="crawlbaseStatus === 'success' ? 'Connected' :
                                             (crawlbaseStatus === 'error' ? 'Error' :
                                             (crawlbaseToken ? 'Configured' : 'Not configured'))"></span>
                            </span>
                            <i class="bi bi-chevron-down settings-accordion-arrow"></i>
                        </div>
                    </button>

                    <div class="settings-accordion-content" x-show="crawlbaseExpanded" x-collapse>
                        <div class="settings-accordion-body">
                            <div class="settings-info">
                                <i class="bi bi-info-circle"></i>
                                <div>
                                    Crawlbase is a web scraping API that fetches Amazon product data reliably.
                                    <a href="https://crawlbase.com/?ref=affiliatecms" target="_blank">Get your API token</a>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="form-label">API Token <span class="required">*</span></label>
                                <div class="input-group">
                                    <input :type="showCrawlbaseToken ? 'text' : 'password'"
                                           class="input"
                                           placeholder="Enter your Crawlbase API token"
                                           x-model="crawlbaseToken"
                                           autocomplete="one-time-code"
                                           data-lpignore="true"
                                           data-1p-ignore>
                                    <button type="button" class="btn btn-secondary btn-icon-only" @click="showCrawlbaseToken = !showCrawlbaseToken" title="Toggle visibility">
                                        <i class="bi" :class="showCrawlbaseToken ? 'bi-eye-slash' : 'bi-eye'"></i>
                                    </button>
                                    <button type="button" class="btn btn-secondary"
                                            @click="testCrawlbase()"
                                            :disabled="crawlbaseTesting || !crawlbaseToken"
                                            :class="{ 'btn-success': crawlbaseStatus === 'success', 'btn-danger': crawlbaseStatus === 'error' }">
                                        <i class="bi" :class="crawlbaseTesting ? 'bi-arrow-repeat animate-spin' :
                                                            (crawlbaseStatus === 'success' ? 'bi-check-lg' :
                                                            (crawlbaseStatus === 'error' ? 'bi-x-lg' : 'bi-plug'))"></i>
                                        <span x-text="crawlbaseTesting ? 'Testing...' :
                                                     (crawlbaseStatus === 'success' ? 'Connected!' :
                                                     (crawlbaseStatus === 'error' ? 'Failed' : 'Test'))"></span>
                                    </button>
                                </div>
                                <p class="form-hint">Your Crawlbase JavaScript token.</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Amazon PA-API Section - Collapsible -->
                <div class="settings-accordion" :class="{ 'is-open': paapiExpanded }">
                    <button type="button" class="settings-accordion-header" @click="paapiExpanded = !paapiExpanded">
                        <div class="settings-accordion-title">
                            <div class="settings-accordion-icon amazon">
                                <i class="bi bi-box-seam"></i>
                            </div>
                            <div class="settings-accordion-info">
                                <h3>Amazon PA-API</h3>
                                <p>Official Amazon Product Advertising API</p>
                            </div>
                        </div>
                        <div class="settings-accordion-status">
                            <span class="api-status" :class="{
                                'connected': paapiStatus === 'success',
                                'error': paapiStatus === 'error',
                                'configured': paapiAccessKey && !paapiStatus
                            }">
                                <span class="api-status-dot"></span>
                                <span x-text="paapiStatus === 'success' ? 'Connected' :
                                             (paapiStatus === 'error' ? 'Error' :
                                             (paapiAccessKey ? 'Configured' : 'Not configured'))"></span>
                            </span>
                            <i class="bi bi-chevron-down settings-accordion-arrow"></i>
                        </div>
                    </button>

                    <div class="settings-accordion-content" x-show="paapiExpanded" x-collapse>
                        <div class="settings-accordion-body">
                            <div class="settings-info settings-info-warning">
                                <i class="bi bi-exclamation-triangle"></i>
                                <div>
                                    Amazon PA-API requires an approved Amazon Associates account with sales history.
                                    <a href="https://affiliate-program.amazon.com/assoc_credentials/home" target="_blank">Get credentials</a>
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group">
                                    <label class="form-label">Partner Tag <span class="required">*</span></label>
                                    <input type="text" class="input" placeholder="yourtag-20" x-model="paapiPartnerTag" autocomplete="one-time-code" data-lpignore="true" data-1p-ignore>
                                    <p class="form-hint">Your Amazon Associates tracking ID</p>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Marketplace</label>
                                    <div class="custom-select" @click.outside="marketplaceOpen = false">
                                        <button type="button" class="custom-select-trigger" :class="{ 'open': marketplaceOpen }" @click="marketplaceOpen = !marketplaceOpen">
                                            <span class="custom-select-value" x-text="regionOptions.find(r => r.value === paapiRegion)?.label || 'Select marketplace'"></span>
                                            <i class="bi bi-chevron-down"></i>
                                        </button>
                                        <div class="custom-select-dropdown" x-show="marketplaceOpen" x-cloak x-transition @click.stop style="max-height: 240px; overflow-y: auto;">
                                            <template x-for="opt in regionOptions" :key="opt.value">
                                                <button type="button" class="custom-select-option" :class="{ 'selected': paapiRegion === opt.value }" @click="paapiRegion = opt.value; marketplaceOpen = false" x-text="opt.label"></button>
                                            </template>
                                        </div>
                                    </div>
                                    <p class="form-hint">Amazon marketplace region</p>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="form-label">Access Key <span class="required">*</span></label>
                                <input type="text" class="input" placeholder="AKIAIOSFODNN7EXAMPLE" x-model="paapiAccessKey" autocomplete="one-time-code" data-lpignore="true" data-1p-ignore>
                                <p class="form-hint">AWS access key ID for PA-API</p>
                            </div>

                            <div class="form-group">
                                <label class="form-label">
                                    Secret Key <span class="required">*</span>
                                    <span class="api-status configured" x-show="hasExistingSecret" style="margin-left: 8px;">
                                        <span class="api-status-dot"></span>
                                        <span>Saved</span>
                                    </span>
                                </label>
                                <div class="input-group">
                                    <input :type="showPaapiSecret ? 'text' : 'password'"
                                           class="input"
                                           :placeholder="hasExistingSecret ? '••••••••••••••••••••' : 'Enter secret key'"
                                           x-model="paapiSecretKey"
                                           autocomplete="one-time-code"
                                           data-lpignore="true"
                                           data-1p-ignore>
                                    <button type="button" class="btn btn-secondary btn-icon-only" @click="showPaapiSecret = !showPaapiSecret" title="Toggle visibility">
                                        <i class="bi" :class="showPaapiSecret ? 'bi-eye-slash' : 'bi-eye'"></i>
                                    </button>
                                    <button type="button" class="btn btn-secondary"
                                            @click="testPaapi()"
                                            :disabled="paapiTesting || !paapiAccessKey || !paapiPartnerTag"
                                            :class="{ 'btn-success': paapiStatus === 'success', 'btn-danger': paapiStatus === 'error' }">
                                        <i class="bi" :class="paapiTesting ? 'bi-arrow-repeat animate-spin' :
                                                            (paapiStatus === 'success' ? 'bi-check-lg' :
                                                            (paapiStatus === 'error' ? 'bi-x-lg' : 'bi-plug'))"></i>
                                        <span x-text="paapiTesting ? 'Testing...' :
                                                     (paapiStatus === 'success' ? 'Connected!' :
                                                     (paapiStatus === 'error' ? 'Failed' : 'Test'))"></span>
                                    </button>
                                </div>
                                <p class="form-hint" x-show="hasExistingSecret">Leave empty to keep existing secret key</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- API Status Summary -->
                <div class="api-summary">
                    <div class="api-summary-item">
                        <span class="api-summary-label">Active Provider:</span>
                        <span class="api-summary-value" x-text="settings.default_provider === 'crawlbase' ? 'Crawlbase' : 'Amazon PA-API'"></span>
                    </div>
                    <div class="api-summary-item" x-show="settings.fallback_provider !== 'none'">
                        <span class="api-summary-label">Fallback:</span>
                        <span class="api-summary-value" x-text="settings.fallback_provider === 'crawlbase' ? 'Crawlbase' : 'Amazon PA-API'"></span>
                    </div>
                </div>
            </div>

            <!-- ============================================
                 DISPLAY TAB
                 ============================================ -->
            <div class="settings-panel" x-show="activeTab === 'display' && !isLoading" x-cloak>
                <!-- Template Settings -->
                <div class="settings-section">
                    <div class="settings-section-header">
                        <div style="display: flex; align-items: center; gap: 16px;">
                            <div style="width: 48px; height: 48px; border-radius: var(--radius-lg); background: linear-gradient(135deg, #3b82f6, #2563eb); display: flex; align-items: center; justify-content: center;">
                                <i class="bi bi-layout-text-window" style="font-size: 24px; color: white;"></i>
                            </div>
                            <div>
                                <h3 class="settings-section-title" style="margin-bottom: 4px;">Default Template</h3>
                                <p class="settings-section-desc" style="margin: 0;">Choose how products are displayed by default</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Product Elements -->
                <div class="settings-section">
                    <div class="settings-section-header">
                        <div>
                            <h3 class="settings-section-title">
                                <i class="bi bi-eye"></i>
                                Visible Elements
                            </h3>
                            <p class="settings-section-desc">Choose what information to display</p>
                        </div>
                    </div>

                    <div class="checkbox-grid">
                        <label class="form-checkbox">
                            <input type="checkbox" x-model="settings.show_price">
                            <div class="form-checkbox-content">
                                <span class="form-checkbox-label">Price</span>
                                <span class="form-checkbox-desc">Display current product price</span>
                            </div>
                        </label>

                        <label class="form-checkbox">
                            <input type="checkbox" x-model="settings.show_rating">
                            <div class="form-checkbox-content">
                                <span class="form-checkbox-label">Rating (Score)</span>
                                <span class="form-checkbox-desc">Show star rating and review count</span>
                            </div>
                        </label>

                        <label class="form-checkbox">
                            <input type="checkbox" x-model="settings.show_prime_badge">
                            <div class="form-checkbox-content">
                                <span class="form-checkbox-label">Prime Badge</span>
                                <span class="form-checkbox-desc">Show Prime eligibility icon</span>
                            </div>
                        </label>

                        <label class="form-checkbox">
                            <input type="checkbox" x-model="settings.show_stock_status">
                            <div class="form-checkbox-content">
                                <span class="form-checkbox-label">Stock Status</span>
                                <span class="form-checkbox-desc">Display in-stock/out-of-stock</span>
                            </div>
                        </label>

                        <label class="form-checkbox">
                            <input type="checkbox" x-model="settings.show_update">
                            <div class="form-checkbox-content">
                                <span class="form-checkbox-label">Updated Time</span>
                                <span class="form-checkbox-desc">Show last updated date/time</span>
                            </div>
                        </label>
                    </div>
                </div>

                <!-- Rating Display — Score only (star rating disabled) -->
                <div class="settings-section" style="opacity: 0.6; pointer-events: none;">
                    <div class="settings-section-header">
                        <div>
                            <h3 class="settings-section-title">
                                <i class="bi bi-star"></i>
                                Rating Display
                            </h3>
                            <p class="settings-section-desc">Score (7.5/10) — ACMS calculated score. Star Rating is disabled.</p>
                        </div>
                    </div>
                </div>

                <!-- Affiliate Tag & Link Settings -->
                <div class="settings-section">
                    <div class="settings-section-header">
                        <div>
                            <h3 class="settings-section-title">
                                <i class="bi bi-link-45deg"></i>
                                Affiliate Links
                            </h3>
                            <p class="settings-section-desc">Configure your Amazon tracking ID and link behavior</p>
                        </div>
                    </div>

                    <!-- Amazon Associates Tag -->
                    <div class="form-group" style="margin-bottom: 20px;">
                        <label class="form-label">
                            <i class="bi bi-amazon" style="color: #ff9900; margin-right: 4px;"></i>
                            Amazon Associates Tracking ID
                        </label>
                        <div class="input-group">
                            <span class="input-prefix">tag=</span>
                            <input type="text" class="input" x-model="settings.affiliate_tag" placeholder="yourtag-20" style="border-top-left-radius: 0; border-bottom-left-radius: 0;">
                        </div>
                        <p class="form-hint">Your Amazon Associates tracking ID (e.g., yourtag-20)</p>
                    </div>

                    <!-- Custom URL Parameters -->
                    <div class="form-group" style="margin-bottom: 20px;">
                        <label class="form-label">
                            <i class="bi bi-sliders2" style="color: var(--primary); margin-right: 4px;"></i>
                            Custom URL Parameters
                        </label>
                        <input type="text" class="input" x-model="settings.custom_url_params" placeholder="linkCode=ogi&th=1&psc=1">
                        <p class="form-hint">Extra query parameters appended after the tag. No leading <code>&amp;</code> needed</p>
                    </div>

                    <!-- Link Redirect Settings -->
                    <div class="settings-subsection" style="margin-bottom: 20px; padding: 16px; background: var(--bg-base); border-radius: var(--radius-md); border: 1px solid var(--border);">
                        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px;">
                            <div style="display: flex; align-items: center; gap: 8px;">
                                <i class="bi bi-arrow-right-circle" style="color: var(--primary);"></i>
                                <div>
                                    <div style="font-weight: 500; font-size: 14px;">Link Redirect</div>
                                    <div style="font-size: 12px; color: var(--text-secondary);">Wrap external links through custom redirect URL</div>
                                </div>
                            </div>
                            <label class="switch">
                                <input type="checkbox" x-model="settings.redirect_enabled">
                                <span class="switch-slider"></span>
                            </label>
                        </div>

                        <div x-show="settings.redirect_enabled" x-collapse>
                            <div class="form-group">
                                <label class="form-label">Redirect Slug</label>
                                <div class="input-group">
                                    <span class="input-prefix" x-text="'/' + (settings.redirect_slug || 'go') + '/'"></span>
                                    <input type="text" class="input" x-model="settings.redirect_slug" placeholder="go" style="border-top-left-radius: 0; border-bottom-left-radius: 0;">
                                </div>
                                <p class="form-hint">Custom slug for redirect URLs (e.g., go, out, link). Example: <code>yoursite.com/<span x-text="settings.redirect_slug || 'go'"></span>/?url=...</code></p>
                            </div>
                        </div>
                    </div>

                    <!-- Affiliate Link Preview -->
                    <div class="affiliate-link-preview" style="margin-bottom: 20px; padding: 16px; background: var(--bg-base); border-radius: var(--radius-md); border: 1px solid var(--border);">
                        <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 12px;">
                            <i class="bi bi-eye" style="color: var(--text-secondary);"></i>
                            <span style="font-weight: 500; font-size: 13px;">Link Preview</span>
                        </div>
                        <div style="font-family: monospace; font-size: 12px; color: var(--text-secondary); word-break: break-all; background: var(--bg-surface); padding: 10px 12px; border-radius: var(--radius-sm);">
                            <span style="color: var(--text-muted);">https://www.amazon.com/dp/</span><span style="color: var(--primary);">B0XXXXXX</span><span style="color: var(--text-muted);">?tag=</span><strong style="color: var(--success);" x-text="settings.affiliate_tag || 'your-tag'"></strong><span x-show="settings.custom_url_params" style="color: var(--text-muted);">&amp;<span style="color: var(--accent);" x-text="settings.custom_url_params"></span></span><span x-show="settings.enable_utm" style="color: var(--text-muted);">&amp;utm_source=<span x-text="settings.utm_source || 'website'"></span>&amp;utm_medium=<span x-text="settings.utm_medium || 'affiliate'"></span>&amp;utm_campaign=<span style="color: var(--info);">post-slug</span></span>
                        </div>
                    </div>

                    <!-- UTM Tracking -->
                    <div class="settings-subsection" style="margin-bottom: 20px; padding: 16px; background: var(--bg-base); border-radius: var(--radius-md); border: 1px solid var(--border);">
                        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px;">
                            <div style="display: flex; align-items: center; gap: 8px;">
                                <i class="bi bi-graph-up" style="color: var(--primary);"></i>
                                <div>
                                    <div style="font-weight: 500; font-size: 14px;">UTM Tracking</div>
                                    <div style="font-size: 12px; color: var(--text-secondary);">Auto-add UTM parameters for analytics</div>
                                </div>
                            </div>
                            <label class="switch">
                                <input type="checkbox" x-model="settings.enable_utm">
                                <span class="switch-slider"></span>
                            </label>
                        </div>

                        <div x-show="settings.enable_utm" x-collapse>
                            <div class="form-row">
                                <div class="form-group">
                                    <label class="form-label">UTM Source</label>
                                    <input type="text" class="input" x-model="settings.utm_source" placeholder="yoursite">
                                    <p class="form-hint">Your website identifier</p>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">UTM Medium</label>
                                    <input type="text" class="input" x-model="settings.utm_medium" placeholder="affiliate">
                                    <p class="form-hint">Traffic source type (e.g., affiliate, referral)</p>
                                </div>
                            </div>

                            <!-- Apply to Amazon Links -->
                            <label class="form-checkbox" style="margin-top: 12px;">
                                <input type="checkbox" x-model="settings.utm_apply_to_amazon">
                                <div class="form-checkbox-content">
                                    <span class="form-checkbox-label">Apply to Amazon Links</span>
                                    <span class="form-checkbox-desc">Also add UTM to Amazon affiliate links (default: external links only)</span>
                                </div>
                            </label>

                            <!-- Cloudflare Parameter -->
                            <div class="form-group" style="margin-top: 16px;">
                                <label class="form-label">
                                    <i class="bi bi-cloud" style="margin-right: 4px;"></i>
                                    Cloudflare Parameter (Optional)
                                </label>
                                <input type="text" class="input" x-model="settings.cf_param" placeholder="ref=site1">
                                <p class="form-hint">Custom parameter for Cloudflare Page Rules (e.g., ref=promo, geo=us). Use for country blocking, A/B testing.</p>
                            </div>

                            <div class="settings-info" style="margin-top: 8px;">
                                <i class="bi bi-info-circle"></i>
                                <div style="font-size: 12px;">
                                    <code>utm_campaign</code> is auto-generated from post slug (e.g., <code>best-wireless-headphones</code>)
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Button Text with Preview -->
                    <div class="form-group">
                        <label class="form-label">Button Text</label>
                        <div style="display: flex; gap: 12px; align-items: stretch;">
                            <input type="text" class="input" x-model="settings.button_text" placeholder="View on Amazon" style="flex: 1;">
                            <a href="#" class="acms-btn-preview" @click.prevent style="display: inline-flex; align-items: center; gap: 8px; padding: 0 20px; height: 40px; background: linear-gradient(135deg, #ff9900, #e88a00); color: white; border-radius: 6px; text-decoration: none; font-weight: 500; font-size: 14px; white-space: nowrap;">
                                <span x-text="settings.button_text || 'View on Amazon'"></span>
                                <i class="bi bi-box-arrow-up-right" style="font-size: 12px;"></i>
                            </a>
                        </div>
                        <p class="form-hint">Call-to-action button text</p>
                    </div>

                    <!-- Link Options -->
                    <div class="form-row" style="margin-top: 20px;">
                        <div class="form-group">
                            <label class="form-checkbox">
                                <input type="checkbox" x-model="settings.open_new_tab">
                                <div class="form-checkbox-content">
                                    <span class="form-checkbox-label">Open in new tab</span>
                                    <span class="form-checkbox-desc">Opens affiliate links in a new browser tab</span>
                                </div>
                            </label>
                        </div>
                        <div class="form-group">
                            <label class="form-checkbox">
                                <input type="checkbox" x-model="settings.nofollow_links">
                                <div class="form-checkbox-content">
                                    <span class="form-checkbox-label">Add nofollow attribute</span>
                                    <span class="form-checkbox-desc">Adds only rel="nofollow" to Amazon links</span>
                                </div>
                            </label>
                        </div>
                    </div>
                </div>

                <!-- Disclosure, Score, Update, Post Disclosure — all hardcoded in theme inc/config.php for performance (0 queries) -->
                <div class="settings-section" style="opacity: 0.6; pointer-events: none;">
                    <div class="settings-section-header">
                        <div>
                            <h3 class="settings-section-title">
                                <i class="bi bi-info-circle"></i>
                                Disclosure, Score &amp; Update Text
                            </h3>
                            <p class="settings-section-desc">Hardcoded in theme <code>inc/config.php</code> for performance (0 queries). Edit that file directly to change disclosure text, score label/tooltip, or update info.</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ============================================
                 POST TYPES TAB (hidden — not used currently)
                 ============================================ -->
            <div class="settings-panel" style="display:none !important;" x-show="activeTab === 'post-types' && !isLoading" x-cloak>
                <!-- Post Types Info -->
                <div class="settings-info">
                    <i class="bi bi-info-circle"></i>
                    <div>
                        Create custom post types similar to WordPress Posts with full support for categories, tags, and custom slugs.
                        Enable a post type below and configure its settings.
                    </div>
                </div>

                <!-- Reviews Post Type -->
                <div class="settings-accordion" :class="{ 'is-open': postTypes.reviews.expanded }">
                    <button type="button" class="settings-accordion-header" @click="postTypes.reviews.expanded = !postTypes.reviews.expanded">
                        <div class="settings-accordion-title">
                            <div class="settings-accordion-icon" style="background: linear-gradient(135deg, #34d399, #10b981);">
                                <i class="bi bi-star-half"></i>
                            </div>
                            <div class="settings-accordion-info">
                                <h3>Reviews</h3>
                                <p>Product reviews and comparisons</p>
                            </div>
                        </div>
                        <div class="settings-accordion-status">
                            <label class="switch" @click.stop>
                                <input type="checkbox" x-model="postTypes.reviews.enabled" @change="onPostTypeToggle('reviews')">
                                <span class="switch-slider"></span>
                            </label>
                            <i class="bi bi-chevron-down settings-accordion-arrow"></i>
                        </div>
                    </button>

                    <div class="settings-accordion-content" x-show="postTypes.reviews.expanded" x-collapse>
                        <div class="settings-accordion-body">
                            <div class="form-row">
                                <div class="form-group">
                                    <label class="form-label">Post Type Slug</label>
                                    <input type="text" class="input" x-model="postTypes.reviews.slug" placeholder="reviews" :disabled="!postTypes.reviews.enabled">
                                    <p class="form-hint">URL slug: yoursite.com/<strong x-text="postTypes.reviews.slug || 'reviews'"></strong>/post-name</p>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Menu Name</label>
                                    <input type="text" class="input" x-model="postTypes.reviews.menu_name" placeholder="Reviews" :disabled="!postTypes.reviews.enabled">
                                    <p class="form-hint">Name shown in admin menu</p>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group">
                                    <label class="form-label">Singular Name</label>
                                    <input type="text" class="input" x-model="postTypes.reviews.singular" placeholder="Review" :disabled="!postTypes.reviews.enabled">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Plural Name</label>
                                    <input type="text" class="input" x-model="postTypes.reviews.plural" placeholder="Reviews" :disabled="!postTypes.reviews.enabled">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Menu Icon</label>
                                <input type="text" class="input" x-model="postTypes.reviews.icon" placeholder="dashicons-star-half" :disabled="!postTypes.reviews.enabled">
                                <p class="form-hint">Dashicon class name. <a href="https://developer.wordpress.org/resource/dashicons/" target="_blank">Browse icons</a></p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Deals Post Type -->
                <div class="settings-accordion" :class="{ 'is-open': postTypes.deals.expanded }">
                    <button type="button" class="settings-accordion-header" @click="postTypes.deals.expanded = !postTypes.deals.expanded">
                        <div class="settings-accordion-title">
                            <div class="settings-accordion-icon" style="background: linear-gradient(135deg, #fbbf24, #f59e0b);">
                                <i class="bi bi-tag"></i>
                            </div>
                            <div class="settings-accordion-info">
                                <h3>Deals</h3>
                                <p>Daily deals and promotions</p>
                            </div>
                        </div>
                        <div class="settings-accordion-status">
                            <label class="switch" @click.stop>
                                <input type="checkbox" x-model="postTypes.deals.enabled" @change="onPostTypeToggle('deals')">
                                <span class="switch-slider"></span>
                            </label>
                            <i class="bi bi-chevron-down settings-accordion-arrow"></i>
                        </div>
                    </button>

                    <div class="settings-accordion-content" x-show="postTypes.deals.expanded" x-collapse>
                        <div class="settings-accordion-body">
                            <div class="form-row">
                                <div class="form-group">
                                    <label class="form-label">Post Type Slug</label>
                                    <input type="text" class="input" x-model="postTypes.deals.slug" placeholder="deals" :disabled="!postTypes.deals.enabled">
                                    <p class="form-hint">URL slug: yoursite.com/<strong x-text="postTypes.deals.slug || 'deals'"></strong>/post-name</p>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Menu Name</label>
                                    <input type="text" class="input" x-model="postTypes.deals.menu_name" placeholder="Deals" :disabled="!postTypes.deals.enabled">
                                    <p class="form-hint">Name shown in admin menu</p>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group">
                                    <label class="form-label">Singular Name</label>
                                    <input type="text" class="input" x-model="postTypes.deals.singular" placeholder="Deal" :disabled="!postTypes.deals.enabled">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Plural Name</label>
                                    <input type="text" class="input" x-model="postTypes.deals.plural" placeholder="Deals" :disabled="!postTypes.deals.enabled">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Menu Icon</label>
                                <input type="text" class="input" x-model="postTypes.deals.icon" placeholder="dashicons-tag" :disabled="!postTypes.deals.enabled">
                                <p class="form-hint">Dashicon class name. <a href="https://developer.wordpress.org/resource/dashicons/" target="_blank">Browse icons</a></p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Guides Post Type -->
                <div class="settings-accordion" :class="{ 'is-open': postTypes.guides.expanded }">
                    <button type="button" class="settings-accordion-header" @click="postTypes.guides.expanded = !postTypes.guides.expanded">
                        <div class="settings-accordion-title">
                            <div class="settings-accordion-icon" style="background: linear-gradient(135deg, #818cf8, #6366f1);">
                                <i class="bi bi-book"></i>
                            </div>
                            <div class="settings-accordion-info">
                                <h3>Guides</h3>
                                <p>Buying guides and tutorials</p>
                            </div>
                        </div>
                        <div class="settings-accordion-status">
                            <label class="switch" @click.stop>
                                <input type="checkbox" x-model="postTypes.guides.enabled" @change="onPostTypeToggle('guides')">
                                <span class="switch-slider"></span>
                            </label>
                            <i class="bi bi-chevron-down settings-accordion-arrow"></i>
                        </div>
                    </button>

                    <div class="settings-accordion-content" x-show="postTypes.guides.expanded" x-collapse>
                        <div class="settings-accordion-body">
                            <div class="form-row">
                                <div class="form-group">
                                    <label class="form-label">Post Type Slug</label>
                                    <input type="text" class="input" x-model="postTypes.guides.slug" placeholder="guides" :disabled="!postTypes.guides.enabled">
                                    <p class="form-hint">URL slug: yoursite.com/<strong x-text="postTypes.guides.slug || 'guides'"></strong>/post-name</p>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Menu Name</label>
                                    <input type="text" class="input" x-model="postTypes.guides.menu_name" placeholder="Guides" :disabled="!postTypes.guides.enabled">
                                    <p class="form-hint">Name shown in admin menu</p>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group">
                                    <label class="form-label">Singular Name</label>
                                    <input type="text" class="input" x-model="postTypes.guides.singular" placeholder="Guide" :disabled="!postTypes.guides.enabled">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Plural Name</label>
                                    <input type="text" class="input" x-model="postTypes.guides.plural" placeholder="Guides" :disabled="!postTypes.guides.enabled">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Menu Icon</label>
                                <input type="text" class="input" x-model="postTypes.guides.icon" placeholder="dashicons-book" :disabled="!postTypes.guides.enabled">
                                <p class="form-hint">Dashicon class name. <a href="https://developer.wordpress.org/resource/dashicons/" target="_blank">Browse icons</a></p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Important Notice -->
                <div class="settings-info settings-info-warning" style="margin-top: var(--space-4);">
                    <i class="bi bi-exclamation-triangle"></i>
                    <div>
                        <strong>Note:</strong> After enabling or changing post type settings, you may need to go to <strong>Settings > Permalinks</strong> and click "Save Changes" to refresh rewrite rules.
                    </div>
                </div>
            </div>

            <!-- ============================================
                 DATABASE TAB
                 ============================================ -->
            <div x-show="activeTab === 'database'" x-cloak>
                <!-- Schema Update -->
                <div class="settings-section">
                    <h3 class="settings-section-title"><i class="bi bi-database-gear"></i> Database Schema</h3>
                    <p class="form-hint" style="margin-bottom: var(--space-3);">
                        Create or update database tables for all ACMS plugins. Run this after installing on a new host or updating plugins.
                    </p>

                    <!-- Result -->
                    <div x-show="schemaResult" x-cloak class="settings-info" :class="schemaResult?.success ? 'settings-info-success' : 'settings-info-warning'" style="margin-bottom: var(--space-3);">
                        <i class="bi" :class="schemaResult?.success ? 'bi-check-circle' : 'bi-exclamation-triangle'"></i>
                        <div>
                            <strong x-text="schemaResult?.message"></strong>
                            <template x-if="schemaResult?.tables">
                                <div style="margin-top: 4px; font-size: 12px; opacity: 0.8;">
                                    <span x-text="schemaResult.tables.length + ' tables:'"></span>
                                    <span x-text="schemaResult.tables.join(', ')"></span>
                                </div>
                            </template>
                            <template x-if="schemaResult?.plugins">
                                <div style="margin-top: 4px; font-size: 12px;">
                                    <template x-for="(info, name) in schemaResult.plugins" :key="name">
                                        <div>
                                            <span x-text="name"></span>:
                                            <span :class="info.success ? 'text-success' : 'text-error'" x-text="info.message"></span>
                                        </div>
                                    </template>
                                </div>
                            </template>
                        </div>
                    </div>

                    <button class="btn btn-primary" @click="updateSchema()" :disabled="isUpdatingSchema">
                        <i class="bi" :class="isUpdatingSchema ? 'bi-arrow-repeat animate-spin' : 'bi-database-gear'"></i>
                        <span x-text="isUpdatingSchema ? 'Updating...' : 'Update Schema'"></span>
                    </button>
                </div>

                <!-- Plugin Versions -->
                <div class="settings-section" style="margin-top: var(--space-4);">
                    <h3 class="settings-section-title"><i class="bi bi-info-circle"></i> Plugin Versions</h3>
                    <div style="display: grid; gap: 8px;">
                        <div style="display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid var(--border-color);">
                            <span style="color: var(--text-secondary);">AffiliateCMS Pro</span>
                            <code style="font-size: 12px;"><?php echo esc_html(defined('ACMS_VERSION') ? ACMS_VERSION : 'N/A'); ?></code>
                        </div>
                        <div style="display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid var(--border-color);">
                            <span style="color: var(--text-secondary);">AffiliateCMS Cat</span>
                            <code style="font-size: 12px;"><?php echo esc_html(defined('ACMS_CAT_VERSION') ? ACMS_CAT_VERSION : 'N/A'); ?></code>
                        </div>
                        <div style="display: flex; justify-content: space-between; padding: 8px 0;">
                            <span style="color: var(--text-secondary);">AffiliateCMS AI</span>
                            <code style="font-size: 12px;"><?php echo esc_html(defined('ACMS_AI_VERSION') ? ACMS_AI_VERSION : 'N/A'); ?></code>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" @click="showSettingsModal = false" :disabled="isSaving">Cancel</button>
            <button class="btn btn-primary" @click="saveSettings()" :disabled="isSaving || isLoading">
                <i class="bi" :class="isSaving ? 'bi-arrow-repeat animate-spin' : 'bi-floppy'"></i>
                <span x-text="isSaving ? 'Saving...' : 'Save Settings'"></span>
            </button>
        </div>
    </div>
</div>

<script>
console.log('[ACMS] Settings modal script loaded');
document.addEventListener('alpine:init', () => {
    console.log('[ACMS] Registering settingsModal component');
    Alpine.data('settingsModal', () => ({
        activeTab: 'general',
        isLoading: true,
        isSaving: false,
        isUpdatingSchema: false,
        schemaResult: null,

        // Accordion states
        crawlbaseExpanded: true,
        paapiExpanded: false,

        // Dropdown states
        primaryProviderOpen: false,
        fallbackProviderOpen: false,
        marketplaceOpen: false,

        // General settings
        settings: {
            default_provider: 'crawlbase',
            fallback_provider: 'none',
            cache_duration: 24,
            auto_update: true,
            default_template: 'list',
            show_price: true,
            show_rating: true,
            show_prime_badge: true,
            show_stock_status: true,
            show_update: true,
            rating_display_type: 'score',
            // Affiliate link settings (tag comes from paapiPartnerTag)
            enable_utm: false,
            utm_source: '',
            utm_medium: 'affiliate',
            utm_apply_to_amazon: false,
            cf_param: '',
            redirect_enabled: true,
            redirect_slug: 'go',
            open_new_tab: true,
            nofollow_links: true,
            button_text: 'View on Amazon',
            affiliate_tag: '',
            custom_url_params: 'linkCode=ogi&th=1&psc=1',
            // Auto Update settings
            update_enabled: false,
            update_interval: 24,
            update_worker_count: 3,
            worker_count: 3
        },

        // Crawlbase
        crawlbaseToken: '',
        crawlbaseTesting: false,
        crawlbaseStatus: null,
        showCrawlbaseToken: false,

        // PA-API
        paapiAccessKey: '',
        paapiSecretKey: '',
        paapiPartnerTag: '',
        paapiRegion: 'com',
        paapiTesting: false,
        paapiStatus: null,
        showPaapiSecret: false,
        hasExistingSecret: false,

        // Post Types
        postTypes: {
            reviews: {
                enabled: false,
                expanded: true,
                slug: 'reviews',
                menu_name: 'Reviews',
                singular: 'Review',
                plural: 'Reviews',
                icon: 'dashicons-star-half'
            },
            deals: {
                enabled: false,
                expanded: false,
                slug: 'deals',
                menu_name: 'Deals',
                singular: 'Deal',
                plural: 'Deals',
                icon: 'dashicons-tag'
            },
            guides: {
                enabled: false,
                expanded: false,
                slug: 'guides',
                menu_name: 'Guides',
                singular: 'Guide',
                plural: 'Guides',
                icon: 'dashicons-book'
            }
        },

        regionOptions: [
            { value: 'com', label: 'United States (.com)' },
            { value: 'co.uk', label: 'United Kingdom (.co.uk)' },
            { value: 'de', label: 'Germany (.de)' },
            { value: 'fr', label: 'France (.fr)' },
            { value: 'it', label: 'Italy (.it)' },
            { value: 'es', label: 'Spain (.es)' },
            { value: 'ca', label: 'Canada (.ca)' },
            { value: 'co.jp', label: 'Japan (.co.jp)' },
            { value: 'in', label: 'India (.in)' },
            { value: 'com.au', label: 'Australia (.com.au)' },
            { value: 'com.br', label: 'Brazil (.com.br)' },
            { value: 'com.mx', label: 'Mexico (.com.mx)' }
        ],

        async init() {
            console.log('[ACMS] settingsModal init() called');
            await this.loadSettings();
        },

        async loadSettings() {
            this.isLoading = true;
            try {
                console.log('[ACMS] loadSettings() fetching from', acmsConfig.restUrl + 'settings');
                const response = await fetch(acmsConfig.restUrl + 'settings', {
                    headers: { 'X-WP-Nonce': acmsConfig.nonce }
                });
                const result = await response.json();
                if (result.success && result.data) {
                    // Merge with defaults
                    this.settings = { ...this.settings, ...result.data.general };
                    this.crawlbaseToken = result.data.crawlbase?.token || '';
                    this.paapiAccessKey = result.data.paapi?.access_key || '';
                    this.paapiPartnerTag = result.data.paapi?.partner_tag || '';
                    this.paapiRegion = result.data.paapi?.region || 'com';
                    this.hasExistingSecret = result.data.paapi?.has_secret_key || false;

                    // Load automation settings (Auto Update, with fallback from old rescrape keys)
                    if (result.data.automation) {
                        const auto = result.data.automation;
                        this.settings.update_enabled = auto.update_enabled ?? auto.rescrape_enabled ?? false;
                        this.settings.update_interval = auto.update_interval ?? auto.rescrape_interval ?? 24;
                        this.settings.update_worker_count = auto.update_worker_count ?? 3;
                        this.settings.worker_count = auto.worker_count ?? 3;
                    }

                    // Auto-expand the configured API section
                    if (this.paapiAccessKey && !this.crawlbaseToken) {
                        this.crawlbaseExpanded = false;
                        this.paapiExpanded = true;
                    }

                    // Load post types settings
                    if (result.data.post_types) {
                        for (const key in result.data.post_types) {
                            if (this.postTypes[key]) {
                                this.postTypes[key] = {
                                    ...this.postTypes[key],
                                    ...result.data.post_types[key],
                                    expanded: this.postTypes[key].expanded
                                };
                            }
                        }
                    }
                }
            } catch (error) {
                console.error('[ACMS] loadSettings() error:', error);
            } finally {
                console.log('[ACMS] loadSettings() completed, isLoading =', this.isLoading);
                this.isLoading = false;
            }
        },

        onPostTypeToggle(type) {
            // Auto-expand when enabling
            if (this.postTypes[type].enabled) {
                this.postTypes[type].expanded = true;
            }
        },

        async saveSettings() {
            this.isSaving = true;
            try {
                const response = await fetch(acmsConfig.restUrl + 'settings', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': acmsConfig.nonce
                    },
                    body: JSON.stringify({
                        general: this.settings,
                        automation: {
                            update_enabled: this.settings.update_enabled,
                            update_interval: this.settings.update_interval,
                            update_worker_count: this.settings.update_worker_count,
                            worker_count: this.settings.worker_count
                        },
                        crawlbase_token: this.crawlbaseToken,
                        paapi_access_key: this.paapiAccessKey,
                        paapi_secret_key: this.paapiSecretKey,
                        paapi_partner_tag: this.paapiPartnerTag,
                        paapi_region: this.paapiRegion,
                        post_types: {
                            reviews: { ...this.postTypes.reviews, expanded: undefined },
                            deals: { ...this.postTypes.deals, expanded: undefined },
                            guides: { ...this.postTypes.guides, expanded: undefined }
                        }
                    })
                });
                const result = await response.json();
                if (result.success) {
                    this.hasExistingSecret = this.paapiSecretKey ? true : this.hasExistingSecret;
                    this.paapiSecretKey = ''; // Clear after save
                    window.dispatchEvent(new CustomEvent('show-toast', {
                        detail: { type: 'success', title: 'Saved', message: 'Settings saved successfully' }
                    }));
                } else {
                    window.dispatchEvent(new CustomEvent('show-toast', {
                        detail: { type: 'error', title: 'Error', message: result.message || 'Failed to save' }
                    }));
                }
            } catch (error) {
                window.dispatchEvent(new CustomEvent('show-toast', {
                    detail: { type: 'error', title: 'Error', message: 'Failed to save settings' }
                }));
            } finally {
                this.isSaving = false;
            }
        },

        async updateSchema() {
            this.isUpdatingSchema = true;
            this.schemaResult = null;
            try {
                const url = acmsConfig.restUrl + 'settings/update-schema';
                const response = await fetch(url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': acmsConfig.nonce
                    }
                });
                if (!response.ok) {
                    const text = await response.text();
                    this.schemaResult = { success: false, message: `HTTP ${response.status}: ${text.substring(0, 300)}` };
                    return;
                }
                const text = await response.text();
                let result;
                try {
                    result = JSON.parse(text);
                } catch (e) {
                    this.schemaResult = { success: false, message: `Invalid JSON response: ${text.substring(0, 300)}` };
                    return;
                }
                this.schemaResult = {
                    success: result.success,
                    message: result.message,
                    tables: result.data?.tables || [],
                    plugins: result.data?.plugins || {}
                };
                window.dispatchEvent(new CustomEvent('show-toast', {
                    detail: {
                        type: result.success ? 'success' : 'warning',
                        title: result.success ? 'Schema Updated' : 'Warning',
                        message: result.message
                    }
                }));
            } catch (error) {
                this.schemaResult = { success: false, message: 'Request failed: ' + error.message };
            } finally {
                this.isUpdatingSchema = false;
            }
        },

        async testCrawlbase() {
            if (!this.crawlbaseToken) return;
            this.crawlbaseTesting = true;
            this.crawlbaseStatus = null;
            try {
                const response = await fetch(acmsConfig.restUrl + 'settings/test-crawlbase', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': acmsConfig.nonce
                    },
                    body: JSON.stringify({ token: this.crawlbaseToken })
                });
                const result = await response.json();
                this.crawlbaseStatus = result.success ? 'success' : 'error';
                window.dispatchEvent(new CustomEvent('show-toast', {
                    detail: {
                        type: result.success ? 'success' : 'error',
                        title: result.success ? 'Connection Successful' : 'Connection Failed',
                        message: result.message
                    }
                }));
            } catch (error) {
                this.crawlbaseStatus = 'error';
                window.dispatchEvent(new CustomEvent('show-toast', {
                    detail: { type: 'error', title: 'Error', message: 'Failed to test connection' }
                }));
            } finally {
                this.crawlbaseTesting = false;
            }
        },

        async testPaapi() {
            if (!this.paapiAccessKey || !this.paapiPartnerTag) return;
            this.paapiTesting = true;
            this.paapiStatus = null;
            try {
                const response = await fetch(acmsConfig.restUrl + 'settings/test-paapi', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': acmsConfig.nonce
                    },
                    body: JSON.stringify({
                        access_key: this.paapiAccessKey,
                        secret_key: this.paapiSecretKey,
                        partner_tag: this.paapiPartnerTag,
                        region: this.paapiRegion
                    })
                });
                const result = await response.json();
                this.paapiStatus = result.success ? 'success' : 'error';
                window.dispatchEvent(new CustomEvent('show-toast', {
                    detail: {
                        type: result.success ? 'success' : 'error',
                        title: result.success ? 'Connection Successful' : 'Connection Failed',
                        message: result.message
                    }
                }));
            } catch (error) {
                this.paapiStatus = 'error';
                window.dispatchEvent(new CustomEvent('show-toast', {
                    detail: { type: 'error', title: 'Error', message: 'Failed to test connection' }
                }));
            } finally {
                this.paapiTesting = false;
            }
        }
    }));
});
</script>
