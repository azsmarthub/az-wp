<?php
/**
 * Scrape Log Modal - Real-time scraping log display
 *
 * @package AffiliateCMS\Pro
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<!-- Scrape Log Modal -->
<div class="modal-backdrop" x-show="showScrapeLogModal" x-cloak @click.self="!scraping && closeScrapeLog()">
    <div class="modal scrape-log-modal" @click.stop>
        <div class="modal-header">
            <h2 class="modal-title">
                <i class="bi bi-terminal"></i>
                Scrape Log
            </h2>
            <div class="modal-header-actions">
                <button class="btn-icon btn-icon-sm"
                        @click="copyLogToClipboard()"
                        :disabled="scraping || scrapeLogs.length === 0"
                        title="Copy log to clipboard">
                    <i class="bi" :class="logCopied ? 'bi-check-lg text-success' : 'bi-clipboard'"></i>
                </button>
                <button class="btn-icon btn-icon-sm" @click="closeScrapeLog()" :disabled="scraping">
                    <i class="bi bi-x-lg"></i>
                </button>
            </div>
        </div>
        <div class="modal-body" style="padding: 0;">
            <!-- Product Info Header -->
            <div class="scrape-log-header" x-show="scrapeLogProduct">
                <div class="scrape-log-product">
                    <code class="scrape-log-asin" x-text="scrapeLogProduct?.asin"></code>
                    <span class="scrape-log-divider">|</span>
                    <span class="scrape-log-title" x-text="scrapeLogProduct?.title ? scrapeLogProduct.title.substring(0, 50) + '...' : 'Pending scrape'"></span>
                </div>
                <div class="scrape-log-status">
                    <span class="scrape-status-indicator" :class="{ 'running': scraping, 'success': !scraping && scrapeSuccess, 'error': !scraping && !scrapeSuccess && scrapeLogs.length > 0 }">
                        <i class="bi" :class="scraping ? 'bi-circle-fill pulse' : (scrapeSuccess ? 'bi-check-circle-fill' : 'bi-x-circle-fill')"></i>
                        <span x-text="scraping ? 'Scraping...' : (scrapeSuccess ? 'Success' : 'Failed')"></span>
                    </span>
                </div>
            </div>

            <!-- Terminal Log -->
            <div class="scrape-log-terminal">
                <template x-for="(log, index) in scrapeLogs" :key="index">
                    <div class="log-line" :class="'log-' + log.type">
                        <span class="log-time" x-text="log.time"></span>
                        <span class="log-prefix" x-text="log.type === 'success' ? '[OK]' : (log.type === 'error' ? '[ERR]' : (log.type === 'data' ? '[DATA]' : '[INFO]'))"></span>
                        <span class="log-msg" x-text="log.msg"></span>
                    </div>
                </template>
                <!-- Empty state -->
                <div class="log-empty" x-show="!scraping && scrapeLogs.length === 0">
                    <i class="bi bi-terminal"></i>
                    <p>No logs yet</p>
                </div>
                <!-- Cursor blink when scraping -->
                <div class="log-cursor" x-show="scraping">
                    <span class="cursor-blink">_</span>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <div class="scrape-log-footer-info">
                <span x-show="!scraping && scrapeSuccess" class="text-success">
                    <i class="bi bi-check-circle"></i>
                    Scrape completed successfully
                </span>
                <span x-show="!scraping && !scrapeSuccess && scrapeLogs.length > 0" class="text-danger">
                    <i class="bi bi-x-circle"></i>
                    Scrape failed
                </span>
                <span x-show="scraping" class="text-muted">
                    <i class="bi bi-hourglass-split"></i>
                    Processing...
                </span>
            </div>
            <button class="btn btn-secondary" @click="closeScrapeLog()" :disabled="scraping">
                <span x-text="scraping ? 'Please wait...' : 'Close'"></span>
            </button>
        </div>
    </div>
</div>
