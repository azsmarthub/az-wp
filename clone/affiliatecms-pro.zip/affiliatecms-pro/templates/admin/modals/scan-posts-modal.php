<?php
/**
 * Scan Posts Modal - Scan posts for ASINs with source categorization
 *
 * Shows product status (scraped/failed/pending) and category associations.
 * Works on both Products page and Cat Queue page.
 *
 * @package AffiliateCMS\Pro
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<!-- Scan Posts Modal - Self-contained CSS for cross-page compatibility -->
<style>
.scan-summary-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 20px; }
.scan-summary-item { padding: 16px; background: var(--bg-elevated); border: 1px solid var(--border); border-radius: var(--radius-md); text-align: center; }
.scan-summary-item.highlight { background: var(--success-light); border-color: rgba(34, 197, 94, 0.3); }
.scan-summary-value { font-size: 24px; font-weight: 600; color: var(--text-primary); }
.scan-summary-item.highlight .scan-summary-value { color: var(--success); }
.scan-summary-label { font-size: 12px; color: var(--text-muted); margin-top: 4px; }
.scan-summary-item.highlight .scan-summary-label { color: var(--success); }
.scan-summary-item.error { background: var(--error-light, #fef2f2); border-color: rgba(239, 68, 68, 0.3); }
.scan-summary-item.error .scan-summary-value { color: var(--error); }
.scan-summary-item.error .scan-summary-label { color: var(--error); }
.scan-tabs { display: flex; gap: 0; margin-bottom: 16px; border-bottom: 1px solid var(--border); }
.scan-tab { display: flex; align-items: center; gap: 8px; padding: 12px 20px; background: transparent; border: none; border-bottom: 2px solid transparent; margin-bottom: -1px; cursor: pointer; font-size: 13px; font-weight: 500; color: var(--text-muted); transition: all 0.15s; }
.scan-tab:hover { color: var(--text-secondary); background: var(--bg-hover); }
.scan-tab.active { color: var(--primary); border-bottom-color: var(--primary); }
.scan-tab .badge { font-size: 11px; padding: 2px 8px; }
.scan-results-list { display: flex; flex-direction: column; gap: 8px; max-height: 300px; overflow-y: auto; padding-right: 4px; }
.scan-asin-item { display: flex; align-items: center; gap: 10px; padding: 10px 14px; background: var(--bg-elevated); border: 1px solid var(--border); border-radius: var(--radius-md); transition: background 0.15s; }
.scan-asin-item:hover { background: var(--bg-hover); }
.scan-asin-item.is-new { border-left: 3px solid var(--success); }
.scan-asin-item.is-new:not(.is-selected) { opacity: 0.5; border-left-color: var(--border); }
.scan-asin-item.is-new.is-selected { background: var(--success-light); }
.scan-asin-item.is-failed { border-left: 3px solid var(--error); }
.scan-asin-code { font-size: 12px; padding: 3px 10px; background: var(--bg-surface); border: 1px solid var(--border); border-radius: 4px; font-weight: 600; font-family: 'JetBrains Mono', 'Fira Code', monospace; letter-spacing: 0.5px; }
.scan-asin-arrow { font-size: 11px; color: var(--text-muted); }
.scan-asin-posts { flex: 1; font-size: 13px; color: var(--text-secondary); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.scan-cat-tag { display: inline-flex; align-items: center; padding: 1px 6px; font-size: 10px; background: var(--bg-surface); border: 1px solid var(--border); border-radius: 3px; color: var(--text-muted); max-width: 120px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.scan-cat-tag.missing { background: var(--primary-light, #eff6ff); border-color: rgba(59, 130, 246, 0.3); color: var(--primary); border-style: dashed; }
.scan-type-option { display: flex; align-items: center; gap: 10px; padding: 10px 16px; background: var(--bg-elevated); border: 1px solid var(--border); border-radius: var(--radius-md); cursor: pointer; transition: all 0.15s; }
.scan-type-option:hover { background: var(--bg-hover); border-color: var(--border-hover); }
.scan-type-option.selected { border-color: var(--primary); background: var(--primary-light); }
.scan-checkbox-box { width: 20px; height: 20px; border: 2px solid var(--border); border-radius: 4px; display: flex; align-items: center; justify-content: center; transition: all 0.15s; flex-shrink: 0; }
.scan-type-option.selected .scan-checkbox-box, .scan-checkbox-box.checked { background: var(--primary); border-color: var(--primary); color: white; }
.scan-type-label { font-size: 14px; font-weight: 500; color: var(--text-primary); }
.scan-type-count { font-size: 12px; color: var(--text-muted); margin-left: auto; }
.scan-source-info { display: flex; flex-direction: column; gap: 8px; }
.scan-source-item { display: flex; align-items: flex-start; gap: 12px; padding: 12px 14px; background: var(--bg-elevated); border-radius: var(--radius-md); }
.scan-source-icon { font-size: 16px; margin-top: 2px; }
.scan-source-icon.success { color: var(--success); }
.scan-source-icon.warning { color: var(--warning); }
.scan-source-icon.muted { color: var(--text-muted); }
.scan-source-title { font-weight: 500; font-size: 13px; color: var(--text-primary); }
.scan-source-desc { font-size: 12px; color: var(--text-muted); margin-top: 2px; }
/* Alert styles for scan modal tabs */
.alert { display: flex; align-items: flex-start; gap: 12px; padding: 12px 16px; border-radius: var(--radius-lg, 8px); border: 1px solid var(--border); background: var(--bg-surface); }
.alert.alert-warning { background: var(--warning-light, #fffbeb); border-color: rgba(245, 158, 11, 0.3); }
.alert.alert-secondary { background: var(--bg-elevated); border-color: var(--border); }
@media (max-width: 768px) { .scan-summary-grid { grid-template-columns: repeat(2, 1fr); } }
</style>
<!-- Scan Posts Modal -->
<div class="modal-backdrop" x-data x-show="$store.app.showScanModal" x-cloak @click.self="$store.app.showScanModal = false">
    <div class="modal modal-lg" @click.stop x-data="{
        isLoading: true,
        isScanning: false,
        scanComplete: false,
        scanProgress: 0,
        totalPosts: 0,
        scannedPosts: 0,

        // Categorized results
        shortcodeAsins: [],
        urlAsins: [],
        rawAsins: [],

        // Active tab
        activeTab: 'shortcode',

        error: null,

        // All available post types from API
        postTypes: [],

        // Selected post type slugs
        selectedTypes: [],

        // Options
        resetFailed: true,

        async init() {
            await this.loadPostTypes();
        },

        async loadPostTypes() {
            this.isLoading = true;
            this.error = null;
            try {
                const response = await fetch(acmsConfig.restUrl + 'products/count-posts', {
                    headers: {
                        'X-WP-Nonce': acmsConfig.nonce
                    }
                });
                const result = await response.json();
                if (result.success) {
                    this.postTypes = result.data.post_types || [];
                    this.totalPosts = result.data.total;
                    // Auto-select post types with content (up to first 3)
                    this.selectedTypes = this.postTypes
                        .filter(pt => pt.count > 0)
                        .slice(0, 3)
                        .map(pt => pt.slug);
                }
            } catch (err) {
                this.error = 'Failed to load post types';
            } finally {
                this.isLoading = false;
            }
        },

        isSelected(slug) {
            return this.selectedTypes.includes(slug);
        },

        toggleType(slug) {
            if (this.isSelected(slug)) {
                this.selectedTypes = this.selectedTypes.filter(s => s !== slug);
            } else {
                this.selectedTypes.push(slug);
            }
        },

        get selectedPostTypes() {
            return this.selectedTypes;
        },

        get selectedTotalPosts() {
            return this.postTypes
                .filter(pt => this.selectedTypes.includes(pt.slug))
                .reduce((sum, pt) => sum + pt.count, 0);
        },

        async startScan() {
            if (this.selectedPostTypes.length === 0) {
                $dispatch('show-toast', { type: 'error', title: 'Error', message: 'Please select at least one content type to scan' });
                return;
            }

            this.isScanning = true;
            this.scanComplete = false;
            this.scanProgress = 0;
            this.scannedPosts = 0;
            this.shortcodeAsins = [];
            this.urlAsins = [];
            this.rawAsins = [];
            this.activeTab = 'shortcode';
            this.error = null;

            // Simulate progress while waiting for API
            const progressInterval = setInterval(() => {
                if (this.scanProgress < 90) {
                    this.scanProgress += Math.random() * 10;
                    this.scannedPosts = Math.floor((this.scanProgress / 100) * this.selectedTotalPosts);
                }
            }, 200);

            try {
                const response = await fetch(acmsConfig.restUrl + 'products/scan-posts', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': acmsConfig.nonce
                    },
                    body: JSON.stringify({
                        post_types: this.selectedPostTypes
                    })
                });

                clearInterval(progressInterval);

                const result = await response.json();
                if (result.success) {
                    this.scanProgress = 100;
                    this.scannedPosts = result.data.posts_scanned;
                    this.shortcodeAsins = result.data.shortcode_asins || [];
                    this.urlAsins = result.data.url_asins || [];
                    this.rawAsins = result.data.raw_asins || [];
                    // Auto-select all new ASINs
                    this.selectedAsins = this.shortcodeAsins
                        .filter(a => a.isNew)
                        .map(a => a.asin);
                    setTimeout(() => {
                        this.isScanning = false;
                        this.scanComplete = true;
                    }, 300);
                } else {
                    throw new Error(result.message || 'Scan failed');
                }
            } catch (err) {
                clearInterval(progressInterval);
                this.error = err.message || 'Failed to scan posts';
                this.isScanning = false;
                $dispatch('show-toast', { type: 'error', title: 'Error', message: this.error });
            }
        },

        // Selected ASINs for adding
        selectedAsins: [],

        get newShortcodeAsins() {
            return this.shortcodeAsins.filter(a => a.isNew);
        },

        get newShortcodeCount() {
            return this.newShortcodeAsins.length;
        },

        get selectedNewCount() {
            return this.selectedAsins.filter(asin =>
                this.newShortcodeAsins.some(a => a.asin === asin)
            ).length;
        },

        get trackedShortcodeCount() {
            return this.shortcodeAsins.filter(a => a.inDb).length;
        },

        get failedShortcodeCount() {
            return this.shortcodeAsins.filter(a => a.productStatus === 'failed').length;
        },

        get unlinkedShortcodeCount() {
            return this.shortcodeAsins.filter(a => a.inDb && a.linkedPostCount === 0).length;
        },

        // ASINs that exist in cat queue but are NOT linked to their queue categories
        get missingCategoryLinkCount() {
            return this.shortcodeAsins.filter(a => {
                if (!a.inDb || !a.queueCategories || a.queueCategories.length === 0) return false;
                // Check if any queue category is missing from actual categories
                const linkedCatIds = (a.categories || []).map(c => c.id);
                return a.queueCategories.some(qc => !linkedCatIds.includes(qc.category_id));
            }).length;
        },

        statusBadgeClass(item) {
            if (item.isNew) return 'badge-success';
            if (item.productStatus === 'failed') return 'badge-error';
            if (item.productStatus === 'pending' || item.productStatus === 'scheduled') return 'badge-warning';
            if (item.productStatus === 'scraped') return 'badge-muted';
            return 'badge-muted';
        },

        statusBadgeText(item) {
            if (item.isNew) return 'New';
            if (item.productStatus === 'failed') return 'Failed';
            if (item.productStatus === 'pending') return 'Pending';
            if (item.productStatus === 'scheduled') return 'Scheduled';
            if (item.productStatus === 'scraped') return 'Scraped';
            return 'In DB';
        },

        isAsinSelected(asin) {
            return this.selectedAsins.includes(asin);
        },

        toggleAsin(asin) {
            if (this.isAsinSelected(asin)) {
                this.selectedAsins = this.selectedAsins.filter(a => a !== asin);
            } else {
                this.selectedAsins.push(asin);
            }
        },

        selectAllNew() {
            this.selectedAsins = this.newShortcodeAsins.map(a => a.asin);
        },

        deselectAllNew() {
            this.selectedAsins = [];
        },

        get allNewSelected() {
            return this.newShortcodeCount > 0 && this.selectedNewCount === this.newShortcodeCount;
        },

        toggleSelectAll() {
            if (this.allNewSelected) {
                this.deselectAllNew();
            } else {
                this.selectAllNew();
            }
        },

        async addNewAsins() {
            const toAdd = this.shortcodeAsins.filter(a => a.isNew && this.isAsinSelected(a.asin));
            if (toAdd.length === 0) {
                $dispatch('show-toast', { type: 'info', title: 'Info', message: 'No ASINs selected to add' });
                return;
            }

            // Build asin_post_map from scan results
            const asinPostMap = {};
            toAdd.forEach(item => {
                if (item.postDetails && item.postDetails.length > 0) {
                    asinPostMap[item.asin] = item.postDetails.map(p => p.id);
                }
            });

            try {
                const response = await fetch(acmsConfig.restUrl + 'products/bulk-add', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': acmsConfig.nonce
                    },
                    body: JSON.stringify({
                        asins: toAdd.map(a => a.asin),
                        asin_post_map: asinPostMap
                    })
                });

                const result = await response.json();
                if (result.success) {
                    $dispatch('show-toast', { type: 'success', title: 'Added', message: result.data.added + ' new ASINs added to database' });
                    $dispatch('products-updated');
                    $store.app.showScanModal = false;
                } else {
                    throw new Error(result.message || 'Failed to add ASINs');
                }
            } catch (err) {
                $dispatch('show-toast', { type: 'error', title: 'Error', message: err.message || 'Failed to add ASINs' });
            }
        },

        async updateExistingAsins() {
            const existingOnes = this.shortcodeAsins.filter(a => a.inDb);
            if (existingOnes.length === 0) {
                $dispatch('show-toast', { type: 'info', title: 'Info', message: 'No existing ASINs to update' });
                return;
            }

            // Build asin_post_map for existing ASINs
            const asinPostMap = {};
            existingOnes.forEach(item => {
                if (item.postDetails && item.postDetails.length > 0) {
                    asinPostMap[item.asin] = item.postDetails.map(p => p.id);
                }
            });

            try {
                const response = await fetch(acmsConfig.restUrl + 'products/bulk-add', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': acmsConfig.nonce
                    },
                    body: JSON.stringify({
                        asins: existingOnes.map(a => a.asin),
                        asin_post_map: asinPostMap,
                        reset_failed: this.resetFailed,
                        link_from_queue: true
                    })
                });

                const result = await response.json();
                if (result.success) {
                    let msg = result.data.updated + ' ASINs linked to posts';
                    if (result.data.category_linked > 0) {
                        msg += ', ' + result.data.category_linked + ' linked to categories';
                    }
                    if (result.data.reset_count > 0) {
                        msg += ', ' + result.data.reset_count + ' failed re-queued';
                    }
                    $dispatch('show-toast', { type: 'success', title: 'Updated', message: msg });
                    $dispatch('products-updated');
                } else {
                    throw new Error(result.message || 'Failed to update ASINs');
                }
            } catch (err) {
                $dispatch('show-toast', { type: 'error', title: 'Error', message: err.message || 'Failed to update ASINs' });
            }
        }
    }">
        <div class="modal-header">
            <h2 class="modal-title">
                <i class="bi bi-search-heart" style="color: var(--primary);"></i>
                Scan Posts for ASINs
            </h2>
            <button class="btn-icon btn-icon-sm" @click="$store.app.showScanModal = false">
                <i class="bi bi-x-lg"></i>
            </button>
        </div>
        <div class="modal-body">
            <!-- Loading State -->
            <div x-show="isLoading" style="text-align: center; padding: 40px 20px;">
                <div class="spinner spinner-lg" style="margin: 0 auto 16px;"></div>
                <div class="text-muted">Loading post counts...</div>
            </div>

            <!-- Initial State: Select Content Types -->
            <div x-show="!isLoading && !isScanning && !scanComplete">
                <!-- Content Types to Scan -->
                <div class="form-group" style="margin-bottom: 24px;">
                    <label class="form-label" style="margin-bottom: 12px;">Content Types to Scan</label>
                    <div style="display: flex; flex-wrap: wrap; gap: 10px;">
                        <template x-for="pt in postTypes" :key="pt.slug">
                            <label class="scan-type-option" :class="{ 'selected': isSelected(pt.slug) }" @click.prevent="toggleType(pt.slug)">
                                <span class="scan-checkbox-box" :class="{ 'checked': isSelected(pt.slug) }">
                                    <i class="bi bi-check2" x-show="isSelected(pt.slug)" style="font-size: 12px;"></i>
                                </span>
                                <span class="scan-type-label" x-text="pt.name"></span>
                                <span class="scan-type-count" x-text="pt.count + ' items'"></span>
                            </label>
                        </template>
                    </div>
                    <div x-show="postTypes.length === 0" class="text-muted" style="padding: 12px 0; font-size: 13px;">
                        No content types available
                    </div>
                </div>

                <!-- What Will Be Scanned -->
                <div class="form-group">
                    <label class="form-label" style="margin-bottom: 12px;">What will be detected</label>
                    <div class="scan-source-info">
                        <div class="scan-source-item">
                            <i class="bi bi-code-square scan-source-icon success"></i>
                            <div>
                                <div class="scan-source-title">
                                    Shortcodes
                                    <span class="badge badge-success" style="font-size: 10px; margin-left: 6px;">Can Add</span>
                                </div>
                                <div class="scan-source-desc">[acms_card], [acms_grid], [acms_list], [acms_table], [acms_link]</div>
                            </div>
                        </div>
                        <div class="scan-source-item">
                            <i class="bi bi-link-45deg scan-source-icon warning"></i>
                            <div>
                                <div class="scan-source-title">
                                    Amazon URLs
                                    <span class="badge badge-warning" style="font-size: 10px; margin-left: 6px;">Info Only</span>
                                </div>
                                <div class="scan-source-desc">amazon.com/dp/..., amzn.to/... links</div>
                            </div>
                        </div>
                        <div class="scan-source-item">
                            <i class="bi bi-hash scan-source-icon muted"></i>
                            <div>
                                <div class="scan-source-title">
                                    Raw ASINs
                                    <span class="badge badge-muted" style="font-size: 10px; margin-left: 6px;">Info Only</span>
                                </div>
                                <div class="scan-source-desc">10-character codes like B0123456789</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Scanning State -->
            <div x-show="isScanning" style="text-align: center; padding: 40px 20px;">
                <div class="spinner spinner-lg" style="margin: 0 auto 24px;"></div>
                <div style="font-size: 16px; font-weight: 500; margin-bottom: 8px;">Scanning posts...</div>
                <div class="text-secondary" style="font-size: 14px; margin-bottom: 20px;">
                    <span x-text="scannedPosts"></span> / <span x-text="selectedTotalPosts"></span> posts scanned
                </div>
                <div class="progress" style="width: 100%; max-width: 400px; margin: 0 auto; height: 8px; background: var(--bg-surface); border-radius: 4px; overflow: hidden;">
                    <div class="progress-bar" :style="'width: ' + Math.min(scanProgress, 100) + '%'" style="height: 100%; background: var(--primary); transition: width 0.3s;"></div>
                </div>
                <div class="text-muted" style="font-size: 12px; margin-top: 8px;" x-text="Math.round(Math.min(scanProgress, 100)) + '% complete'"></div>
            </div>

            <!-- Results State -->
            <div x-show="scanComplete">
                <!-- Summary Stats -->
                <div class="scan-summary-grid">
                    <div class="scan-summary-item">
                        <div class="scan-summary-value" x-text="shortcodeAsins.length"></div>
                        <div class="scan-summary-label">Shortcodes</div>
                    </div>
                    <div class="scan-summary-item highlight">
                        <div class="scan-summary-value" x-text="newShortcodeCount"></div>
                        <div class="scan-summary-label">New ASINs</div>
                    </div>
                    <div class="scan-summary-item" :class="{ 'error': failedShortcodeCount > 0 }">
                        <div class="scan-summary-value" x-text="failedShortcodeCount"></div>
                        <div class="scan-summary-label">Failed</div>
                    </div>
                    <div class="scan-summary-item" :class="{ 'error': missingCategoryLinkCount > 0 }">
                        <div class="scan-summary-value" x-text="missingCategoryLinkCount"></div>
                        <div class="scan-summary-label">Unlinked Cat</div>
                    </div>
                </div>

                <!-- Missing Category Links Notice -->
                <div x-show="missingCategoryLinkCount > 0" style="margin-bottom: 12px; padding: 10px 14px; background: var(--primary-light, #eff6ff); border: 1px solid rgba(59, 130, 246, 0.3); border-radius: var(--radius-sm); display: flex; align-items: center; gap: 8px; font-size: 13px;">
                    <i class="bi bi-link-45deg" style="color: var(--primary); font-size: 16px;"></i>
                    <span><strong x-text="missingCategoryLinkCount"></strong> ASINs can be re-linked to categories from queue data</span>
                </div>

                <!-- Tabs -->
                <div class="scan-tabs">
                    <button class="scan-tab" :class="{ 'active': activeTab === 'shortcode' }" @click="activeTab = 'shortcode'">
                        <i class="bi bi-code-square"></i>
                        Shortcodes
                        <span class="badge" :class="shortcodeAsins.length > 0 ? 'badge-success' : 'badge-muted'" x-text="shortcodeAsins.length"></span>
                    </button>
                    <button class="scan-tab" :class="{ 'active': activeTab === 'url' }" @click="activeTab = 'url'">
                        <i class="bi bi-link-45deg"></i>
                        URLs
                        <span class="badge badge-muted" x-text="urlAsins.length"></span>
                    </button>
                    <button class="scan-tab" :class="{ 'active': activeTab === 'raw' }" @click="activeTab = 'raw'">
                        <i class="bi bi-hash"></i>
                        Raw
                        <span class="badge badge-muted" x-text="rawAsins.length"></span>
                    </button>
                </div>

                <!-- Results List Container -->
                <div style="max-height: 340px; overflow-y: auto;">
                    <!-- Shortcode ASINs Tab -->
                    <div x-show="activeTab === 'shortcode'">
                        <template x-if="shortcodeAsins.length === 0">
                            <div style="text-align: center; padding: 30px; color: var(--text-muted);">
                                <i class="bi bi-inbox" style="font-size: 32px; opacity: 0.5;"></i>
                                <p style="margin-top: 8px;">No shortcode ASINs found</p>
                            </div>
                        </template>

                        <!-- Select All Header for New ASINs -->
                        <div x-show="newShortcodeCount > 0" style="display: flex; align-items: center; justify-content: space-between; padding: 8px 12px; margin-bottom: 8px; background: var(--bg-surface); border-radius: var(--radius-sm);">
                            <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; font-size: 13px;">
                                <span class="scan-checkbox-box" :class="{ 'checked': allNewSelected }" @click="toggleSelectAll()" style="width: 18px; height: 18px;">
                                    <i class="bi" :class="allNewSelected ? 'bi-check2' : (selectedNewCount > 0 ? 'bi-dash' : '')" style="font-size: 12px;"></i>
                                </span>
                                <span class="text-muted">Select all new ASINs</span>
                            </label>
                            <span class="text-muted" style="font-size: 12px;">
                                <span x-text="selectedNewCount"></span> / <span x-text="newShortcodeCount"></span> selected
                            </span>
                        </div>

                        <div class="scan-results-list" x-show="shortcodeAsins.length > 0">
                            <template x-for="item in shortcodeAsins" :key="item.asin">
                                <div class="scan-asin-item" :class="{ 'is-new': item.isNew, 'is-selected': item.isNew && isAsinSelected(item.asin), 'is-failed': item.productStatus === 'failed' }">
                                    <!-- Checkbox for new ASINs -->
                                    <template x-if="item.isNew">
                                        <span class="scan-checkbox-box" :class="{ 'checked': isAsinSelected(item.asin) }" @click.stop="toggleAsin(item.asin)" style="width: 18px; height: 18px; cursor: pointer; flex-shrink: 0;">
                                            <i class="bi bi-check2" x-show="isAsinSelected(item.asin)" style="font-size: 12px;"></i>
                                        </span>
                                    </template>
                                    <!-- Status badge -->
                                    <span class="badge" :class="statusBadgeClass(item)" x-text="statusBadgeText(item)"></span>
                                    <code class="scan-asin-code" x-text="item.asin"></code>
                                    <i class="bi bi-arrow-right scan-asin-arrow"></i>
                                    <div style="flex: 1; min-width: 0;">
                                        <span class="scan-asin-posts" x-text="item.posts.join(', ')"></span>
                                        <!-- Category tags -->
                                        <div x-show="(item.categories && item.categories.length > 0) || (item.queueCategories && item.queueCategories.length > 0)" style="display: flex; flex-wrap: wrap; gap: 4px; margin-top: 3px;">
                                            <!-- Linked categories (solid) -->
                                            <template x-for="cat in (item.categories || []).slice(0, 3)" :key="'cat-' + cat.id">
                                                <span class="scan-cat-tag" x-text="cat.name"></span>
                                            </template>
                                            <template x-if="(item.categories || []).length > 3">
                                                <span class="scan-cat-tag" x-text="'+' + (item.categories.length - 3)"></span>
                                            </template>
                                            <!-- Missing queue categories (dashed blue) -->
                                            <template x-for="qc in (item.queueCategories || []).filter(qc => !(item.categories || []).some(c => c.id === qc.category_id))" :key="'qc-' + qc.queue_id">
                                                <span class="scan-cat-tag missing" :title="'From queue: ' + qc.keyword" x-text="qc.category_name"></span>
                                            </template>
                                        </div>
                                    </div>
                                    <template x-if="item.postDetails && item.postDetails.length > 0">
                                        <a class="btn-icon btn-icon-xs" :href="item.postDetails[0].edit_url" target="_blank" title="Edit Post" @click.stop>
                                            <i class="bi bi-pencil"></i>
                                        </a>
                                    </template>
                                </div>
                            </template>
                        </div>
                    </div>

                    <!-- URL ASINs Tab -->
                    <div x-show="activeTab === 'url'">
                        <div class="alert alert-warning" style="margin-bottom: 12px; padding: 10px 14px;">
                            <i class="bi bi-exclamation-triangle" style="margin-right: 8px;"></i>
                            <span style="font-size: 13px;">These ASINs are from Amazon URLs in your content. Convert them to [acms] shortcodes to track them.</span>
                        </div>
                        <template x-if="urlAsins.length === 0">
                            <div style="text-align: center; padding: 30px; color: var(--text-muted);">
                                <i class="bi bi-inbox" style="font-size: 32px; opacity: 0.5;"></i>
                                <p style="margin-top: 8px;">No Amazon URL ASINs found</p>
                            </div>
                        </template>
                        <div class="scan-results-list" x-show="urlAsins.length > 0">
                            <template x-for="item in urlAsins" :key="item.asin">
                                <div class="scan-asin-item">
                                    <span class="badge" :class="statusBadgeClass(item)" x-text="item.inDb ? statusBadgeText(item) : 'URL'"></span>
                                    <code class="scan-asin-code" x-text="item.asin"></code>
                                    <i class="bi bi-arrow-right scan-asin-arrow"></i>
                                    <div style="flex: 1; min-width: 0;">
                                        <span class="scan-asin-posts" x-text="item.posts.join(', ')"></span>
                                        <template x-if="item.categories && item.categories.length > 0">
                                            <div style="display: flex; flex-wrap: wrap; gap: 4px; margin-top: 3px;">
                                                <template x-for="cat in item.categories.slice(0, 3)" :key="cat.id">
                                                    <span class="scan-cat-tag" x-text="cat.name"></span>
                                                </template>
                                            </div>
                                        </template>
                                    </div>
                                    <template x-if="item.postDetails && item.postDetails.length > 0">
                                        <a class="btn-icon btn-icon-xs" :href="item.postDetails[0].edit_url" target="_blank" title="Edit Post" @click.stop>
                                            <i class="bi bi-pencil"></i>
                                        </a>
                                    </template>
                                </div>
                            </template>
                        </div>
                    </div>

                    <!-- Raw ASINs Tab -->
                    <div x-show="activeTab === 'raw'">
                        <div class="alert alert-secondary" style="margin-bottom: 12px; padding: 10px 14px; background: var(--bg-elevated);">
                            <i class="bi bi-info-circle" style="margin-right: 8px;"></i>
                            <span style="font-size: 13px;">These look like ASINs but aren't in shortcodes or URLs. They may be false positives.</span>
                        </div>
                        <template x-if="rawAsins.length === 0">
                            <div style="text-align: center; padding: 30px; color: var(--text-muted);">
                                <i class="bi bi-inbox" style="font-size: 32px; opacity: 0.5;"></i>
                                <p style="margin-top: 8px;">No raw ASIN codes found</p>
                            </div>
                        </template>
                        <div class="scan-results-list" x-show="rawAsins.length > 0">
                            <template x-for="item in rawAsins" :key="item.asin">
                                <div class="scan-asin-item">
                                    <span class="badge badge-muted">Raw</span>
                                    <code class="scan-asin-code" x-text="item.asin"></code>
                                    <i class="bi bi-arrow-right scan-asin-arrow"></i>
                                    <span class="scan-asin-posts" x-text="item.posts.join(', ')"></span>
                                    <template x-if="item.postDetails && item.postDetails.length > 0">
                                        <a class="btn-icon btn-icon-xs" :href="item.postDetails[0].edit_url" target="_blank" title="Edit Post" @click.stop>
                                            <i class="bi bi-pencil"></i>
                                        </a>
                                    </template>
                                </div>
                            </template>
                        </div>
                    </div>
                </div>

                <!-- Reset Failed Option (shown when failed ASINs exist) -->
                <div x-show="failedShortcodeCount > 0" style="margin-top: 12px; padding: 10px 14px; background: var(--bg-surface); border-radius: var(--radius-sm); display: flex; align-items: center; gap: 10px;">
                    <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; font-size: 13px; flex: 1;">
                        <input type="checkbox" x-model="resetFailed" style="width: 16px; height: 16px; accent-color: var(--primary);">
                        <span>Re-queue <strong x-text="failedShortcodeCount"></strong> failed ASINs for scraping</span>
                    </label>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <template x-if="isLoading">
                <div></div>
            </template>
            <template x-if="!isLoading && !isScanning && !scanComplete">
                <div style="display: flex; gap: 8px; width: 100%; justify-content: space-between; align-items: center;">
                    <div class="text-muted" style="font-size: 13px;">
                        <span x-text="selectedTotalPosts"></span> items selected
                    </div>
                    <div style="display: flex; gap: 8px;">
                        <button class="btn btn-secondary" @click="$store.app.showScanModal = false">Cancel</button>
                        <button class="btn btn-primary" @click="startScan()" :disabled="selectedPostTypes.length === 0">
                            <i class="bi bi-search"></i>
                            Start Scan
                        </button>
                    </div>
                </div>
            </template>
            <template x-if="isScanning">
                <button class="btn btn-secondary" @click="isScanning = false; scanComplete = false">Cancel</button>
            </template>
            <template x-if="scanComplete">
                <div style="display: flex; gap: 8px; width: 100%; justify-content: space-between;">
                    <button class="btn btn-secondary" @click="scanComplete = false; shortcodeAsins = []; urlAsins = []; rawAsins = []; selectedAsins = [];">
                        <i class="bi bi-arrow-repeat"></i>
                        Scan Again
                    </button>
                    <div style="display: flex; gap: 8px;">
                        <button class="btn btn-outline" @click="updateExistingAsins()" :disabled="trackedShortcodeCount === 0"
                                :title="'Link ' + trackedShortcodeCount + ' ASINs to posts' + (missingCategoryLinkCount > 0 ? ', re-link ' + missingCategoryLinkCount + ' to categories' : '') + (failedShortcodeCount > 0 && resetFailed ? ', re-queue ' + failedShortcodeCount + ' failed' : '')">
                            <i class="bi bi-link-45deg"></i>
                            Link <span x-text="trackedShortcodeCount"></span> Existing
                            <template x-if="missingCategoryLinkCount > 0">
                                <span class="badge badge-primary" style="font-size: 10px; margin-left: 4px;" x-text="'+' + missingCategoryLinkCount + ' cat'"></span>
                            </template>
                        </button>
                        <button class="btn btn-primary" @click="addNewAsins()" :disabled="selectedNewCount === 0">
                            <i class="bi bi-plus-lg"></i>
                            Add <span x-text="selectedNewCount"></span> Selected
                        </button>
                    </div>
                </div>
            </template>
        </div>
    </div>
</div>
