<?php
/**
 * Queue Delete Confirmation Modal
 *
 * Provides two delete options:
 * 1. Basic delete - Only delete queue item (keyword record)
 * 2. Full delete - Delete queue item + generated post + orphaned ASINs
 *
 * @package AffiliateCMS\Pro
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<!-- Queue Delete Confirmation Modal -->
<div class="modal-backdrop" x-show="showDeleteModal" x-cloak @click.self="showDeleteModal = false"
     x-transition:enter="transition ease-out duration-200"
     x-transition:enter-start="opacity-0"
     x-transition:enter-end="opacity-100"
     x-transition:leave="transition ease-in duration-150"
     x-transition:leave-start="opacity-100"
     x-transition:leave-end="opacity-0">
    <div class="modal" style="max-width: 480px;" @click.stop
         x-data="{
            deleteMode: 'basic',
            isDeleting: false,
            hasGeneratedPosts: false,

            init() {
                // Check if any selected items have generated posts
                this.$watch('$root.selectedItems', (items) => {
                    this.hasGeneratedPosts = items.some(i => i.generated_post_id);
                });
            },

            getItemsWithPosts() {
                const items = this.$root.selectedItems || [];
                return items.filter(i => i.generated_post_id);
            },

            getItemsWithAsins() {
                const items = this.$root.selectedItems || [];
                return items.filter(i => i.asins && i.asins.length > 0);
            },

            getTotalAsins() {
                const allAsins = new Set();
                const items = this.$root.selectedItems || [];
                items.forEach(item => {
                    if (item.asins) {
                        item.asins.forEach(asin => allAsins.add(asin));
                    }
                });
                return allAsins.size;
            }
         }">
        <div class="modal-body" style="padding: 28px;">
            <!-- Header -->
            <div class="confirm-dialog" style="text-align: center; margin-bottom: 24px;">
                <div class="confirm-icon danger" style="width: 56px; height: 56px; margin: 0 auto 16px; background: rgba(239, 68, 68, 0.1); border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                    <i class="bi bi-exclamation-triangle" style="font-size: 24px; color: #ef4444;"></i>
                </div>
                <h3 class="confirm-title" style="font-size: 17px; font-weight: 600; margin-bottom: 6px;">Delete Keywords?</h3>
                <p class="confirm-message" style="color: var(--text-secondary); font-size: 13px;">
                    You are about to delete <strong x-text="selectedCount"></strong> keyword(s)
                </p>
            </div>

            <!-- Delete Options -->
            <div class="delete-options" style="display: flex; flex-direction: column; gap: 10px; margin-bottom: 20px;">
                <!-- Basic Delete -->
                <label class="delete-option" :class="{ 'selected': deleteMode === 'basic' }">
                    <input type="radio" name="delete_mode" value="basic" x-model="deleteMode" style="display: none;">
                    <div class="delete-option-content">
                        <div class="delete-option-header">
                            <div class="delete-option-radio">
                                <span class="radio-dot"></span>
                            </div>
                            <div class="delete-option-info">
                                <span class="delete-option-title">Basic Delete</span>
                                <span class="delete-option-desc">Only remove keyword records from queue</span>
                            </div>
                        </div>
                    </div>
                </label>

                <!-- Full Delete -->
                <label class="delete-option" :class="{ 'selected': deleteMode === 'full' }">
                    <input type="radio" name="delete_mode" value="full" x-model="deleteMode" style="display: none;">
                    <div class="delete-option-content">
                        <div class="delete-option-header">
                            <div class="delete-option-radio">
                                <span class="radio-dot"></span>
                            </div>
                            <div class="delete-option-info">
                                <span class="delete-option-title">Full Delete</span>
                                <span class="delete-option-desc">Remove keywords + posts + orphaned products</span>
                            </div>
                        </div>
                        <!-- Details when selected -->
                        <div class="delete-option-details" x-show="deleteMode === 'full'" x-cloak x-collapse>
                            <div class="details-list">
                                <div class="detail-item">
                                    <i class="bi bi-file-text"></i>
                                    <span>Posts: <strong x-text="getItemsWithPosts().length"></strong></span>
                                </div>
                                <div class="detail-item">
                                    <i class="bi bi-box-seam"></i>
                                    <span>ASINs: <strong x-text="getTotalAsins()"></strong> <small>(orphans only)</small></span>
                                </div>
                            </div>
                            <p class="detail-note">
                                <i class="bi bi-info-circle"></i>
                                ASINs used by other posts will be kept
                            </p>
                        </div>
                    </div>
                </label>
            </div>

            <!-- Warning for full delete -->
            <div class="delete-warning" x-show="deleteMode === 'full'" x-cloak x-transition>
                <i class="bi bi-exclamation-triangle-fill"></i>
                <span>This will permanently delete posts and cannot be undone!</span>
            </div>

            <!-- Actions -->
            <div class="confirm-actions" style="display: flex; gap: 12px; justify-content: flex-end; margin-top: 20px;">
                <button class="btn btn-secondary" @click="showDeleteModal = false" :disabled="isDeleting">
                    Cancel
                </button>
                <button class="btn btn-danger" @click="deleteQueueItems(deleteMode)" :disabled="isDeleting"
                        :class="{ 'loading': isDeleting }">
                    <i class="bi bi-trash" x-show="!isDeleting"></i>
                    <span class="spinner-sm" x-show="isDeleting" x-cloak></span>
                    <span x-text="deleteMode === 'full' ? 'Delete All' : 'Delete'"></span>
                </button>
            </div>
        </div>
    </div>
</div>

<style>
/* Delete Options */
.delete-option {
    display: block;
    padding: 12px 14px;
    border: 1px solid var(--border-color, #374151);
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.15s ease;
    background: var(--bg-secondary, #1f2937);
}

.delete-option:hover {
    border-color: var(--text-muted, #6b7280);
}

.delete-option.selected {
    border-color: var(--color-primary, #6366f1);
    background: rgba(99, 102, 241, 0.05);
}

.delete-option-content {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.delete-option-header {
    display: flex;
    align-items: flex-start;
    gap: 12px;
}

.delete-option-radio {
    width: 18px;
    height: 18px;
    border: 2px solid var(--border-color, #374151);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    margin-top: 2px;
    transition: all 0.15s ease;
}

.delete-option.selected .delete-option-radio {
    border-color: var(--color-primary, #6366f1);
}

.radio-dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: var(--color-primary, #6366f1);
    opacity: 0;
    transform: scale(0);
    transition: all 0.15s ease;
}

.delete-option.selected .radio-dot {
    opacity: 1;
    transform: scale(1);
}

.delete-option-info {
    display: flex;
    flex-direction: column;
    gap: 2px;
}

.delete-option-title {
    font-weight: 600;
    font-size: 14px;
    color: var(--text-primary, #f3f4f6);
}

.delete-option-desc {
    font-size: 12px;
    color: var(--text-muted, #9ca3af);
}

.delete-option-details {
    margin-left: 30px;
    padding-top: 8px;
    border-top: 1px solid var(--border-color, #374151);
    margin-top: 4px;
}

.details-list {
    display: flex;
    gap: 16px;
    margin-bottom: 8px;
}

.detail-item {
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 12px;
    color: var(--text-secondary, #d1d5db);
}

.detail-item i {
    color: var(--text-muted, #9ca3af);
    font-size: 13px;
}

.detail-item small {
    color: var(--text-muted, #9ca3af);
    font-size: 11px;
}

.detail-note {
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 11px;
    color: var(--text-muted, #9ca3af);
    margin: 0;
}

.detail-note i {
    font-size: 12px;
}

/* Warning */
.delete-warning {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px 12px;
    background: rgba(239, 68, 68, 0.1);
    border: 1px solid rgba(239, 68, 68, 0.2);
    border-radius: 6px;
    color: #ef4444;
    font-size: 12px;
}

.delete-warning i {
    font-size: 14px;
}

/* Danger button */
.btn-danger {
    background: #ef4444 !important;
    color: white !important;
    border: none !important;
}

.btn-danger:hover:not(:disabled) {
    background: #dc2626 !important;
}

.btn-danger:disabled {
    opacity: 0.6;
    cursor: not-allowed;
}

.btn-danger.loading {
    pointer-events: none;
}

/* Small spinner */
.spinner-sm {
    display: inline-block;
    width: 14px;
    height: 14px;
    border: 2px solid rgba(255, 255, 255, 0.3);
    border-top-color: white;
    border-radius: 50%;
    animation: spin 0.8s linear infinite;
}

@keyframes spin {
    to { transform: rotate(360deg); }
}

/* Collapse animation */
[x-collapse] {
    overflow: hidden;
}

[x-collapse].x-collapse-enter-active,
[x-collapse].x-collapse-leave-active {
    transition: height 0.2s ease-out;
}
</style>
