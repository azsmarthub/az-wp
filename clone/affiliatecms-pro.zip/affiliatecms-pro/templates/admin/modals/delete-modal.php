<?php
/**
 * Delete Confirmation Modal
 *
 * @package AffiliateCMS\Pro
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<!-- Delete Confirmation Modal -->
<div class="modal-backdrop" x-show="showDeleteModal" x-cloak @click.self="showDeleteModal = false"
     x-transition:enter="transition ease-out duration-200"
     x-transition:enter-start="opacity-0"
     x-transition:enter-end="opacity-100"
     x-transition:leave="transition ease-in duration-150"
     x-transition:leave-start="opacity-100"
     x-transition:leave-end="opacity-0">
    <div class="modal" style="max-width: 400px;" @click.stop>
        <div class="modal-body" style="padding: 32px;">
            <div class="confirm-dialog" style="text-align: center;">
                <div class="confirm-icon danger" style="width: 64px; height: 64px; margin: 0 auto 20px; background: rgba(239, 68, 68, 0.1); border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                    <i class="bi bi-exclamation-triangle" style="font-size: 28px; color: #ef4444;"></i>
                </div>
                <h3 class="confirm-title" style="font-size: 18px; font-weight: 600; margin-bottom: 8px;">Delete Products?</h3>
                <p class="confirm-message" style="color: var(--text-secondary); margin-bottom: 24px;">
                    This action cannot be undone. Are you sure you want to delete
                    <strong x-text="selectedCount"></strong> selected product(s)?
                </p>
                <div class="confirm-actions" style="display: flex; gap: 12px; justify-content: center;">
                    <button class="btn btn-secondary" @click="showDeleteModal = false">Cancel</button>
                    <button class="btn" style="background: #ef4444; color: white; border: none;" @click="deleteProducts()">
                        <i class="bi bi-trash"></i>
                        Delete
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
