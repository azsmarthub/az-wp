<?php
/**
 * Add ASIN Modal - with tabs Search Amazon và Manual Input
 *
 * @package AffiliateCMS\Pro
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<!-- Add ASINs Modal -->
<div class="modal-backdrop" x-show="showAddModal" x-cloak
     @click.self="showAddModal = false"
     @close-add-modal.window="showAddModal = false"
     @asins-added.window="refreshProducts()"
     x-transition:enter="transition ease-out duration-200"
     x-transition:enter-start="opacity-0"
     x-transition:enter-end="opacity-100"
     x-transition:leave="transition ease-in duration-150"
     x-transition:leave-start="opacity-100"
     x-transition:leave-end="opacity-0">
    <div class="modal modal-lg" @click.stop x-data="{
        addTab: 'search',
        newAsinsText: '',
        isAdding: false,
        error: '',
        searchQuery: '',
        isSearching: false,
        searchResults: [],
        selectedResults: [],
        showingHistory: false,
        searchHistory: [],

        init() {
            // Load search history from localStorage
            try {
                const saved = localStorage.getItem('acms_search_history');
                if (saved) {
                    this.searchHistory = JSON.parse(saved);
                }
            } catch (e) {
            }
        },

        saveToHistory() {
            if (this.searchResults.length === 0) return;

            const historyItem = {
                query: this.searchQuery,
                results: this.searchResults,
                timestamp: Date.now()
            };

            // Add to beginning, keep max 10 items
            this.searchHistory.unshift(historyItem);
            if (this.searchHistory.length > 10) {
                this.searchHistory = this.searchHistory.slice(0, 10);
            }

            // Save to localStorage
            try {
                localStorage.setItem('acms_search_history', JSON.stringify(this.searchHistory));
            } catch (e) {
            }
        },

        loadFromHistory(historyItem) {
            this.searchQuery = historyItem.query;
            this.searchResults = historyItem.results;
            this.selectedResults = [];
            this.showingHistory = false;
        },

        clearHistory() {
            this.searchHistory = [];
            localStorage.removeItem('acms_search_history');
        },

        formatHistoryTime(timestamp) {
            const date = new Date(timestamp);
            const now = new Date();
            const diff = now - date;

            if (diff < 60000) return 'Just now';
            if (diff < 3600000) return Math.floor(diff / 60000) + 'm ago';
            if (diff < 86400000) return Math.floor(diff / 3600000) + 'h ago';
            return date.toLocaleDateString();
        },

        async performSearch() {
            if (!this.searchQuery.trim() || this.isSearching) return;

            this.isSearching = true;
            this.searchResults = [];
            this.showingHistory = false;
            this.error = '';

            try {
                const response = await fetch(acmsConfig.restUrl + 'amazon/search', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': acmsConfig.nonce
                    },
                    body: JSON.stringify({
                        query: this.searchQuery
                    })
                });

                const result = await response.json();

                if (result.success && result.data) {
                    this.searchResults = result.data;
                    this.saveToHistory();
                } else {
                    this.error = result.message || 'Search failed';
                }
            } catch (error) {
                this.error = error.message;
            } finally {
                this.isSearching = false;
            }
        },

        toggleResultSelect(asin) {
            const idx = this.selectedResults.indexOf(asin);
            if (idx > -1) {
                this.selectedResults.splice(idx, 1);
            } else {
                this.selectedResults.push(asin);
            }
        },

        isResultSelected(asin) {
            return this.selectedResults.includes(asin);
        },

        formatPrice(price) {
            if (!price) return '-';
            return '$' + parseFloat(price).toFixed(2);
        },

        formatReviewCount(count) {
            if (!count) return '0';
            if (count >= 1000) return (count / 1000).toFixed(1) + 'k';
            return count;
        },

        async addSelectedProducts() {
            if (this.selectedResults.length === 0 || this.isAdding) return;

            this.isAdding = true;
            this.error = '';

            try {
                const response = await fetch(acmsConfig.restUrl + 'products/import', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': acmsConfig.nonce
                    },
                    body: JSON.stringify({
                        asin: this.selectedResults
                    })
                });

                const result = await response.json();

                if (result.success) {
                    this.selectedResults = [];
                    this.searchResults = [];
                    this.searchQuery = '';
                    $dispatch('asins-added', result.data);
                    $dispatch('show-toast', {
                        type: 'success',
                        title: 'Success',
                        message: result.message || `Added ${this.selectedResults.length} products`
                    });

                    // Trigger scraping for pending products
                    this.triggerScraping();

                    $dispatch('close-add-modal');
                } else {
                    this.error = result.message || 'Failed to add products';
                }
            } catch (error) {
                this.error = error.message;
            } finally {
                this.isAdding = false;
            }
        },

        get parsedAsins() {
            if (!this.newAsinsText.trim()) return [];
            return this.newAsinsText
                .split(/[\n,\s]+/)
                .map(a => a.trim().toUpperCase())
                .filter(a => a.length > 0 && /^[A-Z0-9]{10}$/.test(a));
        },

        get uniqueAsins() {
            return [...new Set(this.parsedAsins)];
        },

        async submitAsins() {
            if (this.uniqueAsins.length === 0 || this.isAdding) return;

            this.isAdding = true;
            this.error = '';

            try {
                const response = await fetch(acmsConfig.restUrl + 'products/import', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': acmsConfig.nonce
                    },
                    body: JSON.stringify({
                        asin: this.uniqueAsins
                    })
                });

                const result = await response.json();

                if (result.success) {
                    this.newAsinsText = '';
                    $dispatch('asins-added', result.data);
                    $dispatch('show-toast', {
                        type: 'success',
                        title: 'Success',
                        message: result.message || `Added ${this.uniqueAsins.length} ASINs`
                    });

                    // Trigger scraping for pending products
                    this.triggerScraping();

                    $dispatch('close-add-modal');
                } else {
                    this.error = result.message || 'Failed to add ASINs';
                }
            } catch (error) {
                this.error = error.message;
            } finally {
                this.isAdding = false;
            }
        },

        async triggerScraping() {
            try {
                // Trigger automation scrape endpoint to scrape all pending products
                await fetch(acmsConfig.restUrl + 'automation/scrape', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': acmsConfig.nonce
                    }
                });
                // Don't wait for response or show error - let it run in background
            } catch (error) {
            }
        }
    }">
        <div class="modal-header">
            <h2 class="modal-title">
                <i class="bi bi-plus-circle"></i>
                Add ASINs
            </h2>
            <button class="btn-icon btn-icon-sm" @click="showAddModal = false">
                <i class="bi bi-x-lg"></i>
            </button>
        </div>
        <div class="modal-body">
            <!-- Error Message -->
            <div class="alert alert-error" x-show="error" x-cloak>
                <i class="bi bi-exclamation-circle"></i>
                <span x-text="error"></span>
                <button class="alert-close" @click="error = ''"><i class="bi bi-x"></i></button>
            </div>

            <!-- Tabs -->
            <div class="tabs">
                <button class="tab" :class="{ 'active': addTab === 'search' }" @click="addTab = 'search'">
                    <i class="bi bi-search"></i>
                    Search Amazon
                </button>
                <button class="tab" :class="{ 'active': addTab === 'manual' }" @click="addTab = 'manual'">
                    <i class="bi bi-pencil"></i>
                    Manual Input
                </button>
            </div>

            <!-- Search Amazon Tab -->
            <div x-show="addTab === 'search'" style="min-height: 380px;">
                <!-- Search Input -->
                <div class="form-group" style="margin-bottom: 12px;">
                    <div class="search-input-inline">
                        <input type="text" class="input" placeholder="Search products on Amazon..."
                               x-model="searchQuery"
                               @keydown.enter="performSearch()">
                        <button type="button" class="search-inline-btn"
                                @click="performSearch()"
                                :disabled="isSearching || !searchQuery.trim()">
                            <i class="bi" :class="isSearching ? 'bi-arrow-clockwise animate-spin' : 'bi-search'"></i>
                        </button>
                    </div>
                </div>

                <div class="search-results-container" style="height: 320px; overflow-y: auto; position: relative;">
                    <!-- Empty State -->
                    <div x-show="!isSearching && searchResults.length === 0 && !showingHistory" class="empty-state">
                        <i class="bi bi-search"></i>
                        <p>Enter a keyword to search products on Amazon</p>
                    </div>

                    <!-- Loading State -->
                    <div x-show="isSearching" class="empty-state">
                        <i class="bi bi-arrow-clockwise animate-spin"></i>
                        <p>Searching Amazon...</p>
                    </div>

                    <!-- Search Results -->
                    <div x-show="!isSearching && searchResults.length > 0 && !showingHistory" class="search-results-list">
                        <template x-for="product in searchResults" :key="product.asin">
                            <div class="search-result-item"
                                 :class="{ 'selected': isResultSelected(product.asin) }"
                                 @click="toggleResultSelect(product.asin)">
                                <div class="result-checkbox" :class="{ 'checked': isResultSelected(product.asin) }">
                                    <i class="bi bi-check2" x-show="isResultSelected(product.asin)"></i>
                                </div>
                                <div class="result-image">
                                    <img :src="product.image || product.image_url" :alt="product.title" onerror="this.src='data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 56 56%22><rect fill=%22%2318181b%22 width=%2256%22 height=%2256%22/><text x=%2228%22 y=%2232%22 fill=%22%2371717a%22 font-size=%2210%22 text-anchor=%22middle%22>No img</text></svg>'">
                                </div>
                                <div class="result-info">
                                    <div class="result-title" x-text="product.title"></div>
                                    <div class="result-meta">
                                        <code class="result-asin" x-text="product.asin"></code>
                                        <span class="result-rating" x-show="product.rating">
                                            <i class="bi bi-star-fill"></i>
                                            <span x-text="product.rating"></span>
                                            (<span x-text="formatReviewCount(product.reviews || product.review_count)"></span>)
                                        </span>
                                        <span x-show="product.isPrime || product.is_prime" class="prime-badge">Prime</span>
                                    </div>
                                </div>
                                <div class="result-price" x-text="formatPrice(product.price)"></div>
                            </div>
                        </template>
                    </div>

                    <!-- History Panel -->
                    <div x-show="showingHistory" class="search-history-panel" x-cloak>
                        <div class="search-history-header">
                            <span class="search-history-title">
                                <i class="bi bi-clock-history"></i>
                                Search History
                            </span>
                            <button class="btn btn-ghost btn-sm" @click="clearHistory()" x-show="searchHistory.length > 0">
                                <i class="bi bi-trash"></i>
                                Clear All
                            </button>
                        </div>
                        <div class="search-history-list" x-show="searchHistory.length > 0">
                            <template x-for="(item, index) in searchHistory" :key="index">
                                <div class="search-history-item" @click="loadFromHistory(item)">
                                    <div class="history-item-info">
                                        <span class="history-query" x-text="item.query"></span>
                                        <span class="history-meta">
                                            <span x-text="item.results.length + ' results'"></span>
                                            <span class="history-time" x-text="formatHistoryTime(item.timestamp)"></span>
                                        </span>
                                    </div>
                                    <i class="bi bi-arrow-right-circle"></i>
                                </div>
                            </template>
                        </div>
                        <div x-show="searchHistory.length === 0" class="empty-state">
                            <i class="bi bi-clock-history"></i>
                            <p>No search history yet</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Manual Input Tab -->
            <div x-show="addTab === 'manual'" x-cloak style="min-height: 380px;">
                <p class="text-secondary" style="margin-bottom: 16px;">Enter Amazon ASINs separated by commas, spaces, or new lines.</p>
                <div class="form-group">
                    <label class="form-label">ASINs</label>
                    <textarea class="input" style="height: 280px; font-family: 'SF Mono', Monaco, monospace; resize: vertical;"
                              x-model="newAsinsText"
                              placeholder="B08N5WRWNW&#10;B09V3KXJPB&#10;B08N5M7S6K"
                              :disabled="isAdding"></textarea>
                    <p class="form-hint">Tip: You can paste multiple ASINs from a spreadsheet</p>
                </div>
            </div>
        </div>
        <div class="modal-footer" style="justify-content: space-between;">
            <div style="display: flex; align-items: center; gap: 12px;">
                <!-- History button (search tab only) -->
                <template x-if="addTab === 'search'">
                    <button class="btn btn-ghost" @click="showingHistory = !showingHistory" :class="{ 'active': showingHistory }">
                        <i class="bi bi-clock-history"></i>
                        History
                        <span x-show="searchHistory.length > 0" class="history-badge" x-text="searchHistory.length"></span>
                    </button>
                </template>
                <!-- Selected count -->
                <template x-if="addTab === 'search' && selectedResults.length > 0 && !showingHistory">
                    <span class="text-primary" style="font-size: 13px;">
                        <strong x-text="selectedResults.length"></strong> selected
                        <button class="btn btn-ghost btn-sm" @click="selectedResults = []" style="margin-left: 4px;">Clear</button>
                    </span>
                </template>
            </div>
            <div class="flex gap-2">
                <button class="btn btn-secondary" @click="showAddModal = false" :disabled="isAdding">Cancel</button>
                <template x-if="addTab === 'manual'">
                    <button class="btn btn-primary" @click="submitAsins()" :disabled="isAdding || uniqueAsins.length === 0">
                        <i class="bi" :class="isAdding ? 'bi-arrow-clockwise animate-spin' : 'bi-plus-lg'"></i>
                        <span x-text="isAdding ? 'Adding...' : ('Add ' + uniqueAsins.length + ' ASIN' + (uniqueAsins.length !== 1 ? 's' : ''))"></span>
                    </button>
                </template>
                <template x-if="addTab === 'search'">
                    <button class="btn btn-primary" @click="addSelectedProducts()" :disabled="selectedResults.length === 0 || showingHistory || isAdding">
                        <i class="bi" :class="isAdding ? 'bi-arrow-clockwise animate-spin' : 'bi-plus-lg'"></i>
                        <span x-text="isAdding ? 'Adding...' : (selectedResults.length > 0 ? 'Add ' + selectedResults.length + ' Product' + (selectedResults.length !== 1 ? 's' : '') : 'Add Products')"></span>
                    </button>
                </template>
            </div>
        </div>
    </div>
</div>
