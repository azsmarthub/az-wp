<?php
/**
 * Posts Using ASIN Modal
 *
 * Shows which posts/pages, cat queue items, and SEO categories are using a specific ASIN
 *
 * @package AffiliateCMS\Pro\Templates\Admin\Modals
 */

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}
?>
<!-- Posts Using ASIN Modal -->
<div class="modal-backdrop" x-show="$store.app.showPostsModal" x-cloak
     @click.self="$store.app.showPostsModal = false; $store.app.selectedProductForPosts = null; $dispatch('close-posts-modal')"
     x-transition:enter="transition ease-out duration-200"
     x-transition:enter-start="opacity-0"
     x-transition:enter-end="opacity-100"
     x-transition:leave="transition ease-in duration-150"
     x-transition:leave-start="opacity-100"
     x-transition:leave-end="opacity-0">
    <div class="modal posts-modal" @click.stop x-data="postsModal()" x-effect="if ($store.app.showPostsModal && $store.app.selectedProductForPosts) loadPosts()">
        <div class="modal-header">
            <h2 class="modal-title">
                <i class="bi bi-file-text"></i>
                Posts Using
                <code class="asin-code" x-text="$store.app.selectedProductForPosts?.asin"></code>
            </h2>
            <button class="btn-icon btn-icon-sm" @click="close()">
                <i class="bi bi-x-lg"></i>
            </button>
        </div>
        <div class="modal-body posts-modal-body">
            <!-- Loading state -->
            <div class="posts-loading" x-show="loading" x-cloak>
                <div class="spinner"></div>
                <span>Loading...</span>
            </div>

            <!-- Error state -->
            <div class="posts-empty" x-show="error && !loading" x-cloak>
                <i class="bi bi-exclamation-triangle"></i>
                <span x-text="error || 'Failed to load'"></span>
            </div>

            <div x-show="!loading && !error" x-cloak>
                <!-- Empty state (no data at all) -->
                <div class="posts-empty" x-show="posts.length === 0 && catQueue.length === 0 && linkedCategories.length === 0">
                    <i class="bi bi-file-earmark-x"></i>
                    <span>No posts, queue items, or categories found for this ASIN</span>
                </div>

                <!-- Section: Linked SEO Categories -->
                <div class="posts-section" x-show="linkedCategories.length > 0">
                    <div class="section-header">
                        <i class="bi bi-folder"></i>
                        SEO Categories
                        <span class="section-count" x-text="linkedCategories.length"></span>
                    </div>
                    <table class="posts-table">
                        <thead>
                            <tr>
                                <th class="col-id">#</th>
                                <th class="col-title">Category</th>
                                <th class="col-type">Content</th>
                                <th class="col-status">Products</th>
                                <th class="col-actions">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <template x-for="cat in linkedCategories" :key="'cat-' + cat.id">
                                <tr>
                                    <td class="col-id">
                                        <span class="post-id" x-text="cat.id"></span>
                                    </td>
                                    <td class="col-title">
                                        <div class="cat-title-cell">
                                            <span class="post-title" x-text="cat.name" :title="cat.name"></span>
                                            <span class="badge badge-sm badge-primary" x-show="cat.is_primary" style="font-size: 9px; padding: 1px 5px;">Primary</span>
                                        </div>
                                    </td>
                                    <td class="col-type">
                                        <span class="badge badge-sm" :class="getCatContentClass(cat.content_status)" x-text="cat.content_status || 'empty'"></span>
                                    </td>
                                    <td class="col-status">
                                        <span class="cat-product-count" x-text="cat.product_count + 'p'"></span>
                                    </td>
                                    <td class="col-actions">
                                        <div class="post-actions">
                                            <a :href="cat.edit_url" target="_blank" class="btn-icon btn-icon-sm" title="Edit Category">
                                                <i class="bi bi-pencil"></i>
                                            </a>
                                            <a :href="cat.url" target="_blank" class="btn-icon btn-icon-sm" title="View Category">
                                                <i class="bi bi-box-arrow-up-right"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            </template>
                        </tbody>
                    </table>
                </div>

                <!-- Section: Cat Queue Items -->
                <div class="posts-section" x-show="catQueue.length > 0">
                    <div class="section-header">
                        <i class="bi bi-list-task"></i>
                        Cat Queue
                        <span class="section-count" x-text="catQueue.length"></span>
                    </div>
                    <table class="posts-table">
                        <thead>
                            <tr>
                                <th class="col-id">#</th>
                                <th class="col-title">Keyword</th>
                                <th class="col-type">Status</th>
                                <th class="col-status">Category</th>
                                <th class="col-actions">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <template x-for="item in catQueue" :key="'cq-' + item.id">
                                <tr>
                                    <td class="col-id">
                                        <span class="post-id" x-text="item.id"></span>
                                    </td>
                                    <td class="col-title">
                                        <span class="post-title" x-text="item.keyword" :title="item.category_path || item.keyword"></span>
                                    </td>
                                    <td class="col-type">
                                        <span class="badge badge-sm" :class="getQueueStatusClass(item.status)" x-text="item.status"></span>
                                    </td>
                                    <td class="col-status">
                                        <span x-show="item.category_name" class="cat-name-text" x-text="item.category_name"></span>
                                        <span x-show="!item.category_name" class="text-muted">-</span>
                                    </td>
                                    <td class="col-actions">
                                        <div class="post-actions">
                                            <a :href="item.edit_url" target="_blank" class="btn-icon btn-icon-sm" title="View Queue">
                                                <i class="bi bi-box-arrow-up-right"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            </template>
                        </tbody>
                    </table>
                </div>

                <!-- Section: WordPress Posts -->
                <div class="posts-section" x-show="posts.length > 0">
                    <div class="section-header">
                        <i class="bi bi-file-text"></i>
                        WordPress Posts
                        <span class="section-count" x-text="posts.length"></span>
                    </div>
                    <table class="posts-table">
                        <thead>
                            <tr>
                                <th class="col-id">#</th>
                                <th class="col-title">Title</th>
                                <th class="col-type">Type</th>
                                <th class="col-status">Status</th>
                                <th class="col-actions">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <template x-for="post in posts" :key="'post-' + post.id">
                                <tr>
                                    <td class="col-id">
                                        <span class="post-id" x-text="post.id"></span>
                                    </td>
                                    <td class="col-title">
                                        <span class="post-title" x-text="post.title" :title="post.title"></span>
                                    </td>
                                    <td class="col-type">
                                        <span class="badge badge-sm" :class="getTypeClass(post.post_type)" x-text="formatType(post.post_type)"></span>
                                    </td>
                                    <td class="col-status">
                                        <span class="badge badge-sm" :class="getStatusClass(post.post_status)" x-text="post.post_status"></span>
                                    </td>
                                    <td class="col-actions">
                                        <div class="post-actions">
                                            <a :href="post.edit_url" target="_blank" class="btn-icon btn-icon-sm" title="Edit Post">
                                                <i class="bi bi-pencil"></i>
                                            </a>
                                            <a :href="post.url" target="_blank" class="btn-icon btn-icon-sm" title="View Post">
                                                <i class="bi bi-box-arrow-up-right"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            </template>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <span class="posts-count" x-show="!loading">
                <template x-if="linkedCategories.length > 0">
                    <span><span x-text="linkedCategories.length"></span> cat</span>
                </template>
                <template x-if="catQueue.length > 0">
                    <span><span x-text="catQueue.length"></span> queue</span>
                </template>
                <template x-if="posts.length > 0">
                    <span><span x-text="posts.length"></span> post(s)</span>
                </template>
            </span>
            <button class="btn btn-secondary" @click="close()">Close</button>
        </div>
    </div>
</div>

<script>
document.addEventListener('alpine:init', () => {
    Alpine.data('postsModal', () => ({
        loading: false,
        error: null,
        posts: [],
        catQueue: [],
        linkedCategories: [],
        _lastAsin: null,

        async loadPosts() {
            const product = this.$store.app.selectedProductForPosts;
            if (!product || !product.asin) {
                return;
            }

            // Prevent duplicate loads for same ASIN
            if (this._lastAsin === product.asin && (this.posts.length > 0 || this.catQueue.length > 0 || this.linkedCategories.length > 0)) {
                return;
            }

            this._lastAsin = product.asin;
            this.loading = true;
            this.error = null;
            this.posts = [];
            this.catQueue = [];
            this.linkedCategories = [];

            try {
                const url = `${acmsConfig.restUrl}products/${product.asin}/posts`;
                const response = await fetch(url, {
                    headers: {
                        'X-WP-Nonce': acmsConfig.nonce
                    }
                });

                if (!response.ok) {
                    throw new Error('Failed to fetch data');
                }

                const result = await response.json();
                this.posts = result.data || [];
                this.linkedCategories = result.linked_categories || [];

                // Filter out cat queue items whose assigned category is already
                // shown in SEO Categories (avoids duplicate "Accent Pillows" rows)
                const linkedCatIds = new Set(this.linkedCategories.map(c => c.id));
                this.catQueue = (result.cat_queue || []).filter(
                    item => !item.category_id || !linkedCatIds.has(item.category_id)
                );
            } catch (error) {
                this.error = error.message || 'Failed to load data';
            } finally {
                this.loading = false;
            }
        },

        formatType(type) {
            const types = {
                'post': 'Post',
                'page': 'Page',
                'acms_reviews': 'Review',
                'acms_comparisons': 'Comparison',
                'acms_guides': 'Guide'
            };
            return types[type] || type;
        },

        getTypeClass(type) {
            const classes = {
                'post': 'badge-info',
                'page': 'badge-warning',
                'acms_reviews': 'badge-success',
                'acms_comparisons': 'badge-primary',
                'acms_guides': 'badge-secondary'
            };
            return classes[type] || 'badge-secondary';
        },

        getStatusClass(status) {
            const classes = {
                'publish': 'badge-success',
                'draft': 'badge-warning',
                'pending': 'badge-info',
                'private': 'badge-secondary',
                'trash': 'badge-error'
            };
            return classes[status] || 'badge-secondary';
        },

        getQueueStatusClass(status) {
            const classes = {
                'pending': 'badge-warning',
                'processing': 'badge-info',
                'searched': 'badge-info',
                'ready_for_ai': 'badge-primary',
                'completed': 'badge-success',
                'failed': 'badge-error'
            };
            return classes[status] || 'badge-secondary';
        },

        getCatContentClass(status) {
            const classes = {
                'empty': 'badge-warning',
                'ai_generating': 'badge-info',
                'ai_generated': 'badge-success',
                'manual': 'badge-primary',
                'failed': 'badge-error'
            };
            return classes[status] || 'badge-secondary';
        },

        close() {
            this.$store.app.showPostsModal = false;
            this.$store.app.selectedProductForPosts = null;
            this._lastAsin = null;
            this.posts = [];
            this.catQueue = [];
            this.linkedCategories = [];
            this.error = null;
            window.dispatchEvent(new CustomEvent('close-posts-modal'));
        }
    }));
});
</script>

<style>
/* Posts Modal */
.posts-modal {
    width: 720px;
    max-width: 95vw;
}

.posts-modal-body {
    padding: 0 !important;
    max-height: 500px;
    overflow-y: auto;
}

.asin-code {
    display: inline-block;
    background: var(--bg-elevated);
    padding: 2px 10px;
    border-radius: var(--radius-sm);
    margin-left: 8px;
    font-family: ui-monospace, SFMono-Regular, 'SF Mono', Menlo, Consolas, monospace;
    font-size: 13px;
    font-weight: 600;
    color: var(--primary);
}

/* Loading & Empty States */
.posts-loading,
.posts-empty {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 12px;
    padding: 48px 24px;
    text-align: center;
    color: var(--text-muted);
}

.posts-loading .spinner,
.posts-empty i {
    font-size: 32px;
    opacity: 0.5;
}

.posts-loading .spinner {
    width: 32px;
    height: 32px;
    border: 3px solid var(--border);
    border-top-color: var(--primary);
    border-radius: 50%;
    animation: spin 0.8s linear infinite;
}

@keyframes spin {
    to { transform: rotate(360deg); }
}

/* Section Headers */
.posts-section {
    border-bottom: 1px solid var(--border);
}
.posts-section:last-child {
    border-bottom: none;
}

.section-header {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px 16px;
    font-size: 12px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    color: var(--text-secondary);
    background: var(--bg-elevated);
    border-bottom: 1px solid var(--border);
}
.section-header i { font-size: 14px; color: var(--primary); }

.section-count {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 20px;
    height: 18px;
    padding: 0 6px;
    font-size: 10px;
    font-weight: 700;
    background: var(--primary);
    color: white;
    border-radius: 9px;
}

/* Posts Table */
.posts-table-container {
    overflow-x: auto;
}

.posts-table {
    width: 100%;
    border-collapse: collapse;
}

.posts-table th,
.posts-table td {
    padding: 8px 16px;
    text-align: left;
    border-bottom: 1px solid var(--border);
}

.posts-table th {
    font-size: 10px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    color: var(--text-muted);
    background: var(--bg);
    position: sticky;
    top: 0;
    z-index: 1;
}

.posts-table tbody tr:hover {
    background: var(--bg-hover);
}

.posts-table tbody tr:last-child td {
    border-bottom: none;
}

/* Column widths */
.posts-table .col-id {
    width: 50px;
    text-align: center;
}

.posts-table .col-title {
    min-width: 180px;
}

.posts-table .col-type,
.posts-table .col-status {
    width: 100px;
}

.posts-table .col-actions {
    width: 80px;
    text-align: right;
}

/* Cell content */
.post-id {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 32px;
    height: 22px;
    padding: 0 6px;
    font-size: 10px;
    font-weight: 600;
    font-family: ui-monospace, SFMono-Regular, 'SF Mono', Menlo, Consolas, monospace;
    background: var(--bg-elevated);
    border: 1px solid var(--border);
    border-radius: 4px;
    color: var(--text-secondary);
}

.post-title {
    display: block;
    font-weight: 500;
    font-size: 13px;
    color: var(--text-primary);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    max-width: 300px;
}

.cat-title-cell {
    display: flex;
    align-items: center;
    gap: 6px;
}

.cat-name-text {
    font-size: 12px;
    color: var(--text-secondary);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    max-width: 140px;
}

.cat-product-count {
    font-size: 11px;
    font-weight: 600;
    color: var(--text-muted);
    font-family: ui-monospace, SFMono-Regular, 'SF Mono', Menlo, Consolas, monospace;
}

.post-actions {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    gap: 4px;
}

/* Footer */
.posts-modal .modal-footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.posts-count {
    display: flex;
    gap: 10px;
    font-size: 12px;
    color: var(--text-muted);
}

.text-muted { color: var(--text-muted); font-size: 12px; }
</style>
