<?php
/**
 * Add Keywords Modal
 *
 * @package AffiliateCMS\Pro
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<!-- Add Keywords Modal -->
<div class="modal-backdrop" x-show="showAddModal" x-cloak
     x-transition:enter="transition ease-out duration-200"
     x-transition:enter-start="opacity-0"
     x-transition:enter-end="opacity-100"
     x-transition:leave="transition ease-in duration-150"
     x-transition:leave-start="opacity-100"
     x-transition:leave-end="opacity-0"
     @keydown.escape.window="showAddModal = false"
     @close-add-modal.window="showAddModal = false">

    <div class="modal modal-md add-keywords-modal" x-data="addKeywordsModal()" @show-add-result.window="showResultDialog($event.detail)"
         x-transition:enter="transition ease-out duration-200"
         x-transition:enter-start="opacity-0 transform scale-95"
         x-transition:enter-end="opacity-100 transform scale-100"
         x-transition:leave="transition ease-in duration-150"
         x-transition:leave-start="opacity-100 transform scale-100"
         x-transition:leave-end="opacity-0 transform scale-95">

        <!-- Modal Header -->
        <div class="modal-header" x-show="!showResult">
            <h3 class="modal-title">
                <i class="bi bi-plus-lg"></i>
                Add Keywords
            </h3>
            <button type="button" class="modal-close" @click="$dispatch('close-add-modal')">
                <i class="bi bi-x-lg"></i>
            </button>
        </div>

        <!-- Modal Body -->
        <div class="modal-body" x-show="!showResult">
            <!-- Keywords Input -->
            <div class="form-group">
                <label class="form-label">
                    Keywords
                    <span class="form-hint">One keyword per line</span>
                </label>
                <textarea class="form-textarea" rows="6" placeholder="Enter keywords here, one per line..."
                          x-model="keywords" @input="parseKeywords()"></textarea>
                <div class="form-help">
                    <span x-show="keywordCount > 0" x-text="keywordCount + ' keyword(s) detected'"></span>
                </div>
            </div>

            <!-- Post Type & Category Row -->
            <div class="form-row" :class="{ 'form-row-responsive': postType && postType !== 'page' }">
                <!-- Post Type -->
                <div class="form-group">
                    <label class="form-label">Post Type</label>
                    <div class="custom-select" x-data="{ open: false }" @click.outside="open = false">
                        <button type="button" class="custom-select-trigger" :class="{ 'open': open, 'placeholder': !postType }" @click="open = !open">
                            <span class="custom-select-value" x-text="postType ? getPostTypeLabel(postType) : 'Select Post Type'"></span>
                            <i class="bi bi-chevron-down"></i>
                        </button>
                        <div class="custom-select-dropdown" x-show="open" x-cloak x-transition @click.stop>
                            <template x-for="pt in enabledPostTypes" :key="pt.value">
                                <button type="button" class="custom-select-option" :class="{ 'selected': postType === pt.value }" @click="selectPostType(pt.value); open = false" x-text="pt.label"></button>
                            </template>
                            <div class="custom-select-empty" x-show="enabledPostTypes.length === 0">
                                No post types enabled
                            </div>
                        </div>
                    </div>
                    <div class="form-help text-subtle" x-show="postType && !isPostTypeEnabled(postType)">
                        This post type is disabled in Settings
                    </div>
                </div>

                <!-- Category (shows after Post Type selection, except for pages) -->
                <div class="form-group" x-show="postType && postType !== 'page'" x-transition>
                    <label class="form-label">Category <span class="form-hint">(optional)</span></label>
                    <div class="custom-select searchable-select" x-data="{ open: false, search: '' }" @click.outside="open = false; search = ''">
                        <button type="button" class="custom-select-trigger" :class="{ 'open': open, 'loading': isLoadingCategories }" @click="open = !open" :disabled="isLoadingCategories">
                            <span class="custom-select-value">
                                <template x-if="isLoadingCategories">
                                    <span class="loading-text"><i class="bi bi-arrow-clockwise animate-spin"></i> Loading...</span>
                                </template>
                                <template x-if="!isLoadingCategories">
                                    <span x-text="getCategoryLabel(categoryId)"></span>
                                </template>
                            </span>
                            <i class="bi bi-chevron-down"></i>
                        </button>
                        <div class="custom-select-dropdown" x-show="open && !isLoadingCategories" x-cloak x-transition @click.stop>
                            <div class="select-search-box">
                                <i class="bi bi-search"></i>
                                <input type="text" class="select-search-input" placeholder="Search categories..." x-model="search" @click.stop x-ref="categorySearch" x-init="$watch('open', value => { if(value) $nextTick(() => $refs.categorySearch?.focus()) })">
                                <button type="button" class="select-search-clear" x-show="search" @click="search = ''">
                                    <i class="bi bi-x"></i>
                                </button>
                            </div>
                            <div class="custom-select-options">
                                <button type="button" class="custom-select-option" :class="{ 'selected': categoryId === null }" @click="categoryId = null; open = false; search = ''" x-show="!search">No Category</button>
                                <template x-if="categories.length === 0 && !search">
                                    <div class="custom-select-empty">No categories found</div>
                                </template>
                                <template x-for="cat in categories.filter(c => !search || c.name.toLowerCase().includes(search.toLowerCase()))" :key="cat.id">
                                    <button type="button" class="custom-select-option" :class="{ 'selected': categoryId === cat.id }" @click="categoryId = cat.id; open = false; search = ''">
                                        <span x-text="cat.name" :style="cat.parent ? 'padding-left: 12px' : ''"></span>
                                    </button>
                                </template>
                                <template x-if="search && categories.filter(c => c.name.toLowerCase().includes(search.toLowerCase())).length === 0">
                                    <div class="custom-select-empty">No matching categories</div>
                                </template>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Author & Content Template Row -->
            <div class="form-row form-row-fixed">
                <!-- Author Selection -->
                <div class="form-group">
                    <label class="form-label">Author</label>
                    <div class="custom-select" x-data="{ open: false }" @click.outside="open = false">
                        <button type="button" class="custom-select-trigger" :class="{ 'open': open, 'loading': isLoadingAuthors }" @click="open = !open" :disabled="isLoadingAuthors">
                            <span class="custom-select-value">
                                <template x-if="isLoadingAuthors">
                                    <span class="loading-text"><i class="bi bi-arrow-clockwise animate-spin"></i> Loading...</span>
                                </template>
                                <template x-if="!isLoadingAuthors">
                                    <span x-text="getAuthorLabel()"></span>
                                </template>
                            </span>
                            <i class="bi bi-chevron-down"></i>
                        </button>
                        <div class="custom-select-dropdown" x-show="open && !isLoadingAuthors" x-cloak x-transition @click.stop>
                            <button type="button" class="custom-select-option" :class="{ 'selected': authorId === 'random' }" @click="authorId = 'random'; open = false">
                                <i class="bi bi-shuffle"></i> Random Author
                            </button>
                            <div class="custom-select-divider"></div>
                            <template x-for="author in authors" :key="author.id">
                                <button type="button" class="custom-select-option" :class="{ 'selected': authorId === author.id }" @click="authorId = author.id; open = false">
                                    <span x-text="author.name"></span>
                                </button>
                            </template>
                        </div>
                    </div>
                </div>

                <!-- Content Template Selection -->
                <div class="form-group">
                    <label class="form-label">Content Template <span class="form-hint">(optional)</span></label>
                    <div class="custom-select" x-data="{ open: false }" @click.outside="open = false">
                        <button type="button" class="custom-select-trigger" :class="{ 'open': open, 'loading': isLoadingTemplates }" @click="open = !open" :disabled="isLoadingTemplates">
                            <span class="custom-select-value">
                                <template x-if="isLoadingTemplates">
                                    <span class="loading-text"><i class="bi bi-arrow-clockwise animate-spin"></i> Loading...</span>
                                </template>
                                <template x-if="!isLoadingTemplates">
                                    <span x-text="getTemplateLabel()"></span>
                                </template>
                            </span>
                            <i class="bi bi-chevron-down"></i>
                        </button>
                        <div class="custom-select-dropdown" x-show="open && !isLoadingTemplates" x-cloak x-transition @click.stop>
                            <button type="button" class="custom-select-option" :class="{ 'selected': templateId === null }" @click="templateId = null; open = false">
                                <i class="bi bi-file-earmark"></i> Default Template
                            </button>
                            <template x-if="templates.length > 0">
                                <div class="custom-select-divider"></div>
                            </template>
                            <template x-for="tpl in templates" :key="tpl.id">
                                <button type="button" class="custom-select-option" :class="{ 'selected': templateId === tpl.id }" @click="templateId = tpl.id; open = false"
                                        style="display: flex; align-items: center; gap: 8px;">
                                    <i class="bi bi-file-earmark-code"></i>
                                    <span x-text="tpl.name" style="flex: 1;"></span>
                                    <i class="bi bi-star-fill" x-show="defaultTemplateId === tpl.id" style="color: #dba617; font-size: 14px;" title="Default Template"></i>
                                </button>
                            </template>
                            <div class="custom-select-empty" x-show="templates.length === 0">
                                No templates saved. <span class="link-text" @click="$dispatch('close-add-modal'); $nextTick(() => $root.showTemplateModal = true)">Create one</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Options Row -->
            <div class="options-row">
                <!-- Search ASIN Toggle -->
                <div class="option-item" :class="{ 'option-item-expanded': searchAsin }">
                    <label class="switch-label">
                        <span class="switch-icon"><i class="bi bi-search"></i></span>
                        <span class="switch-text">Search ASIN</span>
                        <label class="switch">
                            <input type="checkbox" x-model="searchAsin">
                            <span class="switch-slider"></span>
                        </label>
                    </label>
                    <span class="option-hint">Auto find products from Amazon</span>

                    <!-- Search Limit Stepper (shows when searchAsin is enabled) -->
                    <div class="search-limit-row" x-show="searchAsin" x-transition x-cloak>
                        <span class="search-limit-label">Max results:</span>
                        <div class="stepper">
                            <button type="button" class="stepper-btn" @click="searchLimit = Math.max(1, searchLimit - 1)" :disabled="searchLimit <= 1">
                                <i class="bi bi-dash"></i>
                            </button>
                            <input type="number" class="stepper-input" x-model.number="searchLimit" min="1" max="25" @blur="searchLimit = Math.max(1, Math.min(25, searchLimit || 15))">
                            <button type="button" class="stepper-btn" @click="searchLimit = Math.min(25, searchLimit + 1)" :disabled="searchLimit >= 25">
                                <i class="bi bi-plus"></i>
                            </button>
                        </div>
                    </div>

                    <!-- Manual ASIN Input (shows when searchAsin is disabled) -->
                    <div class="manual-asin-row" x-show="!searchAsin" x-transition x-cloak>
                        <label class="manual-asin-label">
                            <i class="bi bi-upc-scan"></i>
                            Manual ASINs
                        </label>
                        <input type="text" class="form-input manual-asin-input"
                               x-model="manualAsins"
                               placeholder="B01ABC1234, B02DEF5678, ..."
                               @input="parseManualAsins()">
                        <span class="manual-asin-hint">
                            <template x-if="manualAsinCount > 0">
                                <span x-text="manualAsinCount + ' ASIN(s) detected'"></span>
                            </template>
                            <template x-if="manualAsinCount === 0">
                                <span>Enter ASINs separated by commas</span>
                            </template>
                        </span>
                    </div>
                </div>

                <!-- Publish Status Toggle -->
                <div class="option-item">
                    <label class="switch-label">
                        <span class="switch-icon"><i class="bi bi-globe2"></i></span>
                        <span class="switch-text">Auto Publish</span>
                        <label class="switch">
                            <input type="checkbox" x-model="autoPublish">
                            <span class="switch-slider"></span>
                        </label>
                    </label>
                    <span class="option-hint" x-text="autoPublish ? 'Will be published' : 'Will be saved as draft'"></span>
                </div>

                <!-- No-Index Toggle -->
                <div class="option-item">
                    <label class="switch-label">
                        <span class="switch-icon"><i class="bi bi-eye-slash"></i></span>
                        <span class="switch-text">No-Index</span>
                        <label class="switch">
                            <input type="checkbox" x-model="noIndex">
                            <span class="switch-slider"></span>
                        </label>
                    </label>
                    <span class="option-hint" x-text="noIndex ? 'Hidden from search engines' : 'Visible to search engines'"></span>
                </div>
            </div>
        </div>

        <!-- Modal Footer -->
        <div class="modal-footer" x-show="!showResult">
            <button type="button" class="btn btn-secondary" @click="$dispatch('close-add-modal')">
                Cancel
            </button>
            <div class="btn-group">
                <button type="button" class="btn btn-primary" @click="submit(false)" :disabled="isSubmitting || keywordCount === 0 || !postType">
                    <i class="bi" :class="isSubmitting && !processNow ? 'bi-arrow-clockwise animate-spin' : 'bi-plus-lg'"></i>
                    <span x-text="isSubmitting && !processNow ? 'Adding...' : 'Add to Queue'"></span>
                </button>
                <!-- Hidden: Process Now button
                <button type="button" class="btn btn-success" @click="submit(true)" :disabled="isSubmitting || keywordCount === 0 || !postType" title="Add and start processing immediately">
                    <i class="bi" :class="isSubmitting && processNow ? 'bi-arrow-clockwise animate-spin' : 'bi-play-fill'"></i>
                    <span x-text="isSubmitting && processNow ? 'Processing...' : 'Process Now'"></span>
                </button>
                -->
            </div>
        </div>

        <!-- Result Dialog (shows after submission) -->
        <div class="result-dialog" x-show="showResult" x-cloak x-transition>
            <!-- Result Header -->
            <div class="result-header" :class="resultData.success ? 'result-success' : 'result-warning'">
                <div class="result-icon">
                    <i class="bi" :class="resultData.success ? 'bi-check-circle-fill' : 'bi-exclamation-triangle-fill'"></i>
                </div>
                <div class="result-title" x-text="resultData.success ? 'Keywords Added!' : 'Completed with Issues'"></div>
            </div>

            <!-- Result Stats -->
            <div class="result-stats">
                <!-- Created -->
                <div class="result-stat result-stat-success" x-show="resultData.summary?.created > 0">
                    <div class="stat-icon"><i class="bi bi-check-lg"></i></div>
                    <div class="stat-content">
                        <div class="stat-value" x-text="resultData.summary?.created || 0"></div>
                        <div class="stat-label">Added</div>
                    </div>
                </div>

                <!-- Processing Scheduled -->
                <div class="result-stat result-stat-info" x-show="resultData.summary?.processing_scheduled > 0">
                    <div class="stat-icon"><i class="bi bi-clock-history"></i></div>
                    <div class="stat-content">
                        <div class="stat-value" x-text="resultData.summary?.processing_scheduled || 0"></div>
                        <div class="stat-label">Processing</div>
                    </div>
                </div>

                <!-- Existing -->
                <div class="result-stat result-stat-warning" x-show="resultData.summary?.existing > 0">
                    <div class="stat-icon"><i class="bi bi-dash-circle"></i></div>
                    <div class="stat-content">
                        <div class="stat-value" x-text="resultData.summary?.existing || 0"></div>
                        <div class="stat-label">Already Exist</div>
                    </div>
                </div>

                <!-- Failed -->
                <div class="result-stat result-stat-error" x-show="resultData.summary?.failed > 0">
                    <div class="stat-icon"><i class="bi bi-x-lg"></i></div>
                    <div class="stat-content">
                        <div class="stat-value" x-text="resultData.summary?.failed || 0"></div>
                        <div class="stat-label">Failed</div>
                    </div>
                </div>
            </div>

            <!-- Existing Keywords List -->
            <div class="result-list" x-show="resultData.data?.existing?.length > 0">
                <div class="result-list-header" @click="showExistingList = !showExistingList">
                    <span><i class="bi bi-dash-circle"></i> Keywords already in queue</span>
                    <i class="bi" :class="showExistingList ? 'bi-chevron-up' : 'bi-chevron-down'"></i>
                </div>
                <div class="result-list-items" x-show="showExistingList" x-collapse>
                    <template x-for="kw in resultData.data?.existing || []" :key="kw">
                        <div class="result-list-item">
                            <i class="bi bi-dash text-warning"></i>
                            <span x-text="kw"></span>
                        </div>
                    </template>
                </div>
            </div>


            <!-- Result Footer -->
            <div class="result-footer">
                <button type="button" class="btn btn-secondary" @click="addMore()">
                    <i class="bi bi-plus-lg"></i> Add More
                </button>
                <button type="button" class="btn btn-primary" @click="closeResult()">
                    <i class="bi bi-check-lg"></i> Done
                </button>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('alpine:init', () => {
    Alpine.data('addKeywordsModal', () => ({
        // Form state
        keywords: '',
        keywordCount: 0,
        postType: null,
        postTypes: [],
        categoryId: null,
        categories: [],
        authorId: 'random',
        authors: [],
        templateId: null,
        templates: [],
        defaultTemplateId: null,
        searchAsin: true,
        searchLimit: 15,
        manualAsins: '',
        manualAsinCount: 0,
        autoPublish: false,
        noIndex: true,
        isSubmitting: false,
        isLoadingCategories: false,
        isLoadingAuthors: false,
        isLoadingTemplates: false,
        processNow: false,
        // Result dialog state
        showResult: false,
        resultData: {},
        showExistingList: false,

        init() {
            // Load postTypes (use backup _acmsPostTypes since acmsConfig.postTypes gets overwritten)
            this.postTypes = window._acmsPostTypes || window.acmsConfig?.postTypes || [];

            // Load authors and templates
            this.loadAuthors();
            this.loadTemplates();

            // Listen for template saved event to refresh templates list
            window.addEventListener('template-saved', () => this.loadTemplates());
        },

        // Computed: only enabled post types
        get enabledPostTypes() {
            return this.postTypes.filter(pt => pt.enabled);
        },

        parseKeywords() {
            const lines = this.keywords.split('\n').filter(line => line.trim() !== '');
            this.keywordCount = lines.length;
        },

        parseManualAsins() {
            // Split by comma, space, or newline and filter valid ASINs
            const asins = this.manualAsins
                .split(/[,\s\n]+/)
                .map(a => a.trim().toUpperCase())
                .filter(a => a.length === 10 && a.startsWith('B') && /^B[A-Z0-9]{9}$/.test(a));
            this.manualAsinCount = asins.length;
        },

        getPostTypeLabel(value) {
            const pt = this.postTypes.find(p => p.value === value);
            return pt ? pt.label : value;
        },

        isPostTypeEnabled(value) {
            const pt = this.postTypes.find(p => p.value === value);
            return pt ? pt.enabled : false;
        },

        getCategoryLabel(id) {
            if (id === null) return 'No Category';
            const cat = this.categories.find(c => c.id === id);
            return cat ? cat.name : 'No Category';
        },

        getAuthorLabel() {
            if (this.authorId === 'random') return 'Random Author';
            const author = this.authors.find(a => a.id === this.authorId);
            return author ? author.name : 'Select Author';
        },

        async loadAuthors() {
            this.isLoadingAuthors = true;
            try {
                const response = await fetch(`${window.location.origin}/wp-json/wp/v2/users?per_page=100&context=edit`, {
                    headers: { 'X-WP-Nonce': acmsConfig.nonce }
                });

                if (response.ok) {
                    const data = await response.json();
                    this.authors = data.map(user => ({
                        id: user.id,
                        name: user.name,
                        email: user.email || ''
                    }));
                } else {
                    this.authors = [];
                }
            } catch (error) {
                this.authors = [];
            } finally {
                this.isLoadingAuthors = false;
            }
        },

        async loadTemplates() {
            this.isLoadingTemplates = true;
            try {
                const response = await fetch(acmsConfig.restUrl + 'templates', {
                    headers: { 'X-WP-Nonce': acmsConfig.nonce }
                });

                if (response.ok) {
                    const result = await response.json();
                    if (result.success) {
                        this.templates = result.data || [];
                        this.defaultTemplateId = result.default_template_id || null;

                        // Auto-select default template if available
                        if (this.defaultTemplateId && this.templateId === null) {
                            this.templateId = this.defaultTemplateId;
                        }
                    }
                } else {
                    this.templates = [];
                }
            } catch (error) {
                this.templates = [];
            } finally {
                this.isLoadingTemplates = false;
            }
        },

        getTemplateLabel() {
            if (this.templateId === null) return 'Default Template';
            const tpl = this.templates.find(t => t.id === this.templateId);
            return tpl ? tpl.name : 'Default Template';
        },

        selectPostType(value) {
            this.postType = value;
            this.categoryId = null;
            this.loadCategories(value);
        },

        async loadCategories(postType) {
            if (!postType) {
                this.categories = [];
                return;
            }

            // Pages don't have categories
            if (postType === 'page') {
                this.categories = [];
                this.isLoadingCategories = false;
                return;
            }

            this.isLoadingCategories = true;
            this.categories = [];

            try {
                // Determine taxonomy endpoint
                let taxonomy;
                if (postType === 'post') {
                    taxonomy = 'categories'; // WordPress built-in category
                } else {
                    taxonomy = postType + '_category'; // Custom post type taxonomy
                }

                // Use WordPress REST API for taxonomies
                const response = await fetch(`${window.location.origin}/wp-json/wp/v2/${taxonomy}?per_page=100&hide_empty=false`, {
                    headers: { 'X-WP-Nonce': acmsConfig.nonce }
                });

                if (response.ok) {
                    const data = await response.json();
                    this.categories = data.map(cat => ({
                        id: cat.id,
                        name: cat.name,
                        slug: cat.slug,
                        parent: cat.parent || 0
                    }));

                    // Sort: parents first, then children
                    this.categories.sort((a, b) => {
                        if (a.parent === 0 && b.parent !== 0) return -1;
                        if (a.parent !== 0 && b.parent === 0) return 1;
                        return a.name.localeCompare(b.name);
                    });
                } else {
                    this.categories = [];
                }
            } catch (error) {
                this.categories = [];
            } finally {
                this.isLoadingCategories = false;
            }
        },

        showResultDialog(result) {
            this.resultData = result;
            this.showResult = true;
            this.showExistingList = false;
            this.showSearchErrors = false;
        },

        addMore() {
            // Hide result dialog and show form again
            this.showResult = false;
            this.resultData = {};
        },

        closeResult() {
            // Close the entire modal
            this.showResult = false;
            this.resultData = {};
            this.$dispatch('close-add-modal');
        },

        async submit(processImmediately = false) {
            if (this.keywordCount === 0 || !this.postType) return;

            this.isSubmitting = true;
            this.processNow = processImmediately;

            // Build payload
            const payload = {
                keywords: this.keywords,
                post_type: this.postType,
                category_id: this.categoryId,
                author_id: this.authorId,
                template_id: this.templateId,
                search_asin: this.searchAsin,
                search_limit: this.searchLimit,
                manual_asins: this.searchAsin ? '' : this.manualAsins,
                auto_publish: this.autoPublish,
                no_index: this.noIndex,
                process_now: processImmediately
            };

            try {
                const response = await fetch(acmsConfig.restUrl + 'queue', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': acmsConfig.nonce
                    },
                    body: JSON.stringify(payload)
                });

                const result = await response.json();

                // Handle non-success HTTP status
                if (!response.ok) {
                    window.dispatchEvent(new CustomEvent('show-toast', {
                        detail: {
                            type: 'error',
                            title: 'Error',
                            message: result.message || `HTTP Error: ${response.status}`
                        }
                    }));
                    return;
                }

                // Show result dialog with detailed feedback
                this.showResultDialog(result);

                // Reset form fields (but don't close modal)
                this.keywords = '';
                this.keywordCount = 0;
                this.manualAsins = '';
                this.manualAsinCount = 0;

                // Refresh list
                window.dispatchEvent(new CustomEvent('items-updated'));

                // If process now and successful, trigger queue processing
                if (processImmediately && result.success) {
                    window.dispatchEvent(new CustomEvent('start-queue-processing'));
                }
            } catch (error) {
                window.dispatchEvent(new CustomEvent('show-toast', {
                    detail: {
                        type: 'error',
                        title: 'Error',
                        message: 'Failed to add keywords'
                    }
                }));
            } finally {
                this.isSubmitting = false;
                this.processNow = false;
            }
        }
    }));
});
</script>

<style>
.add-keywords-modal {
    max-width: 640px;
}

.add-keywords-modal .modal-close {
    position: absolute;
    top: 16px;
    right: 16px;
    width: 32px;
    height: 32px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: transparent;
    border: none;
    border-radius: 6px;
    color: var(--text-muted);
    cursor: pointer;
    transition: all 0.15s ease;
}

.add-keywords-modal .modal-close:hover {
    background: var(--bg-hover);
    color: var(--text-primary);
}

.add-keywords-modal .modal-close i {
    font-size: 18px;
}

.add-keywords-modal .modal-header {
    position: relative;
}

.add-keywords-modal .modal-footer {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.add-keywords-modal .modal-footer .btn-group {
    display: flex;
    gap: 8px;
}

/* Form Row - 50-50 Layout */
.form-row {
    display: flex;
    width: 100%;
    gap: 12px;
}

.form-row > .form-group {
    flex: 1;
    min-width: 0;
}

/* Fixed form row - Always 50-50 (Author & Content Template) */
.form-row-fixed > .form-group {
    width: 50%;
}

/* Responsive form row - Post Type & Category */
/* When category is hidden (no form-row-responsive), Post Type takes full width */
.form-row:not(.form-row-responsive):not(.form-row-fixed) > .form-group {
    width: 100%;
}

/* When category is visible (has form-row-responsive), both take 50% */
.form-row.form-row-responsive > .form-group {
    width: 50%;
}

.custom-select-trigger.placeholder .custom-select-value {
    color: var(--text-muted);
}

.custom-select-trigger.loading {
    opacity: 0.7;
    cursor: wait;
}

.loading-text {
    display: flex;
    align-items: center;
    gap: 6px;
    color: var(--text-muted);
}

.custom-select-empty {
    padding: 12px 16px;
    color: var(--text-muted);
    font-size: 13px;
    text-align: center;
}

.text-subtle {
    color: var(--text-muted) !important;
    font-size: 12px;
}

/* Custom select divider */
.custom-select-divider {
    height: 1px;
    background: var(--border);
    margin: 4px 0;
}

.custom-select-option i {
    margin-right: 6px;
    opacity: 0.7;
}

.custom-select-empty .link-text {
    color: var(--primary);
    cursor: pointer;
    text-decoration: underline;
}

.custom-select-empty .link-text:hover {
    color: var(--primary-hover);
}

/* Searchable Select */
.searchable-select .custom-select-dropdown {
    max-height: 320px;
    display: flex;
    flex-direction: column;
}

.select-search-box {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 12px;
    border-bottom: 1px solid var(--border);
    background: var(--bg-secondary);
    flex-shrink: 0;
}

.select-search-box i {
    color: var(--text-muted);
    font-size: 14px;
}

.select-search-input {
    flex: 1;
    border: none;
    background: transparent;
    font-size: 13px;
    color: var(--text-primary);
    outline: none;
}

.select-search-input::placeholder {
    color: var(--text-muted);
}

.select-search-clear {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 20px;
    height: 20px;
    padding: 0;
    border: none;
    background: var(--bg-tertiary);
    color: var(--text-muted);
    border-radius: 50%;
    cursor: pointer;
    transition: all 0.15s ease;
}

.select-search-clear:hover {
    background: var(--bg-hover);
    color: var(--text-primary);
}

.custom-select-options {
    flex: 1;
    overflow-y: auto;
    max-height: 250px;
}

/* Switch styles */
.switch-label {
    display: flex;
    align-items: center;
    gap: 8px;
    cursor: pointer;
}

.switch-icon {
    width: 24px;
    height: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--text-muted);
}

.switch-icon i {
    font-size: 14px;
}

.switch-text {
    flex: 1;
    font-size: 13px;
    font-weight: 500;
    color: var(--text-primary);
}

.switch {
    position: relative;
    display: inline-block;
    width: 40px;
    height: 22px;
    flex-shrink: 0;
}

.switch input {
    opacity: 0;
    width: 0;
    height: 0;
}

.switch-slider {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: var(--bg-secondary);
    border: 1px solid var(--border);
    transition: 0.2s;
    border-radius: 22px;
}

.switch-slider:before {
    position: absolute;
    content: "";
    height: 16px;
    width: 16px;
    left: 2px;
    bottom: 2px;
    background-color: var(--text-muted);
    transition: 0.2s;
    border-radius: 50%;
}

.switch input:checked + .switch-slider {
    background-color: var(--primary);
    border-color: var(--primary);
}

.switch input:checked + .switch-slider:before {
    transform: translateX(18px);
    background-color: white;
}

/* Options Row - Full width items */
.options-row {
    display: flex;
    flex-direction: column;
    gap: 12px;
    margin-top: 16px;
    padding-top: 16px;
    border-top: 1px solid var(--border);
}

.option-item {
    padding: 12px;
    background: var(--bg-secondary);
    border-radius: 8px;
    display: flex;
    flex-direction: column;
    gap: 6px;
}

.option-item .switch-label {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 0;
}

.option-hint {
    font-size: 11px;
    color: var(--text-muted);
    padding-left: 28px;
}

.option-item-expanded {
    gap: 8px;
}

/* Search Limit Stepper */
.search-limit-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px 0 0 0;
    border-top: 1px dashed var(--border);
    margin-top: 8px;
}

.search-limit-label {
    font-size: 12px;
    color: var(--text-muted);
}

.stepper {
    position: relative;
    display: inline-flex;
    align-items: center;
}

.stepper-input {
    width: 140px;
    height: 36px;
    padding: 0 36px;
    border: 1px solid var(--border);
    border-radius: 6px;
    background: var(--bg-primary);
    text-align: center;
    font-size: 14px;
    font-weight: 600;
    color: var(--text-primary);
    -moz-appearance: textfield;
}

.stepper-input:focus {
    outline: none;
    border-color: var(--primary);
}

.stepper-btn {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    width: 28px;
    height: 28px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: transparent;
    border: none;
    color: var(--text-muted);
    cursor: pointer;
    transition: all 0.15s ease;
}

.stepper-btn:first-child {
    left: 3px;
}

.stepper-btn:last-child {
    right: 3px;
}

.stepper-btn:hover:not(:disabled) {
    color: var(--text-primary);
}

.stepper-btn:disabled {
    opacity: 0.3;
    cursor: not-allowed;
}

.stepper-btn i {
    font-size: 14px;
}

.stepper-input::-webkit-outer-spin-button,
.stepper-input::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
}

.stepper-input:focus {
    outline: none;
}

/* Manual ASIN Input */
.manual-asin-row {
    display: flex;
    flex-direction: column;
    gap: 6px;
    padding: 10px 0 0 0;
    border-top: 1px dashed var(--border);
    margin-top: 8px;
}

.manual-asin-label {
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 12px;
    font-weight: 500;
    color: var(--text-secondary);
}

.manual-asin-label i {
    font-size: 14px;
}

.manual-asin-input {
    width: 100%;
    padding: 8px 12px;
    border: 1px solid var(--border);
    border-radius: 6px;
    background: var(--bg-primary);
    font-size: 13px;
    color: var(--text-primary);
    font-family: monospace;
}

.manual-asin-input:focus {
    outline: none;
    border-color: var(--primary);
}

.manual-asin-input::placeholder {
    color: var(--text-muted);
    font-family: inherit;
}

.manual-asin-hint {
    font-size: 11px;
    color: var(--text-muted);
}

/* Success button */
.btn-success {
    background: var(--success, #10b981);
    color: white;
    border: none;
}

.btn-success:hover:not(:disabled) {
    background: var(--success-hover, #059669);
}

.btn-success:disabled {
    opacity: 0.5;
    cursor: not-allowed;
}

@keyframes spin {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}

.animate-spin {
    animation: spin 1s linear infinite;
}

/* Result Dialog Styles */
.result-dialog {
    padding: 0;
}

.result-header {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 24px 20px;
    gap: 12px;
    border-radius: 12px 12px 0 0;
}

.result-header.result-success {
    background: linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(16, 185, 129, 0.05));
    color: var(--success, #10b981);
}

.result-header.result-warning {
    background: linear-gradient(135deg, rgba(245, 158, 11, 0.1), rgba(245, 158, 11, 0.05));
    color: var(--warning, #f59e0b);
}

.result-icon {
    width: 48px;
    height: 48px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 32px;
}

.result-title {
    font-size: 18px;
    font-weight: 600;
    color: var(--text-primary);
}

.result-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(100px, 1fr));
    gap: 12px;
    padding: 20px;
    background: var(--bg-secondary);
}

.result-stat {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 12px;
    background: var(--bg-primary);
    border-radius: 8px;
    border-left: 3px solid transparent;
}

.result-stat-success {
    border-left-color: var(--success, #10b981);
}

.result-stat-info {
    border-left-color: var(--primary, #3b82f6);
}

.result-stat-warning {
    border-left-color: var(--warning, #f59e0b);
}

.result-stat-error {
    border-left-color: var(--danger, #ef4444);
}

.result-stat .stat-icon {
    width: 32px;
    height: 32px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 6px;
    font-size: 16px;
}

.result-stat-success .stat-icon {
    background: rgba(16, 185, 129, 0.1);
    color: var(--success, #10b981);
}

.result-stat-info .stat-icon {
    background: rgba(59, 130, 246, 0.1);
    color: var(--primary, #3b82f6);
}

.result-stat-warning .stat-icon {
    background: rgba(245, 158, 11, 0.1);
    color: var(--warning, #f59e0b);
}

.result-stat-error .stat-icon {
    background: rgba(239, 68, 68, 0.1);
    color: var(--danger, #ef4444);
}

.result-stat .stat-content {
    display: flex;
    flex-direction: column;
}

.result-stat .stat-value {
    font-size: 20px;
    font-weight: 700;
    color: var(--text-primary);
    line-height: 1.2;
}

.result-stat .stat-label {
    font-size: 11px;
    color: var(--text-muted);
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

/* Result Lists */
.result-list {
    margin: 0 20px 12px;
    border: 1px solid var(--border);
    border-radius: 8px;
    overflow: hidden;
}

.result-list-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px 12px;
    background: var(--bg-secondary);
    cursor: pointer;
    font-size: 13px;
    font-weight: 500;
    color: var(--text-secondary);
    transition: background 0.15s ease;
}

.result-list-header:hover {
    background: var(--bg-hover);
}

.result-list-header span {
    display: flex;
    align-items: center;
    gap: 8px;
}

.result-list-items {
    max-height: 150px;
    overflow-y: auto;
    background: var(--bg-primary);
}

.result-list-item {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 12px;
    font-size: 13px;
    color: var(--text-secondary);
    border-top: 1px solid var(--border);
}

.result-list-item:first-child {
    border-top: none;
}

.result-error-item {
    flex-wrap: wrap;
}

.result-error-item span {
    flex: 1;
    min-width: 0;
    word-break: break-word;
}

.text-warning {
    color: var(--warning, #f59e0b) !important;
}

.text-muted {
    color: var(--text-muted) !important;
}

/* Result Footer */
.result-footer {
    display: flex;
    justify-content: flex-end;
    gap: 12px;
    padding: 16px 20px;
    border-top: 1px solid var(--border);
}

/* Hide modal body when showing result */
.add-keywords-modal:has(.result-dialog[style*="display: block"]) .modal-body,
.add-keywords-modal:has(.result-dialog:not([style*="display: none"])) .modal-body {
    display: none;
}
</style>
