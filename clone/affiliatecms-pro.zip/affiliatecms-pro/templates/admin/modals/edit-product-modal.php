<?php
/**
 * Edit Product Modal - View/Edit product details
 *
 * @package AffiliateCMS\Pro
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<!-- Edit Product Modal -->
<div class="modal-backdrop" x-show="showEditModal" x-cloak @click.self="showEditModal = false"
     @edit-product.window="currentProduct = $event.detail; editForm = {...$event.detail}; editProductTab = 'custom'; showEditModal = true; fetchFullProductDetails($event.detail.id)"
     x-transition:enter="transition ease-out duration-200"
     x-transition:enter-start="opacity-0"
     x-transition:enter-end="opacity-100"
     x-transition:leave="transition ease-in duration-150"
     x-transition:leave-start="opacity-100"
     x-transition:leave-end="opacity-0">
    <div class="modal modal-lg" @click.stop>
        <div class="modal-header">
            <h2 class="modal-title">
                <i class="bi bi-pencil"></i>
                Edit Product
                <code style="background: var(--bg-elevated); padding: 2px 8px; border-radius: 4px; margin-left: 8px; font-size: 13px;" x-text="editForm.asin"></code>
            </h2>
            <button class="btn-icon btn-icon-sm" @click="showEditModal = false">
                <i class="bi bi-x-lg"></i>
            </button>
        </div>

        <!-- Product Preview -->
        <div style="display: flex; gap: 16px; padding: 16px; background: var(--bg-elevated); border-bottom: 1px solid var(--border);">
            <div style="width: 64px; height: 64px; flex-shrink: 0; border-radius: var(--radius-sm); overflow: hidden; background: var(--bg-surface); border: 1px solid var(--border);">
                <img :src="editForm.image_url || editForm.imageUrl" :alt="editForm.title" style="width: 100%; height: 100%; object-fit: cover;"
                     onerror="this.src='data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 48 48%22><rect fill=%22%2318181b%22 width=%2248%22 height=%2248%22/><text x=%2224%22 y=%2228%22 fill=%22%2371717a%22 font-size=%2212%22 text-anchor=%22middle%22>No img</text></svg>'">
            </div>
            <div style="flex: 1; min-width: 0;">
                <div style="font-weight: 500; color: var(--text-primary); margin-bottom: 4px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" x-text="editForm.title || 'Untitled Product'"></div>
                <div style="display: flex; align-items: center; gap: 8px; font-size: 13px; color: var(--text-secondary);">
                    <span x-text="editForm.brand || '-'"></span>
                    <span>|</span>
                    <span class="badge" :class="'badge-' + (editForm.status === 'scraped' ? 'success' : (editForm.status === 'failed' ? 'error' : 'primary'))" x-text="editForm.status"></span>
                </div>
                <!-- Timestamps -->
                <div style="display: flex; flex-wrap: wrap; gap: 12px; margin-top: 6px; font-size: 11px; color: var(--text-muted);">
                    <span x-show="editForm.last_scraped_at" :title="editForm.last_scraped_at">
                        <i class="bi bi-cloud-download" style="margin-right: 2px;"></i>
                        Scraped: <span x-text="editForm.last_scraped_at ? new Date(editForm.last_scraped_at).toLocaleDateString('en-US', {month:'short', day:'numeric', hour:'2-digit', minute:'2-digit'}) : '-'"></span>
                    </span>
                    <span x-show="editForm.quick_update_at" :title="editForm.quick_update_at">
                        <i class="bi bi-arrow-repeat" style="margin-right: 2px;"></i>
                        Updated: <span x-text="editForm.quick_update_at ? new Date(editForm.quick_update_at).toLocaleDateString('en-US', {month:'short', day:'numeric', hour:'2-digit', minute:'2-digit'}) : '-'"></span>
                        <span x-show="editForm.quick_update_count > 0" x-text="'(' + editForm.quick_update_count + 'x)'" style="opacity: 0.7;"></span>
                    </span>
                    <span x-show="editForm.created_at" :title="editForm.created_at">
                        <i class="bi bi-plus-circle" style="margin-right: 2px;"></i>
                        Added: <span x-text="editForm.created_at ? new Date(editForm.created_at).toLocaleDateString('en-US', {month:'short', day:'numeric', year:'numeric'}) : '-'"></span>
                    </span>
                </div>
            </div>
        </div>

        <!-- Tabs -->
        <div style="display: flex; border-bottom: 1px solid var(--border); background: var(--bg-surface);">
            <button class="edit-product-tab" :class="{ 'active': editProductTab === 'custom' }" @click="editProductTab = 'custom'">
                <i class="bi bi-pencil-square"></i>
                Custom Content
                <span x-show="editForm.ai_status === 'generated'"
                      style="margin-left: 4px; width: 8px; height: 8px; background: var(--success); border-radius: 50%; display: inline-block;"
                      title="AI content generated"></span>
            </button>
            <button class="edit-product-tab" :class="{ 'active': editProductTab === 'basic' }" @click="editProductTab = 'basic'">
                <i class="bi bi-box"></i>
                Basic Information
            </button>
            <button class="edit-product-tab" :class="{ 'active': editProductTab === 'links' }" @click="editProductTab = 'links'"
                    x-data="{ linkCount: 0 }"
                    @edit-product.window="fetch(`${acmsConfig.restUrl}products/${$event.detail.id}/links`, { headers: { 'X-WP-Nonce': acmsConfig.nonce } }).then(r => r.json()).then(d => linkCount = d.data?.length || 0).catch(() => linkCount = 0)"
                    @affiliate-links-updated.window="linkCount = $event.detail.count">
                <i class="bi bi-link-45deg"></i>
                Affiliate Links
                <span x-show="linkCount > 0"
                      x-text="linkCount"
                      style="margin-left: 6px; padding: 2px 7px; background: var(--primary); color: white; border-radius: 10px; font-size: 11px; font-weight: 600; line-height: 1; min-width: 18px; display: inline-block; text-align: center;"></span>
            </button>
        </div>

        <div class="modal-body" style="max-height: 60vh; overflow-y: auto;">

            <!-- TAB 1: Basic Information -->
            <div x-show="editProductTab === 'basic'" x-transition:enter="transition ease-out duration-150" x-transition:enter-start="opacity-0" x-transition:enter-end="opacity-100">

                <div class="form-group" style="margin-bottom: 16px;">
                    <label class="form-label">ASIN</label>
                    <input type="text" class="input" x-model="editForm.asin" placeholder="B0XXXXXXXXX" style="font-family: monospace;" readonly>
                </div>

                <div class="form-group" style="margin-bottom: 16px;">
                    <label class="form-label">Title</label>
                    <textarea class="input" x-model="editForm.title" rows="2" style="resize: vertical;"></textarea>
                </div>

                <div class="form-row" style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 16px;">
                    <div class="form-group">
                        <label class="form-label">Brand</label>
                        <input type="text" class="input" x-model="editForm.brand">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Image URL</label>
                        <input type="text" class="input" x-model="editForm.image_url" placeholder="https://...">
                    </div>
                </div>

                <!-- Category -->
                <div style="font-weight: 600; font-size: 13px; color: var(--text-secondary); text-transform: uppercase; letter-spacing: 0.5px; margin: 20px 0 12px; padding-bottom: 6px; border-bottom: 1px solid var(--border);">
                    Category
                </div>

                <div class="form-row" style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 16px;">
                    <div class="form-group">
                        <label class="form-label">Category</label>
                        <input type="text" class="input" x-model="editForm.category">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Category Path <span style="font-weight: 400; color: var(--text-muted); font-size: 11px;">(Amazon)</span></label>
                        <input type="text" class="input" x-model="editForm.category_path" placeholder="Electronics > Headphones > ..." readonly style="background: var(--bg-elevated);">
                    </div>
                </div>

                <!-- Pricing -->
                <div style="font-weight: 600; font-size: 13px; color: var(--text-secondary); text-transform: uppercase; letter-spacing: 0.5px; margin: 20px 0 12px; padding-bottom: 6px; border-bottom: 1px solid var(--border);">
                    Pricing
                </div>

                <div class="form-row" style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 16px;">
                    <div class="form-group">
                        <label class="form-label">Current Price ($)</label>
                        <input type="number" class="input" x-model="editForm.price" step="0.01" min="0">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Original Price ($)</label>
                        <input type="number" class="input" x-model="editForm.original_price" step="0.01" min="0" placeholder="Leave empty if no discount">
                    </div>
                </div>

                <!-- Rating & Reviews -->
                <div style="font-weight: 600; font-size: 13px; color: var(--text-secondary); text-transform: uppercase; letter-spacing: 0.5px; margin: 20px 0 12px; padding-bottom: 6px; border-bottom: 1px solid var(--border);">
                    Rating & Reviews
                </div>

                <div class="form-row" style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 16px;">
                    <div class="form-group">
                        <label class="form-label">Rating (0-5)</label>
                        <input type="number" class="input" x-model="editForm.rating" step="0.1" min="0" max="5">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Reviews Count</label>
                        <input type="number" class="input" x-model="editForm.reviews_count" min="0">
                    </div>
                </div>

                <!-- Status & Flags -->
                <div style="font-weight: 600; font-size: 13px; color: var(--text-secondary); text-transform: uppercase; letter-spacing: 0.5px; margin: 20px 0 12px; padding-bottom: 6px; border-bottom: 1px solid var(--border);">
                    Status & Flags
                </div>

                <div class="form-group" style="margin-bottom: 16px;" x-data="{ editStatusOpen: false }">
                    <label class="form-label">Status</label>
                    <div class="custom-select" @click.outside="editStatusOpen = false">
                        <button type="button" class="custom-select-trigger" :class="{ 'open': editStatusOpen }" @click="editStatusOpen = !editStatusOpen">
                            <span class="custom-select-value" x-text="editForm.status === 'pending' ? 'Pending' : (editForm.status === 'processing' ? 'Processing' : (editForm.status === 'scraped' ? 'Scraped' : 'Failed'))"></span>
                            <i class="bi bi-chevron-down"></i>
                        </button>
                        <div class="custom-select-dropdown" x-show="editStatusOpen" x-cloak x-transition @click.stop>
                            <button type="button" class="custom-select-option" :class="{ 'selected': editForm.status === 'pending' }" @click="editForm.status = 'pending'; editStatusOpen = false">Pending</button>
                            <button type="button" class="custom-select-option" :class="{ 'selected': editForm.status === 'processing' }" @click="editForm.status = 'processing'; editStatusOpen = false">Processing</button>
                            <button type="button" class="custom-select-option" :class="{ 'selected': editForm.status === 'scraped' }" @click="editForm.status = 'scraped'; editStatusOpen = false">Scraped</button>
                            <button type="button" class="custom-select-option" :class="{ 'selected': editForm.status === 'failed' }" @click="editForm.status = 'failed'; editStatusOpen = false">Failed</button>
                        </div>
                    </div>
                </div>

                <div style="display: flex; gap: 16px;">
                    <div style="display: flex; align-items: center; justify-content: space-between; flex: 1; padding: 12px 16px; background: var(--bg-elevated); border: 1px solid var(--border); border-radius: var(--radius-md);">
                        <div>
                            <div style="font-weight: 500; margin-bottom: 2px;">In Stock</div>
                            <div style="font-size: 12px; color: var(--text-muted);">Product availability</div>
                        </div>
                        <div class="toggle" :class="{ 'active': editForm.in_stock }" @click="editForm.in_stock = !editForm.in_stock"
                             style="width: 44px; height: 24px; background: var(--bg-surface); border-radius: 12px; position: relative; cursor: pointer; transition: background 0.2s;"
                             :style="editForm.in_stock ? 'background: var(--success);' : ''">
                            <div style="width: 20px; height: 20px; background: white; border-radius: 50%; position: absolute; top: 2px; transition: left 0.2s;"
                                 :style="editForm.in_stock ? 'left: 22px;' : 'left: 2px;'"></div>
                        </div>
                    </div>
                    <div style="display: flex; align-items: center; justify-content: space-between; flex: 1; padding: 12px 16px; background: var(--bg-elevated); border: 1px solid var(--border); border-radius: var(--radius-md);">
                        <div>
                            <div style="font-weight: 500; margin-bottom: 2px;">Prime</div>
                            <div style="font-size: 12px; color: var(--text-muted);">Amazon Prime eligible</div>
                        </div>
                        <div class="toggle" :class="{ 'active': editForm.is_prime }" @click="editForm.is_prime = !editForm.is_prime"
                             style="width: 44px; height: 24px; background: var(--bg-surface); border-radius: 12px; position: relative; cursor: pointer; transition: background 0.2s;"
                             :style="editForm.is_prime ? 'background: var(--success);' : ''">
                            <div style="width: 20px; height: 20px; background: white; border-radius: 50%; position: absolute; top: 2px; transition: left 0.2s;"
                                 :style="editForm.is_prime ? 'left: 22px;' : 'left: 2px;'"></div>
                        </div>
                    </div>
                </div>

                <!-- Description -->
                <div style="font-weight: 600; font-size: 13px; color: var(--text-secondary); text-transform: uppercase; letter-spacing: 0.5px; margin: 20px 0 12px; padding-bottom: 6px; border-bottom: 1px solid var(--border);">
                    Description & Features
                </div>

                <div class="form-group" style="margin-bottom: 16px;">
                    <label class="form-label">Product Description</label>
                    <textarea class="input" x-model="editForm.description" rows="3" style="resize: vertical; font-size: 13px;" placeholder="Product description..."></textarea>
                </div>

                <div class="form-group" style="margin-bottom: 16px;">
                    <label class="form-label">
                        Feature Bullets
                        <span style="font-weight: 400; font-size: 11px; color: var(--text-muted);">(one per line)</span>
                    </label>
                    <textarea class="input"
                        x-model="editForm._featuresText"
                        x-init="$watch('editForm.features', val => { if(Array.isArray(val)) editForm._featuresText = val.join('\n'); }); if(Array.isArray(editForm.features)) editForm._featuresText = editForm.features.join('\n');"
                        @input="editForm.features = $el.value.split('\n').filter(f => f.trim())"
                        rows="4"
                        style="resize: vertical; font-size: 13px;"
                        placeholder="Feature 1&#10;Feature 2&#10;Feature 3"></textarea>
                    <div style="font-size: 11px; color: var(--text-muted); margin-top: 4px;">
                        <span x-text="Array.isArray(editForm.features) ? editForm.features.length : 0"></span> features
                    </div>
                </div>

                <!-- Images Gallery -->
                <div class="form-group">
                    <label class="form-label" style="display: flex; align-items: center; justify-content: space-between;">
                        <span>Images Gallery</span>
                        <span style="font-weight: 400; font-size: 11px; color: var(--text-muted);">
                            <span x-text="Array.isArray(editForm.images_gallery) ? editForm.images_gallery.length : 0"></span> images
                        </span>
                    </label>
                    <textarea class="input"
                        x-model="editForm._imagesText"
                        x-init="$watch('editForm.images_gallery', val => { if(Array.isArray(val)) editForm._imagesText = val.join('\n'); }); if(Array.isArray(editForm.images_gallery)) editForm._imagesText = editForm.images_gallery.join('\n');"
                        @input="editForm.images_gallery = $el.value.split('\n').filter(u => u.trim())"
                        rows="3"
                        style="resize: vertical; font-size: 11px; font-family: monospace;"
                        placeholder="https://m.media-amazon.com/images/I/xxx.jpg"></textarea>
                </div>
            </div>

            <!-- TAB 2: Custom Content Overrides -->
            <div x-show="editProductTab === 'custom'" x-transition:enter="transition ease-out duration-150" x-transition:enter-start="opacity-0" x-transition:enter-end="opacity-100">

                <!-- AI Status Banner -->
                <div style="margin-bottom: 16px; padding: 12px 16px; border-radius: var(--radius-md);"
                     :style="{
                         background: editForm.ai_status === 'generated' ? 'rgba(16, 185, 129, 0.1)' :
                                    (editForm.ai_status === 'queued' || editForm.ai_status === 'generating') ? 'rgba(59, 130, 246, 0.1)' :
                                    (editForm.ai_status === 'failed') ? 'rgba(239, 68, 68, 0.1)' : 'var(--bg-elevated)',
                         border: '1px solid ' + (editForm.ai_status === 'generated' ? 'var(--success)' :
                                                  (editForm.ai_status === 'queued' || editForm.ai_status === 'generating') ? 'var(--primary)' :
                                                  (editForm.ai_status === 'failed') ? 'var(--error)' : 'var(--border)')
                     }">
                    <div style="display: flex; align-items: center; gap: 12px;">
                        <i class="bi" :class="{
                            'bi-check-circle-fill': editForm.ai_status === 'generated',
                            'bi-hourglass-split': editForm.ai_status === 'queued',
                            'bi-arrow-repeat animate-spin': editForm.ai_status === 'generating',
                            'bi-x-circle-fill': editForm.ai_status === 'failed',
                            'bi-robot': !editForm.ai_status || editForm.ai_status === 'not_generated'
                        }" :style="{
                            color: editForm.ai_status === 'generated' ? 'var(--success)' :
                                   (editForm.ai_status === 'queued' || editForm.ai_status === 'generating') ? 'var(--primary)' :
                                   (editForm.ai_status === 'failed') ? 'var(--error)' : 'var(--text-muted)',
                            fontSize: '20px'
                        }"></i>
                        <div style="flex: 1;">
                            <div style="font-weight: 500;" x-text="
                                editForm.ai_status === 'generated' ? 'AI Content Generated' :
                                editForm.ai_status === 'queued' ? 'Queued for AI Generation' :
                                editForm.ai_status === 'generating' ? 'AI is Generating Content...' :
                                editForm.ai_status === 'failed' ? 'AI Generation Failed' :
                                'No AI Content Yet'
                            "></div>
                            <div style="font-size: 12px; color: var(--text-muted);">
                                <span x-show="editForm.ai_generated_at" x-text="'Generated: ' + editForm.ai_generated_at"></span>
                                <span x-show="editForm.ai_generation_id && editForm.ai_status === 'generated'" style="margin-left: 8px;">
                                    | ID: <a :href="'https://openrouter.ai/activity?generationId=' + editForm.ai_generation_id"
                                             target="_blank"
                                             style="color: var(--primary); text-decoration: none;"
                                             :title="editForm.ai_generation_id"
                                             x-text="(editForm.ai_generation_id || '').substring(0, 20) + '...'"></a>
                                </span>
                                <span x-show="editForm.ai_error_message && editForm.ai_status === 'failed'" x-text="editForm.ai_error_message" style="color: var(--error);"></span>
                                <span x-show="!editForm.ai_status || editForm.ai_status === 'not_generated'">Queue this product to generate AI-enhanced content</span>
                                <span x-show="editForm.ai_status === 'generating'" style="color: var(--warning);">If stuck, use actions below to reset</span>
                            </div>
                        </div>
                        <button class="btn btn-sm"
                                :class="editForm.ai_status === 'queued' || editForm.ai_status === 'generating' ? 'btn-secondary' : 'btn-primary'"
                                @click="queueForAi()"
                                :disabled="editForm.ai_status === 'queued' || editForm.ai_status === 'generating' || editForm.status !== 'scraped'">
                            <i class="bi" :class="editForm.ai_status === 'queued' || editForm.ai_status === 'generating' ? 'bi-hourglass' : 'bi-robot'"></i>
                            <span x-text="editForm.ai_status === 'queued' ? 'Queued' : (editForm.ai_status === 'generating' ? 'Generating...' : (editForm.ai_status === 'generated' ? 'Regenerate' : 'Queue for AI'))"></span>
                        </button>
                    </div>

                    <!-- Fallback Actions for stuck/failed states -->
                    <div x-show="editForm.ai_status === 'generating' || editForm.ai_status === 'failed' || editForm.ai_status === 'queued'"
                         style="margin-top: 12px; padding-top: 12px; border-top: 1px solid var(--border); display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
                        <span style="font-size: 12px; color: var(--text-muted); margin-right: 8px;">Actions:</span>

                        <!-- Re-queue (for generating/failed) -->
                        <button class="btn btn-xs btn-secondary"
                                x-show="editForm.ai_status === 'generating' || editForm.ai_status === 'failed'"
                                @click="resetAiStatus('queued')"
                                title="Re-queue for processing">
                            <i class="bi bi-arrow-clockwise"></i>
                            Re-queue
                        </button>

                        <!-- Force Regenerate Now (for stuck generating) -->
                        <button class="btn btn-xs btn-primary"
                                x-show="editForm.ai_status === 'generating'"
                                @click="queueForAi(true)"
                                title="Force regenerate immediately">
                            <i class="bi bi-lightning"></i>
                            Force Regenerate
                        </button>

                        <!-- Clear AI Status (reset to not_generated) -->
                        <button class="btn btn-xs btn-secondary"
                                @click="resetAiStatus('not_generated')"
                                title="Clear AI status and start fresh">
                            <i class="bi bi-x-lg"></i>
                            Clear Status
                        </button>

                        <!-- View generation on OpenRouter -->
                        <a x-show="editForm.ai_generation_id"
                           :href="'https://openrouter.ai/activity?generationId=' + editForm.ai_generation_id"
                           target="_blank"
                           class="btn btn-xs btn-secondary"
                           :title="'Generation ID: ' + editForm.ai_generation_id">
                            <i class="bi bi-box-arrow-up-right"></i>
                            <span x-text="(editForm.ai_generation_id || '').substring(0, 16) + '...'"></span>
                        </a>
                    </div>
                </div>

                <div x-show="editForm.status !== 'scraped'" style="margin-bottom: 16px; padding: 12px; background: rgba(234, 179, 8, 0.1); border: 1px solid var(--warning); border-radius: var(--radius-sm); font-size: 13px; color: var(--warning);">
                    <i class="bi bi-exclamation-triangle" style="margin-right: 6px;"></i>
                    Product must be scraped before AI content can be generated.
                </div>

                <div style="font-size: 13px; color: var(--text-muted); margin-bottom: 20px; padding: 12px; background: var(--bg-elevated); border-radius: var(--radius-sm); border-left: 3px solid var(--warning);">
                    <i class="bi bi-info-circle" style="margin-right: 6px; color: var(--warning);"></i>
                    Custom content will override scraped data when displaying product. Leave empty to use scraped data.
                </div>

                <div class="form-group" style="margin-bottom: 16px;">
                    <label class="form-label">
                        Custom Title
                        <span style="font-weight: 400; font-size: 11px; color: var(--text-muted);">(overrides scraped title)</span>
                    </label>
                    <input type="text" class="input" x-model="editForm.custom_title" placeholder="Leave empty to use scraped title">
                </div>

                <!-- Short Review (AI-generated or manual) -->
                <div class="form-group" style="margin-bottom: 16px;">
                    <label class="form-label">
                        <i class="bi bi-chat-quote" style="margin-right: 6px; color: var(--primary);"></i>
                        Short Review
                        <span style="font-weight: 400; font-size: 11px; color: var(--text-muted);">(brief product assessment, AI or manual)</span>
                    </label>
                    <textarea class="input" x-model="editForm.ai_short_review" rows="3" style="resize: vertical; font-size: 13px;"
                              placeholder="A brief 2-3 sentence assessment of the product..."></textarea>
                </div>

                <!-- Custom Features (AI-enhanced or manual) -->
                <div class="form-group" style="margin-bottom: 16px;">
                    <label class="form-label">
                        <i class="bi bi-list-check" style="margin-right: 6px; color: var(--primary);"></i>
                        Custom Features
                        <span style="font-weight: 400; font-size: 11px; color: var(--text-muted);">(enhanced features, one per line - overrides scraped)</span>
                    </label>
                    <textarea class="input"
                        x-model="editForm._customFeaturesText"
                        x-init="$watch('editForm.custom_features', val => { if(Array.isArray(val)) editForm._customFeaturesText = val.join('\n'); }); if(Array.isArray(editForm.custom_features)) editForm._customFeaturesText = editForm.custom_features.join('\n');"
                        @input="editForm.custom_features = $el.value.split('\n').filter(f => f.trim())"
                        rows="5"
                        style="resize: vertical; font-size: 13px;"
                        placeholder="Enhanced feature 1&#10;Enhanced feature 2&#10;Enhanced feature 3"></textarea>
                    <div style="font-size: 11px; color: var(--text-muted); margin-top: 4px;">
                        <span x-text="Array.isArray(editForm.custom_features) ? editForm.custom_features.length : 0"></span> features
                    </div>
                </div>

                <!-- Custom Description — hidden, not in use currently
                <div class="form-group" style="margin-bottom: 16px;">
                    <label class="form-label">
                        <i class="bi bi-file-text" style="margin-right: 6px; color: var(--primary);"></i>
                        Custom Description
                        <span style="font-weight: 400; font-size: 11px; color: var(--text-muted);">(overrides scraped description)</span>
                    </label>
                    <textarea class="input" x-model="editForm.custom_description" rows="5" style="resize: vertical; font-size: 13px;"
                              placeholder="Enhanced product description..."></textarea>
                </div>
                -->

                <!-- Custom Tabs -->
                <div style="font-weight: 600; font-size: 13px; color: var(--text-secondary); text-transform: uppercase; letter-spacing: 0.5px; margin: 20px 0 12px; padding-bottom: 6px; border-bottom: 1px solid var(--border);">
                    Custom Tabs
                    <span style="font-weight: 400; font-size: 11px; text-transform: none; color: var(--text-muted);">(optional content sections)</span>
                </div>

                <div style="margin-bottom: 20px;">
                    <!-- Tabs List -->
                    <template x-if="editForm.custom_tabs && editForm.custom_tabs.length > 0">
                        <div style="display: flex; flex-direction: column; gap: 12px; margin-bottom: 12px;">
                            <template x-for="(tab, index) in editForm.custom_tabs" :key="index">
                                <div style="padding: 12px; background: var(--bg-base); border: 1px solid var(--border); border-radius: 6px;">
                                    <div class="form-row" style="display: grid; grid-template-columns: 80px 1fr 38px; gap: 12px; align-items: stretch;">
                                        <!-- Icon -->
                                        <div class="form-group" style="margin: 0;">
                                            <input type="text" class="input" x-model="tab.icon" placeholder="bi-card-text" style="font-size: 12px; height: 100%;" title="Bootstrap Icon class">
                                        </div>
                                        <!-- Title -->
                                        <div class="form-group" style="margin: 0;">
                                            <input type="text" class="input" x-model="tab.title" placeholder="Tab Title" style="font-weight: 500;">
                                        </div>
                                        <!-- Delete Button -->
                                        <button type="button" class="tab-delete-btn" @click="editForm.custom_tabs.splice(index, 1)" title="Delete tab">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </div>
                                    <!-- Content with HTML Editor -->
                                    <div class="form-group" style="margin: 8px 0 0 0;">
                                        <div class="html-editor" x-data='{
                                            insertTag(tag) {
                                                const textarea = $el.querySelector("textarea");
                                                const start = textarea.selectionStart, end = textarea.selectionEnd;
                                                const selectedText = textarea.value.substring(start, end);
                                                let insertion = tag === "ul" || tag === "ol" ? `<${tag}>\n  <li>${selectedText || ""}</li>\n</${tag}>` : `<${tag}>${selectedText}</${tag}>`;
                                                tab.content = textarea.value.substring(0, start) + insertion + textarea.value.substring(end);
                                                $nextTick(() => { textarea.focus(); textarea.setSelectionRange(start + insertion.length, start + insertion.length); });
                                            },
                                            insertHeading(tag) {
                                                if (!tag) return;
                                                const textarea = $el.querySelector("textarea");
                                                const start = textarea.selectionStart, end = textarea.selectionEnd;
                                                const insertion = `<${tag}>${textarea.value.substring(start, end) || "Heading"}</${tag}>`;
                                                tab.content = textarea.value.substring(0, start) + insertion + textarea.value.substring(end);
                                                $nextTick(() => { textarea.focus(); textarea.setSelectionRange(start + insertion.length, start + insertion.length); });
                                            },
                                            insertLink() {
                                                const url = prompt("Enter URL:");
                                                if (!url) return;
                                                const textarea = $el.querySelector("textarea");
                                                const start = textarea.selectionStart, end = textarea.selectionEnd;
                                                const insertion = `<a href="${url}">${textarea.value.substring(start, end) || "Link text"}</a>`;
                                                tab.content = textarea.value.substring(0, start) + insertion + textarea.value.substring(end);
                                                $nextTick(() => { textarea.focus(); textarea.setSelectionRange(start + insertion.length, start + insertion.length); });
                                            }
                                        }'>
                                            <div class="html-editor-toolbar">
                                                <select class="toolbar-select" @change="insertHeading($event.target.value); $event.target.value = ''">
                                                    <option value="">Heading</option>
                                                    <option value="h2">H2</option>
                                                    <option value="h3">H3</option>
                                                    <option value="h4">H4</option>
                                                </select>
                                                <span class="toolbar-divider"></span>
                                                <button type="button" class="toolbar-btn" @click="insertTag('b')" title="Bold"><i class="bi bi-type-bold"></i></button>
                                                <button type="button" class="toolbar-btn" @click="insertTag('i')" title="Italic"><i class="bi bi-type-italic"></i></button>
                                                <span class="toolbar-divider"></span>
                                                <button type="button" class="toolbar-btn" @click="insertTag('ul')" title="List"><i class="bi bi-list-ul"></i></button>
                                                <button type="button" class="toolbar-btn" @click="insertTag('ol')" title="Numbered List"><i class="bi bi-list-ol"></i></button>
                                                <button type="button" class="toolbar-btn" @click="insertTag('blockquote')" title="Quote"><i class="bi bi-quote"></i></button>
                                                <span class="toolbar-divider"></span>
                                                <button type="button" class="toolbar-btn" @click="insertLink()" title="Link"><i class="bi bi-link-45deg"></i></button>
                                                <button type="button" class="toolbar-btn" @click="insertTag('p')" title="Paragraph"><i class="bi bi-paragraph"></i></button>
                                            </div>
                                            <textarea
                                                class="html-editor-area"
                                                x-model="tab.content"
                                                rows="8"
                                                placeholder="<p>Tab content here...</p>&#10;<h3>Subheading</h3>&#10;<ul>&#10;  <li>Point 1</li>&#10;  <li>Point 2</li>&#10;</ul>"></textarea>
                                        </div>
                                    </div>
                                </div>
                            </template>
                        </div>
                    </template>

                    <!-- Add Tab Button -->
                    <button type="button" class="btn btn-secondary" @click="editForm.custom_tabs = editForm.custom_tabs || []; editForm.custom_tabs.push({ title: '', content: '', icon: 'bi-card-text' })" style="width: 100%;">
                        <i class="bi bi-plus-lg"></i>
                        Add Custom Tab
                    </button>
                </div>

                <!-- SEO Categories -->
                <div style="font-weight: 600; font-size: 13px; color: var(--text-secondary); text-transform: uppercase; letter-spacing: 0.5px; margin: 20px 0 12px; padding-bottom: 6px; border-bottom: 1px solid var(--border);">
                    <i class="bi bi-diagram-3" style="margin-right: 6px;"></i>
                    SEO Categories
                    <span style="font-weight: 400; font-size: 11px; text-transform: none; color: var(--text-muted);">(link product to site categories)</span>
                </div>

                <!-- Custom Category Paths (for manual path assignment) -->
                <div class="form-group" style="margin-bottom: 16px;">
                    <label class="form-label" style="display: flex; align-items: center; gap: 8px;">
                        <i class="bi bi-folder-plus" style="color: var(--primary);"></i>
                        Custom Category Paths
                        <span style="font-weight: 400; font-size: 11px; color: var(--text-muted);">(one path per line, for AI or manual assignment)</span>
                    </label>
                    <textarea class="input"
                        x-model="editForm._customCategoryPathsText"
                        x-init="$watch('editForm.custom_category_paths', val => { if(Array.isArray(val)) editForm._customCategoryPathsText = val.join('\n'); }); if(Array.isArray(editForm.custom_category_paths)) editForm._customCategoryPathsText = editForm.custom_category_paths.join('\n');"
                        @input="editForm.custom_category_paths = $el.value.split('\n').filter(p => p.trim())"
                        rows="3"
                        style="resize: vertical; font-size: 13px;"
                        placeholder="Home & Kitchen > Kitchen & Dining > Coffee Makers&#10;Electronics > Small Appliances"></textarea>
                    <div style="font-size: 11px; color: var(--text-muted); margin-top: 4px; display: flex; align-items: center; gap: 8px;">
                        <span><span x-text="Array.isArray(editForm.custom_category_paths) ? editForm.custom_category_paths.length : 0"></span> paths</span>
                        <span x-show="editForm.cat_ai_generation_id" style="color: var(--primary);">
                            | <i class="bi bi-robot"></i> AI assigned
                        </span>
                    </div>
                </div>

                <!-- SEO Category IDs (linked via junction table) -->
                <div class="form-group" style="margin-bottom: 16px;">
                    <label class="form-label" style="display: flex; align-items: center; gap: 8px;">
                        <i class="bi bi-link-45deg" style="color: var(--success);"></i>
                        Linked Category IDs
                        <span style="font-weight: 400; font-size: 11px; color: var(--text-muted);">(comma-separated IDs from SEO Categories)</span>
                    </label>
                    <input type="text" class="input"
                        x-model="editForm.linked_category_ids"
                        placeholder="e.g., 12, 45, 78"
                        style="font-family: monospace;">
                    <div style="font-size: 11px; color: var(--text-muted); margin-top: 4px;">
                        <i class="bi bi-info-circle" style="margin-right: 4px;"></i>
                        These IDs link the product to SEO categories via the junction table.
                        <span x-show="editForm.linked_category_ids" style="color: var(--success); margin-left: 8px;">
                            <span x-text="(editForm.linked_category_ids || '').split(',').filter(id => id.trim()).length"></span> categories linked
                        </span>
                    </div>
                </div>

                <!-- Pros & Cons -->
                <div style="font-weight: 600; font-size: 13px; color: var(--text-secondary); text-transform: uppercase; letter-spacing: 0.5px; margin: 20px 0 12px; padding-bottom: 6px; border-bottom: 1px solid var(--border);">
                    Pros & Cons
                </div>

                <div class="form-row" style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                    <div class="form-group">
                        <label class="form-label" style="color: var(--success);">
                            <i class="bi bi-check-circle" style="margin-right: 4px;"></i>
                            Pros
                            <span style="font-weight: 400; font-size: 11px; color: var(--text-muted);">(one per line)</span>
                        </label>
                        <textarea class="input"
                            x-model="editForm._prosText"
                            x-init="$watch('editForm.custom_pros', val => { if(Array.isArray(val)) editForm._prosText = val.join('\n'); }); if(Array.isArray(editForm.custom_pros)) editForm._prosText = editForm.custom_pros.join('\n');"
                            @input="editForm.custom_pros = $el.value.split('\n').filter(f => f.trim())"
                            rows="5"
                            style="resize: vertical; font-size: 13px; border-color: var(--success);"
                            placeholder="Great battery life&#10;Excellent sound quality&#10;Comfortable fit"></textarea>
                    </div>
                    <div class="form-group">
                        <label class="form-label" style="color: var(--error);">
                            <i class="bi bi-x-circle" style="margin-right: 4px;"></i>
                            Cons
                            <span style="font-weight: 400; font-size: 11px; color: var(--text-muted);">(one per line)</span>
                        </label>
                        <textarea class="input"
                            x-model="editForm._consText"
                            x-init="$watch('editForm.custom_cons', val => { if(Array.isArray(val)) editForm._consText = val.join('\n'); }); if(Array.isArray(editForm.custom_cons)) editForm._consText = editForm.custom_cons.join('\n');"
                            @input="editForm.custom_cons = $el.value.split('\n').filter(f => f.trim())"
                            rows="5"
                            style="resize: vertical; font-size: 13px; border-color: var(--error);"
                            placeholder="Expensive&#10;No wireless charging&#10;Limited color options"></textarea>
                    </div>
                </div>
            </div>

            <!-- TAB 3: Affiliate Links -->
            <div x-show="editProductTab === 'links'" x-transition:enter="transition ease-out duration-150" x-transition:enter-start="opacity-0" x-transition:enter-end="opacity-100">

                <div style="font-size: 13px; color: var(--text-muted); margin-bottom: 20px; padding: 12px; background: var(--bg-elevated); border-radius: var(--radius-sm); border-left: 3px solid var(--primary);">
                    <i class="bi bi-info-circle" style="margin-right: 6px; color: var(--primary);"></i>
                    Add affiliate links from different retailers. The primary link will be used as the main CTA button.
                </div>

                <!-- Links List -->
                <div x-data="affiliateLinksManager()"
                     x-init="init()"
                     @edit-product.window="loadLinks($event.detail.id)">

                    <!-- Existing Links -->
                    <div style="display: flex; flex-direction: column; gap: 8px; margin-bottom: 16px;">
                        <template x-for="(link, index) in links" :key="link.id || index">
                            <div style="padding: 12px 16px; background: var(--bg-elevated); border: 1px solid var(--border); border-radius: var(--radius-md);"
                                 :style="link.is_primary ? 'border-color: var(--primary); background: rgba(59, 130, 246, 0.05);' : ''">

                                <!-- Single row with provider, URL, and actions all inline -->
                                <div style="display: flex; align-items: center; gap: 12px; justify-content: space-between;">

                                    <!-- Left: Provider name and badge -->
                                    <div style="display: flex; align-items: center; gap: 8px; flex-shrink: 0;">
                                        <span style="font-weight: 500; font-size: 14px;" x-text="link.provider_name"></span>
                                        <span class="badge badge-primary" x-show="link.is_primary" style="font-size: 10px;">Primary</span>
                                    </div>

                                    <!-- Center: URL (flexible, can shrink) -->
                                    <div style="flex: 1; min-width: 0; font-size: 12px; color: var(--text-muted); white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" x-text="link.affiliate_url"></div>

                                    <!-- Right: Action buttons -->
                                    <div style="display: flex; gap: 6px; align-items: center; flex-shrink: 0; padding-left: 12px; border-left: 1px solid var(--border);">
                                        <button class="btn-icon btn-icon-sm" @click="editLink(index)" title="Edit">
                                            <i class="bi bi-pencil"></i>
                                        </button>
                                        <button class="btn-icon btn-icon-sm" @click="setPrimary(index)" title="Set as Primary" x-show="!link.is_primary">
                                            <i class="bi bi-star"></i>
                                        </button>
                                        <button class="btn-icon btn-icon-sm" @click="removeLink(index)" title="Delete" style="color: var(--error);">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </template>

                        <!-- Empty State -->
                        <div x-show="links.length === 0" style="text-align: center; padding: 40px 24px; background: var(--bg-elevated); border: 1px dashed var(--border); border-radius: var(--radius-md); color: var(--text-muted);">
                            <i class="bi bi-link-45deg" style="font-size: 32px; opacity: 0.5;"></i>
                            <div style="margin-top: 12px; font-size: 14px;">No affiliate links yet</div>
                            <div style="margin-top: 4px; font-size: 12px;">Add links from different retailers to monetize this product</div>
                        </div>
                    </div>

                    <!-- Add New Link Form -->
                    <div x-show="showAddForm" x-transition style="padding: 16px; background: var(--bg-elevated); border: 1px solid var(--border); border-radius: var(--radius-md); margin-bottom: 16px;">
                        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px;">
                            <div style="font-weight: 500;" x-text="editingIndex >= 0 ? 'Edit Link' : 'Add New Link'"></div>
                            <button class="btn-icon btn-icon-sm" @click="cancelAddLink()">
                                <i class="bi bi-x"></i>
                            </button>
                        </div>

                        <div class="form-row" style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 12px;">
                            <div class="form-group">
                                <label class="form-label" style="font-size: 12px;">Provider</label>
                                <select class="input" x-model="newLink.provider" @change="updateProviderName()">
                                    <option value="">Select provider...</option>
                                    <template x-for="(name, slug) in providers" :key="slug">
                                        <option :value="slug" x-text="name"></option>
                                    </template>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label" style="font-size: 12px;">Display Name</label>
                                <input type="text" class="input" x-model="newLink.provider_name" placeholder="Provider name">
                            </div>
                        </div>

                        <div class="form-group" style="margin-bottom: 16px;">
                            <label class="form-label" style="font-size: 12px;">Affiliate URL</label>
                            <input type="url" class="input" x-model="newLink.affiliate_url" placeholder="https://...">
                        </div>

                        <div style="display: flex; align-items: center; gap: 12px;">
                            <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; font-size: 13px;">
                                <input type="checkbox" x-model="newLink.is_primary" style="width: 16px; height: 16px;">
                                <span>Set as primary link</span>
                            </label>
                            <div style="flex: 1;"></div>
                            <button class="btn btn-secondary btn-sm" @click="cancelAddLink()">Cancel</button>
                            <button class="btn btn-primary btn-sm" @click="saveLink()" :disabled="!newLink.provider || !newLink.affiliate_url">
                                <i class="bi bi-check"></i>
                                <span x-text="editingIndex >= 0 ? 'Update' : 'Add'"></span>
                            </button>
                        </div>
                    </div>

                    <!-- Add Button -->
                    <button class="btn btn-secondary" @click="showAddForm = true" x-show="!showAddForm" style="width: 100%;">
                        <i class="bi bi-plus-lg"></i>
                        Add Affiliate Link
                    </button>
                </div>
            </div>

        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" @click="showEditModal = false">Cancel</button>
            <button class="btn btn-primary" @click="saveProduct()">
                <i class="bi bi-floppy"></i>
                Save Changes
            </button>
        </div>
    </div>
</div>

<style>
.edit-product-tab {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 12px 20px;
    background: transparent;
    border: none;
    border-bottom: 2px solid transparent;
    color: var(--text-muted);
    font-size: 13px;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.15s ease;
}
.edit-product-tab:hover {
    color: var(--text-primary);
    background: var(--bg-elevated);
}
.edit-product-tab.active {
    color: var(--primary);
    border-bottom-color: var(--primary);
}
.edit-product-tab i {
    font-size: 14px;
}

/* HTML Editor Styles */
.html-editor {
    border: 1px solid var(--border);
    border-radius: 6px;
    overflow: hidden;
    background: var(--bg-secondary);
}

.html-editor-toolbar {
    display: flex;
    align-items: center;
    gap: 2px;
    padding: 6px 8px;
    background: var(--bg-surface);
    border-bottom: 1px solid var(--border);
}

.toolbar-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 28px;
    height: 28px;
    padding: 0;
    background: transparent;
    border: 1px solid transparent;
    border-radius: 4px;
    color: var(--text-secondary);
    cursor: pointer;
    transition: all 0.15s ease;
}

.toolbar-btn:hover {
    background: var(--bg-hover);
    color: var(--text-primary);
    border-color: var(--border);
}

.toolbar-btn:active {
    background: var(--bg-active);
}

.toolbar-btn i {
    font-size: 14px;
}

.toolbar-select {
    padding: 4px 8px;
    font-size: 12px;
    background: var(--bg-secondary);
    border: 1px solid var(--border);
    border-radius: 4px;
    color: var(--text-primary);
    cursor: pointer;
}

.toolbar-select:hover {
    background: var(--bg-hover);
}

.toolbar-divider {
    width: 1px;
    height: 20px;
    background: var(--border);
    margin: 0 4px;
}

.html-editor-area {
    width: 100%;
    min-height: 120px;
    padding: 12px;
    font-family: 'Monaco', 'Menlo', 'Consolas', monospace;
    font-size: 12px;
    line-height: 1.6;
    background: var(--bg-secondary);
    border: none;
    color: var(--text-primary);
    resize: vertical;
}

.html-editor-area:focus {
    outline: none;
    background: var(--bg-surface);
}

.html-editor-area::placeholder {
    color: var(--text-muted);
}

/* Custom Tab Delete Button */
.tab-delete-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 38px;
    padding: 0;
    background: transparent;
    border: 1px solid var(--border);
    border-radius: 6px;
    color: var(--error);
    cursor: pointer;
    transition: all 0.15s ease;
}

.tab-delete-btn:hover {
    background: var(--error);
    color: white;
    border-color: var(--error);
}

.tab-delete-btn i {
    font-size: 14px;
}

/* Extra small button variant */
.btn-xs {
    padding: 4px 10px;
    font-size: 11px;
    line-height: 1.4;
}

/* Spin animation for generating state */
.animate-spin {
    animation: spin 1s linear infinite;
}

@keyframes spin {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}
</style>

<script>
function affiliateLinksManager() {
    return {
        links: [],
        showAddForm: false,
        editingIndex: -1,
        productId: null,
        newLink: {
            provider: '',
            provider_name: '',
            affiliate_url: '',
            is_primary: false,
            sort_order: 0
        },
        providers: {
            amazon: 'Amazon',
            walmart: 'Walmart',
            bestbuy: 'Best Buy',
            target: 'Target',
            ebay: 'eBay',
            newegg: 'Newegg',
            costco: 'Costco',
            homedepot: 'Home Depot',
            lowes: "Lowe's",
            custom: 'Custom'
        },

        init() {
            // Will be loaded via event
        },

        async loadLinks(productId) {
            this.productId = productId;
            this.links = [];

            if (!productId) return;

            try {
                const response = await fetch(`${acmsConfig.restUrl}products/${productId}/links`, {
                    headers: { 'X-WP-Nonce': acmsConfig.nonce }
                });
                const data = await response.json();
                if (data.success) {
                    this.links = data.data || [];
                    // Dispatch event to update count in tab
                    window.dispatchEvent(new CustomEvent('affiliate-links-updated', {
                        detail: { count: this.links.length }
                    }));
                }
            } catch (error) {
            }
        },

        resetNewLink() {
            this.newLink = {
                provider: '',
                provider_name: '',
                affiliate_url: '',
                is_primary: false,
                sort_order: this.links.length
            };
            this.editingIndex = -1;
        },

        updateProviderName() {
            if (this.newLink.provider && this.providers[this.newLink.provider]) {
                this.newLink.provider_name = this.providers[this.newLink.provider];
            }
        },

        editLink(index) {
            const link = this.links[index];
            this.newLink = {
                provider: link.provider,
                provider_name: link.provider_name,
                affiliate_url: link.affiliate_url,
                is_primary: link.is_primary,
                sort_order: link.sort_order
            };
            this.editingIndex = index;
            this.showAddForm = true;
        },

        cancelAddLink() {
            this.showAddForm = false;
            this.resetNewLink();
        },

        async saveLink() {
            if (!this.newLink.provider || !this.newLink.affiliate_url) return;

            try {
                let url, method;
                if (this.editingIndex >= 0 && this.links[this.editingIndex].id) {
                    url = `${acmsConfig.restUrl}products/${this.productId}/links/${this.links[this.editingIndex].id}`;
                    method = 'PUT';
                } else {
                    url = `${acmsConfig.restUrl}products/${this.productId}/links`;
                    method = 'POST';
                }

                const response = await fetch(url, {
                    method: method,
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': acmsConfig.nonce
                    },
                    body: JSON.stringify(this.newLink)
                });

                const data = await response.json();

                if (data.success) {
                    await this.loadLinks(this.productId);
                    this.cancelAddLink();
                } else {
                    alert(data.message || 'Failed to save link');
                }
            } catch (error) {
                alert('Failed to save link');
            }
        },

        async removeLink(index) {
            const link = this.links[index];
            if (!link.id) {
                this.links.splice(index, 1);
                window.dispatchEvent(new CustomEvent('affiliate-links-updated', {
                    detail: { count: this.links.length }
                }));
                return;
            }

            if (!confirm('Delete this affiliate link?')) return;

            try {
                const response = await fetch(`${acmsConfig.restUrl}products/${this.productId}/links/${link.id}`, {
                    method: 'DELETE',
                    headers: { 'X-WP-Nonce': acmsConfig.nonce }
                });

                const data = await response.json();
                if (data.success) {
                    this.links.splice(index, 1);
                    window.dispatchEvent(new CustomEvent('affiliate-links-updated', {
                        detail: { count: this.links.length }
                    }));
                }
            } catch (error) {
            }
        },

        async setPrimary(index) {
            const link = this.links[index];
            if (!link.id) return;

            try {
                const response = await fetch(`${acmsConfig.restUrl}products/${this.productId}/links/${link.id}/primary`, {
                    method: 'PUT',
                    headers: { 'X-WP-Nonce': acmsConfig.nonce }
                });

                const data = await response.json();
                if (data.success) {
                    this.links = data.data || [];
                }
            } catch (error) {
            }
        }
    };
}
</script>
