<?php
/**
 * Background Processes Modal
 *
 * Shows AI jobs queue with real-time status.
 * Include this in any admin page that needs to display background process status.
 *
 * Usage: Include this file and add x-data to your Alpine.js root.
 *        Then add a button to toggle: @click="showAsProgressModal = true"
 *
 * @package AffiliateCMS\Pro
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<!-- Background Processes Modal -->
<div class="modal-backdrop" x-show="showAsProgressModal" x-cloak @click.self="showAsProgressModal = false"
     x-transition:enter="transition ease-out duration-200"
     x-transition:enter-start="opacity-0"
     x-transition:enter-end="opacity-100"
     x-transition:leave="transition ease-in duration-150"
     x-transition:leave-start="opacity-100"
     x-transition:leave-end="opacity-0">
    <div class="modal" @click.stop style="max-width: 600px;" x-data="asProgressModalContent()" x-init="init()">
        <div class="modal-header">
            <h2 class="modal-title">
                <i class="bi bi-lightning-charge"></i>
                Background Processes
            </h2>
            <div style="display: flex; align-items: center; gap: 8px;">
                <button class="btn btn-sm btn-secondary" @click="refresh()" :disabled="loading" title="Refresh">
                    <i class="bi" :class="loading ? 'bi-arrow-repeat animate-spin' : 'bi-arrow-clockwise'"></i>
                </button>
                <button class="btn-icon" @click="showAsProgressModal = false">
                    <i class="bi bi-x-lg"></i>
                </button>
            </div>
        </div>
        <div class="modal-body" style="max-height: 60vh; overflow-y: auto; padding: 16px;">
            <!-- Server Time -->
            <div style="text-align: center; margin-bottom: 16px; padding: 8px; background: var(--bg-subtle); border-radius: var(--radius-sm);">
                <span style="font-size: 11px; color: var(--text-muted);">Server Time:</span>
                <span style="font-size: 12px; font-weight: 500; margin-left: 4px;" x-text="serverTime"></span>
                <span style="font-size: 11px; color: var(--text-muted); margin-left: 8px;" x-show="autoRefresh">
                    <i class="bi bi-arrow-repeat animate-spin" style="font-size: 10px;"></i> Auto-refresh
                </span>
            </div>

            <!-- AI Jobs Section -->
            <div>
                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 10px;">
                    <h4 style="margin: 0; font-size: 13px; font-weight: 600;">
                        <i class="bi bi-robot" style="color: var(--accent);"></i>
                        AI Jobs Queue
                    </h4>
                    <span class="badge" style="font-size: 10px;" x-text="aiJobs.length + ' in queue'"></span>
                </div>

                <!-- No Jobs -->
                <div x-show="aiJobs.length === 0" style="text-align: center; padding: 20px; color: var(--text-muted);">
                    <i class="bi bi-check-circle" style="font-size: 24px; color: var(--success);"></i>
                    <p style="margin: 8px 0 0;">No pending jobs</p>
                </div>

                <!-- Jobs List -->
                <div x-show="aiJobs.length > 0" style="display: flex; flex-direction: column; gap: 6px;">
                    <template x-for="job in aiJobs" :key="job.id">
                        <div class="bg-job-item" :class="{ 'is-processing': job.status === 'processing' }">
                            <div class="bg-job-info">
                                <div class="bg-job-name">
                                    <span x-text="job.name"></span>
                                    <span class="bg-job-target" x-text="'(' + job.target + ')'"></span>
                                </div>
                            </div>
                            <div class="bg-job-status">
                                <template x-if="job.status === 'processing'">
                                    <span class="bg-status-running">
                                        <i class="bi bi-arrow-repeat animate-spin"></i> Processing
                                    </span>
                                </template>
                                <template x-if="job.status === 'pending'">
                                    <span class="bg-status-pending">
                                        <i class="bi bi-hourglass-split"></i> P<span x-text="job.priority"></span>
                                    </span>
                                </template>
                            </div>
                        </div>
                    </template>
                </div>
            </div>

            <!-- Auto-refresh toggle -->
            <div style="margin-top: 16px; padding-top: 12px; border-top: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between;">
                <label style="display: flex; align-items: center; gap: 8px; font-size: 12px; cursor: pointer;">
                    <input type="checkbox" x-model="autoRefresh" @change="toggleAutoRefresh()" style="width: 14px; height: 14px;">
                    Auto-refresh every 5s
                </label>
            </div>
        </div>
    </div>
</div>

<style>
.bg-job-item {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 8px 10px;
    background: var(--bg-subtle);
    border-radius: var(--radius-sm);
}
.bg-job-item.is-processing {
    background: rgba(139, 92, 246, 0.1);
}
.bg-job-name {
    font-size: 12px;
}
.bg-job-target {
    font-size: 10px;
    color: var(--text-muted);
    margin-left: 4px;
}
.bg-status-running {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    font-size: 11px;
    font-weight: 500;
    color: #3b82f6;
    background: rgba(59, 130, 246, 0.15);
    padding: 4px 8px;
    border-radius: 10px;
}
.bg-status-pending {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    font-size: 11px;
    color: var(--text-muted);
}
</style>

<script>
document.addEventListener('alpine:init', () => {
    Alpine.data('asProgressModalContent', () => ({
        loading: false,
        serverTime: '',
        aiJobs: [],
        autoRefresh: false,
        refreshInterval: null,

        async init() {
            await this.refresh();
        },

        async refresh() {
            this.loading = true;
            try {
                const nonce = (typeof acmsConfig !== 'undefined' ? acmsConfig.nonce : null)
                           || (typeof acmsCatConfig !== 'undefined' ? acmsCatConfig.nonce : null);
                if (!nonce) return;
                const response = await fetch('<?php echo esc_js(rest_url('acms-ai/v1/pending-actions')); ?>', {
                    headers: { 'X-WP-Nonce': nonce }
                });
                const result = await response.json();
                if (result.success) {
                    this.serverTime = result.server_time;
                    this.aiJobs = result.ai_jobs || [];
                }
            } catch (error) {
                console.error('Failed to load pending actions:', error);
            } finally {
                this.loading = false;
            }
        },

        toggleAutoRefresh() {
            if (this.autoRefresh) {
                this.refreshInterval = setInterval(() => {
                    this.refresh();
                }, 5000);
            } else {
                if (this.refreshInterval) {
                    clearInterval(this.refreshInterval);
                    this.refreshInterval = null;
                }
            }
        }
    }));
});
</script>
