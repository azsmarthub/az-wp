<?php
/**
 * Template Builder Modal - Generate shortcodes for product display
 *
 * @package AffiliateCMS\Pro
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<!-- Template Builder Modal -->
<div class="modal-backdrop" x-show="showTemplateBuilder" x-cloak
     x-init="$watch('showTemplateBuilder', value => { if(value && selectedCount === 0) { scEditMode = true; } })">
    <div class="modal shortcode-modal" @click.stop>
        <div class="modal-header">
            <h2 class="modal-title">
                <i class="bi bi-code-square" style="margin-right: 8px; color: var(--primary);"></i>
                Template Builder
            </h2>
            <button class="btn-icon btn-icon-sm" @click="showTemplateBuilder = false">
                <i class="bi bi-x-lg"></i>
            </button>
        </div>
        <div class="modal-body">
            <!-- ASINs Input -->
            <div class="sc-section">
                <div class="sc-section-header">
                    <i class="bi bi-upc-scan"></i>
                    <span>ASINs</span>
                    <span class="sc-count" x-text="scSelectedAsins.length"></span>
                </div>
                <div class="sc-asins-box">
                    <div class="sc-asins-content" x-show="!scEditMode && scSelectedAsins.length > 0">
                        <code x-text="scSelectedAsins.join(', ')"></code>
                    </div>
                    <textarea
                        x-show="scEditMode || scSelectedAsins.length === 0"
                        class="sc-asins-textarea"
                        x-model="scCustomAsins"
                        placeholder="Enter ASINs separated by commas or spaces (e.g., B09V3KXJPB, B0BDJF9M23)..."
                        rows="2"
                    ></textarea>
                    <button
                        type="button"
                        class="sc-asins-action"
                        x-show="selectedCount > 0"
                        @click="if(!scEditMode) { scEnableEdit(); } scEditMode = !scEditMode"
                        :title="scEditMode ? 'Done editing' : 'Edit ASINs'"
                    >
                        <i class="bi" :class="scEditMode ? 'bi-check-lg' : 'bi-pencil'"></i>
                    </button>
                </div>
            </div>

            <?php /* Template Selection - HIDDEN: Only List template available */ ?>

            <!-- Badge Configuration -->
            <div class="sc-section">
                <div class="sc-section-header">
                    <i class="bi bi-award"></i>
                    <span>Badges</span>
                    <span class="sc-optional">Optional</span>
                </div>
                <div class="sc-badges-container">
                    <div class="sc-quick-badges">
                        <template x-for="badge in scQuickBadges" :key="badge.name">
                            <button
                                type="button"
                                class="sc-badge-btn"
                                :class="{ 'active': scBadges.includes(badge.name) }"
                                @click="scToggleBadge(badge.name)"
                            >
                                <i class="bi" :class="badge.icon"></i>
                                <span x-text="badge.name"></span>
                            </button>
                        </template>
                    </div>
                    <div class="sc-active-badges" x-show="scBadges.length > 0">
                        <template x-for="badge in scBadges" :key="badge">
                            <span class="sc-active-badge">
                                <span x-text="badge"></span>
                                <button type="button" @click="scRemoveBadge(badge)">
                                    <i class="bi bi-x"></i>
                                </button>
                            </span>
                        </template>
                    </div>
                </div>
            </div>

            <?php /* Responsive Columns (Grid only) - DISABLED: Grid template not available */ ?>

            <!-- Display Options -->
            <div class="sc-section">
                <div class="sc-section-header">
                    <i class="bi bi-toggles"></i>
                    <span>Display Options</span>
                </div>
                <div class="sc-options-grid">
                    <label class="sc-toggle-option">
                        <span>Show Price</span>
                        <div class="toggle" :class="{ 'active': scOptions.show_price }" @click="scOptions.show_price = !scOptions.show_price"></div>
                    </label>
                    <label class="sc-toggle-option">
                        <span>Show Rating</span>
                        <div class="toggle" :class="{ 'active': scOptions.show_rating }" @click="scOptions.show_rating = !scOptions.show_rating"></div>
                    </label>
                    <label class="sc-toggle-option">
                        <span>Show Image</span>
                        <div class="toggle" :class="{ 'active': scOptions.show_image }" @click="scOptions.show_image = !scOptions.show_image"></div>
                    </label>
                    <label class="sc-toggle-option">
                        <span>Show Prime Badge</span>
                        <div class="toggle" :class="{ 'active': scOptions.show_prime }" @click="scOptions.show_prime = !scOptions.show_prime"></div>
                    </label>
                </div>
                <div class="sc-button-text">
                    <label>Button Text</label>
                    <input type="text" class="input" x-model="scOptions.button_text" placeholder="Buy on Amazon">
                </div>
            </div>

            <!-- Generated Template -->
            <div class="sc-section sc-output-section">
                <div class="sc-section-header">
                    <i class="bi bi-code-slash"></i>
                    <span>Generated Shortcode</span>
                </div>
                <div class="sc-output-wrapper">
                    <textarea class="sc-output" readonly x-text="scGeneratedShortcode"></textarea>
                    <button
                        type="button"
                        class="sc-copy-btn"
                        :class="{ 'copied': scCopied }"
                        @click="scCopyShortcode()"
                        :disabled="scSelectedAsins.length === 0"
                    >
                        <i class="bi" :class="scCopied ? 'bi-check-lg' : 'bi-clipboard'"></i>
                    </button>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" @click="showTemplateBuilder = false">Close</button>
            <button class="btn btn-primary" @click="scCopyShortcode(); showTemplateBuilder = false" :disabled="scSelectedAsins.length === 0">
                <i class="bi bi-clipboard-check"></i>
                Copy & Close
            </button>
        </div>
    </div>
</div>
