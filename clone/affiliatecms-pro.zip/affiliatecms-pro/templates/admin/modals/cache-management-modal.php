<?php
/**
 * Cache Management Modal
 *
 * Status dashboard + actions + settings for Nginx FastCGI Cache.
 * Uses Alpine.js component pattern consistent with cron-settings-modal.php.
 *
 * @package AffiliateCMS\Pro
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<!-- Cache Management Modal -->
<div class="modal-backdrop" x-show="showCacheModal" x-cloak @click.self="showCacheModal = false"
     x-transition:enter="transition ease-out duration-200"
     x-transition:enter-start="opacity-0"
     x-transition:enter-end="opacity-100"
     x-transition:leave="transition ease-in duration-150"
     x-transition:leave-start="opacity-100"
     x-transition:leave-end="opacity-0">
    <div class="modal modal-lg" @click.stop x-data="cacheManagementModal()" x-init="init()" style="max-width: 720px;">
        <div class="modal-header">
            <h2 class="modal-title">
                <i class="bi bi-hdd-stack"></i>
                Cache Management
            </h2>
            <button class="btn-icon" @click="showCacheModal = false">
                <i class="bi bi-x-lg"></i>
            </button>
        </div>
        <div class="modal-body" style="max-height: 75vh; overflow-y: auto;">

            <!-- ============================================
                 CACHE STATUS
                 ============================================ -->
            <div style="margin-bottom: 20px; padding: 14px; background: var(--bg-base); border: 1px solid var(--border); border-radius: var(--radius-md);">
                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 14px;">
                    <span style="font-weight: 600; font-size: 13px; color: var(--text-primary);">
                        <i class="bi bi-activity" style="color: var(--primary);"></i> Cache Status
                    </span>
                    <button type="button" class="btn btn-sm btn-secondary" @click="refreshStatus()" :disabled="isRefreshing" style="padding: 4px 8px; font-size: 11px;">
                        <i class="bi" :class="isRefreshing ? 'bi-arrow-repeat animate-spin' : 'bi-arrow-clockwise'"></i>
                    </button>
                </div>

                <!-- Stats Grid -->
                <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 16px;">
                    <!-- Cached / Total -->
                    <div style="text-align: center; padding: 12px; background: var(--bg-surface); border-radius: var(--radius-sm);">
                        <div style="font-size: 22px; font-weight: 700; color: var(--success);">
                            <span x-text="(status.cache_files || 0).toLocaleString()"></span>
                            <span style="font-size: 13px; font-weight: 400; color: var(--text-muted);" x-show="status.total_urls"> / <span x-text="(status.total_urls || 0).toLocaleString()"></span></span>
                        </div>
                        <div style="font-size: 11px; color: var(--text-muted); margin-top: 2px;">Cached Pages</div>
                    </div>
                    <!-- Disk Size -->
                    <div style="text-align: center; padding: 12px; background: var(--bg-surface); border-radius: var(--radius-sm);">
                        <div style="font-size: 22px; font-weight: 700; color: var(--primary);" x-text="status.cache_size || '0 B'"></div>
                        <div style="font-size: 11px; color: var(--text-muted); margin-top: 2px;">Disk Size</div>
                    </div>
                    <!-- Batch Size -->
                    <div style="text-align: center; padding: 12px; background: var(--bg-surface); border-radius: var(--radius-sm);">
                        <div style="font-size: 22px; font-weight: 700; color: var(--text-primary);" x-text="status.settings?.batch_size || 150"></div>
                        <div style="font-size: 11px; color: var(--text-muted); margin-top: 2px;">URLs/Chunk</div>
                    </div>
                </div>

                <!-- Cache Path -->
                <div x-show="status.cache_path" style="margin-top: 12px; padding: 8px 10px; background: var(--bg-surface); border-radius: var(--radius-sm); font-family: monospace; font-size: 11px; color: var(--text-muted);">
                    <i class="bi bi-folder2" style="margin-right: 4px;"></i> <span x-text="status.cache_path"></span>
                </div>

                <!-- Last Preload Result -->
                <div x-show="status.last_preload" style="margin-top: 12px; padding-top: 12px; border-top: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <span style="font-size: 11px; color: var(--text-muted);">Last preload:</span>
                        <span style="font-size: 12px; color: var(--success); font-weight: 500;" x-text="(status.last_preload?.urls_preloaded || 0).toLocaleString() + ' / ' + (status.last_preload?.urls_total || 0).toLocaleString() + ' URLs'"></span>
                    </div>
                    <span style="font-size: 11px; color: var(--text-muted);" x-text="status.last_preload?.timestamp || ''"></span>
                </div>
            </div>

            <!-- ============================================
                 PRELOAD PROGRESS (conditional)
                 ============================================ -->
            <div x-show="status.in_progress" x-transition
                 style="margin-bottom: 20px; padding: 14px; background: var(--bg-base); border: 1px solid var(--warning); border-radius: var(--radius-md);">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                    <span style="font-size: 13px; font-weight: 500; color: var(--warning);">
                        <i class="bi bi-arrow-repeat animate-spin"></i> Preload In Progress
                    </span>
                    <span style="font-size: 11px; color: var(--text-muted);" x-text="'Started: ' + (status.progress?.started || '')"></span>
                </div>
                <!-- Progress Bar -->
                <div style="height: 6px; background: var(--bg-surface); border-radius: 3px; overflow: hidden; margin-bottom: 8px;">
                    <div style="height: 100%; background: var(--success); border-radius: 3px; transition: width 0.3s ease;" :style="'width: ' + progressPercent + '%'"></div>
                </div>
                <div style="display: flex; justify-content: space-between; font-size: 12px; color: var(--text-secondary);">
                    <span x-text="(status.progress?.preloaded || 0).toLocaleString() + ' / ' + (status.progress?.total || 0).toLocaleString() + ' URLs'"></span>
                    <span x-text="progressPercent + '%'" style="font-weight: 500;"></span>
                </div>
                <!-- CPU / Batch / Chunk / Delay -->
                <div style="display: flex; gap: 16px; margin-top: 8px; font-size: 11px; color: var(--text-muted);">
                    <span x-show="status.progress?.cpu !== null" x-text="'CPU: ' + (status.progress?.cpu || 0) + '%'" :style="(status.progress?.cpu || 0) > 80 ? 'color: var(--danger)' : ''"></span>
                    <span x-show="status.progress?.batch_size" x-text="'Batch: ' + (status.progress?.batch_size || '?')"></span>
                    <span x-show="status.progress?.chunk_size" x-text="'Chunk: ' + (status.progress?.chunk_size || '?')"></span>
                    <span x-show="status.progress?.delay_ms !== null" x-text="'Delay: ' + (status.progress?.delay_ms || 0) + 'ms'"></span>
                </div>
            </div>

            <!-- ============================================
                 ACTION BUTTONS
                 ============================================ -->
            <div style="display: flex; gap: 8px; margin-bottom: 20px; flex-wrap: wrap;">
                <button class="btn btn-primary" @click="smartRefresh()" :disabled="actionRunning">
                    <i class="bi" :class="actionRunning === 'refresh' ? 'bi-arrow-repeat animate-spin' : 'bi-arrow-clockwise'"></i>
                    Smart Refresh
                </button>
                <button class="btn btn-secondary" @click="resumeQueue()" :disabled="actionRunning">
                    <i class="bi" :class="actionRunning === 'resume' ? 'bi-arrow-repeat animate-spin' : 'bi-play-circle'"></i>
                    Resume Queue
                </button>
                <button class="btn btn-secondary" @click="cleanOrphans()" :disabled="actionRunning">
                    <i class="bi" :class="actionRunning === 'orphans' ? 'bi-arrow-repeat animate-spin' : 'bi-eraser'"></i>
                    Clean Orphans
                </button>
                <button class="btn btn-secondary" @click="preloadFull()" :disabled="actionRunning">
                    <i class="bi" :class="actionRunning === 'full' ? 'bi-arrow-repeat animate-spin' : 'bi-globe2'"></i>
                    Full Preload
                </button>
                <button class="btn btn-secondary" style="color: var(--error); border-color: var(--error);" @click="purgeAll()" :disabled="actionRunning">
                    <i class="bi" :class="actionRunning === 'purge' ? 'bi-arrow-repeat animate-spin' : 'bi-trash3'"></i>
                    Purge Cache
                </button>
                <button class="btn btn-secondary" style="color: var(--warning); border-color: var(--warning);" @click="flushRedis()" :disabled="actionRunning">
                    <i class="bi" :class="actionRunning === 'redis' ? 'bi-arrow-repeat animate-spin' : 'bi-database-x'"></i>
                    Flush Redis
                </button>
                <!-- Stop preload (only when in progress) -->
                <button class="btn btn-secondary" x-show="status.in_progress" style="color: var(--text-muted); border-color: var(--border);" @click="stopPreload()" :disabled="actionRunning === 'stop'">
                    <i class="bi" :class="actionRunning === 'stop' ? 'bi-arrow-repeat animate-spin' : 'bi-stop-circle'"></i>
                    Stop
                </button>
            </div>

            <!-- ============================================
                 SETTINGS ACCORDION
                 ============================================ -->
            <div class="automation-accordion">
                <div class="accordion-section" :class="{ 'is-expanded': settingsExpanded }">
                    <button type="button" class="accordion-trigger" @click="settingsExpanded = !settingsExpanded">
                        <div class="accordion-trigger-content">
                            <i class="bi bi-gear accordion-icon"></i>
                            <div class="accordion-trigger-text">
                                <span class="accordion-title">Cache Settings</span>
                                <span class="accordion-desc">Batch size per chunk</span>
                            </div>
                        </div>
                        <i class="bi bi-chevron-down accordion-arrow"></i>
                    </button>
                    <div class="accordion-content" x-show="settingsExpanded" x-collapse>
                        <div class="accordion-body" style="display: flex; flex-direction: column; gap: 16px; padding-top: 8px;">
                            <!-- Batch Size -->
                            <div class="form-group">
                                <label class="form-label">Batch Size (URLs per chunk)</label>
                                <input type="number" class="input" x-model.number="settings.cache_batch_size" min="10" max="100" step="10" style="max-width: 160px;">
                                <div style="font-size: 11px; color: var(--text-muted); margin-top: 4px;">
                                    10–100 URLs per chunk. Higher = faster but more CPU. Default: 30
                                </div>
                            </div>
                            <!-- Save -->
                            <div>
                                <button class="btn btn-primary btn-sm" @click="saveSettings()" :disabled="isSaving">
                                    <i class="bi" :class="isSaving ? 'bi-arrow-repeat animate-spin' : 'bi-check-lg'"></i>
                                    Save Settings
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" @click="showCacheModal = false">Close</button>
        </div>
    </div>
</div>

<script>
document.addEventListener('alpine:init', () => {
    Alpine.data('cacheManagementModal', () => ({
        isRefreshing: false,
        actionRunning: null, // null | 'priority' | 'full' | 'purge' | 'stop'
        isSaving: false,
        settingsExpanded: false,
        pollInterval: null,

        status: {
            cache_files: 0,
            cache_size: '0 B',
            cache_size_raw: 0,
            cache_path: '',
            total_urls: 0,
            in_progress: false,
            progress: null,
            last_preload: null,
            settings: { batch_size: 150 }
        },

        settings: {
            cache_batch_size: 150
        },

        get progressPercent() {
            if (!this.status.progress || !this.status.progress.total) return 0;
            return Math.round((this.status.progress.preloaded / this.status.progress.total) * 100);
        },

        init() {
            this.loadStatus();
            this.loadSettings();

            // Watch in_progress for auto-polling
            this.$watch('status.in_progress', (val) => {
                if (val) {
                    this.startPolling();
                } else {
                    this.stopPolling();
                }
            });
        },

        async loadStatus() {
            try {
                const response = await fetch(acmsConfig.restUrl + 'cache/status', {
                    headers: { 'X-WP-Nonce': acmsConfig.nonce }
                });
                const data = await response.json();
                if (data.success) {
                    this.status = data;
                    // Sync settings from status if available
                    if (data.settings) {
                        this.settings.cache_batch_size = data.settings.batch_size || 150;
                    }
                }
            } catch (e) {
                console.error('[CacheModal] loadStatus error:', e);
            }
        },

        async refreshStatus() {
            this.isRefreshing = true;
            await this.loadStatus();
            this.isRefreshing = false;
        },

        async loadSettings() {
            try {
                const response = await fetch(acmsConfig.restUrl + 'settings', {
                    headers: { 'X-WP-Nonce': acmsConfig.nonce }
                });
                const result = await response.json();
                if (result.success && result.data?.general) {
                    const g = result.data.general;
                    this.settings.cache_batch_size = g.cache_batch_size || 150;
                }
            } catch (e) {
                console.error('[CacheModal] loadSettings error:', e);
            }
        },

        async smartRefresh() {
            this.actionRunning = 'refresh';
            try {
                const response = await fetch(acmsConfig.restUrl + 'cache/smart-refresh', {
                    method: 'POST',
                    headers: { 'X-WP-Nonce': acmsConfig.nonce }
                });
                const result = await response.json();
                window.dispatchEvent(new CustomEvent('show-toast', {
                    detail: {
                        type: 'success',
                        title: 'Smart Refresh',
                        message: `${result.queued || 0} URLs queued for refresh`
                    }
                }));
                await this.loadStatus();
            } catch (e) {
                window.dispatchEvent(new CustomEvent('show-toast', {
                    detail: { type: 'error', title: 'Error', message: 'Failed to start Smart Refresh' }
                }));
            } finally {
                this.actionRunning = null;
            }
        },

        async resumeQueue() {
            this.actionRunning = 'resume';
            try {
                const response = await fetch(acmsConfig.restUrl + 'cache/resume-queue', {
                    method: 'POST',
                    headers: { 'X-WP-Nonce': acmsConfig.nonce }
                });
                const result = await response.json();
                window.dispatchEvent(new CustomEvent('show-toast', {
                    detail: {
                        type: result.resumed ? 'success' : 'info',
                        title: 'Resume Queue',
                        message: result.message
                    }
                }));
                await this.loadStatus();
            } catch (e) {
                window.dispatchEvent(new CustomEvent('show-toast', {
                    detail: { type: 'error', title: 'Error', message: 'Failed to resume queue' }
                }));
            } finally {
                this.actionRunning = null;
            }
        },

        async cleanOrphans() {
            this.actionRunning = 'orphans';
            try {
                const response = await fetch(acmsConfig.restUrl + 'cache/clean-orphans', {
                    method: 'POST',
                    headers: { 'X-WP-Nonce': acmsConfig.nonce }
                });
                const result = await response.json();
                window.dispatchEvent(new CustomEvent('show-toast', {
                    detail: {
                        type: 'success',
                        title: 'Clean Orphans',
                        message: result.message
                    }
                }));
                await this.loadStatus();
            } catch (e) {
                window.dispatchEvent(new CustomEvent('show-toast', {
                    detail: { type: 'error', title: 'Error', message: 'Failed to clean orphans' }
                }));
            } finally {
                this.actionRunning = null;
            }
        },

        async preloadFull() {
            this.actionRunning = 'full';
            try {
                const response = await fetch(acmsConfig.restUrl + 'cache/preload', {
                    method: 'POST',
                    headers: { 'X-WP-Nonce': acmsConfig.nonce }
                });
                const result = await response.json();
                window.dispatchEvent(new CustomEvent('show-toast', {
                    detail: {
                        type: 'success',
                        title: 'Full Preload',
                        message: result.message || 'Scheduled in background'
                    }
                }));
                // Start polling to track progress
                setTimeout(() => this.loadStatus(), 3000);
            } catch (e) {
                window.dispatchEvent(new CustomEvent('show-toast', {
                    detail: { type: 'error', title: 'Error', message: 'Failed to schedule full preload' }
                }));
            } finally {
                this.actionRunning = null;
            }
        },

        async purgeAll() {
            if (!confirm('This will purge ALL cached pages and start a fresh preload. Continue?')) {
                return;
            }
            this.actionRunning = 'purge';
            try {
                const response = await fetch(acmsConfig.restUrl + 'cache/purge-all', {
                    method: 'POST',
                    headers: { 'X-WP-Nonce': acmsConfig.nonce }
                });
                const result = await response.json();
                const preloaded = result.preload?.urls_preloaded || 0;
                window.dispatchEvent(new CustomEvent('show-toast', {
                    detail: {
                        type: 'success',
                        title: 'Cache Purged',
                        message: `All cache cleared. ${preloaded} priority pages re-warmed.`
                    }
                }));
                await this.loadStatus();
            } catch (e) {
                window.dispatchEvent(new CustomEvent('show-toast', {
                    detail: { type: 'error', title: 'Error', message: 'Failed to purge cache' }
                }));
            } finally {
                this.actionRunning = null;
            }
        },

        async stopPreload() {
            if (!confirm('Stop the running preload? Already cached pages will remain.')) {
                return;
            }
            this.actionRunning = 'stop';
            try {
                const response = await fetch(acmsConfig.restUrl + 'cache/stop', {
                    method: 'POST',
                    headers: { 'X-WP-Nonce': acmsConfig.nonce }
                });
                const result = await response.json();
                window.dispatchEvent(new CustomEvent('show-toast', {
                    detail: {
                        type: 'success',
                        title: 'Stopped',
                        message: result.message || 'Preload stopped'
                    }
                }));
                await this.loadStatus();
            } catch (e) {
                window.dispatchEvent(new CustomEvent('show-toast', {
                    detail: { type: 'error', title: 'Error', message: 'Failed to stop preload' }
                }));
            } finally {
                this.actionRunning = null;
            }
        },

        async flushRedis() {
            if (!confirm('Flush Redis object cache? This will clear all cached database queries.')) {
                return;
            }
            this.actionRunning = 'redis';
            try {
                const response = await fetch(acmsConfig.restUrl + 'cache/flush-redis', {
                    method: 'POST',
                    headers: { 'X-WP-Nonce': acmsConfig.nonce }
                });
                const result = await response.json();
                window.dispatchEvent(new CustomEvent('show-toast', {
                    detail: {
                        type: result.success ? 'success' : 'error',
                        title: result.success ? 'Flushed' : 'Error',
                        message: result.message || 'Redis flushed'
                    }
                }));
            } catch (e) {
                window.dispatchEvent(new CustomEvent('show-toast', {
                    detail: { type: 'error', title: 'Error', message: 'Failed to flush Redis' }
                }));
            } finally {
                this.actionRunning = null;
            }
        },

        async saveSettings() {
            this.isSaving = true;
            try {
                const response = await fetch(acmsConfig.restUrl + 'settings', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': acmsConfig.nonce
                    },
                    body: JSON.stringify({
                        general: {
                            cache_batch_size: this.settings.cache_batch_size
                        }
                    })
                });
                const result = await response.json();
                if (result.success) {
                    window.dispatchEvent(new CustomEvent('show-toast', {
                        detail: { type: 'success', title: 'Saved', message: 'Cache settings updated' }
                    }));
                } else {
                    window.dispatchEvent(new CustomEvent('show-toast', {
                        detail: { type: 'error', title: 'Error', message: result.message || 'Save failed' }
                    }));
                }
            } catch (e) {
                window.dispatchEvent(new CustomEvent('show-toast', {
                    detail: { type: 'error', title: 'Error', message: 'Failed to save settings' }
                }));
            } finally {
                this.isSaving = false;
            }
        },

        startPolling() {
            if (this.pollInterval) return;
            this.pollInterval = setInterval(() => this.loadStatus(), 5000);
        },

        stopPolling() {
            if (this.pollInterval) {
                clearInterval(this.pollInterval);
                this.pollInterval = null;
            }
        }
    }));
});
</script>
