<?php
/**
 * Processing Log Modal
 *
 * Displays detailed processing log for queue items
 *
 * @package AffiliateCMS\Pro
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<!-- Processing Log Modal -->
<div class="modal-backdrop" x-show="showLogModal" x-cloak
     x-transition:enter="transition ease-out duration-200"
     x-transition:enter-start="opacity-0"
     x-transition:enter-end="opacity-100"
     x-transition:leave="transition ease-in duration-150"
     x-transition:leave-start="opacity-100"
     x-transition:leave-end="opacity-0"
     @keydown.escape.window="showLogModal = false"
     @close-log-modal.window="showLogModal = false">

    <div class="modal modal-lg processing-log-modal" x-data="processingLogModal()"
         @open-log-modal.window="loadLog($event.detail.id, $event.detail.keyword)"
         x-transition:enter="transition ease-out duration-200"
         x-transition:enter-start="opacity-0 transform scale-95"
         x-transition:enter-end="opacity-100 transform scale-100"
         x-transition:leave="transition ease-in duration-150"
         x-transition:leave-start="opacity-100 transform scale-100"
         x-transition:leave-end="opacity-0 transform scale-95">

        <!-- Modal Header -->
        <div class="modal-header">
            <div class="modal-title-group">
                <h3 class="modal-title">
                    <i class="bi bi-terminal"></i>
                    Processing Log
                </h3>
                <span class="modal-subtitle" x-show="logData.keyword" x-text="logData.keyword"></span>
            </div>
            <div class="modal-header-actions">
                <!-- Status Badge -->
                <span class="badge" :class="'badge-' + getStatusColor(logData.status)" x-show="logData.status">
                    <span x-text="logData.status"></span>
                </span>
                <button type="button" class="modal-close" @click="$dispatch('close-log-modal')">
                    <i class="bi bi-x-lg"></i>
                </button>
            </div>
        </div>

        <!-- Modal Body -->
        <div class="modal-body">
            <!-- Loading State -->
            <div class="log-loading" x-show="isLoading">
                <i class="bi bi-arrow-clockwise animate-spin"></i>
                <span>Loading log...</span>
            </div>

            <!-- No Log State -->
            <div class="log-empty" x-show="!isLoading && (!logData.steps || logData.steps.length === 0)">
                <i class="bi bi-journal-x"></i>
                <span>No processing log available</span>
                <small>This item hasn't been processed yet</small>
            </div>

            <!-- Log Content -->
            <div class="log-content" x-show="!isLoading && logData.steps && logData.steps.length > 0">
                <!-- Progress Overview -->
                <div class="log-progress" x-show="logData.progress">
                    <div class="progress-bar-container">
                        <div class="progress-bar" :style="'width: ' + (logData.progress?.current / logData.progress?.total * 100) + '%'"></div>
                    </div>
                    <span class="progress-text" x-text="'Step ' + logData.progress?.current + ' of ' + logData.progress?.total"></span>
                </div>

                <!-- Meta Info -->
                <div class="log-meta">
                    <div class="log-meta-item" x-show="logData.attempts">
                        <i class="bi bi-arrow-repeat"></i>
                        <span>Attempts: <strong x-text="logData.attempts"></strong></span>
                    </div>
                    <div class="log-meta-item" x-show="logData.started_at">
                        <i class="bi bi-play-circle"></i>
                        <span>Started: <strong x-text="formatDateTime(logData.started_at)"></strong></span>
                    </div>
                    <div class="log-meta-item" x-show="logData.completed_at">
                        <i class="bi bi-check-circle"></i>
                        <span>Completed: <strong x-text="formatDateTime(logData.completed_at)"></strong></span>
                    </div>
                </div>

                <!-- Error Message -->
                <div class="log-error-banner" x-show="logData.error_message">
                    <i class="bi bi-exclamation-triangle"></i>
                    <span x-text="logData.error_message"></span>
                </div>

                <!-- Steps Timeline -->
                <div class="log-timeline">
                    <template x-for="(step, index) in logData.steps" :key="index">
                        <div class="log-step" :class="getStepClass(step)">
                            <div class="step-indicator">
                                <i class="bi" :class="getStepIcon(step)"></i>
                            </div>
                            <div class="step-content">
                                <div class="step-header">
                                    <span class="step-name" x-text="formatStepName(step.step)"></span>
                                    <span class="step-time" x-text="formatTime(step.timestamp)"></span>
                                </div>
                                <div class="step-message" x-text="step.message"></div>
                                <div class="step-data" x-show="step.data && Object.keys(step.data).length > 0">
                                    <template x-for="(value, key) in step.data" :key="key">
                                        <div class="step-data-item">
                                            <span class="data-key" x-text="key + ':'"></span>
                                            <span class="data-value" x-text="formatDataValue(value)"></span>
                                        </div>
                                    </template>
                                </div>
                            </div>
                        </div>
                    </template>
                </div>

                <!-- Errors Section -->
                <div class="log-errors" x-show="logData.errors && logData.errors.length > 0">
                    <h4 class="errors-title">
                        <i class="bi bi-exclamation-circle"></i>
                        Errors (<span x-text="logData.errors?.length || 0"></span>)
                    </h4>
                    <template x-for="(error, index) in logData.errors" :key="index">
                        <div class="error-item">
                            <div class="error-header">
                                <span class="error-step" x-text="formatStepName(error.step)"></span>
                                <span class="error-time" x-text="formatTime(error.timestamp)"></span>
                            </div>
                            <div class="error-message" x-text="error.message"></div>
                        </div>
                    </template>
                </div>
            </div>
        </div>

        <!-- Modal Footer -->
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" @click="copyLogToClipboard()" :disabled="!logData.steps || logData.steps.length === 0">
                <i class="bi bi-clipboard"></i>
                Copy Log
            </button>
            <div class="footer-actions">
                <button type="button" class="btn btn-secondary" @click="refreshLog()" :disabled="isLoading">
                    <i class="bi" :class="isLoading ? 'bi-arrow-clockwise animate-spin' : 'bi-arrow-clockwise'"></i>
                    Refresh
                </button>
                <button type="button" class="btn btn-primary" @click="$dispatch('close-log-modal')">
                    Close
                </button>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('alpine:init', () => {
    Alpine.data('processingLogModal', () => ({
        isLoading: false,
        itemId: null,
        logData: {
            id: null,
            keyword: '',
            status: '',
            attempts: 0,
            error_message: null,
            started_at: null,
            completed_at: null,
            steps: [],
            errors: [],
            progress: null
        },

        async loadLog(itemId, keyword = '') {
            if (!itemId) return;

            this.itemId = itemId;
            this.logData.keyword = keyword;
            this.isLoading = true;

            try {
                const response = await fetch(`${acmsConfig.restUrl}queue/${itemId}/log`, {
                    headers: { 'X-WP-Nonce': acmsConfig.nonce }
                });

                const result = await response.json();

                if (result.success) {
                    this.logData = result.data;
                }
            } catch (error) {
            } finally {
                this.isLoading = false;
            }
        },

        refreshLog() {
            if (this.itemId) {
                this.loadLog(this.itemId);
            }
        },

        getStatusColor(status) {
            const colors = {
                pending: 'primary',
                processing: 'info',
                completed: 'success',
                failed: 'error',
                paused: 'secondary'
            };
            return colors[status] || 'secondary';
        },

        getStepClass(step) {
            if (step.data?.success === false) return 'step-error';
            if (step.step === 'finalize') return 'step-success';
            return '';
        },

        getStepIcon(step) {
            const icons = {
                init: 'bi-play-circle',
                search_asins: 'bi-search',
                scrape_products: 'bi-download',
                select_products: 'bi-check2-square',
                generate_content: 'bi-pencil-square',
                create_post: 'bi-file-earmark-plus',
                finalize: 'bi-check-circle-fill',
                failure: 'bi-x-circle',
                exception: 'bi-exclamation-triangle'
            };
            return icons[step.step] || 'bi-circle';
        },

        formatStepName(step) {
            const names = {
                init: 'Initialize',
                search_asins: 'Search ASINs',
                scrape_products: 'Scrape Products',
                select_products: 'Select Products',
                generate_content: 'Generate Content',
                create_post: 'Create Post',
                finalize: 'Finalize',
                failure: 'Failure',
                exception: 'Exception'
            };
            return names[step] || step;
        },

        formatTime(timestamp) {
            if (!timestamp) return '';
            const d = new Date(timestamp.replace(' ', 'T'));
            return d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        },

        formatDateTime(timestamp) {
            if (!timestamp) return '';
            const d = new Date(timestamp.replace(' ', 'T'));
            return d.toLocaleString('en-US', {
                month: 'short',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
        },

        formatDataValue(value) {
            if (value === null || value === undefined) return 'null';
            if (typeof value === 'boolean') return value ? 'true' : 'false';
            if (Array.isArray(value)) {
                if (value.length <= 3) return value.join(', ');
                return value.slice(0, 3).join(', ') + ` (+${value.length - 3} more)`;
            }
            if (typeof value === 'object') return JSON.stringify(value);
            return String(value);
        },

        async copyLogToClipboard() {
            if (!this.logData.steps || this.logData.steps.length === 0) return;

            let logText = `Processing Log - ${this.logData.keyword}\n`;
            logText += `Status: ${this.logData.status}\n`;
            logText += `Attempts: ${this.logData.attempts}\n`;
            logText += `---\n\n`;

            this.logData.steps.forEach(step => {
                logText += `[${step.timestamp}] ${this.formatStepName(step.step)}\n`;
                logText += `  ${step.message}\n`;
                if (step.data && Object.keys(step.data).length > 0) {
                    Object.entries(step.data).forEach(([key, value]) => {
                        logText += `  - ${key}: ${this.formatDataValue(value)}\n`;
                    });
                }
                logText += `\n`;
            });

            if (this.logData.errors && this.logData.errors.length > 0) {
                logText += `---\nErrors:\n`;
                this.logData.errors.forEach(error => {
                    logText += `[${error.timestamp}] ${this.formatStepName(error.step)}: ${error.message}\n`;
                });
            }

            try {
                await navigator.clipboard.writeText(logText);
                window.dispatchEvent(new CustomEvent('show-toast', {
                    detail: { type: 'success', title: 'Copied', message: 'Log copied to clipboard' }
                }));
            } catch (err) {
            }
        }
    }));
});
</script>

<style>
.processing-log-modal {
    max-width: 700px;
    max-height: 85vh;
    display: flex;
    flex-direction: column;
}

.processing-log-modal .modal-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    flex-shrink: 0;
}

.modal-title-group {
    display: flex;
    flex-direction: column;
    gap: 4px;
}

.modal-subtitle {
    font-size: 13px;
    color: var(--text-muted);
    font-weight: 400;
}

.modal-header-actions {
    display: flex;
    align-items: center;
    gap: 12px;
}

.processing-log-modal .modal-close {
    position: relative;
    top: 0;
    right: 0;
    width: 32px;
    height: 32px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: transparent;
    border: none;
    border-radius: 6px;
    color: var(--text-muted);
    cursor: pointer;
    transition: all 0.15s ease;
}

.processing-log-modal .modal-close:hover {
    background: var(--bg-hover);
    color: var(--text-primary);
}

.processing-log-modal .modal-body {
    flex: 1;
    overflow-y: auto;
    padding: 0;
}

.processing-log-modal .modal-footer {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-shrink: 0;
    border-top: 1px solid var(--border);
    padding: 16px 20px;
}

.footer-actions {
    display: flex;
    gap: 8px;
}

/* Loading & Empty States */
.log-loading,
.log-empty {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 60px 20px;
    color: var(--text-muted);
    gap: 12px;
}

.log-loading i,
.log-empty i {
    font-size: 32px;
    opacity: 0.5;
}

.log-empty small {
    font-size: 12px;
    opacity: 0.7;
}

/* Log Content */
.log-content {
    padding: 20px;
}

/* Progress Bar */
.log-progress {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 16px;
}

.progress-bar-container {
    flex: 1;
    height: 6px;
    background: var(--bg-secondary);
    border-radius: 3px;
    overflow: hidden;
}

.progress-bar {
    height: 100%;
    background: var(--primary);
    border-radius: 3px;
    transition: width 0.3s ease;
}

.progress-text {
    font-size: 12px;
    color: var(--text-muted);
    white-space: nowrap;
}

/* Meta Info */
.log-meta {
    display: flex;
    flex-wrap: wrap;
    gap: 16px;
    padding: 12px 16px;
    background: var(--bg-secondary);
    border-radius: 8px;
    margin-bottom: 16px;
}

.log-meta-item {
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 13px;
    color: var(--text-secondary);
}

.log-meta-item i {
    font-size: 14px;
    opacity: 0.7;
}

.log-meta-item strong {
    color: var(--text-primary);
}

/* Error Banner */
.log-error-banner {
    display: flex;
    align-items: flex-start;
    gap: 10px;
    padding: 12px 16px;
    background: rgba(239, 68, 68, 0.1);
    border: 1px solid rgba(239, 68, 68, 0.2);
    border-radius: 8px;
    margin-bottom: 16px;
    color: #ef4444;
    font-size: 13px;
}

.log-error-banner i {
    margin-top: 2px;
}

/* Timeline */
.log-timeline {
    position: relative;
    padding-left: 24px;
}

.log-timeline::before {
    content: '';
    position: absolute;
    left: 11px;
    top: 0;
    bottom: 0;
    width: 2px;
    background: var(--border);
}

.log-step {
    position: relative;
    padding-bottom: 20px;
}

.log-step:last-child {
    padding-bottom: 0;
}

.step-indicator {
    position: absolute;
    left: -24px;
    top: 0;
    width: 24px;
    height: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: var(--bg-primary);
    border: 2px solid var(--border);
    border-radius: 50%;
    z-index: 1;
}

.step-indicator i {
    font-size: 12px;
    color: var(--text-muted);
}

.log-step.step-success .step-indicator {
    border-color: var(--success);
    background: rgba(16, 185, 129, 0.1);
}

.log-step.step-success .step-indicator i {
    color: var(--success);
}

.log-step.step-error .step-indicator {
    border-color: #ef4444;
    background: rgba(239, 68, 68, 0.1);
}

.log-step.step-error .step-indicator i {
    color: #ef4444;
}

.step-content {
    padding-left: 12px;
}

.step-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 4px;
}

.step-name {
    font-weight: 600;
    font-size: 13px;
    color: var(--text-primary);
}

.step-time {
    font-size: 11px;
    color: var(--text-muted);
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
}

.step-message {
    font-size: 13px;
    color: var(--text-secondary);
    margin-bottom: 6px;
}

.step-data {
    display: flex;
    flex-direction: column;
    gap: 2px;
    padding: 8px 10px;
    background: var(--bg-secondary);
    border-radius: 6px;
    font-size: 12px;
}

.step-data-item {
    display: flex;
    gap: 6px;
}

.data-key {
    color: var(--text-muted);
    flex-shrink: 0;
}

.data-value {
    color: var(--text-primary);
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    word-break: break-all;
}

/* Errors Section */
.log-errors {
    margin-top: 20px;
    padding-top: 20px;
    border-top: 1px solid var(--border);
}

.errors-title {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 14px;
    font-weight: 600;
    color: #ef4444;
    margin-bottom: 12px;
}

.errors-title i {
    font-size: 16px;
}

.error-item {
    padding: 10px 12px;
    background: rgba(239, 68, 68, 0.05);
    border: 1px solid rgba(239, 68, 68, 0.1);
    border-radius: 6px;
    margin-bottom: 8px;
}

.error-item:last-child {
    margin-bottom: 0;
}

.error-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 4px;
}

.error-step {
    font-size: 12px;
    font-weight: 600;
    color: #ef4444;
}

.error-time {
    font-size: 11px;
    color: var(--text-muted);
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
}

.error-message {
    font-size: 13px;
    color: var(--text-secondary);
}
</style>
