<?php
/**
 * SEO Brand Page Template
 *
 * Displays brand information and products - with sidebar layout
 *
 * @package AffiliateCMS\Pro
 */

defined('ABSPATH') || exit;

// Get brand from global (set in Bootstrap::handleBrandTemplate)
$brand = $GLOBALS['acms_current_brand'] ?? null;

if (!$brand) {
    wp_safe_redirect(home_url('/'));
    exit;
}

// Get affiliate link settings (same resolution as Shortcodes.php)
$acms_general = get_option('acms_general_settings', []);
$affiliate_tag = !empty($acms_general['affiliate_tag']) ? $acms_general['affiliate_tag'] : '';
if (!$affiliate_tag) {
    $affiliate_tag = get_option('acms_paapi_partner_tag', '');
}
if (!$affiliate_tag) {
    $affiliate_tag = get_option('acms_affiliate_tag', '');
}
$custom_url_params = !empty($acms_general['custom_url_params']) ? ltrim($acms_general['custom_url_params'], '&') : 'linkCode=ogi&th=1&psc=1';

// Get products for this brand (ASINs for shortcode + full data for schema)
global $wpdb;
$products_table = $wpdb->prefix . 'acms_products';

$products = $wpdb->get_results(
    $wpdb->prepare(
        "SELECT asin, title, custom_title, image_url, price, original_price, rating, reviews_count
        FROM {$products_table}
        WHERE brand = %s AND status IN ('scraped', 'processing', 'scheduled')
        ORDER BY rating DESC, reviews_count DESC
        LIMIT 50",
        $brand['name']
    )
);

// Get ASINs for shortcode
$product_asins = array_map(function($p) { return $p->asin; }, $products);

// Parse FAQ if JSON
$faq_items = [];
if (!empty($brand['content_faq'])) {
    $faq_data = is_string($brand['content_faq'])
        ? json_decode($brand['content_faq'], true)
        : $brand['content_faq'];
    if (is_array($faq_data)) {
        $faq_items = $faq_data;
    }
}

// SEO title and description
// Fixed format: "SiteName: {Brand} Reviews of {year}"
$page_title = get_bloginfo('name') . ': ' . $brand['name'] . ' Reviews of ' . date('Y');
$page_description = !empty($brand['seo_description']) ? $brand['seo_description'] : ($brand['description'] ?: "Discover the best {$brand['name']} products with reviews, ratings and deals.");

// Theme header
get_header();
?>

<main id="content" class="acms-brand-page">

    <!-- Hero Section -->
    <section class="acms-brand-hero">
        <div class="container">

            <!-- Breadcrumb -->
            <nav class="breadcrumb acms-brand-hero__breadcrumb" aria-label="<?php esc_attr_e('Breadcrumb', 'affiliatecms-pro'); ?>">
                <ol class="breadcrumb__list">
                    <li class="breadcrumb__item">
                        <a href="<?php echo esc_url(home_url('/')); ?>" class="breadcrumb__link">
                            <i class="bi bi-house-fill"></i>
                            <span><?php esc_html_e('Home', 'affiliatecms-pro'); ?></span>
                        </a>
                        <span class="breadcrumb__separator"><i class="bi bi-chevron-right"></i></span>
                    </li>
                    <li class="breadcrumb__item">
                        <span class="breadcrumb__current"><?php echo esc_html($brand['name']); ?></span>
                    </li>
                </ol>
            </nav>

            <!-- Brand Header -->
            <div class="acms-brand-hero__header">
                <h1 class="acms-brand-hero__title"><?php echo esc_html($brand['name']); ?></h1>
                <?php if (!empty($brand['description'])): ?>
                <p class="acms-brand-hero__description"><?php echo esc_html($brand['description']); ?></p>
                <?php endif; ?>
            </div>

            <!-- Stats -->
            <div class="acms-brand-hero__stats">
                <span class="acms-brand-hero__stat">
                    <i class="bi bi-box-seam"></i>
                    <?php printf(
                        esc_html(_n('%d product', '%d products', (int) $brand['product_count'], 'affiliatecms-pro')),
                        (int) $brand['product_count']
                    ); ?>
                </span>
                <?php if (!empty($brand['website_url'])): ?>
                <a href="<?php echo esc_url($brand['website_url']); ?>" class="acms-brand-hero__stat acms-brand-hero__stat--link" target="_blank" rel="nofollow">
                    <i class="bi bi-globe"></i>
                    <?php esc_html_e('Official Website', 'affiliatecms-pro'); ?>
                    <i class="bi bi-box-arrow-up-right" style="font-size:12px;"></i>
                </a>
                <?php endif; ?>
                <?php if (!empty($brand['updated_at'])): ?>
                <span class="acms-brand-hero__stat">
                    <i class="bi bi-clock"></i>
                    <?php printf(
                        esc_html__('Updated %s', 'affiliatecms-pro'),
                        date_i18n(get_option('date_format'), strtotime($brand['updated_at']))
                    ); ?>
                </span>
                <?php endif; ?>
            </div>

        </div>
    </section>

    <!-- Main Content with Sidebar -->
    <section class="acms-brand-content">
        <div class="container">
            <div class="acms-brand-layout">

                <!-- Main Column (Left) -->
                <div class="acms-brand-main">

                    <!-- Products List (using acms_list shortcode) -->
                    <?php if (!empty($product_asins)): ?>
                        <h2 class="acms-brand-section-title" style="margin-bottom: var(--space-4);">
                            <i class="bi bi-list-ul"></i>
                            <?php printf(esc_html__('%s Products', 'affiliatecms-pro'), esc_html($brand['name'])); ?>
                            <span style="font-weight: normal; font-size: var(--text-sm); color: var(--color-text-muted); margin-left: var(--space-2);">
                                (<?php echo count($product_asins); ?>)
                            </span>
                        </h2>
                        <?php echo do_shortcode('[acms_list asin="' . esc_attr(implode(',', $product_asins)) . '" numbered="true" max_width="100%" show_badges="false"]'); ?>
                    <?php else: ?>
                    <div class="acms-brand-empty">
                        <i class="bi bi-inbox"></i>
                        <p><?php esc_html_e('No products found for this brand yet.', 'affiliatecms-pro'); ?></p>
                    </div>
                    <?php endif; ?>

                    <!-- Brand Guide (AI Content) -->
                    <?php if (!empty($brand['content_main'])): ?>
                    <div class="acms-brand-guide" x-data="{ expanded: false }">
                        <h2 class="acms-brand-section-title" style="margin-bottom: var(--space-4);">
                            <i class="bi bi-file-text"></i>
                            <?php printf(esc_html__('%s Brand Guide', 'affiliatecms-pro'), esc_html($brand['name'])); ?>
                        </h2>
                        <div class="acms-brand-guide__content" :class="{ 'is-expanded': expanded }">
                            <div class="prose">
                                <?php echo wp_kses_post($brand['content_main']); ?>
                            </div>
                            <div class="acms-brand-guide__fade" x-show="!expanded"></div>
                        </div>
                        <button type="button" class="acms-brand-guide__toggle" @click="expanded = !expanded">
                            <span x-text="expanded ? '<?php echo esc_js(__('Show less', 'affiliatecms-pro')); ?>' : '<?php echo esc_js(__('Read full guide', 'affiliatecms-pro')); ?>'"></span>
                            <i class="bi" :class="expanded ? 'bi-chevron-up' : 'bi-chevron-down'"></i>
                        </button>
                    </div>
                    <?php endif; ?>

                    <!-- FAQ -->
                    <?php if (!empty($faq_items)): ?>
                    <div class="acms-brand-faq-section">
                        <h2 class="acms-brand-section-title" style="margin-bottom: var(--space-4);">
                            <i class="bi bi-question-circle"></i>
                            <?php esc_html_e('Frequently Asked Questions', 'affiliatecms-pro'); ?>
                        </h2>
                        <div class="acms-brand-faq" x-data="{ openItem: 0 }">
                            <?php foreach ($faq_items as $index => $faq): ?>
                            <div class="acms-brand-faq__item" itemscope itemprop="mainEntity" itemtype="https://schema.org/Question">
                                <button type="button" class="acms-brand-faq__question" @click="openItem = openItem === <?php echo $index; ?> ? null : <?php echo $index; ?>" :class="{ 'is-open': openItem === <?php echo $index; ?> }">
                                    <span itemprop="name"><?php echo esc_html($faq['question'] ?? ''); ?></span>
                                    <i class="bi" :class="openItem === <?php echo $index; ?> ? 'bi-chevron-up' : 'bi-chevron-down'"></i>
                                </button>
                                <div class="acms-brand-faq__answer" itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer" x-show="openItem === <?php echo $index; ?>" x-transition x-cloak>
                                    <div itemprop="text">
                                        <?php echo wp_kses_post($faq['answer'] ?? ''); ?>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>

                </div>

                <!-- Sidebar (Right) -->
                <aside class="acms-brand-sidebar">

                    <!-- Brand Info Card -->
                    <div class="acms-brand-sidebar__card">
                        <h3 class="acms-brand-sidebar__title">
                            <i class="bi bi-building"></i>
                            <?php esc_html_e('About', 'affiliatecms-pro'); ?> <?php echo esc_html($brand['name']); ?>
                        </h3>

                        <?php if (!empty($brand['logo_url'])): ?>
                        <div class="acms-brand-sidebar__logo">
                            <img src="<?php echo esc_url($brand['logo_url']); ?>" alt="<?php echo esc_attr($brand['name']); ?>">
                        </div>
                        <?php endif; ?>

                        <?php if (!empty($brand['description'])): ?>
                        <p class="acms-brand-sidebar__desc"><?php echo esc_html($brand['description']); ?></p>
                        <?php endif; ?>

                        <ul class="acms-brand-sidebar__stats">
                            <li>
                                <i class="bi bi-box-seam"></i>
                                <span><?php echo (int) $brand['product_count']; ?> <?php esc_html_e('Products', 'affiliatecms-pro'); ?></span>
                            </li>
                            <?php if (!empty($brand['website_url'])): ?>
                            <li>
                                <a href="<?php echo esc_url($brand['website_url']); ?>" target="_blank" rel="nofollow">
                                    <i class="bi bi-globe"></i>
                                    <span><?php esc_html_e('Official Website', 'affiliatecms-pro'); ?></span>
                                    <i class="bi bi-box-arrow-up-right" style="font-size: 10px;"></i>
                                </a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </div>

                </aside>

            </div>
        </div>
    </section>

</main>

<?php
// ========================================
// JSON-LD Structured Data (SEO)
// ========================================
$site_name = get_bloginfo('name');
$site_url = home_url('/');
$brand_url = home_url('/brand/' . $brand['slug'] . '/');
$brand_image = !empty($brand['logo_url']) ? $brand['logo_url'] : get_template_directory_uri() . '/assets/images/placeholder.svg';

// BreadcrumbList Schema
$breadcrumb_items = [
    [
        '@type' => 'ListItem',
        'position' => 1,
        'name' => __('Home', 'affiliatecms-pro'),
        'item' => $site_url,
    ],
    [
        '@type' => 'ListItem',
        'position' => 2,
        'name' => $brand['name'],
        'item' => $brand_url,
    ]
];

// ItemList Schema (Product listing)
$item_list_elements = [];
foreach ($products as $idx => $p) {
    $product_schema = [
        '@type' => 'Product',
        'position' => $idx + 1,
        'name' => !empty($p->custom_title) ? $p->custom_title : $p->title,
        'url' => $brand_url . '#' . $p->asin,
        'brand' => [
            '@type' => 'Brand',
            'name' => $brand['name'],
        ],
        'offers' => [
            '@type' => 'Offer',
            'price' => (float) ($p->price ?? 0),
            'priceCurrency' => 'USD',
            'availability' => 'https://schema.org/InStock',
            'url' => 'https://www.amazon.com/dp/' . $p->asin . '?tag=' . urlencode($affiliate_tag) . ($custom_url_params ? '&' . $custom_url_params : ''),
        ],
    ];

    if (!empty($p->image_url)) {
        $product_schema['image'] = $p->image_url;
    }

    /* Amazon rating Schema.org removed — violates policy
    if (!empty($p->rating) && !empty($p->reviews_count)) {
        $product_schema['aggregateRating'] = [
            '@type' => 'AggregateRating',
            'ratingValue' => (float) $p->rating,
            'bestRating' => 5,
            'reviewCount' => (int) $p->reviews_count,
        ];
    }
    */

    $item_list_elements[] = [
        '@type' => 'ListItem',
        'position' => $idx + 1,
        'item' => $product_schema,
    ];
}

// FAQPage Schema
$faq_schema = [];
if (!empty($faq_items)) {
    foreach ($faq_items as $faq) {
        $faq_schema[] = [
            '@type' => 'Question',
            'name' => $faq['question'] ?? '',
            'acceptedAnswer' => [
                '@type' => 'Answer',
                'text' => $faq['answer'] ?? '',
            ],
        ];
    }
}

// Combined JSON-LD
$json_ld = [
    '@context' => 'https://schema.org',
    '@graph' => [
        // BreadcrumbList
        [
            '@type' => 'BreadcrumbList',
            'itemListElement' => $breadcrumb_items,
        ],
        // Brand
        [
            '@type' => 'Brand',
            'name' => $brand['name'],
            'url' => $brand_url,
            'logo' => $brand_image,
            'description' => $page_description,
        ],
        // CollectionPage
        [
            '@type' => 'CollectionPage',
            'name' => $page_title,
            'description' => $page_description,
            'url' => $brand_url,
            'image' => $brand_image,
            'isPartOf' => [
                '@type' => 'WebSite',
                'name' => $site_name,
                'url' => $site_url,
            ],
            'mainEntity' => [
                '@type' => 'ItemList',
                'name' => sprintf(__('Best %s Products', 'affiliatecms-pro'), $brand['name']),
                'numberOfItems' => count($products),
                'itemListElement' => $item_list_elements,
            ],
        ],
    ],
];

// Add FAQPage if FAQ exists
if (!empty($faq_schema)) {
    $json_ld['@graph'][] = [
        '@type' => 'FAQPage',
        'mainEntity' => $faq_schema,
    ];
}
?>
<script type="application/ld+json">
<?php echo wp_json_encode($json_ld, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>
</script>

<?php
// Theme footer
get_footer();
?>
