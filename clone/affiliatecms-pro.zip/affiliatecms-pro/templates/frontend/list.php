<?php
/**
 * ACMS List Template
 *
 * Ranked list layout with horizontal cards
 * Row 1: Product info (image, title, price, action)
 * Row 2: Expandable details (description, pros/cons, features) - full width
 *
 * @var array $products Array of product data
 * @var array $atts Shortcode attributes
 */

declare(strict_types=1);

// Defaults
$maxWidth = isset($atts['max_width']) ? $atts['max_width'] : '900px';
$numbered = $atts['numbered'] !== 'false';
$customClass = $atts['class'] ?? '';
$showBadges = $atts['show_badges'] === 'true';

// Display settings
$showPrice = ($atts['show_price'] ?? 'true') === 'true';
$showRating = ($atts['show_rating'] ?? 'true') === 'true';
$showPrime = ($atts['show_prime'] ?? 'true') === 'true';
$showStock = ($atts['show_stock'] ?? 'true') === 'true';
$showImage = ($atts['show_image'] ?? 'true') === 'true';
$ratingDisplayType = $atts['rating_display_type'] ?? 'score';

// Build style attribute
$styles = [];
if ($maxWidth) {
    $styles[] = "max-width: {$maxWidth}";
}
$styleAttr = !empty($styles) ? 'style="' . esc_attr(implode('; ', $styles)) . '"' : '';

// Badge types for rotation
$badgeTypes = ['danger', 'success', 'warning', 'info'];
$badgeLabels = [
    'danger' => __('Best Seller', 'affiliatecms-pro'),
    'success' => __("Editor's Pick", 'affiliatecms-pro'),
    'warning' => __('Limited Time', 'affiliatecms-pro'),
    'info' => __('Top Rated', 'affiliatecms-pro'),
];

// Unique ID for this instance
$instanceId = uniqid('acms-list-');
?>

<!-- ACMS Product List -->
<div class="acms-list <?php echo esc_attr($customClass); ?>" id="<?php echo esc_attr($instanceId); ?>" <?php echo $styleAttr; ?>>
    <?php foreach ($products as $index => $product) :
        $asin = $product['asin'] ?? '';
        $title = $product['title'] ?? '';
        $brand = $product['brand'] ?? '';
        $priceFormatted = $product['price_formatted'] ?? '';
        $originalPriceFormatted = $product['original_price_formatted'] ?? '';
        $discountPercent = $product['discount_percent'] ?? 0;
        $savingsFormatted = $product['savings_formatted'] ?? '';
        $rating = $product['rating'] ?? 0;
        $score = $product['score'] ?? 0;
        $scoreFormatted = $product['score_formatted'] ?? '0.0';
        $reviewsFormatted = $product['reviews_formatted'] ?? '0';
        $inStock = $product['in_stock'] ?? true;
        $isPrime = $product['is_prime'] ?? false;
        $imageUrl = $product['image_url'] ?? '';
        $affiliateUrl = $product['affiliate_url'] ?? '#';
        $linkRel = $product['link_rel'] ?? 'nofollow';
        $lastUpdated = $product['last_updated'] ?? '';
        $lastUpdatedDetailed = $product['last_updated_detailed'] ?? '';
        $buttonText = $product['button_text'] ?? __('Buy on Amazon', 'affiliatecms-pro');
        $affiliateLinks = $product['affiliate_links'] ?? [];

        // Expand/collapse data - prioritize custom content
        $description = $product['description'] ?? '';
        $features = $product['features'] ?? [];
        $pros = $product['pros'] ?? [];
        $cons = $product['cons'] ?? [];
        $customTabs = $product['custom_tabs'] ?? null;

        // Check what content is available for expand (auto-show if data exists)
        $hasProsCons = !empty($pros) || !empty($cons);
        $hasCustomTabs = !empty($customTabs) && is_array($customTabs);
        $hasExpandContent = $hasProsCons || $hasCustomTabs;

        // Position number
        $position = $index + 1;
        $itemId = $instanceId . '-item-' . $position;

        // Assign badge type if badge enabled
        $badgeType = '';
        $badgeLabel = '';
        if ($showBadges && $index < 4) {
            $badgeType = $badgeTypes[$index % count($badgeTypes)];
            $badgeLabel = $badgeLabels[$badgeType];
        }
    ?>

    <!-- List Item <?php echo $position; ?> -->
    <article class="acms-list__item <?php echo $hasExpandContent ? 'has-expand' : ''; ?>"
             data-position="<?php echo $position; ?>"
             data-asin="<?php echo esc_attr($asin); ?>">

        <?php if ($numbered) : ?>
        <!-- Ranking Badge -->
        <div class="acms-list__rank"><?php echo $position; ?></div>
        <?php endif; ?>

        <!-- Row 1: Main Product Content -->
        <div class="acms-list__row acms-list__row--main">
            <?php if ($showImage) : ?>
            <!-- Product Image -->
            <div class="acms-list__image">
                <?php /* DISABLED: Discount badge
                <?php if ($discountPercent > 0) : ?>
                <div class="acms-list__discount" data-acms-discount>-<?php echo esc_html($discountPercent); ?>%</div>
                <?php else : ?>
                <div class="acms-list__discount" data-acms-discount style="display:none"></div>
                <?php endif; ?>
                */ ?>
                <?php if (!empty($imageUrl)) : ?>
                <a href="<?php echo esc_url($affiliateUrl); ?>" target="_blank" rel="<?php echo esc_attr($linkRel); ?>">
                    <img src="<?php echo esc_url($imageUrl); ?>" alt="<?php echo esc_attr($title); ?>" loading="lazy">
                </a>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <!-- Product Info -->
            <div class="acms-list__info">
                <!-- Badges -->
                <div class="acms-list__badges">
                    <?php if ($showPrime && $isPrime) : ?>
                    <span class="acms-badge acms-badge--prime acms-badge--small" data-acms-prime>
                        <i class="bi bi-check2-circle"></i>
                        Prime
                    </span>
                    <?php elseif ($showPrime) : ?>
                    <span class="acms-badge acms-badge--prime acms-badge--small" data-acms-prime style="display:none">
                        <i class="bi bi-check2-circle"></i>
                        Prime
                    </span>
                    <?php endif; ?>

                    <?php if (!empty($badgeType)) : ?>
                    <span class="acms-badge acms-badge--<?php echo esc_attr($badgeType); ?> acms-badge--small">
                        <?php echo esc_html($badgeLabel); ?>
                    </span>
                    <?php endif; ?>
                </div>

                <!-- Product Title -->
                <h3 class="acms-list__title">
                    <a href="<?php echo esc_url($affiliateUrl); ?>" target="_blank" rel="<?php echo esc_attr($linkRel); ?>">
                        <?php echo esc_html($title); ?>
                    </a>
                </h3>

                <!-- Meta Info -->
                <div class="acms-list__meta">
                    <?php if (!empty($brand)) : ?>
                    <div class="acms-list__brand">
                        <i class="bi bi-patch-check-fill"></i>
                        <span><?php echo esc_html($brand); ?></span>
                    </div>
                    <?php endif; ?>

                    <?php if ($showStock) : ?>
                    <div class="acms-list__stock <?php echo $inStock ? 'acms-list__stock--in' : 'acms-list__stock--out'; ?>" data-acms-stock>
                        <i class="bi <?php echo $inStock ? 'bi-check-circle-fill' : 'bi-x-circle-fill'; ?>"></i>
                        <span><?php echo $inStock ? esc_html__('In Stock', 'affiliatecms-pro') : esc_html__('Out of Stock', 'affiliatecms-pro'); ?></span>
                    </div>
                    <?php endif; ?>

                    <?php if ($showRating && $score > 0) : ?>
                    <!-- Score (inline) -->
                    <div class="acms-list__score-wrapper">
                        <i class="bi bi-bar-chart-fill acms-list__score-icon"></i>
                        <div class="acms-score acms-score--inline" data-score="<?php echo esc_attr($score); ?>">
                            <span class="acms-score__value"><?php echo esc_html($scoreFormatted); ?></span>
                        </div>
                        <button type="button" class="acms-list__score-info" aria-label="<?php echo esc_attr(sprintf(__('About %s', 'affiliatecms-pro'), $atts['score_label_text'] ?? (defined('ACMS_SCORE_LABEL') ? ACMS_SCORE_LABEL : 'Score'))); ?>">
                            <i class="bi bi-info-circle"></i>
                        </button>
                        <div class="acms-list__score-tooltip">
                            <?php
                            echo wp_kses_post($atts['score_tooltip_text'] ?? (defined('ACMS_SCORE_TOOLTIP') ? ACMS_SCORE_TOOLTIP : 'Score is calculated based on product ratings, reviews, and sales performance to help you make informed purchasing decisions.'));
                            $score_link_text = defined('ACMS_SCORE_TOOLTIP_LINK_TEXT') ? ACMS_SCORE_TOOLTIP_LINK_TEXT : '';
                            $score_link_url = defined('ACMS_SCORE_TOOLTIP_LINK_URL') ? ACMS_SCORE_TOOLTIP_LINK_URL : '';
                            if ($score_link_text && $score_link_url) :
                            ?> <a href="<?php echo esc_url($score_link_url); ?>"><?php echo esc_html($score_link_text); ?> &raquo;</a><?php
                            endif;
                            ?>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php if (($atts['show_update'] ?? 'true') === 'true') : ?>
                    <div class="acms-list__update" data-acms-update>
                        <i class="bi bi-clock-history"></i>
                        <span data-acms-update-text><?php echo esc_html($lastUpdatedDetailed); ?></span>
                        <div class="acms-list__update-tooltip" data-acms-update-tooltip>
                            <?php
                            $updateTooltipText = $atts['update_tooltip_text'] ?? (defined('ACMS_UPDATE_TOOLTIP') ? ACMS_UPDATE_TOOLTIP : 'Last update on {date} / Affiliate links / Images, Product Titles, and Product Highlights from Amazon Product Advertising API.');
                            echo esc_html(str_replace('{date}', $lastUpdatedDetailed, $updateTooltipText));
                            ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Price & Action -->
            <div class="acms-list__price-action" data-acms-price="<?php echo esc_attr($asin); ?>">
                <?php if ($showPrice) : ?>
                <div class="acms-list__price-group">
                    <?php if ($discountPercent > 0 && !empty($originalPriceFormatted)) : ?>
                    <div class="acms-list__price-old-row" data-acms-price-discount-row>
                        <del class="acms-list__price-old" data-acms-price-original><?php echo esc_html($originalPriceFormatted); ?></del>
                        <span class="acms-list__price-savings" data-acms-price-savings><?php esc_html_e('Save', 'affiliatecms-pro'); ?> <?php echo esc_html($savingsFormatted); ?></span>
                    </div>
                    <?php endif; ?>
                    <div class="acms-list__price-current" data-acms-price-current><?php echo esc_html($priceFormatted); ?></div>
                </div>
                <?php endif; ?>

                <div class="acms-list__action">
                    <a href="<?php echo esc_url($affiliateUrl); ?>"
                       class="acms-btn acms-btn--amazon"
                       target="_blank"
                       rel="<?php echo esc_attr($linkRel); ?>">
                        <span><?php echo esc_html($buttonText); ?></span>
                        <i class="bi bi-box-arrow-up-right"></i>
                    </a>
                    <?php foreach ($affiliateLinks as $link) :
                        $linkUrl = $link['affiliate_url'] ?? '';
                        $linkName = $link['provider_name'] ?? ucfirst($link['provider'] ?? 'Shop');
                        if (empty($linkUrl)) continue;
                    ?>
                    <a href="<?php echo esc_url($linkUrl); ?>"
                       class="acms-btn acms-btn--affiliate"
                       target="_blank"
                       rel="<?php echo esc_attr($linkRel); ?>">
                        <span><?php echo esc_html($linkName); ?></span>
                        <i class="bi bi-box-arrow-up-right"></i>
                    </a>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- Pros & Cons Section (Expandable) -->
        <?php if ($hasProsCons) : ?>
        <div class="acms-list__row acms-list__row--toggle"
             onclick="this.closest('.acms-list__item').querySelector('#<?php echo esc_attr($itemId); ?>-proscons').classList.toggle('is-expanded'); this.querySelector('.acms-list__expand-toggle').setAttribute('aria-expanded', this.querySelector('.acms-list__expand-toggle').getAttribute('aria-expanded') === 'true' ? 'false' : 'true');">
            <div class="acms-list__toggle-labels">
                <span class="acms-list__toggle-label">
                    <i class="bi bi-hand-thumbs-up"></i>
                    <?php esc_html_e('Pros & Cons', 'affiliatecms-pro'); ?>
                </span>
            </div>
            <button type="button" class="acms-list__expand-toggle"
                    aria-expanded="false"
                    aria-controls="<?php echo esc_attr($itemId); ?>-proscons">
                <span class="acms-list__expand-text"><?php esc_html_e('View', 'affiliatecms-pro'); ?></span>
                <span class="acms-list__collapse-text"><?php esc_html_e('Hide', 'affiliatecms-pro'); ?></span>
                <i class="bi bi-chevron-down"></i>
            </button>
        </div>
        <div class="acms-list__row acms-list__row--details" id="<?php echo esc_attr($itemId); ?>-proscons">
            <div class="acms-list__details-grid">
                <div class="acms-list__detail-section acms-list__pros-cons">
                    <?php if (!empty($pros)) : ?>
                    <div class="acms-list__pros">
                        <h4><i class="bi bi-hand-thumbs-up-fill"></i> <?php esc_html_e('Pros', 'affiliatecms-pro'); ?></h4>
                        <ul>
                            <?php foreach ($pros as $pro) : ?>
                            <li><?php echo esc_html($pro); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <?php endif; ?>

                    <?php if (!empty($cons)) : ?>
                    <div class="acms-list__cons">
                        <h4><i class="bi bi-hand-thumbs-down-fill"></i> <?php esc_html_e('Cons', 'affiliatecms-pro'); ?></h4>
                        <ul>
                            <?php foreach ($cons as $con) : ?>
                            <li><?php echo esc_html($con); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Custom Tabs (Each tab is separate expand/collapse) -->
        <?php if ($hasCustomTabs) : ?>
            <?php foreach ($customTabs as $tabIndex => $tab) : ?>
                <?php
                $tabTitle = $tab['title'] ?? '';
                $tabContent = $tab['content'] ?? '';
                $tabIcon = $tab['icon'] ?? 'bi-card-text';
                if (empty($tabTitle) || empty($tabContent)) continue;
                $tabId = $itemId . '-tab-' . $tabIndex;
                ?>
                <div class="acms-list__row acms-list__row--toggle"
                     onclick="this.closest('.acms-list__item').querySelector('#<?php echo esc_attr($tabId); ?>').classList.toggle('is-expanded'); this.querySelector('.acms-list__expand-toggle').setAttribute('aria-expanded', this.querySelector('.acms-list__expand-toggle').getAttribute('aria-expanded') === 'true' ? 'false' : 'true');">
                    <div class="acms-list__toggle-labels">
                        <span class="acms-list__toggle-label">
                            <i class="bi <?php echo esc_attr($tabIcon); ?>"></i>
                            <?php echo esc_html($tabTitle); ?>
                        </span>
                    </div>
                    <button type="button" class="acms-list__expand-toggle"
                            aria-expanded="false"
                            aria-controls="<?php echo esc_attr($tabId); ?>">
                        <span class="acms-list__expand-text"><?php esc_html_e('View', 'affiliatecms-pro'); ?></span>
                        <span class="acms-list__collapse-text"><?php esc_html_e('Hide', 'affiliatecms-pro'); ?></span>
                        <i class="bi bi-chevron-down"></i>
                    </button>
                </div>
                <div class="acms-list__row acms-list__row--details" id="<?php echo esc_attr($tabId); ?>">
                    <div class="acms-list__details-grid">
                        <div class="acms-list__detail-section acms-list__custom-tab">
                            <div class="acms-list__tab-content">
                                <?php echo wp_kses_post($tabContent); ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </article>
    <?php endforeach; ?>
</div>

