/**
 * AffiliateCMS Pro - Admin JavaScript
 *
 * Admin functionality including API wrapper, toast notifications,
 * form helpers, and modal management.
 */

(function() {
    'use strict';

    // ===========================================
    // API WRAPPER
    // ===========================================

    const acmsApi = {
        baseUrl: window.acmsConfig?.restUrl || '/wp-json/acms/v1/',
        nonce: window.acmsConfig?.nonce || '',

        /**
         * Make GET request
         */
        async get(endpoint, params = {}) {
            const url = new URL(this.baseUrl + endpoint, window.location.origin);
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));

            const response = await fetch(url, {
                method: 'GET',
                headers: {
                    'X-WP-Nonce': this.nonce,
                    'Content-Type': 'application/json',
                },
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            return response.json();
        },

        /**
         * Make POST request
         */
        async post(endpoint, data = {}) {
            const response = await fetch(this.baseUrl + endpoint, {
                method: 'POST',
                headers: {
                    'X-WP-Nonce': this.nonce,
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data),
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            return response.json();
        },

        /**
         * Make PATCH request
         */
        async patch(endpoint, data = {}) {
            const response = await fetch(this.baseUrl + endpoint, {
                method: 'PATCH',
                headers: {
                    'X-WP-Nonce': this.nonce,
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data),
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            return response.json();
        },

        /**
         * Make DELETE request
         */
        async delete(endpoint) {
            const response = await fetch(this.baseUrl + endpoint, {
                method: 'DELETE',
                headers: {
                    'X-WP-Nonce': this.nonce,
                    'Content-Type': 'application/json',
                },
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            return response.json();
        },
    };

    // ===========================================
    // TOAST NOTIFICATIONS
    // ===========================================

    const toast = {
        container: null,

        /**
         * Initialize toast container
         */
        init() {
            if (this.container) return;

            this.container = document.createElement('div');
            this.container.className = 'acms-toasts';
            document.body.appendChild(this.container);
        },

        /**
         * Show toast notification
         */
        show(message, type = 'info', title = '', duration = 4000) {
            this.init();

            const icons = {
                success: 'bi-check-circle-fill',
                error: 'bi-x-circle-fill',
                warning: 'bi-exclamation-triangle-fill',
                info: 'bi-info-circle-fill',
            };

            const toastEl = document.createElement('div');
            toastEl.className = `acms-toast acms-toast--${type}`;
            toastEl.innerHTML = `
                <div class="acms-toast__icon">
                    <i class="bi ${icons[type] || icons.info}"></i>
                </div>
                <div class="acms-toast__content">
                    ${title ? `<div class="acms-toast__title">${title}</div>` : ''}
                    <div class="acms-toast__message">${message}</div>
                </div>
                <button type="button" class="acms-toast__close">
                    <i class="bi bi-x"></i>
                </button>
            `;

            // Add click handler for close button
            toastEl.querySelector('.acms-toast__close').addEventListener('click', () => {
                this.hide(toastEl);
            });

            this.container.appendChild(toastEl);

            // Auto-hide after duration
            if (duration > 0) {
                setTimeout(() => this.hide(toastEl), duration);
            }

            return toastEl;
        },

        /**
         * Hide toast notification
         */
        hide(toastEl) {
            toastEl.classList.add('is-leaving');
            setTimeout(() => toastEl.remove(), 300);
        },

        /**
         * Convenience methods
         */
        success(message, title = '') {
            return this.show(message, 'success', title || window.acmsConfig?.i18n?.success || 'Success');
        },

        error(message, title = '') {
            return this.show(message, 'error', title || window.acmsConfig?.i18n?.error || 'Error');
        },

        warning(message, title = '') {
            return this.show(message, 'warning', title);
        },

        info(message, title = '') {
            return this.show(message, 'info', title);
        },
    };

    // ===========================================
    // MODAL MANAGEMENT
    // ===========================================

    const modal = {
        /**
         * Open modal
         */
        open(modalId) {
            const backdrop = document.getElementById(modalId);
            if (backdrop) {
                backdrop.classList.add('is-open');
                document.body.style.overflow = 'hidden';
            }
        },

        /**
         * Close modal
         */
        close(modalId) {
            const backdrop = document.getElementById(modalId);
            if (backdrop) {
                backdrop.classList.remove('is-open');
                document.body.style.overflow = '';
            }
        },

        /**
         * Close all modals
         */
        closeAll() {
            document.querySelectorAll('.acms-modal-backdrop.is-open').forEach(backdrop => {
                backdrop.classList.remove('is-open');
            });
            document.body.style.overflow = '';
        },

        /**
         * Initialize modal event listeners
         */
        init() {
            // Close on backdrop click
            document.addEventListener('click', (e) => {
                if (e.target.classList.contains('acms-modal-backdrop')) {
                    e.target.classList.remove('is-open');
                    document.body.style.overflow = '';
                }
            });

            // Close on close button click
            document.addEventListener('click', (e) => {
                const closeBtn = e.target.closest('[data-modal-close]');
                if (closeBtn) {
                    const modalId = closeBtn.dataset.modalClose;
                    if (modalId) {
                        this.close(modalId);
                    } else {
                        const backdrop = closeBtn.closest('.acms-modal-backdrop');
                        if (backdrop) {
                            backdrop.classList.remove('is-open');
                            document.body.style.overflow = '';
                        }
                    }
                }
            });

            // Close on Escape key
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape') {
                    this.closeAll();
                }
            });

            // Open modal on trigger click
            document.addEventListener('click', (e) => {
                const trigger = e.target.closest('[data-modal-open]');
                if (trigger) {
                    const modalId = trigger.dataset.modalOpen;
                    this.open(modalId);
                }
            });
        },
    };

    // ===========================================
    // FORM HELPERS
    // ===========================================

    const forms = {
        /**
         * Serialize form data to object
         */
        serialize(form) {
            const formData = new FormData(form);
            const data = {};

            for (const [key, value] of formData.entries()) {
                // Handle array fields (name="field[]")
                if (key.endsWith('[]')) {
                    const arrayKey = key.slice(0, -2);
                    if (!data[arrayKey]) {
                        data[arrayKey] = [];
                    }
                    data[arrayKey].push(value);
                } else {
                    data[key] = value;
                }
            }

            return data;
        },

        /**
         * Reset form
         */
        reset(form) {
            form.reset();
            form.querySelectorAll('.acms-form-error').forEach(el => el.remove());
            form.querySelectorAll('.is-invalid').forEach(el => el.classList.remove('is-invalid'));
        },

        /**
         * Show validation errors
         */
        showErrors(form, errors) {
            // Clear existing errors
            form.querySelectorAll('.acms-form-error').forEach(el => el.remove());
            form.querySelectorAll('.is-invalid').forEach(el => el.classList.remove('is-invalid'));

            // Show new errors
            Object.keys(errors).forEach(field => {
                const input = form.querySelector(`[name="${field}"]`);
                if (input) {
                    input.classList.add('is-invalid');
                    const errorEl = document.createElement('div');
                    errorEl.className = 'acms-form-error';
                    errorEl.textContent = errors[field];
                    input.parentNode.appendChild(errorEl);
                }
            });
        },
    };

    // ===========================================
    // UTILITIES
    // ===========================================

    const utils = {
        /**
         * Debounce function
         */
        debounce(func, wait) {
            let timeout;
            return function executedFunction(...args) {
                const later = () => {
                    clearTimeout(timeout);
                    func(...args);
                };
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
            };
        },

        /**
         * Format currency
         */
        formatCurrency(amount, currency = 'USD') {
            return new Intl.NumberFormat('en-US', {
                style: 'currency',
                currency: currency,
            }).format(amount);
        },

        /**
         * Format number
         */
        formatNumber(num) {
            if (num >= 1000000) {
                return (num / 1000000).toFixed(1) + 'M';
            }
            if (num >= 1000) {
                return (num / 1000).toFixed(1) + 'K';
            }
            return num.toString();
        },

        /**
         * Copy text to clipboard
         */
        async copyToClipboard(text) {
            try {
                await navigator.clipboard.writeText(text);
                toast.success('Copied to clipboard');
                return true;
            } catch (err) {
                toast.error('Failed to copy');
                return false;
            }
        },

        /**
         * Confirm action
         */
        confirm(message) {
            return window.confirm(message || window.acmsConfig?.i18n?.confirm_delete || 'Are you sure?');
        },
    };

    // ===========================================
    // INITIALIZATION
    // ===========================================

    function init() {
        // Initialize modal event listeners
        modal.init();


    }

    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    // ===========================================
    // EXPOSE GLOBAL API
    // ===========================================

    window.acms = {
        api: acmsApi,
        toast,
        modal,
        forms,
        utils,
    };

})();
