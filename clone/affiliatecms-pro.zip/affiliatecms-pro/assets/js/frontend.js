/**
 * AffiliateCMS Pro - Frontend JavaScript
 *
 * Minimal JavaScript for frontend interactions:
 * - Image gallery/lightbox
 * - Features toggle
 * - Lazy loading images
 */

(function() {
    'use strict';

    // ===========================================
    // LIGHTBOX CLASS
    // ===========================================

    class AcmsLightbox {
        constructor() {
            this.currentIndex = {};
            this.images = {};
            this.cacheImages();
            this.bindEvents();
        }

        /**
         * Cache images for each modal from thumbnails
         */
        cacheImages() {
            document.querySelectorAll('[data-modal]').forEach(modal => {
                const asin = modal.dataset.modal;
                const thumbs = modal.querySelectorAll('[data-modal-thumb] img');
                this.images[asin] = Array.from(thumbs).map(img => img.src);
                this.currentIndex[asin] = 0;
            });
        }

        /**
         * Bind event listeners
         */
        bindEvents() {
            document.addEventListener('click', (e) => {
                // Open modal on image click
                const openTrigger = e.target.closest('[data-modal-open]');
                if (openTrigger) {
                    e.preventDefault();
                    const asin = openTrigger.dataset.modalOpen;
                    this.open(asin);
                    return;
                }

                // Close modal
                const closeBtn = e.target.closest('[data-modal-close]');
                if (closeBtn) {
                    const asin = closeBtn.dataset.modalClose;
                    this.close(asin);
                    return;
                }

                // Close on backdrop click
                const modal = e.target.closest('.acms-modal');
                if (modal && e.target === modal) {
                    const asin = modal.dataset.modal;
                    this.close(asin);
                    return;
                }

                // Modal navigation
                const navBtn = e.target.closest('[data-modal-nav]');
                if (navBtn) {
                    const modal = navBtn.closest('[data-modal]');
                    if (modal) {
                        const asin = modal.dataset.modal;
                        const direction = navBtn.dataset.modalNav;
                        this.navigate(asin, direction);
                    }
                    return;
                }

                // Modal thumbnail click
                const thumbBtn = e.target.closest('[data-modal-thumb]');
                if (thumbBtn) {
                    const modal = thumbBtn.closest('[data-modal]');
                    if (modal) {
                        const asin = modal.dataset.modal;
                        const index = parseInt(thumbBtn.dataset.modalThumb, 10);
                        this.goToSlide(asin, index);
                    }
                    return;
                }
            });

            // Keyboard navigation
            document.addEventListener('keydown', (e) => {
                const openModal = document.querySelector('.acms-modal.is-open');
                if (!openModal) return;

                const asin = openModal.dataset.modal;

                if (e.key === 'Escape') {
                    this.close(asin);
                } else if (e.key === 'ArrowLeft') {
                    this.navigate(asin, 'prev');
                } else if (e.key === 'ArrowRight') {
                    this.navigate(asin, 'next');
                }
            });
        }

        /**
         * Open modal
         */
        open(asin) {
            const modal = document.querySelector(`[data-modal="${asin}"]`);
            if (modal) {
                modal.classList.add('is-open');
                document.body.classList.add('acms-modal-open');
            }
        }

        /**
         * Close modal
         */
        close(asin) {
            const modal = asin
                ? document.querySelector(`[data-modal="${asin}"]`)
                : document.querySelector('.acms-modal.is-open');

            if (modal) {
                modal.classList.remove('is-open');
                document.body.classList.remove('acms-modal-open');
            }
        }

        /**
         * Navigate to next/prev image
         */
        navigate(asin, direction) {
            const images = this.images[asin];
            if (!images || images.length === 0) return;

            let currentIdx = this.currentIndex[asin] || 0;

            if (direction === 'prev') {
                currentIdx = (currentIdx - 1 + images.length) % images.length;
            } else {
                currentIdx = (currentIdx + 1) % images.length;
            }

            this.goToSlide(asin, currentIdx);
        }

        /**
         * Go to specific slide
         */
        goToSlide(asin, index) {
            const modal = document.querySelector(`[data-modal="${asin}"]`);
            if (!modal) return;

            const images = this.images[asin];
            if (!images || index < 0 || index >= images.length) return;

            // Update current index
            this.currentIndex[asin] = index;

            // Update main image
            const mainImage = modal.querySelector('[data-modal-main]');
            if (mainImage) {
                mainImage.src = images[index];
            }

            // Update active thumbnail
            const thumbs = modal.querySelectorAll('[data-modal-thumb]');
            thumbs.forEach((thumb, i) => {
                thumb.classList.toggle('is-active', i === index);
            });

            // Update counter
            const currentDisplay = modal.querySelector('[data-modal-current]');
            if (currentDisplay) {
                currentDisplay.textContent = index + 1;
            }
        }
    }

    // ===========================================
    // FEATURES TOGGLE
    // ===========================================

    const FeaturesToggle = {
        init() {
            this.bindEvents();
        },

        bindEvents() {
            document.addEventListener('click', (e) => {
                const toggle = e.target.closest('[data-features-toggle]');
                if (toggle) {
                    this.handleToggle(toggle);
                }
            });
        },

        handleToggle(toggleBtn) {
            const featuresSection = toggleBtn.closest('[data-features]');
            if (!featuresSection) return;

            const isExpanded = featuresSection.classList.toggle('is-expanded');
            const textEl = toggleBtn.querySelector('[data-toggle-text]');

            toggleBtn.setAttribute('aria-expanded', isExpanded);

            if (textEl) {
                textEl.textContent = isExpanded ? 'Collapse' : 'Expand';
            }
        }
    };

    // ===========================================
    // GALLERY MODULE (In-card gallery)
    // ===========================================

    const Gallery = {
        currentIndex: {},

        init() {
            this.bindEvents();
        },

        bindEvents() {
            document.addEventListener('click', (e) => {
                // Thumbnail click
                const thumb = e.target.closest('[data-gallery-thumb]');
                if (thumb) {
                    this.handleThumbClick(thumb);
                }

                // Navigation buttons
                const nav = e.target.closest('[data-gallery-nav]');
                if (nav) {
                    this.handleNavClick(nav);
                }
            });
        },

        handleThumbClick(thumb) {
            const gallery = thumb.closest('[data-gallery]');
            if (!gallery) return;

            const index = parseInt(thumb.dataset.galleryThumb, 10);
            this.goToSlide(gallery, index);
        },

        handleNavClick(nav) {
            const gallery = nav.closest('[data-gallery]');
            if (!gallery) return;

            const direction = nav.dataset.galleryNav;
            this.navigate(gallery, direction);
        },

        navigate(gallery, direction) {
            const thumbs = gallery.querySelectorAll('[data-gallery-thumb]');
            const totalSlides = thumbs.length;
            if (totalSlides === 0) return;

            const galleryId = gallery.dataset.gallery || 'default';
            let currentIdx = this.currentIndex[galleryId] || 0;

            if (direction === 'prev') {
                currentIdx = (currentIdx - 1 + totalSlides) % totalSlides;
            } else {
                currentIdx = (currentIdx + 1) % totalSlides;
            }

            this.goToSlide(gallery, currentIdx);
        },

        goToSlide(gallery, index) {
            const galleryId = gallery.dataset.gallery || 'default';
            const thumbs = gallery.querySelectorAll('[data-gallery-thumb]');
            const mainImage = gallery.querySelector('[data-gallery-main]');
            const currentDisplay = gallery.querySelector('[data-gallery-current]');

            if (index < 0 || index >= thumbs.length) return;

            // Update current index
            this.currentIndex[galleryId] = index;

            // Update active thumbnail
            thumbs.forEach((thumb, i) => {
                thumb.classList.toggle('is-active', i === index);
            });

            // Update main image
            if (mainImage && thumbs[index]) {
                const thumbImg = thumbs[index].querySelector('img');
                if (thumbImg) {
                    mainImage.src = thumbImg.src;
                }
            }

            // Update counter
            if (currentDisplay) {
                currentDisplay.textContent = index + 1;
            }
        }
    };

    // ===========================================
    // TOOLTIP MODULE
    // ===========================================

    const Tooltip = {
        init() {
            this.bindEvents();
        },

        bindEvents() {
            // Toggle tooltip on click
            document.addEventListener('click', (e) => {
                const tooltip = e.target.closest('[data-tooltip]');

                if (tooltip) {
                    e.stopPropagation();
                    this.toggle(tooltip);
                } else {
                    // Close all tooltips when clicking outside
                    this.closeAll();
                }
            });

            // Close on Escape key
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape') {
                    this.closeAll();
                }
            });
        },

        toggle(tooltip) {
            // Close other tooltips first
            document.querySelectorAll('.acms-tooltip.is-active').forEach(t => {
                if (t !== tooltip) {
                    t.classList.remove('is-active');
                }
            });

            tooltip.classList.toggle('is-active');
        },

        closeAll() {
            document.querySelectorAll('.acms-tooltip.is-active').forEach(t => {
                t.classList.remove('is-active');
            });
        }
    };

    // ===========================================
    // LAZY LOADING
    // ===========================================

    const LazyLoad = {
        init() {
            // Use native lazy loading if supported
            if ('loading' in HTMLImageElement.prototype) {
                document.querySelectorAll('img[loading="lazy"]').forEach(img => {
                    if (img.dataset.src) {
                        img.src = img.dataset.src;
                    }
                });
            } else {
                // Fallback to IntersectionObserver
                this.initIntersectionObserver();
            }
        },

        initIntersectionObserver() {
            const images = document.querySelectorAll('img[data-src]');

            if ('IntersectionObserver' in window) {
                const observer = new IntersectionObserver((entries, observer) => {
                    entries.forEach(entry => {
                        if (entry.isIntersecting) {
                            const img = entry.target;
                            img.src = img.dataset.src;
                            img.removeAttribute('data-src');
                            observer.unobserve(img);
                        }
                    });
                }, {
                    rootMargin: '50px 0px',
                    threshold: 0.01
                });

                images.forEach(img => observer.observe(img));
            } else {
                // Fallback for older browsers
                images.forEach(img => {
                    img.src = img.dataset.src;
                    img.removeAttribute('data-src');
                });
            }
        }
    };

    // ===========================================
    // GRID RESPONSIVE MODULE
    // ===========================================

    const GridResponsive = {
        breakpoints: {
            xs: 389,
            sm: 600,
            md: 900,
        },

        init() {
            this.applyResponsiveClasses();
            this.bindEvents();
        },

        bindEvents() {
            let resizeTimeout;
            window.addEventListener('resize', () => {
                clearTimeout(resizeTimeout);
                resizeTimeout = setTimeout(() => {
                    this.applyResponsiveClasses();
                }, 100);
            });
        },

        applyResponsiveClasses() {
            const grids = document.querySelectorAll('.acms-grid');

            grids.forEach(grid => {
                const containerWidth = grid.offsetWidth;

                // Remove existing size classes
                grid.classList.remove(
                    'acms-grid--xs',
                    'acms-grid--sm',
                    'acms-grid--md',
                    'acms-grid--lg'
                );

                // Determine breakpoint and apply class
                if (containerWidth <= this.breakpoints.xs) {
                    grid.classList.add('acms-grid--xs');
                    grid.style.setProperty('--acms-grid-columns', '1');
                } else if (containerWidth <= this.breakpoints.sm) {
                    grid.classList.add('acms-grid--sm');
                    grid.style.setProperty('--acms-grid-columns', '2');
                } else if (containerWidth <= this.breakpoints.md) {
                    grid.classList.add('acms-grid--md');
                    grid.style.setProperty('--acms-grid-columns', '3');
                } else {
                    grid.classList.add('acms-grid--lg');
                    // Keep default columns from style attribute
                }
            });
        }
    };

    // ===========================================
    // LIVE PRICES MODULE
    // ===========================================
    //
    // Design decisions:
    // - All ASINs from ALL shortcodes on page → collected once → 1 fetch → 1 DB query
    // - No cache: Amazon TOS forbids caching price/availability
    //   (server also sends Cache-Control: no-store)
    // - Graceful degradation: if fetch fails, PHP-rendered values stay as-is
    // - Currency formatting matches PHP side (symbol + 2 decimals)
    // - Runs after DOM ready, non-blocking (deferred JS)

    const LivePrices = {
        // Populated by wp_localize_script in Assets.php
        config: window.acmsFrontend || {},

        init() {
            if (!this.config.restUrl) return;

            // Collect all unique ASINs from every [acms_list] on the page
            const nodes = document.querySelectorAll('[data-acms-price]');
            if (!nodes.length) return;

            const asins = [...new Set(
                Array.from(nodes).map(el => el.dataset.acmsPrice).filter(Boolean)
            )];

            if (!asins.length) return;

            this.fetch(asins);
        },

        fetch(asins) {
            const url = this.config.restUrl + 'products/live-prices?asins=' + encodeURIComponent(asins.join(','));

            fetch(url, {
                method: 'GET',
                headers: { 'X-WP-Nonce': this.config.nonce || '' },
                cache: 'no-store',
            })
            .then(r => r.ok ? r.json() : null)
            .then(json => {
                if (!json || !json.data) return;
                Object.entries(json.data).forEach(([asin, d]) => this.update(asin, d));
            })
            .catch(() => {
                // Silent fail — PHP-rendered prices remain visible
            });
        },

        /**
         * Format price from raw float + currency code.
         * Mirrors PHP Shortcodes::formatPrice().
         */
        formatPrice(amount, currency) {
            if (amount === null || amount === undefined) return '';
            const symbols = { USD: '$', EUR: '€', GBP: '£', CAD: 'CA$', AUD: 'A$', JPY: '¥' };
            const sym = symbols[currency] || currency + ' ';
            const decimals = (currency === 'JPY') ? 0 : 2;
            return sym + parseFloat(amount).toFixed(decimals);
        },

        /**
         * Format relative time from ISO date string.
         * Returns e.g. "Updated Jan 15, 2025"
         */
        formatDate(isoDate) {
            if (!isoDate) return '';
            const d = new Date(isoDate.replace(' ', 'T') + 'Z');
            if (isNaN(d.getTime())) return '';
            return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
        },

        update(asin, d) {
            // Find the price wrapper for this ASIN
            const wrapper = document.querySelector('[data-acms-price="' + CSS.escape(asin) + '"]');
            if (!wrapper) return;

            const currency = d.currency || 'USD';

            // --- Current price ---
            const priceEl = wrapper.querySelector('[data-acms-price-current]');
            if (priceEl) {
                priceEl.textContent = d.price !== null ? this.formatPrice(d.price, currency) : priceEl.textContent;
            }

            // --- Original price + savings row ---
            const discountRow = wrapper.querySelector('[data-acms-price-discount-row]');
            const originalEl  = wrapper.querySelector('[data-acms-price-original]');
            const savingsEl   = wrapper.querySelector('[data-acms-price-savings]');

            if (d.discount_pct > 0 && d.original_price !== null) {
                if (originalEl) originalEl.textContent = this.formatPrice(d.original_price, currency);
                const savings = d.original_price - d.price;
                if (savingsEl) {
                    savingsEl.textContent = (this.config.i18n?.save || 'Save') + ' ' + this.formatPrice(savings, currency);
                }
                if (discountRow) discountRow.style.display = '';
            } else {
                if (discountRow) discountRow.style.display = 'none';
            }

            // --- Discount badge on image ---
            const article = wrapper.closest('[data-asin]');
            if (article) {
                const discountBadge = article.querySelector('[data-acms-discount]');
                if (discountBadge) {
                    if (d.discount_pct > 0) {
                        discountBadge.textContent = '-' + d.discount_pct + '%';
                        discountBadge.style.display = '';
                    } else {
                        discountBadge.style.display = 'none';
                    }
                }

                // --- Stock status ---
                const stockEl = article.querySelector('[data-acms-stock]');
                if (stockEl) {
                    const inStock = d.in_stock;
                    stockEl.className = stockEl.className
                        .replace(/acms-list__stock--(in|out)/, '')
                        .trim() + ' ' + (inStock ? 'acms-list__stock--in' : 'acms-list__stock--out');

                    const icon = stockEl.querySelector('i');
                    if (icon) {
                        icon.className = 'bi ' + (inStock ? 'bi-check-circle-fill' : 'bi-x-circle-fill');
                    }
                    const span = stockEl.querySelector('span');
                    if (span) {
                        span.textContent = inStock
                            ? (this.config.i18n?.in_stock || 'In Stock')
                            : (this.config.i18n?.out_of_stock || 'Out of Stock');
                    }
                }

                // --- Prime badge ---
                const primeEl = article.querySelector('[data-acms-prime]');
                if (primeEl) {
                    primeEl.style.display = d.is_prime ? '' : 'none';
                }

                // --- Last updated ---
                const updateEl    = article.querySelector('[data-acms-update]');
                const updateText  = article.querySelector('[data-acms-update-text]');
                const updateTip   = article.querySelector('[data-acms-update-tooltip]');
                if (updateEl && d.last_scraped_at) {
                    const dateStr = this.formatDate(d.last_scraped_at);
                    if (updateText) updateText.textContent = dateStr;
                    if (updateTip) {
                        const tpl = this.config.updateTooltipTpl || 'Last update on {date}';
                        updateTip.textContent = tpl.replace('{date}', dateStr);
                    }
                }
            }
        }
    };

    // ===========================================
    // INITIALIZATION
    // ===========================================

    function init() {
        // Initialize lightbox
        const lightbox = new AcmsLightbox();

        // Initialize modules
        FeaturesToggle.init();
        Gallery.init();
        Tooltip.init();
        LazyLoad.init();
        GridResponsive.init();
        LivePrices.init();
    }

    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})();
