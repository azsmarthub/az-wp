<?php
/**
 * Crawlbase API Debug Test
 * Upload to: wp-content/plugins/affiliatecms-pro/test-crawlbase.php
 * Access: https://productreviews.org/wp-content/plugins/affiliatecms-pro/test-crawlbase.php
 * DELETE THIS FILE AFTER DEBUGGING
 */

// Load WordPress (3 levels up from wp-content/plugins/affiliatecms-pro/)
require_once __DIR__ . '/../../../wp-load.php';

// Only allow admins
if (!current_user_can('manage_options')) {
    wp_die('Admin access required. Please <a href="' . wp_login_url($_SERVER['REQUEST_URI']) . '">log in</a>.');
}

$token = get_option('acms_crawlbase_token', '');
$testAsin = isset($_GET['asin']) ? sanitize_text_field($_GET['asin']) : 'B0DWMBG6ND';
$domain = isset($_GET['domain']) ? sanitize_text_field($_GET['domain']) : 'amazon.com';

// Build URL exactly like CrawlbaseProvider::buildUrl()
$amazonUrl = "https://www.{$domain}/dp/{$testAsin}";
$apiUrl = 'https://api.crawlbase.com/?' . http_build_query([
    'token'   => $token,
    'url'     => $amazonUrl,
    'scraper' => 'amazon-product-details',
    'country' => 'us',
]);

$safeApiUrl = preg_replace('/token=[^&]+/', 'token=' . substr($token, 0, 8) . '...', $apiUrl);

?><!DOCTYPE html>
<html>
<head>
    <title>Crawlbase Debug - <?php echo esc_html($testAsin); ?></title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, monospace; max-width: 1200px; margin: 20px auto; padding: 0 20px; background: #1a1a2e; color: #eee; }
        h1 { color: #e94560; }
        h2 { color: #0f3460; background: #e94560; padding: 8px 12px; border-radius: 4px; }
        .info { background: #16213e; padding: 15px; border-radius: 8px; margin: 10px 0; border-left: 4px solid #0f3460; }
        .error { border-left-color: #e94560; background: #2d1b2e; }
        .success { border-left-color: #4ecca3; background: #1b2d2a; }
        pre { background: #0a0a1a; padding: 15px; border-radius: 8px; overflow-x: auto; font-size: 13px; line-height: 1.5; white-space: pre-wrap; word-break: break-word; }
        code { color: #4ecca3; }
        .label { color: #a0a0c0; }
        .value { color: #4ecca3; font-weight: bold; }
        table { border-collapse: collapse; width: 100%; }
        td, th { padding: 8px 12px; border: 1px solid #333; text-align: left; }
        th { background: #16213e; color: #e94560; }
        form { background: #16213e; padding: 15px; border-radius: 8px; margin: 15px 0; display: flex; gap: 10px; align-items: center; }
        input, button { padding: 8px 12px; border-radius: 4px; border: 1px solid #333; font-size: 14px; }
        input { background: #0a0a1a; color: #eee; }
        button { background: #e94560; color: #fff; border: none; cursor: pointer; font-weight: bold; }
        button:hover { background: #c73e54; }
    </style>
</head>
<body>
    <h1>Crawlbase API Debug</h1>

    <form method="get">
        <label>ASIN:</label>
        <input name="asin" value="<?php echo esc_attr($testAsin); ?>" placeholder="B0DWMBG6ND" size="15">
        <label>Domain:</label>
        <input name="domain" value="<?php echo esc_attr($domain); ?>" placeholder="amazon.com" size="15">
        <button type="submit">Test</button>
    </form>

    <div class="info">
        <span class="label">Token:</span> <code><?php echo $token ? substr($token, 0, 8) . '...' . substr($token, -4) : '<span style="color:#e94560">NOT SET</span>'; ?></code><br>
        <span class="label">ASIN:</span> <code><?php echo esc_html($testAsin); ?></code><br>
        <span class="label">Amazon URL:</span> <code><?php echo esc_html($amazonUrl); ?></code><br>
        <span class="label">API URL:</span> <code><?php echo esc_html($safeApiUrl); ?></code>
    </div>

<?php if (empty($token)): ?>
    <div class="info error">
        <strong>ERROR:</strong> No Crawlbase token found in wp_options (acms_crawlbase_token).
        Set it in AffiliateCMS Pro > Settings.
    </div>
<?php else: ?>

    <h2>Step 1: wp_remote_get (WordPress HTTP)</h2>
    <?php
    $startWp = microtime(true);
    $wpResponse = wp_remote_get($apiUrl, [
        'timeout' => 120,
        'headers' => ['Accept' => 'application/json'],
    ]);
    $wpTime = round(microtime(true) - $startWp, 2);

    if (is_wp_error($wpResponse)): ?>
        <div class="info error">
            <strong>WP ERROR:</strong> <?php echo esc_html($wpResponse->get_error_message()); ?><br>
            <span class="label">Error code:</span> <code><?php echo esc_html($wpResponse->get_error_code()); ?></code><br>
            <span class="label">Time:</span> <code><?php echo $wpTime; ?>s</code>
        </div>
    <?php else:
        $httpCode = wp_remote_retrieve_response_code($wpResponse);
        $body = wp_remote_retrieve_body($wpResponse);
        $headers = wp_remote_retrieve_headers($wpResponse);
        $statusClass = ($httpCode === 200) ? 'success' : 'error';
    ?>
        <div class="info <?php echo $statusClass; ?>">
            <span class="label">HTTP Status:</span> <code class="value"><?php echo $httpCode; ?></code><br>
            <span class="label">Time:</span> <code><?php echo $wpTime; ?>s</code><br>
            <span class="label">Body size:</span> <code><?php echo strlen($body); ?> bytes</code><br>
            <span class="label">Content-Type:</span> <code><?php echo esc_html($headers['content-type'] ?? 'unknown'); ?></code>
        </div>

        <?php
        $json = json_decode($body, true);
        if (isset($json[0])) $json = $json[0];

        if ($json): ?>
            <h2>Step 2: Response Analysis</h2>
            <table>
                <tr><th>Field</th><th>Value</th></tr>
                <tr><td>pc_status</td><td><code><?php echo esc_html($json['pc_status'] ?? 'N/A'); ?></code></td></tr>
                <tr><td>original_status</td><td><code><?php echo esc_html($json['original_status'] ?? 'N/A'); ?></code></td></tr>
                <tr><td>error</td><td><code><?php echo esc_html($json['error'] ?? 'none'); ?></code></td></tr>
                <tr><td>body type</td><td><code><?php echo isset($json['body']) ? (is_array($json['body']) ? 'object (' . count($json['body']) . ' keys)' : gettype($json['body'])) : 'missing'; ?></code></td></tr>
            </table>

            <?php if (isset($json['body']) && is_array($json['body'])):
                $b = $json['body']; ?>
                <h2>Step 3: Product Data</h2>
                <table>
                    <tr><th>Field</th><th>Value</th></tr>
                    <tr><td>name/title</td><td><?php echo esc_html(mb_substr($b['name'] ?? $b['title'] ?? 'MISSING', 0, 120)); ?></td></tr>
                    <tr><td>brand</td><td><?php echo esc_html($b['brand'] ?? 'N/A'); ?></td></tr>
                    <tr><td>price</td><td><?php echo esc_html($b['price'] ?? 'N/A'); ?></td></tr>
                    <tr><td>rawPrice</td><td><?php echo esc_html($b['rawPrice'] ?? 'N/A'); ?></td></tr>
                    <tr><td>originalPrice</td><td><?php echo esc_html($b['originalPrice'] ?? 'N/A'); ?></td></tr>
                    <tr><td>currency</td><td><?php echo esc_html($b['currency'] ?? 'N/A'); ?></td></tr>
                    <tr><td>inStock</td><td><?php echo isset($b['inStock']) ? ($b['inStock'] ? 'true' : 'false') : 'N/A'; ?></td></tr>
                    <tr><td>customerReview</td><td><?php echo esc_html($b['customerReview'] ?? 'N/A'); ?></td></tr>
                    <tr><td>customerReviewCount</td><td><?php echo esc_html($b['customerReviewCount'] ?? 'N/A'); ?></td></tr>
                    <tr><td>images</td><td><?php echo isset($b['images']) ? count($b['images']) . ' images' : 'N/A'; ?></td></tr>
                    <tr><td>highResolutionImages</td><td><?php echo isset($b['highResolutionImages']) ? count($b['highResolutionImages']) . ' images' : 'N/A'; ?></td></tr>
                    <tr><td>features</td><td><?php echo isset($b['features']) ? count($b['features']) . ' items' : 'N/A'; ?></td></tr>
                    <tr><td>breadCrumbs</td><td><?php echo isset($b['breadCrumbs']) ? count($b['breadCrumbs']) . ' levels' : 'N/A'; ?></td></tr>
                    <tr><td>productDetails</td><td><?php echo isset($b['productDetails']) ? count($b['productDetails']) . ' items' : 'N/A'; ?></td></tr>
                    <tr><td>reviews</td><td><?php echo isset($b['reviews']) ? count($b['reviews']) . ' reviews' : 'N/A'; ?></td></tr>
                </table>

                <?php if (!empty($b['images'][0])): ?>
                    <h2>First Image</h2>
                    <img src="<?php echo esc_url($b['images'][0]); ?>" style="max-width:300px; border-radius:8px;">
                <?php endif; ?>
            <?php endif; ?>

            <h2>Raw JSON Response</h2>
            <pre><code><?php echo esc_html(json_encode($json, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)); ?></code></pre>

        <?php else: ?>
            <h2>Raw Body (not JSON)</h2>
            <pre><code><?php echo esc_html(substr($body, 0, 5000)); ?></code></pre>
        <?php endif; ?>
    <?php endif; ?>

    <h2>Step 4: Server Environment</h2>
    <table>
        <tr><th>Setting</th><th>Value</th></tr>
        <tr><td>PHP Version</td><td><?php echo PHP_VERSION; ?></td></tr>
        <tr><td>WordPress</td><td><?php echo get_bloginfo('version'); ?></td></tr>
        <tr><td>cURL available</td><td><?php echo function_exists('curl_version') ? 'Yes - v' . curl_version()['version'] : 'No'; ?></td></tr>
        <tr><td>allow_url_fopen</td><td><?php echo ini_get('allow_url_fopen') ? 'On' : 'Off'; ?></td></tr>
        <tr><td>max_execution_time</td><td><?php echo ini_get('max_execution_time'); ?>s</td></tr>
        <tr><td>WP HTTP Transport</td><td><?php echo _wp_http_get_object() instanceof \WP_Http ? get_class(_wp_http_get_object()) : 'Unknown'; ?></td></tr>
        <tr><td>Server IP</td><td><?php echo esc_html($_SERVER['SERVER_ADDR'] ?? gethostbyname(gethostname())); ?></td></tr>
    </table>

<?php endif; ?>

    <p style="color:#666; margin-top:30px; font-size:12px;">
        ⚠ DELETE this file after debugging: <code>rm /home/nygarden/productreviews.org/test-crawlbase.php</code>
    </p>
</body>
</html>
