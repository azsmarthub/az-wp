<?php
/**
 * Search Service
 *
 * Unified search service for finding ASINs across different providers.
 * Supports pagination to fetch more results across multiple pages.
 *
 * This service is used by:
 * - QueueProcessor (pro plugin) - for keyword-based content generation
 * - QueueProcessor (cat plugin) - for category keyword queue processing
 *
 * @package AffiliateCMS\Pro\Services
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro\Services;

use AffiliateCMS\Pro\Core\ProviderManager;

class SearchService
{
    private static ?SearchService $instance = null;

    private ProviderManager $providerManager;

    /**
     * Search log for debugging
     */
    private array $searchLog = [];

    /**
     * Last error message
     */
    private ?string $lastError = null;

    /**
     * Last used provider
     */
    private ?string $lastProvider = null;

    /**
     * Get singleton instance
     */
    public static function instance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct()
    {
        $this->providerManager = ProviderManager::instance();
    }

    /**
     * Search ASINs with pagination support
     *
     * Fetches products from Amazon search results across multiple pages
     * until the desired limit is reached or maxPages is exhausted.
     *
     * @param string $keyword Search keyword
     * @param int $limit Maximum ASINs to return (default: 20)
     * @param int $maxPages Maximum pages to fetch (default: 3)
     * @param string $domain Amazon domain (default: amazon.com)
     * @return array ['asins' => [...], 'products' => [...], 'total' => int, 'pages_fetched' => int]
     */
    public function searchAsins(
        string $keyword,
        int $limit = 20,
        int $maxPages = 3,
        string $domain = 'amazon.com'
    ): array {
        $this->searchLog = [];
        $this->lastError = null;
        $this->lastProvider = null;

        $allProducts = [];
        $allAsins = [];
        $pagesFetched = 0;

        $this->log("Starting search for: '{$keyword}' (limit: {$limit}, maxPages: {$maxPages})");

        // Get provider settings
        $settings = get_option('acms_general_settings', []);
        $primaryProvider = $settings['default_provider'] ?? 'crawlbase';
        $fallbackProvider = $settings['fallback_provider'] ?? 'none';

        $this->log("Provider: primary={$primaryProvider}, fallback={$fallbackProvider}");

        for ($page = 1; $page <= $maxPages; $page++) {
            // Check if we have enough ASINs
            if (count($allAsins) >= $limit) {
                $this->log("Reached limit ({$limit} ASINs), stopping search");
                break;
            }

            $this->log("Fetching page {$page}...");

            // Search with pagination
            $results = $this->searchPage($keyword, $domain, $page);
            $pagesFetched++;

            if ($results === null || empty($results)) {
                $this->log("Page {$page}: No results or error - " . ($this->lastError ?? 'empty results'));

                // If first page fails, try fallback provider
                if ($page === 1 && $fallbackProvider !== 'none' && $this->lastProvider === $primaryProvider) {
                    $this->log("Trying fallback provider for page 1...");
                    $results = $this->searchPageWithProvider($keyword, $domain, $page, $fallbackProvider);

                    if ($results !== null && !empty($results)) {
                        $this->lastProvider = $fallbackProvider;
                    }
                }

                // Still no results? Stop pagination
                if ($results === null || empty($results)) {
                    $this->log("No more results available, stopping pagination");
                    break;
                }
            }

            // Process results
            $newAsins = 0;
            foreach ($results as $product) {
                $asin = $product['asin'] ?? '';
                if (empty($asin)) {
                    continue;
                }

                // Skip duplicates
                if (in_array($asin, $allAsins)) {
                    continue;
                }

                $allAsins[] = $asin;
                $allProducts[] = $product;
                $newAsins++;

                // Stop if we have enough
                if (count($allAsins) >= $limit) {
                    break;
                }
            }

            $this->log("Page {$page}: Found {$newAsins} new ASINs (total: " . count($allAsins) . ")");

            // If this page returned fewer results than expected, likely no more pages
            if (count($results) < 10) {
                $this->log("Page returned fewer than 10 results, assuming end of results");
                break;
            }

            // Small delay between pages to avoid rate limiting
            if ($page < $maxPages && count($allAsins) < $limit) {
                usleep(500000); // 0.5 second delay
            }
        }

        // Trim to limit
        $allAsins = array_slice($allAsins, 0, $limit);
        $allProducts = array_slice($allProducts, 0, $limit);

        $this->log("Search completed: " . count($allAsins) . " ASINs from {$pagesFetched} pages");

        return [
            'asins' => $allAsins,
            'products' => $allProducts,
            'total' => count($allAsins),
            'pages_fetched' => $pagesFetched,
            'provider' => $this->lastProvider,
            'log' => $this->searchLog,
        ];
    }

    /**
     * Search a single page using configured provider priority
     *
     * @param string $keyword Search keyword
     * @param string $domain Amazon domain
     * @param int $page Page number
     * @return array|null Array of products or null on failure
     */
    private function searchPage(string $keyword, string $domain, int $page): ?array
    {
        // Get provider settings
        $settings = get_option('acms_general_settings', []);
        $primaryProvider = $settings['default_provider'] ?? 'crawlbase';

        return $this->searchPageWithProvider($keyword, $domain, $page, $primaryProvider);
    }

    /**
     * Search a single page with specific provider
     *
     * @param string $keyword Search keyword
     * @param string $domain Amazon domain
     * @param int $page Page number
     * @param string $provider Provider name ('crawlbase' or 'paapi')
     * @return array|null Array of products or null on failure
     */
    private function searchPageWithProvider(
        string $keyword,
        string $domain,
        int $page,
        string $provider
    ): ?array {
        $this->lastProvider = $provider;

        // Use reflection or direct access to provider instances
        // Since ProviderManager doesn't expose providers directly, we use searchProducts method
        // For now, we call searchProducts which already has retry logic

        // Note: We need to add page support to ProviderManager
        $result = $this->searchWithProviderAndPage($keyword, $domain, $page, $provider);

        if ($result === null) {
            $this->lastError = $this->providerManager->getLastError();
        }

        return $result;
    }

    /**
     * Search with specific provider and page number
     *
     * This method accesses providers through ProviderManager
     *
     * @param string $keyword Search keyword
     * @param string $domain Amazon domain
     * @param int $page Page number
     * @param string $provider Provider name
     * @return array|null Array of products or null on failure
     */
    private function searchWithProviderAndPage(
        string $keyword,
        string $domain,
        int $page,
        string $provider
    ): ?array {
        // Get provider instances via ProviderManager
        // Since ProviderManager has searchProducts, we need to extend it or use alternative approach

        // For now, use the searchProductsWithPage method if available
        // Otherwise fall back to regular search for page 1
        return $this->providerManager->searchProductsWithPage($keyword, $domain, $page);
    }

    /**
     * Simple search (single page, for backward compatibility)
     *
     * @param string $keyword Search keyword
     * @param string $domain Amazon domain
     * @return array|null Array of products or null on failure
     */
    public function search(string $keyword, string $domain = 'amazon.com'): ?array
    {
        $result = $this->searchAsins($keyword, 20, 1, $domain);
        return $result['products'] ?? null;
    }

    /**
     * Add log entry
     */
    private function log(string $message): void
    {
        $timestamp = date('H:i:s');
        $this->searchLog[] = "[{$timestamp}] {$message}";
    }

    /**
     * Get search log
     */
    public function getSearchLog(): array
    {
        return $this->searchLog;
    }

    /**
     * Get last error
     */
    public function getLastError(): ?string
    {
        return $this->lastError;
    }

    /**
     * Get last used provider
     */
    public function getLastProvider(): ?string
    {
        return $this->lastProvider;
    }
}
