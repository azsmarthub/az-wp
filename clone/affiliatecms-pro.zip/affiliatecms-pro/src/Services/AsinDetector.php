<?php
/**
 * ASIN Detector Service
 *
 * Detects Amazon ASINs from ACMS shortcodes in posts, pages, and custom content.
 * Categorizes ASINs by source: shortcode, URL, or raw text.
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro\Services;

use AffiliateCMS\Pro\Database\Schema;

class AsinDetector
{
    private static ?AsinDetector $instance = null;

    /**
     * Shortcode patterns to detect ASINs from
     * Product Display: [acms_list asin="..."]
     */
    private const SHORTCODE_PATTERNS = [
        // ACMS product display shortcodes
        '/\[acms_(?:card|grid|list|table|link)\s+[^\]]*asin=["\']([^"\']+)["\']/i',
        // Legacy AZS shortcodes for compatibility
        '/\[azs_(?:card|grid|list|table|link)\s+[^\]]*asin=["\']([^"\']+)["\']/i',
    ];

    /**
     * Source type constants for categorized extraction
     */
    public const SOURCE_SHORTCODE = 'shortcode';
    public const SOURCE_URL = 'url';
    public const SOURCE_RAW = 'raw';

    /**
     * Amazon URL patterns
     */
    private const AMAZON_URL_PATTERNS = [
        // Standard product URLs
        '/amazon\.[a-z.]+\/(?:dp|gp\/product|exec\/obidos\/asin)\/([A-Z0-9]{10})/i',
        // Short URLs
        '/amzn\.[a-z]+\/([A-Z0-9]{10})/i',
        '/a\.co\/d\/([A-Z0-9]{10})/i',
    ];

    /**
     * Common false positives to exclude
     */
    private const ASIN_BLACKLIST = [
        'BACKGROUND', 'FONTFAMILY', 'FONTWEIGHT', 'LINKTARGET', 'TYPOGRAPHY',
        'ALIGNITEMS', 'BORDERLEFT', 'FONTSIZE10', 'LINEHEIGHT', 'MARGINTOP1',
        'CONTROLLER', 'JAVASCRIPT', 'SCREENSHOT', 'FOREGROUND', 'STYLESHEET',
        'WASHINGTON', 'CALIFORNIA', 'PITTSBURGH', 'BIRMINGHAM', 'PROVIDENCE',
        'BASKETBALL', 'VOLLEYBALL', 'SKATEBOARD', 'TABLESPOON', 'EVERYTHING',
        'PLAYGROUND', 'UNDERSTAND', 'HELICOPTER', 'STRAWBERRY',
    ];

    public static function instance(): AsinDetector
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {}

    /**
     * Extract ASINs from shortcodes in content
     */
    public function extractAsins(string $content): array
    {
        $asins = [];

        foreach (self::SHORTCODE_PATTERNS as $pattern) {
            if (preg_match_all($pattern, $content, $matches)) {
                foreach ($matches[1] as $asinString) {
                    // Handle comma-separated ASINs
                    $asinList = array_map('trim', explode(',', $asinString));
                    foreach ($asinList as $asin) {
                        if ($this->isValidAsin($asin)) {
                            $asins[] = strtoupper($asin);
                        }
                    }
                }
            }
        }

        return array_unique($asins);
    }

    /**
     * Extract ASINs from Amazon URLs
     */
    public function extractAsinsFromUrls(string $content): array
    {
        $asins = [];

        foreach (self::AMAZON_URL_PATTERNS as $pattern) {
            if (preg_match_all($pattern, $content, $matches)) {
                foreach ($matches[1] as $asin) {
                    if ($this->isValidAsin($asin, false)) {
                        $asins[] = strtoupper($asin);
                    }
                }
            }
        }

        return array_unique($asins);
    }

    /**
     * Extract raw ASINs (excluding those already found)
     */
    public function extractRawAsins(string $content, array $excludeAsins = []): array
    {
        $asins = [];
        $excludeMap = array_flip(array_map('strtoupper', $excludeAsins));

        if (preg_match_all('/\b([A-Z0-9]{10})\b/i', $content, $matches)) {
            foreach ($matches[1] as $potentialAsin) {
                $asin = strtoupper($potentialAsin);
                if (isset($excludeMap[$asin])) {
                    continue;
                }
                if ($this->isValidAsin($asin, false)) {
                    $asins[] = $asin;
                }
            }
        }

        return array_unique($asins);
    }

    /**
     * Extract ASINs categorized by source type
     *
     * @return array{shortcode: string[], url: string[], raw: string[]}
     */
    public function extractAsinsCategorized(string $content): array
    {
        $result = [
            self::SOURCE_SHORTCODE => [],
            self::SOURCE_URL => [],
            self::SOURCE_RAW => [],
        ];

        // 1. Shortcodes (highest priority)
        $result[self::SOURCE_SHORTCODE] = $this->extractAsins($content);

        // 2. Amazon URLs
        $result[self::SOURCE_URL] = $this->extractAsinsFromUrls($content);
        $result[self::SOURCE_URL] = array_values(array_diff(
            $result[self::SOURCE_URL],
            $result[self::SOURCE_SHORTCODE]
        ));

        // 3. Raw ASINs (excluding already found)
        $alreadyFound = array_merge($result[self::SOURCE_SHORTCODE], $result[self::SOURCE_URL]);
        $result[self::SOURCE_RAW] = $this->extractRawAsins($content, $alreadyFound);

        return $result;
    }

    /**
     * Validate ASIN format
     */
    private function isValidAsin(string $asin, bool $strict = true): bool
    {
        if (strlen($asin) !== 10) {
            return false;
        }

        $asin = strtoupper($asin);

        if (!preg_match('/^[A-Z0-9]{10}$/', $asin)) {
            return false;
        }

        // ASIN must start with B
        if ($asin[0] !== 'B') {
            return false;
        }

        if (in_array($asin, self::ASIN_BLACKLIST, true)) {
            return false;
        }

        // Standard format: B0 + 8 alphanumeric
        if (preg_match('/^B0[A-Z0-9]{8}$/', $asin)) {
            return true;
        }

        if ($strict) {
            return false;
        }

        // Non-strict: Accept any B-prefix with at least 2 digits
        if (preg_match('/^B[A-Z0-9]{9}$/', $asin)) {
            $digitCount = preg_match_all('/\d/', $asin);
            return $digitCount >= 2;
        }

        return false;
    }

    /**
     * Save an ASIN to the database
     */
    public function saveAsin(string $asin, int $sourcePostId = 0, bool $strictValidation = true): bool
    {
        global $wpdb;

        $asin = strtoupper(trim($asin));

        if (!$this->isValidAsin($asin, $strictValidation)) {
            return false;
        }

        $table = Schema::productsTable();

        // Check if exists
        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT id, post_ids, post_count FROM {$table} WHERE asin = %s",
            $asin
        ));

        if ($existing) {
            if ($sourcePostId > 0) {
                $this->updateProductPostIds((int) $existing->id, $sourcePostId, $existing->post_ids);
            }
            return false;
        }

        // Insert new
        $data = [
            'asin' => $asin,
            'status' => 'pending',
            'created_at' => current_time('mysql', true),
            'updated_at' => current_time('mysql', true),
        ];

        if ($sourcePostId > 0) {
            $data['source_post_id'] = $sourcePostId;
            $data['post_ids'] = (string) $sourcePostId;
            $data['post_count'] = 1;
        }

        return $wpdb->insert($table, $data) !== false;
    }

    /**
     * Update product post associations
     */
    private function updateProductPostIds(int $productId, int $postId, ?string $currentPostIds): void
    {
        global $wpdb;

        $postIdsArray = [];
        if (!empty($currentPostIds)) {
            $postIdsArray = array_map('intval', array_filter(explode(',', $currentPostIds)));
        }

        if (!in_array($postId, $postIdsArray, true)) {
            $postIdsArray[] = $postId;
            $postIdsArray = array_unique($postIdsArray);

            $wpdb->update(
                Schema::productsTable(),
                [
                    'post_ids' => implode(',', $postIdsArray),
                    'post_count' => count($postIdsArray),
                    'updated_at' => current_time('mysql', true),
                ],
                ['id' => $productId],
                ['%s', '%d', '%s'],
                ['%d']
            );
        }
    }

    /**
     * Add post to product by ASIN
     */
    public function addPostToProduct(string $asin, int $postId): bool
    {
        global $wpdb;

        $asin = strtoupper(trim($asin));
        $table = Schema::productsTable();

        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT id, post_ids FROM {$table} WHERE asin = %s",
            $asin
        ));

        if (!$existing) {
            return false;
        }

        $this->updateProductPostIds((int) $existing->id, $postId, $existing->post_ids);
        return true;
    }
}
