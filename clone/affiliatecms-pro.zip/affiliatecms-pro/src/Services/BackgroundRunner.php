<?php
/**
 * Background Runner Service
 *
 * Handles WP Cron hooks for background queue processing.
 * Registers hooks and processes queue items asynchronously.
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro\Services;

use AffiliateCMS\Pro\Core\QueueProcessor;

class BackgroundRunner
{
    /**
     * Hook name for processing single queue item
     */
    public const HOOK_PROCESS_ITEM = 'acms_process_queue_item';

    /**
     * Hook name for processing next pending item
     */
    public const HOOK_PROCESS_NEXT = 'acms_process_queue_next';

    /**
     * Hook name for periodic queue check
     */
    public const HOOK_QUEUE_CHECK = 'acms_queue_check';

    /**
     * Hook name for scraping ASINs after queue completion
     */
    public const HOOK_SCRAPE_ASINS = 'acms_scrape_asins';

    /**
     * Singleton instance
     */
    private static ?BackgroundRunner $instance = null;

    /**
     * Get singleton instance
     */
    public static function instance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Register all hooks
     */
    public function register(): void
    {
        // Hook for processing specific queue item
        add_action(self::HOOK_PROCESS_ITEM, [$this, 'processItem'], 10, 1);

        // Hook for processing next pending item
        add_action(self::HOOK_PROCESS_NEXT, [$this, 'processNext']);

        // Hook for periodic queue check
        add_action(self::HOOK_QUEUE_CHECK, [$this, 'checkQueue']);

        // Hook fired by CronController /cron/queue endpoint
        add_action('acms_process_queue', [$this, 'processQueueCron']);

        // Hook for scraping ASINs after queue completion
        add_action(self::HOOK_SCRAPE_ASINS, [$this, 'scrapeAsins'], 10, 1);

        // Register custom cron interval
        add_filter('cron_schedules', [$this, 'addCronIntervals']);
    }

    /**
     * Add custom cron intervals
     */
    public function addCronIntervals(array $schedules): array
    {
        $schedules['acms_every_minute'] = [
            'interval' => 60,
            'display' => __('Every Minute', 'affiliatecms-pro')
        ];

        $schedules['acms_every_five_minutes'] = [
            'interval' => 300,
            'display' => __('Every 5 Minutes', 'affiliatecms-pro')
        ];

        return $schedules;
    }

    /**
     * Process specific queue item by ID
     *
     * @param int $queueId Queue item ID
     */
    public function processItem(int $queueId): void
    {
        $processor = new QueueProcessor(true);
        $result = $processor->processItem($queueId);

        if (!$result['success']) {
            error_log("[ACMS BackgroundRunner] Item #{$queueId} FAILED: {$result['message']}");
        }

        // If there are more pending items and we're in auto-process mode,
        // schedule the next one
        if ($result['success'] && $this->hasMorePendingItems()) {
            $this->scheduleNext();
        }
    }

    /**
     * Process next pending item in queue
     */
    public function processNext(): void
    {
        $processor = new QueueProcessor(true);
        $result = $processor->processNext();

        if (!$result['success']) {
            error_log("[ACMS BackgroundRunner] processNext FAILED: {$result['message']}");
        }
    }

    /**
     * Process queue via cron endpoint — directly process next pending item
     * Called by CronController::runQueueCron() via do_action('acms_process_queue')
     */
    public function processQueueCron(): void
    {
        global $wpdb;
        $table = \AffiliateCMS\Pro\Database\Schema::queueTable();

        // Check if any item is already processing
        $processingCount = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$table} WHERE status = 'processing'"
        );

        if ($processingCount > 0) {
            return; // Another worker is running
        }

        // Count pending items
        $pendingCount = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$table} WHERE status = 'pending'"
        );

        if ($pendingCount === 0) {
            return;
        }

        // Process next item directly (we're in a cron HTTP request, synchronous is fine)
        $processor = new QueueProcessor(true);
        $result = $processor->processNext();

        if (!$result['success']) {
            error_log("[ACMS Queue Cron] processNext FAILED: {$result['message']}");
        }
    }

    /**
     * Check queue for pending items (periodic check)
     */
    public function checkQueue(): void
    {
        global $wpdb;
        $table = \AffiliateCMS\Pro\Database\Schema::queueTable();

        // Count pending items
        $pendingCount = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$table} WHERE status = 'pending'"
        );

        if ($pendingCount > 0) {
            // Check if any processing is already running
            $processingCount = (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM {$table} WHERE status = 'processing'"
            );

            if ($processingCount === 0) {
                // No items currently processing, start next one
                $this->scheduleNext();
            }
        }
    }

    /**
     * Schedule processing of next pending item
     */
    public function scheduleNext(): void
    {
        if (!wp_next_scheduled(self::HOOK_PROCESS_NEXT)) {
            wp_schedule_single_event(time(), self::HOOK_PROCESS_NEXT);
        }
    }

    /**
     * Schedule processing of specific item
     */
    public function scheduleItem(int $queueId): void
    {
        wp_schedule_single_event(time(), self::HOOK_PROCESS_ITEM, ['queue_id' => $queueId]);
    }

    /**
     * Start periodic queue checking
     */
    public function startQueueCheck(): void
    {
        if (!wp_next_scheduled(self::HOOK_QUEUE_CHECK)) {
            wp_schedule_event(time(), 'acms_every_minute', self::HOOK_QUEUE_CHECK);
        }
    }

    /**
     * Stop periodic queue checking
     */
    public function stopQueueCheck(): void
    {
        $timestamp = wp_next_scheduled(self::HOOK_QUEUE_CHECK);
        if ($timestamp) {
            wp_unschedule_event($timestamp, self::HOOK_QUEUE_CHECK);
            error_log('[ACMS BackgroundRunner] Stopped periodic queue check');
        }
    }

    /**
     * Scrape ASINs after queue completion
     *
     * @param array $asins List of ASINs to scrape
     */
    public function scrapeAsins(array $asins): void
    {
        if (empty($asins)) {
            return;
        }

        error_log('[ACMS BackgroundRunner] Scraping ' . count($asins) . ' ASINs after queue completion');

        global $wpdb;
        $productsTable = \AffiliateCMS\Pro\Database\Schema::productsTable();

        // Get provider manager
        $providerManager = \AffiliateCMS\Pro\Core\ProviderManager::instance();

        $scraped = 0;
        $failed = 0;

        foreach ($asins as $asin) {
            // Get product from database
            $product = $wpdb->get_row($wpdb->prepare(
                "SELECT id, status FROM {$productsTable} WHERE asin = %s",
                $asin
            ), ARRAY_A);

            if (!$product) {
                error_log("[ACMS BackgroundRunner] ASIN {$asin} not found in products table");
                continue;
            }

            // Skip if already scraped
            if ($product['status'] === 'scraped') {
                error_log("[ACMS BackgroundRunner] ASIN {$asin} already scraped, skipping");
                continue;
            }

            // Mark as processing
            $wpdb->update($productsTable, ['status' => 'processing'], ['id' => $product['id']]);

            try {
                // Scrape the product
                $data = $providerManager->scrape($asin);

                if ($data) {
                    // Extract log metadata before building update data
                    $providerName = $data['provider'] ?? $providerManager->getLastUsedProvider();
                    $log = $data['log'] ?? [];
                    $fieldLog = $data['field_log'] ?? [];

                    // Calculate score from rating (same as manual scrape)
                    $rating = isset($data['rating']) ? floatval($data['rating']) : null;
                    $scoreManager = \AffiliateCMS\Pro\Services\ScoreManager::instance();
                    $score = $scoreManager->calculateScore($rating);

                    // Build scrape_log for diagnostics
                    $scrapeLog = \AffiliateCMS\Pro\Core\Bootstrap::buildScrapeLog(
                        $asin, $providerName, $log, $fieldLog, $data
                    );

                    // Update product with scraped data
                    $updateData = [
                        'title' => $data['title'] ?? '',
                        'brand' => $data['brand'] ?? '',
                        'price' => $data['price'] ?? null,
                        'original_price' => $data['original_price'] ?? null,
                        'currency' => $data['currency'] ?? 'USD',
                        'rating' => $rating,
                        'reviews_count' => $data['reviews_count'] ?? 0,
                        'score' => $score,
                        'in_stock' => $data['in_stock'] ?? 1,
                        'is_prime' => $data['is_prime'] ?? 0,
                        'image_url' => $data['image_url'] ?? '',
                        'images_gallery' => !empty($data['images_gallery']) ? wp_json_encode($data['images_gallery']) : null,
                        'description' => $data['description'] ?? null,
                        'features' => !empty($data['features']) ? wp_json_encode($data['features']) : null,
                        'category' => $data['category'] ?? '',
                        'category_path' => $data['category_path'] ?? '',
                        'product_information' => !empty($data['product_information']) ? wp_json_encode($data['product_information']) : null,
                        'specifications' => !empty($data['specifications']) ? wp_json_encode($data['specifications']) : null,
                        'best_sellers_rank' => $data['best_sellers_rank'] ?? null,
                        'seller_info' => !empty($data['seller_info']) ? wp_json_encode($data['seller_info']) : null,
                        'reviews_data' => !empty($data['reviews_data']) ? wp_json_encode($data['reviews_data']) : null,
                        'top_reviews' => !empty($data['top_reviews']) ? wp_json_encode($data['top_reviews']) : null,
                        'reviews_summary' => !empty($data['reviews_summary']) ? wp_json_encode($data['reviews_summary']) : null,
                        'scrape_log' => wp_json_encode($scrapeLog),
                        'status' => 'scraped',
                        'last_provider' => $providerName,
                        'last_scraped_at' => current_time('mysql'),
                        'error_message' => null,
                        'ai_status' => 'queued', // Queue for AI content generation immediately
                    ];

                    $wpdb->update($productsTable, $updateData, ['id' => $product['id']]);
                    $scraped++;

                    // Schedule delayed re-scrape if price/rating still missing
                    \AffiliateCMS\Pro\Core\Bootstrap::scheduleIncompleteRescrape(
                        (int) $product['id'], $asin, $data
                    );

                    // Create or get brand term if brand data is available
                    if (!empty($data['brand'])) {
                        $brandTermId = \AffiliateCMS\Pro\Core\PostTypeManager::getOrCreateBrand($data['brand']);
                        if ($brandTermId) {
                            $wpdb->update($productsTable, ['brand_term_id' => $brandTermId], ['id' => $product['id']]);
                            error_log("[ACMS BackgroundRunner] Created/linked brand term #{$brandTermId} for '{$data['brand']}'");
                        }
                    }

                    // Fire hook to trigger immediate AI processing
                    do_action('acms_product_scraped', $asin, $data);

                    error_log("[ACMS BackgroundRunner] Successfully scraped ASIN {$asin}");
                } else {
                    $error = 'Scrape returned no data';
                    $log = $providerManager->getScrapeLog();

                    // Save failure log for diagnostics
                    $failureLog = \AffiliateCMS\Pro\Core\Bootstrap::buildScrapeLog(
                        $asin, 'none', $log, [], [], $error
                    );

                    $wpdb->update($productsTable, [
                        'status' => 'failed',
                        'error_message' => $error,
                        'scrape_log' => wp_json_encode($failureLog),
                    ], ['id' => $product['id']]);
                    $failed++;
                    error_log("[ACMS BackgroundRunner] Failed to scrape ASIN {$asin}: no data");
                }
            } catch (\Exception $e) {
                $log = $providerManager->getScrapeLog();
                $failureLog = \AffiliateCMS\Pro\Core\Bootstrap::buildScrapeLog(
                    $asin, 'none', $log, [], [], $e->getMessage()
                );

                $wpdb->update($productsTable, [
                    'status' => 'failed',
                    'error_message' => $e->getMessage(),
                    'scrape_log' => wp_json_encode($failureLog),
                ], ['id' => $product['id']]);
                $failed++;
                error_log("[ACMS BackgroundRunner] Exception scraping ASIN {$asin}: " . $e->getMessage());
            }

            // Small delay between scrapes to avoid rate limiting
            usleep(500000); // 0.5 seconds
        }

        error_log("[ACMS BackgroundRunner] Scrape complete: {$scraped} successful, {$failed} failed");
    }

    /**
     * Schedule ASIN scraping
     *
     * @param array $asins List of ASINs to scrape
     */
    public function scheduleScrapeAsins(array $asins): void
    {
        if (empty($asins)) {
            return;
        }

        // Schedule via WP-Cron (server cron handles primary scraping via /automation/process-scheduled)
        wp_schedule_single_event(time() + 2, self::HOOK_SCRAPE_ASINS, [$asins]);
    }

    /**
     * Check if there are more pending items
     */
    private function hasMorePendingItems(): bool
    {
        global $wpdb;
        $table = \AffiliateCMS\Pro\Database\Schema::queueTable();

        return (bool) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$table} WHERE status = 'pending' LIMIT 1"
        );
    }

    /**
     * Clear all scheduled events (for plugin deactivation)
     */
    public function clearAllScheduled(): void
    {
        // Clear queue check
        $timestamp = wp_next_scheduled(self::HOOK_QUEUE_CHECK);
        if ($timestamp) {
            wp_unschedule_event($timestamp, self::HOOK_QUEUE_CHECK);
        }

        // Clear all single events (can't easily clear these, they'll just fail)
        error_log('[ACMS BackgroundRunner] Cleared scheduled events');
    }

    /**
     * Get queue status for debugging
     */
    public function getStatus(): array
    {
        global $wpdb;
        $table = \AffiliateCMS\Pro\Database\Schema::queueTable();

        $status = [
            'pending' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE status = 'pending'"),
            'processing' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE status = 'processing'"),
            'completed' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE status = 'completed'"),
            'failed' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE status = 'failed'"),
            'queue_check_scheduled' => wp_next_scheduled(self::HOOK_QUEUE_CHECK) !== false,
            'next_process_scheduled' => wp_next_scheduled(self::HOOK_PROCESS_NEXT) !== false,
        ];

        return $status;
    }
}
