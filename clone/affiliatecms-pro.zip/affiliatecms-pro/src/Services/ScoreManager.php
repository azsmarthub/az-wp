<?php
/**
 * Score Manager
 *
 * Simple scoring system based on Amazon rating
 * Default: 7.0/10 (70 points)
 * Max: 9.9/10 (99 points) - capped for realism
 *
 * @package AffiliateCMS\Pro\Services
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro\Services;

class ScoreManager
{
    private static ?ScoreManager $instance = null;

    /**
     * Get singleton instance
     */
    public static function instance(): ScoreManager
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Calculate score from Amazon rating
     *
     * Logic:
     * - No rating: 0 points (hidden until scraped)
     * - Base: 70 points (7.0/10) + rating bonus
     * - Bonus: rating * 6 (max +30 points for 5 stars)
     * - Cap: 99 points (9.9/10) max
     *
     * Examples:
     * - No rating: 0 points → hidden
     * - 5.0 rating: 100 → capped to 99 → 9.9
     * - 4.5 rating: 97 → 9.7
     * - 4.0 rating: 94 → 9.4
     * - 3.0 rating: 88 → 8.8
     *
     * @param float|null $amazonRating Amazon rating (0-5 stars)
     * @return int Score (0-99, typically 70-99 when rated)
     */
    public function calculateScore(?float $amazonRating): int
    {
        // No rating = no score (hidden until scraped)
        if ($amazonRating === null || $amazonRating <= 0) {
            return 0;
        }

        // Base score + rating bonus
        $score = 70 + ($amazonRating * 6); // Max +30 points for 5 stars

        // Cap at 99 (9.9 display) and ensure minimum 0
        return min(99, max(0, (int) round($score)));
    }

    /**
     * Format score for display (e.g., "9.5" from 95)
     *
     * @param int $score Score value (0-99)
     * @return string Formatted score (e.g., "9.5")
     */
    public function formatScore(int $score): string
    {
        // Convert 0-99 scale to 0-9.9 scale for display
        $displayValue = $score / 10;
        return number_format($displayValue, 1);
    }

    /**
     * Get score label based on score value
     *
     * @param int $score Score value (0-99)
     * @return string Label
     */
    public function getScoreLabel(int $score): string
    {
        if ($score >= 95) {
            return __('Excellent', 'affiliatecms-pro');
        }
        if ($score >= 90) {
            return __('Very Good', 'affiliatecms-pro');
        }
        if ($score >= 80) {
            return __('Good', 'affiliatecms-pro');
        }
        if ($score >= 70) {
            return __('Fair', 'affiliatecms-pro');
        }
        return __('Average', 'affiliatecms-pro');
    }

    /**
     * Get score color class based on score value
     *
     * @param int $score Score value (0-99)
     * @return string CSS class suffix
     */
    public function getScoreColorClass(int $score): string
    {
        if ($score >= 95) {
            return 'excellent';
        }
        if ($score >= 85) {
            return 'very-good';
        }
        if ($score >= 75) {
            return 'good';
        }
        if ($score >= 65) {
            return 'fair';
        }
        return 'average';
    }

    /**
     * Get score data for display
     *
     * @param float|null $amazonRating Amazon rating (0-5 stars)
     * @return array Score data with formatted values
     */
    public function getScoreData(?float $amazonRating): array
    {
        $score = $this->calculateScore($amazonRating);

        return [
            'score' => $score,
            'formatted_score' => $this->formatScore($score),
            'label' => $this->getScoreLabel($score),
            'color_class' => $this->getScoreColorClass($score),
        ];
    }
}
