<?php
/**
 * Post ASIN Sync Service
 *
 * Automatically detects ASINs in post content when posts are saved/updated
 * and updates the product post_ids associations.
 *
 * @package AffiliateCMS\Pro\Services
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro\Services;

use AffiliateCMS\Pro\Database\Schema;

class PostAsinSync
{
    private static ?PostAsinSync $instance = null;

    /**
     * Get singleton instance
     */
    public static function instance(): PostAsinSync
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Private constructor for singleton
     */
    private function __construct()
    {
    }

    /**
     * Register WordPress hooks
     */
    public function register(): void
    {
        // Hook into post save - runs after post is saved/updated
        add_action('save_post', [$this, 'onPostSave'], 20, 3);

        // Hook into post delete - remove post from product associations
        add_action('before_delete_post', [$this, 'onPostDelete'], 10, 1);

        // Hook into post trash - optionally remove from associations
        add_action('wp_trash_post', [$this, 'onPostTrash'], 10, 1);
    }

    /**
     * Handle post save/update
     *
     * @param int      $postId Post ID
     * @param \WP_Post $post   Post object
     * @param bool     $update Whether this is an update
     */
    public function onPostSave(int $postId, \WP_Post $post, bool $update): void
    {
        // Skip autosaves
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        // Skip revisions
        if (wp_is_post_revision($postId)) {
            return;
        }

        // Skip if not a valid post type (only public post types)
        if (!$this->isValidPostType($post->post_type)) {
            return;
        }

        // Skip if post is not published (we only track published content)
        if ($post->post_status !== 'publish') {
            return;
        }

        // Detect ASINs in content
        $this->syncPostAsins($postId, $post->post_content);
    }

    /**
     * Handle post delete
     *
     * @param int $postId Post ID
     */
    public function onPostDelete(int $postId): void
    {
        $this->removePostFromAllProducts($postId);
    }

    /**
     * Handle post trash
     *
     * @param int $postId Post ID
     */
    public function onPostTrash(int $postId): void
    {
        // Optionally remove from associations when trashed
        // For now, we keep the association until permanently deleted
        // Uncomment below to remove on trash:
        // $this->removePostFromAllProducts($postId);
    }

    /**
     * Sync ASINs found in post content with product associations
     *
     * @param int    $postId  Post ID
     * @param string $content Post content
     */
    private function syncPostAsins(int $postId, string $content): void
    {
        $detector = AsinDetector::instance();

        // Extract ASINs from shortcodes only (most reliable source)
        $categorized = $detector->extractAsinsCategorized($content);
        $shortcodeAsins = $categorized['shortcode'] ?? [];

        if (empty($shortcodeAsins)) {
            return;
        }

        // Add post to each found ASIN's product record
        foreach ($shortcodeAsins as $asin) {
            $detector->addPostToProduct($asin, $postId);
        }
    }

    /**
     * Remove post from all product associations
     *
     * @param int $postId Post ID
     */
    private function removePostFromAllProducts(int $postId): void
    {
        global $wpdb;

        $table = Schema::productsTable();

        // Find all products that reference this post
        $products = $wpdb->get_results($wpdb->prepare(
            "SELECT id, post_ids FROM {$table} WHERE post_ids LIKE %s OR post_ids LIKE %s OR post_ids LIKE %s OR post_ids = %s",
            '%,' . $postId . ',%', // Middle
            '%,' . $postId,        // End
            $postId . ',%',        // Start
            (string) $postId       // Only one
        ));

        foreach ($products as $product) {
            $this->removePostFromProduct((int) $product->id, $postId, $product->post_ids);
        }
    }

    /**
     * Remove a specific post from a product's associations
     *
     * @param int    $productId      Product ID
     * @param int    $postId         Post ID to remove
     * @param string $currentPostIds Current post_ids CSV
     */
    private function removePostFromProduct(int $productId, int $postId, string $currentPostIds): void
    {
        global $wpdb;

        $postIdsArray = array_map('intval', array_filter(explode(',', $currentPostIds)));
        $postIdsArray = array_diff($postIdsArray, [$postId]);
        $postIdsArray = array_values($postIdsArray); // Re-index

        $wpdb->update(
            Schema::productsTable(),
            [
                'post_ids' => !empty($postIdsArray) ? implode(',', $postIdsArray) : null,
                'post_count' => count($postIdsArray),
                'updated_at' => current_time('mysql', true),
            ],
            ['id' => $productId],
            ['%s', '%d', '%s'],
            ['%d']
        );
    }

    /**
     * Check if post type should be tracked
     *
     * @param string $postType Post type slug
     * @return bool
     */
    private function isValidPostType(string $postType): bool
    {
        // Built-in WordPress types
        $validTypes = ['post', 'page'];

        // Add custom ACMS post types
        $acmsTypes = ['acms_reviews', 'acms_comparisons', 'acms_guides'];
        $validTypes = array_merge($validTypes, $acmsTypes);

        // Allow filtering for custom post types
        $validTypes = apply_filters('acms_sync_post_types', $validTypes);

        return in_array($postType, $validTypes, true);
    }

    /**
     * Manually sync all posts (for bulk operations)
     *
     * @param array $postTypes Post types to sync
     * @return array Stats about sync
     */
    public function syncAllPosts(array $postTypes = ['post', 'page']): array
    {
        $stats = [
            'posts_processed' => 0,
            'asins_linked' => 0,
            'errors' => 0,
        ];

        $posts = get_posts([
            'post_type' => $postTypes,
            'post_status' => 'publish',
            'posts_per_page' => -1,
            'fields' => 'all',
        ]);

        foreach ($posts as $post) {
            try {
                $this->syncPostAsins($post->ID, $post->post_content);
                $stats['posts_processed']++;
            } catch (\Exception $e) {
                $stats['errors']++;
            }
        }

        return $stats;
    }
}
