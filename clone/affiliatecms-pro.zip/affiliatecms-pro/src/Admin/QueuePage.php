<?php
/**
 * Queue Admin Page
 *
 * @package AffiliateCMS\Pro\Admin
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro\Admin;

use AffiliateCMS\Pro\Database\Schema;
use AffiliateCMS\Pro\Core\PostTypeManager;

class QueuePage
{
    /**
     * Render the queue page
     */
    public function render(): void
    {
        $data = $this->getInitialData();

        // Pass data to template
        $stats = $data['stats'];
        $postTypes = $data['postTypes'];

        include ACMS_PLUGIN_DIR . 'templates/admin/queue-page.php';
    }

    /**
     * Get initial data for the page
     */
    private function getInitialData(): array
    {
        global $wpdb;

        $tableName = Schema::queueTable();

        // Get stats
        $stats = [
            'total' => 0,
            'pending' => 0,
            'processing' => 0,
            'completed' => 0,
            'failed' => 0,
            'paused' => 0,
        ];

        // Check if table exists
        $tableExists = $wpdb->get_var(
            $wpdb->prepare(
                "SHOW TABLES LIKE %s",
                $tableName
            )
        );

        if ($tableExists) {
            $stats['total'] = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$tableName}");
            $stats['pending'] = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$tableName} WHERE status = 'pending'");
            $stats['processing'] = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$tableName} WHERE status = 'processing'");
            $stats['completed'] = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$tableName} WHERE status = 'completed'");
            $stats['failed'] = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$tableName} WHERE status = 'failed'");
            $stats['paused'] = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$tableName} WHERE status = 'paused'");
        }

        // Get all post types (show all, not just enabled ones)
        // Add WordPress built-in post types first
        $postTypes = [
            [
                'value' => 'post',
                'label' => 'Post',
                'enabled' => true,
            ],
            [
                'value' => 'page',
                'label' => 'Page',
                'enabled' => true,
            ],
        ];

        // Then add custom post types
        $postTypeSettings = PostTypeManager::getSettings();
        foreach ($postTypeSettings as $key => $config) {
            $postTypes[] = [
                'value' => 'acms_' . $key,
                'label' => $config['menu_name'] ?? ucfirst($key),
                'enabled' => !empty($config['enabled']),
            ];
        }

        return [
            'stats' => $stats,
            'postTypes' => $postTypes,
        ];
    }
}
