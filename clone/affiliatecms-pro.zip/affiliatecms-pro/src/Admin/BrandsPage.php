<?php
/**
 * Brands Admin Page
 *
 * Admin interface for managing SEO brand pages.
 * Uses shared admin.css and template file for consistent styling.
 *
 * @package AffiliateCMS\Pro\Admin
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro\Admin;

use AffiliateCMS\Pro\Repositories\BrandRepository;

class BrandsPage
{
    /**
     * Render the brands page
     */
    public function render(): void
    {
        // Enqueue WordPress editor for TinyMCE in edit modal
        wp_enqueue_editor();
        wp_enqueue_script('editor');
        wp_enqueue_script('quicktags');
        wp_enqueue_style('editor-buttons');

        $repository = BrandRepository::instance();
        $stats = $repository->getStats();

        include ACMS_PLUGIN_DIR . 'templates/admin/brands-page.php';
    }
}
