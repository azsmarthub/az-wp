<?php
/**
 * Products Admin Page
 *
 * @package AffiliateCMS\Pro\Admin
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro\Admin;

class ProductsPage
{
    /**
     * Render the products page
     */
    public function render(): void
    {
        $data = $this->getInitialData();

        // Pass data to template
        $stats = $data['stats'];
        $settings = $data['settings'];

        include ACMS_PLUGIN_DIR . 'templates/admin/products-page.php';
    }

    /**
     * Enqueue admin assets
     */
    public function enqueueAssets(): void
    {
        $version = defined('ACMS_VERSION') ? ACMS_VERSION : '1.0.0';
        $assetsUrl = ACMS_PLUGIN_URL . 'assets/';

        // Alpine.js Collapse Plugin - self-hosted (must load before Alpine.js core)
        wp_enqueue_script(
            'alpinejs-collapse',
            $assetsUrl . 'js/vendor/alpinejs-collapse.min.js',
            [],
            '3.14.3',
            true
        );

        // Alpine.js Core - self-hosted
        wp_enqueue_script(
            'alpinejs',
            $assetsUrl . 'js/vendor/alpinejs.min.js',
            ['alpinejs-collapse'],
            '3.14.3',
            true
        );

        // Add defer attribute for Alpine.js scripts
        add_filter('script_loader_tag', function ($tag, $handle) {
            if (in_array($handle, ['alpinejs', 'alpinejs-collapse', 'acms-admin'])) {
                return str_replace(' src', ' defer src', $tag);
            }
            return $tag;
        }, 10, 2);

        // Bootstrap Icons - self-hosted
        wp_enqueue_style(
            'bootstrap-icons',
            $assetsUrl . 'fonts/bootstrap-icons/bootstrap-icons.min.css',
            [],
            '1.11.3'
        );

        // Admin styles
        wp_enqueue_style(
            'acms-admin',
            $assetsUrl . 'css/admin.css',
            ['bootstrap-icons'],
            $version
        );

        // Admin scripts
        wp_enqueue_script(
            'acms-admin',
            $assetsUrl . 'js/admin.js',
            ['alpinejs'],
            $version,
            true
        );

        // Localize script
        wp_localize_script('acms-admin', 'acmsConfig', [
            'restUrl' => rest_url('acms/v1/'),
            'nonce' => wp_create_nonce('wp_rest'),
        ]);
    }

    /**
     * Get initial data for the page
     *
     * Stats are intentionally set to 0 here — the real stats are loaded
     * asynchronously via the REST API (GET /products) to avoid duplicate
     * COUNT queries that slow down server-side page render.
     */
    private function getInitialData(): array
    {
        return [
            'stats' => [
                'total' => 0,
                'scraped' => 0,
                'pending' => 0,
                'failed' => 0,
            ],
            'settings' => [
                'crawlbase_token' => get_option('acms_crawlbase_token', ''),
                'paapi_access_key' => get_option('acms_paapi_access_key', ''),
                'paapi_partner_tag' => get_option('acms_paapi_partner_tag', ''),
                'paapi_region' => get_option('acms_paapi_region', 'com'),
            ],
        ];
    }
}
