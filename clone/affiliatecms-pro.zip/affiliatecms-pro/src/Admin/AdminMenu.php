<?php
/**
 * Admin Menu Registration
 *
 * @package AffiliateCMS\Pro\Admin
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro\Admin;

class AdminMenu
{
    private ProductsPage $productsPage;

    public function __construct(ProductsPage $productsPage)
    {
        $this->productsPage = $productsPage;
    }

    /**
     * Register admin menu hooks
     */
    public function register(): void
    {
        add_action('admin_menu', [$this, 'addMenuPage']);
        add_action('admin_enqueue_scripts', [$this, 'enqueueAssets']);
    }

    /**
     * Add menu page to WordPress admin
     */
    public function addMenuPage(): void
    {
        add_menu_page(
            __('AffiliateCMS', 'affiliatecms-pro'),
            __('AffiliateCMS', 'affiliatecms-pro'),
            'manage_options',
            'affiliatecms',
            [$this, 'renderProductsPage'],
            'dashicons-products',
            30
        );

        // Add submenu pages
        $this->addSubMenuPages();
    }

    /**
     * Add submenu pages
     */
    private function addSubMenuPages(): void
    {
        add_submenu_page(
            'affiliatecms',
            __('Products', 'affiliatecms-pro'),
            __('Products', 'affiliatecms-pro'),
            'manage_options',
            'affiliatecms',
            [$this, 'renderProductsPage']
        );
    }

    /**
     * Render products page
     */
    public function renderProductsPage(): void
    {
        $this->productsPage->render();
    }

    /**
     * Enqueue admin assets
     */
    public function enqueueAssets(string $hook): void
    {
        // Only load on our admin pages
        if (strpos($hook, 'affiliatecms') === false) {
            return;
        }

        $this->productsPage->enqueueAssets();
    }
}
