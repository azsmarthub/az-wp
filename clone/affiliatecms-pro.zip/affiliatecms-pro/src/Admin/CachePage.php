<?php
/**
 * Cache Admin Page
 *
 * Admin interface for cache preload management.
 * Displays URL queue with status tracking, priority, and preload controls.
 *
 * @package AffiliateCMS\Pro\Admin
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro\Admin;

class CachePage
{
    /**
     * Render the cache management page
     */
    public function render(): void
    {
        include ACMS_PLUGIN_DIR . 'templates/admin/cache-page.php';
    }
}
