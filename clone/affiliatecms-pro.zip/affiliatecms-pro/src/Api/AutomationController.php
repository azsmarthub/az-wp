<?php
/**
 * Automation REST API Controller
 *
 * Handles cron jobs, API endpoints for external scraping, and queue management
 *
 * @package AffiliateCMS\Pro\Api
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro\Api;

use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;
use WP_Error;
use AffiliateCMS\Pro\Database\Schema;

class AutomationController
{
    private const NAMESPACE = 'acms/v1';
    private const CRON_HOOK = 'acms_automation_cron';
    private const LOG_OPTION_SERVER = 'acms_cron_log_server';
    private const LOG_OPTION_WP = 'acms_cron_log_wp';
    private const MAX_LOG_ENTRIES = 20;

    /**
     * Register REST API routes
     */
    public function register(): void
    {
        $this->registerRoutes();
        $this->registerCronSchedules();
    }

    /**
     * Register routes
     */
    public function registerRoutes(): void
    {
        // Get automation status
        register_rest_route(self::NAMESPACE, '/automation/status', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'getStatus'],
            'permission_callback' => [$this, 'checkAdminPermission'],
        ]);

        // Update automation settings
        register_rest_route(self::NAMESPACE, '/automation/settings', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'updateSettings'],
            'permission_callback' => [$this, 'checkAdminPermission'],
        ]);

        // Trigger scrape (admin + server cron via GET or POST)
        register_rest_route(self::NAMESPACE, '/automation/scrape', [
            'methods' => 'GET, POST',
            'callback' => [$this, 'triggerScrape'],
            'permission_callback' => [$this, 'checkScrapePermission'],
        ]);

        // Regenerate API token
        register_rest_route(self::NAMESPACE, '/automation/regenerate-token', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'regenerateToken'],
            'permission_callback' => [$this, 'checkAdminPermission'],
        ]);

        // Manual date update trigger
        register_rest_route(self::NAMESPACE, '/automation/date-update', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'triggerDateUpdate'],
            'permission_callback' => [$this, 'checkAdminPermission'],
        ]);

        // Process scheduled products (admin + server cron via GET or POST)
        register_rest_route(self::NAMESPACE, '/automation/process-scheduled', [
            'methods' => 'GET, POST',
            'callback' => [$this, 'processScheduledProductsEndpoint'],
            'permission_callback' => [$this, 'checkScrapePermission'],
        ]);

        // Process quick-update workers (token auth, called by parallel workers)
        register_rest_route(self::NAMESPACE, '/automation/process-quick-update', [
            'methods' => 'GET, POST',
            'callback' => [$this, 'processQuickUpdateEndpoint'],
            'permission_callback' => [$this, 'checkScrapePermission'],
        ]);

        // Test WP Cron manually
        register_rest_route(self::NAMESPACE, '/automation/test-wp-cron', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'testWpCron'],
            'permission_callback' => [$this, 'checkAdminPermission'],
        ]);
    }

    /**
     * Register cron action handler
     *
     * Note: Custom cron schedules (every_5_minutes, etc.) are now registered
     * in Bootstrap::registerCustomCronSchedules() on 'init' hook to ensure
     * they're available when WordPress validates cron events on page load.
     */
    public function registerCronSchedules(): void
    {
        // Register cron action handler
        add_action(self::CRON_HOOK, [$this, 'executeCronScrape']);
    }

    /**
     * Check admin permission
     */
    public function checkAdminPermission(): bool
    {
        return current_user_can('manage_options');
    }

    /**
     * Check scrape permission (admin or valid API token)
     * Accepts token via:
     * - Header: X-ACMS-Token
     * - Query param: ?token=xxx
     */
    public function checkScrapePermission(WP_REST_Request $request): bool
    {
        // Prevent caching of cron responses by CDN/LiteSpeed/browser
        nocache_headers();

        // Admin can always scrape
        if (current_user_can('manage_options')) {
            return true;
        }

        // Check API token (header or query param)
        $token = $request->get_header('X-ACMS-Token');
        if (empty($token)) {
            $token = $request->get_param('token');
        }

        if (empty($token)) {
            return false;
        }

        $storedToken = get_option('acms_api_token', '');
        return !empty($storedToken) && hash_equals($storedToken, (string) $token);
    }

    /**
     * Get automation status
     */
    public function getStatus(WP_REST_Request $request): WP_REST_Response
    {
        global $wpdb;

        // Get settings
        $settings = get_option('acms_automation', [
            'cron_enabled' => false,
            'cron_schedule' => 'hourly',
            'update_enabled' => false,
            'update_interval' => 24,
            'worker_count' => 3,
        ]);
        // Ensure worker_count has default value
        $settings['worker_count'] = $settings['worker_count'] ?? 3;

        // Cron status - Show WordPress local time (based on Settings > General > Timezone)
        $nextRun = wp_next_scheduled(self::CRON_HOOK);

        // Get last WP cron run from logs
        $wpLogs = get_option(self::LOG_OPTION_WP, []);
        $lastWpRun = !empty($wpLogs) ? $wpLogs[0]['time'] : null;

        // Check if cron is overdue (scheduled time has passed)
        $isOverdue = $nextRun !== false && $nextRun < time();

        $cronStatus = [
            'scheduled' => $nextRun !== false,
            'next_run' => $nextRun ? wp_date('M j, Y g:i A', $nextRun) : null,
            'next_run_timestamp' => $nextRun ?: null,
            'is_overdue' => $isOverdue,
            'last_run' => $lastWpRun,
        ];

        // Update stats - count products in update queue
        $updateInterval = intval($settings['update_interval'] ?? $settings['rescrape_interval'] ?? 24);
        $staleTime = gmdate('Y-m-d H:i:s', current_time('timestamp') - ($updateInterval * 3600));

        // Single GROUP BY query replaces 7 separate COUNT queries.
        $table = Schema::productsTable();
        $statusRows = $wpdb->get_results(
            "SELECT status, COUNT(*) as cnt FROM {$table}
             WHERE status IN ('pending','scheduled','processing','scraped','failed','update','updating')
             GROUP BY status",
            ARRAY_A
        );
        $counts = [];
        foreach ((array) $statusRows as $row) {
            $counts[$row['status']] = (int) $row['cnt'];
        }

        $updateQueued = $counts['update']   ?? 0;
        $updating     = $counts['updating'] ?? 0;

        $staleCount = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$table}
             WHERE status = 'scraped'
             AND COALESCE(quick_update_at, last_scraped_at) < %s",
            $staleTime
        ));

        $updateStats = [
            'stale_count'  => $staleCount,
            'update_queued' => $updateQueued,
            'updating'      => $updating,
        ];

        // Queue stats — built from the same GROUP BY result above.
        $queueStats = [
            'pending'    => $counts['pending']    ?? 0,
            'scheduled'  => $counts['scheduled']  ?? 0,
            'processing' => $counts['processing'] ?? 0,
            'completed'  => $counts['scraped']    ?? 0,
            'failed'     => $counts['failed']     ?? 0,
            'update'     => $updateQueued,
            'updating'   => $updating,
        ];

        return new WP_REST_Response([
            'success' => true,
            'data' => [
                'settings' => $settings,
                'cron' => $cronStatus,
                'update' => $updateStats,
                'queue' => $queueStats,
                'logs' => self::getCronLogs('all'),
            ],
        ]);
    }

    /**
     * Update automation settings
     */
    public function updateSettings(WP_REST_Request $request): WP_REST_Response
    {
        $data = $request->get_json_params();

        $settings = [
            'cron_enabled' => !empty($data['cron_enabled']),
            'cron_schedule' => sanitize_text_field($data['cron_schedule'] ?? 'hourly'),
            'update_enabled' => !empty($data['update_enabled']),
            'update_interval' => min(168, max(1, intval($data['update_interval'] ?? 24))),
            'update_worker_count' => min(50, max(1, intval($data['update_worker_count'] ?? 3))), // 1-50 update workers
            'worker_count' => min(50, max(1, intval($data['worker_count'] ?? 3))), // 1-50 scrape workers
        ];

        // Save settings
        update_option('acms_automation', $settings);

        // Update cron schedule
        $this->updateCronSchedule($settings['cron_enabled'], $settings['cron_schedule']);

        // Get updated cron status - Show WordPress local time
        $nextRun = wp_next_scheduled(self::CRON_HOOK);
        $cronStatus = [
            'scheduled' => $nextRun !== false,
            'next_run' => $nextRun ? wp_date('M j, Y g:i A', $nextRun) : null,
        ];

        return new WP_REST_Response([
            'success' => true,
            'message' => __('Automation settings saved successfully', 'affiliatecms-pro'),
            'data' => [
                'settings' => $settings,
                'cron' => $cronStatus,
            ],
        ]);
    }

    /**
     * Update cron schedule
     */
    private function updateCronSchedule(bool $enabled, string $schedule): void
    {
        // Clear existing cron
        $timestamp = wp_next_scheduled(self::CRON_HOOK);
        if ($timestamp) {
            wp_unschedule_event($timestamp, self::CRON_HOOK);
        }

        // Schedule new cron if enabled
        if ($enabled) {
            $validSchedules = ['every_5_minutes', 'every_15_minutes', 'every_30_minutes', 'hourly', 'twicedaily', 'daily'];
            if (in_array($schedule, $validSchedules)) {
                // Get the interval for this schedule
                $schedules = wp_get_schedules();
                $interval = $schedules[$schedule]['interval'] ?? 3600;

                // Schedule first event at current time + interval (not immediately)
                wp_schedule_event(time() + $interval, $schedule, self::CRON_HOOK);
            }
        }
    }

    /**
     * Trigger scrape (via API or admin)
     *
     * Marks ALL eligible products as 'scheduled' for background processing.
     * Workflow:
     * 1. Auto-retry failed products (timeout errors) after 1 hour
     * 2. Mark ALL pending products as 'scheduled'
     * 3. Trigger background processing via WP Cron
     *
     * Note: Stale product updates (price/rating/stock) are handled separately
     * by the Auto Update system (QuickUpdateCron) with its own status flow.
     */
    public function triggerScrape(WP_REST_Request $request): WP_REST_Response
    {
        global $wpdb;

        // Determine call source for logging
        $isWpCron = $request->get_param('_wp_cron') === true;
        $isServerCron = !$isWpCron && $request->get_header('X-ACMS-Token');

        // Log server cron CRON 1 call (not WP cron, not admin button)
        if ($isServerCron) {
            $this->addCronLog('server', 'cron1_start', [
                'endpoint' => 'scrape',
            ]);
        }

        // Unified cron log (visible in Cron Settings > Logs > Scraping tab)
        CronController::addLog('scraping', 'info', 'Check & Mark started');
        $startTime = microtime(true);

        $settings = get_option('acms_automation', []);

        // Step 0a: Reset stuck processing products (>15 min)
        // Workers that die mid-scrape (OOM, timeout) leave products stuck in 'processing'.
        // First attempt: re-schedule for retry. Second stuck: mark as failed.
        $stuckThreshold = gmdate('Y-m-d H:i:s', current_time('timestamp') - 900); // 15 min ago in local time
        $table = Schema::productsTable();

        // Mark as failed if stuck AND already has error_message starting with 'Stuck:' (= 2nd time stuck)
        $stuckFailed = $wpdb->query($wpdb->prepare(
            "UPDATE {$table}
             SET status = 'failed',
                 error_message = CONCAT('Stuck: processing timeout (final). Previous: ', COALESCE(error_message, 'none'))
             WHERE status = 'processing'
               AND updated_at < %s
               AND error_message LIKE 'Stuck:%%'",
            $stuckThreshold
        ));

        // Re-schedule first-time stuck items (no 'Stuck:' prefix yet)
        $stuckRescheduled = $wpdb->query($wpdb->prepare(
            "UPDATE {$table}
             SET status = 'scheduled',
                 error_message = CONCAT('Stuck: processing timeout, retrying. ', COALESCE(error_message, ''))
             WHERE status = 'processing'
               AND updated_at < %s
               AND (error_message IS NULL OR error_message NOT LIKE 'Stuck:%%')",
            $stuckThreshold
        ));

        if ($stuckRescheduled > 0 || $stuckFailed > 0) {
            error_log("[ACMS] triggerScrape: Reset stuck processing: {$stuckRescheduled} rescheduled, {$stuckFailed} failed");
            CronController::addLog('scraping', 'warning', "Reset stuck: {$stuckRescheduled} retried, {$stuckFailed} failed");
        }

        // Step 0b: Auto-retry failed products (timeout errors) after 1 hour
        // Use WordPress timezone for threshold comparison
        $retryTime = gmdate('Y-m-d H:i:s', current_time('timestamp') - 3600);
        $retriedCount = $wpdb->query($wpdb->prepare(
            "UPDATE " . Schema::productsTable() . "
             SET status = 'scheduled',
                 error_message = NULL
             WHERE status = 'failed'
             AND (error_message LIKE %s OR error_message LIKE %s)
             AND updated_at < %s",
            '%timeout%',
            '%timed out%',
            $retryTime
        ));

        // Step 1: Mark ALL pending products as 'scheduled' (no limit)
        // Note: Stale product re-scraping has been replaced by the Auto Update system
        // (QuickUpdateCron) which handles price/rating/stock updates via status='update'.
        $table = Schema::productsTable();

        // Debug: count pending BEFORE update
        $pendingBefore = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE status = 'pending'");

        $pendingCount = $wpdb->query(
            "UPDATE {$table} SET status = 'scheduled' WHERE status = 'pending'"
        );
        $sqlError = $wpdb->last_error;

        // Debug: count pending AFTER update
        $pendingAfter = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE status = 'pending'");

        if ($sqlError) {
            error_log("[ACMS] triggerScrape SQL ERROR: {$sqlError}");
        }
        error_log("[ACMS] triggerScrape: table={$table}, pending_before={$pendingBefore}, affected={$pendingCount}, pending_after={$pendingAfter}, sql_error=" . ($sqlError ?: 'none'));

        // Count total scheduled products
        $totalScheduled = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$table} WHERE status = 'scheduled'"
        );

        if ($totalScheduled === 0) {
            $duration = round((microtime(true) - $startTime) * 1000);
            CronController::addLog('scraping', 'success', 'Check & Mark: no products to scrape', "Duration: {$duration}ms");
            return new WP_REST_Response([
                'success' => true,
                'message' => __('No products to scrape', 'affiliatecms-pro'),
                'data' => ['scheduled' => 0, 'retried' => 0, 'pending' => 0],
            ]);
        }

        // Step 3: Trigger background processing via WP Cron
        $this->triggerBackgroundProcessing();

        // Log server cron CRON 1 completion
        if ($isServerCron) {
            $this->addCronLog('server', 'cron1_complete', [
                'scheduled' => $totalScheduled,
                'pending' => (int) $pendingCount,
                'retried' => (int) $retriedCount,
            ]);
        }

        $duration = round((microtime(true) - $startTime) * 1000);
        CronController::addLog('scraping', 'success', "Check & Mark: {$totalScheduled} scheduled", "pending={$pendingCount} retried={$retriedCount} {$duration}ms");

        return new WP_REST_Response([
            'success' => true,
            'message' => sprintf(
                __('%d products queued for scraping (processing in background)', 'affiliatecms-pro'),
                $totalScheduled
            ),
            'data' => [
                'scheduled' => $totalScheduled,
                'retried' => (int) $retriedCount,
                'pending' => (int) $pendingCount,
                'stuck_rescheduled' => (int) $stuckRescheduled,
                'stuck_failed' => (int) $stuckFailed,
                'debug' => [
                    'table' => $table,
                    'pending_before' => $pendingBefore,
                    'pending_after' => $pendingAfter,
                    'sql_error' => $sqlError ?: null,
                    'worker_count' => \AffiliateCMS\Pro\Core\Bootstrap::instance()->getWorkerCount(),
                ],
            ],
        ]);
    }

    /**
     * Trigger background processing with parallel workers
     *
     * Spawns multiple parallel workers to process scheduled products.
     * Each worker atomically claims one product to prevent race conditions.
     */
    private function triggerBackgroundProcessing(): void
    {
        $bootstrap = \AffiliateCMS\Pro\Core\Bootstrap::instance();

        // Spawn parallel workers (default 3, configurable)
        $bootstrap->spawnParallelWorkers();

        error_log('[ACMS] Triggered parallel workers for background processing');
    }

    /**
     * Process scheduled products (Server cron fallback endpoint)
     *
     * This endpoint can be called by server cron to process scheduled products.
     * It's more reliable than WP Cron for hosts that disable WP Cron.
     *
     * Server cron example:
     * curl -X POST "https://yoursite.com/wp-json/acms/v1/automation/process-scheduled?token=YOUR_TOKEN"
     */
    public function processScheduledProductsEndpoint(WP_REST_Request $request): WP_REST_Response
    {
        $repository = \AffiliateCMS\Pro\Repositories\ProductRepository::instance();
        $scheduled = $repository->count(['status' => 'scheduled']);
        $processing = $repository->count(['status' => 'processing']);

        CronController::addLog('scraping', 'info', "Process Scrape: scheduled={$scheduled} processing={$processing}");

        // Run worker loop AFTER response is sent to client.
        // fastcgi_finish_request() flushes response + closes connection,
        // but PHP continues executing in background.
        add_action('shutdown', function () {
            if (function_exists('fastcgi_finish_request')) {
                fastcgi_finish_request();
            }
            \AffiliateCMS\Pro\Core\Bootstrap::instance()->processScheduledProducts();
        });

        return new WP_REST_Response([
            'success' => true,
            'message' => "Worker starting (scheduled={$scheduled}, processing={$processing})",
            'data' => [
                'scheduled' => $scheduled,
                'processing' => $processing,
            ],
        ]);
    }

    /**
     * Execute cron scrape (WordPress Cron callback)
     */
    public function executeCronScrape(): void
    {
        $settings = get_option('acms_automation', []);

        if (empty($settings['cron_enabled'])) {
            return;
        }

        // Log WP Cron execution
        $this->addCronLog('wp', 'cron_start', [
            'schedule' => $settings['cron_schedule'] ?? 'unknown',
        ]);

        // Create a mock request
        $request = new WP_REST_Request('POST');

        // Trigger the scrape (mark as internal WP cron call)
        $request->set_param('_wp_cron', true);
        $response = $this->triggerScrape($request);

        // Log completion
        $responseData = $response->get_data();
        $this->addCronLog('wp', 'cron_complete', [
            'scheduled' => $responseData['data']['scheduled'] ?? 0,
            'pending' => $responseData['data']['pending'] ?? 0,
            'retried' => $responseData['data']['retried'] ?? 0,
        ]);
    }

    /**
     * Regenerate API token
     */
    public function regenerateToken(WP_REST_Request $request): WP_REST_Response
    {
        $newToken = wp_generate_password(32, false, false);
        update_option('acms_api_token', $newToken);

        return new WP_REST_Response([
            'success' => true,
            'message' => __('API token regenerated successfully', 'affiliatecms-pro'),
            'data' => [
                'token' => $newToken,
            ],
        ]);
    }

    /**
     * Test WP Cron manually
     *
     * Manually triggers the WP Cron hook to test if it works.
     * This bypasses the normal cron scheduling and runs immediately.
     */
    public function testWpCron(WP_REST_Request $request): WP_REST_Response
    {
        $settings = get_option('acms_automation', []);

        if (empty($settings['cron_enabled'])) {
            return new WP_REST_Response([
                'success' => false,
                'message' => __('WP Cron is not enabled. Please enable it first.', 'affiliatecms-pro'),
            ]);
        }

        // Log test execution
        $this->addCronLog('wp', 'test_start', [
            'triggered_by' => 'manual_test',
        ]);

        // Execute the cron hook directly
        $this->executeCronScrape();

        // Get logs to show result
        $wpLogs = get_option(self::LOG_OPTION_WP, []);

        return new WP_REST_Response([
            'success' => true,
            'message' => __('WP Cron test executed successfully. Check the logs for results.', 'affiliatecms-pro'),
            'data' => [
                'logs' => array_slice($wpLogs, 0, 5), // Return last 5 logs
            ],
        ]);
    }

    /**
     * Trigger date update manually
     *
     * Updates all posts with date placeholders to current month/year values.
     */
    public function triggerDateUpdate(WP_REST_Request $request): WP_REST_Response
    {
        global $wpdb;

        try {
            // Load DateUpdateCron
            $dateUpdateCron = \AffiliateCMS\Pro\Core\DateUpdateCron::instance();

            // Get count before update (use WordPress timezone)
            $currentMonth = wp_date('Y-m');
            $postsToUpdate = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(DISTINCT p.ID)
                 FROM {$wpdb->posts} p
                 INNER JOIN {$wpdb->postmeta} pm1 ON p.ID = pm1.post_id AND pm1.meta_key = %s
                 INNER JOIN {$wpdb->postmeta} pm2 ON p.ID = pm2.post_id AND pm2.meta_key = %s
                 WHERE pm2.meta_value != %s
                 AND p.post_status IN ('publish', 'draft')",
                \AffiliateCMS\Pro\Core\DateUpdateContext::META_KEY,
                \AffiliateCMS\Pro\Core\DateUpdateContext::META_KEY_GENERATED_DATE,
                $currentMonth
            ));

            // Run the update
            $result = $dateUpdateCron->runManually();

            if ($result['success']) {
                $message = sprintf(
                    __('Date update completed. %d posts were eligible for update.', 'affiliatecms-pro'),
                    (int) $postsToUpdate
                );

                return new WP_REST_Response([
                    'success' => true,
                    'message' => $message,
                    'data' => [
                        'updated_count' => (int) $postsToUpdate,
                        'duration_ms' => $result['duration_ms'] ?? 0,
                    ],
                ]);
            } else {
                return new WP_REST_Response([
                    'success' => false,
                    'message' => __('Date update failed', 'affiliatecms-pro'),
                ], 500);
            }
        } catch (\Exception $e) {
            return new WP_REST_Response([
                'success' => false,
                'message' => sprintf(
                    __('Date update error: %s', 'affiliatecms-pro'),
                    $e->getMessage()
                ),
            ], 500);
        }
    }

    /**
     * Process one queued quick-update product (worker endpoint).
     *
     * Called by parallel workers spawned from bulk quick-update action.
     * Each call claims one product atomically, quick-scrapes it, and
     * self-spawns if more remain in the queue.
     */
    public function processQuickUpdateEndpoint(WP_REST_Request $request): WP_REST_Response
    {
        @set_time_limit(120);

        $bootstrap = \AffiliateCMS\Pro\Core\Bootstrap::instance();
        $bootstrap->processQuickUpdateWorker();

        $repository = \AffiliateCMS\Pro\Repositories\ProductRepository::instance();
        $remaining = $repository->countUpdateQueued();

        return new WP_REST_Response([
            'success' => true,
            'data' => ['remaining' => $remaining],
        ]);
    }

    /**
     * Add a cron log entry
     *
     * @param string $type 'server' or 'wp'
     * @param string $action Action performed (e.g., 'scrape', 'process')
     * @param array $data Additional data to log
     */
    private function addCronLog(string $type, string $action, array $data = []): void
    {
        $optionKey = $type === 'server' ? self::LOG_OPTION_SERVER : self::LOG_OPTION_WP;
        $logs = get_option($optionKey, []);

        // Add new log entry
        $entry = [
            'time' => wp_date('Y-m-d H:i:s'),
            'timestamp' => time(),
            'action' => $action,
            'data' => $data,
        ];

        // Prepend new entry (newest first)
        array_unshift($logs, $entry);

        // Keep only MAX_LOG_ENTRIES
        $logs = array_slice($logs, 0, self::MAX_LOG_ENTRIES);

        update_option($optionKey, $logs, false);
    }

    /**
     * Get cron logs
     *
     * @param string $type 'server' or 'wp' or 'all'
     * @return array Logs
     */
    public static function getCronLogs(string $type = 'all'): array
    {
        $result = [];

        if ($type === 'all' || $type === 'server') {
            $result['server'] = get_option(self::LOG_OPTION_SERVER, []);
        }

        if ($type === 'all' || $type === 'wp') {
            $result['wp'] = get_option(self::LOG_OPTION_WP, []);
        }

        return $type === 'all' ? $result : ($result[$type] ?? []);
    }
}
