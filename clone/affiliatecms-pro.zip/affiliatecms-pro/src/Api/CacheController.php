<?php
/**
 * Cache URL Controller
 *
 * REST endpoints for browsing/managing the cache URL queue.
 * Complements CachePreload::registerRoutes() which handles
 * preload/purge/status/stop/flush-redis/process-chunk.
 *
 * Endpoints:
 *   GET  /cache/urls       — paginated URL list with filters
 *   GET  /cache/urls/stats — aggregate counts by status & type
 *   POST /cache/urls/reset — re-queue failed/timeout URLs
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro\Api;

use AffiliateCMS\Pro\Database\Schema;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

class CacheController
{
    private const NAMESPACE = 'acms/v1';

    public function register(): void
    {
        $this->registerRoutes();
    }

    private function registerRoutes(): void
    {
        register_rest_route(self::NAMESPACE, '/cache/urls', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this, 'getUrls'],
            'permission_callback' => [$this, 'checkPermission'],
            'args'                => $this->getUrlsParams(),
        ]);

        register_rest_route(self::NAMESPACE, '/cache/urls/stats', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this, 'getStats'],
            'permission_callback' => [$this, 'checkPermission'],
        ]);

        register_rest_route(self::NAMESPACE, '/cache/urls/reset', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this, 'resetFailed'],
            'permission_callback' => [$this, 'checkPermission'],
        ]);
    }

    public function checkPermission(): bool
    {
        return current_user_can('manage_options');
    }

    // ─── GET /cache/urls ──────────────────────────────────────

    /**
     * Paginated URL list with status/type/search filters
     */
    public function getUrls(WP_REST_Request $request): WP_REST_Response
    {
        global $wpdb;
        $table = Schema::cacheUrlsTable();

        $page     = max(1, (int) $request->get_param('page'));
        $per_page = max(10, min(200, (int) ($request->get_param('per_page') ?: 50)));
        $status   = sanitize_text_field($request->get_param('status') ?: '');
        $url_type = sanitize_text_field($request->get_param('url_type') ?: '');
        $search   = sanitize_text_field($request->get_param('search') ?: '');
        $orderby  = sanitize_text_field($request->get_param('orderby') ?: 'priority');
        $order    = strtoupper($request->get_param('order') ?: 'DESC') === 'ASC' ? 'ASC' : 'DESC';

        // Whitelist orderby columns
        $allowed_orderby = ['id', 'url', 'url_type', 'status', 'priority', 'http_code', 'response_time_ms', 'attempts', 'last_warmed_at'];
        if (!in_array($orderby, $allowed_orderby, true)) {
            $orderby = 'priority';
        }

        // Build WHERE clauses
        $where = [];
        $values = [];

        if ($status !== '' && $status !== 'all') {
            $where[] = 'status = %s';
            $values[] = $status;
        }

        if ($url_type !== '' && $url_type !== 'all') {
            $where[] = 'url_type = %s';
            $values[] = $url_type;
        }

        if ($search !== '') {
            $where[] = 'url LIKE %s';
            $values[] = '%' . $wpdb->esc_like($search) . '%';
        }

        $whereSQL = $where ? 'WHERE ' . implode(' AND ', $where) : '';
        $offset = ($page - 1) * $per_page;

        // Count query
        $countQuery = "SELECT COUNT(*) FROM {$table} {$whereSQL}";
        if ($values) {
            $total = (int) $wpdb->get_var($wpdb->prepare($countQuery, ...$values));
        } else {
            $total = (int) $wpdb->get_var($countQuery);
        }

        // Data query
        $dataQuery = "SELECT id, url, url_type, status, priority, http_code, response_time_ms, attempts, last_warmed_at
                      FROM {$table} {$whereSQL}
                      ORDER BY {$orderby} {$order}, id ASC
                      LIMIT %d OFFSET %d";

        $queryValues = array_merge($values, [$per_page, $offset]);
        $rows = $wpdb->get_results($wpdb->prepare($dataQuery, ...$queryValues), ARRAY_A);

        // Cast numeric fields
        foreach ($rows as &$row) {
            $row['id']               = (int) $row['id'];
            $row['priority']         = (int) $row['priority'];
            $row['http_code']        = $row['http_code'] !== null ? (int) $row['http_code'] : null;
            $row['response_time_ms'] = $row['response_time_ms'] !== null ? (int) $row['response_time_ms'] : null;
            $row['attempts']         = (int) $row['attempts'];
        }
        unset($row);

        return new WP_REST_Response([
            'success'  => true,
            'data'     => $rows,
            'total'    => $total,
            'page'     => $page,
            'per_page' => $per_page,
            'pages'    => (int) ceil($total / $per_page),
        ]);
    }

    // ─── GET /cache/urls/stats ────────────────────────────────

    /**
     * Aggregate counts: by status, by type, avg response time
     */
    public function getStats(WP_REST_Request $request): WP_REST_Response
    {
        global $wpdb;
        $table = Schema::cacheUrlsTable();

        $tableExists = $wpdb->get_var("SHOW TABLES LIKE '{$table}'") === $table;

        if (!$tableExists) {
            return new WP_REST_Response([
                'success'    => true,
                'by_status'  => [],
                'by_type'    => [],
                'avg_time'   => 0,
                'total'      => 0,
            ]);
        }

        // By status
        $byStatus = [];
        $statusRows = $wpdb->get_results(
            "SELECT status, COUNT(*) as cnt FROM {$table} GROUP BY status",
            ARRAY_A
        );
        $total = 0;
        foreach ($statusRows as $row) {
            $byStatus[$row['status']] = (int) $row['cnt'];
            $total += (int) $row['cnt'];
        }

        // By type
        $byType = [];
        $typeRows = $wpdb->get_results(
            "SELECT url_type, COUNT(*) as cnt FROM {$table} GROUP BY url_type ORDER BY cnt DESC",
            ARRAY_A
        );
        foreach ($typeRows as $row) {
            $byType[$row['url_type']] = (int) $row['cnt'];
        }

        // Average response time (cached URLs only)
        $avgTime = (int) $wpdb->get_var(
            "SELECT COALESCE(AVG(response_time_ms), 0) FROM {$table} WHERE status = 'cached' AND response_time_ms IS NOT NULL"
        );

        // Slowest URLs (top 10)
        $slowest = $wpdb->get_results(
            "SELECT url, response_time_ms, http_code
             FROM {$table}
             WHERE response_time_ms IS NOT NULL
             ORDER BY response_time_ms DESC
             LIMIT 10",
            ARRAY_A
        );

        return new WP_REST_Response([
            'success'    => true,
            'by_status'  => $byStatus,
            'by_type'    => $byType,
            'avg_time'   => $avgTime,
            'total'      => $total,
            'slowest'    => $slowest,
        ]);
    }

    // ─── POST /cache/urls/reset ───────────────────────────────

    /**
     * Reset failed/timeout URLs back to pending for retry
     */
    public function resetFailed(WP_REST_Request $request): WP_REST_Response
    {
        global $wpdb;
        $table = Schema::cacheUrlsTable();

        $affected = $wpdb->query(
            "UPDATE {$table} SET status = 'pending', attempts = 0, http_code = NULL, response_time_ms = NULL
             WHERE status IN ('failed', 'timeout', 'skipped')"
        );

        return new WP_REST_Response([
            'success' => true,
            'reset'   => (int) $affected,
            'message' => sprintf('%d URLs reset to pending.', (int) $affected),
        ]);
    }

    // ─── Parameter Definitions ────────────────────────────────

    private function getUrlsParams(): array
    {
        return [
            'page' => [
                'type'              => 'integer',
                'default'           => 1,
                'minimum'           => 1,
                'sanitize_callback' => 'absint',
            ],
            'per_page' => [
                'type'              => 'integer',
                'default'           => 50,
                'minimum'           => 10,
                'maximum'           => 200,
                'sanitize_callback' => 'absint',
            ],
            'status' => [
                'type'              => 'string',
                'default'           => '',
                'enum'              => ['', 'all', 'pending', 'cached', 'failed', 'timeout', 'skipped'],
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'url_type' => [
                'type'              => 'string',
                'default'           => '',
                'enum'              => ['', 'all', 'homepage', 'post', 'page', 'category', 'archive', 'other'],
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'search' => [
                'type'              => 'string',
                'default'           => '',
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'orderby' => [
                'type'              => 'string',
                'default'           => 'priority',
                'enum'              => ['id', 'url', 'url_type', 'status', 'priority', 'http_code', 'response_time_ms', 'attempts', 'last_warmed_at'],
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'order' => [
                'type'              => 'string',
                'default'           => 'DESC',
                'enum'              => ['ASC', 'DESC'],
                'sanitize_callback' => 'sanitize_text_field',
            ],
        ];
    }
}
