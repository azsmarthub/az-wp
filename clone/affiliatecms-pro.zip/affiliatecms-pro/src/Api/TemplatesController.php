<?php
/**
 * Content Templates REST API Controller
 *
 * @package AffiliateCMS\Pro\Api
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro\Api;

use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;
use WP_Error;

class TemplatesController
{
    private const NAMESPACE = 'acms/v1';
    private const OPTION_KEY = 'acms_content_templates';
    private const DEFAULT_TEMPLATE_KEY = 'acms_default_template_id';

    /**
     * Register REST API routes
     */
    public function register(): void
    {
        $this->registerRoutes();
    }

    /**
     * Register routes
     */
    public function registerRoutes(): void
    {
        // Get all templates
        register_rest_route(self::NAMESPACE, '/templates', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'index'],
            'permission_callback' => [$this, 'checkPermission'],
        ]);

        // Create/Update template
        register_rest_route(self::NAMESPACE, '/templates', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'save'],
            'permission_callback' => [$this, 'checkPermission'],
        ]);

        // Get single template
        register_rest_route(self::NAMESPACE, '/templates/(?P<id>[a-zA-Z0-9_-]+)', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'get'],
            'permission_callback' => [$this, 'checkPermission'],
        ]);

        // Delete template
        register_rest_route(self::NAMESPACE, '/templates/(?P<id>[a-zA-Z0-9_-]+)', [
            'methods' => WP_REST_Server::DELETABLE,
            'callback' => [$this, 'delete'],
            'permission_callback' => [$this, 'checkPermission'],
        ]);

        // Set default template
        register_rest_route(self::NAMESPACE, '/templates/default', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'setDefault'],
            'permission_callback' => [$this, 'checkPermission'],
        ]);
    }

    /**
     * Check user permission
     */
    public function checkPermission(): bool
    {
        return current_user_can('manage_options');
    }

    /**
     * Get all templates
     */
    public function index(WP_REST_Request $request): WP_REST_Response
    {
        $templates = get_option(self::OPTION_KEY, []);

        if (!is_array($templates)) {
            $templates = [];
        }

        return new WP_REST_Response([
            'success' => true,
            'data' => array_values($templates),
            'default_template_id' => $this->getDefaultTemplateId(),
        ]);
    }

    /**
     * Get single template by ID
     */
    public function get(WP_REST_Request $request): WP_REST_Response
    {
        $id = $request->get_param('id');
        $templates = get_option(self::OPTION_KEY, []);

        // Try direct lookup first
        if (isset($templates[$id])) {
            return new WP_REST_Response([
                'success' => true,
                'data' => $templates[$id],
            ]);
        }

        // Fallback: search by internal id field (for templates saved before the fix)
        foreach ($templates as $key => $template) {
            if (isset($template['id']) && $template['id'] === $id) {
                // Fix the key mismatch by updating the array key
                unset($templates[$key]);
                $templates[$id] = $template;
                update_option(self::OPTION_KEY, $templates);

                return new WP_REST_Response([
                    'success' => true,
                    'data' => $template,
                ]);
            }
        }

        return new WP_REST_Response([
            'success' => false,
            'message' => __('Template not found', 'affiliatecms-pro'),
        ], 404);
    }

    /**
     * Save template (create or update)
     */
    public function save(WP_REST_Request $request): WP_REST_Response
    {
        $params = $request->get_json_params();
        $templates = get_option(self::OPTION_KEY, []);

        if (!is_array($templates)) {
            $templates = [];
        }

        // Generate ID if not provided (new template)
        // Always sanitize ID to ensure consistency between array key and template data
        $rawId = $params['id'] ?? 'template_' . time() . '_' . wp_generate_password(6, false);
        $id = sanitize_key($rawId);
        $isNew = !isset($templates[$id]);

        // Validate required fields
        if (empty($params['name'])) {
            return new WP_REST_Response([
                'success' => false,
                'message' => __('Template name is required', 'affiliatecms-pro'),
            ], 400);
        }

        // Sanitize and prepare template data
        $template = [
            'id' => $id, // Already sanitized above
            'name' => sanitize_text_field($params['name']),
            'postType' => sanitize_key($params['postType'] ?? 'acms_reviews'),
            'title' => sanitize_text_field($params['title'] ?? ''),
            'description' => wp_kses_post($params['description'] ?? ''),
            'metaTitle' => sanitize_text_field($params['metaTitle'] ?? ''),
            'metaDescription' => sanitize_textarea_field($params['metaDescription'] ?? ''),
            'beforeProducts' => wp_kses_post($params['beforeProducts'] ?? ''),
            'afterProducts' => wp_kses_post($params['afterProducts'] ?? ''),
            'displayType' => in_array($params['displayType'] ?? 'list', ['list', 'grid'], true)
                ? $params['displayType']
                : 'list',
            'createdAt' => $templates[$id]['createdAt'] ?? current_time('mysql'),
            'updatedAt' => current_time('mysql'),
        ];

        // Store template
        $templates[$id] = $template;
        update_option(self::OPTION_KEY, $templates);

        return new WP_REST_Response([
            'success' => true,
            'message' => $isNew
                ? __('Template created successfully', 'affiliatecms-pro')
                : __('Template updated successfully', 'affiliatecms-pro'),
            'data' => $template,
        ]);
    }

    /**
     * Delete template
     */
    public function delete(WP_REST_Request $request): WP_REST_Response
    {
        $id = $request->get_param('id');
        $templates = get_option(self::OPTION_KEY, []);

        if (!isset($templates[$id])) {
            return new WP_REST_Response([
                'success' => false,
                'message' => __('Template not found', 'affiliatecms-pro'),
            ], 404);
        }

        // Clear default template ID if this was the default
        if ($this->getDefaultTemplateId() === $id) {
            delete_option(self::DEFAULT_TEMPLATE_KEY);
        }

        // Remove template
        unset($templates[$id]);
        update_option(self::OPTION_KEY, $templates);

        return new WP_REST_Response([
            'success' => true,
            'message' => __('Template deleted successfully', 'affiliatecms-pro'),
        ]);
    }

    /**
     * Set default template
     */
    public function setDefault(WP_REST_Request $request): WP_REST_Response
    {
        $params = $request->get_json_params();
        $templateId = $params['template_id'] ?? '';

        if (empty($templateId)) {
            return new WP_REST_Response([
                'success' => false,
                'message' => __('Template ID is required', 'affiliatecms-pro'),
            ], 400);
        }

        // Verify template exists
        $templates = get_option(self::OPTION_KEY, []);
        if (!isset($templates[$templateId])) {
            return new WP_REST_Response([
                'success' => false,
                'message' => __('Template not found', 'affiliatecms-pro'),
            ], 404);
        }

        // Save default template ID
        update_option(self::DEFAULT_TEMPLATE_KEY, $templateId);

        return new WP_REST_Response([
            'success' => true,
            'message' => __('Default template updated successfully', 'affiliatecms-pro'),
            'data' => [
                'default_template_id' => $templateId,
            ],
        ]);
    }

    /**
     * Get default template ID
     */
    private function getDefaultTemplateId(): string
    {
        return get_option(self::DEFAULT_TEMPLATE_KEY, '');
    }

    /**
     * Get default template structure
     */
    public static function getDefaultTemplate(): array
    {
        return [
            'id' => '',
            'name' => '',
            'postType' => 'acms_reviews',
            'title' => '%keyword%',
            'description' => '',
            'metaTitle' => '%keyword% - Best Products Review',
            'metaDescription' => 'Find the best %keyword% products. Compare prices, features, and reviews.',
            'beforeProducts' => '<p>Looking for the best %keyword%? We\'ve researched and compared the top products to help you make an informed decision.</p>',
            'afterProducts' => '<p>We hope this guide helped you find the perfect %keyword% for your needs.</p>',
            'displayType' => 'list',
            'createdAt' => '',
            'updatedAt' => '',
        ];
    }
}
