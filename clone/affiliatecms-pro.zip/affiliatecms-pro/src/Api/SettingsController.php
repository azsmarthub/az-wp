<?php
/**
 * Settings REST API Controller
 *
 * @package AffiliateCMS\Pro\Api
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro\Api;

use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;
use WP_Error;
use AffiliateCMS\Pro\Core\PostTypeManager;

class SettingsController
{
    private const NAMESPACE = 'acms/v1';

    /**
     * Register REST API routes
     * Called directly from rest_api_init hook
     */
    public function register(): void
    {
        $this->registerRoutes();
    }

    /**
     * Register routes
     */
    public function registerRoutes(): void
    {
        // Get settings
        register_rest_route(self::NAMESPACE, '/settings', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'index'],
            'permission_callback' => [$this, 'checkPermission'],
        ]);

        // Update settings
        register_rest_route(self::NAMESPACE, '/settings', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'update'],
            'permission_callback' => [$this, 'checkPermission'],
        ]);

        // Test Crawlbase connection
        register_rest_route(self::NAMESPACE, '/settings/test-crawlbase', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'testCrawlbase'],
            'permission_callback' => [$this, 'checkPermission'],
        ]);

        // Test PA-API connection
        register_rest_route(self::NAMESPACE, '/settings/test-paapi', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'testPaapi'],
            'permission_callback' => [$this, 'checkPermission'],
        ]);

        // Update database schema for all plugins
        register_rest_route(self::NAMESPACE, '/settings/update-schema', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'updateSchema'],
            'permission_callback' => [$this, 'checkPermission'],
        ]);
    }

    /**
     * Check user permission
     */
    public function checkPermission(): bool
    {
        return current_user_can('manage_options');
    }

    /**
     * Get all settings
     */
    public function index(WP_REST_Request $request): WP_REST_Response
    {
        // Default general settings
        $defaultGeneral = [
            'default_provider' => 'crawlbase',
            'fallback_provider' => 'none',
            'cache_duration' => 24,
            'auto_update' => true,
            'default_template' => 'list',
            'show_price' => true,
            'show_rating' => true,
            'show_prime_badge' => true,
            'show_stock_status' => true,
            'show_update' => true,
            'rating_display_type' => 'score',
            'enable_utm' => false,
            'utm_source' => '',
            'utm_medium' => 'affiliate',
            'utm_apply_to_amazon' => false,
            'cf_param' => '',
            'redirect_enabled' => true,
            'redirect_slug' => 'go',
            'open_new_tab' => true,
            'nofollow_links' => true,
            'button_text' => 'View on Amazon',
            // Affiliate link settings
            'affiliate_tag' => '',
            'custom_url_params' => 'linkCode=ogi&th=1&psc=1',
            // Cache preload settings
            'cache_batch_size' => 30,
            'cache_path' => '/home/productreviewsorg/cache/fastcgi/',
        ];

        // Get saved general settings and merge with defaults
        $savedGeneral = get_option('acms_general_settings', []);
        $general = array_merge($defaultGeneral, is_array($savedGeneral) ? $savedGeneral : []);

        // Add WordPress built-in post types
        $wpPostTypes = [
            [
                'value' => 'post',
                'label' => 'Post',
                'enabled' => true,
                'is_builtin' => true,
            ],
            [
                'value' => 'page',
                'label' => 'Page',
                'enabled' => true,
                'is_builtin' => true,
            ],
        ];

        // Format custom post types for frontend dropdown
        $customPostTypes = [];
        foreach (PostTypeManager::getSettings() as $key => $config) {
            $customPostTypes[] = [
                'value' => 'acms_' . $key,
                'label' => $config['menu_name'],
                'enabled' => $config['enabled'],
                'is_builtin' => false,
            ];
        }

        // Merge WordPress + Custom post types (for dropdown)
        $allPostTypes = array_merge($wpPostTypes, $customPostTypes);

        // Get full post type configurations (for settings modal)
        $postTypeConfigs = PostTypeManager::getSettings();

        // Get automation settings (for Auto Update in General tab)
        $automationDefaults = [
            'update_enabled' => false,
            'update_interval' => 24,
            'update_worker_count' => 3,
            'worker_count' => 3,
        ];
        $automationSettings = get_option('acms_automation', $automationDefaults);
        $automation = array_merge($automationDefaults, is_array($automationSettings) ? $automationSettings : []);

        $settings = [
            'general' => $general,
            'automation' => [
                'update_enabled' => (bool) ($automation['update_enabled'] ?? $automation['rescrape_enabled'] ?? false),
                'update_interval' => (int) ($automation['update_interval'] ?? $automation['rescrape_interval'] ?? 24),
                'update_worker_count' => (int) ($automation['update_worker_count'] ?? 3),
                'worker_count' => (int) ($automation['worker_count'] ?? 3),
            ],
            'crawlbase' => [
                'token' => get_option('acms_crawlbase_token', ''),
                'has_token' => !empty(get_option('acms_crawlbase_token', '')),
            ],
            'paapi' => [
                'access_key' => get_option('acms_paapi_access_key', ''),
                'has_secret_key' => !empty(get_option('acms_paapi_secret_key', '')),
                'partner_tag' => get_option('acms_paapi_partner_tag', ''),
                'region' => get_option('acms_paapi_region', 'com'),
            ],
            'post_types' => $postTypeConfigs,
            'post_types_list' => $allPostTypes,
        ];

        return new WP_REST_Response([
            'success' => true,
            'data' => $settings,
        ]);
    }

    /**
     * Update settings
     */
    public function update(WP_REST_Request $request): WP_REST_Response
    {
        $params = $request->get_json_params();

        // Update general settings
        if (isset($params['general']) && is_array($params['general'])) {
            $general = $params['general'];
            $sanitizedGeneral = [
                'default_provider' => sanitize_text_field($general['default_provider'] ?? 'crawlbase'),
                'fallback_provider' => sanitize_text_field($general['fallback_provider'] ?? 'none'),
                'cache_duration' => absint($general['cache_duration'] ?? 24),
                'auto_update' => (bool) ($general['auto_update'] ?? true),
                'default_template' => sanitize_text_field($general['default_template'] ?? 'list'),
                'show_price' => (bool) ($general['show_price'] ?? true),
                'show_rating' => (bool) ($general['show_rating'] ?? true),
                'show_prime_badge' => (bool) ($general['show_prime_badge'] ?? true),
                'show_stock_status' => (bool) ($general['show_stock_status'] ?? true),
                'show_update' => (bool) ($general['show_update'] ?? true),
                'rating_display_type' => in_array($general['rating_display_type'] ?? 'score', ['score', 'star']) ? $general['rating_display_type'] : 'score',
                // UTM settings
                'enable_utm' => (bool) ($general['enable_utm'] ?? true),
                'utm_source' => sanitize_text_field($general['utm_source'] ?? ''),
                'utm_medium' => sanitize_text_field($general['utm_medium'] ?? 'affiliate'),
                'utm_apply_to_amazon' => (bool) ($general['utm_apply_to_amazon'] ?? false),
                'cf_param' => sanitize_text_field($general['cf_param'] ?? ''),
                'redirect_enabled' => (bool) ($general['redirect_enabled'] ?? true),
                'redirect_slug' => sanitize_title($general['redirect_slug'] ?? 'go'),
                'open_new_tab' => (bool) ($general['open_new_tab'] ?? true),
                'nofollow_links' => (bool) ($general['nofollow_links'] ?? true),
                'button_text' => sanitize_text_field($general['button_text'] ?? 'View on Amazon'),
                // Affiliate link settings
                'affiliate_tag' => sanitize_text_field($general['affiliate_tag'] ?? ''),
                'custom_url_params' => sanitize_text_field($general['custom_url_params'] ?? ''),
                // Cache preload settings
                'cache_batch_size' => max(10, min(100, absint($general['cache_batch_size'] ?? 30))),
                'cache_path' => rtrim(sanitize_text_field($general['cache_path'] ?? '/home/productreviewsorg/cache/fastcgi/'), '/') . '/',
            ];

            // Flush rewrite rules if redirect slug changed
            $oldGeneral = get_option('acms_general_settings', []);
            if (isset($oldGeneral['redirect_slug']) && $oldGeneral['redirect_slug'] !== $sanitizedGeneral['redirect_slug']) {
                flush_rewrite_rules();
            }

            update_option('acms_general_settings', $sanitizedGeneral);
        }

        // Update Crawlbase settings
        if (isset($params['crawlbase_token'])) {
            update_option('acms_crawlbase_token', sanitize_text_field($params['crawlbase_token']));
        }

        // Update PA-API settings
        if (isset($params['paapi_access_key'])) {
            update_option('acms_paapi_access_key', sanitize_text_field($params['paapi_access_key']));
        }

        if (isset($params['paapi_secret_key']) && !empty($params['paapi_secret_key'])) {
            update_option('acms_paapi_secret_key', sanitize_text_field($params['paapi_secret_key']));
        }

        if (isset($params['paapi_partner_tag'])) {
            update_option('acms_paapi_partner_tag', sanitize_text_field($params['paapi_partner_tag']));
        }

        if (isset($params['paapi_region'])) {
            $validRegions = ['com', 'co.uk', 'de', 'fr', 'it', 'es', 'ca', 'co.jp', 'in', 'com.au', 'com.br', 'com.mx'];
            if (in_array($params['paapi_region'], $validRegions, true)) {
                update_option('acms_paapi_region', $params['paapi_region']);
            }
        }

        // Update Post Types settings
        if (isset($params['post_types']) && is_array($params['post_types'])) {
            PostTypeManager::saveSettings($params['post_types']);
        }

        // Update Automation settings (Auto Update)
        if (isset($params['automation']) && is_array($params['automation'])) {
            $automation = $params['automation'];
            // Get existing automation settings to preserve cron_enabled and cron_schedule
            $existingAutomation = get_option('acms_automation', []);
            $sanitizedAutomation = array_merge(
                is_array($existingAutomation) ? $existingAutomation : [],
                [
                    'update_enabled' => (bool) ($automation['update_enabled'] ?? false),
                    'update_interval' => max(1, min(168, absint($automation['update_interval'] ?? 24))),
                    'update_worker_count' => max(1, min(50, absint($automation['update_worker_count'] ?? 3))),
                    'worker_count' => max(1, min(50, absint($automation['worker_count'] ?? 3))),
                ]
            );
            update_option('acms_automation', $sanitizedAutomation);
        }

        return new WP_REST_Response([
            'success' => true,
            'message' => __('Settings saved successfully', 'affiliatecms-pro'),
        ]);
    }

    /**
     * Test Crawlbase connection
     */
    public function testCrawlbase(WP_REST_Request $request): WP_REST_Response
    {
        $params = $request->get_json_params();
        $token = $params['token'] ?? get_option('acms_crawlbase_token', '');

        if (empty($token)) {
            return new WP_REST_Response([
                'success' => false,
                'message' => __('Crawlbase token is required', 'affiliatecms-pro'),
            ], 400);
        }

        // Test API connection
        $testUrl = 'https://www.amazon.com/dp/B08N5WRWNW';
        $apiUrl = 'https://api.crawlbase.com/?token=' . urlencode($token) . '&url=' . urlencode($testUrl);

        $response = wp_remote_get($apiUrl, [
            'timeout' => 30,
            'headers' => [
                'Accept' => 'text/html',
            ],
        ]);

        if (is_wp_error($response)) {
            return new WP_REST_Response([
                'success' => false,
                'message' => $response->get_error_message(),
            ], 500);
        }

        $statusCode = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);

        if ($statusCode === 200 && !empty($body)) {
            return new WP_REST_Response([
                'success' => true,
                'message' => __('Crawlbase connection successful', 'affiliatecms-pro'),
            ]);
        }

        return new WP_REST_Response([
            'success' => false,
            'message' => sprintf(__('Connection failed with status code: %d', 'affiliatecms-pro'), $statusCode),
        ], 400);
    }

    /**
     * Test PA-API connection
     */
    public function testPaapi(WP_REST_Request $request): WP_REST_Response
    {
        $params = $request->get_json_params();

        $accessKey = $params['access_key'] ?? get_option('acms_paapi_access_key', '');
        $secretKey = $params['secret_key'] ?? get_option('acms_paapi_secret_key', '');
        $partnerTag = $params['partner_tag'] ?? get_option('acms_paapi_partner_tag', '');
        $region = $params['region'] ?? get_option('acms_paapi_region', 'com');

        if (empty($accessKey) || empty($secretKey) || empty($partnerTag)) {
            return new WP_REST_Response([
                'success' => false,
                'message' => __('All PA-API credentials are required', 'affiliatecms-pro'),
            ], 400);
        }

        // Map region to host
        $hosts = [
            'com' => 'webservices.amazon.com',
            'co.uk' => 'webservices.amazon.co.uk',
            'de' => 'webservices.amazon.de',
            'fr' => 'webservices.amazon.fr',
            'it' => 'webservices.amazon.it',
            'es' => 'webservices.amazon.es',
            'ca' => 'webservices.amazon.ca',
            'co.jp' => 'webservices.amazon.co.jp',
            'in' => 'webservices.amazon.in',
            'com.au' => 'webservices.amazon.com.au',
            'com.br' => 'webservices.amazon.com.br',
            'com.mx' => 'webservices.amazon.com.mx',
        ];

        $host = $hosts[$region] ?? $hosts['com'];

        // Build PA-API request
        $serviceName = 'ProductAdvertisingAPI';
        $target = 'com.amazon.paapi5.v1.ProductAdvertisingAPIv1.GetItems';
        $payload = json_encode([
            'ItemIds' => ['B08N5WRWNW'],
            'PartnerTag' => $partnerTag,
            'PartnerType' => 'Associates',
            'Marketplace' => "www.amazon.{$region}",
            'Resources' => ['ItemInfo.Title'],
        ]);

        // AWS Signature Version 4
        $timestamp = gmdate('Ymd\THis\Z');
        $date = gmdate('Ymd');
        $awsRegion = $this->getAwsRegion($region);

        $canonicalUri = '/paapi5/getitems';
        $canonicalQueryString = '';
        $canonicalHeaders = "content-encoding:amz-1.0\n" .
            "content-type:application/json; charset=utf-8\n" .
            "host:{$host}\n" .
            "x-amz-date:{$timestamp}\n" .
            "x-amz-target:{$target}\n";
        $signedHeaders = 'content-encoding;content-type;host;x-amz-date;x-amz-target';
        $hashedPayload = hash('sha256', $payload);

        $canonicalRequest = "POST\n{$canonicalUri}\n{$canonicalQueryString}\n{$canonicalHeaders}\n{$signedHeaders}\n{$hashedPayload}";

        $credentialScope = "{$date}/{$awsRegion}/{$serviceName}/aws4_request";
        $stringToSign = "AWS4-HMAC-SHA256\n{$timestamp}\n{$credentialScope}\n" . hash('sha256', $canonicalRequest);

        $kSecret = 'AWS4' . $secretKey;
        $kDate = hash_hmac('sha256', $date, $kSecret, true);
        $kRegion = hash_hmac('sha256', $awsRegion, $kDate, true);
        $kService = hash_hmac('sha256', $serviceName, $kRegion, true);
        $kSigning = hash_hmac('sha256', 'aws4_request', $kService, true);
        $signature = hash_hmac('sha256', $stringToSign, $kSigning);

        $authorization = "AWS4-HMAC-SHA256 Credential={$accessKey}/{$credentialScope}, SignedHeaders={$signedHeaders}, Signature={$signature}";

        $response = wp_remote_post("https://{$host}{$canonicalUri}", [
            'timeout' => 30,
            'headers' => [
                'Content-Type' => 'application/json; charset=utf-8',
                'Content-Encoding' => 'amz-1.0',
                'Host' => $host,
                'X-Amz-Date' => $timestamp,
                'X-Amz-Target' => $target,
                'Authorization' => $authorization,
            ],
            'body' => $payload,
        ]);

        if (is_wp_error($response)) {
            return new WP_REST_Response([
                'success' => false,
                'message' => $response->get_error_message(),
            ], 500);
        }

        $statusCode = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);

        if ($statusCode === 200 && isset($body['ItemsResult'])) {
            return new WP_REST_Response([
                'success' => true,
                'message' => __('PA-API connection successful', 'affiliatecms-pro'),
            ]);
        }

        $errorMessage = $body['Errors'][0]['Message'] ?? __('Unknown error', 'affiliatecms-pro');

        return new WP_REST_Response([
            'success' => false,
            'message' => $errorMessage,
        ], 400);
    }

    /**
     * Get AWS region from marketplace
     */
    private function getAwsRegion(string $marketplace): string
    {
        $regions = [
            'com' => 'us-east-1',
            'ca' => 'us-east-1',
            'com.mx' => 'us-east-1',
            'com.br' => 'us-east-1',
            'co.uk' => 'eu-west-1',
            'de' => 'eu-west-1',
            'fr' => 'eu-west-1',
            'it' => 'eu-west-1',
            'es' => 'eu-west-1',
            'co.jp' => 'us-west-2',
            'in' => 'eu-west-1',
            'com.au' => 'us-west-2',
        ];

        return $regions[$marketplace] ?? 'us-east-1';
    }

    /**
     * POST /settings/update-schema - Force create/update all plugin database tables
     */
    public function updateSchema(WP_REST_Request $request): WP_REST_Response
    {
        global $wpdb;

        $results = [];

        // 1. Pro plugin
        try {
            \AffiliateCMS\Pro\Database\Schema::instance()->install();
            $results['affiliatecms_pro'] = ['success' => true, 'message' => 'Schema updated'];
        } catch (\Throwable $e) {
            $results['affiliatecms_pro'] = ['success' => false, 'message' => $e->getMessage()];
        }

        // 2. Cat plugin
        if (class_exists(\AffiliateCMS\Categories\Database\Schema::class)) {
            try {
                \AffiliateCMS\Categories\Database\Schema::install();
                $results['affiliatecms_cat'] = ['success' => true, 'message' => 'Schema updated'];
            } catch (\Throwable $e) {
                $results['affiliatecms_cat'] = ['success' => false, 'message' => $e->getMessage()];
            }
        } else {
            $results['affiliatecms_cat'] = ['success' => false, 'message' => 'Plugin not active'];
        }

        // 3. AI plugin
        if (class_exists(\AffiliateCMS\AI\Database\Schema::class)) {
            try {
                $schema = new \AffiliateCMS\AI\Database\Schema();
                $schema->createTables();
                $results['affiliatecms_ai'] = ['success' => true, 'message' => 'Schema updated'];
            } catch (\Throwable $e) {
                $results['affiliatecms_ai'] = ['success' => false, 'message' => $e->getMessage()];
            }
        } else {
            $results['affiliatecms_ai'] = ['success' => false, 'message' => 'Plugin not active'];
        }

        // List all ACMS tables
        $tables = $wpdb->get_col("SHOW TABLES LIKE '%acms%'");

        $allSuccess = !in_array(false, array_column($results, 'success'), true);

        return new WP_REST_Response([
            'success' => $allSuccess,
            'message' => $allSuccess ? 'All schemas updated successfully' : 'Some schemas failed',
            'data' => [
                'plugins' => $results,
                'tables' => $tables,
                'tables_count' => count($tables),
            ],
        ]);
    }
}
