<?php
/**
 * Brand REST API Controller
 *
 * Handles REST API endpoints for brand management.
 * Brands are flat (no hierarchy) - simpler than categories.
 *
 * @package AffiliateCMS\Pro\Api
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro\Api;

use AffiliateCMS\Pro\Repositories\BrandRepository;
use WP_REST_Controller;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;
use WP_Error;

class BrandController extends WP_REST_Controller
{
    protected $namespace = 'acms/v1';
    protected $rest_base = 'brands';

    private BrandRepository $repository;

    public function __construct()
    {
        $this->repository = BrandRepository::instance();
    }

    /**
     * Register the controller
     */
    public function register(): void
    {
        $this->registerRoutes();
    }

    /**
     * Register REST routes
     */
    public function registerRoutes(): void
    {
        // GET /brands - List all brands
        // POST /brands - Create brand
        register_rest_route($this->namespace, '/' . $this->rest_base, [
            [
                'methods' => WP_REST_Server::READABLE,
                'callback' => [$this, 'getBrands'],
                'permission_callback' => '__return_true',
                'args' => $this->getCollectionParams(),
            ],
            [
                'methods' => WP_REST_Server::CREATABLE,
                'callback' => [$this, 'createBrand'],
                'permission_callback' => [$this, 'adminPermissionCheck'],
                'args' => $this->getCreateParams(),
            ],
        ]);

        // GET /brands/stats - Get statistics
        register_rest_route($this->namespace, '/' . $this->rest_base . '/stats', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'getStats'],
            'permission_callback' => [$this, 'adminPermissionCheck'],
        ]);

        // GET /brands/search - Search brands
        register_rest_route($this->namespace, '/' . $this->rest_base . '/search', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'searchBrands'],
            'permission_callback' => '__return_true',
            'args' => [
                'term' => [
                    'required' => true,
                    'sanitize_callback' => 'sanitize_text_field',
                ],
                'limit' => [
                    'default' => 20,
                    'sanitize_callback' => 'absint',
                ],
            ],
        ]);

        // GET/PUT/DELETE /brands/{id}
        register_rest_route($this->namespace, '/' . $this->rest_base . '/(?P<id>\d+)', [
            [
                'methods' => WP_REST_Server::READABLE,
                'callback' => [$this, 'getBrand'],
                'permission_callback' => '__return_true',
            ],
            [
                'methods' => WP_REST_Server::EDITABLE,
                'callback' => [$this, 'updateBrand'],
                'permission_callback' => [$this, 'adminPermissionCheck'],
                'args' => $this->getUpdateParams(),
            ],
            [
                'methods' => WP_REST_Server::DELETABLE,
                'callback' => [$this, 'deleteBrand'],
                'permission_callback' => [$this, 'adminPermissionCheck'],
            ],
        ]);

        // GET /brands/{id}/products
        register_rest_route($this->namespace, '/' . $this->rest_base . '/(?P<id>\d+)/products', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'getProducts'],
            'permission_callback' => '__return_true',
            'args' => [
                'limit' => [
                    'default' => 20,
                    'sanitize_callback' => 'absint',
                ],
                'offset' => [
                    'default' => 0,
                    'sanitize_callback' => 'absint',
                ],
            ],
        ]);

        // GET /brands/slug/{slug} - Get by slug
        register_rest_route($this->namespace, '/' . $this->rest_base . '/slug/(?P<slug>[a-z0-9-]+)', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'getBrandBySlug'],
            'permission_callback' => '__return_true',
        ]);

        // POST /brands/bulk-ai - Bulk AI content generation
        register_rest_route($this->namespace, '/' . $this->rest_base . '/bulk-ai', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'bulkAiGeneration'],
            'permission_callback' => [$this, 'adminPermissionCheck'],
            'args' => [
                'action' => [
                    'required' => true,
                    'enum' => ['generate', 'regenerate'],
                    'sanitize_callback' => 'sanitize_text_field',
                ],
                'brand_ids' => [
                    'required' => true,
                    'type' => 'array',
                    'items' => ['type' => 'integer'],
                ],
            ],
        ]);

        // POST /brands/sync-products - Sync product counts
        register_rest_route($this->namespace, '/' . $this->rest_base . '/sync-products', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'syncProductCounts'],
            'permission_callback' => [$this, 'adminPermissionCheck'],
        ]);

        // POST /brands/import-taxonomy - Import from acms_reviews_brand taxonomy
        register_rest_route($this->namespace, '/' . $this->rest_base . '/import-taxonomy', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'importFromTaxonomy'],
            'permission_callback' => [$this, 'adminPermissionCheck'],
        ]);

        // POST /brands/run-ai - Manually trigger brand AI cron
        register_rest_route($this->namespace, '/' . $this->rest_base . '/run-ai', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'runAiNow'],
            'permission_callback' => [$this, 'adminPermissionCheck'],
        ]);

        // GET /brands/debug-ai - Debug AI processing status
        register_rest_route($this->namespace, '/' . $this->rest_base . '/debug-ai', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'debugAi'],
            'permission_callback' => [$this, 'adminPermissionCheck'],
        ]);

        // POST /brands/reset-stuck - Reset stuck generating brands
        register_rest_route($this->namespace, '/' . $this->rest_base . '/reset-stuck', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'resetStuck'],
            'permission_callback' => [$this, 'adminPermissionCheck'],
        ]);
    }

    // =========================================
    // Permission Checks
    // =========================================

    public function adminPermissionCheck(): bool
    {
        return current_user_can('manage_options');
    }

    // =========================================
    // Endpoint Handlers
    // =========================================

    /**
     * Get all brands
     */
    public function getBrands(WP_REST_Request $request): WP_REST_Response
    {
        $args = [
            'status' => $request->get_param('status') ?: '',
            'content_status' => $request->get_param('content_status') ?: '',
            'search' => $request->get_param('search') ?: '',
            'orderby' => $request->get_param('orderby') ?: 'name',
            'order' => $request->get_param('order') ?: 'ASC',
            'page' => (int) $request->get_param('page') ?: 1,
            'per_page' => (int) $request->get_param('per_page') ?: 50,
        ];

        $result = $this->repository->all($args);

        return new WP_REST_Response([
            'success' => true,
            'data' => $result,
        ]);
    }

    /**
     * Get single brand
     */
    public function getBrand(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $id = (int) $request->get_param('id');
        $brand = $this->repository->find($id);

        if (!$brand) {
            return new WP_Error('not_found', 'Brand not found', ['status' => 404]);
        }

        return new WP_REST_Response([
            'success' => true,
            'data' => $brand,
        ]);
    }

    /**
     * Get brand by slug
     */
    public function getBrandBySlug(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $slug = $request->get_param('slug');
        $brand = $this->repository->findBySlug($slug);

        if (!$brand) {
            return new WP_Error('not_found', 'Brand not found', ['status' => 404]);
        }

        return new WP_REST_Response([
            'success' => true,
            'data' => $brand,
        ]);
    }

    /**
     * Create brand
     */
    public function createBrand(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $data = [
            'name' => $request->get_param('name'),
            'slug' => $request->get_param('slug'),
            'description' => $request->get_param('description'),
            'logo_url' => $request->get_param('logo_url'),
            'banner_url' => $request->get_param('banner_url'),
            'website_url' => $request->get_param('website_url'),
            'seo_title' => $request->get_param('seo_title'),
            'seo_description' => $request->get_param('seo_description'),
            'status' => $request->get_param('status') ?: 'draft',
        ];

        $data = array_filter($data, fn($v) => $v !== null);

        $id = $this->repository->create($data);

        if (!$id) {
            return new WP_Error('create_failed', 'Failed to create brand', ['status' => 500]);
        }

        $brand = $this->repository->find($id);

        return new WP_REST_Response([
            'success' => true,
            'data' => $brand,
            'message' => 'Brand created successfully',
        ], 201);
    }

    /**
     * Update brand
     */
    public function updateBrand(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $id = (int) $request->get_param('id');
        $brand = $this->repository->find($id);

        if (!$brand) {
            return new WP_Error('not_found', 'Brand not found', ['status' => 404]);
        }

        $data = [];
        $fields = [
            'name',
            'slug',
            'description',
            'logo_url',
            'banner_url',
            'website_url',
            'seo_title',
            'seo_description',
            'content_intro',
            'content_main',
            'content_faq',
            'content_status',
            'status'
        ];

        foreach ($fields as $field) {
            $value = $request->get_param($field);
            if ($value !== null) {
                $data[$field] = $value;
            }
        }

        if (empty($data)) {
            return new WP_Error('no_data', 'No data to update', ['status' => 400]);
        }

        $result = $this->repository->update($id, $data);

        if (!$result) {
            return new WP_Error('update_failed', 'Failed to update brand', ['status' => 500]);
        }

        $brand = $this->repository->find($id);

        return new WP_REST_Response([
            'success' => true,
            'data' => $brand,
            'message' => 'Brand updated successfully',
        ]);
    }

    /**
     * Delete brand
     */
    public function deleteBrand(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $id = (int) $request->get_param('id');
        $brand = $this->repository->find($id);

        if (!$brand) {
            return new WP_Error('not_found', 'Brand not found', ['status' => 404]);
        }

        $result = $this->repository->delete($id);

        if (!$result) {
            return new WP_Error('delete_failed', 'Failed to delete brand', ['status' => 500]);
        }

        return new WP_REST_Response([
            'success' => true,
            'message' => 'Brand deleted successfully',
        ]);
    }

    /**
     * Search brands
     */
    public function searchBrands(WP_REST_Request $request): WP_REST_Response
    {
        $term = $request->get_param('term');
        $limit = (int) $request->get_param('limit');

        $brands = $this->repository->search($term, $limit);

        return new WP_REST_Response([
            'success' => true,
            'data' => $brands,
            'total' => count($brands),
        ]);
    }

    /**
     * Get brand products
     */
    public function getProducts(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $id = (int) $request->get_param('id');
        $limit = (int) $request->get_param('limit');
        $offset = (int) $request->get_param('offset');

        $brand = $this->repository->find($id);
        if (!$brand) {
            return new WP_Error('not_found', 'Brand not found', ['status' => 404]);
        }

        // getProducts() uses JOIN internally — no extra find() inside
        $products = $this->repository->getProducts($id, $limit, $offset);

        return new WP_REST_Response([
            'success' => true,
            'data' => $products,
            'total' => (int) $brand['product_count'],
            'limit' => $limit,
            'offset' => $offset,
        ]);
    }

    /**
     * Get statistics
     */
    public function getStats(WP_REST_Request $request): WP_REST_Response
    {
        $stats = $this->repository->getStats();

        return new WP_REST_Response([
            'success' => true,
            'data' => $stats,
        ]);
    }

    /**
     * Sync product counts
     */
    public function syncProductCounts(WP_REST_Request $request): WP_REST_Response
    {
        // First, import any new brands from products
        $imported = $this->repository->importBrandsFromProducts();

        // Then update product counts for all brands
        $updated = $this->repository->updateAllProductCounts();

        $message = '';
        if ($imported['created'] > 0) {
            $message .= "{$imported['created']} new brands imported. ";
        }
        $message .= "{$updated} brands synced.";

        return new WP_REST_Response([
            'success' => true,
            'message' => trim($message),
            'data' => [
                'imported' => $imported['created'],
                'existing' => $imported['existing'],
                'updated' => $updated,
            ],
        ]);
    }

    /**
     * Manually trigger brand AI content generation
     * Processes jobs SYNCHRONOUSLY (not relying on AS queue)
     */
    public function runAiNow(WP_REST_Request $request): WP_REST_Response
    {
        // Extend execution time for synchronous AI processing
        @set_time_limit(300);
        @ini_set('max_execution_time', '300');

        global $wpdb;

        // First sync product counts to ensure accuracy
        $this->repository->importBrandsFromProducts();
        $this->repository->updateAllProductCounts();

        // Check setting
        $enabled = get_option('acms_ai_seo_brand_enabled', true);

        // Count qualifying brands
        $table = $wpdb->prefix . 'acms_brands';
        $emptyCount = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$table} WHERE content_status = 'empty' AND product_count >= 3"
        );
        $generatingCount = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$table} WHERE content_status = 'ai_generating'"
        );
        $totalBrands = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table}");

        // Create jobs via BrandAiCron
        $jobsTable = $wpdb->prefix . 'acms_ai_jobs';
        $pendingBefore = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$jobsTable} WHERE type = 'generate_seo_brand' AND status IN ('pending', 'processing')"
        );

        // generateContent() now does inline processing (creates job + API call + saves to DB)
        // Pass limit=5 for manual runs (more brands per click)
        $startTime = microtime(true);
        if (class_exists(\AffiliateCMS\Pro\Core\BrandAiCron::class)) {
            $cron = \AffiliateCMS\Pro\Core\BrandAiCron::instance();
            $cron->generateContent(5);
        }
        $duration = round(microtime(true) - $startTime, 1);

        // Count results after processing
        $completedJobs = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$jobsTable}
             WHERE type = 'generate_seo_brand'
             AND status = 'completed'
             AND completed_at >= %s",
            wp_date('Y-m-d H:i:s', (int) ($startTime))
        ));
        $failedJobs = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$jobsTable}
             WHERE type = 'generate_seo_brand'
             AND status = 'failed'
             AND processing_at >= %s",
            wp_date('Y-m-d H:i:s', (int) ($startTime))
        ));

        // Build response message
        if ($completedJobs > 0) {
            $message = "Processed {$completedJobs} brand(s) successfully in {$duration}s";
            if ($failedJobs > 0) {
                $message .= ", {$failedJobs} failed";
            }
        } else {
            $message = "No brands processed in {$duration}s. Empty: {$emptyCount}, Generating: {$generatingCount}";
            if ($failedJobs > 0) {
                $message .= ", {$failedJobs} failed";
            }
        }

        return new WP_REST_Response([
            'success' => true,
            'message' => $message,
            'data' => [
                'enabled' => $enabled,
                'total_brands' => $totalBrands,
                'empty_content' => $emptyCount,
                'ai_generating' => $generatingCount,
                'processed' => $completedJobs,
                'failed' => $failedJobs,
                'duration_s' => $duration,
            ],
        ]);
    }

    /**
     * Import brands from taxonomy
     * Migrates data from acms_reviews_brand taxonomy to acms_brands table
     */
    public function importFromTaxonomy(WP_REST_Request $request): WP_REST_Response
    {
        $result = $this->repository->importFromTaxonomy();

        $message = '';
        if ($result['imported'] > 0) {
            $message .= "{$result['imported']} brands imported from taxonomy. ";
        }
        if ($result['linked'] > 0) {
            $message .= "{$result['linked']} existing brands linked to taxonomy terms. ";
        }
        if ($result['skipped'] > 0) {
            $message .= "{$result['skipped']} already linked.";
        }
        if (empty($message)) {
            $message = 'No taxonomy terms to import.';
        }

        return new WP_REST_Response([
            'success' => true,
            'message' => trim($message),
            'data' => $result,
        ]);
    }

    /**
     * Bulk AI content generation
     * Processes jobs synchronously for immediate results
     */
    public function bulkAiGeneration(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        // Extend execution time for synchronous AI processing
        @set_time_limit(300);
        @ini_set('max_execution_time', '300');

        global $wpdb;

        $action = $request->get_param('action');
        $brandIds = $request->get_param('brand_ids');

        // Validate brand_ids
        if (!is_array($brandIds) || empty($brandIds)) {
            return new WP_Error('invalid_ids', 'brand_ids must be a non-empty array', ['status' => 400]);
        }

        // Limit to 10 brands per request for synchronous processing (prevent timeout)
        if (count($brandIds) > 10) {
            return new WP_Error('too_many', 'Maximum 10 brands per request for synchronous processing', ['status' => 400]);
        }

        // Sanitize IDs
        $brandIds = array_map('absint', $brandIds);
        $brandIds = array_filter($brandIds);

        // Check if AI plugin is active (jobs table exists)
        $jobsTable = $wpdb->prefix . 'acms_ai_jobs';
        $tableExists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $jobsTable));
        if ($tableExists !== $jobsTable) {
            return new WP_Error('ai_not_active', 'AI plugin is not active. Please activate affiliatecms-ai plugin.', ['status' => 400]);
        }

        $processed = 0;
        $failed = 0;
        $skipped = 0;
        $alreadyProcessing = 0;
        $alreadyGenerated = 0;
        $startTime = microtime(true);

        foreach ($brandIds as $brandId) {
            $brand = $this->repository->find($brandId);

            if (!$brand) {
                $skipped++;
                continue;
            }

            // Check for existing pending/processing job
            $existingJob = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$jobsTable}
                 WHERE type = 'generate_seo_brand'
                 AND target_type = 'seo_brand'
                 AND target_id = %s
                 AND status IN ('pending', 'processing')",
                (string) $brandId
            ));

            if ($existingJob) {
                $alreadyProcessing++;
                continue;
            }

            // For "generate" action: skip if already has content (allow empty + stuck ai_generating)
            if ($action === 'generate' && !in_array($brand['content_status'], ['empty', 'ai_generating'], true)) {
                $alreadyGenerated++;
                continue;
            }

            // For "regenerate" action: reset content fields
            if ($action === 'regenerate') {
                $this->repository->update($brandId, [
                    'content_intro' => null,
                    'content_main' => null,
                    'content_faq' => null,
                    'seo_title' => null,
                    'seo_description' => null,
                    'content_status' => 'empty',
                    'ai_error_message' => null,
                ]);
                // Refresh brand data after reset
                $brand = $this->repository->find($brandId);
            }

            // Create AI job and PROCESS SYNCHRONOUSLY
            $success = $this->createAiJobForBrand($brandId, $brand, true);
            if ($success) {
                $processed++;
            } else {
                $failed++;
            }

            // Small delay between brands to avoid rate limiting
            usleep(300000); // 0.3 second
        }

        $duration = round(microtime(true) - $startTime, 1);

        $message = "Processed {$processed} brand(s) in {$duration}s";
        if ($failed > 0) {
            $message .= ", {$failed} failed";
        }
        if ($skipped > 0) {
            $message .= ", {$skipped} skipped";
        }
        if ($alreadyProcessing > 0) {
            $message .= ", {$alreadyProcessing} already processing";
        }
        if ($alreadyGenerated > 0 && $action === 'generate') {
            $message .= ", {$alreadyGenerated} already have content";
        }

        return new WP_REST_Response([
            'success' => true,
            'message' => $message,
            'data' => [
                'processed' => $processed,
                'failed' => $failed,
                'skipped' => $skipped,
                'already_processing' => $alreadyProcessing,
                'already_generated' => $alreadyGenerated,
                'duration_s' => $duration,
            ],
        ]);
    }

    /**
     * Create AI job for a single brand
     *
     * @param int $brandId Brand ID
     * @param array $brand Brand data
     * @param bool $processNow Process synchronously (true) or via AS (false)
     * @return bool True if job created (and optionally processed) successfully
     */
    private function createAiJobForBrand(int $brandId, array $brand, bool $processNow = false): bool
    {
        global $wpdb;
        $jobsTable = $wpdb->prefix . 'acms_ai_jobs';

        // Mark brand as generating
        $this->repository->update($brandId, [
            'content_status' => 'ai_generating',
            'ai_generating_at' => current_time('mysql'),
            'ai_error_message' => null,
        ]);

        // Get sample products for context
        $products = $this->repository->getProducts($brandId, 15, 0);

        // Prepare job input data
        $inputData = [
            'brand_id' => $brandId,
            'brand_name' => $brand['name'],
            'brand_slug' => $brand['slug'] ?? '',
            'website_url' => $brand['website_url'] ?? '',
            'products' => $products,
            'total_product_count' => (int) ($brand['product_count'] ?? 0),
            'current_description' => $brand['description'] ?? '',
        ];

        // Create the job
        $inserted = $wpdb->insert($jobsTable, [
            'type' => 'generate_seo_brand',
            'status' => 'pending',
            'priority' => 35,
            'target_type' => 'seo_brand',
            'target_id' => (string) $brandId,
            'input_data' => wp_json_encode($inputData),
            'created_at' => current_time('mysql'),
        ]);

        if (!$inserted) {
            $this->repository->update($brandId, [
                'content_status' => 'empty',
                'ai_error_message' => 'Failed to create AI job',
            ]);
            return false;
        }

        $jobId = (int) $wpdb->insert_id;

        // Process synchronously if requested (manual trigger from admin)
        if ($processNow && class_exists(\AffiliateCMS\AI\Core\JobProcessor::class)) {
            try {
                $job = $wpdb->get_row($wpdb->prepare(
                    "SELECT * FROM {$jobsTable} WHERE id = %d",
                    $jobId
                ), ARRAY_A);

                if ($job) {
                    $processor = new \AffiliateCMS\AI\Core\JobProcessor();
                    $processor->processSingleJob($job);
                    return true;
                }
            } catch (\Throwable $e) {
                error_log("[ACMS BrandController] Sync processing job #{$jobId} failed: " . $e->getMessage());
                // Job failure handling is inside processSingleJob, brand will be reset there
                return false;
            }
        }

        // Job will be picked up by WP-Cron fallback (acms_ai_process_queue)
        return true;
    }

    /**
     * Debug AI processing - shows jobs, AS actions, stuck brands
     */
    public function debugAi(WP_REST_Request $request): WP_REST_Response
    {
        global $wpdb;
        $brandsTable = $wpdb->prefix . 'acms_brands';
        $jobsTable = $wpdb->prefix . 'acms_ai_jobs';
        $debug = [];

        // 1. Stuck brands (ai_generating)
        $debug['stuck_brands'] = $wpdb->get_results(
            "SELECT id, name, content_status, ai_generating_at, ai_error_message
             FROM {$brandsTable}
             WHERE content_status = 'ai_generating'
             ORDER BY ai_generating_at ASC",
            ARRAY_A
        ) ?: [];

        // 2. Recent brand AI jobs (last 20)
        $jobsTableExists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $jobsTable)) === $jobsTable;
        if ($jobsTableExists) {
            $debug['recent_jobs'] = $wpdb->get_results(
                "SELECT id, status, target_id, error_message, created_at, processing_at, completed_at, attempts,
                        TIMESTAMPDIFF(SECOND, processing_at, NOW()) as processing_seconds
                 FROM {$jobsTable}
                 WHERE type = 'generate_seo_brand'
                 ORDER BY created_at DESC
                 LIMIT 20",
                ARRAY_A
            ) ?: [];

            // 3. Job stats
            $debug['job_stats'] = [
                'pending' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$jobsTable} WHERE type = 'generate_seo_brand' AND status = 'pending'"),
                'processing' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$jobsTable} WHERE type = 'generate_seo_brand' AND status = 'processing'"),
                'completed' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$jobsTable} WHERE type = 'generate_seo_brand' AND status = 'completed'"),
                'failed' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$jobsTable} WHERE type = 'generate_seo_brand' AND status = 'failed'"),
            ];
        }

        // 5. API config check
        $debug['config'] = [
            'api_key_set' => !empty(get_option('acms_ai_api_key', '')),
            'model' => get_option('acms_ai_default_model', 'not set'),
            'brand_ai_enabled' => (bool) get_option('acms_ai_seo_brand_enabled', true),
        ];

        // 6. Brand content stats
        $debug['brand_stats'] = [
            'total' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$brandsTable}"),
            'empty' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$brandsTable} WHERE content_status = 'empty'"),
            'ai_generating' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$brandsTable} WHERE content_status = 'ai_generating'"),
            'ai_generated' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$brandsTable} WHERE content_status = 'ai_generated'"),
            'with_products_gte3' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$brandsTable} WHERE product_count >= 3"),
        ];

        // 7. Diagnostic: Test job table insert + API connectivity
        $diagnostics = [];
        if ($jobsTableExists) {
            // Test: Can we insert into the jobs table?
            $testInserted = $wpdb->insert($jobsTable, [
                'type' => 'generate_seo_brand',
                'status' => 'failed',
                'priority' => 0,
                'target_type' => 'diagnostic_test',
                'target_id' => '0',
                'input_data' => '{"test":true}',
                'error_message' => 'Diagnostic test - auto-deleted',
                'created_at' => current_time('mysql'),
            ]);
            if ($testInserted) {
                $testId = $wpdb->insert_id;
                $wpdb->delete($jobsTable, ['id' => $testId]);
                $diagnostics['job_table_writable'] = true;
            } else {
                $diagnostics['job_table_writable'] = false;
                $diagnostics['job_table_error'] = $wpdb->last_error;
            }

            // Show table columns
            $columns = $wpdb->get_results("SHOW COLUMNS FROM {$jobsTable}", ARRAY_A);
            $diagnostics['job_table_columns'] = array_column($columns ?: [], 'Field');
        } else {
            $diagnostics['job_table_writable'] = false;
            $diagnostics['job_table_error'] = 'Table does not exist';
        }

        // Test API connectivity (quick HEAD/options check)
        $apiKey = get_option('acms_ai_api_key', '');
        if (!empty($apiKey)) {
            $testResponse = wp_remote_post('https://openrouter.ai/api/v1/chat/completions', [
                'headers' => [
                    'Authorization' => 'Bearer ' . $apiKey,
                    'Content-Type' => 'application/json',
                ],
                'body' => wp_json_encode([
                    'model' => get_option('acms_ai_default_model', 'google/gemini-3-flash-preview'),
                    'messages' => [['role' => 'user', 'content' => 'Say "OK" only.']],
                    'max_tokens' => 5,
                ]),
                'timeout' => 15,
            ]);
            if (is_wp_error($testResponse)) {
                $diagnostics['api_connection'] = false;
                $diagnostics['api_error'] = $testResponse->get_error_message();
            } else {
                $httpCode = wp_remote_retrieve_response_code($testResponse);
                $body = json_decode(wp_remote_retrieve_body($testResponse), true);
                $diagnostics['api_connection'] = ($httpCode === 200);
                $diagnostics['api_http_code'] = $httpCode;
                if ($httpCode !== 200) {
                    $diagnostics['api_error'] = $body['error']['message'] ?? "HTTP {$httpCode}";
                }
            }
        } else {
            $diagnostics['api_connection'] = false;
            $diagnostics['api_error'] = 'API key not configured';
        }

        // Check PHP error log for recent brand AI entries
        $logFile = ini_get('error_log') ?: (defined('WP_CONTENT_DIR') ? WP_CONTENT_DIR . '/debug.log' : '');
        $diagnostics['error_log_path'] = $logFile;
        $recentLogs = [];
        if ($logFile && file_exists($logFile) && is_readable($logFile)) {
            $lines = file($logFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            if ($lines) {
                $lastLines = array_slice($lines, -200);
                foreach ($lastLines as $line) {
                    if (stripos($line, 'BrandAiCron') !== false || stripos($line, 'brand_ai') !== false || stripos($line, 'generate_seo_brand') !== false) {
                        $recentLogs[] = $line;
                    }
                }
                $recentLogs = array_slice($recentLogs, -15);
            }
        }
        $diagnostics['recent_logs'] = $recentLogs;

        $debug['diagnostics'] = $diagnostics;

        return new WP_REST_Response([
            'success' => true,
            'data' => $debug,
            'timestamp' => current_time('mysql'),
        ]);
    }

    /**
     * Reset stuck brands (ai_generating) and their jobs
     */
    public function resetStuck(WP_REST_Request $request): WP_REST_Response
    {
        global $wpdb;
        $brandsTable = $wpdb->prefix . 'acms_brands';
        $jobsTable = $wpdb->prefix . 'acms_ai_jobs';
        $results = [];

        // 1. Reset stuck brands
        $stuckBrands = $wpdb->query(
            "UPDATE {$brandsTable}
             SET content_status = 'empty', ai_error_message = 'Manual reset by admin'
             WHERE content_status = 'ai_generating'"
        );
        $results['brands_reset'] = (int) $stuckBrands;

        // 2. Reset stuck jobs
        $jobsTableExists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $jobsTable)) === $jobsTable;
        if ($jobsTableExists) {
            $stuckJobs = $wpdb->query(
                "UPDATE {$jobsTable}
                 SET status = 'failed', error_message = 'Manual reset by admin'
                 WHERE type = 'generate_seo_brand'
                 AND status = 'processing'"
            );
            $results['jobs_reset'] = (int) $stuckJobs;
        }

        $message = "Reset: {$results['brands_reset']} brand(s)";
        if (!empty($results['jobs_reset'])) {
            $message .= ", {$results['jobs_reset']} job(s)";
        }

        return new WP_REST_Response([
            'success' => true,
            'message' => $message,
            'data' => $results,
        ]);
    }

    // =========================================
    // Parameter Definitions
    // =========================================

    protected function getCollectionParams(): array
    {
        return [
            'status' => [
                'default' => '',
                'enum' => ['', 'publish', 'draft', 'all'],
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'content_status' => [
                'default' => '',
                'enum' => ['', 'empty', 'ai_generating', 'ai_generated', 'manual', 'all'],
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'search' => [
                'default' => '',
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'orderby' => [
                'default' => 'name',
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'order' => [
                'default' => 'ASC',
                'enum' => ['ASC', 'DESC'],
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'page' => [
                'default' => 1,
                'sanitize_callback' => 'absint',
            ],
            'per_page' => [
                'default' => 50,
                'sanitize_callback' => 'absint',
            ],
        ];
    }

    protected function getCreateParams(): array
    {
        return [
            'name' => [
                'required' => true,
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'slug' => [
                'sanitize_callback' => 'sanitize_title',
            ],
            'description' => [
                'sanitize_callback' => 'sanitize_textarea_field',
            ],
            'logo_url' => [
                'sanitize_callback' => 'esc_url_raw',
            ],
            'banner_url' => [
                'sanitize_callback' => 'esc_url_raw',
            ],
            'website_url' => [
                'sanitize_callback' => 'esc_url_raw',
            ],
            'seo_title' => [
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'seo_description' => [
                'sanitize_callback' => 'sanitize_textarea_field',
            ],
            'status' => [
                'default' => 'draft',
                'enum' => ['publish', 'draft'],
                'sanitize_callback' => 'sanitize_text_field',
            ],
        ];
    }

    protected function getUpdateParams(): array
    {
        $params = $this->getCreateParams();
        unset($params['name']['required']);
        return $params;
    }
}
