<?php
/**
 * Amazon REST API Controller
 *
 * REST endpoints for Amazon search and product data
 * Base URL: /acms/v1/amazon
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro\Api;

use AffiliateCMS\Pro\Core\ProviderManager;
use WP_REST_Request;
use WP_REST_Response;
use WP_Error;

class AmazonController
{
    private string $namespace = 'acms/v1';
    private ProviderManager $provider;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->provider = ProviderManager::instance();
    }

    /**
     * Register REST API routes
     */
    public function register(): void
    {
        $this->registerRoutes();
    }

    /**
     * Register routes
     */
    public function registerRoutes(): void
    {
        // POST /amazon/search - Search Amazon products
        register_rest_route($this->namespace, '/amazon/search', [
            'methods' => 'POST',
            'callback' => [$this, 'search'],
            'permission_callback' => [$this, 'checkPermission'],
            'args' => [
                'query' => [
                    'required' => true,
                    'type' => 'string',
                    'description' => 'Search query',
                    'minLength' => 2,
                ],
                'domain' => [
                    'default' => 'amazon.com',
                    'type' => 'string',
                    'description' => 'Amazon domain',
                ],
            ],
        ]);
    }

    /**
     * Check admin permission
     */
    public function checkPermission(): bool
    {
        return current_user_can('manage_options');
    }

    /**
     * POST /amazon/search - Search Amazon products
     */
    public function search(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $query = trim($request->get_param('query') ?? '');
        $domain = $request->get_param('domain') ?? 'amazon.com';

        if (strlen($query) < 2) {
            return new WP_Error(
                'invalid_query',
                'Search query must be at least 2 characters',
                ['status' => 400]
            );
        }

        // Check if any provider is configured
        if (!$this->provider->hasAnyProvider()) {
            return new WP_Error(
                'no_provider_configured',
                'No provider is configured. Please configure Crawlbase or PA-API in Settings.',
                ['status' => 400]
            );
        }

        // Perform search using configured provider priority
        $results = $this->provider->searchProducts($query, $domain);

        if ($results === null) {
            $error = $this->provider->getCrawlbaseError() ?? $this->provider->getPaapiError() ?? 'Search failed';
            return new WP_Error(
                'search_failed',
                $error,
                ['status' => 500]
            );
        }

        return new WP_REST_Response([
            'success' => true,
            'data' => $results,
            'message' => count($results) . ' products found',
        ]);
    }
}
