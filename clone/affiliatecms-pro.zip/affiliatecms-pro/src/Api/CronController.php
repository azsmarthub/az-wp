<?php
/**
 * Cron REST API Controller
 *
 * Provides endpoints for server cron integration and manual cron execution.
 *
 * @package AffiliateCMS\Pro\Api
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro\Api;

use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;
use WP_Error;
use AffiliateCMS\Pro\Core\ProductAiCron;
use AffiliateCMS\Pro\Core\PostAiCron;
use AffiliateCMS\Pro\Core\ScrapeMonitorCron;
use AffiliateCMS\Pro\Core\BrandAiCron;
use AffiliateCMS\Pro\Core\DateUpdateCron;

class CronController
{
    private const NAMESPACE = 'acms/v1';
    private const MAX_LOGS = 20;
    private const LOG_OPTION_PREFIX = 'acms_cron_logs_';

    /**
     * Acquire a transient lock to prevent overlapping execution.
     *
     * When multiple cron triggers hit the same handler,
     * only the first one executes — the rest skip gracefully.
     *
     * @param string $key Lock identifier (e.g., 'product_ai')
     * @param int $ttlSeconds Lock duration in seconds (default: 240s for 5-min interval tasks)
     * @return bool True if lock acquired, false if already locked
     */
    private static function acquireLock(string $key, int $ttlSeconds = 240): bool
    {
        $lockKey = 'acms_cron_lock_' . $key;
        if (get_transient($lockKey)) {
            return false;
        }
        set_transient($lockKey, time(), $ttlSeconds);
        return true;
    }

    /**
     * Register REST API routes
     */
    public function register(): void
    {
        $this->registerRoutes();
    }

    /**
     * Register routes
     */
    public function registerRoutes(): void
    {
        // Get AI generation stats
        register_rest_route(self::NAMESPACE, '/cron/stats', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'getStats'],
            'permission_callback' => [$this, 'checkAdminPermission'],
        ]);

        // Run cron manually (admin)
        register_rest_route(self::NAMESPACE, '/cron/run/(?P<type>[a-z-]+)', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'runCronManually'],
            'permission_callback' => [$this, 'checkAdminPermission'],
            'args' => [
                'type' => [
                    'required' => true,
                    'type' => 'string',
                    'enum' => ['product-ai', 'post-ai', 'queue', 'quick-update', 'scrape-monitor'],
                ],
            ],
        ]);

        // External cron endpoints (authenticated by token query param)
        // Support both GET and POST for flexibility with different cron services
        // Note: Cannot use WP_REST_Server::READABLE | WP_REST_Server::CREATABLE
        // because PHP bitwise OR on strings ('GET' | 'POST') = 'WOWT', not 'GET, POST'
        register_rest_route(self::NAMESPACE, '/cron/product-ai', [
            'methods' => 'GET, POST',
            'callback' => [$this, 'runProductAiCron'],
            'permission_callback' => [$this, 'checkCronToken'],
        ]);

        register_rest_route(self::NAMESPACE, '/cron/post-ai', [
            'methods' => 'GET, POST',
            'callback' => [$this, 'runPostAiCron'],
            'permission_callback' => [$this, 'checkCronToken'],
        ]);

        register_rest_route(self::NAMESPACE, '/cron/queue', [
            'methods' => 'GET, POST',
            'callback' => [$this, 'runQueueCron'],
            'permission_callback' => [$this, 'checkCronToken'],
        ]);

        register_rest_route(self::NAMESPACE, '/cron/quick-update', [
            'methods' => 'GET, POST',
            'callback' => [$this, 'runQuickUpdateCron'],
            'permission_callback' => [$this, 'checkCronToken'],
        ]);

        register_rest_route(self::NAMESPACE, '/cron/scrape-monitor', [
            'methods' => 'GET, POST',
            'callback' => [$this, 'runScrapeMonitorCron'],
            'permission_callback' => [$this, 'checkCronToken'],
        ]);

        // Brand AI content generation (token-authenticated for cron server)
        register_rest_route(self::NAMESPACE, '/cron/brand-ai', [
            'methods' => 'GET, POST',
            'callback' => [$this, 'runBrandAiCron'],
            'permission_callback' => [$this, 'checkCronToken'],
        ]);

        // AI Worker endpoint (called by non-blocking self-spawning workers)
        // Authenticated via X-ACMS-Token header (same as scrape workers)
        register_rest_route(self::NAMESPACE, '/cron/ai-worker', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'runAiWorker'],
            'permission_callback' => [$this, 'checkWorkerToken'],
        ]);

        // Brand AI Worker endpoint (called by non-blocking self-spawning workers)
        // Authenticated via X-ACMS-Token header
        register_rest_route(self::NAMESPACE, '/cron/brand-ai-worker', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'runBrandAiWorker'],
            'permission_callback' => [$this, 'checkWorkerToken'],
        ]);

        // Category AI Worker endpoint (called by non-blocking self-spawning workers)
        // Authenticated via X-ACMS-Token header
        register_rest_route(self::NAMESPACE, '/cron/category-ai-worker', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'runCategoryAiWorker'],
            'permission_callback' => [$this, 'checkWorkerToken'],
        ]);

        // Date update: update date placeholders in posts (daily)
        register_rest_route(self::NAMESPACE, '/cron/date-update', [
            'methods' => 'GET, POST',
            'callback' => [$this, 'runDateUpdateCron'],
            'permission_callback' => [$this, 'checkCronToken'],
        ]);

        // Get cron logs
        register_rest_route(self::NAMESPACE, '/cron/logs', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'getLogs'],
            'permission_callback' => [$this, 'checkAdminPermission'],
        ]);

        // Clear cron logs by type
        register_rest_route(self::NAMESPACE, '/cron/logs/(?P<type>[a-z_]+)', [
            'methods' => WP_REST_Server::DELETABLE,
            'callback' => [$this, 'clearLogs'],
            'permission_callback' => [$this, 'checkAdminPermission'],
            'args' => [
                'type' => [
                    'required' => true,
                    'type' => 'string',
                    'enum' => ['scraping', 'product_ai', 'post_ai', 'quick_update', 'scrape_monitor'],
                ],
            ],
        ]);

        // Regenerate API token
        register_rest_route(self::NAMESPACE, '/cron/regenerate-token', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'regenerateToken'],
            'permission_callback' => [$this, 'checkAdminPermission'],
        ]);
    }

    /**
     * Check admin permission
     */
    public function checkAdminPermission(): bool
    {
        return current_user_can('manage_options');
    }

    /**
     * Check cron token for external cron calls
     * Uses unified token (acms_api_token) with ?token=xxx query parameter
     */
    public function checkCronToken(WP_REST_Request $request): bool
    {
        // Prevent caching of cron responses by CDN/LiteSpeed/browser
        nocache_headers();

        $token = $request->get_param('token');
        $stored_token = get_option('acms_api_token', '');

        if (empty($stored_token)) {
            error_log('[ACMS CronController] Token check FAILED: acms_api_token is empty');
            return false;
        }

        $valid = hash_equals($stored_token, (string) $token);
        if (!$valid) {
            error_log('[ACMS CronController] Token check FAILED: token mismatch');
        }

        return $valid;
    }

    /**
     * Get AI generation statistics
     */
    public function getStats(WP_REST_Request $request): WP_REST_Response
    {
        global $wpdb;

        $products_table = $wpdb->prefix . 'acms_products';
        $queue_table = $wpdb->prefix . 'acms_queue';
        $categories_table = $wpdb->prefix . 'acms_categories';

        // Product AI stats
        // Note: Products are automatically queued for AI when scrape completes
        // 'pending' = queued + legacy not_generated (waiting for AI processing)
        $product_stats = [
            'pending' => (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM {$products_table}
                 WHERE status = 'scraped'
                 AND (ai_status IS NULL OR ai_status = 'not_generated' OR ai_status = 'queued')"
            ),
            'queued' => (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM {$products_table}
                 WHERE status = 'scraped' AND ai_status = 'queued'"
            ),
            'generating' => (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM {$products_table} WHERE ai_status = 'generating'"
            ),
            'generated' => (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM {$products_table} WHERE ai_status = 'generated'"
            ),
            'failed' => (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM {$products_table} WHERE ai_status = 'failed'"
            ),
        ];

        // Post AI stats
        // Note: Queue items are automatically queued for AI when completed
        // 'pending' = queued + legacy not_generated (waiting for AI processing)
        $post_stats = [
            'pending' => (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM {$queue_table}
                 WHERE status = 'completed'
                 AND (ai_post_status IS NULL OR ai_post_status = 'not_generated' OR ai_post_status = 'queued')"
            ),
            'queued' => (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM {$queue_table}
                 WHERE status = 'completed' AND ai_post_status = 'queued'"
            ),
            'generating' => (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM {$queue_table} WHERE ai_post_status = 'generating'"
            ),
            'generated' => (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM {$queue_table} WHERE ai_post_status = 'generated'"
            ),
            'failed' => (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM {$queue_table} WHERE ai_post_status = 'failed'"
            ),
        ];

        // Category AI stats (check if table exists first)
        $category_stats = [
            'empty' => 0,
            'generating' => 0,
            'generated' => 0,
            'failed' => 0,
        ];

        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$categories_table}'");
        if ($table_exists) {
            $category_stats = [
                'empty' => (int) $wpdb->get_var(
                    "SELECT COUNT(*) FROM {$categories_table} WHERE content_status = 'empty' AND product_count > 0 AND status = 'publish'"
                ),
                'generating' => (int) $wpdb->get_var(
                    "SELECT COUNT(*) FROM {$categories_table} WHERE content_status = 'ai_generating'"
                ),
                'generated' => (int) $wpdb->get_var(
                    "SELECT COUNT(*) FROM {$categories_table} WHERE content_status = 'ai_generated'"
                ),
                'failed' => (int) $wpdb->get_var(
                    "SELECT COUNT(*) FROM {$categories_table} WHERE content_status = 'empty' AND ai_error_message IS NOT NULL"
                ),
            ];
        }

        // Scrape monitor stats
        $scrape_monitor_stats = ScrapeMonitorCron::instance()->getStats();

        return new WP_REST_Response([
            'success' => true,
            'data' => [
                'product' => $product_stats,
                'post' => $post_stats,
                'category' => $category_stats,
                'scrape_monitor' => $scrape_monitor_stats,
            ],
        ]);
    }

    /**
     * Run cron manually (admin action)
     */
    public function runCronManually(WP_REST_Request $request): WP_REST_Response
    {
        $type = $request->get_param('type');

        switch ($type) {
            case 'product-ai':
                return $this->runProductAiCron($request);

            case 'post-ai':
                return $this->runPostAiCron($request);

            case 'queue':
                return $this->runQueueCron($request);

            case 'quick-update':
                return $this->runQuickUpdateCron($request);

            case 'scrape-monitor':
                return $this->runScrapeMonitorCron($request);

            default:
                return new WP_REST_Response([
                    'success' => false,
                    'message' => 'Unknown cron type',
                ], 400);
        }
    }

    /**
     * Run Product AI cron
     */
    public function runProductAiCron(WP_REST_Request $request): WP_REST_Response
    {
        if (!self::acquireLock('product_ai', 240)) {
            return new WP_REST_Response([
                'success' => true,
                'message' => 'Skipped: recently executed (lock active)',
                'data' => ['skipped' => true],
            ]);
        }

        try {
            self::addLog('product_ai', 'info', 'Product AI cron started');

            $cron = ProductAiCron::instance();
            $result = $cron->runManually();

            $duration = $result['duration_ms'] ?? 0;
            self::addLog('product_ai', 'success', 'Product AI cron completed', "Duration: {$duration}ms");

            return new WP_REST_Response([
                'success' => true,
                'message' => 'Product AI cron executed',
                'data' => $result,
            ]);
        } catch (\Throwable $e) {
            self::addLog('product_ai', 'error', 'Product AI cron failed', $e->getMessage());

            return new WP_REST_Response([
                'success' => false,
                'message' => 'Error: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Run Post AI cron
     */
    public function runPostAiCron(WP_REST_Request $request): WP_REST_Response
    {
        if (!self::acquireLock('post_ai', 240)) {
            return new WP_REST_Response([
                'success' => true,
                'message' => 'Skipped: recently executed (lock active)',
                'data' => ['skipped' => true],
            ]);
        }

        try {
            self::addLog('post_ai', 'info', 'Post AI cron started');

            $cron = PostAiCron::instance();
            $result = $cron->runManually();

            $duration = $result['duration_ms'] ?? 0;
            self::addLog('post_ai', 'success', 'Post AI cron completed', "Duration: {$duration}ms");

            return new WP_REST_Response([
                'success' => true,
                'message' => 'Post AI cron executed',
                'data' => $result,
            ]);
        } catch (\Throwable $e) {
            self::addLog('post_ai', 'error', 'Post AI cron failed', $e->getMessage());

            return new WP_REST_Response([
                'success' => false,
                'message' => 'Error: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Run Queue processor cron
     */
    public function runQueueCron(WP_REST_Request $request): WP_REST_Response
    {
        if (!self::acquireLock('queue', 90)) {
            return new WP_REST_Response([
                'success' => true,
                'message' => 'Skipped: recently executed (lock active)',
                'data' => ['skipped' => true],
            ]);
        }

        try {
            self::addLog('scraping', 'info', 'Queue processor started');

            do_action('acms_process_queue');

            self::addLog('scraping', 'success', 'Queue processor completed');

            return new WP_REST_Response([
                'success' => true,
                'message' => 'Queue processor executed',
            ]);
        } catch (\Throwable $e) {
            self::addLog('scraping', 'error', 'Queue processor failed', $e->getMessage());

            return new WP_REST_Response([
                'success' => false,
                'message' => 'Error: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Run Quick Update cron (prices/ratings/stock)
     *
     * Flow: marks stale scraped products as 'update', spawns parallel workers
     * Workers: claim product (update→updating), quick-scrape, set back to 'scraped'
     */
    public function runQuickUpdateCron(WP_REST_Request $request): WP_REST_Response
    {
        if (!self::acquireLock('quick_update', 1500)) {
            return new WP_REST_Response([
                'success' => true,
                'message' => 'Skipped: recently executed (lock active)',
                'data' => ['skipped' => true],
            ]);
        }

        try {
            self::addLog('quick_update', 'info', 'Quick update cron started');

            $cron = \AffiliateCMS\Pro\Core\QuickUpdateCron::instance();
            $result = $cron->runManually();

            $queued = $result['queued'] ?? 0;
            $duration = $result['duration_ms'] ?? 0;
            self::addLog('quick_update', 'success', "Quick update completed: {$queued} queued", "Duration: {$duration}ms");

            return new WP_REST_Response([
                'success' => true,
                'message' => 'Quick update executed',
                'data' => $result,
            ]);
        } catch (\Throwable $e) {
            self::addLog('quick_update', 'error', 'Quick update failed', $e->getMessage());

            return new WP_REST_Response([
                'success' => false,
                'message' => 'Error: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Run Scrape Monitor cron (check scrape progress and mark ready for AI)
     */
    public function runScrapeMonitorCron(WP_REST_Request $request): WP_REST_Response
    {
        if (!self::acquireLock('scrape_monitor', 90)) {
            return new WP_REST_Response([
                'success' => true,
                'message' => 'Skipped: recently executed (lock active)',
                'data' => ['skipped' => true],
            ]);
        }

        try {
            self::addLog('scrape_monitor', 'info', 'Scrape monitor started');

            $cron = ScrapeMonitorCron::instance();
            $result = $cron->runManually();

            $duration = $result['duration_ms'] ?? 0;
            self::addLog('scrape_monitor', 'success', 'Scrape monitor completed', "Duration: {$duration}ms");

            $stats = $cron->getStats();

            return new WP_REST_Response([
                'success' => true,
                'message' => 'Scrape monitor executed',
                'data' => array_merge($result, ['stats' => $stats]),
            ]);
        } catch (\Throwable $e) {
            self::addLog('scrape_monitor', 'error', 'Scrape monitor failed', $e->getMessage());

            return new WP_REST_Response([
                'success' => false,
                'message' => 'Error: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Run Brand AI cron
     */
    public function runBrandAiCron(WP_REST_Request $request): WP_REST_Response
    {
        if (!self::acquireLock('brand_ai', 200)) {
            return new WP_REST_Response([
                'success' => true,
                'message' => 'Skipped: recently executed (lock active)',
                'data' => ['skipped' => true],
            ]);
        }

        try {
            self::addLog('brand_ai', 'info', 'Brand AI cron started');

            $cron = BrandAiCron::instance();
            $result = $cron->runManually();

            $duration = $result['duration_ms'] ?? 0;
            self::addLog('brand_ai', 'success', 'Brand AI cron completed', "Duration: {$duration}ms");

            return new WP_REST_Response([
                'success' => true,
                'message' => 'Brand AI cron executed',
                'data' => $result,
            ]);
        } catch (\Throwable $e) {
            self::addLog('brand_ai', 'error', 'Brand AI cron failed', $e->getMessage());

            return new WP_REST_Response([
                'success' => false,
                'message' => 'Error: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Brand AI Worker endpoint — processes one queued brand then self-spawns
     *
     * Called by non-blocking HTTP requests from BrandAiCron::spawnBrandAiWorker().
     * Each invocation claims one brand atomically, processes it via OpenRouter,
     * and spawns the next worker if more brands are queued.
     */
    public function runBrandAiWorker(WP_REST_Request $request): WP_REST_Response
    {
        try {
            $cron = BrandAiCron::instance();
            $result = $cron->processNextQueuedBrand();

            return new WP_REST_Response([
                'success' => true,
                'data' => $result,
            ]);
        } catch (\Exception $e) {
            error_log('[ACMS Brand AI Worker] Error: ' . $e->getMessage());

            return new WP_REST_Response([
                'success' => false,
                'message' => 'Error: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Run Date Update cron (update date placeholders in posts)
     * Runs daily via server cron
     */
    public function runDateUpdateCron(WP_REST_Request $request): WP_REST_Response
    {
        if (!self::acquireLock('date_update', 43200)) { // 12h lock (daily task)
            return new WP_REST_Response([
                'success' => true,
                'message' => 'Skipped: recently executed (lock active)',
                'data' => ['skipped' => true],
            ]);
        }

        try {
            $cron = DateUpdateCron::instance();
            $result = $cron->updateDatePlaceholders();

            return new WP_REST_Response([
                'success' => true,
                'message' => 'Date update executed',
                'data' => is_array($result) ? $result : ['updated' => $result],
            ]);
        } catch (\Throwable $e) {
            return new WP_REST_Response([
                'success' => false,
                'message' => 'Error: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Check worker token (X-ACMS-Token header)
     *
     * Used by self-spawning worker endpoints (ai-worker, process-scheduled).
     * Accepts token via X-ACMS-Token header only (not query param).
     */
    public function checkWorkerToken(WP_REST_Request $request): bool
    {
        $token = $request->get_header('X-ACMS-Token');

        if (empty($token)) {
            return false;
        }

        $storedToken = get_option('acms_api_token', '');
        return !empty($storedToken) && hash_equals($storedToken, (string) $token);
    }

    /**
     * AI Worker endpoint — processes one queued product then self-spawns
     *
     * Called by non-blocking HTTP requests from ProductAiCron::spawnAiWorker().
     * Each invocation claims one product atomically, processes it via OpenRouter,
     * and spawns the next worker if more products are queued.
     */
    public function runAiWorker(WP_REST_Request $request): WP_REST_Response
    {
        // Run AI worker loop AFTER response is sent to client.
        add_action('shutdown', function () {
            if (function_exists('fastcgi_finish_request')) {
                fastcgi_finish_request();
            }
            try {
                ProductAiCron::instance()->processNextQueuedAi();
            } catch (\Exception $e) {
                error_log('[ACMS AI Worker] Error: ' . $e->getMessage());
            }
        });

        return new WP_REST_Response([
            'success' => true,
            'message' => 'AI worker starting',
        ]);
    }

    /**
     * Category AI Worker endpoint — processes one queued category then self-spawns
     *
     * Called by non-blocking HTTP requests from CategoryAiCron::spawnCategoryAiWorker().
     * Each invocation claims one category atomically, creates a generate_seo_category job,
     * processes it via OpenRouter, and spawns the next worker if more categories are queued.
     */
    public function runCategoryAiWorker(WP_REST_Request $request): WP_REST_Response
    {
        try {
            if (!class_exists(\AffiliateCMS\Categories\Core\CategoryAiCron::class)) {
                return new WP_REST_Response([
                    'success' => false,
                    'message' => 'CategoryAiCron class not available',
                ], 500);
            }

            $cron = \AffiliateCMS\Categories\Core\CategoryAiCron::instance();
            $result = $cron->processNextQueuedCategoryAi();

            return new WP_REST_Response([
                'success' => true,
                'data' => $result,
            ]);
        } catch (\Exception $e) {
            error_log('[ACMS Category AI Worker] Error: ' . $e->getMessage());

            return new WP_REST_Response([
                'success' => false,
                'message' => 'Error: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Get all cron logs
     */
    public function getLogs(WP_REST_Request $request): WP_REST_Response
    {
        $types = [
            // Pipeline
            'scraping', 'scrape_monitor', 'cat_queue', 'cat_monitor', 'process_category_ai',
            // AI Generation
            'product_ai', 'post_ai', 'category_ai', 'brand_ai', 'brand_category_ai',
            // Maintenance
            'quick_update', 'retry_stuck', 'backfill_links',
        ];
        $logs = [];

        foreach ($types as $type) {
            $logs[$type] = get_option(self::LOG_OPTION_PREFIX . $type, []);
        }

        return new WP_REST_Response([
            'success' => true,
            'data' => $logs,
        ]);
    }

    /**
     * Clear logs for a specific type
     */
    public function clearLogs(WP_REST_Request $request): WP_REST_Response
    {
        $type = $request->get_param('type');
        delete_option(self::LOG_OPTION_PREFIX . $type);

        return new WP_REST_Response([
            'success' => true,
            'message' => 'Logs cleared',
        ]);
    }

    /**
     * Regenerate API token
     */
    public function regenerateToken(WP_REST_Request $request): WP_REST_Response
    {
        $newToken = wp_generate_password(32, false, false);
        update_option('acms_api_token', $newToken);

        return new WP_REST_Response([
            'success' => true,
            'message' => 'Token regenerated',
            'data' => [
                'token' => $newToken,
            ],
        ]);
    }

    /**
     * Add a log entry for a cron type
     *
     * @param string $type Log type (scraping, product_ai, post_ai, quick_update)
     * @param string $status Status (info, success, warning, error)
     * @param string $message Log message
     * @param string|null $details Additional details
     */
    public static function addLog(string $type, string $status, string $message, ?string $details = null): void
    {
        $optionKey = self::LOG_OPTION_PREFIX . $type;
        $logs = get_option($optionKey, []);

        // Add new log entry at the beginning
        array_unshift($logs, [
            'time' => current_time('Y-m-d H:i:s'),
            'status' => $status,
            'message' => $message,
            'details' => $details,
        ]);

        // Keep only the last MAX_LOGS entries
        $logs = array_slice($logs, 0, self::MAX_LOGS);

        update_option($optionKey, $logs, false);
    }
}
