<?php
/**
 * Products REST API Controller
 *
 * REST endpoints for product management
 * Base URL: /acms/v1/products
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro\Api;

use AffiliateCMS\Pro\Repositories\ProductRepository;
use AffiliateCMS\Pro\Repositories\ProductLinkRepository;
use AffiliateCMS\Pro\Models\Product;
use AffiliateCMS\Pro\Models\ProductLink;
use AffiliateCMS\Pro\Core\ProviderManager;
use AffiliateCMS\Pro\Services\AsinDetector;
use AffiliateCMS\Pro\Database\Schema;
use WP_REST_Request;
use WP_REST_Response;
use WP_Error;

class ProductsController
{
    private string $namespace = 'acms/v1';
    private ProductRepository $repository;
    private ProductLinkRepository $linkRepository;
    private ProviderManager $provider;

    /** @var bool|null Cached result of junction table existence check */
    private static ?bool $junctionTableExists = null;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->repository = ProductRepository::instance();
        $this->linkRepository = ProductLinkRepository::instance();
        $this->provider = ProviderManager::instance();
    }

    /**
     * Check if the category_products junction table exists (cached per request)
     */
    private function junctionTableExists(): bool
    {
        if (self::$junctionTableExists !== null) {
            return self::$junctionTableExists;
        }

        global $wpdb;
        $junctionTable = $wpdb->prefix . 'acms_category_products';
        $result = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $junctionTable));
        self::$junctionTableExists = ($result === $junctionTable);

        return self::$junctionTableExists;
    }

    /**
     * Register REST API routes
     * Called directly from rest_api_init hook
     */
    public function register(): void
    {
        $this->registerRoutes();
    }

    /**
     * Register routes
     */
    public function registerRoutes(): void
    {
        // GET /products - List products
        // POST /products - Add product by ASIN
        register_rest_route($this->namespace, '/products', [
            [
                'methods' => 'GET',
                'callback' => [$this, 'index'],
                'permission_callback' => [$this, 'checkPermission'],
                'args' => $this->getIndexArgs(),
            ],
            [
                'methods' => 'POST',
                'callback' => [$this, 'store'],
                'permission_callback' => [$this, 'checkPermission'],
                'args' => $this->getStoreArgs(),
            ],
        ]);

        // GET /products/stats - Get statistics
        register_rest_route($this->namespace, '/products/stats', [
            'methods' => 'GET',
            'callback' => [$this, 'stats'],
            'permission_callback' => [$this, 'checkPermission'],
        ]);

        // GET /products/categories - Get categories
        register_rest_route($this->namespace, '/products/categories', [
            'methods' => 'GET',
            'callback' => [$this, 'categories'],
            'permission_callback' => [$this, 'checkPermission'],
        ]);

        // GET /products/brands - Get brands
        register_rest_route($this->namespace, '/products/brands', [
            'methods' => 'GET',
            'callback' => [$this, 'brands'],
            'permission_callback' => [$this, 'checkPermission'],
        ]);

        // POST /products/import - Bulk import ASINs
        register_rest_route($this->namespace, '/products/import', [
            'methods' => 'POST',
            'callback' => [$this, 'import'],
            'permission_callback' => [$this, 'checkPermission'],
            'args' => $this->getImportArgs(),
        ]);

        // POST /products/bulk - Bulk operations
        register_rest_route($this->namespace, '/products/bulk', [
            'methods' => 'POST',
            'callback' => [$this, 'bulk'],
            'permission_callback' => [$this, 'checkPermission'],
            'args' => $this->getBulkArgs(),
        ]);

        // POST /products/scrape - Trigger scrape
        register_rest_route($this->namespace, '/products/scrape', [
            'methods' => 'POST',
            'callback' => [$this, 'scrape'],
            'permission_callback' => [$this, 'checkPermission'],
            'args' => $this->getScrapeArgs(),
        ]);

        // GET /products/count-posts - Count posts by type for scan UI
        register_rest_route($this->namespace, '/products/count-posts', [
            'methods' => 'GET',
            'callback' => [$this, 'countPosts'],
            'permission_callback' => [$this, 'checkPermission'],
        ]);

        // POST /products/scan-posts - Scan posts for ASINs
        register_rest_route($this->namespace, '/products/scan-posts', [
            'methods' => 'POST',
            'callback' => [$this, 'scanPosts'],
            'permission_callback' => [$this, 'checkPermission'],
            'args' => $this->getScanPostsArgs(),
        ]);

        // POST /products/bulk-add - Bulk add scanned ASINs
        register_rest_route($this->namespace, '/products/bulk-add', [
            'methods' => 'POST',
            'callback' => [$this, 'bulkAddAsins'],
            'permission_callback' => [$this, 'checkPermission'],
            'args' => $this->getBulkAddArgs(),
        ]);

        // GET /products/live-prices?asins=B0xxx,B1xxx
        // Public endpoint — returns only price/stock/prime/last_updated.
        // No auth required (public data, no sensitive info).
        // Must NOT be cached by Nginx/CDN (see no-store header below).
        // IMPORTANT: Register BEFORE parameterized routes (?P<asin>, ?P<id>)
        // to avoid WordPress matching "live-prices" as an ASIN or ID.
        register_rest_route($this->namespace, '/products/live-prices', [
            'methods' => 'GET',
            'callback' => [$this, 'livePrices'],
            'permission_callback' => '__return_true',
            'args' => [
                'asins' => [
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ],
            ],
        ]);

        // GET /products/{asin}/posts - Get posts using a specific ASIN
        register_rest_route($this->namespace, '/products/(?P<asin>[A-Za-z0-9]+)/posts', [
            'methods' => 'GET',
            'callback' => [$this, 'getPostsByAsin'],
            'permission_callback' => [$this, 'checkPermission'],
        ]);

        // POST /products/recalculate-scores - Recalculate scores for all products
        register_rest_route($this->namespace, '/products/recalculate-scores', [
            'methods' => 'POST',
            'callback' => [$this, 'recalculateScores'],
            'permission_callback' => [$this, 'checkPermission'],
        ]);

        // GET /products/{id} - Get single product
        // PATCH /products/{id} - Update product
        // DELETE /products/{id} - Delete product
        register_rest_route($this->namespace, '/products/(?P<id>\d+)', [
            [
                'methods' => 'GET',
                'callback' => [$this, 'show'],
                'permission_callback' => [$this, 'checkPermission'],
            ],
            [
                'methods' => 'PATCH,PUT',
                'callback' => [$this, 'update'],
                'permission_callback' => [$this, 'checkPermission'],
            ],
            [
                'methods' => 'DELETE',
                'callback' => [$this, 'destroy'],
                'permission_callback' => [$this, 'checkPermission'],
            ],
        ]);

        // POST /products/{id}/generate-ai - Generate AI content immediately
        register_rest_route($this->namespace, '/products/(?P<id>\d+)/generate-ai', [
            'methods' => 'POST',
            'callback' => [$this, 'generateAiContent'],
            'permission_callback' => [$this, 'checkPermission'],
        ]);

        // POST /products/{id}/reset-ai - Reset AI status (for stuck/failed products)
        register_rest_route($this->namespace, '/products/(?P<id>\d+)/reset-ai', [
            'methods' => 'POST',
            'callback' => [$this, 'resetAiStatus'],
            'permission_callback' => [$this, 'checkPermission'],
        ]);

        // =========================================================================
        // PRODUCT LINKS ROUTES
        // =========================================================================

        // GET /products/{id}/links - Get all links for a product
        // POST /products/{id}/links - Create a new link
        register_rest_route($this->namespace, '/products/(?P<id>\d+)/links', [
            [
                'methods' => 'GET',
                'callback' => [$this, 'getProductLinks'],
                'permission_callback' => [$this, 'checkPermission'],
            ],
            [
                'methods' => 'POST',
                'callback' => [$this, 'createProductLink'],
                'permission_callback' => [$this, 'checkPermission'],
                'args' => $this->getProductLinkArgs(),
            ],
        ]);

        // PUT /products/{id}/links/{linkId} - Update a link
        // DELETE /products/{id}/links/{linkId} - Delete a link
        register_rest_route($this->namespace, '/products/(?P<id>\d+)/links/(?P<linkId>\d+)', [
            [
                'methods' => 'PUT,PATCH',
                'callback' => [$this, 'updateProductLink'],
                'permission_callback' => [$this, 'checkPermission'],
            ],
            [
                'methods' => 'DELETE',
                'callback' => [$this, 'deleteProductLink'],
                'permission_callback' => [$this, 'checkPermission'],
            ],
        ]);

        // PUT /products/{id}/links/{linkId}/primary - Set link as primary
        register_rest_route($this->namespace, '/products/(?P<id>\d+)/links/(?P<linkId>\d+)/primary', [
            'methods' => 'PUT',
            'callback' => [$this, 'setLinkAsPrimary'],
            'permission_callback' => [$this, 'checkPermission'],
        ]);

        // PUT /products/{id}/links/order - Reorder links
        register_rest_route($this->namespace, '/products/(?P<id>\d+)/links/order', [
            'methods' => 'PUT',
            'callback' => [$this, 'reorderProductLinks'],
            'permission_callback' => [$this, 'checkPermission'],
        ]);

        // GET /products/{id}/scrape-log - Get scrape diagnostics log
        register_rest_route($this->namespace, '/products/(?P<id>[\d]+)/scrape-log', [
            'methods' => 'GET',
            'callback' => [$this, 'getScrapeLog'],
            'permission_callback' => [$this, 'checkPermission'],
        ]);

        // GET /products/providers - Get available providers list
        register_rest_route($this->namespace, '/products/providers', [
            'methods' => 'GET',
            'callback' => [$this, 'getProviders'],
            'permission_callback' => [$this, 'checkPermission'],
        ]);

    }

    // =========================================================================
    // PERMISSION CHECKS
    // =========================================================================

    /**
     * Check admin permission
     */
    public function checkPermission(): bool
    {
        return current_user_can('manage_options');
    }

    // =========================================================================
    // ENDPOINT HANDLERS
    // =========================================================================

    /**
     * GET /products - List products
     *
     * Uses allForListing() to SELECT only ~28 columns instead of 50+,
     * skipping heavy LONGTEXT/JSON columns (description, features, reviews_data, etc.)
     * This reduces data transfer by ~90% and speeds up queries significantly.
     */
    public function index(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $args = [
            'page' => $request->get_param('page') ?? 1,
            'per_page' => $request->get_param('per_page') ?? 20,
            'search' => $request->get_param('search') ?? '',
            'status' => $request->get_param('status') ?? '',
            'ai_status' => $request->get_param('ai_status') ?? '',
            'category' => $request->get_param('category') ?? '',
            'brand' => $request->get_param('brand') ?? '',
            'in_stock' => $request->get_param('in_stock'),
            'orderby' => $request->get_param('orderby') ?? 'id',
            'order' => $request->get_param('order') ?? 'desc',
        ];

        // Use lightweight listing query (no heavy LONGTEXT/JSON columns)
        $result = $this->repository->allForListing($args);

        // Batch-query linked category counts from junction table (cached check)
        $productIds = array_filter(array_column($result['products'], 'id'));
        $categoryCounts = [];
        if (!empty($productIds) && $this->junctionTableExists()) {
            global $wpdb;
            $junctionTable = $wpdb->prefix . 'acms_category_products';
            $placeholders = implode(',', array_fill(0, count($productIds), '%d'));
            $rows = $wpdb->get_results($wpdb->prepare(
                "SELECT product_id, COUNT(*) as cnt FROM {$junctionTable} WHERE product_id IN ({$placeholders}) GROUP BY product_id",
                ...$productIds
            ), ARRAY_A);
            foreach ($rows as $row) {
                $categoryCounts[(int) $row['product_id']] = (int) $row['cnt'];
            }
        }

        // Merge linked_category_count into each product
        foreach ($result['products'] as &$product) {
            $product['linked_category_count'] = $categoryCounts[(int) $product['id']] ?? 0;
        }
        unset($product);

        // Include stats (single query with conditional aggregation)
        $result['stats'] = $this->repository->getStats();

        $response = new WP_REST_Response([
            'success' => true,
            'data' => $result,
        ]);

        // Add no-cache headers for LiteSpeed Cache and other caching systems
        $response->header('Cache-Control', 'no-cache, no-store, must-revalidate, max-age=0');
        $response->header('Pragma', 'no-cache');
        $response->header('Expires', '0');
        $response->header('X-LiteSpeed-Cache-Control', 'no-cache');

        return $response;
    }

    /**
     * GET /products/{id} - Get single product
     */
    public function show(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $id = (int) $request->get_param('id');
        $product = $this->repository->find($id);

        if (!$product) {
            return new WP_Error(
                'product_not_found',
                'Product not found',
                ['status' => 404]
            );
        }

        $data = $product->toArray();

        // Include affiliate links
        $links = $this->linkRepository->getByProductId($id);
        $data['affiliate_links'] = array_map(fn($link) => $link->toArray(), $links);

        // Include linked SEO category IDs from junction table
        $data['linked_category_ids'] = $this->getLinkedCategoryIds($id);

        $response = new WP_REST_Response([
            'success' => true,
            'data' => $data,
        ]);

        // Add no-cache headers for LiteSpeed Cache and other caching systems
        $response->header('Cache-Control', 'no-cache, no-store, must-revalidate, max-age=0');
        $response->header('Pragma', 'no-cache');
        $response->header('Expires', '0');
        $response->header('X-LiteSpeed-Cache-Control', 'no-cache');

        return $response;
    }

    /**
     * POST /products - Add product by ASIN
     */
    public function store(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $asin = strtoupper(trim($request->get_param('asin') ?? ''));

        // Validate ASIN
        if (!preg_match('/^[A-Z0-9]{10}$/', $asin)) {
            return new WP_Error(
                'invalid_asin',
                'Invalid ASIN format. Must be 10 alphanumeric characters.',
                ['status' => 400]
            );
        }

        // Check if already exists
        $existing = $this->repository->findByAsin($asin);
        if ($existing) {
            return new WP_Error(
                'asin_exists',
                'Product with this ASIN already exists',
                ['status' => 409, 'data' => ['id' => $existing->id]]
            );
        }

        // Create product
        $data = [
            'asin' => $asin,
            'status' => 'pending',
        ];

        // Optional fields
        $optionalFields = ['title', 'brand', 'image_url', 'price', 'original_price'];
        foreach ($optionalFields as $field) {
            $value = $request->get_param($field);
            if ($value !== null) {
                $data[$field] = $value;
            }
        }

        $id = $this->repository->create($data);

        if (!$id) {
            return new WP_Error(
                'create_failed',
                'Failed to create product',
                ['status' => 500]
            );
        }

        $product = $this->repository->find($id);

        return new WP_REST_Response([
            'success' => true,
            'data' => $product->toArray(),
            'message' => 'Product created successfully',
        ], 201);
    }

    /**
     * PATCH /products/{id} - Update product
     */
    public function update(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $id = (int) $request->get_param('id');
        $product = $this->repository->find($id);

        if (!$product) {
            return new WP_Error(
                'product_not_found',
                'Product not found',
                ['status' => 404]
            );
        }

        // Allowed update fields
        $allowedFields = [
            'title', 'brand', 'image_url', 'images_gallery', 'price', 'original_price', 'currency',
            'rating', 'reviews_count', 'in_stock', 'is_prime', 'category',
            'category_path', 'description', 'features', 'status', 'error_message',
            'custom_title', 'custom_description', 'custom_features', 'custom_pros', 'custom_cons', 'custom_tabs',
            // AI content fields
            'ai_status', 'ai_features', 'ai_short_review', 'ai_description',
            // Custom category paths for SEO categories
            'custom_category_paths',
        ];

        $data = [];
        foreach ($allowedFields as $field) {
            $value = $request->get_param($field);
            if ($value !== null) {
                $data[$field] = $value;
            }
        }

        // Handle linked_category_ids separately (syncs with junction table)
        $linkedCategoryIds = $request->get_param('linked_category_ids');
        $syncCategoryIds = false;
        if ($linkedCategoryIds !== null) {
            $syncCategoryIds = true;
        }

        if (empty($data) && !$syncCategoryIds) {
            return new WP_Error(
                'no_data',
                'No data to update',
                ['status' => 400]
            );
        }

        $success = !empty($data) ? $this->repository->update($id, $data) : true;

        // Sync category IDs with junction table if affiliatecms-cat is active
        if ($syncCategoryIds && class_exists('\\AffiliateCMS\\Categories\\Repositories\\CategoryProductRepository')) {
            $this->syncProductCategories($id, $linkedCategoryIds);
        }

        if (!$success) {
            return new WP_Error(
                'update_failed',
                'Failed to update product',
                ['status' => 500]
            );
        }

        $updated = $this->repository->find($id);

        return new WP_REST_Response([
            'success' => true,
            'data' => $updated->toArray(),
            'message' => 'Product updated successfully',
        ]);
    }

    /**
     * DELETE /products/{id} - Delete product
     */
    public function destroy(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $id = (int) $request->get_param('id');
        $product = $this->repository->find($id);

        if (!$product) {
            return new WP_Error(
                'product_not_found',
                'Product not found',
                ['status' => 404]
            );
        }

        // Cascade delete handles all related data (links, reviews, category_products, ai_jobs, queue refs)
        $success = $this->repository->delete($id);

        if (!$success) {
            return new WP_Error(
                'delete_failed',
                'Failed to delete product',
                ['status' => 500]
            );
        }

        return new WP_REST_Response([
            'success' => true,
            'message' => 'Product deleted successfully',
        ]);
    }

    /**
     * Get linked SEO category IDs for a product
     *
     * @param int $productId Product ID
     * @return string Comma-separated category IDs
     */
    private function getLinkedCategoryIds(int $productId): string
    {
        global $wpdb;

        if (!$this->junctionTableExists()) {
            return '';
        }

        $junctionTable = $wpdb->prefix . 'acms_category_products';
        $ids = $wpdb->get_col($wpdb->prepare(
            "SELECT category_id FROM {$junctionTable} WHERE product_id = %d ORDER BY is_primary DESC, position ASC",
            $productId
        ));

        return implode(', ', $ids);
    }

    /**
     * Sync product with SEO categories via junction table
     *
     * @param int $productId Product ID
     * @param string $categoryIds Comma-separated category IDs
     */
    private function syncProductCategories(int $productId, string $categoryIds): void
    {
        global $wpdb;

        if (!$this->junctionTableExists()) {
            return;
        }

        $junctionTable = $wpdb->prefix . 'acms_category_products';

        // Parse category IDs
        $ids = array_filter(
            array_map('intval', explode(',', $categoryIds)),
            fn($id) => $id > 0
        );

        // Get current linked categories
        $currentIds = $wpdb->get_col($wpdb->prepare(
            "SELECT category_id FROM {$junctionTable} WHERE product_id = %d",
            $productId
        ));
        $currentIds = array_map('intval', $currentIds);

        // Calculate diff
        $toAdd = array_diff($ids, $currentIds);
        $toRemove = array_diff($currentIds, $ids);

        // Remove old links
        if (!empty($toRemove)) {
            $placeholders = implode(',', array_fill(0, count($toRemove), '%d'));
            $wpdb->query($wpdb->prepare(
                "DELETE FROM {$junctionTable} WHERE product_id = %d AND category_id IN ($placeholders)",
                array_merge([$productId], $toRemove)
            ));
        }

        // Add new links
        foreach ($toAdd as $categoryId) {
            $wpdb->insert($junctionTable, [
                'product_id' => $productId,
                'category_id' => $categoryId,
                'position' => 0,
                'is_primary' => 0,
                'created_at' => current_time('mysql'),
            ]);
        }

        // Update product counts for affected categories
        $affectedCategoryIds = array_unique(array_merge($toAdd, $toRemove));
        if (!empty($affectedCategoryIds)) {
            $categoriesTable = $wpdb->prefix . 'acms_categories';
            foreach ($affectedCategoryIds as $catId) {
                $count = (int) $wpdb->get_var($wpdb->prepare(
                    "SELECT COUNT(*) FROM {$junctionTable} WHERE category_id = %d",
                    $catId
                ));
                $wpdb->update($categoriesTable, ['product_count' => $count], ['id' => $catId]);
            }
        }
    }

    /**
     * POST /products/{id}/generate-ai - Generate AI content immediately
     *
     * Creates an AI job and processes it immediately (synchronous).
     * Used when user clicks "Regenerate" button.
     */
    public function generateAiContent(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $steps = []; // Track detailed steps for frontend debugging
        $id = (int) $request->get_param('id');

        $steps[] = ['step' => 'find_product', 'product_id' => $id];
        $product = $this->repository->find($id);

        if (!$product) {
            return new WP_Error('product_not_found', 'Product not found', ['status' => 404]);
        }

        $steps[] = ['step' => 'product_found', 'asin' => $product->asin, 'status' => $product->status, 'ai_status' => $product->aiStatus ?? null];

        // Only process scraped products
        if ($product->status !== 'scraped') {
            return new WP_Error('product_not_scraped', "Product status is '{$product->status}', must be 'scraped'", ['status' => 400]);
        }

        // Check if AI plugin is active
        global $wpdb;
        $aiJobsTable = $wpdb->prefix . 'acms_ai_jobs';
        $tableExists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $aiJobsTable));

        if ($tableExists !== $aiJobsTable) {
            return new WP_Error('ai_plugin_not_active', 'AI plugin not active (acms_ai_jobs table missing)', ['status' => 400]);
        }

        // Check API key
        $apiKey = get_option('acms_ai_api_key', '');
        if (empty($apiKey)) {
            return new WP_Error('api_key_missing', 'OpenRouter API key not configured (Settings > AI Assistant)', ['status' => 400]);
        }
        $steps[] = ['step' => 'api_key_check', 'key_length' => strlen($apiKey)];

        // Check for existing pending/processing job
        $existingJob = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$aiJobsTable} WHERE type = 'enhance_asin' AND target_id = %s AND status IN ('pending', 'processing') LIMIT 1",
            $product->asin
        ));
        if ($existingJob) {
            $steps[] = ['step' => 'duplicate_job', 'existing_job_id' => (int) $existingJob];
            return new WP_REST_Response([
                'success' => false,
                'message' => "Job #{$existingJob} already pending/processing for this ASIN",
                'steps' => $steps,
            ]);
        }

        // Mark as generating
        $this->repository->update($id, ['ai_status' => 'generating']);
        $steps[] = ['step' => 'status_set', 'ai_status' => 'generating'];

        // Prepare full input data (same as ProductAiCron::createAiJob)
        $inputData = [
            'asin' => $product->asin,
            'product_id' => $product->id,
            'title' => $product->title,
            'brand' => $product->brand,
            'category' => $product->category,
            'category_path' => $product->categoryPath ?? '',
            'price' => $product->price,
            'original_price' => $product->originalPrice ?? null,
            'currency' => $product->currency ?? 'USD',
            'in_stock' => $product->inStock ?? true,
            'is_prime' => $product->isPrime ?? false,
            'rating' => $product->rating,
            'reviews_count' => $product->reviewsCount,
            'score' => $product->score ?? null,
            'description' => $product->description,
            'features' => $product->features ?? [],
            'specifications' => $product->specifications ?? null,
            'product_information' => $product->productInformation ?? null,
            'best_sellers_rank' => $product->bestSellersRank ?? null,
            'top_reviews' => $product->topReviews ?? null,
            'reviews_summary' => $product->reviewsSummary ?? null,
            'seller_info' => $product->sellerInfo ?? null,
            'image_url' => $product->imageUrl ?? '',
            'images_gallery' => $product->imagesGallery ?? null,
        ];

        $encodedInput = wp_json_encode($inputData, JSON_INVALID_UTF8_IGNORE);
        if ($encodedInput === false) {
            $err = 'JSON encoding failed: ' . json_last_error_msg();
            $this->repository->update($id, ['ai_status' => 'failed', 'ai_error_message' => $err]);
            return new WP_Error('json_encode_failed', $err, ['status' => 500]);
        }
        $steps[] = ['step' => 'input_prepared', 'json_size' => strlen($encodedInput), 'input_keys' => array_keys($inputData)];

        // Create AI job
        $inserted = $wpdb->insert($aiJobsTable, [
            'type' => 'enhance_asin',
            'target_type' => 'asin',
            'target_id' => $product->asin,
            'input_data' => $encodedInput,
            'status' => 'pending',
            'priority' => 10,
            'max_attempts' => 3,
            'created_at' => current_time('mysql'),
        ]);

        if (!$inserted) {
            $err = 'DB insert failed: ' . $wpdb->last_error;
            $this->repository->update($id, ['ai_status' => 'failed', 'ai_error_message' => $err]);
            return new WP_Error('job_creation_failed', $err, ['status' => 500]);
        }

        $jobId = (int) $wpdb->insert_id;
        $steps[] = ['step' => 'job_created', 'job_id' => $jobId];

        // Process the job immediately using JobProcessor
        if (class_exists('\\AffiliateCMS\\AI\\Core\\JobProcessor')) {
            $steps[] = ['step' => 'processor_class_found'];

            try {
                $processor = new \AffiliateCMS\AI\Core\JobProcessor();
                $steps[] = ['step' => 'processor_constructed'];

                // Fetch the job and process it directly (not processQueue which picks random jobs)
                $job = $wpdb->get_row($wpdb->prepare(
                    "SELECT * FROM {$aiJobsTable} WHERE id = %d",
                    $jobId
                ), ARRAY_A);

                if (!$job) {
                    throw new \Exception("Job #{$jobId} not found after insert");
                }

                $steps[] = ['step' => 'job_fetched', 'job_status' => $job['status'], 'job_type' => $job['type']];

                // Process THIS specific job
                $processor->processSingleJob($job);
                $steps[] = ['step' => 'job_processed'];

                // Check the job result
                $jobAfter = $wpdb->get_row($wpdb->prepare(
                    "SELECT status, error_message, tokens_used, model FROM {$aiJobsTable} WHERE id = %d",
                    $jobId
                ), ARRAY_A);

                $steps[] = [
                    'step' => 'job_result',
                    'job_status' => $jobAfter['status'] ?? 'unknown',
                    'error' => $jobAfter['error_message'] ?? null,
                    'tokens' => (int) ($jobAfter['tokens_used'] ?? 0),
                    'model' => $jobAfter['model'] ?? null,
                ];

                // Refresh product data
                $updatedProduct = $this->repository->find($id);

                $response = [
                    'success' => ($jobAfter['status'] ?? '') === 'completed',
                    'message' => ($jobAfter['status'] ?? '') === 'completed'
                        ? 'AI content generated successfully'
                        : 'Job finished with status: ' . ($jobAfter['status'] ?? 'unknown') . ($jobAfter['error_message'] ? ' — ' . $jobAfter['error_message'] : ''),
                    'data' => $updatedProduct ? $updatedProduct->toArray() : null,
                    'job_id' => $jobId,
                    'steps' => $steps,
                ];

                return new WP_REST_Response($response);
            } catch (\Throwable $e) {
                $steps[] = ['step' => 'error', 'message' => $e->getMessage(), 'file' => basename($e->getFile()) . ':' . $e->getLine()];
                error_log("[ACMS ProductsController] generateAiContent error: " . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());

                $this->repository->update($id, [
                    'ai_status' => 'failed',
                    'ai_error_message' => $e->getMessage(),
                ]);

                return new WP_REST_Response([
                    'success' => false,
                    'message' => 'AI processing failed: ' . $e->getMessage(),
                    'job_id' => $jobId,
                    'steps' => $steps,
                ], 500);
            }
        }

        $steps[] = ['step' => 'processor_class_missing', 'note' => 'Job queued for WP-Cron processing'];

        return new WP_REST_Response([
            'success' => true,
            'message' => 'AI job created, will be processed by WP-Cron',
            'data' => $product->toArray(),
            'job_id' => $jobId,
            'steps' => $steps,
        ]);
    }

    /**
     * POST /products/{id}/reset-ai - Reset AI status
     *
     * Used to reset stuck or failed AI generation statuses.
     * Allows re-queueing or clearing AI status entirely.
     */
    public function resetAiStatus(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $id = (int) $request->get_param('id');
        $product = $this->repository->find($id);

        if (!$product) {
            return new WP_Error(
                'product_not_found',
                'Product not found',
                ['status' => 404]
            );
        }

        $newStatus = $request->get_param('ai_status');

        // Validate allowed statuses
        $allowedStatuses = ['queued', 'not_generated', null];
        if (!in_array($newStatus, $allowedStatuses, true)) {
            return new WP_Error(
                'invalid_status',
                'Invalid AI status. Allowed: queued, not_generated, null',
                ['status' => 400]
            );
        }

        // Build update data
        $updateData = [
            'ai_status' => $newStatus,
            'ai_error_message' => null, // Clear any error message
        ];

        // If resetting completely, also clear generation timestamp
        if ($newStatus === 'not_generated' || $newStatus === null) {
            $updateData['ai_generated_at'] = null;
        }

        // Update the product
        $success = $this->repository->update($id, $updateData);

        if (!$success) {
            return new WP_Error(
                'update_failed',
                'Failed to reset AI status',
                ['status' => 500]
            );
        }

        // Get refreshed product
        $updatedProduct = $this->repository->find($id);

        return new WP_REST_Response([
            'success' => true,
            'message' => 'AI status reset successfully',
            'data' => $updatedProduct ? $updatedProduct->toArray() : null,
        ]);
    }

    /**
     * POST /products/import - Bulk import ASINs
     *
     * Creates products with status='pending' and triggers background scraping.
     */
    public function import(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $asin = $request->get_param('asin') ?? [];

        // Normalize to array
        if (is_string($asin)) {
            // Parse string: split by comma, newline, or space
            $asins = preg_split('/[\n,\s]+/', $asin);
        } else {
            $asins = (array) $asin;
        }

        // Validate and clean ASINs
        $asins = array_filter(array_map(function ($asin) {
            $asin = strtoupper(trim($asin));
            return preg_match('/^[A-Z0-9]{10}$/', $asin) ? $asin : null;
        }, $asins));

        // Remove duplicates
        $asins = array_unique($asins);

        if (empty($asins)) {
            return new WP_Error(
                'no_valid_asins',
                'No valid ASINs found. ASINs must be 10 alphanumeric characters.',
                ['status' => 400]
            );
        }

        $results = [
            'created' => [],
            'existing' => [],
            'failed' => [],
        ];

        foreach ($asins as $asin) {
            // Check if already exists
            $existing = $this->repository->findByAsin($asin);
            if ($existing) {
                $results['existing'][] = $asin;
                continue;
            }

            // Create product with status='pending'
            $id = $this->repository->create([
                'asin' => $asin,
                'status' => 'pending',
            ]);

            if ($id) {
                $results['created'][] = $asin;
            } else {
                $results['failed'][] = $asin;
            }
        }

        $createdCount = count($results['created']);
        $existingCount = count($results['existing']);
        $failedCount = count($results['failed']);

        $messages = [];
        if ($createdCount > 0) {
            $messages[] = "{$createdCount} ASINs added to queue";
        }
        if ($existingCount > 0) {
            $messages[] = "{$existingCount} already exist";
        }
        if ($failedCount > 0) {
            $messages[] = "{$failedCount} failed";
        }

        return new WP_REST_Response([
            'success' => $createdCount > 0 || $existingCount > 0,
            'data' => $results,
            'message' => implode(', ', $messages),
        ], $createdCount > 0 ? 201 : 200);
    }

    /**
     * POST /products/bulk - Bulk operations
     */
    public function bulk(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        // Start output buffering to catch any stray output
        ob_start();

        try {
            $action = $request->get_param('action');
            $ids = $request->get_param('ids') ?? [];

            error_log('[ACMS] Bulk action received: ' . $action . ' for ' . count($ids) . ' products');

            if (empty($ids)) {
                ob_end_clean();
                return new WP_Error(
                    'no_ids',
                    'No product IDs provided',
                    ['status' => 400]
                );
            }

            switch ($action) {
            case 'delete':
                $count = $this->repository->bulkDelete($ids);
                ob_end_clean();
                return new WP_REST_Response([
                    'success' => true,
                    'data' => ['deleted' => $count],
                    'message' => "{$count} products deleted",
                ]);

            case 'update_status':
                $status = $request->get_param('status');
                if (!$status) {
                    ob_end_clean();
                    return new WP_Error(
                        'missing_status',
                        'Status is required for update_status action',
                        ['status' => 400]
                    );
                }
                $count = $this->repository->bulkUpdateStatus($ids, $status);
                ob_end_clean();
                return new WP_REST_Response([
                    'success' => true,
                    'data' => ['updated' => $count],
                    'message' => "{$count} products updated",
                ]);

            case 'regenerate-ai':
                $queued = 0;
                foreach ($ids as $id) {
                    $product = $this->repository->find((int) $id);
                    if (!$product) continue;

                    // Allow regenerate for scraped products OR stuck generating/failed AI
                    $canRegenerate = $product->status === 'scraped'
                        || in_array($product->ai_status, ['generating', 'failed', 'generated'], true);

                    if ($canRegenerate) {
                        $this->repository->update((int) $id, [
                            'ai_status' => 'queued',
                            'ai_error_message' => null,
                        ]);
                        $queued++;
                    }
                }

                // Spawn AI workers to process immediately
                if ($queued > 0 && class_exists(\AffiliateCMS\Pro\Core\ProductAiCron::class)) {
                    \AffiliateCMS\Pro\Core\ProductAiCron::instance()->spawnAiWorkers();
                }

                ob_end_clean();
                return new WP_REST_Response([
                    'success' => true,
                    'data' => ['queued' => $queued],
                    'message' => "{$queued} product(s) queued for AI regeneration",
                ]);

            case 'reset-ai':
                // Reset stuck generating/failed AI status back to queued
                global $wpdb;
                $table = $wpdb->prefix . 'acms_products';
                $placeholders = implode(',', array_fill(0, count($ids), '%d'));

                $resetCount = $wpdb->query($wpdb->prepare(
                    "UPDATE {$table}
                     SET ai_status = 'queued', ai_error_message = NULL
                     WHERE id IN ({$placeholders})
                       AND ai_status IN ('generating', 'failed')",
                    ...$ids
                ));

                // Spawn AI workers
                if ($resetCount > 0 && class_exists(\AffiliateCMS\Pro\Core\ProductAiCron::class)) {
                    \AffiliateCMS\Pro\Core\ProductAiCron::instance()->spawnAiWorkers();
                }

                ob_end_clean();
                return new WP_REST_Response([
                    'success' => true,
                    'data' => ['reset' => (int) $resetCount],
                    'message' => "{$resetCount} product(s) AI status reset and re-queued",
                ]);

            case 'quick-update':
                if (!$this->provider->hasAnyProvider()) {
                    ob_end_clean();
                    return new WP_Error(
                        'no_provider',
                        'No scraping provider is configured. Please configure Crawlbase or PA-API.',
                        ['status' => 400]
                    );
                }

                // Mark products as 'update' and spawn workers
                global $wpdb;
                $table = $wpdb->prefix . 'acms_products';
                $placeholders = implode(',', array_fill(0, count($ids), '%d'));

                // Set status to 'update' for async processing
                // Allow any status except already-processing ones (update/updating)
                $wpdb->query($wpdb->prepare(
                    "UPDATE {$table}
                     SET status = 'update'
                     WHERE id IN ({$placeholders}) AND status NOT IN ('update', 'updating') AND asin IS NOT NULL AND asin != ''",
                    ...$ids
                ));
                $queued = (int) $wpdb->rows_affected;

                if ($queued > 0) {
                    // Spawn parallel workers for background processing
                    $settings = get_option('acms_automation', []);
                    $maxWorkers = (int) ($settings['update_worker_count'] ?? 3);
                    $bootstrap = \AffiliateCMS\Pro\Core\Bootstrap::instance();
                    $bootstrap->spawnQuickUpdateWorkers(min($maxWorkers, $queued));
                }

                ob_end_clean();
                return new WP_REST_Response([
                    'success' => true,
                    'data' => [
                        'queued' => $queued,
                        'total' => count($ids),
                    ],
                    'message' => "{$queued} product(s) queued for quick update. Processing in background.",
                ]);

            case 'rescrape':
                error_log('[ACMS] Bulk rescrape started for ' . count($ids) . ' products');

                // Check if provider is configured
                if (!$this->provider->hasAnyProvider()) {
                    error_log('[ACMS] Bulk rescrape failed: No provider configured');
                    ob_end_clean();
                    return new WP_Error(
                        'no_provider',
                        'No scraping provider is configured. Please configure Crawlbase or PA-API.',
                        ['status' => 400]
                    );
                }

                // Get ASINs from product IDs and mark as 'scheduled' for background processing
                $asins = [];
                foreach ($ids as $id) {
                    $product = $this->repository->find((int) $id);
                    if ($product && !empty($product->asin)) {
                        $asins[] = $product->asin;
                        // Mark as 'scheduled' so it will be picked up by automation cron
                        // Products with 'scheduled' status still show in shortcodes
                        $this->repository->update((int) $id, ['status' => 'scheduled']);
                    }
                }

                error_log('[ACMS] Marked ' . count($asins) . ' products as scheduled for rescrape');

                if (empty($asins)) {
                    error_log('[ACMS] Bulk rescrape failed: No valid ASINs found');
                    ob_end_clean();
                    return new WP_Error(
                        'no_asins',
                        'No valid ASINs found for the selected products',
                        ['status' => 400]
                    );
                }

                // Trigger parallel workers for background processing
                // Each worker atomically claims one product to prevent race conditions
                $bootstrap = \AffiliateCMS\Pro\Core\Bootstrap::instance();
                $bootstrap->spawnParallelWorkers();

                error_log('[ACMS] Spawned parallel workers for bulk rescrape');

                ob_end_clean();
                return new WP_REST_Response([
                    'success' => true,
                    'data' => [
                        'scheduled' => count($asins),
                        'asins' => $asins,
                    ],
                    'message' => count($asins) . ' products queued for re-scraping. Processing started in background.',
                ]);

            default:
                ob_end_clean();
                return new WP_Error(
                    'invalid_action',
                    'Invalid bulk action',
                    ['status' => 400]
                );
            }
        } catch (\Throwable $e) {
            ob_end_clean();
            error_log('[ACMS] Bulk action error: ' . $e->getMessage() . ' at ' . $e->getFile() . ':' . $e->getLine());
            return new WP_Error(
                'bulk_error',
                'Bulk operation failed: ' . $e->getMessage(),
                ['status' => 500]
            );
        }
    }

    /**
     * POST /products/scrape - Trigger scrape for ASIN(s)
     */
    public function scrape(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        // Start output buffering to catch any stray output
        ob_start();

        // Wrap in try-catch to return errors as JSON instead of HTML
        try {
            if (!$this->provider->hasAnyProvider()) {
                return new WP_Error(
                    'no_provider',
                    'No scraping provider is configured. Please configure Crawlbase or PA-API.',
                    ['status' => 400]
                );
            }

            $asin = $request->get_param('asin');

            // Normalize to array
            if (is_string($asin)) {
                // Could be single ASIN or comma/space/newline separated
                $asins = preg_split('/[\n,\s]+/', $asin);
            } else {
                $asins = (array) $asin;
            }

            // Validate ASINs
            $asins = array_filter(array_map(function ($asin) {
                $asin = strtoupper(trim($asin));
                return preg_match('/^[A-Z0-9]{10}$/', $asin) ? $asin : null;
            }, $asins));

            if (empty($asins)) {
                return new WP_Error(
                    'invalid_asins',
                    'No valid ASINs provided',
                    ['status' => 400]
                );
            }

            $domain = $request->get_param('domain') ?? 'amazon.com';
            $results = $this->performScrape($asins, $domain);

            $successCount = count(array_filter($results, fn($r) => $r['success']));
            $failCount = count($results) - $successCount;

            // Capture any stray output
            $strayOutput = ob_get_clean();

            $responseData = [
                'success' => $successCount > 0,
                'data' => [
                    'results' => $results,
                    'success_count' => $successCount,
                    'fail_count' => $failCount,
                ],
                'message' => "{$successCount} products scraped successfully, {$failCount} failed",
            ];

            // Include stray output for debugging if any
            if (!empty($strayOutput)) {
                $responseData['debug_output'] = $strayOutput;
            }

            return new WP_REST_Response($responseData);
        } catch (\Throwable $e) {
            // Clean output buffer
            $strayOutput = ob_get_clean();

            // Return any PHP errors as JSON for debugging
            return new WP_REST_Response([
                'success' => false,
                'message' => 'PHP Error: ' . $e->getMessage(),
                'error' => 'PHP Error: ' . $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine(),
                'trace' => defined('WP_DEBUG') && WP_DEBUG ? $e->getTraceAsString() : null,
                'debug_output' => $strayOutput ?: null,
            ], 500);
        }
    }

    /**
     * Perform scraping for an array of ASINs
     *
     * @param array $asins Array of validated ASINs
     * @param string $domain Amazon domain (default: amazon.com)
     * @return array Results keyed by ASIN
     */
    private function performScrape(array $asins, string $domain = 'amazon.com'): array
    {
        $results = [];

        foreach ($asins as $asin) {
            // Find or create product
            $product = $this->repository->findByAsin($asin);
            if (!$product) {
                $id = $this->repository->create(['asin' => $asin, 'status' => 'pending']);
                if (!$id) {
                    $results[$asin] = ['success' => false, 'error' => 'Failed to create product'];
                    continue;
                }
            } else {
                $id = $product->id;
            }

            // Mark as processing
            $this->repository->markAsProcessing($id);

            // Scrape
            $data = $this->provider->scrape($asin, $domain);

            if ($data) {
                $provider = $data['provider'] ?? 'unknown';
                $log = $data['log'] ?? [];
                $fieldLog = $data['field_log'] ?? [];
                unset($data['provider'], $data['log'], $data['field_log']);

                // Build scrape_log using shared helper
                $data['scrape_log'] = \AffiliateCMS\Pro\Core\Bootstrap::buildScrapeLog(
                    $asin, $provider, $log, $fieldLog, $data
                );

                $updateResult = $this->repository->markAsScraped($id, $data, $provider);

                // Schedule delayed re-scrape if price/rating still missing
                \AffiliateCMS\Pro\Core\Bootstrap::scheduleIncompleteRescrape($id, $asin, $data);

                $results[$asin] = [
                    'success' => true,
                    'provider' => $provider,
                    'title' => $data['title'] ?? null,
                    'log' => $log,
                    'db_update' => $updateResult ? 'success' : 'failed',
                    'fields_received' => array_keys($data),
                ];
            } else {
                $error = $this->provider->getCrawlbaseError() ?? $this->provider->getPaapiError() ?? 'All providers failed';
                $log = $this->provider->getScrapeLog();

                // Save failure log using shared helper
                $failureLogData = \AffiliateCMS\Pro\Core\Bootstrap::buildScrapeLog(
                    $asin, 'none', $log, [], [], $error
                );
                $this->repository->update($id, ['scrape_log' => $failureLogData]);

                $this->repository->markAsFailed($id, $error);
                $results[$asin] = [
                    'success' => false,
                    'error' => $error,
                    'log' => $log,
                ];
            }
        }

        return $results;
    }

    /**
     * GET /products/stats - Get statistics
     */
    public function stats(WP_REST_Request $request): WP_REST_Response
    {
        $stats = $this->repository->getStats();

        return new WP_REST_Response([
            'success' => true,
            'data' => $stats,
        ]);
    }

    /**
     * GET /products/categories - Get categories
     */
    public function categories(WP_REST_Request $request): WP_REST_Response
    {
        $categories = $this->repository->getCategories();
        $total = $this->repository->count();

        // Add "All" option at the beginning
        array_unshift($categories, [
            'name' => 'All Categories',
            'count' => $total,
        ]);

        return new WP_REST_Response([
            'success' => true,
            'data' => [
                'categories' => $categories,
                'total' => $total,
            ],
        ]);
    }

    /**
     * GET /products/brands - Get brands
     */
    public function brands(WP_REST_Request $request): WP_REST_Response
    {
        $brands = $this->repository->getBrands();

        return new WP_REST_Response([
            'success' => true,
            'data' => [
                'brands' => $brands,
            ],
        ]);
    }

    /**
     * GET /products/count-posts - Count posts by type for scan UI
     */
    public function countPosts(WP_REST_Request $request): WP_REST_Response
    {
        global $wpdb;

        // Get all public post types
        $postTypes = get_post_types(['public' => true], 'objects');

        $postTypeData = [];
        $total = 0;

        foreach ($postTypes as $slug => $postType) {
            // Skip attachments
            if ($slug === 'attachment') {
                continue;
            }

            $count = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = %s AND post_status = 'publish'",
                $slug
            ));

            $postTypeData[] = [
                'slug' => $slug,
                'name' => $postType->labels->name,
                'singular' => $postType->labels->singular_name,
                'count' => $count,
            ];

            $total += $count;
        }

        // Sort by count descending, then by name
        usort($postTypeData, function ($a, $b) {
            if ($b['count'] !== $a['count']) {
                return $b['count'] - $a['count'];
            }
            return strcasecmp($a['name'], $b['name']);
        });

        return new WP_REST_Response([
            'success' => true,
            'data' => [
                'post_types' => $postTypeData,
                'total' => $total,
            ],
        ]);
    }

    /**
     * POST /products/scan-posts - Scan posts for ASINs with categorized results
     */
    public function scanPosts(WP_REST_Request $request): WP_REST_Response
    {
        global $wpdb;

        $postTypes = $request->get_param('post_types') ?: ['post', 'page'];

        // Validate post types
        $postTypes = array_filter($postTypes, function ($type) {
            return post_type_exists($type);
        });

        if (empty($postTypes)) {
            return new WP_REST_Response([
                'success' => false,
                'message' => 'No valid post types specified',
            ], 400);
        }

        // Get all published posts
        $posts = get_posts([
            'post_type' => $postTypes,
            'post_status' => 'publish',
            'posts_per_page' => -1,
            'fields' => 'all',
        ]);

        // Get existing ASINs with status details
        $productsTable = Schema::productsTable();
        $existingProducts = $wpdb->get_results(
            "SELECT id, asin, status, ai_status, post_ids, post_count FROM {$productsTable}",
            ARRAY_A
        );
        $existingAsinsMap = [];
        foreach ($existingProducts as $product) {
            $existingAsinsMap[$product['asin']] = $product;
        }

        // Get category associations for existing ASINs (from category_products junction)
        $categoryMap = []; // asin => [{id, name}]
        $categoriesTable = $wpdb->prefix . 'acms_categories';
        $catProductsTable = $wpdb->prefix . 'acms_category_products';
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $categoriesTable)) === $categoriesTable) {
            $catLinks = $wpdb->get_results(
                "SELECT p.asin, c.id as category_id, c.name as category_name
                 FROM {$productsTable} p
                 INNER JOIN {$catProductsTable} cp ON p.id = cp.product_id
                 INNER JOIN {$categoriesTable} c ON cp.category_id = c.id
                 ORDER BY p.asin, c.name",
                ARRAY_A
            );
            foreach ($catLinks as $link) {
                $categoryMap[$link['asin']][] = [
                    'id' => (int) $link['category_id'],
                    'name' => $link['category_name'],
                ];
            }
        }

        // Get cat queue associations — find which queue items reference each ASIN
        // Queue items have linked_asins (JSON array) and assigned_category_id
        $queueCategoryMap = []; // asin => [{queue_id, keyword, category_id, category_name}]
        $queueTable = $wpdb->prefix . 'acms_category_queue';
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $queueTable)) === $queueTable) {
            $queueItems = $wpdb->get_results(
                "SELECT q.id, q.keyword, q.assigned_category_id, q.linked_asins,
                        c.name as category_name
                 FROM {$queueTable} q
                 LEFT JOIN {$categoriesTable} c ON q.assigned_category_id = c.id
                 WHERE q.linked_asins IS NOT NULL
                 AND q.assigned_category_id IS NOT NULL",
                ARRAY_A
            );
            foreach ($queueItems as $qi) {
                $asins = json_decode($qi['linked_asins'], true);
                if (!is_array($asins)) {
                    continue;
                }
                foreach ($asins as $asin) {
                    $asin = strtoupper(trim($asin));
                    $queueCategoryMap[$asin][] = [
                        'queue_id' => (int) $qi['id'],
                        'keyword' => $qi['keyword'],
                        'category_id' => (int) $qi['assigned_category_id'],
                        'category_name' => $qi['category_name'] ?? '',
                    ];
                }
            }
        }

        $detector = AsinDetector::instance();

        // Track found ASINs by source type
        $asinData = [];
        $postsScanned = 0;

        foreach ($posts as $post) {
            $postsScanned++;
            $content = $post->post_content . ' ' . $post->post_title;

            // Extract ASINs categorized by source
            $categorized = $detector->extractAsinsCategorized($content);

            $postInfo = [
                'id' => $post->ID,
                'title' => $post->post_title,
                'type' => $post->post_type,
                'edit_url' => admin_url('post.php?post=' . $post->ID . '&action=edit'),
            ];

            // Process each source type
            foreach ($categorized as $sourceType => $asins) {
                foreach ($asins as $asin) {
                    $isInDb = isset($existingAsinsMap[$asin]);
                    $productInfo = $existingAsinsMap[$asin] ?? null;

                    if (!isset($asinData[$asin])) {
                        $asinData[$asin] = [
                            'asin' => $asin,
                            'source' => $sourceType,
                            'posts' => [],
                            'isNew' => !$isInDb,
                            'inDb' => $isInDb,
                            'productStatus' => $productInfo ? $productInfo['status'] : null,
                            'aiStatus' => $productInfo ? $productInfo['ai_status'] : null,
                            'productId' => $productInfo ? (int) $productInfo['id'] : null,
                            'linkedPostCount' => $productInfo ? (int) ($productInfo['post_count'] ?? 0) : 0,
                            'categories' => $categoryMap[$asin] ?? [],
                            'queueCategories' => $queueCategoryMap[$asin] ?? [],
                        ];
                    } else {
                        // Upgrade source priority: shortcode > url > raw
                        $priorities = [
                            AsinDetector::SOURCE_SHORTCODE => 3,
                            AsinDetector::SOURCE_URL => 2,
                            AsinDetector::SOURCE_RAW => 1,
                        ];
                        $currentPriority = $priorities[$asinData[$asin]['source']] ?? 0;
                        $newPriority = $priorities[$sourceType] ?? 0;
                        if ($newPriority > $currentPriority) {
                            $asinData[$asin]['source'] = $sourceType;
                        }
                    }

                    // Add post info if not already added
                    $postExists = false;
                    foreach ($asinData[$asin]['posts'] as $existingPost) {
                        if ($existingPost['id'] === $post->ID) {
                            $postExists = true;
                            break;
                        }
                    }
                    if (!$postExists) {
                        $asinData[$asin]['posts'][] = $postInfo;
                    }
                }
            }
        }

        // Group by source type
        $bySource = [
            'shortcode' => [],
            'url' => [],
            'raw' => [],
        ];

        foreach ($asinData as $item) {
            $formatted = [
                'asin' => $item['asin'],
                'source' => $item['source'],
                'posts' => array_map(fn($p) => $p['title'], $item['posts']),
                'postDetails' => $item['posts'],
                'isNew' => $item['isNew'],
                'inDb' => $item['inDb'],
                'productStatus' => $item['productStatus'],
                'aiStatus' => $item['aiStatus'],
                'productId' => $item['productId'],
                'linkedPostCount' => $item['linkedPostCount'],
                'categories' => $item['categories'],
                'queueCategories' => $item['queueCategories'],
            ];
            $bySource[$item['source']][] = $formatted;
        }

        $shortcodeAsins = $bySource['shortcode'];
        $newCount = count(array_filter($shortcodeAsins, fn($a) => $a['isNew']));
        $trackedCount = count(array_filter($shortcodeAsins, fn($a) => $a['inDb']));
        $failedCount = count(array_filter($shortcodeAsins, fn($a) => $a['productStatus'] === 'failed'));
        $unlinkCount = count(array_filter($shortcodeAsins, fn($a) => $a['inDb'] && $a['linkedPostCount'] === 0));

        return new WP_REST_Response([
            'success' => true,
            'message' => sprintf(
                'Scanned %d posts, found %d shortcode ASINs (%d new, %d failed), %d URL ASINs, %d raw ASINs',
                $postsScanned,
                count($shortcodeAsins),
                $newCount,
                $failedCount,
                count($bySource['url']),
                count($bySource['raw'])
            ),
            'data' => [
                'posts_scanned' => $postsScanned,
                'shortcode_asins' => $shortcodeAsins,
                'shortcode_count' => count($shortcodeAsins),
                'new_count' => $newCount,
                'tracked_count' => $trackedCount,
                'failed_count' => $failedCount,
                'unlinked_count' => $unlinkCount,
                'url_asins' => $bySource['url'],
                'url_count' => count($bySource['url']),
                'raw_asins' => $bySource['raw'],
                'raw_count' => count($bySource['raw']),
            ],
        ]);
    }

    /**
     * POST /products/bulk-add - Add multiple ASINs with post associations
     */
    public function bulkAddAsins(WP_REST_Request $request): WP_REST_Response
    {
        global $wpdb;

        $asins = $request->get_param('asins');
        $asinPostMapRaw = $request->get_param('asin_post_map'); // Optional: [asin => [post_ids]]
        $categoryId = (int) ($request->get_param('category_id') ?? 0);
        $resetFailed = (bool) ($request->get_param('reset_failed') ?? false);

        // Normalize asin_post_map to associative array (handles stdClass from JSON)
        $asinPostMap = [];
        if (!empty($asinPostMapRaw)) {
            if (is_object($asinPostMapRaw)) {
                $asinPostMap = (array) $asinPostMapRaw;
            } elseif (is_array($asinPostMapRaw)) {
                $asinPostMap = $asinPostMapRaw;
            }
        }

        if (empty($asins) || !is_array($asins)) {
            return new WP_REST_Response([
                'success' => false,
                'message' => 'No ASINs provided',
            ], 400);
        }

        $linkFromQueue = (bool) ($request->get_param('link_from_queue') ?? false);

        $detector = AsinDetector::instance();
        $productsTable = Schema::productsTable();
        $added = 0;
        $updated = 0;
        $skipped = 0;
        $resetCount = 0;
        $categoryLinked = 0;
        $debug = []; // Debug info

        // Prepare category linking
        $catRepo = null;
        if (class_exists('\\AffiliateCMS\\Categories\\Repositories\\CategoryRepository')) {
            if ($categoryId > 0 || $linkFromQueue) {
                $catRepo = new \AffiliateCMS\Categories\Repositories\CategoryRepository();
            }
        }

        // Build queue-based category map if link_from_queue enabled
        $queueCatMap = []; // asin => [category_ids]
        if ($linkFromQueue && $catRepo) {
            $categoriesTable = $wpdb->prefix . 'acms_categories';
            $queueTable = $wpdb->prefix . 'acms_category_queue';
            if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $queueTable)) === $queueTable) {
                $queueItems = $wpdb->get_results(
                    "SELECT q.linked_asins, q.assigned_category_id
                     FROM {$queueTable} q
                     WHERE q.linked_asins IS NOT NULL
                     AND q.assigned_category_id IS NOT NULL",
                    ARRAY_A
                );
                foreach ($queueItems as $qi) {
                    $qAsins = json_decode($qi['linked_asins'], true);
                    if (!is_array($qAsins)) {
                        continue;
                    }
                    $catId = (int) $qi['assigned_category_id'];
                    foreach ($qAsins as $qAsin) {
                        $qAsin = strtoupper(trim($qAsin));
                        $queueCatMap[$qAsin][$catId] = true;
                    }
                }
            }
        }

        foreach ($asins as $asin) {
            $asinKey = strtoupper(trim($asin));
            // Look up post IDs using both original and uppercase keys for safety
            $postIds = $asinPostMap[$asinKey] ?? $asinPostMap[$asin] ?? [];

            $debugEntry = [
                'asin' => $asinKey,
                'post_ids_found' => $postIds,
                'action' => null,
            ];

            // Try to save new ASIN (using normalized key)
            $firstPostId = !empty($postIds) ? (int) $postIds[0] : 0;
            if ($detector->saveAsin($asinKey, $firstPostId, false)) {
                $added++;
                $debugEntry['action'] = 'added_new';
                // Add remaining post IDs
                for ($i = 1; $i < count($postIds); $i++) {
                    $detector->addPostToProduct($asinKey, (int) $postIds[$i]);
                }
            } else {
                // ASIN exists — always update post associations
                if (!empty($postIds)) {
                    $linkedCount = 0;
                    foreach ($postIds as $postId) {
                        if ($detector->addPostToProduct($asinKey, (int) $postId)) {
                            $linkedCount++;
                        }
                    }
                    $debugEntry['action'] = 'updated_existing';
                    $debugEntry['posts_linked'] = $linkedCount;
                    $updated++;
                } else {
                    $debugEntry['action'] = 'skipped_no_posts';
                    $skipped++;
                }

                // Reset failed products to pending for re-scraping
                if ($resetFailed) {
                    $product = $wpdb->get_row($wpdb->prepare(
                        "SELECT id, status FROM {$productsTable} WHERE asin = %s",
                        $asinKey
                    ));
                    if ($product && $product->status === 'failed') {
                        $wpdb->update(
                            $productsTable,
                            ['status' => 'pending', 'updated_at' => current_time('mysql', true)],
                            ['id' => $product->id],
                            ['%s', '%s'],
                            ['%d']
                        );
                        $resetCount++;
                        $debugEntry['reset_to_pending'] = true;
                    }
                }
            }

            // Link product to categories
            if ($catRepo) {
                $product = $wpdb->get_row($wpdb->prepare(
                    "SELECT id FROM {$productsTable} WHERE asin = %s",
                    $asinKey
                ));
                if ($product) {
                    $linkedCats = [];

                    // Explicit category_id
                    if ($categoryId > 0) {
                        if ($catRepo->addProduct($categoryId, (int) $product->id)) {
                            $linkedCats[] = $categoryId;
                        }
                    }

                    // Auto-link from cat queue data
                    if ($linkFromQueue && isset($queueCatMap[$asinKey])) {
                        foreach (array_keys($queueCatMap[$asinKey]) as $qCatId) {
                            if ($catRepo->addProduct($qCatId, (int) $product->id)) {
                                $linkedCats[] = $qCatId;
                            }
                        }
                    }

                    if (!empty($linkedCats)) {
                        $categoryLinked += count($linkedCats);
                        $debugEntry['categories_linked'] = $linkedCats;
                    }
                }
            }

            $debug[] = $debugEntry;
        }

        return new WP_REST_Response([
            'success' => true,
            'message' => sprintf(
                'Added %d ASINs, updated %d existing (%d skipped, %d reset, %d category-linked)',
                $added,
                $updated,
                $skipped,
                $resetCount,
                $categoryLinked
            ),
            'data' => [
                'added' => $added,
                'updated' => $updated,
                'skipped' => $skipped,
                'reset_count' => $resetCount,
                'category_linked' => $categoryLinked,
                'debug' => $debug,
                'debug_input' => [
                    'asins_count' => count($asins),
                    'map_type' => gettype($asinPostMapRaw),
                    'map_keys' => is_array($asinPostMap) ? array_keys($asinPostMap) : [],
                    'category_id' => $categoryId,
                    'reset_failed' => $resetFailed,
                    'link_from_queue' => $linkFromQueue,
                ],
            ],
        ]);
    }

    /**
     * GET /products/{asin}/posts - Get posts using a specific ASIN
     */
    public function getPostsByAsin(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        global $wpdb;

        $asin = strtoupper(sanitize_text_field($request->get_param('asin')));

        if (empty($asin)) {
            return new WP_Error(
                'invalid_asin',
                'Invalid ASIN provided',
                ['status' => 400]
            );
        }

        // Find product by ASIN
        $product = $this->repository->findByAsin($asin);

        if (!$product) {
            return new WP_REST_Response([
                'success' => true,
                'data' => [],
                'message' => 'Product not found',
            ]);
        }

        // Get post IDs from product (Note: Product model uses camelCase: postIds)
        $postIds = [];
        if (!empty($product->postIds)) {
            $postIds = array_map('intval', array_filter(explode(',', $product->postIds)));
        }

        // Fetch posts data (may be empty)
        $formattedPosts = [];
        if (!empty($postIds)) {
            $placeholders = implode(',', array_fill(0, count($postIds), '%d'));
            $posts = $wpdb->get_results($wpdb->prepare(
                "SELECT ID, post_title, post_type, post_status, post_date, post_modified
                 FROM {$wpdb->posts}
                 WHERE ID IN ($placeholders)
                 ORDER BY post_date DESC",
                ...$postIds
            ), ARRAY_A);

            $formattedPosts = array_map(function ($post) {
                return [
                    'id' => (int) $post['ID'],
                    'title' => $post['post_title'],
                    'post_type' => $post['post_type'],
                    'post_status' => $post['post_status'],
                    'post_date' => $post['post_date'],
                    'url' => get_permalink((int) $post['ID']),
                    'edit_url' => get_edit_post_link((int) $post['ID'], 'raw'),
                ];
            }, $posts);
        }

        // Get Cat Queue items referencing this ASIN
        $catQueueItems = [];
        $catQueueTable = $wpdb->prefix . 'acms_cat_queue';
        $catQueueExists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $catQueueTable));
        if ($catQueueExists === $catQueueTable) {
            $likeAsin = '%"' . $wpdb->esc_like($asin) . '"%';
            $queueRows = $wpdb->get_results($wpdb->prepare(
                "SELECT q.id, q.keyword, q.status, q.ai_status, q.custom_category_path, q.assigned_category_id,
                        c.name as category_name, c.slug as category_slug
                 FROM {$catQueueTable} q
                 LEFT JOIN {$wpdb->prefix}acms_categories c ON q.assigned_category_id = c.id
                 WHERE q.linked_asins LIKE %s
                 ORDER BY q.created_at DESC",
                $likeAsin
            ), ARRAY_A);

            foreach ($queueRows as $row) {
                $catQueueItems[] = [
                    'id' => (int) $row['id'],
                    'keyword' => $row['keyword'],
                    'status' => $row['status'],
                    'ai_status' => $row['ai_status'],
                    'category_path' => $row['custom_category_path'],
                    'category_id' => $row['assigned_category_id'] ? (int) $row['assigned_category_id'] : null,
                    'category_name' => $row['category_name'],
                    'category_slug' => $row['category_slug'],
                    'edit_url' => admin_url('admin.php?page=acms-cat-queue'),
                ];
            }
        }

        // Get linked SEO categories via junction table
        $linkedCategories = [];
        $junctionTable = $wpdb->prefix . 'acms_category_products';
        $categoriesTable = $wpdb->prefix . 'acms_categories';
        if ($this->junctionTableExists()) {
            $categoryRows = $wpdb->get_results($wpdb->prepare(
                "SELECT c.id, c.name, c.slug, c.product_count, c.content_status, cp.is_primary
                 FROM {$junctionTable} cp
                 JOIN {$categoriesTable} c ON cp.category_id = c.id
                 WHERE cp.product_id = %d
                 ORDER BY cp.is_primary DESC, c.name ASC",
                $product->id
            ), ARRAY_A);

            foreach ($categoryRows as $row) {
                $linkedCategories[] = [
                    'id' => (int) $row['id'],
                    'name' => $row['name'],
                    'slug' => $row['slug'],
                    'product_count' => (int) $row['product_count'],
                    'content_status' => $row['content_status'],
                    'is_primary' => (bool) $row['is_primary'],
                    'url' => home_url('/c/' . $row['slug'] . '/'),
                    'edit_url' => admin_url('admin.php?page=acms-category-edit&id=' . $row['id']),
                ];
            }
        }

        return new WP_REST_Response([
            'success' => true,
            'data' => $formattedPosts,
            'cat_queue' => $catQueueItems,
            'linked_categories' => $linkedCategories,
        ]);
    }

    /**
     * POST /products/recalculate-scores - Recalculate AZS scores for all products
     */
    public function recalculateScores(WP_REST_Request $request): WP_REST_Response
    {
        global $wpdb;

        $scoreManager = \AffiliateCMS\Pro\Services\ScoreManager::instance();
        $productsTable = Schema::productsTable();

        // Get all scraped products
        $products = $wpdb->get_results(
            "SELECT id, rating FROM `{$productsTable}` WHERE status = 'scraped'",
            ARRAY_A
        );

        $updated = 0;
        foreach ($products as $product) {
            $rating = isset($product['rating']) ? floatval($product['rating']) : null;
            $score = $scoreManager->calculateScore($rating);

            $result = $wpdb->update(
                $productsTable,
                ['score' => $score],
                ['id' => $product['id']],
                ['%d'],
                ['%d']
            );

            if ($result !== false) {
                $updated++;
            }
        }

        return new WP_REST_Response([
            'success' => true,
            'message' => sprintf('Recalculated scores for %d products', $updated),
            'data' => [
                'total' => count($products),
                'updated' => $updated,
            ],
        ]);
    }

    // =========================================================================
    // PRODUCT LINKS HANDLERS
    // =========================================================================

    /**
     * GET /products/{id}/links - Get all affiliate links for a product
     */
    public function getProductLinks(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $productId = (int) $request->get_param('id');
        $product = $this->repository->find($productId);

        if (!$product) {
            return new WP_Error(
                'product_not_found',
                'Product not found',
                ['status' => 404]
            );
        }

        $links = $this->linkRepository->getByProductId($productId);

        return new WP_REST_Response([
            'success' => true,
            'data' => array_map(fn($link) => $link->toArray(), $links),
        ]);
    }

    /**
     * POST /products/{id}/links - Create a new affiliate link
     */
    public function createProductLink(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $productId = (int) $request->get_param('id');
        $product = $this->repository->find($productId);

        if (!$product) {
            return new WP_Error(
                'product_not_found',
                'Product not found',
                ['status' => 404]
            );
        }

        $data = [
            'product_id' => $productId,
            'provider' => $request->get_param('provider'),
            'provider_name' => $request->get_param('provider_name') ?: ProductLink::PROVIDERS[$request->get_param('provider')] ?? ucfirst($request->get_param('provider')),
            'affiliate_url' => $request->get_param('affiliate_url'),
            'price' => $request->get_param('price'),
            'currency' => $request->get_param('currency') ?? 'USD',
            'in_stock' => $request->get_param('in_stock'),
            'is_primary' => $request->get_param('is_primary') ?? false,
            'sort_order' => $request->get_param('sort_order') ?? 0,
        ];

        $linkId = $this->linkRepository->create($data);

        if (!$linkId) {
            return new WP_Error(
                'create_failed',
                'Failed to create affiliate link',
                ['status' => 500]
            );
        }

        $link = $this->linkRepository->find($linkId);

        return new WP_REST_Response([
            'success' => true,
            'data' => $link->toArray(),
            'message' => 'Affiliate link created successfully',
        ], 201);
    }

    /**
     * PUT /products/{id}/links/{linkId} - Update an affiliate link
     */
    public function updateProductLink(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $productId = (int) $request->get_param('id');
        $linkId = (int) $request->get_param('linkId');

        $link = $this->linkRepository->find($linkId);

        if (!$link || $link->productId !== $productId) {
            return new WP_Error(
                'link_not_found',
                'Affiliate link not found',
                ['status' => 404]
            );
        }

        $updateData = [];
        $allowedFields = ['provider', 'provider_name', 'affiliate_url', 'price', 'currency', 'in_stock', 'is_primary', 'sort_order'];

        foreach ($allowedFields as $field) {
            $value = $request->get_param($field);
            if ($value !== null) {
                $updateData[$field] = $value;
            }
        }

        if (empty($updateData)) {
            return new WP_Error(
                'no_data',
                'No data to update',
                ['status' => 400]
            );
        }

        $success = $this->linkRepository->update($linkId, $updateData);

        if (!$success) {
            return new WP_Error(
                'update_failed',
                'Failed to update affiliate link',
                ['status' => 500]
            );
        }

        $updated = $this->linkRepository->find($linkId);

        return new WP_REST_Response([
            'success' => true,
            'data' => $updated->toArray(),
            'message' => 'Affiliate link updated successfully',
        ]);
    }

    /**
     * DELETE /products/{id}/links/{linkId} - Delete an affiliate link
     */
    public function deleteProductLink(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $productId = (int) $request->get_param('id');
        $linkId = (int) $request->get_param('linkId');

        $link = $this->linkRepository->find($linkId);

        if (!$link || $link->productId !== $productId) {
            return new WP_Error(
                'link_not_found',
                'Affiliate link not found',
                ['status' => 404]
            );
        }

        $success = $this->linkRepository->delete($linkId);

        if (!$success) {
            return new WP_Error(
                'delete_failed',
                'Failed to delete affiliate link',
                ['status' => 500]
            );
        }

        return new WP_REST_Response([
            'success' => true,
            'message' => 'Affiliate link deleted successfully',
        ]);
    }

    /**
     * PUT /products/{id}/links/{linkId}/primary - Set link as primary
     */
    public function setLinkAsPrimary(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $productId = (int) $request->get_param('id');
        $linkId = (int) $request->get_param('linkId');

        $link = $this->linkRepository->find($linkId);

        if (!$link || $link->productId !== $productId) {
            return new WP_Error(
                'link_not_found',
                'Affiliate link not found',
                ['status' => 404]
            );
        }

        $success = $this->linkRepository->setPrimary($linkId);

        if (!$success) {
            return new WP_Error(
                'update_failed',
                'Failed to set link as primary',
                ['status' => 500]
            );
        }

        $links = $this->linkRepository->getByProductId($productId);

        return new WP_REST_Response([
            'success' => true,
            'data' => array_map(fn($l) => $l->toArray(), $links),
            'message' => 'Primary link updated successfully',
        ]);
    }

    /**
     * PUT /products/{id}/links/order - Reorder affiliate links
     */
    public function reorderProductLinks(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $productId = (int) $request->get_param('id');
        $product = $this->repository->find($productId);

        if (!$product) {
            return new WP_Error(
                'product_not_found',
                'Product not found',
                ['status' => 404]
            );
        }

        $order = $request->get_param('order');

        if (!is_array($order)) {
            return new WP_Error(
                'invalid_order',
                'Order must be an array of link IDs to sort order',
                ['status' => 400]
            );
        }

        $this->linkRepository->updateSortOrder($order);

        $links = $this->linkRepository->getByProductId($productId);

        return new WP_REST_Response([
            'success' => true,
            'data' => array_map(fn($l) => $l->toArray(), $links),
            'message' => 'Links reordered successfully',
        ]);
    }

    /**
     * GET /products/providers - Get available affiliate providers
     */
    public function getProviders(WP_REST_Request $request): WP_REST_Response
    {
        $providers = ProductLink::getProviders();

        return new WP_REST_Response([
            'success' => true,
            'data' => $providers,
        ]);
    }

    /**
     * GET /products/{id}/scrape-log - Get scrape diagnostics log
     */
    public function getScrapeLog(WP_REST_Request $request): WP_REST_Response
    {
        $id = (int) $request->get_param('id');
        $product = $this->repository->find($id);

        if (!$product) {
            return new WP_REST_Response(['success' => false, 'message' => 'Product not found'], 404);
        }

        global $wpdb;
        $table = $wpdb->prefix . 'acms_products';
        $scrapeLog = $wpdb->get_var($wpdb->prepare(
            "SELECT scrape_log FROM {$table} WHERE id = %d", $id
        ));

        $logData = null;
        if ($scrapeLog) {
            $logData = is_array($scrapeLog) ? $scrapeLog : json_decode($scrapeLog, true);
        }

        return new WP_REST_Response([
            'success' => true,
            'data' => [
                'asin' => $product->asin,
                'title' => $product->title,
                'status' => $product->status,
                'last_provider' => $product->lastProvider ?? null,
                'last_scraped_at' => $product->lastScrapedAt ?? null,
                'error_message' => $product->errorMessage ?? null,
                'scrape_log' => $logData,
            ],
        ]);
    }

    // =========================================================================
    // ARGUMENT DEFINITIONS
    // =========================================================================

    /**
     * Get index endpoint arguments
     */
    private function getIndexArgs(): array
    {
        return [
            'page' => [
                'default' => 1,
                'type' => 'integer',
                'minimum' => 1,
            ],
            'per_page' => [
                'default' => 100,
                'type' => 'integer',
                'minimum' => 1,
                'maximum' => 1000,
            ],
            'search' => [
                'default' => '',
                'type' => 'string',
            ],
            'status' => [
                'default' => '',
                'type' => 'string',
                'enum' => ['', 'pending', 'processing', 'scheduled', 'scraped', 'failed', 'update', 'updating'],
            ],
            'category' => [
                'default' => '',
                'type' => 'string',
            ],
            'brand' => [
                'default' => '',
                'type' => 'string',
            ],
            'in_stock' => [
                'type' => 'boolean',
            ],
            'ai_status' => [
                'default' => '',
                'type' => 'string',
                'enum' => ['', 'not_generated', 'queued', 'generating', 'generated', 'failed'],
            ],
            'orderby' => [
                'default' => 'id',
                'type' => 'string',
                'enum' => ['id', 'asin', 'title', 'brand', 'price', 'rating', 'reviews_count', 'status', 'post_count', 'created_at', 'updated_at', 'last_scraped_at'],
            ],
            'order' => [
                'default' => 'desc',
                'type' => 'string',
                'enum' => ['asc', 'desc'],
            ],
        ];
    }

    /**
     * Get store endpoint arguments
     */
    private function getStoreArgs(): array
    {
        return [
            'asin' => [
                'required' => true,
                'type' => 'string',
                'minLength' => 10,
                'maxLength' => 10,
            ],
            'title' => [
                'type' => 'string',
            ],
            'brand' => [
                'type' => 'string',
            ],
            'image_url' => [
                'type' => 'string',
            ],
            'price' => [
                'type' => 'number',
            ],
            'original_price' => [
                'type' => 'number',
            ],
        ];
    }

    /**
     * Get import endpoint arguments
     */
    private function getImportArgs(): array
    {
        return [
            'asin' => [
                'required' => true,
                'type' => ['string', 'array'],
                'description' => 'Single ASIN, array of ASINs, or string with ASINs separated by comma/newline/space',
            ],
        ];
    }

    /**
     * Get bulk endpoint arguments
     */
    private function getBulkArgs(): array
    {
        return [
            'action' => [
                'required' => true,
                'type' => 'string',
                'enum' => ['delete', 'update_status', 'rescrape', 'quick-update', 'regenerate-ai', 'reset-ai'],
            ],
            'ids' => [
                'required' => true,
                'type' => 'array',
                'items' => ['type' => 'integer'],
            ],
            'status' => [
                'type' => 'string',
                'enum' => ['pending', 'processing', 'scraped', 'failed'],
            ],
        ];
    }

    /**
     * Get scrape endpoint arguments
     */
    private function getScrapeArgs(): array
    {
        return [
            'asin' => [
                'required' => true,
                'type' => ['string', 'array'],
                'description' => 'Single ASIN, array of ASINs, or string with ASINs separated by comma/newline/space',
            ],
            'domain' => [
                'default' => 'amazon.com',
                'type' => 'string',
            ],
        ];
    }

    /**
     * Get scan-posts endpoint arguments
     */
    private function getScanPostsArgs(): array
    {
        return [
            'post_types' => [
                'default' => ['post', 'page'],
                'type' => 'array',
                'items' => ['type' => 'string'],
            ],
        ];
    }

    /**
     * Get bulk-add endpoint arguments
     */
    private function getBulkAddArgs(): array
    {
        return [
            'asins' => [
                'required' => true,
                'type' => 'array',
                'items' => ['type' => 'string'],
            ],
            'asin_post_map' => [
                'required' => false,
                'type' => 'object',
                'description' => 'Map of ASIN to post IDs: {asin: [post_id, ...]}',
            ],
            'category_id' => [
                'required' => false,
                'type' => 'integer',
                'description' => 'Category ID to link products to',
            ],
            'reset_failed' => [
                'required' => false,
                'type' => 'boolean',
                'default' => false,
                'description' => 'Reset failed products to pending for re-scraping',
            ],
            'link_from_queue' => [
                'required' => false,
                'type' => 'boolean',
                'default' => false,
                'description' => 'Auto-link products to categories based on cat queue linked_asins data',
            ],
        ];
    }

    /**
     * Get product link endpoint arguments
     */
    private function getProductLinkArgs(): array
    {
        return [
            'provider' => [
                'required' => true,
                'type' => 'string',
                'description' => 'Provider slug (e.g., amazon, walmart, bestbuy)',
            ],
            'provider_name' => [
                'type' => 'string',
                'description' => 'Display name for the provider (optional, defaults to known provider name)',
            ],
            'affiliate_url' => [
                'required' => true,
                'type' => 'string',
                'description' => 'The affiliate URL',
            ],
            'price' => [
                'type' => 'number',
                'description' => 'Product price at this provider',
            ],
            'currency' => [
                'default' => 'USD',
                'type' => 'string',
                'description' => 'Currency code',
            ],
            'in_stock' => [
                'type' => 'boolean',
                'description' => 'Stock status at this provider',
            ],
            'is_primary' => [
                'default' => false,
                'type' => 'boolean',
                'description' => 'Whether this is the primary link',
            ],
            'sort_order' => [
                'default' => 0,
                'type' => 'integer',
                'description' => 'Sort order for display',
            ],
        ];
    }

    // =========================================================================
    // LIVE PRICES ENDPOINT
    // =========================================================================

    /**
     * GET /products/live-prices?asins=B0xxx,B1xxx
     *
     * Returns price/stock/prime/last_updated for a batch of ASINs.
     * Data comes from our DB (already scraped) — not from Amazon API.
     *
     * Batching: all ASINs from all shortcodes on the page are collected
     * client-side and sent in a SINGLE request. 1 fetch = 1 DB query.
     *
     * Amazon TOS: price/stock must NOT be cached. Response headers set
     * Cache-Control: no-store to prevent Nginx/CDN/browser caching.
     */
    public function livePrices(WP_REST_Request $request): WP_REST_Response
    {
        global $wpdb;

        $raw = $request->get_param('asins');
        if (empty($raw)) {
            return new WP_REST_Response(['data' => []], 200);
        }

        // Sanitize and validate ASIN list (alphanumeric only, max 50)
        $asins = array_values(array_filter(
            array_map(
                fn($a) => strtoupper(preg_replace('/[^A-Za-z0-9]/', '', trim($a))),
                explode(',', $raw)
            ),
            fn($a) => strlen($a) >= 4 && strlen($a) <= 20
        ));

        if (empty($asins)) {
            return new WP_REST_Response(['data' => []], 200);
        }

        // Hard cap at 50 ASINs per request
        $asins = array_slice($asins, 0, 50);

        $table = Schema::productsTable();
        $placeholders = implode(',', array_fill(0, count($asins), '%s'));

        // Single query — only the 6 fields the frontend needs.
        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT asin, price, original_price, currency, in_stock, is_prime, last_scraped_at
                 FROM {$table}
                 WHERE asin IN ({$placeholders})
                 AND status IN ('scraped','update','updating')",
                ...$asins
            ),
            ARRAY_A
        );

        $data = [];
        foreach ((array) $rows as $row) {
            $price    = $row['price']    !== null ? (float) $row['price']    : null;
            $original = $row['original_price'] !== null ? (float) $row['original_price'] : null;

            $discountPct = 0;
            if ($original && $price && $original > $price) {
                $discountPct = (int) round((1 - $price / $original) * 100);
            }

            $data[$row['asin']] = [
                'price'          => $price,
                'original_price' => $original,
                'currency'       => $row['currency'] ?? 'USD',
                'discount_pct'   => $discountPct,
                'in_stock'       => (bool) $row['in_stock'],
                'is_prime'       => (bool) $row['is_prime'],
                'last_scraped_at' => $row['last_scraped_at'],
            ];
        }

        $response = new WP_REST_Response(['data' => $data], 200);

        // Amazon PA-API TOS: price and availability must not be cached.
        $response->header('Cache-Control', 'no-store, no-cache, must-revalidate');
        $response->header('Pragma', 'no-cache');

        return $response;
    }
}
