<?php
/**
 * Queue REST API Controller
 *
 * REST endpoints for keyword queue management (auto content)
 * Base URL: /acms/v1/queue
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro\Api;

use AffiliateCMS\Pro\Database\Schema;
use AffiliateCMS\Pro\Core\ProviderManager;
use AffiliateCMS\Pro\Core\QueueProcessor;
use AffiliateCMS\Pro\Repositories\ProductRepository;
use WP_REST_Request;
use WP_REST_Response;
use WP_Error;

class QueueController
{
    private string $namespace = 'acms/v1';

    /**
     * Register REST API routes
     */
    public function register(): void
    {
        $this->registerRoutes();
    }

    /**
     * Register routes
     */
    public function registerRoutes(): void
    {
        // GET /queue - List queue items
        // POST /queue - Add keyword(s) to queue
        register_rest_route($this->namespace, '/queue', [
            [
                'methods' => 'GET',
                'callback' => [$this, 'index'],
                'permission_callback' => [$this, 'checkPermission'],
                'args' => $this->getIndexArgs(),
            ],
            [
                'methods' => 'POST',
                'callback' => [$this, 'store'],
                'permission_callback' => [$this, 'checkPermission'],
                'args' => $this->getStoreArgs(),
            ],
        ]);

        // GET /queue/stats - Get statistics
        register_rest_route($this->namespace, '/queue/stats', [
            'methods' => 'GET',
            'callback' => [$this, 'stats'],
            'permission_callback' => [$this, 'checkPermission'],
        ]);

        // POST /queue/bulk - Bulk operations
        register_rest_route($this->namespace, '/queue/bulk', [
            'methods' => 'POST',
            'callback' => [$this, 'bulk'],
            'permission_callback' => [$this, 'checkPermission'],
            'args' => $this->getBulkArgs(),
        ]);

        // POST /queue/process - Process queue item(s)
        register_rest_route($this->namespace, '/queue/process', [
            'methods' => 'POST',
            'callback' => [$this, 'process'],
            'permission_callback' => [$this, 'checkPermission'],
            'args' => $this->getProcessArgs(),
        ]);

        // GET /queue/{id}/log - Get processing log for queue item
        register_rest_route($this->namespace, '/queue/(?P<id>\d+)/log', [
            'methods' => 'GET',
            'callback' => [$this, 'getProcessingLog'],
            'permission_callback' => [$this, 'checkPermission'],
        ]);

        // GET /queue/{id} - Get single queue item
        // PATCH /queue/{id} - Update queue item
        // DELETE /queue/{id} - Delete queue item
        register_rest_route($this->namespace, '/queue/(?P<id>\d+)', [
            [
                'methods' => 'GET',
                'callback' => [$this, 'show'],
                'permission_callback' => [$this, 'checkPermission'],
            ],
            [
                'methods' => 'PATCH,PUT',
                'callback' => [$this, 'update'],
                'permission_callback' => [$this, 'checkPermission'],
            ],
            [
                'methods' => 'DELETE',
                'callback' => [$this, 'destroy'],
                'permission_callback' => [$this, 'checkPermission'],
            ],
        ]);
    }

    /**
     * Check admin permission
     */
    public function checkPermission(): bool
    {
        return current_user_can('manage_options');
    }

    /**
     * GET /queue - List queue items
     */
    public function index(WP_REST_Request $request): WP_REST_Response
    {
        global $wpdb;
        $table = Schema::queueTable();

        $page = (int) ($request->get_param('page') ?? 1);
        $perPage = (int) ($request->get_param('per_page') ?? 100);
        $search = $request->get_param('search') ?? '';
        $status = $request->get_param('status') ?? '';
        $postType = $request->get_param('post_type') ?? '';
        $orderBy = $request->get_param('orderby') ?? 'created_at';
        $order = strtoupper($request->get_param('order') ?? 'DESC');

        // Build query
        $where = ['1=1'];
        $params = [];

        if ($search) {
            $where[] = 'keyword LIKE %s';
            $params[] = '%' . $wpdb->esc_like($search) . '%';
        }

        if ($status) {
            $where[] = 'status = %s';
            $params[] = $status;
        }

        if ($postType) {
            $where[] = 'post_type = %s';
            $params[] = $postType;
        }

        $whereClause = implode(' AND ', $where);

        // Allowed order columns
        $allowedColumns = ['id', 'keyword', 'status', 'post_type', 'created_at', 'updated_at', 'scheduled_at'];
        if (!in_array($orderBy, $allowedColumns)) {
            $orderBy = 'created_at';
        }
        if (!in_array($order, ['ASC', 'DESC'])) {
            $order = 'DESC';
        }

        // Get total count
        $countQuery = "SELECT COUNT(*) FROM {$table} WHERE {$whereClause}";
        if (!empty($params)) {
            $countQuery = $wpdb->prepare($countQuery, ...$params);
        }
        $total = (int) $wpdb->get_var($countQuery);

        // Get items
        $offset = ($page - 1) * $perPage;
        $query = "SELECT * FROM {$table} WHERE {$whereClause} ORDER BY {$orderBy} {$order} LIMIT %d OFFSET %d";
        $params[] = $perPage;
        $params[] = $offset;

        $items = $wpdb->get_results($wpdb->prepare($query, ...$params), ARRAY_A);

        // Parse JSON fields and enrich with term names
        foreach ($items as &$item) {
            if (isset($item['content_settings'])) {
                $item['content_settings'] = is_array($item['content_settings'])
                    ? $item['content_settings']
                    : json_decode($item['content_settings'], true);
            }
            if (isset($item['processing_log'])) {
                $item['processing_log'] = is_array($item['processing_log'])
                    ? $item['processing_log']
                    : json_decode($item['processing_log'], true);
            }
            // Parse linked_asins and expose as 'asins' for frontend
            if (isset($item['linked_asins'])) {
                $item['asins'] = is_array($item['linked_asins'])
                    ? $item['linked_asins']
                    : (json_decode($item['linked_asins'], true) ?: []);
            } else {
                $item['asins'] = [];
            }
            // Get category name from term_id
            if (!empty($item['category_id'])) {
                $term = get_term((int) $item['category_id']);
                $item['category_name'] = ($term && !is_wp_error($term)) ? $term->name : '';
            } else {
                $item['category_name'] = '';
            }
            // Get post status if generated_post_id exists
            if (!empty($item['generated_post_id'])) {
                $post = get_post((int) $item['generated_post_id']);
                $item['post_status'] = $post ? $post->post_status : null;
            } else {
                $item['post_status'] = null;
            }
        }

        return new WP_REST_Response([
            'success' => true,
            'data' => [
                'items' => $items,
                'total' => $total,
                'page' => $page,
                'per_page' => $perPage,
                'total_pages' => (int) ceil($total / $perPage),
                'stats' => $this->getStatsData(),
            ],
        ]);
    }

    /**
     * GET /queue/{id} - Get single queue item
     */
    public function show(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        global $wpdb;
        $table = Schema::queueTable();
        $id = (int) $request->get_param('id');

        $item = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $id),
            ARRAY_A
        );

        if (!$item) {
            return new WP_Error('not_found', 'Queue item not found', ['status' => 404]);
        }

        // Parse JSON fields
        if (isset($item['content_settings'])) {
            $item['content_settings'] = is_array($item['content_settings'])
                ? $item['content_settings']
                : json_decode($item['content_settings'], true);
        }
        if (isset($item['processing_log'])) {
            $item['processing_log'] = is_array($item['processing_log'])
                ? $item['processing_log']
                : json_decode($item['processing_log'], true);
        }

        return new WP_REST_Response([
            'success' => true,
            'data' => $item,
        ]);
    }

    /**
     * POST /queue - Add keyword(s) to queue
     */
    public function store(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        global $wpdb;
        $table = Schema::queueTable();

        $keywords = $request->get_param('keywords');
        $postType = $request->get_param('post_type') ?? 'acms_reviews';
        $categoryId = $request->get_param('category_id');
        $brandId = $request->get_param('brand_id');
        $tags = $request->get_param('tags');
        $template = $request->get_param('template') ?? 'default';
        $contentSettings = $request->get_param('content_settings') ?: [];

        // New fields from add-keywords-modal
        $authorId = $request->get_param('author_id');
        $templateId = $request->get_param('template_id');
        $searchAsin = (bool) $request->get_param('search_asin');
        $searchLimit = (int) ($request->get_param('search_limit') ?? 15);
        $manualAsins = $request->get_param('manual_asins');
        $autoPublish = (bool) $request->get_param('auto_publish');
        $noIndex = $request->get_param('no_index') ?? true; // Default to noindex
        $processNow = (bool) $request->get_param('process_now');

        // Ensure search_limit is within bounds
        $searchLimit = max(1, min(25, $searchLimit));

        // Parse manual ASINs if provided and search is disabled
        $parsedManualAsins = [];
        if (!$searchAsin && !empty($manualAsins)) {
            // Split by comma, space, or newline and validate ASIN format
            $asins = preg_split('/[,\s\n]+/', $manualAsins);
            foreach ($asins as $asin) {
                $asin = strtoupper(trim($asin));
                // Valid ASIN: 10 chars, starts with B, alphanumeric
                if (strlen($asin) === 10 && $asin[0] === 'B' && preg_match('/^B[A-Z0-9]{9}$/', $asin)) {
                    $parsedManualAsins[] = $asin;
                }
            }
            $parsedManualAsins = array_unique($parsedManualAsins);
        }

        // Store author_id, template_id, auto_publish, no_index in content_settings
        if (!is_array($contentSettings)) {
            $contentSettings = [];
        }
        if ($authorId) {
            $contentSettings['author_id'] = $authorId;
        }
        if ($templateId) {
            $contentSettings['template_id'] = $templateId;
        }
        $contentSettings['auto_publish'] = $autoPublish;
        $contentSettings['no_index'] = (bool) $noIndex;

        // Normalize keywords to array
        if (is_string($keywords)) {
            $keywords = preg_split('/[\n]+/', $keywords);
        }

        // Clean and validate keywords
        $keywords = array_filter(array_map(function ($kw) {
            return trim($kw);
        }, (array) $keywords));

        if (empty($keywords)) {
            return new WP_Error('no_keywords', 'No valid keywords provided', ['status' => 400]);
        }

        $results = [
            'created' => [],
            'created_ids' => [],
            'existing' => [],
            'failed' => [],
        ];

        foreach ($keywords as $keyword) {
            if (empty($keyword)) continue;

            // Check if already exists
            $existing = $wpdb->get_var(
                $wpdb->prepare("SELECT id FROM {$table} WHERE keyword = %s", $keyword)
            );

            if ($existing) {
                $results['existing'][] = $keyword;
                continue;
            }

            // Insert
            $data = [
                'keyword' => $keyword,
                'post_type' => $postType,
                'category_id' => $categoryId,
                'brand_id' => $brandId,
                'tags' => $tags ? trim($tags) : null,
                'template' => $template,
                'status' => 'pending',
                'auto_search_asins' => $searchAsin ? 1 : 0,
                'search_limit' => $searchLimit,
                'linked_asins' => !empty($parsedManualAsins) ? wp_json_encode($parsedManualAsins) : null,
                'content_settings' => !empty($contentSettings) ? wp_json_encode($contentSettings) : null,
            ];

            $inserted = $wpdb->insert($table, $data);

            if ($inserted) {
                $queueId = $wpdb->insert_id;
                $results['created'][] = $keyword;
                $results['created_ids'][] = $queueId;
            } else {
                $results['failed'][] = $keyword;
            }
        }

        // If "Process Now" is enabled, trigger background processing for created items
        if ($processNow && !empty($results['created_ids'])) {
            foreach ($results['created_ids'] as $queueId) {
                wp_schedule_single_event(time(), 'acms_process_queue_item', ['queue_id' => $queueId]);
            }
            $results['processing_scheduled'] = count($results['created_ids']);
        }

        $createdCount = count($results['created']);
        $existingCount = count($results['existing']);
        $failedCount = count($results['failed']);
        $processingScheduled = $results['processing_scheduled'] ?? 0;

        $messages = [];
        if ($createdCount > 0) {
            $messages[] = "{$createdCount} keywords added";
        }
        if ($processingScheduled > 0) {
            $messages[] = "{$processingScheduled} scheduled for processing";
        }
        if ($existingCount > 0) {
            $messages[] = "{$existingCount} already exist";
        }
        if ($failedCount > 0) {
            $messages[] = "{$failedCount} failed";
        }

        return new WP_REST_Response([
            'success' => $createdCount > 0,
            'data' => $results,
            'message' => implode(', ', $messages),
            'summary' => [
                'created' => $createdCount,
                'existing' => $existingCount,
                'failed' => $failedCount,
                'processing_scheduled' => $processingScheduled,
            ],
        ], $createdCount > 0 ? 201 : 200);
    }

    /**
     * PATCH /queue/{id} - Update queue item
     */
    public function update(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        global $wpdb;
        $table = Schema::queueTable();
        $id = (int) $request->get_param('id');

        // Get current item
        $item = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $id),
            ARRAY_A
        );

        if (!$item) {
            return new WP_Error('not_found', 'Queue item not found', ['status' => 404]);
        }

        // Allowed update fields
        $allowedFields = [
            'keyword', 'post_type', 'category_id', 'template',
            'status', 'scheduled_at', 'content_settings',
            'tags', 'auto_search_asins', 'search_limit', 'linked_asins',
            // AI post fields (for retry/reset functionality)
            'ai_post_status', 'ai_post_generating_at', 'ai_post_error'
        ];

        $data = [];
        $newContentSettings = null;

        foreach ($allowedFields as $field) {
            $value = $request->get_param($field);
            if ($value !== null) {
                if ($field === 'content_settings' && is_array($value)) {
                    $newContentSettings = $value;
                    $data[$field] = wp_json_encode($value);
                } elseif ($field === 'linked_asins' && is_array($value)) {
                    $data[$field] = wp_json_encode($value);
                    $data['search_results_count'] = count($value);
                } else {
                    $data[$field] = $value;
                }
            }
        }

        if (empty($data)) {
            return new WP_Error('no_data', 'No data to update', ['status' => 400]);
        }

        $updated = $wpdb->update($table, $data, ['id' => $id]);

        if ($updated === false) {
            return new WP_Error('update_failed', 'Failed to update queue item', ['status' => 500]);
        }

        // If content_settings.no_index was updated and post exists, update post meta
        if ($newContentSettings !== null && isset($newContentSettings['no_index']) && !empty($item['generated_post_id'])) {
            $postId = (int) $item['generated_post_id'];
            $noIndex = (bool) $newContentSettings['no_index'];

            if ($noIndex) {
                // Set noindex
                update_post_meta($postId, '_acms_noindex', '1');

                // Yoast SEO support
                if (defined('WPSEO_VERSION')) {
                    update_post_meta($postId, '_yoast_wpseo_meta-robots-noindex', '1');
                }

                // Rank Math support
                if (defined('RANK_MATH_VERSION')) {
                    update_post_meta($postId, 'rank_math_robots', ['noindex']);
                }
            } else {
                // Remove noindex
                delete_post_meta($postId, '_acms_noindex');

                // Yoast SEO support
                if (defined('WPSEO_VERSION')) {
                    delete_post_meta($postId, '_yoast_wpseo_meta-robots-noindex');
                }

                // Rank Math support
                if (defined('RANK_MATH_VERSION')) {
                    update_post_meta($postId, 'rank_math_robots', ['index']);
                }
            }
        }

        return new WP_REST_Response([
            'success' => true,
            'message' => 'Queue item updated successfully',
        ]);
    }

    /**
     * DELETE /queue/{id} - Delete queue item
     *
     * @param string delete_mode - 'basic' (default) or 'full'
     *   - basic: Only delete queue item
     *   - full: Delete queue item + generated post + orphaned ASINs
     */
    public function destroy(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        global $wpdb;
        $table = Schema::queueTable();
        $id = (int) $request->get_param('id');
        $deleteMode = $request->get_param('delete_mode') ?? 'basic';

        // Get item data before deletion (needed for full delete)
        $item = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $id),
            ARRAY_A
        );

        if (!$item) {
            return new WP_Error('not_found', 'Queue item not found', ['status' => 404]);
        }

        $deletedPosts = 0;
        $deletedAsins = 0;

        // Full delete: delete post and orphaned ASINs first
        if ($deleteMode === 'full') {
            $result = $this->deleteRelatedData($item);
            $deletedPosts = $result['deleted_posts'];
            $deletedAsins = $result['deleted_asins'];
        }

        // Delete queue item
        $deleted = $wpdb->delete($table, ['id' => $id]);

        if (!$deleted) {
            return new WP_Error('delete_failed', 'Failed to delete queue item', ['status' => 500]);
        }

        $message = 'Queue item deleted successfully';
        if ($deleteMode === 'full') {
            $parts = ['1 keyword'];
            if ($deletedPosts > 0) {
                $parts[] = "{$deletedPosts} post";
            }
            if ($deletedAsins > 0) {
                $parts[] = "{$deletedAsins} orphaned ASIN(s)";
            }
            $message = implode(', ', $parts) . ' deleted';
        }

        return new WP_REST_Response([
            'success' => true,
            'message' => $message,
            'data' => [
                'deleted_posts' => $deletedPosts,
                'deleted_asins' => $deletedAsins,
            ],
        ]);
    }

    /**
     * POST /queue/bulk - Bulk operations
     *
     * For delete action:
     * @param string delete_mode - 'basic' (default) or 'full'
     *   - basic: Only delete queue items
     *   - full: Delete queue items + generated posts + orphaned ASINs
     */
    public function bulk(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        global $wpdb;
        $table = Schema::queueTable();

        $action = $request->get_param('action');
        $ids = $request->get_param('ids') ?? [];

        if (empty($ids)) {
            return new WP_Error('no_ids', 'No IDs provided', ['status' => 400]);
        }

        $ids = array_map('intval', (array) $ids);
        $placeholders = implode(',', array_fill(0, count($ids), '%d'));

        switch ($action) {
            case 'delete':
                $deleteMode = $request->get_param('delete_mode') ?? 'basic';
                $deletedPosts = 0;
                $deletedAsins = 0;

                // Full delete: delete posts and orphaned ASINs first
                if ($deleteMode === 'full') {
                    // Get all items data
                    $items = $wpdb->get_results(
                        $wpdb->prepare("SELECT * FROM {$table} WHERE id IN ({$placeholders})", ...$ids),
                        ARRAY_A
                    );

                    foreach ($items as $item) {
                        $result = $this->deleteRelatedData($item);
                        $deletedPosts += $result['deleted_posts'];
                        $deletedAsins += $result['deleted_asins'];
                    }
                }

                // Delete queue items
                $count = $wpdb->query(
                    $wpdb->prepare("DELETE FROM {$table} WHERE id IN ({$placeholders})", ...$ids)
                );

                $message = "{$count} items deleted";
                if ($deleteMode === 'full') {
                    $parts = ["{$count} keyword(s)"];
                    if ($deletedPosts > 0) {
                        $parts[] = "{$deletedPosts} post(s)";
                    }
                    if ($deletedAsins > 0) {
                        $parts[] = "{$deletedAsins} orphaned ASIN(s)";
                    }
                    $message = implode(', ', $parts) . ' deleted';
                }

                return new WP_REST_Response([
                    'success' => true,
                    'data' => [
                        'deleted' => $count,
                        'deleted_posts' => $deletedPosts,
                        'deleted_asins' => $deletedAsins,
                    ],
                    'message' => $message,
                ]);

            case 'update_status':
                $status = $request->get_param('status');
                if (!$status) {
                    return new WP_Error('missing_status', 'Status is required', ['status' => 400]);
                }
                $count = $wpdb->query(
                    $wpdb->prepare(
                        "UPDATE {$table} SET status = %s WHERE id IN ({$placeholders})",
                        $status,
                        ...$ids
                    )
                );
                return new WP_REST_Response([
                    'success' => true,
                    'data' => ['updated' => $count],
                    'message' => "{$count} items updated",
                ]);

            case 'reset':
                // Reset failed/completed items to pending
                $count = $wpdb->query(
                    $wpdb->prepare(
                        "UPDATE {$table} SET status = 'pending', attempts = 0, error_message = NULL WHERE id IN ({$placeholders})",
                        ...$ids
                    )
                );
                return new WP_REST_Response([
                    'success' => true,
                    'data' => ['reset' => $count],
                    'message' => "{$count} items reset to pending",
                ]);

            default:
                return new WP_Error('invalid_action', 'Invalid bulk action', ['status' => 400]);
        }
    }

    /**
     * POST /queue/process - Process queue item(s)
     */
    public function process(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        global $wpdb;
        $table = Schema::queueTable();

        $ids = $request->get_param('ids');
        $async = (bool) $request->get_param('async'); // If true, schedule for background processing

        // If no IDs provided, get next pending items
        if (empty($ids)) {
            $limit = (int) ($request->get_param('limit') ?? 1);
            $items = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT * FROM {$table} WHERE status = 'pending' ORDER BY priority DESC, created_at ASC LIMIT %d",
                    $limit
                ),
                ARRAY_A
            );
            $ids = array_column($items, 'id');
        } else {
            $ids = array_map('intval', (array) $ids);
        }

        if (empty($ids)) {
            return new WP_REST_Response([
                'success' => true,
                'data' => ['processed' => 0],
                'message' => 'No items to process',
            ]);
        }

        // Log start of processing
        error_log('[ACMS Queue] Process request: ' . count($ids) . ' items, async=' . ($async ? 'true' : 'false'));

        $results = [];
        $processor = new QueueProcessor(true); // Enable debug logging

        if ($async) {
            // Schedule for background processing via WP Cron
            foreach ($ids as $id) {
                wp_schedule_single_event(time(), 'acms_process_queue_item', ['queue_id' => (int) $id]);

                $results[$id] = [
                    'status' => 'scheduled',
                    'message' => 'Scheduled for background processing'
                ];
            }

            return new WP_REST_Response([
                'success' => true,
                'data' => [
                    'scheduled' => count($ids),
                    'results' => $results,
                ],
                'message' => count($ids) . ' items scheduled for background processing',
            ]);
        }

        // Synchronous processing (one at a time)
        foreach ($ids as $id) {
            $result = $processor->processItem((int) $id);

            $results[$id] = [
                'success' => $result['success'],
                'message' => $result['message'],
                'post_id' => $result['post_id'] ?? null,
            ];

            // Stop on first failure in sync mode
            if (!$result['success']) {
                break;
            }
        }

        $successCount = count(array_filter($results, fn($r) => $r['success'] ?? false));
        $failedCount = count($results) - $successCount;

        return new WP_REST_Response([
            'success' => $successCount > 0,
            'data' => [
                'processed' => $successCount,
                'failed' => $failedCount,
                'results' => $results,
            ],
            'message' => "{$successCount} processed, {$failedCount} failed",
        ]);
    }

    /**
     * GET /queue/{id}/log - Get processing log
     */
    public function getProcessingLog(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        global $wpdb;
        $table = Schema::queueTable();
        $id = (int) $request->get_param('id');

        $item = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT id, keyword, status, processing_log, error_message, attempts, started_at, completed_at
                 FROM {$table} WHERE id = %d",
                $id
            ),
            ARRAY_A
        );

        if (!$item) {
            return new WP_Error('not_found', 'Queue item not found', ['status' => 404]);
        }

        $log = $item['processing_log']
            ? (is_array($item['processing_log']) ? $item['processing_log'] : json_decode($item['processing_log'], true))
            : null;

        return new WP_REST_Response([
            'success' => true,
            'data' => [
                'id' => $item['id'],
                'keyword' => $item['keyword'],
                'status' => $item['status'],
                'attempts' => (int) $item['attempts'],
                'error_message' => $item['error_message'],
                'started_at' => $item['started_at'],
                'completed_at' => $item['completed_at'],
                'log' => $log,
                'steps' => $log['steps'] ?? [],
                'errors' => $log['errors'] ?? [],
                'progress' => $log['progress'] ?? null,
            ],
        ]);
    }

    /**
     * GET /queue/stats - Get statistics
     */
    public function stats(WP_REST_Request $request): WP_REST_Response
    {
        return new WP_REST_Response([
            'success' => true,
            'data' => $this->getStatsData(),
        ]);
    }

    /**
     * Get stats data
     */
    private function getStatsData(): array
    {
        global $wpdb;
        $table = Schema::queueTable();

        // Check if table exists
        $tableExists = $wpdb->get_var(
            $wpdb->prepare("SHOW TABLES LIKE %s", $table)
        );

        if (!$tableExists) {
            return [
                'total' => 0,
                'pending' => 0,
                'processing' => 0,
                'completed' => 0,
                'failed' => 0,
                'paused' => 0,
            ];
        }

        $stats = [
            'total' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table}"),
            'pending' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE status = 'pending'"),
            'processing' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE status = 'processing'"),
            'completed' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE status = 'completed'"),
            'failed' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE status = 'failed'"),
            'paused' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE status = 'paused'"),
        ];

        return $stats;
    }

    /**
     * Search ASINs by keyword and link them to queue item
     *
     * @param int $queueId Queue item ID
     * @param string $keyword Search keyword
     * @param int $limit Max number of ASINs to retrieve
     * @return array ['count' => int, 'asins' => array, 'provider' => string|null]
     */
    private function searchAndLinkAsins(int $queueId, string $keyword, int $limit): array
    {
        global $wpdb;
        $queueTable = Schema::queueTable();
        $productsTable = Schema::productsTable();

        $result = [
            'count' => 0,
            'asins' => [],
            'provider' => null,
        ];

        try {
            // Use ProviderManager to search products (follows provider priority)
            $providerManager = ProviderManager::instance();
            // searchProducts(query, domain) - limit is handled when processing results
            $searchResults = $providerManager->searchProducts($keyword);

            if (empty($searchResults) || !is_array($searchResults)) {
                return $result;
            }

            $linkedAsins = [];
            $productRepository = new ProductRepository();

            // Track product stats for template placeholders
            $productStats = [
                'product_count' => 0,
                'price_min' => null,
                'price_max' => null,
                'review_total' => 0,
                'brands' => [],
            ];

            foreach ($searchResults as $productData) {
                if (empty($productData['asin'])) {
                    continue;
                }

                $asin = $productData['asin'];

                // Check if ASIN already exists in products table
                $existingProduct = $wpdb->get_var(
                    $wpdb->prepare("SELECT id FROM {$productsTable} WHERE asin = %s", $asin)
                );

                if (!$existingProduct) {
                    // Add new product with basic info (status = pending for later scrape)
                    $newProductData = [
                        'asin' => $asin,
                        'title' => $productData['title'] ?? '',
                        'brand' => $productData['brand'] ?? '',
                        'price' => isset($productData['price']) ? floatval($productData['price']) : null,
                        'rating' => isset($productData['rating']) ? floatval($productData['rating']) : null,
                        'reviews_count' => isset($productData['reviews']) ? intval($productData['reviews']) : 0,
                        'image_url' => $productData['image'] ?? '',
                        'is_prime' => !empty($productData['isPrime']) ? 1 : 0,
                        'status' => 'pending',
                        'last_provider' => $providerManager->getLastUsedProvider(),
                    ];

                    $wpdb->insert($productsTable, $newProductData);
                }

                // Collect stats from search results
                $price = isset($productData['price']) ? floatval($productData['price']) : null;
                $reviewCount = isset($productData['reviews']) ? intval($productData['reviews']) : 0;
                $brand = $productData['brand'] ?? '';

                if ($price !== null && $price > 0) {
                    if ($productStats['price_min'] === null || $price < $productStats['price_min']) {
                        $productStats['price_min'] = $price;
                    }
                    if ($productStats['price_max'] === null || $price > $productStats['price_max']) {
                        $productStats['price_max'] = $price;
                    }
                }

                $productStats['review_total'] += $reviewCount;

                if (!empty($brand) && !in_array($brand, $productStats['brands'])) {
                    $productStats['brands'][] = $brand;
                }

                $linkedAsins[] = $asin;

                if (count($linkedAsins) >= $limit) {
                    break;
                }
            }

            // Update product count
            $productStats['product_count'] = count($linkedAsins);

            // Update queue item with linked ASINs and product stats
            if (!empty($linkedAsins)) {
                // Get existing content_settings to merge with product_stats
                $existingSettings = $wpdb->get_var(
                    $wpdb->prepare("SELECT content_settings FROM {$queueTable} WHERE id = %d", $queueId)
                );
                $contentSettings = $existingSettings ? json_decode($existingSettings, true) : [];
                if (!is_array($contentSettings)) {
                    $contentSettings = [];
                }

                // Add product stats to content_settings
                $contentSettings['product_stats'] = $productStats;

                $wpdb->update($queueTable, [
                    'linked_asins' => wp_json_encode($linkedAsins),
                    'search_results_count' => count($linkedAsins),
                    'search_provider' => $providerManager->getLastUsedProvider(),
                    'searched_at' => current_time('mysql'),
                    'content_settings' => wp_json_encode($contentSettings),
                ], ['id' => $queueId]);

                $result['count'] = count($linkedAsins);
                $result['asins'] = $linkedAsins;
                $result['provider'] = $providerManager->getLastUsedProvider();
                $result['product_stats'] = $productStats;
            }
        } catch (\Throwable $e) {
            // Log error but don't fail the entire operation
            error_log('ACMS searchAndLinkAsins error: ' . $e->getMessage());
            $result['error'] = $e->getMessage();
        }

        return $result;
    }

    /**
     * Delete related data for a queue item (post and orphaned ASINs)
     *
     * @param array $item Queue item data
     * @return array ['deleted_posts' => int, 'deleted_asins' => int]
     */
    private function deleteRelatedData(array $item): array
    {
        global $wpdb;
        $productsTable = Schema::productsTable();
        $queueTable = Schema::queueTable();

        $deletedPosts = 0;
        $deletedAsins = 0;

        // 1. Delete generated post if exists
        $postId = $item['generated_post_id'] ?? null;
        if ($postId) {
            $deleted = wp_delete_post((int) $postId, true); // true = force delete (skip trash)
            if ($deleted) {
                $deletedPosts = 1;
            }
        }

        // 2. Delete orphaned ASINs
        // An ASIN is "orphaned" if it's not linked to any OTHER queue item
        $linkedAsins = $item['linked_asins']
            ? (is_array($item['linked_asins']) ? $item['linked_asins'] : json_decode($item['linked_asins'], true))
            : [];

        if (!empty($linkedAsins)) {
            $currentQueueId = (int) $item['id'];

            foreach ($linkedAsins as $asin) {
                // Check if this ASIN is used by any other queue item
                $isUsedElsewhere = $wpdb->get_var(
                    $wpdb->prepare(
                        "SELECT COUNT(*) FROM {$queueTable}
                         WHERE id != %d
                         AND linked_asins LIKE %s",
                        $currentQueueId,
                        '%"' . $wpdb->esc_like($asin) . '"%'
                    )
                );

                // If ASIN is not used by other queue items, delete it from products table
                if (!$isUsedElsewhere) {
                    $deleted = $wpdb->delete($productsTable, ['asin' => $asin]);
                    if ($deleted) {
                        $deletedAsins++;
                    }
                }
            }
        }

        return [
            'deleted_posts' => $deletedPosts,
            'deleted_asins' => $deletedAsins,
        ];
    }

    /**
     * Get index endpoint arguments
     */
    private function getIndexArgs(): array
    {
        return [
            'page' => [
                'default' => 1,
                'type' => 'integer',
                'minimum' => 1,
            ],
            'per_page' => [
                'default' => 100,
                'type' => 'integer',
                'minimum' => 1,
                'maximum' => 1000,
            ],
            'search' => [
                'default' => '',
                'type' => 'string',
            ],
            'status' => [
                'default' => '',
                'type' => 'string',
                'enum' => ['', 'pending', 'processing', 'completed', 'failed', 'paused'],
            ],
            'post_type' => [
                'default' => '',
                'type' => 'string',
            ],
            'orderby' => [
                'default' => 'created_at',
                'type' => 'string',
                'enum' => ['id', 'keyword', 'status', 'post_type', 'created_at', 'updated_at', 'scheduled_at'],
            ],
            'order' => [
                'default' => 'desc',
                'type' => 'string',
                'enum' => ['asc', 'desc'],
            ],
        ];
    }

    /**
     * Get store endpoint arguments
     */
    private function getStoreArgs(): array
    {
        return [
            'keywords' => [
                'required' => true,
                'type' => ['string', 'array'],
                'description' => 'Single keyword, array of keywords, or string with keywords separated by newlines',
            ],
            'post_type' => [
                'default' => 'acms_reviews',
                'type' => 'string',
            ],
            'category_id' => [
                'type' => ['integer', 'null'],
                'default' => null,
            ],
            'author_id' => [
                'type' => ['string', 'integer', 'null'],
                'default' => 'random',
                'description' => 'Author ID for generated posts, or "random" for random author',
            ],
            'template_id' => [
                'type' => ['string', 'null'],
                'default' => null,
                'description' => 'Content template ID to use for generating posts',
            ],
            'search_asin' => [
                'default' => true,
                'type' => 'boolean',
                'description' => 'Whether to auto search ASINs from Amazon',
            ],
            'search_limit' => [
                'default' => 15,
                'type' => 'integer',
                'minimum' => 1,
                'maximum' => 25,
                'description' => 'Number of ASINs to search (1-25)',
            ],
            'auto_publish' => [
                'default' => false,
                'type' => 'boolean',
                'description' => 'Whether to auto publish generated posts (false = draft)',
            ],
            'no_index' => [
                'default' => true,
                'type' => 'boolean',
                'description' => 'Whether to set post as noindex for search engines (default true)',
            ],
            'template' => [
                'default' => 'default',
                'type' => 'string',
            ],
            'content_settings' => [
                'type' => 'object',
            ],
        ];
    }

    /**
     * Get bulk endpoint arguments
     */
    private function getBulkArgs(): array
    {
        return [
            'action' => [
                'required' => true,
                'type' => 'string',
                'enum' => ['delete', 'update_status', 'reset'],
            ],
            'ids' => [
                'required' => true,
                'type' => 'array',
                'items' => ['type' => 'integer'],
            ],
            'status' => [
                'type' => 'string',
                'enum' => ['pending', 'processing', 'completed', 'failed', 'paused'],
            ],
            'delete_mode' => [
                'type' => 'string',
                'default' => 'basic',
                'enum' => ['basic', 'full'],
                'description' => 'Delete mode: basic (queue only) or full (queue + post + orphaned ASINs)',
            ],
        ];
    }

    /**
     * Get process endpoint arguments
     */
    private function getProcessArgs(): array
    {
        return [
            'ids' => [
                'type' => 'array',
                'items' => ['type' => 'integer'],
                'description' => 'Specific IDs to process. If empty, processes next pending items.',
            ],
            'limit' => [
                'default' => 1,
                'type' => 'integer',
                'minimum' => 1,
                'maximum' => 10,
                'description' => 'Number of pending items to process if no IDs provided.',
            ],
        ];
    }
}
