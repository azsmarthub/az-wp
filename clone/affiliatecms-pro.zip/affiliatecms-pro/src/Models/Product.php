<?php
/**
 * Product Model
 *
 * Data model for Amazon products with all scraped fields
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro\Models;

class Product
{
    // === PRIMARY ===
    public ?int $id = null;
    public string $asin = '';

    // === CORE PRODUCT INFO ===
    public ?string $title = null;
    public ?string $brand = null;
    public ?float $price = null;
    public ?float $originalPrice = null;
    public string $currency = 'USD';
    public ?float $rating = null;
    public int $reviewsCount = 0;
    public int $score = 70; // AZS Score (0-99, displayed as 0-9.9)
    public bool $inStock = true;
    public bool $isPrime = false;

    // === IMAGES ===
    public ?string $imageUrl = null;
    public ?array $imagesGallery = null;

    // === DESCRIPTION ===
    public ?string $description = null;
    public ?array $features = null;

    // === CATEGORY HIERARCHY ===
    public ?string $category = null;
    public ?string $categoryPath = null;
    public ?array $customCategoryPaths = null;

    // === SPECIFICATIONS ===
    public ?array $productInformation = null;
    public ?array $specifications = null;
    public ?string $bestSellersRank = null;

    // === SELLER INFO ===
    public ?array $sellerInfo = null;

    // === REVIEWS DATA ===
    public ?array $reviewsData = null;
    public ?array $topReviews = null;
    public ?array $reviewsSummary = null;

    // === CUSTOM OVERRIDES (user-defined content) ===
    public ?string $customTitle = null;
    public ?string $customDescription = null;
    public ?array $customFeatures = null;
    public ?array $customPros = null;
    public ?array $customCons = null;
    public ?array $customTabs = null;

    // === SCRAPE MANAGEMENT ===
    public string $status = 'pending';
    public ?string $lastProvider = null;
    public ?string $lastScrapedAt = null;
    public ?string $errorMessage = null;

    // === QUICK UPDATE TRACKING ===
    public ?string $quickUpdateAt = null;
    public int $quickUpdateCount = 0;

    // === AI CONTENT GENERATION ===
    public ?string $aiStatus = null;
    public ?string $aiGeneratedAt = null;
    public ?string $aiErrorMessage = null;

    // === AI-GENERATED CONTENT (separate from scraped/custom) ===
    public ?array $aiFeatures = null;
    public ?string $aiShortReview = null;
    public ?string $aiDescription = null;
    public ?string $aiGenerationId = null;

    // === CONTENT ASSOCIATIONS ===
    public ?int $sourcePostId = null;
    public ?string $postIds = null;
    public int $postCount = 0;

    // === TIMESTAMPS ===
    public ?string $createdAt = null;
    public ?string $updatedAt = null;

    /**
     * Create Product from array data
     *
     * @param array $data Product data array
     * @return self
     */
    public static function fromArray(array $data): self
    {
        $product = new self();

        // === PRIMARY ===
        $product->id = isset($data['id']) ? (int) $data['id'] : null;
        $product->asin = $data['asin'] ?? '';

        // === CORE PRODUCT INFO ===
        $product->title = $data['title'] ?? null;
        $product->brand = $data['brand'] ?? null;
        $product->price = isset($data['price']) ? (float) $data['price'] : null;
        $product->originalPrice = isset($data['original_price']) ? (float) $data['original_price'] : null;
        $product->currency = $data['currency'] ?? 'USD';
        $product->rating = isset($data['rating']) ? (float) $data['rating'] : null;
        $product->reviewsCount = (int) ($data['reviews_count'] ?? 0);
        $product->score = (int) ($data['score'] ?? 70);
        $product->inStock = (bool) ($data['in_stock'] ?? true);
        $product->isPrime = (bool) ($data['is_prime'] ?? false);

        // === IMAGES ===
        $product->imageUrl = $data['image_url'] ?? null;
        $product->imagesGallery = self::decodeJson($data['images_gallery'] ?? null);

        // === DESCRIPTION ===
        $product->description = $data['description'] ?? null;
        $product->features = self::decodeJson($data['features'] ?? null);

        // === CATEGORY HIERARCHY ===
        $product->category = $data['category'] ?? null;
        $product->categoryPath = $data['category_path'] ?? null;
        $product->customCategoryPaths = self::decodeJson($data['custom_category_paths'] ?? null);

        // === SPECIFICATIONS ===
        $product->productInformation = self::decodeJson($data['product_information'] ?? null);
        $product->specifications = self::decodeJson($data['specifications'] ?? null);
        $product->bestSellersRank = $data['best_sellers_rank'] ?? null;

        // === SELLER INFO ===
        $product->sellerInfo = self::decodeJson($data['seller_info'] ?? null);

        // === REVIEWS DATA ===
        $product->reviewsData = self::decodeJson($data['reviews_data'] ?? null);
        $product->topReviews = self::decodeJson($data['top_reviews'] ?? null);
        $product->reviewsSummary = self::decodeJson($data['reviews_summary'] ?? null);

        // === CUSTOM OVERRIDES ===
        $product->customTitle = $data['custom_title'] ?? null;
        $product->customDescription = $data['custom_description'] ?? null;
        $product->customFeatures = self::decodeJson($data['custom_features'] ?? null);
        $product->customPros = self::decodeJson($data['custom_pros'] ?? null);
        $product->customCons = self::decodeJson($data['custom_cons'] ?? null);
        $product->customTabs = self::decodeJson($data['custom_tabs'] ?? null);

        // === SCRAPE MANAGEMENT ===
        $product->status = $data['status'] ?? 'pending';
        $product->lastProvider = $data['last_provider'] ?? null;
        $product->lastScrapedAt = $data['last_scraped_at'] ?? null;
        $product->errorMessage = $data['error_message'] ?? null;

        // === QUICK UPDATE TRACKING ===
        $product->quickUpdateAt = $data['quick_update_at'] ?? null;
        $product->quickUpdateCount = (int) ($data['quick_update_count'] ?? 0);

        // === AI CONTENT GENERATION ===
        $product->aiStatus = $data['ai_status'] ?? null;
        $product->aiGeneratedAt = $data['ai_generated_at'] ?? null;
        $product->aiErrorMessage = $data['ai_error_message'] ?? null;

        // === AI-GENERATED CONTENT ===
        $product->aiFeatures = self::decodeJson($data['ai_features'] ?? null);
        $product->aiShortReview = $data['ai_short_review'] ?? null;
        $product->aiDescription = $data['ai_description'] ?? null;
        $product->aiGenerationId = $data['ai_generation_id'] ?? null;

        // === CONTENT ASSOCIATIONS ===
        $product->sourcePostId = isset($data['source_post_id']) ? (int) $data['source_post_id'] : null;
        $product->postIds = $data['post_ids'] ?? null;
        $product->postCount = (int) ($data['post_count'] ?? 0);

        // === TIMESTAMPS ===
        $product->createdAt = $data['created_at'] ?? null;
        $product->updatedAt = $data['updated_at'] ?? null;

        return $product;
    }

    /**
     * Create Product from database row object
     *
     * @param object $row Database row
     * @return self
     */
    public static function fromRow(object $row): self
    {
        return self::fromArray((array) $row);
    }

    /**
     * Convert Product to array for JSON response
     * Uses snake_case to match database columns and frontend expectations
     *
     * @return array
     */
    public function toArray(): array
    {
        return [
            'id' => $this->id,
            'asin' => $this->asin,

            // CORE
            'title' => $this->title,
            'brand' => $this->brand,
            'price' => $this->price,
            'original_price' => $this->originalPrice,
            'currency' => $this->currency,
            'rating' => $this->rating,
            'reviews_count' => $this->reviewsCount,
            'score' => $this->score,
            'in_stock' => $this->inStock,
            'is_prime' => $this->isPrime,

            // IMAGES
            'image_url' => $this->imageUrl,
            'images_gallery' => $this->imagesGallery,

            // DESCRIPTION
            'description' => $this->description,
            'features' => $this->features,

            // CATEGORY
            'category' => $this->category,
            'category_path' => $this->categoryPath,
            'custom_category_paths' => $this->customCategoryPaths,

            // SPECIFICATIONS
            'product_information' => $this->productInformation,
            'specifications' => $this->specifications,
            'best_sellers_rank' => $this->bestSellersRank,

            // SELLER INFO
            'seller_info' => $this->sellerInfo,

            // REVIEWS DATA
            'reviews_data' => $this->reviewsData,
            'top_reviews' => $this->topReviews,
            'reviews_summary' => $this->reviewsSummary,

            // CUSTOM OVERRIDES
            'custom_title' => $this->customTitle,
            'custom_description' => $this->customDescription,
            'custom_features' => $this->customFeatures,
            'custom_pros' => $this->customPros,
            'custom_cons' => $this->customCons,
            'custom_tabs' => $this->customTabs,

            // SCRAPE MANAGEMENT
            'status' => $this->status,
            'last_provider' => $this->lastProvider,
            'last_scraped_at' => $this->lastScrapedAt,
            'error_message' => $this->errorMessage,

            // QUICK UPDATE TRACKING
            'quick_update_at' => $this->quickUpdateAt,
            'quick_update_count' => $this->quickUpdateCount,

            // AI CONTENT GENERATION
            'ai_status' => $this->aiStatus,
            'ai_generated_at' => $this->aiGeneratedAt,
            'ai_error_message' => $this->aiErrorMessage,

            // AI-GENERATED CONTENT
            'ai_features' => $this->aiFeatures,
            'ai_short_review' => $this->aiShortReview,
            'ai_description' => $this->aiDescription,
            'ai_generation_id' => $this->aiGenerationId,

            // CONTENT ASSOCIATIONS
            'source_post_id' => $this->sourcePostId,
            'post_ids' => $this->postIds,
            'post_count' => $this->postCount,

            // TIMESTAMPS
            'created_at' => $this->createdAt,
            'updated_at' => $this->updatedAt,

            // COMPUTED
            'discount' => $this->getDiscount(),
            'affiliate_url' => $this->getAffiliateUrl(),
        ];
    }

    /**
     * Convert Product to array for database insert/update
     *
     * @return array
     */
    public function toDbArray(): array
    {
        return [
            'asin' => $this->asin,

            // CORE
            'title' => $this->title,
            'brand' => $this->brand,
            'price' => $this->price,
            'original_price' => $this->originalPrice,
            'currency' => $this->currency,
            'rating' => $this->rating,
            'reviews_count' => $this->reviewsCount,
            'score' => $this->score,
            'in_stock' => $this->inStock ? 1 : 0,
            'is_prime' => $this->isPrime ? 1 : 0,

            // IMAGES
            'image_url' => $this->imageUrl,
            'images_gallery' => $this->imagesGallery ? wp_json_encode($this->imagesGallery) : null,

            // DESCRIPTION
            'description' => $this->description,
            'features' => $this->features ? wp_json_encode($this->features) : null,

            // CATEGORY
            'category' => $this->category,
            'category_path' => $this->categoryPath,
            'product_information' => $this->productInformation ? wp_json_encode($this->productInformation) : null,
            'specifications' => $this->specifications ? wp_json_encode($this->specifications) : null,
            'best_sellers_rank' => $this->bestSellersRank,

            // SELLER INFO
            'seller_info' => $this->sellerInfo ? wp_json_encode($this->sellerInfo) : null,

            // REVIEWS DATA
            'reviews_data' => $this->reviewsData ? wp_json_encode($this->reviewsData) : null,
            'top_reviews' => $this->topReviews ? wp_json_encode($this->topReviews) : null,
            'reviews_summary' => $this->reviewsSummary ? wp_json_encode($this->reviewsSummary) : null,

            // CUSTOM OVERRIDES
            'custom_title' => $this->customTitle,
            'custom_description' => $this->customDescription,
            'custom_features' => $this->customFeatures ? wp_json_encode($this->customFeatures) : null,
            'custom_pros' => $this->customPros ? wp_json_encode($this->customPros) : null,
            'custom_cons' => $this->customCons ? wp_json_encode($this->customCons) : null,
            'custom_tabs' => $this->customTabs ? wp_json_encode($this->customTabs) : null,

            // SCRAPE MANAGEMENT
            'status' => $this->status,
            'last_provider' => $this->lastProvider,
            'last_scraped_at' => $this->lastScrapedAt,
            'error_message' => $this->errorMessage,

            // CONTENT ASSOCIATIONS
            'source_post_id' => $this->sourcePostId,
            'post_ids' => $this->postIds,
            'post_count' => $this->postCount,
        ];
    }

    /**
     * Calculate discount percentage
     *
     * @return int|null Discount percentage or null if no discount
     */
    public function getDiscount(): ?int
    {
        if (!$this->originalPrice || !$this->price || $this->originalPrice <= $this->price) {
            return null;
        }

        return (int) round((1 - $this->price / $this->originalPrice) * 100);
    }

    /**
     * Generate Amazon affiliate URL
     *
     * @param string|null $tag Affiliate tag (uses wp_option if not provided)
     * @return string Affiliate URL
     */
    public function getAffiliateUrl(?string $tag = null): string
    {
        if (!$tag) {
            // Primary: Display settings affiliate_tag
            $settings = get_option('acms_general_settings', []);
            if (!empty($settings['affiliate_tag'])) {
                $tag = $settings['affiliate_tag'];
            }
        }

        if (!$tag) {
            // Fallback: PA-API partner tag
            $tag = get_option('acms_paapi_partner_tag', '');
        }

        $url = "https://www.amazon.com/dp/{$this->asin}";

        if ($tag) {
            $url .= "?tag={$tag}";
        }

        return $url;
    }

    /**
     * Get primary image URL with optional size
     *
     * @param string $size Image size: 'small', 'medium', 'large'
     * @return string Image URL
     */
    public function getPrimaryImage(string $size = 'large'): string
    {
        if (!$this->imageUrl) {
            return '';
        }

        // Amazon image URLs can be resized by modifying the URL
        // Original format: https://m.media-amazon.com/images/I/XXXX._AC_SL1500_.jpg
        // Size modifiers: _SL75_, _SL160_, _SL500_, _SL1500_

        $sizeMap = [
            'small' => '_SL75_',
            'medium' => '_SL160_',
            'large' => '_SL500_',
        ];

        $sizeModifier = $sizeMap[$size] ?? '_SL500_';

        // Replace existing size modifier with requested size
        if (preg_match('/_SL\d+_/', $this->imageUrl)) {
            return preg_replace('/_SL\d+_/', $sizeModifier, $this->imageUrl);
        }

        return $this->imageUrl;
    }

    /**
     * Check if product needs update
     *
     * @param int $hoursThreshold Hours since last scrape
     * @return bool True if needs update
     */
    public function needsUpdate(int $hoursThreshold = 24): bool
    {
        if (!$this->lastScrapedAt) {
            return true;
        }

        // Use WordPress timezone for comparison
        // lastScrapedAt is stored in WordPress local time via current_time('mysql')
        $lastScraped = strtotime($this->lastScrapedAt);
        $threshold = current_time('timestamp') - ($hoursThreshold * 3600);

        return $lastScraped < $threshold;
    }

    /**
     * Check if product has been scraped successfully
     *
     * @return bool True if scraped
     */
    public function isScraped(): bool
    {
        return $this->status === 'scraped' && !empty($this->title);
    }

    /**
     * Check if product scrape failed
     *
     * @return bool True if failed
     */
    public function isFailed(): bool
    {
        return $this->status === 'failed';
    }

    /**
     * Get effective title (custom override or original)
     *
     * @return string|null
     */
    public function getEffectiveTitle(): ?string
    {
        return $this->customTitle ?? $this->title;
    }

    /**
     * Get effective description (custom override or original)
     *
     * @return string|null
     */
    public function getEffectiveDescription(): ?string
    {
        return $this->customDescription ?? $this->description;
    }

    /**
     * Get effective features (custom override or original)
     *
     * @return array|null
     */
    public function getEffectiveFeatures(): ?array
    {
        return $this->customFeatures ?? $this->features;
    }

    /**
     * Get pros list
     *
     * @return array|null
     */
    public function getPros(): ?array
    {
        return $this->customPros;
    }

    /**
     * Get cons list
     *
     * @return array|null
     */
    public function getCons(): ?array
    {
        return $this->customCons;
    }

    /**
     * Check if product has custom content
     *
     * @return bool
     */
    public function hasCustomContent(): bool
    {
        return $this->customTitle !== null
            || $this->customDescription !== null
            || $this->customFeatures !== null
            || $this->customPros !== null
            || $this->customCons !== null;
    }

    /**
     * Helper to decode JSON safely
     *
     * @param mixed $value Value to decode
     * @return array|null Decoded array or null
     */
    private static function decodeJson($value): ?array
    {
        if (empty($value)) {
            return null;
        }
        if (is_array($value)) {
            return $value;
        }
        if (is_string($value)) {
            $decoded = json_decode($value, true);
            return is_array($decoded) ? $decoded : null;
        }
        return null;
    }
}
