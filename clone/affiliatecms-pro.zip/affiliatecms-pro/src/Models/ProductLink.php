<?php
/**
 * ProductLink Model
 *
 * Data model for affiliate links from various providers (Walmart, Best Buy, etc.)
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro\Models;

class ProductLink
{
    // === PRIMARY ===
    public ?int $id = null;
    public int $productId = 0;

    // === PROVIDER INFO ===
    public string $provider = '';
    public string $providerName = '';

    // === LINK DETAILS ===
    public string $affiliateUrl = '';
    public ?float $price = null;
    public string $currency = 'USD';
    public ?bool $inStock = null;

    // === DISPLAY SETTINGS ===
    public bool $isPrimary = false;
    public int $sortOrder = 0;

    // === TIMESTAMPS ===
    public ?string $createdAt = null;
    public ?string $updatedAt = null;

    /**
     * Common provider definitions
     */
    public const PROVIDERS = [
        'amazon' => 'Amazon',
        'walmart' => 'Walmart',
        'bestbuy' => 'Best Buy',
        'target' => 'Target',
        'ebay' => 'eBay',
        'newegg' => 'Newegg',
        'costco' => 'Costco',
        'homedepot' => 'Home Depot',
        'lowes' => "Lowe's",
        'custom' => 'Custom',
    ];

    /**
     * Create ProductLink from array data
     *
     * @param array $data ProductLink data array
     * @return self
     */
    public static function fromArray(array $data): self
    {
        $link = new self();

        // === PRIMARY ===
        $link->id = isset($data['id']) ? (int) $data['id'] : null;
        $link->productId = (int) ($data['product_id'] ?? 0);

        // === PROVIDER INFO ===
        $link->provider = $data['provider'] ?? '';
        $link->providerName = $data['provider_name'] ?? '';

        // === LINK DETAILS ===
        $link->affiliateUrl = $data['affiliate_url'] ?? '';
        $link->price = isset($data['price']) ? (float) $data['price'] : null;
        $link->currency = $data['currency'] ?? 'USD';
        $link->inStock = isset($data['in_stock']) ? (bool) $data['in_stock'] : null;

        // === DISPLAY SETTINGS ===
        $link->isPrimary = (bool) ($data['is_primary'] ?? false);
        $link->sortOrder = (int) ($data['sort_order'] ?? 0);

        // === TIMESTAMPS ===
        $link->createdAt = $data['created_at'] ?? null;
        $link->updatedAt = $data['updated_at'] ?? null;

        return $link;
    }

    /**
     * Create ProductLink from database row object
     *
     * @param object $row Database row
     * @return self
     */
    public static function fromRow(object $row): self
    {
        return self::fromArray((array) $row);
    }

    /**
     * Convert ProductLink to array for JSON response
     *
     * @return array
     */
    public function toArray(): array
    {
        return [
            'id' => $this->id,
            'product_id' => $this->productId,
            'provider' => $this->provider,
            'provider_name' => $this->providerName,
            'affiliate_url' => $this->affiliateUrl,
            'price' => $this->price,
            'currency' => $this->currency,
            'in_stock' => $this->inStock,
            'is_primary' => $this->isPrimary,
            'sort_order' => $this->sortOrder,
            'created_at' => $this->createdAt,
            'updated_at' => $this->updatedAt,
        ];
    }

    /**
     * Convert ProductLink to array for database insert/update
     *
     * @return array
     */
    public function toDbArray(): array
    {
        return [
            'product_id' => $this->productId,
            'provider' => $this->provider,
            'provider_name' => $this->providerName,
            'affiliate_url' => $this->affiliateUrl,
            'price' => $this->price,
            'currency' => $this->currency,
            'in_stock' => $this->inStock !== null ? ($this->inStock ? 1 : 0) : null,
            'is_primary' => $this->isPrimary ? 1 : 0,
            'sort_order' => $this->sortOrder,
        ];
    }

    /**
     * Get display name for provider
     *
     * @return string
     */
    public function getProviderDisplayName(): string
    {
        if (!empty($this->providerName)) {
            return $this->providerName;
        }

        return self::PROVIDERS[$this->provider] ?? ucfirst($this->provider);
    }

    /**
     * Get formatted price
     *
     * @return string|null
     */
    public function getFormattedPrice(): ?string
    {
        if ($this->price === null) {
            return null;
        }

        $currencySymbols = [
            'USD' => '$',
            'EUR' => '€',
            'GBP' => '£',
            'JPY' => '¥',
        ];

        $symbol = $currencySymbols[$this->currency] ?? $this->currency . ' ';
        return $symbol . number_format($this->price, 2);
    }

    /**
     * Check if this is the Amazon link
     *
     * @return bool
     */
    public function isAmazon(): bool
    {
        return $this->provider === 'amazon';
    }

    /**
     * Get all available providers
     *
     * @return array
     */
    public static function getProviders(): array
    {
        return self::PROVIDERS;
    }
}
