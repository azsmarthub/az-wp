<?php
/**
 * SEO Date Modifier
 *
 * Modifies post dateModified based on latest product scrape time.
 * Integrates with Rank Math schema and provides theme helper functions.
 *
 * @package AffiliateCMS\Pro\Frontend
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro\Frontend;

use AffiliateCMS\Pro\Services\AsinDetector;
use AffiliateCMS\Pro\Database\Schema;

class SeoDateModifier
{
    private static ?SeoDateModifier $instance = null;

    /**
     * Cache for computed dates per post
     * @var array<int, string|null>
     */
    private array $cache = [];

    /**
     * Get singleton instance
     */
    public static function instance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Initialize hooks
     */
    public function init(): void
    {
        // Rank Math Article schema filter (runs after template placeholders)
        add_filter('rank_math/json_ld', [$this, 'modifySchemaDateModified'], 99, 2);
    }

    /**
     * Get effective modified date for a post
     *
     * Returns MAX(post_modified, latest_product_scrape_time)
     *
     * @param int|null $postId Post ID (defaults to current post)
     * @return string|null ISO 8601 datetime string or null if no products
     */
    public function getEffectiveModifiedDate(?int $postId = null): ?string
    {
        if ($postId === null) {
            $postId = get_the_ID();
        }

        if (!$postId) {
            return null;
        }

        // Check cache
        if (isset($this->cache[$postId])) {
            return $this->cache[$postId];
        }

        // Get post modified date
        $post = get_post($postId);
        if (!$post) {
            $this->cache[$postId] = null;
            return null;
        }

        $postModified = strtotime($post->post_modified_gmt);

        // Get latest product scrape time for this post
        $latestScrapeTime = $this->getLatestProductScrapeTime($postId);

        // Determine which is more recent
        if ($latestScrapeTime === null) {
            // No products found, use post modified date
            $this->cache[$postId] = gmdate('c', $postModified);
            return $this->cache[$postId];
        }

        $scrapeTimestamp = strtotime($latestScrapeTime);

        // Use the more recent of the two
        $effectiveTimestamp = max($postModified, $scrapeTimestamp);
        $this->cache[$postId] = gmdate('c', $effectiveTimestamp);

        return $this->cache[$postId];
    }

    /**
     * Get effective modified date formatted for display
     *
     * @param int|null $postId Post ID
     * @param string $format Date format (default: 'M j, Y')
     * @return string Formatted date
     */
    public function getEffectiveModifiedDateFormatted(?int $postId = null, string $format = 'M j, Y'): string
    {
        $isoDate = $this->getEffectiveModifiedDate($postId);

        if ($isoDate === null) {
            // Fallback to post modified date
            return get_the_modified_date($format, $postId);
        }

        $timestamp = strtotime($isoDate);
        return date_i18n($format, $timestamp);
    }

    /**
     * Get latest product scrape time from ASINs in post content
     *
     * @param int $postId Post ID
     * @return string|null MySQL datetime string or null
     */
    private function getLatestProductScrapeTime(int $postId): ?string
    {
        global $wpdb;

        // Get post content
        $post = get_post($postId);
        if (!$post || empty($post->post_content)) {
            return null;
        }

        // Extract ASINs from content
        $detector = AsinDetector::instance();
        $asins = $detector->extractAsins($post->post_content);

        if (empty($asins)) {
            return null;
        }

        // Query for latest scrape time
        $table = Schema::productsTable();
        $placeholders = implode(',', array_fill(0, count($asins), '%s'));

        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $query = $wpdb->prepare(
            "SELECT MAX(last_scraped_at) as latest_scrape
             FROM {$table}
             WHERE asin IN ({$placeholders})
             AND last_scraped_at IS NOT NULL
             AND status IN ('scraped','update','updating')",
            ...$asins
        );

        $result = $wpdb->get_var($query);

        return $result ?: null;
    }

    /**
     * Modify Rank Math schema dateModified
     *
     * @param array $data Schema data
     * @param object|null $jsonld JsonLD object
     * @return array Modified schema data
     */
    public function modifySchemaDateModified(array $data, $jsonld = null): array
    {
        if (empty($data) || !is_singular()) {
            return $data;
        }

        $postId = get_the_ID();
        if (!$postId) {
            return $data;
        }

        // Only process for supported post types
        $postType = get_post_type($postId);
        $supportedTypes = ['post', 'acms_reviews', 'acms_deals', 'acms_guides'];
        if (!in_array($postType, $supportedTypes, true)) {
            return $data;
        }

        // Get effective modified date
        $effectiveDate = $this->getEffectiveModifiedDate($postId);
        if ($effectiveDate === null) {
            return $data;
        }

        // Modify dateModified in @graph array
        if (isset($data['@graph']) && is_array($data['@graph'])) {
            foreach ($data['@graph'] as $key => $item) {
                if (!isset($item['@type'])) {
                    continue;
                }

                // Check for Article types
                $articleTypes = ['Article', 'BlogPosting', 'NewsArticle', 'WebPage'];
                $itemType = is_array($item['@type']) ? $item['@type'] : [$item['@type']];

                if (array_intersect($itemType, $articleTypes)) {
                    $data['@graph'][$key]['dateModified'] = $effectiveDate;
                }
            }
        }

        return $data;
    }

    /**
     * Clear cache for a specific post or all posts
     *
     * @param int|null $postId Post ID or null to clear all
     */
    public function clearCache(?int $postId = null): void
    {
        if ($postId === null) {
            $this->cache = [];
        } else {
            unset($this->cache[$postId]);
        }
    }
}

