<?php
/**
 * Frontend Shortcodes
 *
 * Product Display Shortcodes:
 * [acms_list asin="B0...,B1...,B2..."]        - Ranked product list
 *
 * @package AffiliateCMS\Pro\Frontend
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro\Frontend;

use AffiliateCMS\Pro\Core\Assets;
use AffiliateCMS\Pro\Database\Schema;
use AffiliateCMS\Pro\Services\SettingsManager;
use AffiliateCMS\Pro\Services\ScoreManager;

class Shortcodes
{
    private static ?Shortcodes $instance = null;

    public static function instance(): Shortcodes
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct()
    {
        // Private constructor for singleton
    }

    /**
     * Register all shortcodes
     */
    public function register(): void
    {
        add_shortcode('acms_list', [$this, 'productList']);
    }

    /**
     * [acms_list asin="B0...,B1...,B2..." tag="..." numbered="true"]
     * Ranked product list with horizontal cards
     */
    public function productList(array $atts): string
    {
        // Get default settings
        $settings = $this->getGeneralSettings();

        $atts = shortcode_atts([
            'asin' => '',
            'tag' => '',
            'numbered' => 'true',
            'class' => '',
            'max_width' => '900px',
            'show_badges' => 'true',
            'hide_disclaimer' => 'false',
            // Display settings from global settings
            'show_price' => $settings['show_price'] ?? true ? 'true' : 'false',
            'show_rating' => $settings['show_rating'] ?? true ? 'true' : 'false',
            'show_prime' => $settings['show_prime_badge'] ?? true ? 'true' : 'false',
            'show_stock' => $settings['show_stock_status'] ?? true ? 'true' : 'false',
            'show_image' => 'true',
            'rating_display_type' => 'score', // Always score — star rating disabled
            // Button text override
            'button_text' => '',
            // Score label and tooltip text (hardcoded in theme config.php)
            'score_label_text' => defined('ACMS_SCORE_LABEL') ? ACMS_SCORE_LABEL : __('Score', 'affiliatecms-pro'),
            'score_tooltip_text' => defined('ACMS_SCORE_TOOLTIP') ? ACMS_SCORE_TOOLTIP : __('Score is calculated based on product ratings, reviews, and sales performance to help you make informed purchasing decisions.', 'affiliatecms-pro'),
            // Update info settings (from DB settings, fallback to theme config.php)
            'show_update' => ($settings['show_update'] ?? (defined('ACMS_SHOW_UPDATE') ? ACMS_SHOW_UPDATE : true)) ? 'true' : 'false',
            'update_tooltip_text' => defined('ACMS_UPDATE_TOOLTIP') ? ACMS_UPDATE_TOOLTIP : __('Last update on {date} / Affiliate links / Images, Product Titles, and Product Highlights from Amazon Product Advertising API.', 'affiliatecms-pro'),
        ], $atts, 'acms_list');

        $asins = $this->parseAsins($atts['asin']);
        if (empty($asins)) {
            return $this->errorMessage(__('ASINs required', 'affiliatecms-pro'));
        }

        $products = $this->getProducts($asins);
        if (empty($products)) {
            return '';
        }

        // Force enqueue frontend assets
        Assets::forceEnqueueFrontendAssets();

        // Prepare products data
        $preparedProducts = [];

        foreach ($products as $product) {
            $prepared = $this->prepareProductData($product, $atts['tag']);

            // Description and features are no longer displayed (removed from Details Section)
            // Keep fields empty for backward compatibility
            $prepared['description'] = '';
            $prepared['features'] = [];

            // Override button_text if provided in shortcode
            if (!empty($atts['button_text'])) {
                $prepared['button_text'] = $atts['button_text'];
            }
            $preparedProducts[] = $prepared;
        }

        return $this->renderTemplate('list', [
            'products' => $preparedProducts,
            'atts' => $atts,
        ]);
    }

    /**
     * Columns fetched for frontend display.
     * Excludes heavy LONGTEXT fields never used by the shortcode template:
     * reviews_data, top_reviews, reviews_summary, product_information,
     * specifications, seller_info — these cut query payload by ~80%.
     * We keep: description + features for SEO schema/fallback display,
     * and all custom_* AI fields for content override.
     */
    private const DISPLAY_COLUMNS = 'id, asin, title, brand, category, price, original_price,
        currency, rating, reviews_count, score, in_stock, is_prime, image_url, images_gallery,
        status, last_scraped_at,
        description, features,
        custom_title, custom_description, custom_features, custom_pros, custom_cons, custom_tabs';

    /**
     * Get product by ASIN
     */
    private function getProduct(string $asin): ?array
    {
        global $wpdb;

        // Include statuses where products have valid data (processing/scheduled during rescrape, update/updating during price refresh)
        $product = $wpdb->get_row($wpdb->prepare(
            "SELECT " . self::DISPLAY_COLUMNS . " FROM " . Schema::productsTable() . " WHERE asin = %s AND status IN ('scraped', 'processing', 'scheduled', 'update', 'updating')",
            $asin
        ), ARRAY_A);

        return $product ?: null;
    }

    /**
     * Get multiple products by ASINs
     */
    private function getProducts(array $asins): array
    {
        global $wpdb;

        if (empty($asins)) {
            return [];
        }

        $placeholders = implode(',', array_fill(0, count($asins), '%s'));

        // Include statuses where products have valid data (processing/scheduled during rescrape, update/updating during price refresh)
        $products = $wpdb->get_results($wpdb->prepare(
            "SELECT " . self::DISPLAY_COLUMNS . " FROM " . Schema::productsTable() . " WHERE asin IN ($placeholders) AND status IN ('scraped', 'processing', 'scheduled', 'update', 'updating')",
            ...$asins
        ), ARRAY_A);

        // Decode only the JSON fields actually fetched by DISPLAY_COLUMNS.
        // Heavy fields (reviews_data, top_reviews, reviews_summary, product_information,
        // specifications, seller_info) are not selected so not listed here.
        $jsonFields = ['images_gallery', 'features', 'custom_features', 'custom_pros', 'custom_cons', 'custom_tabs'];
        foreach ($products as &$product) {
            foreach ($jsonFields as $field) {
                if (isset($product[$field]) && is_string($product[$field])) {
                    $decoded = json_decode($product[$field], true);
                    $product[$field] = $decoded !== null ? $decoded : null;
                }
            }
        }
        unset($product); // Break reference

        // Reorder products to match ASIN order
        $productMap = [];
        foreach ($products as $product) {
            $productMap[$product['asin']] = $product;
        }

        $orderedProducts = [];
        foreach ($asins as $asin) {
            if (isset($productMap[$asin])) {
                $orderedProducts[] = $productMap[$asin];
            }
        }

        return $orderedProducts;
    }

    /**
     * Parse comma-separated ASINs
     */
    private function parseAsins(string $asins): array
    {
        if (empty($asins)) {
            return [];
        }

        return array_filter(
            array_map(
                [$this, 'sanitizeAsin'],
                explode(',', $asins)
            )
        );
    }

    /**
     * Sanitize ASIN
     */
    private function sanitizeAsin(string $asin): string
    {
        return strtoupper(trim(preg_replace('/[^A-Za-z0-9]/', '', $asin)));
    }

    /**
     * Prepare product data for template
     */
    private function prepareProductData(array $product, string $tagOverride = ''): array
    {
        $asin = $product['asin'] ?? '';
        $price = isset($product['price']) ? (float) $product['price'] : null;
        $originalPrice = isset($product['original_price']) ? (float) $product['original_price'] : null;
        $currency = $product['currency'] ?? 'USD';

        // Parse images gallery
        $imagesGallery = [];
        if (!empty($product['images_gallery'])) {
            $gallery = is_string($product['images_gallery'])
                ? json_decode($product['images_gallery'], true)
                : $product['images_gallery'];
            if (is_array($gallery)) {
                $imagesGallery = $gallery;
            }
        }

        // Add main image if not in gallery
        if (!empty($product['image_url']) && !in_array($product['image_url'], $imagesGallery)) {
            array_unshift($imagesGallery, $product['image_url']);
        }

        // Parse scraped features
        $scrapedFeatures = [];
        if (!empty($product['features'])) {
            $featuresData = is_string($product['features'])
                ? json_decode($product['features'], true)
                : $product['features'];
            if (is_array($featuresData)) {
                $scrapedFeatures = $featuresData;
            }
        }

        // Parse custom features
        $customFeatures = [];
        if (!empty($product['custom_features'])) {
            $customFeaturesData = is_string($product['custom_features'])
                ? json_decode($product['custom_features'], true)
                : $product['custom_features'];
            if (is_array($customFeaturesData)) {
                $customFeatures = $customFeaturesData;
            }
        }

        // Parse custom pros
        $pros = [];
        if (!empty($product['custom_pros'])) {
            $prosData = is_string($product['custom_pros'])
                ? json_decode($product['custom_pros'], true)
                : $product['custom_pros'];
            if (is_array($prosData)) {
                $pros = $prosData;
            }
        }

        // Parse custom cons
        $cons = [];
        if (!empty($product['custom_cons'])) {
            $consData = is_string($product['custom_cons'])
                ? json_decode($product['custom_cons'], true)
                : $product['custom_cons'];
            if (is_array($consData)) {
                $cons = $consData;
            }
        }

        // Get custom and scraped description separately
        $customDescription = $product['custom_description'] ?? '';
        $scrapedDescription = $product['description'] ?? '';

        // Calculate discount
        $discountPercent = 0;
        $savingsAmount = 0;
        if ($originalPrice && $price && $originalPrice > $price) {
            $discountPercent = (int) round((1 - $price / $originalPrice) * 100);
            $savingsAmount = $originalPrice - $price;
        }

        // Get settings for button display
        $settings = $this->getGeneralSettings();

        // Get custom affiliate links for this product
        $productId = isset($product['id']) ? (int) $product['id'] : 0;
        $affiliateLinks = $productId ? $this->getProductLinks($productId) : [];

        // Title: custom_title overrides scraped title
        $title = !empty($product['custom_title']) ? $product['custom_title'] : ($product['title'] ?? '');

        return [
            'asin' => $asin,
            'title' => $title,
            'brand' => $product['brand'] ?? '',
            'category' => $product['category'] ?? '',
            'price' => $price,
            'original_price' => $originalPrice,
            'currency' => $currency,
            'price_formatted' => $this->formatPrice($price, $currency),
            'original_price_formatted' => $this->formatPrice($originalPrice, $currency),
            'discount_percent' => $discountPercent,
            'savings_amount' => $savingsAmount,
            'savings_formatted' => $this->formatPrice($savingsAmount, $currency),
            'rating' => isset($product['rating']) ? (float) $product['rating'] : 0,
            'reviews_count' => isset($product['reviews_count']) ? (int) $product['reviews_count'] : 0,
            'reviews_formatted' => $this->formatReviewsCount((int) ($product['reviews_count'] ?? 0)),
            'in_stock' => (bool) ($product['in_stock'] ?? true),
            'is_prime' => (bool) ($product['is_prime'] ?? false),
            'image_url' => $product['image_url'] ?? '',
            'images_gallery' => $imagesGallery,
            // Custom and scraped data (separate for fallback logic)
            'custom_description' => $customDescription,
            'scraped_description' => $scrapedDescription,
            'custom_features' => $customFeatures,
            'scraped_features' => $scrapedFeatures,
            // Pros/Cons (custom only, no scraped equivalent)
            'pros' => $pros,
            'cons' => $cons,
            // Custom tabs (array of {title, content, icon})
            'custom_tabs' => $product['custom_tabs'] ?? null,
            'score' => isset($product['score']) ? (int) $product['score'] : 0,
            'score_formatted' => isset($product['score']) ? ScoreManager::instance()->formatScore((int) $product['score']) : '0.0',
            'affiliate_url' => $this->getAffiliateLink($asin, $tagOverride),
            'link_rel' => $this->getLinkRelAttribute(),
            'last_updated' => $this->getRelativeTime($product['last_scraped_at'] ?? null),
            'last_updated_detailed' => $this->getDetailedTime($product['last_scraped_at'] ?? null),
            'merchant' => 'amazon.com',
            // Button display settings
            'button_text' => $settings['button_text'] ?? __('View on Amazon', 'affiliatecms-pro'),
            // Custom affiliate links from product_links table
            'affiliate_links' => $affiliateLinks,
        ];
    }

    /**
     * Format price with currency symbol
     */
    private function formatPrice(?float $price, string $currency = 'USD'): string
    {
        if ($price === null) {
            return '';
        }

        $symbols = [
            'USD' => '$',
            'EUR' => '€',
            'GBP' => '£',
            'JPY' => '¥',
            'CAD' => 'CA$',
            'AUD' => 'A$',
            'INR' => '₹',
            'BRL' => 'R$',
            'MXN' => 'MX$',
        ];

        $symbol = $symbols[$currency] ?? '$';
        return $symbol . number_format($price, 2);
    }

    /**
     * Format reviews count (e.g., 5200 -> 5.2K)
     */
    private function formatReviewsCount(int $count): string
    {
        if ($count >= 1000000) {
            return number_format($count / 1000000, 1) . 'M';
        }
        if ($count >= 1000) {
            return number_format($count / 1000, 1) . 'K';
        }
        return (string) $count;
    }

    /**
     * Get Amazon affiliate link with optional UTM parameters
     */
    private function getAffiliateLink(string $asin, string $tagOverride = ''): string
    {
        $tag = !empty($tagOverride) ? $tagOverride : $this->getAffiliateTag();
        $settings = $this->getGeneralSettings();

        $url = "https://www.amazon.com/dp/{$asin}";
        $params = [];

        // Add affiliate tag
        if (!empty($tag)) {
            $params['tag'] = $tag;
        }

        // Add custom URL parameters (e.g. linkCode=ogi&th=1&psc=1)
        $customParams = '';
        if (!empty($settings['custom_url_params'])) {
            $customParams = ltrim($settings['custom_url_params'], '&');
        }

        // Add UTM parameters if enabled
        if (!empty($settings['enable_utm'])) {
            $utmSource = !empty($settings['utm_source']) ? $settings['utm_source'] : $this->getSiteName();
            $utmMedium = !empty($settings['utm_medium']) ? $settings['utm_medium'] : 'affiliate';
            $params['utm_source'] = $utmSource;
            $params['utm_medium'] = $utmMedium;

            // Use current post slug as campaign
            $postSlug = $this->getCurrentPostSlug();
            if (!empty($postSlug)) {
                $params['utm_campaign'] = $postSlug;
            }

            // Add ASIN as content identifier
            $params['utm_content'] = $asin;
        }

        if (!empty($params)) {
            $url .= '?' . http_build_query($params);
        }

        // Append custom params (kept raw to preserve exact user-specified format)
        if (!empty($customParams)) {
            $url .= (strpos($url, '?') !== false ? '&' : '?') . $customParams;
        }

        // Wrap through redirect if enabled
        if (!empty($settings['redirect_enabled'])) {
            $slug = $settings['redirect_slug'] ?? 'go';
            $redirect_url = home_url('/' . $slug . '/?url=' . urlencode($url));

            // Add Cloudflare parameter if configured
            $cfParam = $settings['cf_param'] ?? '';
            if (!empty($cfParam)) {
                $redirect_url .= '&' . $cfParam;
            }

            return $redirect_url;
        }

        return $url;
    }

    /**
     * Get current post slug for UTM campaign
     */
    private function getCurrentPostSlug(): string
    {
        global $post;

        if ($post && !empty($post->post_name)) {
            return $post->post_name;
        }

        return '';
    }

    /**
     * Get site name for UTM source
     */
    private function getSiteName(): string
    {
        $siteName = get_bloginfo('name');
        // Convert to URL-safe slug
        return sanitize_title($siteName);
    }

    /**
     * Get general settings
     */
    private function getGeneralSettings(): array
    {
        static $settings = null;

        if ($settings === null) {
            $settings = get_option('acms_general_settings', []);
        }

        return $settings;
    }

    /**
     * Get affiliate tag from settings
     * Priority: Display settings affiliate_tag > PA-API partner_tag > legacy fallbacks
     */
    private function getAffiliateTag(): string
    {
        // Primary: Display settings affiliate_tag (separate from PA-API)
        $settings = $this->getGeneralSettings();
        if (!empty($settings['affiliate_tag'])) {
            return $settings['affiliate_tag'];
        }

        // Fallback: PA-API Partner Tag
        $paapiTag = get_option('acms_paapi_partner_tag', '');
        if (!empty($paapiTag)) {
            return $paapiTag;
        }

        // Legacy fallback
        return get_option('acms_affiliate_tag', '');
    }

    /**
     * Get link rel attribute based on settings
     */
    private function getLinkRelAttribute(): string
    {
        $settings = $this->getGeneralSettings();

        // Use new settings or fall back to legacy
        $nofollow = $settings['nofollow_links'] ?? get_option('acms_link_nofollow', true);

        // Only return 'nofollow' if enabled, nothing else
        return $nofollow ? 'nofollow' : '';
    }

    /**
     * Get custom affiliate links for a product (with redirect wrapping)
     */
    private function getProductLinks(int $productId): array
    {
        global $wpdb;

        $table = Schema::productLinksTable();
        $links = $wpdb->get_results($wpdb->prepare(
            "SELECT provider, provider_name, affiliate_url, is_primary FROM {$table} WHERE product_id = %d ORDER BY sort_order ASC, is_primary DESC",
            $productId
        ), ARRAY_A);

        if (empty($links)) {
            return [];
        }

        // Wrap affiliate URLs through redirect if enabled
        $settings = $this->getGeneralSettings();
        if (!empty($settings['redirect_enabled'])) {
            $slug = $settings['redirect_slug'] ?? 'go';
            $cfParam = $settings['cf_param'] ?? '';

            foreach ($links as &$link) {
                if (!empty($link['affiliate_url'])) {
                    $redirect_url = home_url('/' . $slug . '/?url=' . urlencode($link['affiliate_url']));
                    if (!empty($cfParam)) {
                        $redirect_url .= '&' . $cfParam;
                    }
                    $link['affiliate_url'] = $redirect_url;
                }
            }
            unset($link);
        }

        return $links;
    }

    /**
     * Get relative time string
     */
    private function getRelativeTime(?string $datetime): string
    {
        if (empty($datetime)) {
            return __('never', 'affiliatecms-pro');
        }

        // Use WordPress timezone for time comparison
        // datetime is stored in WordPress local time via current_time('mysql')
        $timestamp = strtotime($datetime);
        $diff = current_time('timestamp') - $timestamp;

        if ($diff < 60) {
            return __('just now', 'affiliatecms-pro');
        }
        if ($diff < 3600) {
            $mins = floor($diff / 60);
            return sprintf(_n('%d min ago', '%d mins ago', $mins, 'affiliatecms-pro'), $mins);
        }
        if ($diff < 86400) {
            $hours = floor($diff / 3600);
            return sprintf(_n('%d hour ago', '%d hours ago', $hours, 'affiliatecms-pro'), $hours);
        }
        if ($diff < 604800) {
            $days = floor($diff / 86400);
            return sprintf(_n('%d day ago', '%d days ago', $days, 'affiliatecms-pro'), $days);
        }

        return date_i18n(get_option('date_format'), $timestamp);
    }

    /**
     * Get detailed datetime string
     */
    private function getDetailedTime(?string $datetime): string
    {
        if (empty($datetime)) {
            return '';
        }

        $timestamp = strtotime($datetime);
        return date_i18n('M j, Y', $timestamp);
    }

    /**
     * Render template with data
     */
    private function renderTemplate(string $template, array $data): string
    {
        $templatePath = ACMS_PLUGIN_DIR . "templates/frontend/{$template}.php";

        if (!file_exists($templatePath)) {
            return $this->errorMessage(sprintf(__('Template not found: %s', 'affiliatecms-pro'), $template));
        }

        // Extract variables for template
        extract($data);

        ob_start();
        include $templatePath;
        return ob_get_clean();
    }

    /**
     * Display error message (admin only)
     */
    private function errorMessage(string $message): string
    {
        if (!current_user_can('manage_options')) {
            return '';
        }

        return sprintf(
            '<div class="acms-error" style="padding: 10px; background: #fee; border: 1px solid #c00; border-radius: 4px; color: #c00; font-style: italic;">[ACMS Error: %s]</div>',
            esc_html($message)
        );
    }
}
