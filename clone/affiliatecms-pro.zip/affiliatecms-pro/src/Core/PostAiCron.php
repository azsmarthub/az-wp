<?php
/**
 * Post AI Content Generation Cron Job
 *
 * Continuously finds queue items ready for AI post generation and processes them.
 * Runs every 15 minutes to find queue items with:
 * - status = 'completed' (keyword has linked ASINs)
 * - ai_post_status = 'queued' (automatically set when queue completes)
 * - At least 80% of linked products are scraped (raw data available)
 *
 * This is part of the 3-tier AI generation system:
 * 1. ProductAiCron - Product content (custom_title, custom_description, pros/cons)
 * 2. PostAiCron - Review post generation from keywords
 * 3. CategoryAiCron - Category content generation (affiliatecms-cat)
 *
 * NOTE: Uses RAW scraped data (title, features, specs, reviews) for AI generation.
 * Does NOT wait for Product AI (custom_title, etc.) - raw data is sufficient.
 *
 * Output:
 * - Creates WordPress posts (acms_reviews post type)
 * - Post title, content, excerpt
 * - SEO meta (title, description)
 * - Links to products via ASINs
 *
 * Performance optimizations:
 * - Uses composite index (status, ai_post_status) for fast queries
 * - Processes in small batches (3 posts per run)
 * - Skips items where products aren't scraped yet (will retry later)
 *
 * @package AffiliateCMS\Pro\Core
 * @see docs/ai-generation-architecture.md
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro\Core;

use AffiliateCMS\Pro\Database\Schema;
use AffiliateCMS\Pro\Repositories\ProductRepository;

class PostAiCron
{
    /**
     * Hook name for the cron job
     */
    public const CRON_HOOK = 'acms_post_ai_generation';

    /**
     * Queue items to process per run
     */
    private const BATCH_SIZE = 3;

    /**
     * Singleton instance
     */
    private static ?PostAiCron $instance = null;

    private ProductRepository $productRepo;

    /**
     * Get singleton instance
     */
    public static function instance(): PostAiCron
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Private constructor for singleton
     */
    private function __construct()
    {
        $this->productRepo = ProductRepository::instance();
    }

    /**
     * Register the cron job
     */
    public function register(): void
    {
        add_action(self::CRON_HOOK, [$this, 'generatePosts']);

        // WP-Cron as safety net (server cron is primary)
        if (!wp_next_scheduled(self::CRON_HOOK)) {
            wp_schedule_event(time(), 'every_15_minutes', self::CRON_HOOK);
        }
    }

    /**
     * Generate AI posts for queue items that are ready
     *
     * This runs every 15 minutes and finds queue items with:
     * - ai_post_status = 'queued' (automatically set when queue completes)
     * - At least 80% of linked products are scraped (raw data available)
     */
    public function generatePosts(): void
    {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[ACMS PostAiCron] Starting post AI generation');
        }

        // Get queue items ready for AI generation
        $queueItems = $this->getQueueItemsNeedingAiPost();

        if (empty($queueItems)) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('[ACMS PostAiCron] No queue items need AI post generation');
            }
            return;
        }

        $generatedCount = 0;
        $failedCount = 0;

        foreach ($queueItems as $item) {
            try {
                $success = $this->generatePostForQueueItem($item);
                if ($success) {
                    $generatedCount++;
                } else {
                    $failedCount++;
                }
            } catch (\Exception $e) {
                $failedCount++;
                error_log("[ACMS PostAiCron] Error generating post for queue item {$item->id}: " . $e->getMessage());

                // Mark as failed with error message
                $this->updateQueueItem((int) $item->id, [
                    'ai_post_status' => 'failed',
                    'ai_post_error' => $e->getMessage(),
                ]);
            }

            // Delay between posts to avoid rate limiting
            usleep(1000000); // 1 second
        }

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("[ACMS PostAiCron] Completed. Generated: {$generatedCount}, Failed: {$failedCount}");
        }
    }

    /**
     * Get queue items that need AI post generation
     *
     * Uses composite index (status, ai_post_status) for efficient query.
     * ScrapeMonitorCron sets ai_post_status = 'queued' when products are ready.
     *
     * @return array Queue item objects
     */
    private function getQueueItemsNeedingAiPost(): array
    {
        global $wpdb;
        $queueTable = $wpdb->prefix . 'acms_queue';

        // Find queue items that:
        // 1. Have ai_post_status = 'queued' (set by ScrapeMonitorCron when ready)
        // 2. Have linked ASINs
        // ScrapeMonitorCron already verified products have AI content (80% threshold)
        $sql = $wpdb->prepare(
            "SELECT q.* FROM {$queueTable} q
             WHERE q.ai_post_status = 'queued'
             AND q.linked_asins IS NOT NULL
             AND JSON_LENGTH(q.linked_asins) > 0
             ORDER BY q.id ASC
             LIMIT %d",
            self::BATCH_SIZE
        );

        $rows = $wpdb->get_results($sql);

        return $rows ?: [];
    }

    /**
     * Scrape readiness threshold (percentage of products that must be scraped)
     */
    private const SCRAPE_THRESHOLD = 80;

    /**
     * Generate AI post for a single queue item
     *
     * Checks if products are scraped before generating.
     * Uses raw scraped data (title, features, specs, reviews) for AI.
     * If not enough products are scraped (< threshold), skips without failing.
     *
     * @param object $item Queue item
     * @return bool True if generated/skipped successfully, false on error
     */
    private function generatePostForQueueItem(object $item): bool
    {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("[ACMS PostAiCron] Checking queue item ID: {$item->id} (Keyword: {$item->keyword})");
        }

        // Get linked ASINs (may already be array if WordPress auto-decoded JSON)
        $asins = is_array($item->linked_asins)
            ? $item->linked_asins
            : json_decode($item->linked_asins, true);
        if (empty($asins)) {
            throw new \Exception('No linked ASINs found');
        }

        $totalAsins = count($asins);
        $scrapedProducts = [];

        // Get scraped products (raw data is sufficient for AI)
        foreach ($asins as $asin) {
            $product = $this->productRepo->findByAsin($asin);
            if ($product && $product->status === 'scraped') {
                $scrapedProducts[] = $product;
            }
        }

        $scrapedCount = count($scrapedProducts);
        $scrapeProgress = $totalAsins > 0 ? round(($scrapedCount / $totalAsins) * 100) : 0;

        // Check if enough products are scraped
        if ($scrapeProgress < self::SCRAPE_THRESHOLD) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("[ACMS PostAiCron] Queue #{$item->id}: Waiting for scrape ({$scrapeProgress}% < " . self::SCRAPE_THRESHOLD . "%)");
            }
            // Don't change status - will retry on next cron run
            return true; // Return true to not count as failure
        }

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("[ACMS PostAiCron] Queue #{$item->id}: Products scraped ({$scrapeProgress}%), generating post...");
        }

        // Mark as generating
        $this->updateQueueItem((int) $item->id, [
            'ai_post_status' => 'generating',
        ]);

        // 1. Prepare rich product data for AI prompt
        $productsData = $this->prepareProductsData($scrapedProducts);

        // 2. Get related posts for internal linking (~30 posts)
        $relatedPosts = $this->getRelatedPosts($item);

        // 3. Get category info
        $categoryName = '';
        $categoryPath = '';
        if (!empty($item->category_id)) {
            $categoryInfo = $this->getCategoryInfo((int) $item->category_id);
            $categoryName = $categoryInfo['name'] ?? '';
            $categoryPath = $categoryInfo['path'] ?? '';
        }

        // Check if post already exists (created by template)
        $postId = $item->generated_post_id ?? null;
        if (empty($postId)) {
            throw new \Exception('No generated_post_id found - template must create post first');
        }

        // Verify post exists
        $post = get_post($postId);
        if (!$post) {
            throw new \Exception("Post #{$postId} not found");
        }

        // Get current post content for context
        $currentTitle = $post->post_title;
        $currentContent = $post->post_content;
        $currentExcerpt = $post->post_excerpt;

        // 4. Create AI job in acms_ai_jobs table
        $inputData = [
            'queue_id' => (int) $item->id,
            'post_id' => (int) $postId, // Existing post to optimize
            'keyword' => $item->keyword,
            'current_title' => $currentTitle,
            'current_content' => $currentContent,
            'current_excerpt' => $currentExcerpt,
            'products' => $productsData,
            'products_count' => count($productsData),
            'related_posts' => $relatedPosts,
            'related_posts_count' => count($relatedPosts),
            'category_name' => $categoryName,
            'category_path' => $categoryPath,
            'brand_id' => $item->brand_id ?? null,
            'post_type' => $item->post_type ?? 'acms_reviews',
        ];

        $jobCreated = $this->createAiJob($inputData);

        if (!$jobCreated) {
            // Failed to create job, reset status
            $this->updateQueueItem((int) $item->id, [
                'ai_post_status' => 'queued',
            ]);
            throw new \Exception('Failed to create AI job');
        }

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("[ACMS PostAiCron] Created AI job for queue item {$item->id} (keyword: {$item->keyword})");
        }

        return true;
    }

    /**
     * Unschedule the cron job
     */
    public function unschedule(): void
    {
        $timestamp = wp_next_scheduled(self::CRON_HOOK);
        if ($timestamp) {
            wp_unschedule_event($timestamp, self::CRON_HOOK);
        }
    }

    /**
     * Run the generation manually (for testing or manual trigger)
     *
     * @return array Result with count of processed items
     */
    public function runManually(): array
    {
        $startTime = microtime(true);

        ob_start();
        $this->generatePosts();
        $output = ob_get_clean();

        $duration = round((microtime(true) - $startTime) * 1000);

        return [
            'success' => true,
            'message' => 'Post AI generation completed',
            'duration_ms' => $duration,
            'log' => $output,
        ];
    }

    /**
     * Get next scheduled run time
     *
     * @return int|false Unix timestamp or false if not scheduled
     */
    public function getNextRun()
    {
        return wp_next_scheduled(self::CRON_HOOK);
    }

    /**
     * Get statistics about queue items needing AI posts
     *
     * @return array Statistics
     */
    public function getStats(): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'acms_queue';

        // Count completed queue items pending AI (includes legacy 'not_generated' and new 'queued')
        $pending = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$table}
             WHERE status = 'completed'
             AND (ai_post_status IS NULL OR ai_post_status = 'not_generated' OR ai_post_status = 'queued')"
        );

        $queued = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$table}
             WHERE status = 'completed' AND ai_post_status = 'queued'"
        );

        $generating = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$table} WHERE ai_post_status = 'generating'"
        );

        $generated = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$table} WHERE ai_post_status = 'generated'"
        );

        $failed = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$table} WHERE ai_post_status = 'failed'"
        );

        return [
            'pending' => (int) $pending, // Total waiting for AI (queued + legacy not_generated)
            'queued' => (int) $queued,   // Ready for AI processing
            'generating' => (int) $generating,
            'generated' => (int) $generated,
            'failed' => (int) $failed,
            'total_completed' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE status = 'completed'"),
            'next_run' => $this->getNextRun(),
            'batch_size' => self::BATCH_SIZE,
        ];
    }

    /**
     * Update a queue item in the database
     *
     * @param int $id Queue item ID
     * @param array $data Data to update
     * @return bool True if updated successfully
     */
    private function updateQueueItem(int $id, array $data): bool
    {
        global $wpdb;
        $table = Schema::queueTable();

        $result = $wpdb->update($table, $data, ['id' => $id]);

        return $result !== false;
    }

    /**
     * Prepare product data for AI prompt
     *
     * Extracts key information from scraped products:
     * - title, brand, price, rating
     * - pros, cons, short_review (if AI-generated)
     * - features (raw scraped data)
     *
     * @param array $products Array of product objects
     * @return array Formatted product data
     */
    private function prepareProductsData(array $products): array
    {
        $productsData = [];

        foreach ($products as $product) {
            // Parse JSON fields (may already be decoded by WordPress/PDO)
            $features = [];
            if (!empty($product->features)) {
                $features = is_array($product->features)
                    ? $product->features
                    : (json_decode($product->features, true) ?: []);
            }

            $specs = [];
            if (!empty($product->specifications)) {
                $specs = is_array($product->specifications)
                    ? $product->specifications
                    : (json_decode($product->specifications, true) ?: []);
            }

            $pros = [];
            if (!empty($product->pros)) {
                $pros = is_array($product->pros)
                    ? $product->pros
                    : (json_decode($product->pros, true) ?: []);
            }

            $cons = [];
            if (!empty($product->cons)) {
                $cons = is_array($product->cons)
                    ? $product->cons
                    : (json_decode($product->cons, true) ?: []);
            }

            $productsData[] = [
                'asin' => $product->asin,
                'title' => $product->title ?? '',
                'brand' => $product->brand ?? '',
                'price' => $product->price ?? '',
                'rating' => $product->rating ?? '',
                'reviews_count' => $product->reviews_count ?? 0,
                'features' => array_slice($features, 0, 10), // Limit to 10 features
                'specs' => array_slice($specs, 0, 10), // Limit to 10 specs
                'pros' => $pros,
                'cons' => $cons,
                'short_review' => $product->ai_short_review ?? '',
                'custom_title' => $product->custom_title ?? '',
                'custom_description' => $product->custom_description ?? '',
            ];
        }

        return $productsData;
    }

    /**
     * Get related posts for internal linking
     *
     * Returns ~30 posts that are related to the queue item:
     * - Posts in the same category (if category_id is set)
     * - Posts with similar keywords
     *
     * @param object $item Queue item
     * @return array Array of related posts with id, title, url
     */
    private function getRelatedPosts(object $item): array
    {
        $relatedPosts = [];
        $limit = 30;

        // Get posts from the same category
        if (!empty($item->category_id)) {
            $categoryPosts = get_posts([
                'post_type' => 'acms_reviews',
                'post_status' => 'publish',
                'posts_per_page' => 20,
                'orderby' => 'date',
                'order' => 'DESC',
                'tax_query' => [
                    [
                        'taxonomy' => 'category',
                        'field' => 'term_id',
                        'terms' => (int) $item->category_id,
                    ],
                ],
            ]);

            foreach ($categoryPosts as $post) {
                $relatedPosts[$post->ID] = [
                    'id' => $post->ID,
                    'title' => $post->post_title,
                    'url' => get_permalink($post->ID),
                ];
            }
        }

        // If we don't have enough posts, search by keyword similarity
        if (count($relatedPosts) < $limit && !empty($item->keyword)) {
            // Extract main words from keyword for search
            $keywords = explode(' ', $item->keyword);
            $searchTerms = array_slice($keywords, 0, 3); // Use first 3 words

            foreach ($searchTerms as $term) {
                if (strlen($term) < 3) {
                    continue;
                }

                $similarPosts = get_posts([
                    'post_type' => 'acms_reviews',
                    'post_status' => 'publish',
                    'posts_per_page' => 15,
                    's' => $term,
                    'orderby' => 'relevance',
                ]);

                foreach ($similarPosts as $post) {
                    if (!isset($relatedPosts[$post->ID])) {
                        $relatedPosts[$post->ID] = [
                            'id' => $post->ID,
                            'title' => $post->post_title,
                            'url' => get_permalink($post->ID),
                        ];
                    }

                    if (count($relatedPosts) >= $limit) {
                        break 2;
                    }
                }
            }
        }

        // If still not enough, get recent posts of same type
        if (count($relatedPosts) < 10) {
            $recentPosts = get_posts([
                'post_type' => 'acms_reviews',
                'post_status' => 'publish',
                'posts_per_page' => 15,
                'orderby' => 'date',
                'order' => 'DESC',
            ]);

            foreach ($recentPosts as $post) {
                if (!isset($relatedPosts[$post->ID])) {
                    $relatedPosts[$post->ID] = [
                        'id' => $post->ID,
                        'title' => $post->post_title,
                        'url' => get_permalink($post->ID),
                    ];
                }

                if (count($relatedPosts) >= $limit) {
                    break;
                }
            }
        }

        return array_values($relatedPosts);
    }

    /**
     * Get category information
     *
     * @param int $categoryId Category ID
     * @return array Category info with name and path
     */
    private function getCategoryInfo(int $categoryId): array
    {
        // Try to get from acms_categories table first (custom categories)
        if (class_exists(\AffiliateCMS\Categories\Repositories\CategoryRepository::class)) {
            $categoryRepo = new \AffiliateCMS\Categories\Repositories\CategoryRepository();
            $category = $categoryRepo->find($categoryId);

            if ($category) {
                // Build path from parent chain
                $path = $category['name'];
                if (!empty($category['parent_id'])) {
                    $ancestors = $categoryRepo->getAncestors($categoryId);
                    if (!empty($ancestors)) {
                        $ancestorNames = array_column($ancestors, 'name');
                        $path = implode(' > ', $ancestorNames) . ' > ' . $category['name'];
                    }
                }

                return [
                    'name' => $category['name'],
                    'path' => $path,
                ];
            }
        }

        // Fallback to WordPress category
        $term = get_term($categoryId, 'category');
        if ($term && !is_wp_error($term)) {
            $path = $term->name;
            $ancestors = get_ancestors($categoryId, 'category');
            if (!empty($ancestors)) {
                $ancestorNames = [];
                foreach (array_reverse($ancestors) as $ancestorId) {
                    $ancestor = get_term($ancestorId, 'category');
                    if ($ancestor && !is_wp_error($ancestor)) {
                        $ancestorNames[] = $ancestor->name;
                    }
                }
                $path = implode(' > ', $ancestorNames) . ' > ' . $term->name;
            }

            return [
                'name' => $term->name,
                'path' => $path,
            ];
        }

        return ['name' => '', 'path' => ''];
    }

    /**
     * Create AI job in acms_ai_jobs table
     *
     * @param array $inputData Job input data
     * @return bool True if job created successfully
     */
    private function createAiJob(array $inputData): bool
    {
        global $wpdb;
        $jobsTable = $wpdb->prefix . 'acms_ai_jobs';

        // Check if jobs table exists
        $tableExists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $jobsTable));
        if ($tableExists !== $jobsTable) {
            error_log('[ACMS PostAiCron] AI jobs table does not exist. Is affiliatecms-ai plugin active?');
            return false;
        }

        $inserted = $wpdb->insert($jobsTable, [
            'type' => 'optimize_review',
            'status' => 'pending',
            'priority' => 50, // Higher priority than category/brand AI
            'target_type' => 'queue_item',
            'target_id' => (string) $inputData['queue_id'],
            'input_data' => wp_json_encode($inputData),
            'created_at' => current_time('mysql'),
        ]);

        if (!$inserted) {
            error_log("[ACMS PostAiCron] Failed to create AI job: " . $wpdb->last_error);
            return false;
        }

        return true;
    }
}
