<?php
/**
 * Queue Processor
 *
 * Handles step-by-step processing of queue items with detailed logging.
 * Each queue item goes through these steps:
 * 1. Initialize - Set status to processing
 * 2. Search ASINs - Find products from Amazon, save basic info to Products table (status=pending)
 * 3. Generate Content - Create article with template + shortcodes
 * 4. Create Post - Insert WordPress post
 * 5. Finalize - Mark as completed
 *
 * Note: Product scraping is done separately in the Products page (async/manual).
 * Shortcodes render products based on available data in the database.
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro\Core;

use AffiliateCMS\Pro\Core\TemplatePlaceholders;
use AffiliateCMS\Pro\Database\Schema;
use AffiliateCMS\Pro\Repositories\ProductRepository;
use AffiliateCMS\Pro\Services\SearchService;

class QueueProcessor
{
    /**
     * Processing steps in order
     */
    private const STEPS = [
        'init',
        'search_asins',
        'generate_content',
        'create_post',
        'finalize'
    ];

    /**
     * Current queue item ID
     */
    private int $queueId = 0;

    /**
     * Current queue item data
     */
    private array $item = [];

    /**
     * Content settings from JSON
     */
    private array $settings = [];

    /**
     * Processing log entries
     */
    private array $log = [];

    /**
     * Errors encountered
     */
    private array $errors = [];

    /**
     * Current step index
     */
    private int $currentStepIndex = 0;

    /**
     * Debug mode (more verbose logging)
     */
    private bool $debug = false;

    /**
     * ProviderManager instance
     */
    private ?ProviderManager $providerManager = null;

    /**
     * SearchService instance
     */
    private ?SearchService $searchService = null;

    /**
     * ProductRepository instance
     */
    private ProductRepository $productRepository;

    /**
     * Constructor
     */
    public function __construct(bool $debug = false)
    {
        $this->debug = $debug || (defined('WP_DEBUG') && WP_DEBUG);
        $this->productRepository = ProductRepository::instance();
    }

    /**
     * Process next pending item in queue
     *
     * @return array Result with 'success', 'message', 'queue_id', 'post_id'
     */
    public function processNext(): array
    {
        global $wpdb;
        $table = Schema::queueTable();

        // Get next pending item (priority DESC, created_at ASC)
        $item = $wpdb->get_row(
            "SELECT * FROM {$table}
             WHERE status = 'pending'
             ORDER BY priority DESC, created_at ASC
             LIMIT 1",
            ARRAY_A
        );

        if (!$item) {
            return [
                'success' => true,
                'message' => 'No pending items in queue',
                'queue_id' => null,
                'post_id' => null
            ];
        }

        return $this->processItem((int) $item['id']);
    }

    /**
     * Process specific queue item by ID
     *
     * @param int $queueId Queue item ID
     * @return array Result
     */
    public function processItem(int $queueId): array
    {
        global $wpdb;
        $table = Schema::queueTable();

        // Load item
        $this->item = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $queueId),
            ARRAY_A
        );

        if (!$this->item) {
            return [
                'success' => false,
                'message' => 'Queue item not found',
                'queue_id' => $queueId,
                'post_id' => null
            ];
        }

        $this->queueId = $queueId;
        $this->log = [];
        $this->errors = [];
        $this->currentStepIndex = 0;

        // Parse content_settings (may already be decoded by WordPress/PDO)
        $rawSettings = $this->item['content_settings'] ?? null;
        $this->settings = is_array($rawSettings)
            ? $rawSettings
            : (!empty($rawSettings) ? (json_decode($rawSettings, true) ?? []) : []);

        // Load existing processing_log if resuming (may be string or already decoded array)
        if (!empty($this->item['processing_log'])) {
            $existingLog = is_array($this->item['processing_log'])
                ? $this->item['processing_log']
                : json_decode($this->item['processing_log'], true);
            if (isset($existingLog['steps'])) {
                $this->log = $existingLog['steps'];
            }
            if (isset($existingLog['errors'])) {
                $this->errors = $existingLog['errors'];
            }
        }

        try {
            // Execute all steps
            $result = $this->executeSteps();

            return [
                'success' => $result['success'],
                'message' => $result['message'],
                'queue_id' => $queueId,
                'post_id' => $result['post_id'] ?? null,
                'log' => $this->log
            ];
        } catch (\Exception $e) {
            $this->logError('exception', $e->getMessage());
            $this->handleFailure($e->getMessage());

            return [
                'success' => false,
                'message' => 'Processing failed: ' . $e->getMessage(),
                'queue_id' => $queueId,
                'post_id' => null,
                'log' => $this->log
            ];
        }
    }

    /**
     * Execute all processing steps
     *
     * @return array Result with success and message
     */
    private function executeSteps(): array
    {
        $postId = null;

        foreach (self::STEPS as $index => $step) {
            $this->currentStepIndex = $index;

            $stepResult = $this->executeStep($step);

            if (!$stepResult['success']) {
                // Step failed - handle based on retry logic
                $this->handleFailure($stepResult['message']);
                return [
                    'success' => false,
                    'message' => "Failed at step '{$step}': " . $stepResult['message'],
                    'post_id' => null
                ];
            }

            // Capture post_id from create_post step
            if ($step === 'create_post' && isset($stepResult['post_id'])) {
                $postId = $stepResult['post_id'];
            }

            // Save log after each step
            $this->saveProcessingLog();
        }

        return [
            'success' => true,
            'message' => 'Processing completed successfully',
            'post_id' => $postId
        ];
    }

    /**
     * Execute a single step
     *
     * @param string $step Step name
     * @return array Result with success and message
     */
    private function executeStep(string $step): array
    {
        $startTime = microtime(true);
        $this->log($step, "Starting step: {$step}");

        try {
            $result = match ($step) {
                'init' => $this->stepInit(),
                'search_asins' => $this->stepSearchAsins(),
                'generate_content' => $this->stepGenerateContent(),
                'create_post' => $this->stepCreatePost(),
                'finalize' => $this->stepFinalize(),
                default => ['success' => false, 'message' => 'Unknown step']
            };

            $duration = round((microtime(true) - $startTime) * 1000);
            $this->log($step, "Step completed in {$duration}ms", [
                'success' => $result['success'],
                'duration_ms' => $duration
            ]);

            return $result;
        } catch (\Exception $e) {
            $this->logError($step, $e->getMessage());
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }

    // =========================================================================
    // STEP IMPLEMENTATIONS
    // =========================================================================

    /**
     * Step 1: Initialize processing
     */
    private function stepInit(): array
    {
        global $wpdb;
        $table = Schema::queueTable();

        // Update status to processing
        $updated = $wpdb->update($table, [
            'status' => 'processing',
            'started_at' => current_time('mysql'),
            'attempts' => (int) $this->item['attempts'] + 1,
        ], ['id' => $this->queueId]);

        if ($updated === false) {
            return ['success' => false, 'message' => 'Failed to update status'];
        }

        $this->log('init', 'Processing initialized', [
            'keyword' => $this->item['keyword'],
            'post_type' => $this->item['post_type'],
            'attempt' => (int) $this->item['attempts'] + 1,
            'settings' => $this->settings
        ]);

        return ['success' => true, 'message' => 'Initialized'];
    }

    /**
     * Step 2: Search ASINs from Amazon (with pagination support)
     *
     * Uses SearchService for unified search with pagination.
     */
    private function stepSearchAsins(): array
    {
        // Check if search is enabled
        if (empty($this->item['auto_search_asins'])) {
            $this->log('search_asins', 'ASIN search disabled, skipping');
            return ['success' => true, 'message' => 'Skipped - search disabled'];
        }

        // Check if already has ASINs (may be string or already decoded array)
        $linkedAsins = $this->item['linked_asins']
            ? (is_array($this->item['linked_asins']) ? $this->item['linked_asins'] : json_decode($this->item['linked_asins'], true))
            : [];

        if (!empty($linkedAsins)) {
            $this->log('search_asins', 'ASINs already found, skipping', [
                'existing_count' => count($linkedAsins)
            ]);
            return ['success' => true, 'message' => 'Skipped - already has ASINs'];
        }

        // Search for ASINs
        $keyword = $this->item['keyword'];
        $limit = (int) ($this->item['search_limit'] ?? 15);
        $maxPages = (int) ($this->item['max_search_pages'] ?? 2);
        $domain = $this->item['search_domain'] ?? 'amazon.com';

        $this->log('search_asins', "Searching ASINs for: {$keyword}", [
            'limit' => $limit,
            'max_pages' => $maxPages,
            'domain' => $domain
        ]);

        // Use SearchService for pagination support
        $this->searchService = $this->searchService ?? SearchService::instance();
        $searchResult = $this->searchService->searchAsins($keyword, $limit, $maxPages, $domain);

        if (empty($searchResult['products'])) {
            $error = $this->searchService->getLastError() ?? 'No results found';
            $this->logError('search_asins', $error);
            // Don't fail - just continue with no ASINs
            return ['success' => true, 'message' => 'No ASINs found, continuing'];
        }

        // Save ASINs to products table and link to queue
        $savedAsins = $this->saveSearchResults($searchResult['products'], $limit, $searchResult['provider'] ?? null);

        // Update queue item in database
        global $wpdb;
        $linkedAsinsJson = wp_json_encode($savedAsins);
        $wpdb->update(Schema::queueTable(), [
            'linked_asins' => $linkedAsinsJson,
            'search_results_count' => count($savedAsins),
            'search_provider' => $searchResult['provider'] ?? 'unknown',
            'searched_at' => current_time('mysql'),
        ], ['id' => $this->queueId]);

        // IMPORTANT: Also update in-memory item for subsequent steps
        $this->item['linked_asins'] = $linkedAsinsJson;
        $this->item['search_results_count'] = count($savedAsins);

        $this->log('search_asins', 'ASINs found and saved', [
            'count' => count($savedAsins),
            'pages_fetched' => $searchResult['pages_fetched'] ?? 1,
            'provider' => $searchResult['provider'] ?? 'unknown',
            'asins' => $savedAsins
        ]);

        return [
            'success' => true,
            'message' => count($savedAsins) . ' ASINs found'
        ];
    }

    /**
     * Save search results to products table
     *
     * Uses ProductRepository for unified database operations.
     * Creates new products or returns existing product IDs.
     *
     * @param array $results Search results from SearchService
     * @param int $limit Maximum ASINs to save
     * @param string|null $provider Provider name (optional)
     * @return array List of saved ASINs
     */
    private function saveSearchResults(array $results, int $limit, ?string $provider = null): array
    {
        $savedAsins = [];
        // Use provided provider or fall back to ProviderManager
        $provider = $provider ?? $this->providerManager?->getLastUsedProvider();

        foreach ($results as $product) {
            if (empty($product['asin'])) continue;
            if (count($savedAsins) >= $limit) break;

            $asin = $product['asin'];

            try {
                // Check if product exists before creating
                $existingProduct = $this->productRepository->findByAsin($asin);

                // Use repository method for unified create/update logic
                $productId = $this->productRepository->createOrUpdateFromSearch(
                    $asin,
                    $product,
                    $provider
                );

                // Log only if this was a newly created product
                if (!$existingProduct) {
                    $this->log('search_asins', "New product added: {$asin}", [
                        'title' => $product['title'] ?? 'N/A',
                        'product_id' => $productId
                    ]);
                }

                $savedAsins[] = $asin;
            } catch (\Exception $e) {
                $this->log('search_asins', "Failed to save product: {$asin}", [
                    'error' => $e->getMessage()
                ]);
                // Continue with other products even if one fails
            }
        }

        return $savedAsins;
    }

    /**
     * Refresh product_stats from products table
     *
     * This fetches the latest data from products table (which may have been scraped
     * since the initial search) and updates the content_settings.product_stats.
     * Especially useful for getting brand data that might not be available from search.
     *
     * @param array $asins List of ASINs to refresh data for
     */
    private function refreshProductStats(array $asins): void
    {
        if (empty($asins)) {
            return;
        }

        global $wpdb;
        $productsTable = Schema::productsTable();

        // Build placeholders for IN clause
        $placeholders = implode(',', array_fill(0, count($asins), '%s'));

        // Fetch product data from table
        $products = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT asin, title, brand, price, rating, reviews_count
                 FROM {$productsTable}
                 WHERE asin IN ({$placeholders})",
                ...$asins
            ),
            ARRAY_A
        );

        if (empty($products)) {
            return;
        }

        // Collect stats from products
        $productStats = [
            'product_count' => count($asins),  // Count linked ASINs, not just scraped products
            'price_min' => null,
            'price_max' => null,
            'review_total' => 0,
            'brands' => [],
        ];

        foreach ($products as $product) {
            // Price stats
            $price = $product['price'] !== null ? floatval($product['price']) : null;
            if ($price !== null && $price > 0) {
                if ($productStats['price_min'] === null || $price < $productStats['price_min']) {
                    $productStats['price_min'] = $price;
                }
                if ($productStats['price_max'] === null || $price > $productStats['price_max']) {
                    $productStats['price_max'] = $price;
                }
            }

            // Review count
            $productStats['review_total'] += intval($product['reviews_count'] ?? 0);

            // Brands (unique)
            $brand = trim($product['brand'] ?? '');
            if (!empty($brand) && !in_array($brand, $productStats['brands'])) {
                $productStats['brands'][] = $brand;
            }
        }

        // Get existing product_stats and merge
        $existingStats = $this->settings['product_stats'] ?? [];

        // Only update fields that have new data
        if ($productStats['price_min'] !== null) {
            $existingStats['price_min'] = $productStats['price_min'];
        }
        if ($productStats['price_max'] !== null) {
            $existingStats['price_max'] = $productStats['price_max'];
        }
        if ($productStats['review_total'] > 0) {
            $existingStats['review_total'] = $productStats['review_total'];
        }
        if (!empty($productStats['brands'])) {
            $existingStats['brands'] = $productStats['brands'];
        }
        $existingStats['product_count'] = $productStats['product_count'];

        // Update settings
        $this->settings['product_stats'] = $existingStats;

        // Also update the item for TemplatePlaceholders (may already be decoded)
        $rawCs = $this->item['content_settings'] ?? null;
        $contentSettings = is_array($rawCs) ? $rawCs : (!empty($rawCs) ? (json_decode($rawCs, true) ?? []) : []);
        $contentSettings['product_stats'] = $existingStats;
        $this->item['content_settings'] = wp_json_encode($contentSettings);

        // Persist to database
        $wpdb->update(Schema::queueTable(), [
            'content_settings' => $this->item['content_settings'],
        ], ['id' => $this->queueId]);

        $this->log('generate_content', 'Product stats refreshed from database', [
            'brands' => $existingStats['brands'] ?? [],
            'price_range' => ($existingStats['price_min'] ?? 'N/A') . ' - ' . ($existingStats['price_max'] ?? 'N/A'),
            'products_found' => $productStats['product_count'],
        ]);
    }

    /**
     * Step 3: Generate content with template
     *
     * Uses linked_asins directly from search results.
     * Refreshes product_stats from products table to get latest data (brands, prices, etc.)
     */
    private function stepGenerateContent(): array
    {
        // Get linked ASINs directly from queue item (may be string or already decoded array)
        $linkedAsins = $this->item['linked_asins']
            ? (is_array($this->item['linked_asins']) ? $this->item['linked_asins'] : json_decode($this->item['linked_asins'], true))
            : [];

        if (empty($linkedAsins)) {
            $this->log('generate_content', 'No ASINs linked, will create content without products');
        }

        // Refresh product_stats from products table (may have been scraped since search)
        $this->refreshProductStats($linkedAsins);

        // Get template ID from settings
        $templateId = $this->settings['template_id'] ?? null;

        $this->log('generate_content', 'Generating content', [
            'template_id' => $templateId,
            'asin_count' => count($linkedAsins),
            'keyword' => $this->item['keyword']
        ]);

        // Initialize placeholder handler (uses updated product_stats from content_settings)
        $placeholders = new TemplatePlaceholders($this->item);

        // Generate content from template or fallback to basic content
        if (!empty($templateId)) {
            $content = $this->generateFromTemplate($templateId, $linkedAsins, $placeholders);
        } else {
            $content = $this->generateBasicContent($linkedAsins, $placeholders);
        }

        $this->settings['generated_content'] = $content;

        $this->log('generate_content', 'Content generated', [
            'word_count' => str_word_count(strip_tags($content['body'] ?? '')),
            'has_title' => !empty($content['title']),
            'has_body' => !empty($content['body']),
            'used_template' => !empty($templateId)
        ]);

        return [
            'success' => true,
            'message' => 'Content generated',
            'content' => $content
        ];
    }

    /**
     * Generate content from template
     *
     * @param string $templateId Template ID
     * @param array $asins Linked ASINs
     * @param TemplatePlaceholders $placeholders Placeholder handler
     * @return array Generated content
     */
    private function generateFromTemplate(string $templateId, array $asins, TemplatePlaceholders $placeholders): array
    {
        // Load template from options
        $templates = get_option('acms_content_templates', []);
        $template = $templates[$templateId] ?? null;

        if (!$template) {
            $this->log('generate_content', "Template '{$templateId}' not found, using basic content");
            return $this->generateBasicContent($asins, $placeholders);
        }

        $this->log('generate_content', 'Using template: ' . ($template['name'] ?? $templateId));

        // Build product shortcodes
        $displayType = $template['displayType'] ?? 'list';
        $productShortcode = $this->buildProductShortcode($asins, $displayType);

        // Build content body
        $beforeProducts = $template['beforeProducts'] ?? '';
        $afterProducts = $template['afterProducts'] ?? '';
        $description = $template['description'] ?? '';

        // Combine content sections
        $bodyParts = [];

        if (!empty($beforeProducts)) {
            $bodyParts[] = $beforeProducts;
        }

        if (!empty($description)) {
            $bodyParts[] = $description;
        }

        if (!empty($productShortcode)) {
            $bodyParts[] = $productShortcode;
        }

        if (!empty($afterProducts)) {
            $bodyParts[] = $afterProducts;
        }

        $body = implode("\n\n", $bodyParts);

        // Get title and meta from template
        $title = $template['title'] ?? '%keyword%';
        $metaTitle = $template['metaTitle'] ?? '';
        $metaDescription = $template['metaDescription'] ?? '';

        // RUNTIME RENDER: Keep raw placeholders in content
        // Placeholders will be replaced at display time via the_content/the_title filters
        // This ensures dates and product stats are always current
        $content = [
            'title' => $title,
            'body' => $body,
            'excerpt' => $description, // Use Sapo/Description for excerpt
            'meta_title' => $metaTitle,
            'meta_description' => $metaDescription,
            'template_id' => $templateId,
            'context_map' => [], // No longer needed for cron updates
        ];

        return $content;
    }

    /**
     * Generate basic content without template
     *
     * @param array $asins Linked ASINs
     * @param TemplatePlaceholders $placeholders Placeholder handler
     * @return array Generated content
     */
    private function generateBasicContent(array $asins, TemplatePlaceholders $placeholders): array
    {
        $keyword = $this->item['keyword'];
        $title = ucwords($keyword);

        // Build product shortcode
        $productShortcode = $this->buildProductShortcode($asins, 'list');

        $body = sprintf(
            '<p>This is a review article about %s.</p>
            <h2>Top Products</h2>
            %s
            <h2>Buying Guide</h2>
            <p>When choosing %s, consider the following factors...</p>',
            esc_html($keyword),
            $productShortcode,
            esc_html($keyword)
        );

        // RUNTIME RENDER: Keep raw placeholders - use %Keyword% instead of hardcoded keyword
        // This allows runtime replacement with current data
        $excerpt = "Find the best %Keyword% with our comprehensive buying guide.";

        return [
            'title' => '%Keyword%', // Use placeholder for runtime replacement
            'body' => $body,
            'excerpt' => $excerpt,
            'context_map' => [], // No longer needed for cron updates
        ];
    }

    /**
     * Build product shortcode based on display type
     *
     * @param array $asins Product ASINs
     * @param string $displayType 'list' or 'grid'
     * @return string Shortcode HTML
     */
    private function buildProductShortcode(array $asins, string $displayType): string
    {
        if (empty($asins)) {
            return '';
        }

        $asinList = implode(',', $asins);

        return sprintf('[acms_list asin="%s"]', esc_attr($asinList));
    }

    /**
     * Step 4: Create WordPress post
     */
    private function stepCreatePost(): array
    {
        $content = $this->settings['generated_content'] ?? [];

        if (empty($content['title']) || empty($content['body'])) {
            return ['success' => false, 'message' => 'No content to publish'];
        }

        // Check if post with this keyword already exists
        $keyword = $this->item['keyword'] ?? '';
        $postType = $this->item['post_type'] ?? 'acms_reviews';
        $existingPostId = $this->findPostByKeyword($keyword, $postType);

        // Determine author
        $authorId = $this->settings['author_id'] ?? null;
        if ($authorId === 'random' || empty($authorId)) {
            // Get random author
            $authors = get_users(['role__in' => ['administrator', 'editor', 'author']]);
            if (!empty($authors)) {
                $authorId = $authors[array_rand($authors)]->ID;
            } else {
                $authorId = get_current_user_id() ?: 1;
            }
        }

        // Determine post status
        $postStatus = !empty($this->settings['auto_publish']) ? 'publish' : 'draft';

        // Generate slug from keyword (excluding year)
        $slug = $this->generateSlugFromKeyword($keyword);

        // Prepare post data
        $postData = [
            'post_title' => $content['title'],
            'post_name' => $slug,
            'post_content' => $content['body'],
            'post_excerpt' => $content['excerpt'] ?? '',
            'post_type' => $postType,
            'post_status' => $postStatus,
            'post_author' => (int) $authorId,
        ];

        // Update existing post or create new one
        if ($existingPostId) {
            // Update existing post
            $postData['ID'] = $existingPostId;

            $this->log('create_post', 'Updating existing post', [
                'post_id' => $existingPostId,
                'keyword' => $keyword,
                'title' => $content['title'],
                'slug' => $slug,
                'status' => $postStatus
            ]);

            $postId = wp_update_post($postData, true);
        } else {
            // Create new post
            $this->log('create_post', 'Creating new WordPress post', [
                'keyword' => $keyword,
                'title' => $content['title'],
                'slug' => $slug,
                'post_type' => $postType,
                'status' => $postStatus,
                'author_id' => $authorId
            ]);

            $postId = wp_insert_post($postData, true);
        }

        if (is_wp_error($postId)) {
            return [
                'success' => false,
                'message' => $postId->get_error_message()
            ];
        }

        // Set category if specified
        if (!empty($this->item['category_id'])) {
            // Determine correct taxonomy based on post type
            $taxonomy = match ($this->item['post_type']) {
                'post' => 'category',              // WordPress built-in
                'page' => null,                    // Pages don't have categories
                default => $this->item['post_type'] . '_category'  // Custom post types
            };

            if ($taxonomy) {
                wp_set_object_terms($postId, [(int) $this->item['category_id']], $taxonomy);
            }
        }

        // Set tags if specified
        if (!empty($this->item['tags'])) {
            // Determine correct tag taxonomy
            $tagTaxonomy = match ($this->item['post_type']) {
                'post' => 'post_tag',              // WordPress built-in
                'page' => null,                    // Pages don't have tags by default
                default => $this->item['post_type'] . '_tag'  // Custom post types
            };

            if ($tagTaxonomy) {
                $tags = array_map('trim', explode(',', $this->item['tags']));
                wp_set_object_terms($postId, $tags, $tagTaxonomy);
            }
        }

        // Set brand taxonomy for acms_reviews posts
        if ($this->item['post_type'] === 'acms_reviews') {
            $brands = $this->settings['product_stats']['brands'] ?? [];
            if (!empty($brands)) {
                $brandTermIds = [];
                foreach ($brands as $brandName) {
                    $termId = PostTypeManager::getOrCreateBrand($brandName);
                    if ($termId) {
                        $brandTermIds[] = (int) $termId;
                    }
                }

                if (!empty($brandTermIds)) {
                    wp_set_object_terms($postId, $brandTermIds, 'acms_reviews_brand');
                    $this->log('create_post', 'Assigned brand terms to post', [
                        'brands' => $brands,
                        'term_ids' => $brandTermIds
                    ]);
                }
            }
        }

        // Set noindex meta if enabled (default is noindex)
        $noIndex = $this->settings['no_index'] ?? true;
        if ($noIndex) {
            // Set our custom meta
            update_post_meta($postId, '_acms_noindex', '1');

            // Also set Yoast SEO meta if Yoast is active
            if (defined('WPSEO_VERSION')) {
                update_post_meta($postId, '_yoast_wpseo_meta-robots-noindex', '1');
            }

            // Also set Rank Math meta if Rank Math is active
            if (defined('RANK_MATH_VERSION')) {
                update_post_meta($postId, 'rank_math_robots', ['noindex']);
            }

            $this->log('create_post', 'Set post as noindex');
        }

        // Set SEO meta fields if provided (from template)
        if (!empty($content['meta_title']) || !empty($content['meta_description'])) {
            $metaTitle = $content['meta_title'] ?? '';
            $metaDescription = $content['meta_description'] ?? '';

            // Save to our custom meta
            if (!empty($metaTitle)) {
                update_post_meta($postId, '_acms_meta_title', $metaTitle);
            }
            if (!empty($metaDescription)) {
                update_post_meta($postId, '_acms_meta_description', $metaDescription);
            }

            // Yoast SEO support
            if (defined('WPSEO_VERSION')) {
                if (!empty($metaTitle)) {
                    update_post_meta($postId, '_yoast_wpseo_title', $metaTitle);
                }
                if (!empty($metaDescription)) {
                    update_post_meta($postId, '_yoast_wpseo_metadesc', $metaDescription);
                }
            }

            // Rank Math support
            if (defined('RANK_MATH_VERSION')) {
                if (!empty($metaTitle)) {
                    update_post_meta($postId, 'rank_math_title', $metaTitle);
                }
                if (!empty($metaDescription)) {
                    update_post_meta($postId, 'rank_math_description', $metaDescription);
                }
            }

            $this->log('create_post', 'Set SEO meta fields', [
                'meta_title' => $metaTitle,
                'meta_description' => substr($metaDescription, 0, 50) . '...'
            ]);
        }

        // Store template ID in post meta for reference
        if (!empty($content['template_id'])) {
            update_post_meta($postId, '_acms_template_id', $content['template_id']);
        }

        // Store date update context map for monthly updates
        if (!empty($content['context_map'])) {
            $generatedDate = date('Y-m'); // Current year-month
            DateUpdateContext::saveToPost($postId, $content['context_map'], $generatedDate);

            $this->log('create_post', 'Saved date update context map', [
                'generated_date' => $generatedDate,
                'contexts_count' => array_sum(array_map('count', $content['context_map'])),
            ]);
        }

        // Save keyword to post meta for duplicate prevention
        if (!empty($keyword)) {
            update_post_meta($postId, '_acms_queue_keyword', sanitize_text_field($keyword));
            $this->log('create_post', 'Saved keyword to post meta for tracking', [
                'keyword' => $keyword
            ]);
        }

        // Update queue with post ID
        global $wpdb;
        $wpdb->update(Schema::queueTable(), [
            'generated_post_id' => $postId
        ], ['id' => $this->queueId]);

        $this->log('create_post', 'Post created successfully', [
            'post_id' => $postId,
            'edit_url' => admin_url("post.php?post={$postId}&action=edit")
        ]);

        return [
            'success' => true,
            'message' => "Post created with ID: {$postId}",
            'post_id' => $postId
        ];
    }

    /**
     * Step 5: Finalize processing
     */
    private function stepFinalize(): array
    {
        global $wpdb;

        $wpdb->update(Schema::queueTable(), [
            'status' => 'completed',
            'completed_at' => current_time('mysql'),
            'error_message' => null,
            'ai_post_status' => 'queued', // Queue for AI post generation immediately
        ], ['id' => $this->queueId]);

        // Fire event so AI Bootstrap can trigger post generation immediately
        do_action('acms_post_ai_queued', $this->queueId);

        // Link found ASINs to the generated post and let the recurring scrape job handle them
        // Products are already in acms_products with status='pending' from search_asins step
        // Server cron scrape endpoint (every 2 min) will mark them scheduled and spawn workers
        $linkedAsins = $this->getLinkedAsins();
        if (!empty($linkedAsins)) {
            $this->log('finalize', 'Products ready for scraping', [
                'asin_count' => count($linkedAsins)
            ]);

            // Link the generated post to all ASINs in products table
            $postId = $this->item['generated_post_id'] ?? null;
            if ($postId) {
                $detector = \AffiliateCMS\Pro\Services\AsinDetector::instance();
                $linkedCount = 0;
                foreach ($linkedAsins as $asin) {
                    if ($detector->addPostToProduct($asin, (int) $postId)) {
                        $linkedCount++;
                    }
                }
                $this->log('finalize', 'Linked post to products', [
                    'post_id' => $postId,
                    'asins_linked' => $linkedCount
                ]);
            }
        }

        $this->log('finalize', 'Processing completed successfully', [
            'total_steps' => count(self::STEPS),
            'post_id' => $this->item['generated_post_id'] ?? null,
            'asins_scheduled' => count($linkedAsins)
        ]);

        return [
            'success' => true,
            'message' => 'Finalized'
        ];
    }

    /**
     * Get linked ASINs from the queue item
     */
    private function getLinkedAsins(): array
    {
        $linkedAsins = $this->item['linked_asins'] ?? '';

        if (empty($linkedAsins)) {
            return [];
        }

        if (is_string($linkedAsins)) {
            $decoded = json_decode($linkedAsins, true);
            return is_array($decoded) ? $decoded : [];
        }

        return is_array($linkedAsins) ? $linkedAsins : [];
    }

    // =========================================================================
    // HELPER METHODS
    // =========================================================================

    /**
     * Find existing post by keyword
     *
     * Searches for a post with matching _acms_queue_keyword meta
     *
     * @param string $keyword The keyword to search for
     * @param string $postType The post type to search in
     * @return int|null Post ID if found, null otherwise
     */
    private function findPostByKeyword(string $keyword, string $postType): ?int
    {
        if (empty($keyword)) {
            return null;
        }

        global $wpdb;

        // Search for post with matching keyword meta
        $query = $wpdb->prepare(
            "SELECT p.ID
             FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
             WHERE p.post_type = %s
             AND pm.meta_key = '_acms_queue_keyword'
             AND pm.meta_value = %s
             LIMIT 1",
            $postType,
            sanitize_text_field($keyword)
        );

        $postId = $wpdb->get_var($query);

        if ($postId) {
            $this->log('create_post', 'Found existing post for keyword', [
                'keyword' => $keyword,
                'post_id' => (int) $postId
            ]);
        }

        return $postId ? (int) $postId : null;
    }

    /**
     * Generate slug from keyword, excluding year
     *
     * Examples:
     * - "coffee maker 2026" -> "coffee-maker"
     * - "best headphones 2025 review" -> "best-headphones-review"
     * - "top 10 laptops" -> "top-10-laptops"
     *
     * @param string $keyword The keyword to convert
     * @return string Sanitized slug
     */
    private function generateSlugFromKeyword(string $keyword): string
    {
        if (empty($keyword)) {
            return '';
        }

        // Remove dynamic placeholders (date/time-related) — these shouldn't be in slugs
        $slug = preg_replace('/%(?:year|month_text|month_short|month_number|month|day|date_full)%/', '', $keyword);

        // Remove double-delimiter variants too
        $slug = preg_replace('/%%(?:year|month_text|month_short|month_number|month|day|date_full)%%/', '', $slug);

        // Remove literal years (4-digit numbers starting with 19 or 20)
        $slug = preg_replace('/\b(19|20)\d{2}\b/', '', $slug);

        // Clean up: multiple spaces, leading/trailing whitespace, dangling separators
        $slug = preg_replace('/\s+/', ' ', $slug);
        $slug = trim($slug, " \t\n\r-,.");

        // Use WordPress sanitize_title for proper slug formatting
        $slug = sanitize_title($slug);

        return $slug;
    }

    // =========================================================================
    // LOGGING METHODS
    // =========================================================================

    /**
     * Log a message
     */
    private function log(string $step, string $message, array $data = []): void
    {
        $entry = [
            'timestamp' => current_time('mysql'),
            'step' => $step,
            'message' => $message,
            'data' => $data
        ];

        $this->log[] = $entry;

        // Also log to WP debug.log
        if ($this->debug) {
            $logMessage = sprintf(
                '[ACMS Queue #%d] [%s] %s%s',
                $this->queueId,
                strtoupper($step),
                $message,
                $data ? ' ' . wp_json_encode($data) : ''
            );
            error_log($logMessage);
        }
    }

    /**
     * Log an error
     */
    private function logError(string $step, string $message, array $data = []): void
    {
        $this->errors[] = [
            'timestamp' => current_time('mysql'),
            'step' => $step,
            'message' => $message,
            'data' => $data
        ];

        // Always log errors regardless of debug mode
        error_log(sprintf(
            '[ACMS Queue #%d] [ERROR] [%s] %s',
            $this->queueId,
            $step,
            $message
        ));
    }

    /**
     * Save processing log to database
     */
    private function saveProcessingLog(): void
    {
        global $wpdb;

        $logData = [
            'steps' => $this->log,
            'errors' => $this->errors,
            'current_step' => self::STEPS[$this->currentStepIndex] ?? null,
            'progress' => [
                'current' => $this->currentStepIndex + 1,
                'total' => count(self::STEPS)
            ]
        ];

        $wpdb->update(Schema::queueTable(), [
            'processing_log' => wp_json_encode($logData)
        ], ['id' => $this->queueId]);
    }

    /**
     * Handle processing failure
     */
    private function handleFailure(string $errorMessage): void
    {
        global $wpdb;
        $table = Schema::queueTable();

        $attempts = (int) $this->item['attempts'] + 1;
        $maxAttempts = (int) ($this->item['max_attempts'] ?? 3);

        if ($attempts >= $maxAttempts) {
            // Max retries reached - mark as failed
            $wpdb->update($table, [
                'status' => 'failed',
                'error_message' => $errorMessage,
            ], ['id' => $this->queueId]);

            $this->log('failure', 'Max attempts reached, marking as failed', [
                'attempts' => $attempts,
                'max_attempts' => $maxAttempts
            ]);
        } else {
            // Reset to pending for retry
            $wpdb->update($table, [
                'status' => 'pending',
                'error_message' => $errorMessage,
            ], ['id' => $this->queueId]);

            $this->log('failure', 'Will retry later', [
                'attempts' => $attempts,
                'max_attempts' => $maxAttempts,
                'remaining' => $maxAttempts - $attempts
            ]);
        }

        $this->saveProcessingLog();
    }

    // =========================================================================
    // PUBLIC GETTERS
    // =========================================================================

    /**
     * Get current processing log
     */
    public function getLog(): array
    {
        return $this->log;
    }

    /**
     * Get current errors
     */
    public function getErrors(): array
    {
        return $this->errors;
    }

    /**
     * Get processing progress
     */
    public function getProgress(): array
    {
        return [
            'current_step' => self::STEPS[$this->currentStepIndex] ?? null,
            'step_index' => $this->currentStepIndex,
            'total_steps' => count(self::STEPS),
            'percentage' => round(($this->currentStepIndex / count(self::STEPS)) * 100)
        ];
    }
}
