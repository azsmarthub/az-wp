<?php
/**
 * Cache Preload Service
 *
 * Crawls sitemap URLs to warm the FastCGI cache.
 * Uses DB-backed queue (acms_cache_urls) with per-URL tracking,
 * priority ordering, and self-balancing FPM batch sizing.
 *
 * Endpoints:
 *   GET|POST /wp-json/acms/v1/cache/preload       — trigger preload
 *   POST     /wp-json/acms/v1/cache/purge-all      — purge all + preload
 *   GET      /wp-json/acms/v1/cache/status          — cache stats
 *   POST     /wp-json/acms/v1/cache/stop            — stop preload
 *   POST     /wp-json/acms/v1/cache/flush-redis     — flush object cache
 *   POST     /wp-json/acms/v1/cache/process-chunk   — internal self-chaining
 *
 * @package AffiliateCMS\Pro
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro\Core;

use AffiliateCMS\Pro\Database\Schema;

class CachePreload
{
    /** Max FPM workers on this server (productreviewsorg pool) */
    private const FPM_MAX_CHILDREN = 100;

    /** Maximum retry attempts before marking as 'failed' */
    private const MAX_ATTEMPTS = 3;

    /** CPU threshold: pause preload if CPU% exceeds this */
    private const CPU_PAUSE_THRESHOLD = 90;

    /** Transient key for preload status */
    private const STATUS_KEY = 'acms_cache_preload_status';

    /** Option key: when set to true, workers must stop immediately */
    private const STOP_FLAG = 'acms_cache_preload_stopped';

    /**
     * Set the stop flag (with Redis object cache bust)
     */
    private static function setStopFlag(bool $stopped): void
    {
        if ($stopped) {
            update_option(self::STOP_FLAG, '1');
        } else {
            delete_option(self::STOP_FLAG);
        }
        // Bust Redis object cache for this key
        wp_cache_delete(self::STOP_FLAG, 'options');
    }

    /**
     * Check if preload is stopped (bypass stale Redis cache)
     */
    private static function isStopped(): bool
    {
        // Force fresh read from DB, bypassing object cache
        global $wpdb;
        $val = $wpdb->get_var(
            $wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name = %s LIMIT 1", self::STOP_FLAG)
        );
        return $val === '1';
    }

    /** Cron hook names */
    private const CRON_HOOK = 'acms_cache_preload_daily';
    private const CHUNK_HOOK = 'acms_cache_preload_chunk';
    private const REFRESH_HOOK = 'acms_cache_smart_refresh';

    /** Smart Refresh: max URLs per refresh cycle */
    private const REFRESH_LIMIT = 10000;

    /**
     * Initialize: register hooks and REST routes
     */
    public static function init(): void
    {
        add_action(self::CRON_HOOK, [self::class, 'runDailyPreload']);
        add_action(self::CHUNK_HOOK, [self::class, 'processChunk']);
        add_action(self::REFRESH_HOOK, [self::class, 'runSmartRefresh']);
        add_action('rest_api_init', [self::class, 'registerRoutes']);
        add_action('admin_bar_menu', [self::class, 'adminBarCacheStatus'], 999);
        add_action('wp_footer', [self::class, 'adminBarPurgeScript'], 999);

        // Auto-purge per-page cache (replaces Nginx Helper)
        add_action('transition_post_status', [self::class, 'autoPurgeOnPostChange'], 20, 3);
        add_action('wp_insert_comment', [self::class, 'autoPurgeOnComment'], 200, 2);
        add_action('edit_term', [self::class, 'autoPurgeOnTermEdit'], 20, 3);
        add_action('delete_term', [self::class, 'autoPurgeOnTermEdit'], 20, 3);
    }

    // ─── Self-balancing FPM ───────────────────────────────────

    /**
     * Get count of active PHP-FPM worker processes for the site pool.
     * Only counts 'productreviewsorg' pool — ignores www/workers pools.
     */
    private static function getActiveFpmWorkers(): int
    {
        $output = [];
        @exec("ps aux 2>/dev/null | grep -c '[p]hp-fpm.*pool productreviewsorg'", $output);
        return max(0, (int) ($output[0] ?? 0));
    }

    /**
     * Get current CPU usage as percentage (0-100).
     * Uses /proc/loadavg 1-min average divided by CPU cores.
     */
    private static function getCpuPercent(): int
    {
        $cores = (int) @file_get_contents('/proc/cpuinfo');
        // Count "processor" lines
        $cores = preg_match_all('/^processor\s/m', (string) @file_get_contents('/proc/cpuinfo'));
        if ($cores < 1) {
            $cores = 4; // fallback
        }

        $loadavg = @file_get_contents('/proc/loadavg');
        if (!$loadavg) {
            return 50; // fallback: assume moderate
        }

        $load1min = (float) explode(' ', $loadavg)[0];
        return (int) min(100, round(($load1min / $cores) * 100));
    }

    /**
     * Calculate adaptive batch/chunk/timeout/delay based on CPU load.
     *
     * Uses CPU percentage (load / cores) instead of FPM count — more accurate
     * since each page renders in ~10-50ms post-optimization.
     *
     * batch_size = concurrent curl_multi handles
     * chunk_size = total URLs per processChunkOnce() call
     * timeout_ms = per-request curl timeout
     * delay_ms   = sleep between batches
     */
    private static function getAdaptiveSizes(): array
    {
        $cpu = self::getCpuPercent();

        if ($cpu > self::CPU_PAUSE_THRESHOLD) {
            // Critical: skip this chunk entirely, chain recovery will resume
            return ['batch_size' => 0, 'chunk_size' => 0, 'timeout_ms' => 0, 'delay_ms' => 0, 'cpu' => $cpu];
        }

        // Fixed full speed — only pause at >90% CPU
        return ['batch_size' => 60, 'chunk_size' => 600, 'timeout_ms' => 8000, 'delay_ms' => 30, 'cpu' => $cpu];
    }

    // ─── REST Routes ──────────────────────────────────────────

    public static function registerRoutes(): void
    {
        register_rest_route('acms/v1', '/cache/preload', [
            'methods'             => 'GET, POST',
            'callback'            => [self::class, 'handlePreload'],
            'permission_callback' => [self::class, 'checkTokenOrAdmin'],
        ]);

        register_rest_route('acms/v1', '/cache/purge-all', [
            'methods'             => 'POST',
            'callback'            => [self::class, 'handlePurgeAndPreload'],
            'permission_callback' => [self::class, 'checkTokenOrAdmin'],
        ]);

        register_rest_route('acms/v1', '/cache/status', [
            'methods'             => 'GET',
            'callback'            => [self::class, 'handleStatus'],
            'permission_callback' => [self::class, 'checkTokenOrAdmin'],
        ]);

        register_rest_route('acms/v1', '/cache/stop', [
            'methods'             => 'POST',
            'callback'            => [self::class, 'handleStop'],
            'permission_callback' => [self::class, 'checkTokenOrAdmin'],
        ]);

        register_rest_route('acms/v1', '/cache/flush-redis', [
            'methods'             => 'POST',
            'callback'            => [self::class, 'handleFlushRedis'],
            'permission_callback' => [self::class, 'checkTokenOrAdmin'],
        ]);

        register_rest_route('acms/v1', '/cache/process-chunk', [
            'methods'             => 'POST',
            'callback'            => [self::class, 'handleProcessChunk'],
            'permission_callback' => [self::class, 'checkTokenOrAdmin'],
        ]);

        register_rest_route('acms/v1', '/cache/purge-url', [
            'methods'             => 'POST',
            'callback'            => [self::class, 'handlePurgeUrl'],
            'permission_callback' => [self::class, 'checkTokenOrAdmin'],
        ]);

        register_rest_route('acms/v1', '/cache/sync', [
            'methods'             => 'POST',
            'callback'            => [self::class, 'handleSyncFromDisk'],
            'permission_callback' => [self::class, 'checkTokenOrAdmin'],
        ]);

        register_rest_route('acms/v1', '/cache/smart-refresh', [
            'methods'             => 'POST',
            'callback'            => [self::class, 'handleSmartRefresh'],
            'permission_callback' => [self::class, 'checkTokenOrAdmin'],
        ]);

        register_rest_route('acms/v1', '/cache/resume-queue', [
            'methods'             => 'POST',
            'callback'            => [self::class, 'handleResumeQueue'],
            'permission_callback' => [self::class, 'checkTokenOrAdmin'],
        ]);

        register_rest_route('acms/v1', '/cache/clean-orphans', [
            'methods'             => 'POST',
            'callback'            => [self::class, 'handleCleanOrphans'],
            'permission_callback' => [self::class, 'checkTokenOrAdmin'],
        ]);
    }

    /**
     * Permission: accept X-ACMS-Token header, ?token= query param, or logged-in admin
     */
    public static function checkTokenOrAdmin(\WP_REST_Request $request): bool
    {
        if (current_user_can('manage_options')) {
            return true;
        }

        $token = $request->get_header('X-ACMS-Token');
        if (empty($token)) {
            $token = $request->get_param('token');
        }

        if (empty($token)) {
            return false;
        }

        $stored = get_option('acms_api_token', '');
        return !empty($stored) && hash_equals($stored, $token);
    }

    // ─── REST Handlers ────────────────────────────────────────

    /**
     * GET|POST /cache/preload
     * ?priority_only=1 → smart refresh (kept for backward compat)
     * default          → full preload via DB queue
     */
    public static function handlePreload(\WP_REST_Request $request): \WP_REST_Response
    {
        if ((bool) $request->get_param('priority_only')) {
            return self::handleSmartRefresh($request);
        }

        // Clear stop flag — user is explicitly starting preload
        self::setStopFlag(false);

        // Purge all cache files first to prevent disk bloat from stale pages
        self::purgeAllFiles();
        error_log('[ACMS CachePreload] Purged all cache files before full preload');

        self::runDailyPreload();

        return new \WP_REST_Response([
            'success' => true,
            'type'    => 'full',
            'status'  => 'started',
            'message' => 'Purged old cache, full preload started. Check /cache/status for progress.',
        ], 202);
    }

    /**
     * POST /cache/purge-all
     */
    public static function handlePurgeAndPreload(): \WP_REST_Response
    {
        global $wpdb;
        $table = Schema::cacheUrlsTable();

        // 1. Purge nginx cache files (direct filesystem, no Nginx Helper dependency)
        self::purgeAllFiles();

        // 2. Stop any running preload + clear state
        self::setStopFlag(true);
        delete_option('acms_preload_meta');
        wp_clear_scheduled_hook(self::CHUNK_HOOK);

        // 3. Reset all DB URLs to pending (keep the queue, just reset status)
        $tableExists = $wpdb->get_var("SHOW TABLES LIKE '{$table}'") === $table;
        if ($tableExists) {
            $wpdb->query(
                "UPDATE {$table} SET status = 'pending', http_code = NULL, response_time_ms = NULL, attempts = 0, last_warmed_at = NULL"
            );
        }

        // 4. Purge Cloudflare cache (everything)
        self::cloudflarePurgeAll();

        return new \WP_REST_Response([
            'success' => true,
            'purged'  => true,
            'message' => 'Cache purged (Nginx + Cloudflare). All URLs reset to pending. Click "Full Preload" to start warming.',
        ], 200);
    }

    /**
     * POST /cache/purge-url — purge a single URL from nginx cache
     */
    public static function handlePurgeUrl(\WP_REST_Request $request): \WP_REST_Response
    {
        $url = $request->get_param('url');
        if (empty($url)) {
            return new \WP_REST_Response(['success' => false, 'message' => 'URL required.'], 400);
        }

        $url = esc_url_raw($url);
        $purged = self::purgeUrl($url);

        return new \WP_REST_Response([
            'success' => true,
            'purged'  => $purged,
            'url'     => $url,
            'message' => $purged ? 'Cache refreshed.' : 'Failed to refresh cache.',
        ]);
    }

    /**
     * POST /cache/sync — scan disk cache files, match KEY header → update DB status
     *
     * Nginx cache file format: binary header + "KEY: httpsGEThost/path\n" + response.
     * We read first 512 bytes, extract URL from KEY line, match against acms_cache_urls.
     */
    public static function handleSyncFromDisk(): \WP_REST_Response
    {
        global $wpdb;
        $table = Schema::cacheUrlsTable();
        $cache_path = self::getCachePath();

        $tableExists = $wpdb->get_var("SHOW TABLES LIKE '{$table}'") === $table;
        if (!$tableExists) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => 'Cache URLs table not found. Run Full Preload first to build the queue.',
            ], 400);
        }

        if (!is_dir($cache_path)) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => "Cache directory not found: {$cache_path}",
            ], 400);
        }

        // Build a set of md5 hashes from cache files on disk.
        // Use sudo to read cache files owned by flashpanel (Nginx worker user).
        $diskHashes = [];
        $escaped = escapeshellarg(rtrim($cache_path, '/'));
        $output = [];
        @exec("sudo /usr/local/bin/nginx-cache-purge list {$escaped} 2>/dev/null", $output);
        if (empty($output)) {
            // Fallback: direct find (works if ACL grants access)
            @exec("find {$escaped} -type f -maxdepth 3 2>/dev/null", $output);
        }
        foreach ($output as $line) {
            $hash = basename($line);
            if (strlen($hash) === 32 && ctype_xdigit($hash)) {
                $diskHashes[$hash] = true;
            }
        }

        $totalFiles = count($diskHashes);
        if ($totalFiles === 0) {
            return new \WP_REST_Response([
                'success' => true,
                'synced'  => 0,
                'files'   => 0,
                'message' => 'No cache files found on disk.',
            ]);
        }

        // Get all URLs from DB and compute their expected hash
        $synced = 0;
        $batchSize = 1000;
        $offset = 0;
        $siteHost = wp_parse_url(home_url(), PHP_URL_HOST);

        do {
            $rows = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT id, url, status FROM {$table} LIMIT %d OFFSET %d",
                    $batchSize,
                    $offset
                ),
                ARRAY_A
            );

            if (empty($rows)) {
                break;
            }

            $updateCached = [];
            $updatePending = [];

            foreach ($rows as $row) {
                $parsed = wp_parse_url($row['url']);
                if (!$parsed || empty($parsed['host'])) {
                    continue;
                }

                $scheme = $parsed['scheme'] ?? 'https';
                $path = $parsed['path'] ?? '/';
                $hash = md5($scheme . 'GET' . $parsed['host'] . $path);

                if (isset($diskHashes[$hash])) {
                    // File exists on disk → should be 'cached'
                    if ($row['status'] !== 'cached') {
                        $updateCached[] = (int) $row['id'];
                    }
                } else {
                    // File NOT on disk → if DB says 'cached', reset to 'pending'
                    if ($row['status'] === 'cached') {
                        $updatePending[] = (int) $row['id'];
                    }
                }
            }

            // Batch UPDATE cached
            if (!empty($updateCached)) {
                $ids = implode(',', $updateCached);
                $now = current_time('mysql');
                $wpdb->query(
                    "UPDATE {$table} SET status = 'cached', last_warmed_at = '{$now}' WHERE id IN ({$ids})"
                );
                $synced += count($updateCached);
            }

            // Batch UPDATE stale cached → pending
            if (!empty($updatePending)) {
                $ids = implode(',', $updatePending);
                $wpdb->query(
                    "UPDATE {$table} SET status = 'pending', http_code = NULL, response_time_ms = NULL WHERE id IN ({$ids})"
                );
            }

            $offset += $batchSize;
        } while (count($rows) === $batchSize);

        return new \WP_REST_Response([
            'success' => true,
            'synced'  => $synced,
            'files'   => $totalFiles,
            'message' => sprintf('%d URLs synced from %d cache files on disk.', $synced, $totalFiles),
        ]);
    }

    /**
     * GET /cache/status — cache statistics with per-URL status counts
     */
    public static function handleStatus(): \WP_REST_Response
    {
        global $wpdb;
        $table = Schema::cacheUrlsTable();

        // Nginx cache file stats
        // Primary: read from root-generated stats file (no permission issues)
        // Fallback: find/du (partial results due to flashpanel ownership)
        $cache_path = self::getCachePath();
        $file_count = 0;
        $total_size = 0;

        $statsFile = dirname($cache_path) . '/cache-stats.json';
        if (file_exists($statsFile)) {
            $stats = json_decode((string) file_get_contents($statsFile), true);
            if ($stats) {
                $file_count = (int) ($stats['files'] ?? 0);
                $total_size = (int) ($stats['size'] ?? 0);
            }
        }

        // Fallback: use sudo helper for accurate count
        if ($file_count === 0) {
            $escaped_path = escapeshellarg(rtrim($cache_path, '/'));
            $out = [];
            @exec("sudo /usr/local/bin/nginx-cache-purge {$escaped_path} count 2>/dev/null", $out);
            $file_count = (int) ($out[0] ?? 0);

            // Also get size if count > 0
            if ($file_count > 0) {
                $sizeOut = [];
                @exec("sudo /usr/local/bin/nginx-cache-purge {$escaped_path} size 2>/dev/null", $sizeOut);
                $total_size = (int) ($sizeOut[0] ?? 0);

                // Update cache-stats.json with real data
                @file_put_contents($statsFile, json_encode([
                    'files' => $file_count,
                    'size' => $total_size,
                    'updated' => date('Y-m-d H:i:s'),
                ]));
            }
        }

        // DB queue stats
        $tableExists = $wpdb->get_var("SHOW TABLES LIKE '{$table}'") === $table;
        $urlStats = ['total' => 0, 'pending' => 0, 'cached' => 0, 'failed' => 0, 'timeout' => 0, 'skipped' => 0];
        $byType = [];

        if ($tableExists) {
            $counts = $wpdb->get_results(
                "SELECT status, COUNT(*) as cnt FROM {$table} GROUP BY status",
                ARRAY_A
            );
            foreach ($counts as $row) {
                $urlStats[$row['status']] = (int) $row['cnt'];
                $urlStats['total'] += (int) $row['cnt'];
            }

            $typeCounts = $wpdb->get_results(
                "SELECT url_type, COUNT(*) as cnt FROM {$table} GROUP BY url_type",
                ARRAY_A
            );
            foreach ($typeCounts as $row) {
                $byType[$row['url_type']] = (int) $row['cnt'];
            }
        }

        // quickSyncFromDisk disabled — cache files owned by flashpanel (600 perms)
        // so PHP user productreviewsorg cannot read most subdirs, causing false
        // cached→pending resets. DB status from curl responses is the source of truth.
        $meta = get_option('acms_preload_meta', []);
        $stopped = self::isStopped();
        $preloadRunning = !$stopped && !empty($meta) && ($urlStats['pending'] > 0 || $urlStats['timeout'] > 0);

        $inProgress = $preloadRunning;

        // Chain recovery: if preload should be running but no worker is active, respawn
        if ($inProgress) {
            $psOutput = [];
            @exec("ps aux 2>/dev/null | grep 'cache/process-chunk' | grep -v grep | head -1", $psOutput);

            if (empty($psOutput)) {
                $currentCpu = self::getCpuPercent();
                if ($currentCpu < self::CPU_PAUSE_THRESHOLD) {
                    error_log(sprintf('[ACMS CachePreload] Chain recovery: no worker found, CPU=%d%%, respawning', $currentCpu));
                    self::spawnChunkWorker();
                } else {
                    error_log(sprintf('[ACMS CachePreload] Chain recovery: CPU=%d%% > %d%%, waiting', $currentCpu, self::CPU_PAUSE_THRESHOLD));
                }
            }
        }

        return new \WP_REST_Response([
            'success'        => true,
            'cache_files'    => $file_count,
            'cache_size'     => size_format($total_size),
            'cache_size_raw' => $total_size,
            'cache_path'     => $cache_path,
            'total_urls'     => $urlStats['total'],
            'url_stats'      => $urlStats,
            'by_type'        => $byType,
            'in_progress'    => $inProgress,
            'progress'       => $inProgress ? [
                'total'       => $urlStats['total'],
                'preloaded'   => $urlStats['cached'],
                'remaining'   => $urlStats['pending'] + $urlStats['timeout'],
                'failed'      => $urlStats['failed'],
                'cpu'         => $meta['cpu'] ?? null,
                'batch_size'  => $meta['batch_size'] ?? null,
                'chunk_size'  => $meta['chunk_size'] ?? null,
                'timeout_ms'  => $meta['timeout_ms'] ?? null,
                'delay_ms'    => $meta['delay_ms'] ?? null,
                'started'     => $meta['started'] ?? '',
            ] : null,
            'last_preload'   => get_transient(self::STATUS_KEY) ?: null,
        ], 200);
    }

    /**
     * POST /cache/stop — stop running preload
     */
    public static function handleStop(): \WP_REST_Response
    {
        global $wpdb;
        $table = Schema::cacheUrlsTable();

        // Set stop flag FIRST — in-flight workers check this
        self::setStopFlag(true);

        $pending = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$table} WHERE status IN ('pending', 'timeout')"
        );

        if ($pending > 0) {
            $wpdb->query("UPDATE {$table} SET status = 'skipped' WHERE status IN ('pending', 'timeout')");
        }

        // Clean up all state
        delete_option('acms_preload_meta');
        wp_clear_scheduled_hook(self::CHUNK_HOOK);
        wp_clear_scheduled_hook(self::CRON_HOOK);

        // Also remove old file queue if exists
        $queueFile = self::queueFilePath();
        if (file_exists($queueFile)) {
            @unlink($queueFile);
        }

        return new \WP_REST_Response([
            'success' => true,
            'message' => $pending > 0
                ? sprintf('Preload stopped. %s URLs skipped.', number_format($pending))
                : 'Preload stopped.',
        ], 200);
    }

    /**
     * POST /cache/flush-redis
     */
    public static function handleFlushRedis(): \WP_REST_Response
    {
        if (function_exists('wp_cache_flush')) {
            $result = wp_cache_flush();
            return new \WP_REST_Response([
                'success' => $result,
                'message' => $result ? 'Redis object cache flushed' : 'Failed to flush cache',
            ], 200);
        }

        return new \WP_REST_Response([
            'success' => false,
            'message' => 'wp_cache_flush() not available',
        ], 200);
    }

    /**
     * POST /cache/process-chunk — internal endpoint for self-chaining
     */
    public static function handleProcessChunk()
    {
        ignore_user_abort(true);
        set_time_limit(1800); // 30 min: 600 URLs max × up to 8s + delays

        $start = microtime(true);
        $hasMore = self::processChunkOnce();
        $elapsed = round(microtime(true) - $start, 1);

        if ($hasMore) {
            self::spawnChunkWorker();
        }

        header('Content-Type: application/json; charset=UTF-8');
        echo json_encode([
            'success' => true,
            'message' => $hasMore ? 'Chunk processed, next spawned' : 'Processing complete',
            'elapsed' => $elapsed,
        ]);
        exit;
    }

    // ─── Core Logic ───────────────────────────────────────────

    /**
     * Spawn next chunk worker via non-blocking loopback HTTP.
     * Checks FPM headroom first — won't spawn if pool is busy.
     */
    private static function spawnChunkWorker(): void
    {
        $cpu = self::getCpuPercent();
        if ($cpu > self::CPU_PAUSE_THRESHOLD) {
            error_log(sprintf('[ACMS CachePreload] Skipping spawn: CPU=%d%% > %d%%, chain recovery will resume', $cpu, self::CPU_PAUSE_THRESHOLD));
            return;
        }

        $apiToken = get_option('acms_api_token', '');
        $endpoint = rest_url('acms/v1/cache/process-chunk');
        $host = wp_parse_url(home_url(), PHP_URL_HOST);

        $tokenHeader = 'X-ACMS-Token: ' . $apiToken;
        $resolve = $host . ':443:127.0.0.1';
        $cmd = sprintf(
            'curl -s -X POST -H %s --resolve %s --max-time 360 -k %s > /dev/null 2>&1 &',
            escapeshellarg($tokenHeader),
            escapeshellarg($resolve),
            escapeshellarg($endpoint)
        );
        exec($cmd);
    }

    /**
     * Queue file path (kept for backward compat cleanup)
     */
    private static function queueFilePath(): string
    {
        $upload_dir = wp_upload_dir();
        return $upload_dir['basedir'] . '/acms-preload-queue.txt';
    }

    /**
     * Build URL queue from sitemap into DB table.
     * Classifies each URL and assigns priority.
     */
    public static function buildQueue(): int
    {
        global $wpdb;
        $table = Schema::cacheUrlsTable();

        $urls = self::getUrlsFromSitemap();
        if (empty($urls)) {
            return 0;
        }

        // Pre-fetch recent post URLs for priority boost
        $recentPostUrls = [];
        $recentPosts = get_posts([
            'numberposts' => 500,
            'post_type'   => 'post',
            'post_status' => 'publish',
            'orderby'     => 'modified',
            'order'       => 'DESC',
            'date_query'  => [['after' => '30 days ago']],
            'fields'      => 'ids',
        ]);
        foreach ($recentPosts as $pid) {
            $recentPostUrls[get_permalink($pid)] = true;
        }

        // Pre-fetch page URLs
        $pageUrls = [];
        $pages = get_posts([
            'post_type'   => 'page',
            'post_status' => 'publish',
            'fields'      => 'ids',
            'numberposts' => -1,
        ]);
        foreach ($pages as $pid) {
            $pageUrls[get_permalink($pid)] = true;
        }

        // Truncate existing queue (fresh build)
        $wpdb->query("TRUNCATE TABLE {$table}");

        // Batch insert in chunks of 500
        $batch = [];
        $inserted = 0;

        foreach ($urls as $url) {
            $path = wp_parse_url($url, PHP_URL_PATH) ?? '/';

            // Classify and assign priority
            if ($path === '/') {
                $type = 'homepage';
                $priority = 100;
            } elseif (isset($pageUrls[$url])) {
                $type = 'page';
                $priority = 80;
            } elseif (preg_match('#^/category/#', $path) || preg_match('#^/c/#', $path)) {
                $type = 'category';
                $priority = 70;
            } elseif (preg_match('#/page/\d+#', $path)) {
                $type = 'archive';
                $priority = 30;
            } elseif (isset($recentPostUrls[$url])) {
                $type = 'post';
                $priority = 90;
            } else {
                $type = 'post';
                $priority = 50;
            }

            $batch[] = $wpdb->prepare(
                "(%s, %s, 'pending', %d)",
                $url, $type, $priority
            );

            if (count($batch) >= 500) {
                $wpdb->query(
                    "INSERT IGNORE INTO {$table} (url, url_type, status, priority) VALUES " . implode(',', $batch)
                );
                $inserted += count($batch);
                $batch = [];
            }
        }

        if (!empty($batch)) {
            $wpdb->query(
                "INSERT IGNORE INTO {$table} (url, url_type, status, priority) VALUES " . implode(',', $batch)
            );
            $inserted += count($batch);
        }

        return $inserted;
    }

    /**
     * Daily preload: build URL queue from sitemap and start chunked processing
     */
    public static function runDailyPreload(): void
    {
        global $wpdb;
        $table = Schema::cacheUrlsTable();

        // Check if table exists
        $tableExists = $wpdb->get_var("SHOW TABLES LIKE '{$table}'") === $table;
        if (!$tableExists) {
            error_log('[ACMS CachePreload] Table not found, running schema install');
            Schema::instance()->install();
        }

        // Check if already in progress (pending rows exist)
        $pending = (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$table} WHERE status IN ('pending', 'timeout') AND attempts < %d",
                self::MAX_ATTEMPTS
            )
        );

        if ($pending > 0) {
            error_log(sprintf('[ACMS CachePreload] Queue has %d pending URLs, resuming', $pending));
            self::spawnChunkWorker();
            return;
        }

        // Purge stale cache before fresh rebuild to prevent disk bloat
        self::purgeAllFiles();
        error_log('[ACMS CachePreload] Purged stale cache before queue rebuild');

        error_log('[ACMS CachePreload] Building fresh queue from sitemap');
        $count = self::buildQueue();

        if ($count === 0) {
            error_log('[ACMS CachePreload] No URLs found in sitemap');
            return;
        }

        update_option('acms_preload_meta', [
            'total'     => $count,
            'preloaded' => 0,
            'remaining' => $count,
            'started'   => current_time('mysql'),
        ], false);

        set_transient('acms_total_site_urls', $count, DAY_IN_SECONDS);

        error_log(sprintf('[ACMS CachePreload] Queue built: %d URLs', $count));
        self::spawnChunkWorker();
    }

    /**
     * Process one chunk of URLs from DB queue using curl_multi parallel batching.
     * Adaptive: adjusts batch_size/chunk_size/delay based on real-time FPM load.
     * Returns true if more work remains.
     */
    private static function processChunkOnce(): bool
    {
        if (self::isStopped()) {
            error_log('[ACMS CachePreload] Stop flag detected, aborting chunk');
            return false;
        }

        global $wpdb;
        $table = Schema::cacheUrlsTable();

        // Get adaptive sizes based on current CPU load
        $sizes = self::getAdaptiveSizes();
        if ($sizes['batch_size'] === 0) {
            error_log(sprintf('[ACMS CachePreload] CPU=%d%% > %d%%, skipping chunk', $sizes['cpu'], self::CPU_PAUSE_THRESHOLD));
            return true; // More work remains but we can't do it now
        }

        $chunkSize = $sizes['chunk_size'];
        $batchSize = $sizes['batch_size'];

        // Get next chunk of pending URLs, ordered by priority DESC
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, url, attempts FROM {$table} WHERE status = 'pending' ORDER BY priority DESC LIMIT %d",
                $chunkSize
            ),
            ARRAY_A
        );

        if (empty($rows)) {
            // Check timeout URLs worth retrying
            $rows = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT id, url, attempts FROM {$table} WHERE status = 'timeout' AND attempts < %d ORDER BY priority DESC LIMIT %d",
                    self::MAX_ATTEMPTS, $chunkSize
                ),
                ARRAY_A
            );

            if (empty($rows)) {
                self::finishPreload();
                return false;
            }
        }

        // Warm URLs using curl_multi batching with per-URL tracking
        $results = self::warmUrlsWithTracking($rows, $sizes);

        // Update each URL's status in DB
        foreach ($results as $r) {
            if ($r['http_code'] > 0) {
                $wpdb->update($table, [
                    'status'           => 'cached',
                    'http_code'        => $r['http_code'],
                    'response_time_ms' => $r['response_time_ms'],
                    'attempts'         => $r['attempts'],
                    'last_warmed_at'   => gmdate('Y-m-d H:i:s'),
                ], ['id' => $r['id']], ['%s', '%d', '%d', '%d', '%s'], ['%d']);
            } else {
                $newStatus = ($r['attempts'] >= self::MAX_ATTEMPTS) ? 'failed' : 'timeout';
                $wpdb->update($table, [
                    'status'           => $newStatus,
                    'attempts'         => $r['attempts'],
                    'response_time_ms' => $r['response_time_ms'],
                    'last_warmed_at'   => gmdate('Y-m-d H:i:s'),
                ], ['id' => $r['id']], ['%s', '%d', '%d', '%s'], ['%d']);
            }
        }

        // Check remaining work
        $remaining = (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$table} WHERE status IN ('pending', 'timeout') AND attempts < %d",
                self::MAX_ATTEMPTS
            )
        );

        if ($remaining > 0) {
            $total = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table}");
            $cached = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE status = 'cached'");

            update_option('acms_preload_meta', [
                'total'       => $total,
                'preloaded'   => $cached,
                'remaining'   => $remaining,
                'cpu'         => $sizes['cpu'],
                'batch_size'  => $batchSize,
                'chunk_size'  => $chunkSize,
                'timeout_ms'  => $sizes['timeout_ms'],
                'delay_ms'    => $sizes['delay_ms'],
                'started'     => get_option('acms_preload_meta', [])['started'] ?? current_time('mysql'),
            ], false);

            error_log(sprintf(
                '[ACMS CachePreload] Chunk done: %d/%d cached, %d remaining (CPU:%d%% batch:%d chunk:%d delay:%dms)',
                $cached, $total, $remaining, $sizes['cpu'], $batchSize, $chunkSize, $sizes['delay_ms']
            ));

            return true;
        }

        self::finishPreload();
        return false;
    }

    /**
     * Process chunk + self-chain (for cron hook compat)
     */
    public static function processChunk(): void
    {
        $hasMore = self::processChunkOnce();
        if ($hasMore) {
            self::spawnChunkWorker();
        }
    }

    /**
     * Warm URLs using curl_multi with per-URL result tracking.
     * Splits URLs into batches of $sizes['batch_size'], runs each batch
     * concurrently, then sleeps $sizes['delay_ms'] between batches.
     * Re-checks FPM load between batches and pauses if too high.
     */
    private static function warmUrlsWithTracking(array $rows, array $sizes): array
    {
        $allResults = [];
        $host = wp_parse_url(home_url(), PHP_URL_HOST);
        $resolve = $host . ':443:127.0.0.1';
        $batches = array_chunk($rows, $sizes['batch_size']);
        $timeoutMs = $sizes['timeout_ms'];
        $delayMs = $sizes['delay_ms'];

        foreach ($batches as $i => $batch) {
            // Re-check stop flag between batches
            if ($i > 0 && self::isStopped()) {
                break;
            }

            $mh = curl_multi_init();
            $handleMap = [];

            foreach ($batch as $row) {
                $ch = curl_init($row['url']);
                curl_setopt_array($ch, [
                    CURLOPT_RETURNTRANSFER   => true,
                    CURLOPT_TIMEOUT_MS       => $timeoutMs,
                    CURLOPT_CONNECTTIMEOUT_MS => 3000,
                    CURLOPT_SSL_VERIFYPEER   => false,
                    CURLOPT_SSL_VERIFYHOST   => 0,
                    CURLOPT_NOBODY           => false,
                    CURLOPT_USERAGENT        => 'ACMS-CachePreload/3.0',
                    CURLOPT_HTTPHEADER       => ['X-Preload: 1'],
                    CURLOPT_RESOLVE          => [$resolve],
                    CURLOPT_WRITEFUNCTION    => function ($ch, $data) { return strlen($data); },
                ]);
                curl_multi_add_handle($mh, $ch);
                $handleMap[spl_object_id($ch)] = ['ch' => $ch, 'row' => $row];
            }

            do {
                $status = curl_multi_exec($mh, $active);
                if ($active) {
                    curl_multi_select($mh, 0.5);
                }
            } while ($active && $status === CURLM_OK);

            foreach ($handleMap as $entry) {
                $ch = $entry['ch'];
                $row = $entry['row'];
                $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
                $totalTime = curl_getinfo($ch, CURLINFO_TOTAL_TIME);

                $allResults[] = [
                    'id'               => (int) $row['id'],
                    'http_code'        => $httpCode,
                    'response_time_ms' => (int) round($totalTime * 1000),
                    'attempts'         => ((int) ($row['attempts'] ?? 0)) + 1,
                ];

                curl_multi_remove_handle($mh, $ch);
            }
            curl_multi_close($mh);

            // Delay between batches
            if ($i < count($batches) - 1) {
                usleep($delayMs * 1000);
            }
        }

        return $allResults;
    }

    /**
     * Warm a single URL via simple curl (used by warmUrls for priority pages).
     * Returns HTTP code (0 = timeout/error).
     */
    private static function warmSingleUrl(string $url, string $resolve): int
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER   => true,
            CURLOPT_TIMEOUT          => 15,
            CURLOPT_CONNECTTIMEOUT   => 5,
            CURLOPT_SSL_VERIFYPEER   => false,
            CURLOPT_SSL_VERIFYHOST   => 0,
            CURLOPT_NOBODY           => false,
            CURLOPT_USERAGENT        => 'ACMS-CachePreload/3.0',
            CURLOPT_HTTPHEADER       => ['X-Preload: 1'],
            CURLOPT_RESOLVE          => [$resolve],
            CURLOPT_WRITEFUNCTION    => function ($ch, $data) { return strlen($data); },
        ]);
        curl_exec($ch);
        return (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    }

    /**
     * Mark preload as finished, save final status
     */
    private static function finishPreload(): void
    {
        global $wpdb;
        $table = Schema::cacheUrlsTable();

        $total = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table}");
        $cached = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE status = 'cached'");
        $failed = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE status = 'failed'");

        set_transient(self::STATUS_KEY, [
            'type'           => 'full',
            'urls_total'     => $total,
            'urls_preloaded' => $cached,
            'urls_failed'    => $failed,
            'timestamp'      => current_time('mysql'),
        ], DAY_IN_SECONDS);

        delete_option('acms_preload_meta');

        // Cleanup old file-based queue if exists
        $queueFile = self::queueFilePath();
        if (file_exists($queueFile)) {
            @unlink($queueFile);
        }

        error_log(sprintf('[ACMS CachePreload] Preload complete: %d cached, %d failed / %d total', $cached, $failed, $total));
    }

    // ─── Smart Refresh ─────────────────────────────────────

    /**
     * POST /cache/smart-refresh — refresh ~10K most important URLs
     *
     * Uses bypass header to force Nginx to serve fresh content.
     * Runs via chunk system (600 URLs/chunk, self-chaining).
     */
    public static function handleSmartRefresh(\WP_REST_Request $request): \WP_REST_Response
    {
        $count = self::queueSmartRefresh();

        if ($count === 0) {
            return new \WP_REST_Response([
                'success' => true,
                'message' => 'No URLs need refreshing.',
            ]);
        }

        // Clear stop flag + start chunk processing
        self::setStopFlag(false);
        self::spawnChunkWorker();

        return new \WP_REST_Response([
            'success' => true,
            'type'    => 'smart-refresh',
            'queued'  => $count,
            'message' => sprintf('Smart Refresh: %d URLs queued for refresh.', $count),
        ], 202);
    }

    /**
     * POST /cache/resume-queue — resume stalled chunk processing.
     * Called by cron every 30 min. If pending URLs exist but no chunk
     * is running, re-spawns the chain. Safe to call repeatedly.
     */
    public static function handleResumeQueue(\WP_REST_Request $request): \WP_REST_Response
    {
        if (self::isStopped()) {
            return new \WP_REST_Response([
                'success' => true,
                'resumed' => false,
                'message' => 'Queue is stopped by user. Not resuming.',
            ]);
        }

        global $wpdb;
        $table = Schema::cacheUrlsTable();
        $tableExists = $wpdb->get_var("SHOW TABLES LIKE '{$table}'") === $table;
        if (!$tableExists) {
            return new \WP_REST_Response([
                'success' => true,
                'resumed' => false,
                'message' => 'Cache table does not exist.',
            ]);
        }

        $pending = (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$table} WHERE status IN ('pending', 'timeout') AND attempts < %d",
                self::MAX_ATTEMPTS
            )
        );

        if ($pending === 0) {
            return new \WP_REST_Response([
                'success' => true,
                'resumed' => false,
                'pending' => 0,
                'message' => 'No pending URLs. Queue is idle.',
            ]);
        }

        // Pending URLs exist — spawn chunk worker to resume
        self::spawnChunkWorker();

        return new \WP_REST_Response([
            'success' => true,
            'resumed' => true,
            'pending' => $pending,
            'message' => sprintf('Resumed: %d pending URLs, chunk worker spawned.', $pending),
        ]);
    }

    /**
     * POST /cache/clean-orphans — manually trigger orphan URL cleanup.
     * Removes deleted posts, trashed pages, unpublished categories from cache queue.
     */
    public static function handleCleanOrphans(\WP_REST_Request $request): \WP_REST_Response
    {
        $removed = self::cleanOrphanUrls();

        return new \WP_REST_Response([
            'success' => true,
            'removed' => $removed,
            'message' => $removed > 0
                ? sprintf('Cleaned %d orphan URLs from cache queue.', $removed)
                : 'No orphan URLs found. Queue is clean.',
        ]);
    }

    /**
     * Cron entry point for Smart Refresh (every 4h).
     */
    public static function runSmartRefresh(): void
    {
        $count = self::queueSmartRefresh();
        if ($count > 0) {
            self::setStopFlag(false);
            self::spawnChunkWorker();
            error_log(sprintf('[ACMS CachePreload] Smart Refresh: queued %d URLs', $count));
        }
    }

    /**
     * Remove orphan URLs from cache queue: deleted posts, unpublished categories, etc.
     * Also purges their cache files from disk.
     *
     * Runs automatically during Smart Refresh (every 4h).
     *
     * @return int Number of orphan URLs removed
     */
    private static function cleanOrphanUrls(): int
    {
        global $wpdb;
        $table = Schema::cacheUrlsTable();
        $tableExists = $wpdb->get_var("SHOW TABLES LIKE '{$table}'") === $table;
        if (!$tableExists) {
            return 0;
        }

        $removed = 0;

        // 1. Remove post/page URLs where the post no longer exists or isn't published
        $postUrls = $wpdb->get_results(
            "SELECT id, url FROM {$table} WHERE url_type IN ('post', 'page', 'homepage')",
            ARRAY_A
        );

        $orphanIds = [];
        $orphanUrls = [];
        foreach ($postUrls as $row) {
            $postId = url_to_postid($row['url']);
            if ($postId === 0) {
                // URL doesn't resolve to any post — might be archive, tag, etc.
                // Only remove if it returns 404 (check via head request would be expensive)
                // Instead, check known junk patterns
                $path = wp_parse_url($row['url'], PHP_URL_PATH) ?? '';
                // Skip homepage and known archive patterns
                if ($path === '/' || preg_match('#^/(blog|tag|category)/.*#', $path)) {
                    continue;
                }
                $orphanIds[] = $row['id'];
                $orphanUrls[] = $row['url'];
            } elseif (get_post_status($postId) !== 'publish') {
                $orphanIds[] = $row['id'];
                $orphanUrls[] = $row['url'];
            }
        }

        // 2. Remove category URLs where category is no longer published
        // URL pattern: {home}/c/{slug}/ — extract slug via SUBSTRING
        $catTable = $wpdb->prefix . 'acms_categories';
        $catTableExists = $wpdb->get_var("SHOW TABLES LIKE '{$catTable}'") === $catTable;

        if ($catTableExists) {
            $homeUrl = home_url('/c/');
            $prefixLen = strlen($homeUrl) + 1; // +1 for 1-based SUBSTRING

            // Extract slug from cache URL, LEFT JOIN to categories
            // Orphan = no matching published category
            $orphanCatRows = $wpdb->get_results($wpdb->prepare(
                "SELECT cu.id, cu.url
                 FROM {$table} cu
                 LEFT JOIN {$catTable} c
                   ON c.slug = TRIM(TRAILING '/' FROM SUBSTRING(cu.url, %d))
                   AND c.status = 'publish'
                 WHERE cu.url_type = 'category'
                   AND c.id IS NULL",
                $prefixLen
            ), ARRAY_A);

            // Safety: only clean if reasonable count (< 5K prevents data mismatch wipe)
            if (count($orphanCatRows) > 0 && count($orphanCatRows) < 5000) {
                foreach ($orphanCatRows as $row) {
                    $orphanIds[] = $row['id'];
                    $orphanUrls[] = $row['url'];
                }
            }
        }

        // Delete orphan rows from DB
        if (!empty($orphanIds)) {
            $chunks = array_chunk($orphanIds, 500);
            foreach ($chunks as $chunk) {
                $placeholders = implode(',', array_fill(0, count($chunk), '%d'));
                $wpdb->query(
                    $wpdb->prepare(
                        "DELETE FROM {$table} WHERE id IN ({$placeholders})",
                        ...$chunk
                    )
                );
                $removed += count($chunk);
            }

            // Purge cache files for removed URLs
            self::purgeCacheFiles($orphanUrls);

            error_log(sprintf(
                '[ACMS CachePreload] Cleaned %d orphan URLs (posts: %d, categories: %d)',
                $removed,
                count(array_filter($orphanUrls, fn($u) => !str_contains($u, '/c/'))),
                count(array_filter($orphanUrls, fn($u) => str_contains($u, '/c/')))
            ));
        }

        return $removed;
    }

    /**
     * Build the smart refresh queue: mark ~10K important URLs as pending.
     *
     * Priority tiers (processed in order, filling up to REFRESH_LIMIT):
     *   1. Recently modified posts (last 7d)           — always fresh
     *   2. Core pages (home, blog, categories, about)  — always fresh
     *   3. Top category pages (by product_count)        — highest traffic
     *   4. Stalest cached URLs (oldest last_warmed_at)  — prevent stale content
     *
     * @return int Number of URLs queued
     */
    private static function queueSmartRefresh(): int
    {
        global $wpdb;
        $table = Schema::cacheUrlsTable();
        $tableExists = $wpdb->get_var("SHOW TABLES LIKE '{$table}'") === $table;
        if (!$tableExists) {
            return 0;
        }

        // Clean orphan URLs first (deleted posts, unpublished categories)
        self::cleanOrphanUrls();

        $limit = self::REFRESH_LIMIT;
        $queued = 0;
        $urlsToRefresh = [];

        // Tier 1: Recently modified posts (last 7 days) — ~20-50 URLs
        $recentPosts = get_posts([
            'numberposts' => 50,
            'post_status' => 'publish',
            'post_type'   => ['post', 'page'],
            'orderby'     => 'modified',
            'order'       => 'DESC',
            'date_query'  => [['after' => '7 days ago']],
            'fields'      => 'ids',
        ]);
        $tier1Urls = [home_url('/')];
        foreach ($recentPosts as $id) {
            $tier1Urls[] = get_permalink($id);
        }
        // Blog archive + paginated
        $blog_url = get_post_type_archive_link('post');
        if ($blog_url) {
            $tier1Urls[] = $blog_url;
            for ($i = 2; $i <= 5; $i++) {
                $tier1Urls[] = trailingslashit($blog_url) . 'page/' . $i . '/';
            }
        }
        $tier1Urls = array_unique(array_filter($tier1Urls));

        // Tier 2: Important static pages
        $importantPages = get_posts([
            'numberposts' => 20,
            'post_status' => 'publish',
            'post_type'   => 'page',
            'fields'      => 'ids',
        ]);
        $tier2Urls = [];
        foreach ($importantPages as $id) {
            $tier2Urls[] = get_permalink($id);
        }
        $tier2Urls = array_filter($tier2Urls);

        // Mark Tier 1+2 as pending (high priority)
        $highPriorityUrls = array_unique(array_merge($tier1Urls, $tier2Urls));
        foreach ($highPriorityUrls as $url) {
            $affected = $wpdb->query($wpdb->prepare(
                "UPDATE {$table} SET status = 'pending', priority = 99 WHERE url = %s AND status = 'cached'",
                $url
            ));
            if ($affected > 0) {
                $queued++;
                $urlsToRefresh[] = $url;
            }
        }

        $remaining = $limit - $queued;
        if ($remaining <= 0) {
            return $queued;
        }

        // Tier 3: Top category pages by product_count (highest traffic potential)
        // Use acms_categories table to find categories with most products
        $catTable = $wpdb->prefix . 'acms_categories';
        $catTableExists = $wpdb->get_var("SHOW TABLES LIKE '{$catTable}'") === $catTable;

        if ($catTableExists) {
            $topCatLimit = min(5000, (int) ($remaining * 0.5));
            $homeUrl = home_url('/c/');

            // Get top categories by product_count, build their URLs
            $topCats = $wpdb->get_col($wpdb->prepare(
                "SELECT CONCAT(%s, slug, '/') FROM {$catTable}
                 WHERE status = 'publish' AND product_count > 0
                 ORDER BY product_count DESC
                 LIMIT %d",
                $homeUrl,
                $topCatLimit
            ));

            if (!empty($topCats)) {
                // Batch update: mark these category URLs as pending
                $chunks = array_chunk($topCats, 500);
                foreach ($chunks as $chunk) {
                    $placeholders = implode(',', array_fill(0, count($chunk), '%s'));
                    $affected = (int) $wpdb->query($wpdb->prepare(
                        "UPDATE {$table} SET status = 'pending', priority = 80
                         WHERE url IN ({$placeholders}) AND status = 'cached'",
                        ...$chunk
                    ));
                    $queued += $affected;
                }
                $urlsToRefresh = array_merge($urlsToRefresh, $topCats);
            }
        }

        $remaining = $limit - $queued;
        if ($remaining <= 0) {
            return $queued;
        }

        // Tier 4: Stalest cached URLs (oldest last_warmed_at)
        // Collect URLs before updating so we can purge their cache files
        $staleUrls = $wpdb->get_col($wpdb->prepare(
            "SELECT url FROM {$table}
             WHERE status = 'cached'
             ORDER BY last_warmed_at ASC
             LIMIT %d",
            $remaining
        ));
        if (!empty($staleUrls)) {
            $chunks = array_chunk($staleUrls, 500);
            foreach ($chunks as $chunk) {
                $placeholders = implode(',', array_fill(0, count($chunk), '%s'));
                $affected = (int) $wpdb->query($wpdb->prepare(
                    "UPDATE {$table} SET status = 'pending', priority = 60
                     WHERE url IN ({$placeholders}) AND status = 'cached'",
                    ...$chunk
                ));
                $queued += $affected;
            }
            $urlsToRefresh = array_merge($urlsToRefresh, $staleUrls);
        }

        // Purge cache files for all queued URLs so Nginx returns MISS → warm creates new cache
        self::purgeCacheFiles($urlsToRefresh);

        return $queued;
    }

    /**
     * Purge cache files for a list of URLs using sudo helper.
     * This ensures Nginx returns MISS so warm requests create fresh cache files.
     */
    private static function purgeCacheFiles(array $urls): void
    {
        if (empty($urls)) {
            return;
        }

        $cache_path = self::getCachePath();
        $commands = [];

        foreach ($urls as $url) {
            $parsed = wp_parse_url($url);
            if (!$parsed || empty($parsed['host'])) {
                continue;
            }
            $scheme = $parsed['scheme'] ?? 'https';
            $path = $parsed['path'] ?? '/';
            $hash = md5($scheme . 'GET' . $parsed['host'] . $path);
            $file = $cache_path . substr($hash, -1) . '/' . substr($hash, -3, 2) . '/' . $hash;
            $commands[] = escapeshellarg($file);
        }

        // Batch purge in chunks of 200 (avoid command line too long)
        $chunks = array_chunk($commands, 200);
        foreach ($chunks as $chunk) {
            $files = implode(' ', $chunk);
            @exec("sudo /usr/local/bin/nginx-cache-purge purge-batch {$files} 2>/dev/null");
        }
    }

    // ─── Admin Bar ────────────────────────────────────────────

    /**
     * Admin bar: show cache status for current page (frontend only)
     */
    public static function adminBarCacheStatus(\WP_Admin_Bar $admin_bar): void
    {
        if (is_admin() || !current_user_can('manage_options')) {
            return;
        }

        $cached = self::isCurrentPageCached();
        $icon = $cached ? '●' : '○';
        $color = $cached ? '#46d369' : '#888';
        $label = $cached ? 'Cached' : 'Not Cached';

        // Parent node: clickable cache status (click to purge this page)
        $admin_bar->add_node([
            'id'    => 'acms-cache-status',
            'title' => sprintf(
                '<span style="color:%s;font-size:11px;">%s %s</span>',
                $color,
                $icon,
                $label
            ),
            'href'  => '#',
            'meta'  => [
                'onclick' => 'return false;',
                'title'   => $cached
                    ? 'Click to purge this page from cache'
                    : 'This page is not cached',
            ],
        ]);

        // Child node: Purge This Page button
        $admin_bar->add_node([
            'id'     => 'acms-purge-this-page',
            'parent' => 'acms-cache-status',
            'title'  => 'Purge This Page',
            'href'   => '#',
            'meta'   => [
                'onclick' => 'return false;',
                'title'   => 'Remove this page from Nginx cache',
            ],
        ]);

        // Child node: link to Cache admin page
        $admin_bar->add_node([
            'id'     => 'acms-cache-manage',
            'parent' => 'acms-cache-status',
            'title'  => 'Manage Cache',
            'href'   => admin_url('admin.php?page=acms-pro-cache'),
        ]);
    }

    /**
     * Inline JS for admin bar purge buttons (frontend only)
     */
    public static function adminBarPurgeScript(): void
    {
        if (is_admin() || !current_user_can('manage_options')) {
            return;
        }
        ?>
        <script>
        document.addEventListener('DOMContentLoaded', function() {
            var statusNode = document.querySelector('#wp-admin-bar-acms-cache-status > .ab-item');
            var purgeBtn = document.getElementById('wp-admin-bar-acms-purge-this-page');
            var parentBar = document.getElementById('wp-admin-bar-acms-cache-status');

            function purgeThisPage() {
                var url = window.location.href.split('?')[0];
                if (statusNode) {
                    statusNode.innerHTML = '<span style="color:#f0ad4e;font-size:11px;">⟳ Purging…</span>';
                }
                fetch('<?php echo esc_url(rest_url('acms/v1/cache/purge-url')); ?>', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': '<?php echo wp_create_nonce('wp_rest'); ?>'
                    },
                    body: JSON.stringify({ url: url })
                })
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    if (statusNode) {
                        statusNode.innerHTML = '<span style="color:#888;font-size:11px;">○ Purged</span>';
                    }
                })
                .catch(function() {
                    if (statusNode) {
                        statusNode.innerHTML = '<span style="color:#e55;font-size:11px;">✕ Error</span>';
                    }
                });
            }

            // Parent node click → purge this page
            if (parentBar) {
                parentBar.querySelector('.ab-item').addEventListener('click', function(e) {
                    e.preventDefault();
                    purgeThisPage();
                });
            }

            // Submenu "Purge This Page" → same action
            if (purgeBtn) {
                purgeBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    purgeThisPage();
                });
            }
        });
        </script>
        <?php
    }

    /**
     * Check if current frontend page is cached.
     *
     * Uses acms_cache_urls DB table (source of truth) instead of filesystem,
     * because admin requests bypass Nginx cache and file_exists() is unreliable
     * when PHP-FPM user differs from Nginx worker user.
     */
    private static function isCurrentPageCached(): bool
    {
        global $wpdb;
        $table = Schema::cacheUrlsTable();

        // Build canonical URL (strip query string — Nginx cache key uses clean URI)
        $scheme = is_ssl() ? 'https' : 'http';
        $host = $_SERVER['HTTP_HOST'] ?? wp_parse_url(home_url(), PHP_URL_HOST);
        $uri = strtok($_SERVER['REQUEST_URI'] ?? '/', '?');
        $url = $scheme . '://' . $host . $uri;

        $status = $wpdb->get_var($wpdb->prepare(
            "SELECT status FROM {$table} WHERE url = %s LIMIT 1",
            $url
        ));

        return $status === 'cached';
    }

    // ─── Sitemap Parser ───────────────────────────────────────

    /**
     * HTTP GET that always goes through loopback (127.0.0.1).
     * Bypasses Cloudflare to get fresh content from local Nginx.
     * Needed because WP-CLI doesn't trigger Bootstrap's http_api_curl hook.
     */
    private static function loopbackGet(string $url): array|\WP_Error
    {
        $host = wp_parse_url($url, PHP_URL_HOST);
        if (!$host) {
            return new \WP_Error('invalid_url', 'Cannot parse host from URL');
        }

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 15,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_RESOLVE        => ["{$host}:443:127.0.0.1", "{$host}:80:127.0.0.1"],
            CURLOPT_HEADER         => true,
        ]);

        $raw = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $header_size = (int) curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($raw === false) {
            return new \WP_Error('http_request_failed', $error);
        }

        $body = substr($raw, $header_size);

        return [
            'response' => ['code' => $code],
            'body'     => $body,
        ];
    }

    /**
     * Parse sitemap index → extract all page URLs
     */
    private static function getUrlsFromSitemap(): array
    {
        $sitemap_url = home_url('/sitemap.xml');
        $urls = [];

        $response = self::loopbackGet($sitemap_url);

        if (is_wp_error($response)) {
            error_log('[ACMS CachePreload] Failed to fetch sitemap index: ' . $response->get_error_message());
            return [];
        }

        $body = wp_remote_retrieve_body($response);
        if (empty($body)) {
            return [];
        }

        libxml_use_internal_errors(true);
        $xml = simplexml_load_string($body);
        if (!$xml) {
            error_log('[ACMS CachePreload] Failed to parse sitemap index XML');
            return [];
        }

        $xml->registerXPathNamespace('sm', 'http://www.sitemaps.org/schemas/sitemap/0.9');

        $sitemap_locs = $xml->xpath('//sm:sitemap/sm:loc');
        if (empty($sitemap_locs)) {
            $url_locs = $xml->xpath('//sm:url/sm:loc');
            foreach ($url_locs as $loc) {
                $urls[] = (string) $loc;
            }
            return $urls;
        }

        foreach ($sitemap_locs as $sitemap_loc) {
            $child_url = (string) $sitemap_loc;
            $child_urls = self::parseChildSitemap($child_url);
            $urls = array_merge($urls, $child_urls);
        }

        return array_unique($urls);
    }

    /**
     * Parse a child sitemap XML and return URLs
     */
    private static function parseChildSitemap(string $sitemap_url): array
    {
        $response = self::loopbackGet($sitemap_url);

        if (is_wp_error($response)) {
            return [];
        }

        $body = wp_remote_retrieve_body($response);
        if (empty($body)) {
            return [];
        }

        libxml_use_internal_errors(true);
        $xml = simplexml_load_string($body);
        if (!$xml) {
            return [];
        }

        $xml->registerXPathNamespace('sm', 'http://www.sitemaps.org/schemas/sitemap/0.9');
        $url_locs = $xml->xpath('//sm:url/sm:loc');

        $urls = [];
        foreach ($url_locs as $loc) {
            $urls[] = (string) $loc;
        }

        return $urls;
    }

    // ─── Cache Purge ──────────────────────────────────────────

    // ─── Quick Sync ─────────────────────────────────────────

    /**
     * Sync DB status from disk cache files.
     * Scans cache dir for md5 hashes, matches against acms_cache_urls,
     * marks matched URLs as 'cached' and stale 'cached' as 'pending'.
     *
     * @return int Number of URLs updated to 'cached'
     */
    private static function quickSyncFromDisk(string $cache_path, string $table): int
    {
        global $wpdb;

        // Collect md5 hashes from disk (use sudo helper for permission-safe access)
        $diskHashes = [];
        $output = [];
        @exec("sudo /usr/local/bin/nginx-cache-purge list 2>/dev/null", $output);
        if (empty($output)) {
            $escaped = escapeshellarg(rtrim($cache_path, '/'));
            @exec("find {$escaped} -type f -maxdepth 3 2>/dev/null", $output);
        }
        foreach ($output as $line) {
            $hash = basename($line);
            if (strlen($hash) === 32 && ctype_xdigit($hash)) {
                $diskHashes[$hash] = true;
            }
        }

        if (empty($diskHashes)) {
            return 0;
        }

        // Process DB rows in batches
        $synced = 0;
        $batchSize = 2000;
        $offset = 0;

        do {
            $rows = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT id, url, status FROM {$table} LIMIT %d OFFSET %d",
                    $batchSize,
                    $offset
                ),
                ARRAY_A
            );

            if (empty($rows)) {
                break;
            }

            $toCached = [];
            $toPending = [];

            foreach ($rows as $row) {
                $parsed = wp_parse_url($row['url']);
                if (!$parsed || empty($parsed['host'])) {
                    continue;
                }
                $scheme = $parsed['scheme'] ?? 'https';
                $path = $parsed['path'] ?? '/';
                $hash = md5($scheme . 'GET' . $parsed['host'] . $path);

                if (isset($diskHashes[$hash])) {
                    if ($row['status'] !== 'cached') {
                        $toCached[] = (int) $row['id'];
                    }
                } elseif ($row['status'] === 'cached') {
                    $toPending[] = (int) $row['id'];
                }
            }

            if (!empty($toCached)) {
                $ids = implode(',', $toCached);
                $now = current_time('mysql');
                $wpdb->query("UPDATE {$table} SET status = 'cached', last_warmed_at = '{$now}' WHERE id IN ({$ids})");
                $synced += count($toCached);
            }

            if (!empty($toPending)) {
                $ids = implode(',', $toPending);
                $wpdb->query("UPDATE {$table} SET status = 'pending', http_code = NULL, response_time_ms = NULL WHERE id IN ({$ids})");
            }

            $offset += $batchSize;
        } while (count($rows) === $batchSize);

        return $synced;
    }

    // ─── Cache Path ─────────────────────────────────────────

    /**
     * Get the configured nginx fastcgi cache path.
     * Configurable via Settings > Cache Path in the Cache admin page.
     */
    public static function getCachePath(): string
    {
        $settings = get_option('acms_general_settings', []);
        $path = $settings['cache_path'] ?? '/home/productreviewsorg/cache/fastcgi/';
        return rtrim($path, '/') . '/';
    }

    // ─── Per-URL Purge ───────────────────────────────────────

    /**
     * Purge a single URL from nginx fastcgi cache (blocking).
     *
     * Sends a request with X-Purge-Cache header → Nginx bypasses cache,
     * PHP-FPM handles request, Nginx writes fresh cache file.
     * This effectively purges AND warms in one step.
     */
    public static function purgeUrl(string $url, bool $blocking = true): bool
    {
        $parsed = wp_parse_url($url);
        if (!$parsed || empty($parsed['host'])) {
            return false;
        }

        // Step 1: Delete old cache file so Nginx returns MISS
        $scheme = $parsed['scheme'] ?? 'https';
        $path = $parsed['path'] ?? '/';
        $hash = md5($scheme . 'GET' . $parsed['host'] . $path);
        $cache_path = self::getCachePath();
        $file = $cache_path . substr($hash, -1) . '/' . substr($hash, -3, 2) . '/' . $hash;
        $escaped = escapeshellarg($file);
        @exec("sudo /usr/local/bin/nginx-cache-purge purge {$escaped} 2>/dev/null");

        // Step 2: Warm the URL (no bypass header → Nginx creates new cache file)
        $response = wp_remote_get($url, [
            'timeout'   => $blocking ? 10 : 0.5,
            'blocking'  => $blocking,
            'sslverify' => false,
        ]);

        if (!$blocking) {
            self::markUrlPending($url);
            return true;
        }

        $success = !is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200;

        if ($success) {
            self::markUrlCached($url);
        } else {
            self::markUrlPending($url);
        }

        return $success;
    }

    /**
     * Mark a URL as pending in acms_cache_urls (after purge).
     */
    private static function markUrlPending(string $url): void
    {
        global $wpdb;
        $table = Schema::cacheUrlsTable();
        $tableExists = $wpdb->get_var("SHOW TABLES LIKE '{$table}'") === $table;
        if (!$tableExists) {
            return;
        }
        $wpdb->update(
            $table,
            ['status' => 'pending', 'http_code' => null, 'response_time_ms' => null],
            ['url' => $url],
            ['%s', null, null],
            ['%s']
        );
    }

    /**
     * Mark a URL as cached in acms_cache_urls (after successful purge+warm).
     */
    private static function markUrlCached(string $url): void
    {
        global $wpdb;
        $table = Schema::cacheUrlsTable();
        $tableExists = $wpdb->get_var("SHOW TABLES LIKE '{$table}'") === $table;
        if (!$tableExists) {
            return;
        }
        $wpdb->update(
            $table,
            ['status' => 'cached', 'http_code' => 200],
            ['url' => $url],
            ['%s', '%d'],
            ['%s']
        );
    }

    /**
     * Ensure a URL exists in the cache queue (INSERT IGNORE).
     */
    private static function ensureUrlInQueue(string $url, string $type = 'post', int $priority = 50): void
    {
        global $wpdb;
        $table = Schema::cacheUrlsTable();
        if ($wpdb->get_var("SHOW TABLES LIKE '{$table}'") !== $table) {
            return;
        }
        $wpdb->query($wpdb->prepare(
            "INSERT IGNORE INTO {$table} (url, url_type, status, priority) VALUES (%s, %s, 'pending', %d)",
            $url, $type, $priority
        ));
    }

    /**
     * Remove a URL from the cache queue.
     */
    private static function removeUrlFromQueue(string $url): void
    {
        global $wpdb;
        $table = Schema::cacheUrlsTable();
        if ($wpdb->get_var("SHOW TABLES LIKE '{$table}'") !== $table) {
            return;
        }
        $wpdb->delete($table, ['url' => $url], ['%s']);
    }

    /**
     * Purge multiple URLs related to a post (permalink, homepage, feeds).
     */
    public static function purgePost(int $postId): void
    {
        $url = get_permalink($postId);
        if (!$url) {
            return;
        }

        // Collect all URLs to purge
        $purgeUrls = [$url];

        // Related pages
        $purgeUrls[] = home_url('/');

        $blog_url = get_post_type_archive_link('post');
        if ($blog_url) {
            $purgeUrls[] = $blog_url;
            for ($i = 2; $i <= 5; $i++) {
                $purgeUrls[] = trailingslashit($blog_url) . 'page/' . $i . '/';
            }
        }

        // Post's category/term archives
        $taxonomies = get_object_taxonomies(get_post_type($postId), 'names');
        foreach ($taxonomies as $tax) {
            $terms = get_the_terms($postId, $tax);
            if ($terms && !is_wp_error($terms)) {
                foreach ($terms as $term) {
                    $term_link = get_term_link($term);
                    if ($term_link && !is_wp_error($term_link)) {
                        $purgeUrls[] = $term_link;
                    }
                }
            }
        }

        // Purge the post itself (blocking)
        self::purgeUrl($url, true);

        // Purge related pages (non-blocking)
        foreach (array_slice($purgeUrls, 1) as $relatedUrl) {
            self::purgeUrl($relatedUrl, false);
        }

        // Purge from Cloudflare (batch all URLs in one API call)
        self::cloudflarePurgeUrls($purgeUrls);
    }

    // ─── Cloudflare Cache Purge ─────────────────────────────

    /**
     * Read Cloudflare credentials from /etc/azwp/config (set by azwp CLI).
     * Returns [zone, email, apiKey] or null if not configured.
     */
    private static function getCloudflareCredentials(): ?array
    {
        $config_file = '/etc/azwp/config';
        if (!is_readable($config_file)) {
            return null;
        }

        $config = [];
        $lines = @file($config_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if (!$lines) {
            return null;
        }
        foreach ($lines as $line) {
            if (str_contains($line, '=')) {
                [$key, $value] = explode('=', $line, 2);
                $config[trim($key)] = trim($value, " \t\n\r\0\x0B\"'");
            }
        }

        $zone   = $config['CF_ZONE_ID'] ?? '';
        $email  = $config['CF_EMAIL'] ?? '';
        $apiKey = $config['CF_API_KEY'] ?? '';

        if (empty($zone) || empty($email) || empty($apiKey)) {
            return null;
        }

        return [$zone, $email, $apiKey];
    }

    /**
     * Purge specific URLs from Cloudflare edge cache.
     * Silently skips if not configured.
     */
    private static function cloudflarePurgeUrls(array $urls): void
    {
        if (empty($urls)) {
            return;
        }

        $cf = self::getCloudflareCredentials();
        if (!$cf) {
            return;
        }
        [$zone, $email, $apiKey] = $cf;

        // Cloudflare API allows up to 30 URLs per purge request
        $chunks = array_chunk(array_values(array_unique($urls)), 30);
        foreach ($chunks as $chunk) {
            wp_remote_post(
                "https://api.cloudflare.com/client/v4/zones/{$zone}/purge_cache",
                [
                    'timeout'   => 5,
                    'blocking'  => false,
                    'headers'   => [
                        'X-Auth-Email' => $email,
                        'X-Auth-Key'   => $apiKey,
                        'Content-Type' => 'application/json',
                    ],
                    'body'      => wp_json_encode(['files' => $chunk]),
                    'sslverify' => true,
                ]
            );
        }
    }

    /**
     * Purge everything from Cloudflare edge cache.
     */
    private static function cloudflarePurgeAll(): void
    {
        $cf = self::getCloudflareCredentials();
        if (!$cf) {
            return;
        }
        [$zone, $email, $apiKey] = $cf;

        wp_remote_post(
            "https://api.cloudflare.com/client/v4/zones/{$zone}/purge_cache",
            [
                'timeout'   => 5,
                'blocking'  => false,
                'headers'   => [
                    'X-Auth-Email' => $email,
                    'X-Auth-Key'   => $apiKey,
                    'Content-Type' => 'application/json',
                ],
                'body'      => wp_json_encode(['purge_everything' => true]),
                'sslverify' => true,
            ]
        );
    }

    // ─── Auto-purge Hooks ────────────────────────────────────

    /**
     * Auto-purge when post status changes (publish, update, trash).
     */
    public static function autoPurgeOnPostChange(string $new_status, string $old_status, \WP_Post $post): void
    {
        if ($new_status === $old_status && $new_status !== 'publish') {
            return;
        }

        // Purge on: publish, update (publish→publish), trash, unpublish
        if (in_array($new_status, ['publish', 'trash'], true) || $old_status === 'publish') {
            self::purgePost($post->ID);
        }

        // New publish: add URL to cache queue so total count stays accurate
        if ($new_status === 'publish' && $old_status !== 'publish') {
            $url = get_permalink($post->ID);
            if ($url) {
                self::ensureUrlInQueue($url, 'post', 90);
            }
        }

        // Trash/unpublish: remove URL from cache queue
        if ($new_status !== 'publish' && $old_status === 'publish') {
            $url = get_permalink($post->ID);
            if ($url) {
                self::removeUrlFromQueue($url);
            }
        }
    }

    /**
     * Auto-purge post cache when a new comment is added.
     */
    public static function autoPurgeOnComment(int $commentId, $comment): void
    {
        if (is_object($comment) && !empty($comment->comment_post_ID)) {
            $post = get_post($comment->comment_post_ID);
            if ($post && $post->post_status === 'publish') {
                self::purgeUrl(get_permalink($post->ID));
            }
        }
    }

    /**
     * Auto-purge term archive cache when term is edited/deleted.
     */
    public static function autoPurgeOnTermEdit(int $termId, int $ttId, string $taxonomy): void
    {
        $term_link = get_term_link($termId, $taxonomy);
        if ($term_link && !is_wp_error($term_link)) {
            self::purgeUrl($term_link);
        }
        // Also purge homepage
        self::purgeUrl(home_url('/'));
    }

    // ─── Purge All Files ─────────────────────────────────────

    /**
     * Purge all nginx fastcgi cache files.
     * Uses shell find -delete for speed (107K+ files), falls back to PHP iterator.
     */
    private static function purgeAllFiles(): void
    {
        $cache_path = rtrim(self::getCachePath(), '/');

        // Use sudo helper script (NOPASSWD) to purge cache
        $escaped = escapeshellarg(rtrim($cache_path, '/'));
        $output = [];
        @exec("sudo /usr/local/bin/nginx-cache-purge {$escaped} purge-all 2>&1", $output, $code);

        // Update stats file so UI reflects 0 files
        $statsFile = dirname($cache_path) . '/cache-stats.json';
        @file_put_contents($statsFile, json_encode([
            'files' => 0,
            'size' => 0,
            'updated' => date('Y-m-d H:i:s'),
        ]));

        error_log(sprintf('[ACMS CachePreload] Purged all cache files (exit=%d)', $code));
    }
}
