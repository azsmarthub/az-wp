<?php
/**
 * Product Update Cron Job
 *
 * Marks stale products for price/rating/stock update and spawns
 * parallel workers to process them.
 *
 * Flow: scraped → update → updating → scraped
 *
 * @package AffiliateCMS\Pro\Core
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro\Core;

use AffiliateCMS\Pro\Repositories\ProductRepository;

class QuickUpdateCron
{
    /**
     * Hook name for the cron job
     */
    public const CRON_HOOK = 'acms_quick_update_products';

    /**
     * Max products to mark per cron run (prevents marking thousands at once)
     */
    private const MARK_LIMIT = 100;

    /**
     * Default interval hours (used when settings not configured)
     */
    private const DEFAULT_INTERVAL_HOURS = 24;

    /**
     * Singleton instance
     */
    private static ?QuickUpdateCron $instance = null;

    private ProductRepository $productRepo;
    private ProviderManager $providerManager;

    /**
     * Get singleton instance
     */
    public static function instance(): QuickUpdateCron
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Private constructor for singleton
     */
    private function __construct()
    {
        $this->productRepo = ProductRepository::instance();
        $this->providerManager = ProviderManager::instance();
    }

    /**
     * Register the cron job
     */
    public function register(): void
    {
        add_action(self::CRON_HOOK, [$this, 'updateProducts']);

        // WP-Cron as safety net (server cron is primary)
        if (!wp_next_scheduled(self::CRON_HOOK)) {
            wp_schedule_event(time(), 'hourly', self::CRON_HOOK);
        }
    }

    /**
     * Main cron handler: mark stale products + spawn workers + recover stuck
     *
     * Phase 1: Recover products stuck in 'updating' for > 10 minutes
     * Phase 2: Mark stale 'scraped' products as 'update'
     * Phase 3: Spawn parallel workers to process them
     */
    public function updateProducts(): void
    {
        if (!$this->providerManager->hasAnyProvider()) {
            return;
        }

        // Check if Auto Update is enabled
        $settings = get_option('acms_automation', []);
        $enabled = !empty($settings['update_enabled']);

        // Fallback: check old setting name for migration
        if (!$enabled && !empty($settings['rescrape_enabled'])) {
            $enabled = true;
        }

        if (!$enabled) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('[ACMS UpdateCron] Auto Update is disabled, skipping');
            }
            return;
        }

        global $wpdb;
        $table = $this->productRepo->getTable();

        // Phase 1: Recover stuck 'updating' products (> 10 min)
        $stuckThreshold = gmdate('Y-m-d H:i:s', current_time('timestamp') - 600);
        $recovered = $wpdb->query(
            "UPDATE {$table}
             SET status = 'update'
             WHERE status = 'updating'
             AND updated_at < '{$stuckThreshold}'"
        );
        if ($recovered > 0) {
            error_log("[ACMS UpdateCron] Recovered {$recovered} stuck 'updating' products");
        }

        // Phase 2: Mark stale products as 'update'
        $interval = (int) ($settings['update_interval'] ?? $settings['rescrape_interval'] ?? self::DEFAULT_INTERVAL_HOURS);
        $threshold = gmdate('Y-m-d H:i:s', current_time('timestamp') - ($interval * 3600));

        $marked = $wpdb->query(
            "UPDATE {$table}
             SET status = 'update'
             WHERE status = 'scraped'
             AND COALESCE(quick_update_at, last_scraped_at) < '{$threshold}'
             ORDER BY COALESCE(quick_update_at, last_scraped_at, created_at) ASC
             LIMIT " . self::MARK_LIMIT
        );

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("[ACMS UpdateCron] Marked {$marked} stale products for update");
        }

        // Phase 3: Spawn workers if there are products to process
        $queued = $this->productRepo->countUpdateQueued();
        if ($queued > 0) {
            $maxWorkers = (int) ($settings['update_worker_count'] ?? 3);
            $workerCount = min($maxWorkers, $queued);
            Bootstrap::instance()->spawnQuickUpdateWorkers($workerCount);

            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("[ACMS UpdateCron] Spawned {$workerCount} workers for {$queued} queued products");
            }
        }
    }

    /**
     * Run the update manually (for testing or manual trigger)
     *
     * @return array Result with stats
     */
    public function runManually(): array
    {
        $startTime = microtime(true);

        ob_start();
        $this->updateProducts();
        ob_end_clean();

        $duration = round((microtime(true) - $startTime) * 1000);
        $queued = $this->productRepo->countUpdateQueued();

        return [
            'success' => true,
            'message' => "Update cron completed. {$queued} products queued.",
            'duration_ms' => $duration,
            'queued' => $queued,
        ];
    }

    /**
     * Unschedule the cron job
     */
    public function unschedule(): void
    {
        $timestamp = wp_next_scheduled(self::CRON_HOOK);
        if ($timestamp) {
            wp_unschedule_event($timestamp, self::CRON_HOOK);
        }
    }

    /**
     * Get next scheduled run time
     *
     * @return int|false Unix timestamp or false if not scheduled
     */
    public function getNextRun()
    {
        return wp_next_scheduled(self::CRON_HOOK);
    }

    /**
     * Get statistics about product updates
     *
     * @return array Statistics
     */
    public function getStats(): array
    {
        global $wpdb;
        $table = $this->productRepo->getTable();

        $settings = get_option('acms_automation', []);
        $interval = (int) ($settings['update_interval'] ?? $settings['rescrape_interval'] ?? self::DEFAULT_INTERVAL_HOURS);
        $threshold = gmdate('Y-m-d H:i:s', current_time('timestamp') - ($interval * 3600));

        $needsUpdate = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$table}
             WHERE status = 'scraped'
             AND COALESCE(quick_update_at, last_scraped_at) < '{$threshold}'"
        );

        $queued = $this->productRepo->countUpdateQueued();

        $updating = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$table} WHERE status = 'updating'"
        );

        $recentlyUpdated = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$table}
             WHERE quick_update_at >= '{$threshold}'"
        );

        $totalQuickUpdates = $wpdb->get_var(
            "SELECT SUM(quick_update_count) FROM {$table} WHERE quick_update_count > 0"
        );

        return [
            'needs_update' => (int) $needsUpdate,
            'queued' => (int) $queued,
            'updating' => (int) $updating,
            'recently_updated' => (int) $recentlyUpdated,
            'total_quick_updates' => (int) $totalQuickUpdates,
            'next_run' => $this->getNextRun(),
            'threshold_hours' => $interval,
        ];
    }
}
