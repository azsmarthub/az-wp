<?php
/**
 * Post Type Manager - Register custom post types
 *
 * @package AffiliateCMS\Pro
 */

namespace AffiliateCMS\Pro\Core;

class PostTypeManager
{
    /**
     * Option name for post type settings
     */
    const OPTION_NAME = 'acms_post_types';

    /**
     * Initialize the post type manager
     */
    public function init()
    {
        add_action('init', [$this, 'registerPostTypes'], 5);
        add_action('init', [$this, 'registerTaxonomies'], 5);

        // Ensure excerpt panel is visible in Gutenberg for ACMS post types
        add_action('enqueue_block_editor_assets', [$this, 'enableExcerptPanel']);
        add_action('admin_init', [$this, 'ensureExcerptPreference']);

        // Add custom fields for Brand taxonomy
        add_action('acms_reviews_brand_add_form_fields', [$this, 'addBrandFields']);
        add_action('acms_reviews_brand_edit_form_fields', [$this, 'editBrandFields'], 10, 2);
        add_action('created_acms_reviews_brand', [$this, 'saveBrandFields']);
        add_action('edited_acms_reviews_brand', [$this, 'saveBrandFields']);

        // Add column for brand content
        add_filter('manage_edit-acms_reviews_brand_columns', [$this, 'brandColumns']);
        add_filter('manage_acms_reviews_brand_custom_column', [$this, 'brandColumnContent'], 10, 3);
    }

    /**
     * Get post type settings
     *
     * @return array
     */
    public static function getSettings()
    {
        $defaults = [
            'reviews' => [
                'enabled' => false,
                'slug' => 'reviews',
                'menu_name' => 'Reviews',
                'singular' => 'Review',
                'plural' => 'Reviews',
                'icon' => 'dashicons-star-half'
            ],
            'deals' => [
                'enabled' => false,
                'slug' => 'deals',
                'menu_name' => 'Deals',
                'singular' => 'Deal',
                'plural' => 'Deals',
                'icon' => 'dashicons-tag'
            ],
            'guides' => [
                'enabled' => false,
                'slug' => 'guides',
                'menu_name' => 'Guides',
                'singular' => 'Guide',
                'plural' => 'Guides',
                'icon' => 'dashicons-book'
            ]
        ];

        $saved = get_option(self::OPTION_NAME, []);

        // Merge saved settings with defaults
        foreach ($defaults as $key => $default) {
            if (isset($saved[$key])) {
                $defaults[$key] = array_merge($default, $saved[$key]);
            }
        }

        return $defaults;
    }

    /**
     * Save post type settings
     *
     * @param array $settings
     * @return bool
     */
    public static function saveSettings($settings)
    {
        $sanitized = [];

        foreach (['reviews', 'deals', 'guides'] as $type) {
            if (isset($settings[$type])) {
                $sanitized[$type] = [
                    'enabled' => !empty($settings[$type]['enabled']),
                    'slug' => sanitize_title($settings[$type]['slug'] ?? $type),
                    'menu_name' => sanitize_text_field($settings[$type]['menu_name'] ?? ucfirst($type)),
                    'singular' => sanitize_text_field($settings[$type]['singular'] ?? ucfirst($type)),
                    'plural' => sanitize_text_field($settings[$type]['plural'] ?? ucfirst($type) . 's'),
                    'icon' => sanitize_text_field($settings[$type]['icon'] ?? 'dashicons-admin-post')
                ];
            }
        }

        $result = update_option(self::OPTION_NAME, $sanitized);

        // Flush rewrite rules when settings change
        flush_rewrite_rules();

        return $result;
    }

    /**
     * Ensure excerpt panel is visible in Gutenberg for ACMS post types
     */
    public function enableExcerptPanel()
    {
        $screen = get_current_screen();
        if (!$screen) {
            return;
        }

        $acms_post_types = ['acms_reviews', 'acms_deals', 'acms_guides'];
        if (!in_array($screen->post_type, $acms_post_types, true)) {
            return;
        }

        // Inline script to enable excerpt panel in Gutenberg (compatible with WP 6.x)
        wp_add_inline_script('wp-edit-post', "
            wp.domReady(function() {
                // Method 1: Try modern preferences API (WP 6.0+)
                if (wp.data.dispatch('core/preferences')) {
                    var prefsDispatch = wp.data.dispatch('core/preferences');
                    var prefsSelect = wp.data.select('core/preferences');

                    // Enable excerpt in document settings (Preferences modal)
                    var excerptEnabled = prefsSelect.get('core/edit-post', 'enablePostExcerpt');
                    if (excerptEnabled === false) {
                        prefsDispatch.set('core/edit-post', 'enablePostExcerpt', true);
                    }
                }

                // Method 2: Fallback for older WP or panel visibility
                var editPostDispatch = wp.data.dispatch('core/edit-post');
                var editPostSelect = wp.data.select('core/edit-post');

                if (editPostDispatch && editPostSelect) {
                    // Check if panel is enabled in preferences
                    var panels = editPostSelect.getPreference ? editPostSelect.getPreference('panels') : null;
                    if (panels) {
                        var excerptPanel = panels['post-excerpt'];
                        if (excerptPanel && excerptPanel.enabled === false) {
                            if (editPostDispatch.toggleEditorPanelEnabled) {
                                editPostDispatch.toggleEditorPanelEnabled('post-excerpt');
                            }
                        }
                    }

                    // Also check hiddenBlockTypes and remove excerpt if hidden
                    var hiddenTypes = editPostSelect.getPreference ? editPostSelect.getPreference('hiddenBlockTypes') : [];
                    if (hiddenTypes && hiddenTypes.includes && hiddenTypes.includes('core/post-excerpt')) {
                        if (editPostDispatch.showBlockTypes) {
                            editPostDispatch.showBlockTypes(['core/post-excerpt']);
                        }
                    }
                }
            });
        ");
    }

    /**
     * Ensure excerpt preference is enabled for ACMS post types (server-side)
     * This sets the user preference in database to always show excerpt panel
     */
    public function ensureExcerptPreference()
    {
        // Only run on post edit screens for ACMS post types
        global $pagenow;
        if (!in_array($pagenow, ['post.php', 'post-new.php'], true)) {
            return;
        }

        // Check post type
        $post_type = '';
        if (isset($_GET['post'])) {
            $post_type = get_post_type((int) $_GET['post']);
        } elseif (isset($_GET['post_type'])) {
            $post_type = sanitize_key($_GET['post_type']);
        }

        $acms_post_types = ['acms_reviews', 'acms_deals', 'acms_guides'];
        if (!in_array($post_type, $acms_post_types, true)) {
            return;
        }

        // Get current user preferences
        $user_id = get_current_user_id();
        if (!$user_id) {
            return;
        }

        $prefs = get_user_meta($user_id, 'wp_persisted_preferences', true);
        if (!is_array($prefs)) {
            $prefs = [];
        }

        $needs_update = false;

        // Ensure core/edit-post preferences exist
        if (!isset($prefs['core/edit-post'])) {
            $prefs['core/edit-post'] = [];
        }

        // Enable excerpt in document settings (WP 6.x structure)
        // The key for excerpt visibility in Preferences > Document settings
        if (!isset($prefs['core/edit-post']['postExcerpt']) || $prefs['core/edit-post']['postExcerpt'] !== true) {
            $prefs['core/edit-post']['postExcerpt'] = true;
            $needs_update = true;
        }

        // Also check panels structure for older WP versions
        if (!isset($prefs['core/edit-post']['panels'])) {
            $prefs['core/edit-post']['panels'] = [];
        }
        if (!isset($prefs['core/edit-post']['panels']['post-excerpt']) ||
            (isset($prefs['core/edit-post']['panels']['post-excerpt']['enabled']) &&
             $prefs['core/edit-post']['panels']['post-excerpt']['enabled'] === false)) {
            $prefs['core/edit-post']['panels']['post-excerpt'] = ['enabled' => true, 'opened' => true];
            $needs_update = true;
        }

        // Save if updated
        if ($needs_update) {
            update_user_meta($user_id, 'wp_persisted_preferences', $prefs);
        }
    }

    /**
     * Register custom post types
     */
    public function registerPostTypes()
    {
        $settings = self::getSettings();

        foreach ($settings as $type => $config) {
            if (empty($config['enabled'])) {
                continue;
            }

            $post_type = 'acms_' . $type;

            $labels = [
                'name'                  => $config['plural'],
                'singular_name'         => $config['singular'],
                'menu_name'             => $config['menu_name'],
                'name_admin_bar'        => $config['singular'],
                'add_new'               => __('Add New', 'affiliatecms-pro'),
                'add_new_item'          => sprintf(__('Add New %s', 'affiliatecms-pro'), $config['singular']),
                'new_item'              => sprintf(__('New %s', 'affiliatecms-pro'), $config['singular']),
                'edit_item'             => sprintf(__('Edit %s', 'affiliatecms-pro'), $config['singular']),
                'view_item'             => sprintf(__('View %s', 'affiliatecms-pro'), $config['singular']),
                'all_items'             => sprintf(__('All %s', 'affiliatecms-pro'), $config['plural']),
                'search_items'          => sprintf(__('Search %s', 'affiliatecms-pro'), $config['plural']),
                'parent_item_colon'     => sprintf(__('Parent %s:', 'affiliatecms-pro'), $config['singular']),
                'not_found'             => sprintf(__('No %s found.', 'affiliatecms-pro'), strtolower($config['plural'])),
                'not_found_in_trash'    => sprintf(__('No %s found in Trash.', 'affiliatecms-pro'), strtolower($config['plural'])),
                'featured_image'        => __('Featured Image', 'affiliatecms-pro'),
                'set_featured_image'    => __('Set featured image', 'affiliatecms-pro'),
                'remove_featured_image' => __('Remove featured image', 'affiliatecms-pro'),
                'use_featured_image'    => __('Use as featured image', 'affiliatecms-pro'),
                'archives'              => sprintf(__('%s Archives', 'affiliatecms-pro'), $config['singular']),
                'insert_into_item'      => sprintf(__('Insert into %s', 'affiliatecms-pro'), strtolower($config['singular'])),
                'uploaded_to_this_item' => sprintf(__('Uploaded to this %s', 'affiliatecms-pro'), strtolower($config['singular'])),
                'filter_items_list'     => sprintf(__('Filter %s list', 'affiliatecms-pro'), strtolower($config['plural'])),
                'items_list_navigation' => sprintf(__('%s list navigation', 'affiliatecms-pro'), $config['plural']),
                'items_list'            => sprintf(__('%s list', 'affiliatecms-pro'), $config['plural']),
            ];

            $args = [
                'labels'             => $labels,
                'public'             => true,
                'publicly_queryable' => true,
                'show_ui'            => true,
                'show_in_menu'       => true,
                'query_var'          => true,
                'rewrite'            => ['slug' => $config['slug'], 'with_front' => false],
                'capability_type'    => 'post',
                'has_archive'        => true,
                'hierarchical'       => false,
                'menu_position'      => 5,
                'menu_icon'          => $config['icon'],
                'supports'           => [
                    'title',
                    'editor',
                    'author',
                    'thumbnail',
                    'excerpt',
                    'comments',
                    'revisions',
                    'custom-fields'
                ],
                'show_in_rest'       => true, // Enable Gutenberg editor
                'taxonomies'         => ['acms_' . $type . '_category', 'acms_' . $type . '_tag'],
            ];

            register_post_type($post_type, $args);
        }

        // Auto-flush rewrite rules when CPT rules are missing
        $this->maybeFlushRewrites($settings);
    }

    /**
     * Flush rewrite rules if registered CPT slugs are missing from rules
     */
    private function maybeFlushRewrites(array $settings): void
    {
        $rules = get_option('rewrite_rules');
        if (!is_array($rules)) {
            flush_rewrite_rules();
            return;
        }

        foreach ($settings as $type => $config) {
            if (empty($config['enabled'])) {
                continue;
            }
            $slug = $config['slug'];
            // Check if at least one rule exists for this CPT slug
            $found = false;
            foreach ($rules as $rule => $rewrite) {
                if (strpos($rule, $slug) === 0) {
                    $found = true;
                    break;
                }
            }
            if (!$found) {
                flush_rewrite_rules();
                return;
            }
        }
    }

    /**
     * Register custom taxonomies for post types
     */
    public function registerTaxonomies()
    {
        $settings = self::getSettings();

        foreach ($settings as $type => $config) {
            if (empty($config['enabled'])) {
                continue;
            }

            $post_type = 'acms_' . $type;

            // Register Category taxonomy
            $cat_labels = [
                'name'              => sprintf(__('%s Categories', 'affiliatecms-pro'), $config['singular']),
                'singular_name'     => sprintf(__('%s Category', 'affiliatecms-pro'), $config['singular']),
                'search_items'      => __('Search Categories', 'affiliatecms-pro'),
                'all_items'         => __('All Categories', 'affiliatecms-pro'),
                'parent_item'       => __('Parent Category', 'affiliatecms-pro'),
                'parent_item_colon' => __('Parent Category:', 'affiliatecms-pro'),
                'edit_item'         => __('Edit Category', 'affiliatecms-pro'),
                'update_item'       => __('Update Category', 'affiliatecms-pro'),
                'add_new_item'      => __('Add New Category', 'affiliatecms-pro'),
                'new_item_name'     => __('New Category Name', 'affiliatecms-pro'),
                'menu_name'         => __('Categories', 'affiliatecms-pro'),
            ];

            register_taxonomy('acms_' . $type . '_category', $post_type, [
                'hierarchical'      => true,
                'labels'            => $cat_labels,
                'show_ui'           => true,
                'show_admin_column' => true,
                'query_var'         => true,
                'rewrite'           => ['slug' => $config['slug'] . '-category'],
                'show_in_rest'      => true,
            ]);

            // Register Brand taxonomy (only for reviews)
            // NOTE: Public URLs disabled - use /brand/ from SEO Brands instead
            // This taxonomy is for internal linking only (reviews to brands)
            if ($type === 'reviews') {
                $brand_labels = [
                    'name'              => __('Brands (Internal)', 'affiliatecms-pro'),
                    'singular_name'     => __('Brand', 'affiliatecms-pro'),
                    'search_items'      => __('Search Brands', 'affiliatecms-pro'),
                    'all_items'         => __('All Brands', 'affiliatecms-pro'),
                    'parent_item'       => __('Parent Brand', 'affiliatecms-pro'),
                    'parent_item_colon' => __('Parent Brand:', 'affiliatecms-pro'),
                    'edit_item'         => __('Edit Brand', 'affiliatecms-pro'),
                    'update_item'       => __('Update Brand', 'affiliatecms-pro'),
                    'add_new_item'      => __('Add New Brand', 'affiliatecms-pro'),
                    'new_item_name'     => __('New Brand Name', 'affiliatecms-pro'),
                    'menu_name'         => __('Brands (Internal)', 'affiliatecms-pro'),
                ];

                register_taxonomy('acms_reviews_brand', $post_type, [
                    'hierarchical'      => true,
                    'labels'            => $brand_labels,
                    'show_ui'           => true,
                    'show_admin_column' => true,
                    'query_var'         => false,  // No public query var
                    'publicly_queryable' => false, // No public URLs
                    'rewrite'           => false,  // No rewrite rules (use /brand/ instead)
                    'show_in_rest'      => true,
                ]);
            }

            // Register Tag taxonomy
            $tag_labels = [
                'name'                       => sprintf(__('%s Tags', 'affiliatecms-pro'), $config['singular']),
                'singular_name'              => sprintf(__('%s Tag', 'affiliatecms-pro'), $config['singular']),
                'search_items'               => __('Search Tags', 'affiliatecms-pro'),
                'popular_items'              => __('Popular Tags', 'affiliatecms-pro'),
                'all_items'                  => __('All Tags', 'affiliatecms-pro'),
                'edit_item'                  => __('Edit Tag', 'affiliatecms-pro'),
                'update_item'                => __('Update Tag', 'affiliatecms-pro'),
                'add_new_item'               => __('Add New Tag', 'affiliatecms-pro'),
                'new_item_name'              => __('New Tag Name', 'affiliatecms-pro'),
                'separate_items_with_commas' => __('Separate tags with commas', 'affiliatecms-pro'),
                'add_or_remove_items'        => __('Add or remove tags', 'affiliatecms-pro'),
                'choose_from_most_used'      => __('Choose from the most used tags', 'affiliatecms-pro'),
                'not_found'                  => __('No tags found.', 'affiliatecms-pro'),
                'menu_name'                  => __('Tags', 'affiliatecms-pro'),
            ];

            register_taxonomy('acms_' . $type . '_tag', $post_type, [
                'hierarchical'          => false,
                'labels'                => $tag_labels,
                'show_ui'               => true,
                'show_admin_column'     => true,
                'update_count_callback' => '_update_post_term_count',
                'query_var'             => true,
                'rewrite'               => ['slug' => $config['slug'] . '-tag'],
                'show_in_rest'          => true,
            ]);
        }
    }

    /**
     * Check if a post type is enabled
     *
     * @param string $type Post type key (reviews, deals, guides)
     * @return bool
     */
    public static function isEnabled(string $type): bool
    {
        $settings = self::getSettings();
        return !empty($settings[$type]['enabled']);
    }

    /**
     * Get or create a brand term for the reviews post type
     *
     * @param string $brandName Brand name
     * @return int|false Term ID or false on failure
     */
    public static function getOrCreateBrand(string $brandName): int|false
    {
        if (empty($brandName) || !self::isEnabled('reviews')) {
            return false;
        }

        $taxonomy = 'acms_reviews_brand';

        // Check if term exists
        $term = term_exists($brandName, $taxonomy);

        if ($term) {
            return (int) $term['term_id'];
        }

        // Create new term
        $result = wp_insert_term($brandName, $taxonomy, [
            'slug' => sanitize_title($brandName),
        ]);

        if (is_wp_error($result)) {
            return false;
        }

        return (int) $result['term_id'];
    }

    /**
     * Add custom fields to Brand add form
     */
    public function addBrandFields(): void
    {
        ?>
        <div class="form-field">
            <label for="brand_content"><?php esc_html_e('Content', 'affiliatecms-pro'); ?></label>
            <textarea name="brand_content" id="brand_content" rows="5" cols="40"></textarea>
            <p class="description"><?php esc_html_e('Custom content for the brand archive page.', 'affiliatecms-pro'); ?></p>
        </div>
        <div class="form-field">
            <label for="brand_logo"><?php esc_html_e('Logo URL', 'affiliatecms-pro'); ?></label>
            <input type="url" name="brand_logo" id="brand_logo" value="" />
            <p class="description"><?php esc_html_e('URL to the brand logo image.', 'affiliatecms-pro'); ?></p>
        </div>
        <div class="form-field">
            <label for="brand_thumbnail"><?php esc_html_e('Thumbnail Image', 'affiliatecms-pro'); ?></label>
            <input type="url" name="brand_thumbnail" id="brand_thumbnail" value="" />
            <p class="description"><?php esc_html_e('Featured image for the brand archive page.', 'affiliatecms-pro'); ?></p>
        </div>
        <div class="form-field">
            <label for="brand_og_image"><?php esc_html_e('OG Image (Social Share)', 'affiliatecms-pro'); ?></label>
            <input type="url" name="brand_og_image" id="brand_og_image" value="" />
            <p class="description"><?php esc_html_e('Image for social media sharing (recommended: 1200x630px).', 'affiliatecms-pro'); ?></p>
        </div>
        <div class="form-field">
            <label for="brand_website"><?php esc_html_e('Website', 'affiliatecms-pro'); ?></label>
            <input type="url" name="brand_website" id="brand_website" value="" />
            <p class="description"><?php esc_html_e('Official brand website URL.', 'affiliatecms-pro'); ?></p>
        </div>
        <?php
    }

    /**
     * Add custom fields to Brand edit form
     *
     * @param \WP_Term $term Current term object
     */
    public function editBrandFields($term): void
    {
        $content = get_term_meta($term->term_id, 'brand_content', true);
        $logo = get_term_meta($term->term_id, 'brand_logo', true);
        $thumbnail = get_term_meta($term->term_id, 'brand_thumbnail', true);
        $ogImage = get_term_meta($term->term_id, 'brand_og_image', true);
        $website = get_term_meta($term->term_id, 'brand_website', true);
        ?>
        <tr class="form-field">
            <th scope="row">
                <label for="brand_content"><?php esc_html_e('Content', 'affiliatecms-pro'); ?></label>
            </th>
            <td>
                <textarea name="brand_content" id="brand_content" rows="5" cols="50"><?php echo esc_textarea($content); ?></textarea>
                <p class="description"><?php esc_html_e('Custom content for the brand archive page.', 'affiliatecms-pro'); ?></p>
            </td>
        </tr>
        <tr class="form-field">
            <th scope="row">
                <label for="brand_logo"><?php esc_html_e('Logo URL', 'affiliatecms-pro'); ?></label>
            </th>
            <td>
                <input type="url" name="brand_logo" id="brand_logo" value="<?php echo esc_url($logo); ?>" class="large-text" />
                <?php if ($logo): ?>
                    <p><img src="<?php echo esc_url($logo); ?>" alt="" style="max-width: 100px; max-height: 60px; margin-top: 8px; object-fit: contain; background: #f0f0f0; padding: 4px; border-radius: 4px;" /></p>
                <?php endif; ?>
                <p class="description"><?php esc_html_e('URL to the brand logo image.', 'affiliatecms-pro'); ?></p>
            </td>
        </tr>
        <tr class="form-field">
            <th scope="row">
                <label for="brand_thumbnail"><?php esc_html_e('Thumbnail Image', 'affiliatecms-pro'); ?></label>
            </th>
            <td>
                <input type="url" name="brand_thumbnail" id="brand_thumbnail" value="<?php echo esc_url($thumbnail); ?>" class="large-text" />
                <?php if ($thumbnail): ?>
                    <p><img src="<?php echo esc_url($thumbnail); ?>" alt="" style="max-width: 200px; max-height: 120px; margin-top: 8px; object-fit: cover; border-radius: 4px;" /></p>
                <?php endif; ?>
                <p class="description"><?php esc_html_e('Featured image for the brand archive page.', 'affiliatecms-pro'); ?></p>
            </td>
        </tr>
        <tr class="form-field">
            <th scope="row">
                <label for="brand_og_image"><?php esc_html_e('OG Image (Social Share)', 'affiliatecms-pro'); ?></label>
            </th>
            <td>
                <input type="url" name="brand_og_image" id="brand_og_image" value="<?php echo esc_url($ogImage); ?>" class="large-text" />
                <?php if ($ogImage): ?>
                    <p><img src="<?php echo esc_url($ogImage); ?>" alt="" style="max-width: 300px; max-height: 157px; margin-top: 8px; object-fit: cover; border-radius: 4px;" /></p>
                <?php endif; ?>
                <p class="description"><?php esc_html_e('Image for social media sharing (recommended: 1200x630px).', 'affiliatecms-pro'); ?></p>
            </td>
        </tr>
        <tr class="form-field">
            <th scope="row">
                <label for="brand_website"><?php esc_html_e('Website', 'affiliatecms-pro'); ?></label>
            </th>
            <td>
                <input type="url" name="brand_website" id="brand_website" value="<?php echo esc_url($website); ?>" class="large-text" />
                <p class="description"><?php esc_html_e('Official brand website URL.', 'affiliatecms-pro'); ?></p>
            </td>
        </tr>
        <?php
    }

    /**
     * Save Brand custom fields
     *
     * @param int $termId Term ID
     */
    public function saveBrandFields(int $termId): void
    {
        // Save content
        if (isset($_POST['brand_content'])) {
            update_term_meta(
                $termId,
                'brand_content',
                wp_kses_post($_POST['brand_content'])
            );
        }

        // Save logo URL
        if (isset($_POST['brand_logo'])) {
            update_term_meta(
                $termId,
                'brand_logo',
                esc_url_raw($_POST['brand_logo'])
            );
        }

        // Save thumbnail URL
        if (isset($_POST['brand_thumbnail'])) {
            update_term_meta(
                $termId,
                'brand_thumbnail',
                esc_url_raw($_POST['brand_thumbnail'])
            );
        }

        // Save OG image URL
        if (isset($_POST['brand_og_image'])) {
            update_term_meta(
                $termId,
                'brand_og_image',
                esc_url_raw($_POST['brand_og_image'])
            );
        }

        // Save website URL
        if (isset($_POST['brand_website'])) {
            update_term_meta(
                $termId,
                'brand_website',
                esc_url_raw($_POST['brand_website'])
            );
        }
    }

    /**
     * Add custom columns to Brand taxonomy list
     *
     * @param array $columns Existing columns
     * @return array Modified columns
     */
    public function brandColumns(array $columns): array
    {
        $newColumns = [];

        // Add image column at the beginning (after checkbox)
        foreach ($columns as $key => $value) {
            if ($key === 'name') {
                $newColumns['brand_image'] = __('Image', 'affiliatecms-pro');
            }
            $newColumns[$key] = $value;
        }

        // Add content column before posts count
        if (isset($newColumns['posts'])) {
            $posts = $newColumns['posts'];
            unset($newColumns['posts']);
            $newColumns['brand_content'] = __('Content', 'affiliatecms-pro');
            $newColumns['posts'] = $posts;
        } else {
            $newColumns['brand_content'] = __('Content', 'affiliatecms-pro');
        }

        return $newColumns;
    }

    /**
     * Display custom column content for Brand taxonomy
     *
     * @param string $content Column content
     * @param string $columnName Column name
     * @param int $termId Term ID
     * @return string Modified content
     */
    public function brandColumnContent(string $content, string $columnName, int $termId): string
    {
        if ($columnName === 'brand_content') {
            $brandContent = get_term_meta($termId, 'brand_content', true);
            if (!empty($brandContent)) {
                return '<span title="' . esc_attr($brandContent) . '">' . wp_trim_words($brandContent, 10, '...') . '</span>';
            }
            return '—';
        }

        if ($columnName === 'brand_image') {
            // Priority: thumbnail > logo
            $thumbnail = get_term_meta($termId, 'brand_thumbnail', true);
            $logo = get_term_meta($termId, 'brand_logo', true);
            $image = $thumbnail ?: $logo;

            if (!empty($image)) {
                $type = $thumbnail ? 'thumbnail' : 'logo';
                return '<img src="' . esc_url($image) . '" alt="" title="' . esc_attr(ucfirst($type)) . '" style="max-width: 50px; max-height: 50px; object-fit: contain; background: #f5f5f5; padding: 2px; border-radius: 4px;" />';
            }
            return '—';
        }

        return $content;
    }

    /**
     * Get brand meta data
     *
     * @param int $termId Term ID
     * @return array Brand meta data
     */
    public static function getBrandMeta(int $termId): array
    {
        return [
            'content' => get_term_meta($termId, 'brand_content', true) ?: '',
            'logo' => get_term_meta($termId, 'brand_logo', true) ?: '',
            'thumbnail' => get_term_meta($termId, 'brand_thumbnail', true) ?: '',
            'og_image' => get_term_meta($termId, 'brand_og_image', true) ?: '',
            'website' => get_term_meta($termId, 'brand_website', true) ?: '',
        ];
    }
}
