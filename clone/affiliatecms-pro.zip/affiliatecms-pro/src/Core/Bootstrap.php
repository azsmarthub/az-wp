<?php
/**
 * Bootstrap
 *
 * Main entry point for the plugin. Registers all hooks and functionality.
 *
 * @package AffiliateCMS\Pro
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro\Core;

class Bootstrap
{
    private static ?Bootstrap $instance = null;
    private bool $initialized = false;

    /**
     * Get singleton instance
     */
    public static function instance(): Bootstrap
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Private constructor for singleton
     */
    private function __construct()
    {
        // No dependencies needed
    }

    /**
     * Initialize the plugin
     * Called on plugins_loaded hook with priority 5
     */
    public function init(): void
    {
        if ($this->initialized) {
            return;
        }

        $this->initialized = true;

        // Always register CPTs (content must remain accessible)
        $postTypeManager = new PostTypeManager();
        $postTypeManager->init();

        // Register all hooks and functionality
        $this->registerHooks();
    }

    /**
     * Register all plugin hooks
     */
    private function registerHooks(): void
    {
        // Loopback optimization: resolve our own domain to 127.0.0.1
        // so wp_remote_post() connects locally instead of through Cloudflare
        add_action('http_api_curl', [$this, 'resolveLoopbackLocal'], 10, 3);

        // Initialize meta boxes
        MetaBoxes::instance()->register();

        // Initialize admin functionality
        if (is_admin()) {
            add_action('admin_menu', [$this, 'registerAdminMenu']);
            add_action('admin_enqueue_scripts', [$this, 'enqueueAdminAssets']);
        }

        // Initialize provider manager
        add_action('init', [$this, 'initProviders'], 10);

        // Register shortcodes
        add_action('init', [$this, 'registerShortcodes'], 15);

        // Register blocks
        add_action('init', [$this, 'registerBlocks'], 15);

        // Register post-ASIN sync (auto-update post_ids when posts are saved)
        add_action('init', [$this, 'registerPostAsinSync'], 20);

        // Auto-extract ASINs from shortcodes on post save
        add_action('save_post', [$this, 'handlePostSave'], 10, 3);

        // Replace template placeholders at render time
        add_filter('the_content', [$this, 'replaceTemplatePlaceholders'], 5);
        add_filter('the_title', [$this, 'replaceTemplatePlaceholdersInTitle'], 5, 2);
        add_filter('get_the_excerpt', [$this, 'replaceTemplatePlaceholdersInExcerpt'], 5, 2);

        // SEO meta placeholders (Yoast SEO)
        add_filter('wpseo_title', [$this, 'replaceTemplatePlaceholdersInSeoMeta'], 1);
        add_filter('wpseo_metadesc', [$this, 'replaceTemplatePlaceholdersInSeoMeta'], 1);
        // Yoast Open Graph
        add_filter('wpseo_opengraph_title', [$this, 'replaceTemplatePlaceholdersInSeoMeta'], 1);
        add_filter('wpseo_opengraph_desc', [$this, 'replaceTemplatePlaceholdersInSeoMeta'], 1);
        // Yoast Twitter
        add_filter('wpseo_twitter_title', [$this, 'replaceTemplatePlaceholdersInSeoMeta'], 1);
        add_filter('wpseo_twitter_description', [$this, 'replaceTemplatePlaceholdersInSeoMeta'], 1);

        // Filter post meta BEFORE SEO plugins read them (handles stored SEO titles with placeholders)
        add_filter('get_post_metadata', [$this, 'filterSeoPostMeta'], 1, 4);

        // SEO meta placeholders (Rank Math) - All output locations
        add_filter('rank_math/frontend/title', [$this, 'replaceTemplatePlaceholdersInSeoMeta'], 1);
        add_filter('rank_math/frontend/description', [$this, 'replaceTemplatePlaceholdersInSeoMeta'], 1);
        // Rank Math Open Graph
        add_filter('rank_math/opengraph/facebook/og_title', [$this, 'replaceTemplatePlaceholdersInSeoMeta'], 1);
        add_filter('rank_math/opengraph/facebook/og_description', [$this, 'replaceTemplatePlaceholdersInSeoMeta'], 1);
        // Rank Math Twitter Cards
        add_filter('rank_math/opengraph/twitter/title', [$this, 'replaceTemplatePlaceholdersInSeoMeta'], 1);
        add_filter('rank_math/opengraph/twitter/description', [$this, 'replaceTemplatePlaceholdersInSeoMeta'], 1);
        // Rank Math JSON-LD Schema
        add_filter('rank_math/json_ld', [$this, 'replaceTemplatePlaceholdersInSchema'], 1, 2);

        // Register custom variables with Rank Math's native variable system
        add_action('rank_math/vars/register_extra_replacements', [$this, 'registerRankMathVariables']);

        // SEO Date Modifier - update dateModified based on product scrape time
        \AffiliateCMS\Pro\Frontend\SeoDateModifier::instance()->init();

        // Auto-add affiliate tag to all Amazon links in content
        add_filter('the_content', [$this, 'addAffiliateTagToAmazonLinks'], 99);

        // Remove noopener/noreferrer from ALL external links (runs after all other filters)
        add_filter('the_content', [$this, 'removeNoopenerFromAllLinks'], 999);

        // Override WordPress default rel attribute (removes noopener/noreferrer for all target="_blank" links)
        add_filter('wp_targeted_link_rel', [$this, 'filterExternalLinksRel'], 10, 2);

        // Register REST API endpoints
        add_action('rest_api_init', [$this, 'registerApiEndpoints']);

        // Bypass LiteSpeed Cache for all ACMS REST API endpoints
        add_action('rest_api_init', [$this, 'bypassCacheForAcmsApi']);

        // Schedule cron jobs
        add_action('init', [$this, 'scheduleCronJobs']);

        // Register brand rewrite rules for frontend pages
        add_action('init', [$this, 'registerBrandRewriteRules'], 10);

        // Handle brand template
        add_action('template_redirect', [$this, 'handleBrandTemplate'], 5);

        // Allow other components to hook in
        do_action('acms_pro_loaded', $this);
    }

    /**
     * Register admin menu (full functionality)
     * Menu with submenu items for Products and Queue
     */
    public function registerAdminMenu(): void
    {
        // Main menu page
        add_menu_page(
            __('AffiliateCMS Pro', 'affiliatecms-pro'),
            __('AffiliateCMS', 'affiliatecms-pro'),
            'manage_options',
            'acms-pro',
            [$this, 'renderProducts'],
            'dashicons-money-alt',
            30
        );

        // Products submenu (same as main)
        add_submenu_page(
            'acms-pro',
            __('Products', 'affiliatecms-pro'),
            __('Products', 'affiliatecms-pro'),
            'manage_options',
            'acms-pro',
            [$this, 'renderProducts']
        );

        // Queue submenu
        add_submenu_page(
            'acms-pro',
            __('Keyword Queue', 'affiliatecms-pro'),
            __('Keyword Queue', 'affiliatecms-pro'),
            'manage_options',
            'acms-pro-queue',
            [$this, 'renderQueue']
        );

        // SEO Brands submenu
        add_submenu_page(
            'acms-pro',
            __('SEO Brands', 'affiliatecms-pro'),
            __('SEO Brands', 'affiliatecms-pro'),
            'manage_options',
            'acms-pro-brands',
            [$this, 'renderBrands']
        );

        // Cache submenu
        add_submenu_page(
            'acms-pro',
            __('Cache', 'affiliatecms-pro'),
            __('Cache', 'affiliatecms-pro'),
            'manage_options',
            'acms-pro-cache',
            [$this, 'renderCache']
        );
    }

    /**
     * Enqueue admin assets
     */
    public function enqueueAdminAssets(string $hook): void
    {
        // Check for main page, queue page, brands page, and cache page hooks
        if (strpos($hook, 'acms-pro') === false && strpos($hook, 'acms-pro-queue') === false && strpos($hook, 'acms-pro-brands') === false && strpos($hook, 'acms-pro-cache') === false) {
            return;
        }

        // Alpine.js Collapse Plugin (must load before Alpine.js core)
        wp_enqueue_script(
            'alpinejs-collapse',
            ACMS_PLUGIN_URL . 'assets/js/vendor/alpinejs-collapse.min.js',
            [],
            '3.14.3',
            true
        );

        // Alpine.js Core
        wp_enqueue_script(
            'alpinejs',
            ACMS_PLUGIN_URL . 'assets/js/vendor/alpinejs.min.js',
            ['alpinejs-collapse'],
            '3.14.3',
            true
        );

        // Add defer attribute for Alpine.js and dependent scripts
        add_filter('script_loader_tag', function ($tag, $handle) {
            $deferHandles = ['alpinejs', 'alpinejs-collapse', 'acms-admin'];
            if (in_array($handle, $deferHandles)) {
                if (strpos($tag, ' defer') === false) {
                    return str_replace(' src', ' defer src', $tag);
                }
            }
            return $tag;
        }, 10, 2);

        // Bootstrap Icons
        wp_enqueue_style(
            'bootstrap-icons',
            ACMS_PLUGIN_URL . 'assets/css/vendor/bootstrap-icons.min.css',
            [],
            '1.11.3'
        );

        // Plugin CSS
        wp_enqueue_style(
            'acms-admin',
            ACMS_PLUGIN_URL . 'assets/css/admin.css',
            ['bootstrap-icons'],
            ACMS_VERSION
        );

        // Plugin JS
        wp_enqueue_script(
            'acms-admin',
            ACMS_PLUGIN_URL . 'assets/js/admin.js',
            ['jquery', 'alpinejs'],
            ACMS_VERSION,
            true
        );

        // Localize script
        wp_localize_script('acms-admin', 'acmsConfig', [
            'restUrl' => rest_url('acms/v1/'),
            'nonce' => wp_create_nonce('wp_rest'),
            'pluginUrl' => ACMS_PLUGIN_URL,
        ]);
    }

    /**
     * Initialize providers
     */
    public function initProviders(): void
    {
        do_action('acms_init_providers');
    }

    /**
     * Register shortcodes
     */
    public function registerShortcodes(): void
    {
        \AffiliateCMS\Pro\Frontend\Shortcodes::instance()->register();
        \AffiliateCMS\Pro\Core\Assets::instance()->register();
        do_action('acms_register_shortcodes');
    }

    /**
     * Register blocks
     */
    public function registerBlocks(): void
    {
        do_action('acms_register_blocks');
    }

    /**
     * Register post-ASIN sync service
     */
    public function registerPostAsinSync(): void
    {
        \AffiliateCMS\Pro\Services\PostAsinSync::instance()->register();
    }

    /**
     * Register API endpoints
     */
    public function registerApiEndpoints(): void
    {
        // Products API
        $productsController = new \AffiliateCMS\Pro\Api\ProductsController();
        $productsController->register();

        // Amazon API
        $amazonController = new \AffiliateCMS\Pro\Api\AmazonController();
        $amazonController->register();

        // Settings API
        $settingsController = new \AffiliateCMS\Pro\Api\SettingsController();
        $settingsController->register();

        // Automation API
        $automationController = new \AffiliateCMS\Pro\Api\AutomationController();
        $automationController->register();

        // Queue API
        $queueController = new \AffiliateCMS\Pro\Api\QueueController();
        $queueController->register();

        // Templates API
        $templatesController = new \AffiliateCMS\Pro\Api\TemplatesController();
        $templatesController->register();

        // Cron API
        $cronController = new \AffiliateCMS\Pro\Api\CronController();
        $cronController->register();

        // Brands API
        $brandController = new \AffiliateCMS\Pro\Api\BrandController();
        $brandController->register();

        // Cache URL API
        $cacheController = new \AffiliateCMS\Pro\Api\CacheController();
        $cacheController->register();

        do_action('acms_register_api_endpoints');
    }

    /**
     * Bypass LiteSpeed Cache (and other caches) for all ACMS REST API endpoints.
     *
     * LiteSpeed caches GET responses at the web server level, which causes
     * cron endpoints to return stale responses instead of executing PHP code.
     */
    public function bypassCacheForAcmsApi(): void
    {
        add_filter('rest_pre_dispatch', function ($result, $server, $request) {
            $route = $request->get_route();

            // Match all ACMS namespaces: /acms/v1/, /acms-cat/v1/, /acms-ai/v1/
            if (strpos($route, '/acms') === false) {
                return $result;
            }

            // 1. LiteSpeed Cache plugin API
            do_action('litespeed_control_set_nocache', 'ACMS REST API');

            // 2. LiteSpeed Cache constant (must be before headers sent)
            if (!defined('LSCACHE_NO_CACHE')) {
                define('LSCACHE_NO_CACHE', true);
            }

            // 3. LiteSpeed Cache header (server-level bypass)
            if (!headers_sent()) {
                header('X-LiteSpeed-Cache-Control: no-cache');
            }

            // 4. Standard WordPress no-cache headers
            nocache_headers();

            return $result;
        }, 1, 3);
    }

    /**
     * Schedule cron jobs
     */
    public function scheduleCronJobs(): void
    {
        // Register custom cron schedules
        add_filter('cron_schedules', [$this, 'registerCustomCronSchedules']);

        // Register Background Runner for queue processing
        $backgroundRunner = \AffiliateCMS\Pro\Services\BackgroundRunner::instance();
        $backgroundRunner->register();

        // Start automatic queue processing (checks pending items every minute)
        $backgroundRunner->startQueueCheck();

        // Register handler for bulk rescrape background processing
        add_action('acms_process_scheduled_products', [$this, 'processScheduledProducts']);

        // Register handler for auto-rescrape of incomplete products (missing price/rating)
        add_action('acms_rescrape_incomplete', [$this, 'handleIncompleteRescrape'], 10, 2);

        // Unschedule any existing date update cron
        DateUpdateCron::instance()->unschedule();

        // Register Quick Update Cron (hourly price/stock updates)
        QuickUpdateCron::instance()->register();

        // Register Product AI Cron (every 10 minutes for product AI generation)
        ProductAiCron::instance()->register();

        // Register Post AI Cron (every 15 minutes for review post generation)
        PostAiCron::instance()->register();

        // Register Scrape Monitor Cron (every 5 minutes to check scrape progress)
        ScrapeMonitorCron::instance()->register();

        // Register Brand AI Cron (every 20 minutes for brand SEO content generation)
        BrandAiCron::instance()->register();

        // Cache Preload (daily cron + REST endpoints + auto-preload after purge)
        CachePreload::init();

        // Allow other components to schedule jobs
        do_action('acms_schedule_cron_jobs');
    }

    /**
     * Register custom cron schedules for automation
     *
     * @param array $schedules Existing schedules
     * @return array Modified schedules
     */
    public function registerCustomCronSchedules(array $schedules): array
    {
        $schedules['every_5_minutes'] = [
            'interval' => 5 * 60,
            'display' => __('Every 5 minutes', 'affiliatecms-pro'),
        ];
        $schedules['every_10_minutes'] = [
            'interval' => 10 * 60,
            'display' => __('Every 10 minutes', 'affiliatecms-pro'),
        ];
        $schedules['every_15_minutes'] = [
            'interval' => 15 * 60,
            'display' => __('Every 15 minutes', 'affiliatecms-pro'),
        ];
        $schedules['every_30_minutes'] = [
            'interval' => 30 * 60,
            'display' => __('Every 30 minutes', 'affiliatecms-pro'),
        ];
        return $schedules;
    }

    /**
     * Render dashboard page (redirect to products for now)
     */
    public function renderDashboard(): void
    {
        $this->renderProducts();
    }

    /**
     * Render products page
     */
    public function renderProducts(): void
    {
        $productsPage = new \AffiliateCMS\Pro\Admin\ProductsPage();
        $productsPage->render();
    }

    /**
     * Render settings page (integrated into products page modal)
     */
    public function renderSettings(): void
    {
        $this->renderProducts();
    }

    /**
     * Render queue page
     */
    public function renderQueue(): void
    {
        $queuePage = new \AffiliateCMS\Pro\Admin\QueuePage();
        $queuePage->render();
    }

    /**
     * Render brands page
     */
    public function renderBrands(): void
    {
        $brandsPage = new \AffiliateCMS\Pro\Admin\BrandsPage();
        $brandsPage->render();
    }

    /**
     * Render cache page
     */
    public function renderCache(): void
    {
        $cachePage = new \AffiliateCMS\Pro\Admin\CachePage();
        $cachePage->render();
    }

    /**
     * Handle post save/publish - extract ASINs from shortcodes and auto-add products
     *
     * @param int $postId Post ID
     * @param \WP_Post $post Post object
     * @param bool $update Whether this is an existing post being updated
     */
    public function handlePostSave(int $postId, \WP_Post $post, bool $update): void
    {
        try {
            // Skip autosaves and revisions
            if (wp_is_post_autosave($postId) || wp_is_post_revision($postId)) {
                return;
            }

            // Only process published posts
            if ($post->post_status !== 'publish') {
                return;
            }

            // Extract ASINs from post content
            $asins = $this->extractAsinsFromContent($post->post_content);

            if (empty($asins)) {
                return;
            }

            // Process immediately
            $this->processPostAsins($postId, $asins);
        } catch (\Throwable $e) {
            error_log('ACMS: Failed to process post ASINs: ' . $e->getMessage());
        }
    }

    /**
     * Process ASINs from post - save to database and trigger scrape
     *
     * @param int $postId Post ID
     * @param array $asins Array of ASINs
     */
    private function processPostAsins(int $postId, array $asins): void
    {
        try {
            global $wpdb;
            $table = $wpdb->prefix . 'acms_products';

            // Verify table exists
            $tableExists = $wpdb->get_var("SHOW TABLES LIKE '{$table}'");
            if (!$tableExists) {
                return;
            }

            $repository = \AffiliateCMS\Pro\Repositories\ProductRepository::instance();
            $newAsins = [];
            $existingBrands = [];

            foreach ($asins as $asin) {
                $existing = $repository->findByAsin($asin);
                if (!$existing) {
                    // Create new product with pending status
                    $id = $repository->create([
                        'asin' => $asin,
                        'status' => 'pending',
                        'source_post_id' => $postId,
                    ]);

                    if ($id) {
                        $newAsins[] = $asin;
                    }
                } else {
                    // Collect brand from existing product
                    if (!empty($existing->brand) && !in_array($existing->brand, $existingBrands)) {
                        $existingBrands[] = $existing->brand;
                    }
                }
            }

            // Assign brand taxonomy for acms_reviews posts
            $postType = get_post_type($postId);
            if ($postType === 'acms_reviews' && !empty($existingBrands)) {
                $brandTermIds = [];
                foreach ($existingBrands as $brandName) {
                    $termId = PostTypeManager::getOrCreateBrand($brandName);
                    if ($termId) {
                        $brandTermIds[] = (int) $termId;
                    }
                }

                if (!empty($brandTermIds)) {
                    wp_set_object_terms($postId, $brandTermIds, 'acms_reviews_brand');
                }
            }

            // Trigger scrape for new products
            if (!empty($newAsins)) {
                $this->triggerScrapeForAsins($newAsins);
            }
        } catch (\Throwable $e) {
            error_log('ACMS: Failed to create products from ASINs: ' . $e->getMessage());
        }
    }

    /**
     * Extract ASINs from post content by parsing [acms_list] shortcodes
     *
     * @param string $content Post content
     * @return array Array of unique ASINs
     */
    private function extractAsinsFromContent(string $content): array
    {
        if (empty($content)) {
            return [];
        }

        $asins = [];

        // Match [acms_list asin="B01LXY19XD,B0DRG6DM1S,B0FBR3R9LV"]
        if (preg_match_all('/\[acms_list\s+asin=["\']?([^"\'\]]+)["\']?\s*\]/i', $content, $matches)) {
            foreach ($matches[1] as $asinString) {
                $extractedAsins = preg_split('/[\s,]+/', trim($asinString));

                foreach ($extractedAsins as $asin) {
                    $asin = strtoupper(trim($asin));

                    if (empty($asin)) {
                        continue;
                    }

                    // Validate ASIN format
                    if (strlen($asin) === 10 && $asin[0] === 'B' && preg_match('/^B[A-Z0-9]{9}$/', $asin)) {
                        $asins[] = $asin;
                    }
                }
            }
        }

        return array_unique($asins);
    }

    /**
     * Trigger scrape for ASINs via internal REST API call
     *
     * @param array $asins Array of ASINs to scrape
     */
    private function triggerScrapeForAsins(array $asins): void
    {
        if (empty($asins)) {
            return;
        }

        wp_schedule_single_event(time() + 5, 'acms_scrape_asins', [$asins]);

        if (!has_action('acms_scrape_asins', [$this, 'performAsyncScrape'])) {
            add_action('acms_scrape_asins', [$this, 'performAsyncScrape']);
        }
    }

    /**
     * Perform async scrape via REST API
     *
     * @param array $asins Array of ASINs
     */
    public function performAsyncScrape(array $asins): void
    {
        if (empty($asins)) {
            return;
        }

        $url = rest_url('acms/v1/products/scrape');

        $adminUsers = get_users(['role' => 'administrator', 'number' => 1]);
        if (empty($adminUsers)) {
            return;
        }

        wp_set_current_user($adminUsers[0]->ID);
        $nonce = wp_create_nonce('wp_rest');

        wp_remote_post($url, [
            'blocking' => false,
            'timeout' => 0.01,
            'headers' => [
                'Content-Type' => 'application/json',
                'X-WP-Nonce' => $nonce,
            ],
            'body' => wp_json_encode([
                'asin' => implode(',', $asins),
                'domain' => 'amazon.com',
            ]),
        ]);
    }

    /**
     * Process scheduled products ONE at a time, then self-trigger the next.
     * Triggers AI cron after EACH successful scrape for immediate processing.
     */
    public function processScheduledProducts(): void
    {
        // Keep running even after the spawner (wp_remote_post) disconnects
        ignore_user_abort(true);
        @set_time_limit(290);

        $repository = \AffiliateCMS\Pro\Repositories\ProductRepository::instance();
        $provider = ProviderManager::instance();
        $maxWorkers = $this->getWorkerCount();
        $startTime = time();
        $maxRuntime = 270; // 4.5 min — under FPM's request_terminate_timeout (300s)
        $processed = 0;

        // In-process loop: keep claiming + scraping until time limit or no work
        while ((time() - $startTime) < $maxRuntime) {
            // Emergency pause
            if (file_exists(ABSPATH . '.scrape-pause')) {
                break;
            }

            // Concurrency guard
            $currentProcessing = $repository->count(['status' => 'processing']);
            if ($currentProcessing >= $maxWorkers) {
                break;
            }

            $product = $repository->claimScheduledProduct();
            if (!$product) {
                break; // No more scheduled products
            }

            $id = $product->id;
            $asin = $product->asin;
            $scrapeSuccess = false;

            $data = $provider->scrape($asin, 'amazon.com');

            if ($data) {
                $providerName = $data['provider'] ?? 'unknown';
                $log = $data['log'] ?? [];
                $fieldLog = $data['field_log'] ?? [];
                unset($data['provider'], $data['log'], $data['field_log']);

                $data['scrape_log'] = self::buildScrapeLog($asin, $providerName, $log, $fieldLog, $data);
                $repository->markAsScraped($id, $data, $providerName);
                $scrapeSuccess = true;

                self::scheduleIncompleteRescrape($id, $asin, $data);
            } else {
                $error = $provider->getLastError() ?? 'Scrape failed';
                $log = $provider->getScrapeLog();

                $repository->update($id, [
                    'scrape_log' => self::buildScrapeLog($asin, 'none', $log, [], [], $error),
                ]);
                $repository->markAsFailed($id, $error);
            }

            if ($scrapeSuccess) {
                $this->triggerAiProcessingThrottled();
            }

            $processed++;
        }

        if ($processed > 0) {
            error_log("[ACMS] Worker processed {$processed} products in " . (time() - $startTime) . "s");
        }
    }

    /**
     * Build structured scrape_log for diagnostics persistence
     *
     * Used by all scrape code paths (ProductsController, Bootstrap, BackgroundRunner)
     * to ensure consistent diagnostic data regardless of how the scrape was triggered.
     *
     * @param string $asin Product ASIN
     * @param string $provider Provider name
     * @param array $providerLog Timestamped log entries from ProviderManager
     * @param array $fieldLog Field extraction diagnostics from CrawlbaseProvider
     * @param array $data Scraped product data (for summary calculation)
     * @param string|null $error Error message (for failure logs)
     * @return array Structured scrape log
     */
    public static function buildScrapeLog(
        string $asin,
        string $provider,
        array $providerLog,
        array $fieldLog,
        array $data,
        ?string $error = null
    ): array {
        $log = [
            'scraped_at' => current_time('mysql'),
            'provider' => $provider,
            'asin' => $asin,
            'provider_log' => $providerLog,
            'field_diagnostics' => $fieldLog,
            'fields_received' => array_keys(array_filter(
                $data,
                fn($v, $k) => $v !== null && !in_array($k, ['provider', 'log', 'field_log', 'scrape_log'], true),
                ARRAY_FILTER_USE_BOTH
            )),
            'summary' => [
                'title_present' => !empty($data['title']),
                'price_present' => isset($data['price']) && $data['price'] !== null,
                'rating_present' => isset($data['rating']) && $data['rating'] !== null,
                'images_count' => count($data['images_gallery'] ?? []),
                'features_count' => count($data['features'] ?? []),
                'has_description' => !empty($data['description']),
                'has_category' => !empty($data['category_path']),
            ],
        ];

        if ($error !== null) {
            $log['error'] = $error;
        }

        return $log;
    }

    /**
     * Schedule a delayed re-scrape for products with missing critical data (price/rating)
     *
     * Crawlbase sometimes returns incomplete data (no price/rating) due to Amazon A/B testing
     * or Crawlbase parser issues. All in-session retries fail because Crawlbase caches the
     * same response. A delayed re-scrape (30 min later) gets a fresh page and often succeeds.
     *
     * @param int $productId Product ID
     * @param string $asin Product ASIN
     * @param array $data Scraped data to check for missing fields
     */
    public static function scheduleIncompleteRescrape(int $productId, string $asin, array $data): void
    {
        // Check if price or rating is missing
        $priceMissing = !isset($data['price']) || $data['price'] === null || $data['price'] === '';
        $ratingMissing = !isset($data['rating']) || $data['rating'] === null || $data['rating'] === '';

        if (!$priceMissing && !$ratingMissing) {
            return; // All critical fields present, no rescrape needed
        }

        // Prevent duplicate scheduling (1 hour TTL)
        $transientKey = 'acms_rescrape_' . $productId;
        if (get_transient($transientKey)) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("[ACMS Rescrape] Already scheduled for product #{$productId} ({$asin}), skipping");
            }
            return;
        }

        $missingFields = [];
        if ($priceMissing) {
            $missingFields[] = 'price';
        }
        if ($ratingMissing) {
            $missingFields[] = 'rating';
        }
        $missingStr = implode(', ', $missingFields);

        // Set transient to prevent duplicate scheduling
        set_transient($transientKey, 1, 3600);

        // Schedule delayed re-scrape (30 minutes)
        $delay = 30 * 60;

        wp_schedule_single_event(
            time() + $delay,
            'acms_rescrape_incomplete',
            [$productId, $asin]
        );

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("[ACMS Rescrape] Scheduled re-scrape in 30min for product #{$productId} ({$asin}) - missing: {$missingStr}");
        }
    }

    /**
     * Handle delayed re-scrape for products with missing critical data
     *
     * Uses quickScrape (lighter weight) to fetch only dynamic data (price, rating, stock).
     * Only updates fields that were previously missing - never overwrites existing data with null.
     *
     * @param int $productId Product ID
     * @param string $asin Product ASIN
     */
    public function handleIncompleteRescrape(int $productId, string $asin): void
    {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("[ACMS Rescrape] Starting re-scrape for product #{$productId} ({$asin})");
        }

        $repository = \AffiliateCMS\Pro\Repositories\ProductRepository::instance();
        $product = $repository->find($productId);

        if (!$product) {
            error_log("[ACMS Rescrape] Product #{$productId} not found, skipping");
            return;
        }

        // Check if product still needs re-scrape (may have been manually re-scraped)
        $priceMissing = $product->price === null || $product->price === '';
        $ratingMissing = $product->rating === null || $product->rating === '';

        if (!$priceMissing && !$ratingMissing) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("[ACMS Rescrape] Product #{$productId} ({$asin}) already has price/rating, skipping");
            }
            return;
        }

        $provider = ProviderManager::instance();

        // Try quickScrape first (lighter weight, dynamic data only)
        $data = $provider->quickScrape($asin, 'amazon.com');

        if ($data === null) {
            // QuickScrape failed, try full scrape as last resort
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("[ACMS Rescrape] Quick scrape failed for {$asin}, trying full scrape");
            }
            $data = $provider->scrape($asin, 'amazon.com');
        }

        if ($data === null) {
            error_log("[ACMS Rescrape] All scrape attempts failed for product #{$productId} ({$asin})");
            return;
        }

        // Build update data - only fill in previously missing fields
        $updateData = [];
        $filled = [];

        if ($priceMissing && isset($data['price']) && $data['price'] !== null && $data['price'] !== '') {
            $updateData['price'] = $data['price'];
            $filled[] = 'price=' . $data['price'];
        }
        if (isset($data['original_price']) && $data['original_price'] !== null) {
            $updateData['original_price'] = $data['original_price'];
        }
        if ($ratingMissing && isset($data['rating']) && $data['rating'] !== null && $data['rating'] !== '') {
            $updateData['rating'] = $data['rating'];
            $filled[] = 'rating=' . $data['rating'];

            // Recalculate score when rating is filled
            $scoreManager = \AffiliateCMS\Pro\Services\ScoreManager::instance();
            $updateData['score'] = $scoreManager->calculateScore(floatval($data['rating']));
        }
        if (isset($data['reviews_count']) && $data['reviews_count'] > 0 && ($product->reviewsCount ?? 0) == 0) {
            $updateData['reviews_count'] = $data['reviews_count'];
            $filled[] = 'reviews_count=' . $data['reviews_count'];
        }
        if (isset($data['in_stock'])) {
            $updateData['in_stock'] = $data['in_stock'];
        }

        if (empty($updateData)) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("[ACMS Rescrape] Re-scrape for {$asin} returned no new data for missing fields");
            }
            return;
        }

        // Update the product
        $repository->update($productId, $updateData);

        // Clear the transient
        delete_transient('acms_rescrape_' . $productId);

        $filledStr = implode(', ', $filled);
        $providerName = $data['provider'] ?? 'unknown';

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("[ACMS Rescrape] Successfully filled missing data for product #{$productId} ({$asin}) via {$providerName}: {$filledStr}");
        }
    }

    /**
     * Trigger AI processing with throttling to avoid excessive API calls
     *
     * Only triggers once every 30 seconds to prevent flooding the API
     * when multiple products are being scraped in parallel.
     */
    private function triggerAiProcessingThrottled(): void
    {
        $lastTrigger = (int) get_transient('acms_ai_trigger_time');
        $now = time();

        // Only trigger if 30 seconds have passed since last trigger
        if ($lastTrigger && ($now - $lastTrigger) < 30) {
            return;
        }

        // Set transient to prevent duplicate triggers
        set_transient('acms_ai_trigger_time', $now, 60);

        // Trigger AI crons
        $this->triggerCronApiEndpoints();

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[ACMS Bootstrap] Triggered AI processing after scrape (throttled)');
        }
    }

    /**
     * Trigger cron execution via direct API endpoint calls
     *
     * Calls the cron API endpoints directly instead of relying on wp-cron.php
     * This is more reliable than WP Cron which depends on site traffic.
     */
    private function triggerCronApiEndpoints(): void
    {
        $apiToken = get_option('acms_api_token', '');

        if (empty($apiToken)) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('[ACMS Bootstrap] Cannot trigger cron API - no API token configured');
            }
            return;
        }

        // Common request args for non-blocking calls
        // Note: timeout=0.5 gives enough time for request to initiate while staying non-blocking
        $requestArgs = [
            'timeout' => 0.5,
            'blocking' => false,
            'sslverify' => false,
            'headers' => [
                'User-Agent' => 'ACMS-Cron-Trigger/1.0',
            ],
        ];

        // Trigger Product AI cron endpoint
        $productAiUrl = rest_url('acms/v1/cron/product-ai') . '?token=' . urlencode($apiToken);
        wp_remote_post($productAiUrl, $requestArgs);

        // Trigger Scrape Monitor cron endpoint
        $scrapeMonitorUrl = rest_url('acms/v1/cron/scrape-monitor') . '?token=' . urlencode($apiToken);
        wp_remote_post($scrapeMonitorUrl, $requestArgs);

        // Trigger Category Queue Monitor (if cat plugin active)
        $catMonitorUrl = rest_url('acms-cat/v1/cron/queue-monitor') . '?token=' . urlencode($apiToken);
        wp_remote_post($catMonitorUrl, $requestArgs);

        // Trigger Category AI Content Generation (if cat plugin active)
        $catAiUrl = rest_url('acms-cat/v1/cron/category-ai') . '?token=' . urlencode($apiToken);
        wp_remote_post($catAiUrl, $requestArgs);

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[ACMS Bootstrap] Triggered cron API endpoints (product-ai, scrape-monitor, cat-queue-monitor, category-ai)');
        }
    }

    /**
     * Resolve loopback requests to 127.0.0.1 via CURLOPT_RESOLVE
     *
     * When wp_remote_post() calls our own REST API (e.g., spawning workers),
     * this routes the connection directly to localhost instead of going
     * through Cloudflare DNS → CDN → back to origin.
     *
     * @param resource $handle  cURL handle
     * @param array    $parsed_args  Request arguments
     * @param string   $url     Request URL
     */
    public function resolveLoopbackLocal($handle, array $parsed_args, string $url): void
    {
        $host = parse_url(home_url(), PHP_URL_HOST);

        // Only apply to requests targeting our own domain's REST API
        if (strpos($url, $host) !== false && strpos($url, '/wp-json/acms') !== false) {
            curl_setopt($handle, CURLOPT_RESOLVE, ["{$host}:443:127.0.0.1"]);
        }
    }

    /**
     * Get number of parallel workers to spawn
     *
     * @return int Number of workers (default 3, max 50)
     */
    public function getWorkerCount(): int
    {
        $settings = get_option('acms_automation', []);
        $count = (int) ($settings['worker_count'] ?? 3);
        return max(1, min(50, $count));
    }

    /**
     * Spawn parallel workers to process scheduled products
     *
     * @param int|null $count Number of workers to spawn (null = use setting)
     */
    public function spawnParallelWorkers(?int $count = null): void
    {
        $settingCount = $this->getWorkerCount();
        $maxWorkers = $count ?? $settingCount;
        $repository = \AffiliateCMS\Pro\Repositories\ProductRepository::instance();
        $scheduled = $repository->count(['status' => 'scheduled']);

        // Concurrency control: count products already being processed
        $currentProcessing = $repository->count(['status' => 'processing']);
        $availableSlots = max(0, $maxWorkers - $currentProcessing);
        $workersToSpawn = min($availableSlots, $scheduled);

        error_log("[ACMS] spawnParallelWorkers: max={$maxWorkers}, processing={$currentProcessing}, scheduled={$scheduled}, slots={$availableSlots}, spawning={$workersToSpawn}");

        if ($workersToSpawn <= 0) {
            return;
        }

        for ($i = 0; $i < $workersToSpawn; $i++) {
            $this->spawnWorker();
        }
    }

    /**
     * Spawn a single worker (fire-and-forget via wp_remote_post)
     *
     * Uses wp_remote_post with CURLOPT_RESOLVE to connect locally (127.0.0.1)
     * while using the real domain for SNI/Host. This avoids Cloudflare round-trip.
     * Worker endpoint uses ignore_user_abort(true) so PHP continues after disconnect.
     * blocking=false + timeout=1s: sends request then returns immediately.
     */
    private function spawnWorker(): void
    {
        $apiToken = get_option('acms_api_token', '');
        $endpoint = rest_url('acms/v1/automation/process-scheduled');

        // blocking=true with short timeout: sends POST then times out.
        // blocking=false would override timeout to 1s (WP core behavior).
        // Worker continues via ignore_user_abort(true) after we disconnect.
        wp_remote_post($endpoint, [
            'timeout'   => 0.1,
            'blocking'  => true,
            'sslverify' => false,
            'headers'   => [
                'X-ACMS-Token' => $apiToken,
            ],
        ]);
    }

    /**
     * Process one product from the update queue.
     *
     * Called by /automation/process-quick-update endpoint.
     * Claims one product atomically (update → updating), quick-scrapes it,
     * sets back to 'scraped', and self-spawns if more remain.
     */
    public function processQuickUpdateWorker(): void
    {
        // Keep running even after the spawner (wp_remote_post) disconnects
        ignore_user_abort(true);

        $repository = \AffiliateCMS\Pro\Repositories\ProductRepository::instance();
        $provider = ProviderManager::instance();

        // Atomic claim: status update → updating
        $product = $repository->claimUpdateProduct();

        if (!$product) {
            return; // Queue empty
        }

        $data = $provider->quickScrape($product->asin);

        if ($data) {
            $providerName = $data['provider'] ?? 'unknown';
            unset($data['provider'], $data['log']);
            $repository->updateDynamicData($product->id, $data, $providerName);
        } else {
            $error = $provider->getLastError() ?? 'Unknown error';
            error_log("[ACMS Update Worker] Failed ASIN {$product->asin}: {$error}");
        }

        // Always set back to 'scraped' (whether success or fail)
        $repository->update($product->id, ['status' => 'scraped']);

        // Check if more products in queue
        $remaining = $repository->countUpdateQueued();

        if ($remaining > 0) {
            usleep(500000); // 0.5s delay
            $this->spawnQuickUpdateWorker();
        }
    }

    /**
     * Spawn parallel update workers.
     *
     * @param int $count Number of workers to spawn (default 3)
     */
    public function spawnQuickUpdateWorkers(int $count = 3): void
    {
        $repository = \AffiliateCMS\Pro\Repositories\ProductRepository::instance();
        $remaining = $repository->countUpdateQueued();
        $workersToSpawn = min($count, $remaining);

        if ($workersToSpawn <= 0) {
            return;
        }

        for ($i = 0; $i < $workersToSpawn; $i++) {
            $this->spawnQuickUpdateWorker();
        }
    }

    /**
     * Spawn a single quick-update worker (fire-and-forget).
     */
    private function spawnQuickUpdateWorker(): void
    {
        $apiToken = get_option('acms_api_token', '');
        $endpoint = rest_url('acms/v1/automation/process-quick-update');

        wp_remote_post($endpoint, [
            'timeout'   => 0.1,
            'blocking'  => true,
            'sslverify' => false,
            'headers'   => [
                'X-ACMS-Token' => $apiToken,
            ],
        ]);
    }

    /**
     * Register custom variables with Rank Math's native variable system
     */
    public function registerRankMathVariables(): void
    {
        if (!function_exists('rank_math_register_var_replacement')) {
            return;
        }

        rank_math_register_var_replacement(
            'acms_keyword',
            [
                'name'        => esc_html__('ACMS Keyword', 'affiliatecms-pro'),
                'description' => esc_html__('The keyword used to generate this post from queue', 'affiliatecms-pro'),
                'variable'    => 'acms_keyword',
                'example'     => 'Best Wireless Headphones',
            ],
            [$this, 'getRankMathKeyword']
        );

        rank_math_register_var_replacement(
            'KEYWORD',
            [
                'name'        => esc_html__('ACMS Keyword (Title Case)', 'affiliatecms-pro'),
                'description' => esc_html__('The keyword in title case', 'affiliatecms-pro'),
                'variable'    => 'KEYWORD',
                'example'     => 'Best Wireless Headphones',
            ],
            [$this, 'getRankMathKeywordTitle']
        );

        rank_math_register_var_replacement(
            'product_count',
            [
                'name'        => esc_html__('Product Count', 'affiliatecms-pro'),
                'description' => esc_html__('Number of products in this post', 'affiliatecms-pro'),
                'variable'    => 'product_count',
                'example'     => '10',
            ],
            [$this, 'getRankMathProductCount']
        );

        rank_math_register_var_replacement(
            'price_range',
            [
                'name'        => esc_html__('Price Range', 'affiliatecms-pro'),
                'description' => esc_html__('Price range of products (e.g., $29.99 - $99.99)', 'affiliatecms-pro'),
                'variable'    => 'price_range',
                'example'     => '$29.99 - $99.99',
            ],
            [$this, 'getRankMathPriceRange']
        );

        rank_math_register_var_replacement(
            'brand_list',
            [
                'name'        => esc_html__('Brand List', 'affiliatecms-pro'),
                'description' => esc_html__('List of brands featured in this post', 'affiliatecms-pro'),
                'variable'    => 'brand_list',
                'example'     => 'Sony, Bose, Apple',
            ],
            [$this, 'getRankMathBrandList']
        );
    }

    /**
     * Callback for Rank Math ACMS Keyword variable
     */
    public function getRankMathKeyword(): string
    {
        $post_id = $this->getCurrentPostId();
        if (!$post_id) {
            return '';
        }

        $keyword = get_post_meta($post_id, '_acms_queue_keyword', true);
        if (empty($keyword)) {
            $title = get_the_title($post_id);
            $keyword = preg_replace('/%[^%]+%/', '', $title);
            $keyword = trim($keyword);
        }

        return $keyword;
    }

    /**
     * Callback for Rank Math KEYWORD (title case) variable
     */
    public function getRankMathKeywordTitle(): string
    {
        return ucwords($this->getRankMathKeyword());
    }

    /**
     * Callback for Rank Math product_count variable
     */
    public function getRankMathProductCount(): string
    {
        $post_id = $this->getCurrentPostId();
        if (!$post_id) {
            return '0';
        }

        $placeholders = $this->getProductPlaceholders($post_id);
        return $placeholders['%product_count%'] ?? '0';
    }

    /**
     * Callback for Rank Math price_range variable
     */
    public function getRankMathPriceRange(): string
    {
        $post_id = $this->getCurrentPostId();
        if (!$post_id) {
            return '';
        }

        $placeholders = $this->getProductPlaceholders($post_id);
        return $placeholders['%price_range%'] ?? '';
    }

    /**
     * Callback for Rank Math brand_list variable
     */
    public function getRankMathBrandList(): string
    {
        $post_id = $this->getCurrentPostId();
        if (!$post_id) {
            return '';
        }

        $placeholders = $this->getProductPlaceholders($post_id);
        return $placeholders['%brand_list%'] ?? '';
    }

    /**
     * Replace template placeholders in post content at render time
     *
     * @param string $content Post content
     * @return string Modified content
     */
    public function replaceTemplatePlaceholders(string $content): string
    {
        if (empty($content) || strpos($content, '%') === false) {
            return $content;
        }

        $post_id = get_the_ID();
        if ($post_id) {
            $post_type = get_post_type($post_id);
            if (!in_array($post_type, ['post', 'page', 'acms_reviews', 'acms_deals', 'acms_guides'], true)) {
                return $content;
            }
        }

        return $this->doPlaceholderReplacement($content);
    }

    /**
     * Replace template placeholders in post title at render time
     *
     * @param string $title Post title
     * @param int|null $post_id Post ID
     * @return string Modified title
     */
    public function replaceTemplatePlaceholdersInTitle(string $title, $post_id = null): string
    {
        if (empty($title) || strpos($title, '%') === false) {
            return $title;
        }

        if ($post_id) {
            $post_type = get_post_type($post_id);
            if (!in_array($post_type, ['post', 'page', 'acms_reviews', 'acms_deals', 'acms_guides'], true)) {
                return $title;
            }
        }

        return $this->doPlaceholderReplacement($title, $post_id);
    }

    /**
     * Replace template placeholders in post excerpt at render time
     *
     * @param string $excerpt Post excerpt
     * @param WP_Post|null $post Post object
     * @return string Modified excerpt
     */
    public function replaceTemplatePlaceholdersInExcerpt(string $excerpt, $post = null): string
    {
        if (empty($excerpt) || strpos($excerpt, '%') === false) {
            return $excerpt;
        }

        $post_id = $post ? $post->ID : get_the_ID();

        if ($post_id) {
            $post_type = get_post_type($post_id);
            if (!in_array($post_type, ['post', 'page', 'acms_reviews', 'acms_deals', 'acms_guides'], true)) {
                return $excerpt;
            }
        }

        return $this->doPlaceholderReplacement($excerpt, $post_id);
    }

    /**
     * Replace template placeholders in SEO meta (Yoast/RankMath)
     *
     * @param mixed $text Meta text
     * @return mixed Modified text
     */
    public function replaceTemplatePlaceholdersInSeoMeta($text)
    {
        if (!is_string($text)) {
            return $text;
        }

        if (empty($text) || strpos($text, '%') === false) {
            return $text;
        }

        $post_id = $this->getCurrentPostId();

        if (!$post_id) {
            return $text;
        }

        $post_type = get_post_type($post_id);
        if (!in_array($post_type, ['post', 'acms_reviews', 'acms_deals', 'acms_guides'], true)) {
            return $text;
        }

        return $this->doPlaceholderReplacement($text, $post_id);
    }

    /**
     * Get current post ID from multiple sources
     *
     * @return int|null Post ID or null
     */
    private function getCurrentPostId(): ?int
    {
        $post_id = get_the_ID();
        if ($post_id && $post_id > 0) {
            return (int) $post_id;
        }

        global $post;
        if ($post instanceof \WP_Post && $post->ID > 0) {
            return (int) $post->ID;
        }

        $queried = get_queried_object();
        if ($queried instanceof \WP_Post && $queried->ID > 0) {
            return (int) $queried->ID;
        }

        global $wp_query;
        if ($wp_query && isset($wp_query->query_vars['p']) && $wp_query->query_vars['p'] > 0) {
            return (int) $wp_query->query_vars['p'];
        }

        if (isset($_GET['p']) && is_numeric($_GET['p'])) {
            return (int) $_GET['p'];
        }
        if (isset($_GET['post']) && is_numeric($_GET['post'])) {
            return (int) $_GET['post'];
        }

        return null;
    }

    /**
     * Filter SEO post meta to replace placeholders BEFORE SEO plugins process them
     *
     * @param mixed $value The meta value
     * @param int $object_id Post ID
     * @param string $meta_key Meta key
     * @param bool $single Whether to return single value
     * @return mixed Modified value or null
     */
    public function filterSeoPostMeta($value, $object_id, $meta_key, $single)
    {
        $object_id = (int) $object_id;
        $meta_key = (string) $meta_key;

        if ($object_id <= 0 || empty($meta_key)) {
            return $value;
        }

        $seoMetaKeys = [
            'rank_math_title',
            'rank_math_description',
            'rank_math_facebook_title',
            'rank_math_facebook_description',
            'rank_math_twitter_title',
            'rank_math_twitter_description',
            '_yoast_wpseo_title',
            '_yoast_wpseo_metadesc',
            '_yoast_wpseo_opengraph-title',
            '_yoast_wpseo_opengraph-description',
            '_yoast_wpseo_twitter-title',
            '_yoast_wpseo_twitter-description',
        ];

        if (!in_array($meta_key, $seoMetaKeys, true)) {
            return $value;
        }

        $post_type = get_post_type($object_id);
        if (!$post_type || !in_array($post_type, ['post', 'acms_reviews', 'acms_deals', 'acms_guides'], true)) {
            return $value;
        }

        remove_filter('get_post_metadata', [$this, 'filterSeoPostMeta'], 1);
        $rawValue = get_post_meta($object_id, $meta_key, true);
        add_filter('get_post_metadata', [$this, 'filterSeoPostMeta'], 1, 4);

        if (empty($rawValue) || !is_string($rawValue) || strpos($rawValue, '%') === false) {
            return $value;
        }

        return $this->doPlaceholderReplacement($rawValue, $object_id);
    }

    /**
     * Replace template placeholders in Rank Math JSON-LD Schema
     *
     * @param array $data Schema data array
     * @param mixed $jsonld JsonLD instance
     * @return array Modified schema data
     */
    public function replaceTemplatePlaceholdersInSchema(array $data, $jsonld = null): array
    {
        if (empty($data) || !is_singular()) {
            return $data;
        }

        $post_id = get_the_ID();

        if ($post_id) {
            $post_type = get_post_type($post_id);
            if (!in_array($post_type, ['post', 'acms_reviews', 'acms_deals', 'acms_guides'], true)) {
                return $data;
            }
        }

        $data = $this->addImageToSchema($data, $post_id);

        return $this->replaceInSchemaArray($data, $post_id);
    }

    /**
     * Add image to BlogPosting/Article schema if missing
     *
     * @param array $data Schema data
     * @param int $post_id Post ID
     * @return array Modified data
     */
    private function addImageToSchema(array $data, int $post_id): array
    {
        if (!isset($data['@graph']) || !is_array($data['@graph'])) {
            return $data;
        }

        foreach ($data['@graph'] as $key => $item) {
            if (!isset($item['@type'])) {
                continue;
            }

            $type = is_array($item['@type']) ? $item['@type'] : [$item['@type']];
            $isArticle = array_intersect(['BlogPosting', 'Article', 'NewsArticle'], $type);

            if ($isArticle && !isset($item['image'])) {
                $image = $this->getSchemaImage($post_id);
                if ($image) {
                    $data['@graph'][$key]['image'] = $image;
                }
            }
        }

        return $data;
    }

    /**
     * Get image for schema
     *
     * @param int $post_id Post ID
     * @return array|null Image schema array or null
     */
    private function getSchemaImage(int $post_id): ?array
    {
        if (has_post_thumbnail($post_id)) {
            $image_id = get_post_thumbnail_id($post_id);
            $image_data = wp_get_attachment_image_src($image_id, 'full');
            if ($image_data) {
                return [
                    '@type' => 'ImageObject',
                    'url' => $image_data[0],
                    'width' => $image_data[1],
                    'height' => $image_data[2],
                ];
            }
        }

        $post = get_post($post_id);
        if ($post) {
            $content = apply_filters('the_content', $post->post_content);
            if (preg_match('/<img[^>]+src=["\']([^"\']+)["\']/', $content, $matches)) {
                return [
                    '@type' => 'ImageObject',
                    'url' => $matches[1],
                ];
            }
        }

        $custom_logo_id = get_theme_mod('custom_logo');
        if ($custom_logo_id) {
            $logo_data = wp_get_attachment_image_src($custom_logo_id, 'full');
            if ($logo_data) {
                return [
                    '@type' => 'ImageObject',
                    'url' => $logo_data[0],
                    'width' => $logo_data[1],
                    'height' => $logo_data[2],
                ];
            }
        }

        return null;
    }

    /**
     * Recursively replace placeholders in schema array
     *
     * @param array $data Schema data
     * @param int $post_id Post ID
     * @return array Modified data
     */
    private function replaceInSchemaArray(array $data, int $post_id): array
    {
        foreach ($data as $key => $value) {
            if (is_string($value) && strpos($value, '%') !== false) {
                $data[$key] = $this->doPlaceholderReplacement($value, $post_id);
            } elseif (is_array($value)) {
                $data[$key] = $this->replaceInSchemaArray($value, $post_id);
            }
        }
        return $data;
    }

    /**
     * Perform placeholder replacement on text
     *
     * @param string $text Text with placeholders
     * @param int|null $post_id Post ID
     * @return string Text with placeholders replaced
     */
    private function doPlaceholderReplacement(string $text, ?int $post_id = null): string
    {
        $post_id = $post_id ?: get_the_ID();

        // Cache per-request values in static variables to avoid repeated get_option()
        // calls (which hit the object cache) on every title/content filter invocation.
        static $timestamp = null;
        static $date_format = null;
        static $site_name = null;
        if ($timestamp === null) {
            $timestamp = current_time('timestamp');
        }
        if ($date_format === null) {
            $date_format = get_option('date_format');
        }
        if ($site_name === null) {
            $site_name = get_bloginfo('name');
        }

        // Cache per-post keyword to avoid repeated DB calls and avoid calling
        // get_the_title() (which fires the_title filter → recursive loop).
        static $keyword_cache = [];
        if (!isset($keyword_cache[$post_id])) {
            $kw = get_post_meta($post_id, '_acms_queue_keyword', true);
            if (empty($kw)) {
                // Use get_post_field to bypass the_title filter and avoid recursion.
                $kw = get_post_field('post_title', $post_id);
            }
            $keyword_cache[$post_id] = (string) $kw;
        }
        $keyword = $keyword_cache[$post_id];
        $keywordTitle = ucwords($keyword);

        $author = get_the_author() ?: $site_name;

        $replacements = [
            '%year%'         => date('Y', $timestamp),
            '%%year%%'       => date('Y', $timestamp),
            '%month_text%'   => date_i18n('F', $timestamp),
            '%month_number%' => date('m', $timestamp),
            '%month_short%'  => date_i18n('M', $timestamp),
            '%day%'          => date('d', $timestamp),
            '%date_full%'    => date_i18n($date_format, $timestamp),

            '%keyword%'       => $keyword,
            '%Keyword%'       => $keywordTitle,
            '%KEYWORD%'       => $keywordTitle,
            '%keyword_title%' => $keywordTitle,
            '%keyword_upper%' => strtoupper($keyword),

            '%author%'      => $author,
            '%author_name%' => $author,
            '%site_name%'   => $site_name,
        ];

        if (strpos($text, '%product_count%') !== false ||
            strpos($text, '%price_') !== false ||
            strpos($text, '%review_count%') !== false ||
            strpos($text, '%brand_list%') !== false ||
            strpos($text, '%brand_count%') !== false) {

            $productReplacements = $this->getProductPlaceholders($post_id);
            $replacements = array_merge($replacements, $productReplacements);
        }

        return str_replace(
            array_keys($replacements),
            array_values($replacements),
            $text
        );
    }

    /**
     * Get product-related placeholder values from post content
     *
     * @param int $post_id Post ID
     * @return array Product placeholder replacements
     */
    private function getProductPlaceholders(int $post_id): array
    {
        global $wpdb;

        $content = get_post_field('post_content', $post_id);
        if (empty($content)) {
            return $this->getEmptyProductPlaceholders();
        }

        $asins = [];
        if (preg_match_all('/\[acms_(?:list|card|grid|table)\s+[^\]]*asin=["\']([^"\']+)["\']/i', $content, $matches)) {
            foreach ($matches[1] as $asinString) {
                $asins = array_merge($asins, array_map('trim', explode(',', $asinString)));
            }
        }

        $asins = array_unique(array_filter($asins));

        if (empty($asins)) {
            return $this->getEmptyProductPlaceholders();
        }

        $table = $wpdb->prefix . 'acms_products';
        $placeholders = implode(',', array_fill(0, count($asins), '%s'));

        $products = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT price, reviews_count, brand FROM {$table} WHERE asin IN ({$placeholders})",
                ...$asins
            ),
            ARRAY_A
        );

        if (empty($products)) {
            return $this->getEmptyProductPlaceholders();
        }

        $productCount = count($products);
        $priceMin = null;
        $priceMax = null;
        $reviewTotal = 0;
        $brands = [];

        foreach ($products as $product) {
            $price = isset($product['price']) ? floatval($product['price']) : 0;
            if ($price > 0) {
                if ($priceMin === null || $price < $priceMin) {
                    $priceMin = $price;
                }
                if ($priceMax === null || $price > $priceMax) {
                    $priceMax = $price;
                }
            }

            $reviewTotal += isset($product['reviews_count']) ? intval($product['reviews_count']) : 0;

            $brand = $product['brand'] ?? '';
            if (!empty($brand) && !in_array($brand, $brands)) {
                $brands[] = $brand;
            }
        }

        $currencySymbol = '$';
        $priceMinFormatted = $priceMin !== null ? $currencySymbol . number_format($priceMin, 2) : '';
        $priceMaxFormatted = $priceMax !== null ? $currencySymbol . number_format($priceMax, 2) : '';

        $priceRange = '';
        if ($priceMin !== null && $priceMax !== null) {
            $priceRange = ($priceMin === $priceMax)
                ? $priceMinFormatted
                : $priceMinFormatted . ' - ' . $priceMaxFormatted;
        }

        $brandList = '';
        if (!empty($brands)) {
            $brandList = count($brands) > 3
                ? implode(', ', array_slice($brands, 0, 3)) . ' and more'
                : implode(', ', $brands);
        }

        $reviewFormatted = $reviewTotal >= 1000
            ? number_format($reviewTotal / 1000, 1) . 'K'
            : (string) $reviewTotal;

        return [
            '%product_count%' => (string) $productCount,
            '%review_count%' => (string) $reviewTotal,
            '%review_count_formatted%' => $reviewFormatted,
            '%brand_list%' => $brandList,
            '%brand_count%' => (string) count($brands),
            '%price_min%' => $priceMinFormatted,
            '%price_max%' => $priceMaxFormatted,
            '%price_range%' => $priceRange,
            '%price_avg%' => $priceMin && $priceMax ? $currencySymbol . number_format(($priceMin + $priceMax) / 2, 2) : '',
            '%product_min%' => $priceMinFormatted,
            '%product_max%' => $priceMaxFormatted,
        ];
    }

    /**
     * Get empty product placeholders
     *
     * @return array
     */
    private function getEmptyProductPlaceholders(): array
    {
        return [
            '%product_count%' => '0',
            '%review_count%' => '0',
            '%review_count_formatted%' => '0',
            '%brand_list%' => '',
            '%brand_count%' => '0',
            '%price_min%' => '',
            '%price_max%' => '',
            '%price_range%' => '',
            '%price_avg%' => '',
            '%product_min%' => '',
            '%product_max%' => '',
        ];
    }

    /**
     * Auto-add affiliate tag to all Amazon links in content
     *
     * @param string $content Post content
     * @return string Modified content
     */
    public function addAffiliateTagToAmazonLinks(string $content): string
    {
        if (empty($content)) {
            return $content;
        }

        $settings = get_option('acms_general_settings', []);
        $affiliateTag = $settings['affiliate_tag'] ?? '';
        $customUrlParams = $settings['custom_url_params'] ?? '';

        if (empty($affiliateTag)) {
            $paapiSettings = get_option('acms_paapi_settings', []);
            $affiliateTag = $paapiSettings['partner_tag'] ?? '';
        }

        if (empty($affiliateTag)) {
            return $content;
        }

        $customParams = [];
        if (!empty($customUrlParams)) {
            parse_str($customUrlParams, $customParams);
        }

        $amazonDomains = [
            'amazon.com',
            'amazon.co.uk',
            'amazon.de',
            'amazon.fr',
            'amazon.it',
            'amazon.es',
            'amazon.ca',
            'amazon.co.jp',
            'amazon.in',
            'amazon.com.au',
            'amazon.com.br',
            'amazon.com.mx',
            'amzn.to',
            'amzn.eu',
        ];

        $domainsPattern = implode('|', array_map(function ($domain) {
            return preg_quote($domain, '/');
        }, $amazonDomains));

        $pattern = '/<a\s([^>]*?)href=(["\'])(https?:\/\/(?:www\.)?(?:' . $domainsPattern . ')[^\s"\']*)\2([^>]*)>/i';

        $content = preg_replace_callback($pattern, function ($matches) use ($affiliateTag, $customParams) {
            $beforeHref = $matches[1];
            $quote = $matches[2];
            $url = $matches[3];
            $afterHref = $matches[4];

            $url = html_entity_decode($url, ENT_QUOTES | ENT_HTML5, 'UTF-8');

            $parsedUrl = parse_url($url);
            if (!$parsedUrl || !isset($parsedUrl['host'])) {
                return $matches[0];
            }

            $queryParams = [];
            if (isset($parsedUrl['query'])) {
                parse_str($parsedUrl['query'], $queryParams);
            }

            if (empty($queryParams['tag'])) {
                $queryParams['tag'] = $affiliateTag;
            }

            foreach ($customParams as $key => $value) {
                if (!isset($queryParams[$key])) {
                    $queryParams[$key] = $value;
                }
            }

            $newUrl = $parsedUrl['scheme'] . '://' . $parsedUrl['host'];
            if (isset($parsedUrl['path'])) {
                $newUrl .= $parsedUrl['path'];
            }
            if (!empty($queryParams)) {
                $newUrl .= '?' . http_build_query($queryParams);
            }

            return '<a ' . $beforeHref . 'href=' . $quote . $newUrl . $quote . $afterHref . '>';
        }, $content);

        return $content;
    }

    /**
     * Remove noopener and noreferrer from ALL external links
     *
     * @param string $content Post content
     * @return string Modified content
     */
    public function removeNoopenerFromAllLinks(string $content): string
    {
        if (empty($content)) {
            return $content;
        }

        $pattern = '/<a\s+([^>]*target=["\']_blank["\'][^>]*)rel=["\'](.*?)["\']([^>]*)>/i';

        $content = preg_replace_callback($pattern, function ($matches) {
            $beforeRel = $matches[1];
            $relValue = $matches[2];
            $afterRel = $matches[3];

            $relValue = preg_replace('/\s*\bnoopener\b\s*/i', ' ', $relValue);
            $relValue = preg_replace('/\s*\bnoreferrer\b\s*/i', ' ', $relValue);
            $relValue = trim(preg_replace('/\s+/', ' ', $relValue));

            if (stripos($relValue, 'nofollow') === false) {
                $relValue = trim($relValue . ' nofollow');
            }

            return '<a ' . $beforeRel . 'rel="' . $relValue . '"' . $afterRel . '>';
        }, $content);

        $pattern2 = '/<a\s+([^>]*)rel=["\'](.*?)["\']([^>]*target=["\']_blank["\'][^>]*)>/i';

        $content = preg_replace_callback($pattern2, function ($matches) {
            $beforeRel = $matches[1];
            $relValue = $matches[2];
            $afterRel = $matches[3];

            $relValue = preg_replace('/\s*\bnoopener\b\s*/i', ' ', $relValue);
            $relValue = preg_replace('/\s*\bnoreferrer\b\s*/i', ' ', $relValue);
            $relValue = trim(preg_replace('/\s+/', ' ', $relValue));

            if (stripos($relValue, 'nofollow') === false) {
                $relValue = trim($relValue . ' nofollow');
            }

            return '<a ' . $beforeRel . 'rel="' . $relValue . '"' . $afterRel . '>';
        }, $content);

        return $content;
    }

    /**
     * Filter WordPress default rel attribute for ALL external links
     *
     * @param string $rel The rel attribute value
     * @param string $link_html The link HTML
     * @return string Modified rel attribute
     */
    public function filterExternalLinksRel(string $rel, string $link_html): string
    {
        $rel = preg_replace('/\s*\bnoopener\b\s*/i', ' ', $rel);
        $rel = preg_replace('/\s*\bnoreferrer\b\s*/i', ' ', $rel);
        $rel = trim(preg_replace('/\s+/', ' ', $rel));

        if (stripos($rel, 'nofollow') === false) {
            $rel = trim($rel . ' nofollow');
        }

        return trim($rel) ?: 'nofollow';
    }

    /**
     * Register rewrite rules for brand pages
     */
    public function registerBrandRewriteRules(): void
    {
        // /brand/brand-slug/ -> brand page
        add_rewrite_rule(
            '^brand/([^/]+)/?$',
            'index.php?acms_brand=$matches[1]',
            'top'
        );

        // /brand/brand-slug/page/2/ -> brand page with pagination
        add_rewrite_rule(
            '^brand/([^/]+)/page/([0-9]+)/?$',
            'index.php?acms_brand=$matches[1]&paged=$matches[2]',
            'top'
        );

        // Register query var
        add_filter('query_vars', function (array $vars): array {
            $vars[] = 'acms_brand';
            return $vars;
        });
    }

    /**
     * Handle brand template on frontend
     */
    public function handleBrandTemplate(): void
    {
        $brand_slug = get_query_var('acms_brand');

        if (empty($brand_slug)) {
            return;
        }

        $repository = \AffiliateCMS\Pro\Repositories\BrandRepository::instance();
        $brand = $repository->findBySlug($brand_slug);

        if (!$brand) {
            global $wp_query;
            $wp_query->set_404();
            status_header(404);
            return;
        }

        // Set global for template use
        $GLOBALS['acms_current_brand'] = $brand;

        // Enqueue frontend assets
        add_action('wp_enqueue_scripts', [$this, 'enqueueBrandFrontendAssets'], 5);

        // Load template - check theme first, then plugin
        $template = locate_template(['acms-brand.php', 'templates/acms-brand.php']);

        if (!$template) {
            $template = ACMS_PLUGIN_DIR . 'templates/brand.php';
        }

        if (file_exists($template)) {
            include $template;
            exit;
        }
    }

    /**
     * Enqueue frontend assets for brand pages
     */
    public function enqueueBrandFrontendAssets(): void
    {
        // Enqueue Alpine.js if not already registered
        if (!wp_script_is('alpinejs', 'registered') && !wp_script_is('alpine', 'registered')) {
            wp_enqueue_script(
                'alpinejs',
                'https://cdn.jsdelivr.net/npm/alpinejs@3.14.3/dist/cdn.min.js',
                [],
                '3.14.3',
                ['strategy' => 'defer', 'in_footer' => false]
            );
        }
    }

}
