<?php
/**
 * Asset Management
 *
 * Handles loading of CSS, JS assets for admin and frontend.
 *
 * @package AffiliateCMS\Pro\Core
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro\Core;

class Assets
{
    private static ?Assets $instance = null;

    public static function instance(): Assets
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct()
    {
        // Private constructor for singleton
    }

    /**
     * Register asset hooks
     */
    public function register(): void
    {
        // Admin assets
        add_action('admin_enqueue_scripts', [$this, 'enqueueAdminStyles']);
        add_action('admin_enqueue_scripts', [$this, 'enqueueAdminScripts']);

        // Frontend assets
        add_action('wp_enqueue_scripts', [$this, 'enqueueFrontendStyles']);
        add_action('wp_enqueue_scripts', [$this, 'enqueueFrontendScripts']);
    }

    /**
     * Enqueue admin styles
     */
    public function enqueueAdminStyles(string $hook): void
    {
        // Only load on plugin pages
        if (strpos($hook, 'affiliatecms') === false) {
            return;
        }

        // Bootstrap Icons - self-hosted
        wp_enqueue_style(
            'bootstrap-icons',
            ACMS_PLUGIN_URL . 'assets/fonts/bootstrap-icons/bootstrap-icons.min.css',
            [],
            '1.11.3'
        );

        // Plugin admin CSS
        wp_enqueue_style(
            'acms-admin',
            ACMS_PLUGIN_URL . 'assets/css/admin.css',
            ['bootstrap-icons'],
            $this->getVersion()
        );
    }

    /**
     * Enqueue admin scripts
     */
    public function enqueueAdminScripts(string $hook): void
    {
        // Only load on plugin pages
        if (strpos($hook, 'affiliatecms') === false) {
            return;
        }

        // Alpine.js Collapse Plugin - self-hosted (must load before Alpine.js core)
        wp_enqueue_script(
            'alpinejs-collapse',
            ACMS_PLUGIN_URL . 'assets/js/vendor/alpinejs-collapse.min.js',
            [],
            '3.14.3',
            true
        );

        // Alpine.js Core - self-hosted
        wp_enqueue_script(
            'alpinejs',
            ACMS_PLUGIN_URL . 'assets/js/vendor/alpinejs.min.js',
            ['alpinejs-collapse'],
            '3.14.3',
            true
        );

        // Add defer attribute for Alpine.js scripts
        add_filter('script_loader_tag', function ($tag, $handle) {
            if (in_array($handle, ['alpinejs', 'alpinejs-collapse'])) {
                return str_replace(' src', ' defer src', $tag);
            }
            return $tag;
        }, 10, 2);

        // Plugin admin JS
        wp_enqueue_script(
            'acms-admin',
            ACMS_PLUGIN_URL . 'assets/js/admin.js',
            ['alpinejs'],
            $this->getVersion(),
            true
        );

        // Localize script data
        wp_localize_script('acms-admin', 'acmsConfig', $this->getAdminScriptData());
    }

    /**
     * Enqueue frontend styles
     */
    public function enqueueFrontendStyles(): void
    {
        global $post;

        if (!is_a($post, 'WP_Post')) {
            return;
        }

        // Check for ACMS shortcodes
        $shortcodes = ['acms_list'];
        $hasShortcode = false;

        foreach ($shortcodes as $shortcode) {
            if (has_shortcode($post->post_content, $shortcode)) {
                $hasShortcode = true;
                break;
            }
        }

        if (!$hasShortcode) {
            return;
        }

        // Bootstrap Icons - check if theme already loaded it (handle: 'bootstrap-icons')
        // If not loaded by theme, load from plugin's local copy
        $iconsDep = [];
        if (!wp_style_is('bootstrap-icons', 'registered') && !wp_style_is('bootstrap-icons', 'enqueued')) {
            wp_enqueue_style(
                'bootstrap-icons',
                ACMS_PLUGIN_URL . 'assets/fonts/bootstrap-icons/bootstrap-icons.min.css',
                [],
                '1.11.3'
            );
        }
        $iconsDep = ['bootstrap-icons'];

        // Frontend CSS
        wp_enqueue_style(
            'acms-frontend',
            ACMS_PLUGIN_URL . 'assets/css/frontend.css',
            $iconsDep,
            $this->getVersion()
        );
    }

    /**
     * Enqueue frontend scripts
     */
    public function enqueueFrontendScripts(): void
    {
        global $post;

        if (!is_a($post, 'WP_Post')) {
            return;
        }

        // Check for ACMS shortcodes
        $shortcodes = ['acms_list'];
        $hasShortcode = false;

        foreach ($shortcodes as $shortcode) {
            if (has_shortcode($post->post_content, $shortcode)) {
                $hasShortcode = true;
                break;
            }
        }

        if (!$hasShortcode) {
            return;
        }

        // Frontend JS (defer to avoid render-blocking)
        wp_enqueue_script(
            'acms-frontend',
            ACMS_PLUGIN_URL . 'assets/js/frontend.js',
            [],
            $this->getVersion(),
            ['in_footer' => true, 'strategy' => 'defer']
        );
        wp_localize_script('acms-frontend', 'acmsFrontend', $this->getFrontendScriptData());

    }

    /**
     * Force enqueue frontend assets (for use in shortcode rendering)
     */
    public static function forceEnqueueFrontendAssets(): void
    {
        $instance = self::instance();

        // Bootstrap Icons - only load if theme hasn't loaded it
        if (!wp_style_is('bootstrap-icons', 'enqueued') && !wp_style_is('bootstrap-icons', 'registered')) {
            wp_enqueue_style(
                'bootstrap-icons',
                ACMS_PLUGIN_URL . 'assets/fonts/bootstrap-icons/bootstrap-icons.min.css',
                [],
                '1.11.3'
            );
        }

        // Frontend CSS
        if (!wp_style_is('acms-frontend', 'enqueued')) {
            wp_enqueue_style(
                'acms-frontend',
                ACMS_PLUGIN_URL . 'assets/css/frontend.css',
                ['bootstrap-icons'],
                $instance->getVersion()
            );
        }

        // Frontend JS (defer to avoid render-blocking)
        if (!wp_script_is('acms-frontend', 'enqueued')) {
            wp_enqueue_script(
                'acms-frontend',
                ACMS_PLUGIN_URL . 'assets/js/frontend.js',
                [],
                $instance->getVersion(),
                ['in_footer' => true, 'strategy' => 'defer']
            );
            wp_localize_script('acms-frontend', 'acmsFrontend', $instance->getFrontendScriptData());
        }
    }

    /**
     * Get frontend script localization data (for LivePrices JS module)
     */
    private function getFrontendScriptData(): array
    {
        $updateTooltip = defined('ACMS_UPDATE_TOOLTIP')
            ? ACMS_UPDATE_TOOLTIP
            : __('Last update on {date} / Affiliate links / Images, Product Titles, and Product Highlights from Amazon Product Advertising API.', 'affiliatecms-pro');

        return [
            'restUrl'          => rest_url('acms/v1/'),
            'nonce'            => wp_create_nonce('wp_rest'),
            'updateTooltipTpl' => $updateTooltip,
            'i18n'             => [
                'save'         => __('Save', 'affiliatecms-pro'),
                'in_stock'     => __('In Stock', 'affiliatecms-pro'),
                'out_of_stock' => __('Out of Stock', 'affiliatecms-pro'),
            ],
        ];
    }

    /**
     * Get admin script localization data
     */
    private function getAdminScriptData(): array
    {
        return [
            'restUrl' => rest_url('acms/v1/'),
            'nonce' => wp_create_nonce('wp_rest'),
            'pluginUrl' => ACMS_PLUGIN_URL,
            'i18n' => [
                'confirm_delete' => __('Are you sure you want to delete?', 'affiliatecms-pro'),
                'loading' => __('Loading...', 'affiliatecms-pro'),
                'success' => __('Success!', 'affiliatecms-pro'),
                'error' => __('An error occurred', 'affiliatecms-pro'),
                'save' => __('Save', 'affiliatecms-pro'),
                'cancel' => __('Cancel', 'affiliatecms-pro'),
                'delete' => __('Delete', 'affiliatecms-pro'),
                'edit' => __('Edit', 'affiliatecms-pro'),
                'add' => __('Add', 'affiliatecms-pro'),
                'search' => __('Search...', 'affiliatecms-pro'),
                'no_results' => __('No results found', 'affiliatecms-pro'),
                'page_of' => __('Page %1$d of %2$d', 'affiliatecms-pro'),
                'rows_selected' => __('%d row(s) selected', 'affiliatecms-pro'),
            ],
        ];
    }

    /**
     * Get plugin version
     * In development mode (WP_DEBUG), use timestamp to bust cache
     */
    private function getVersion(): string
    {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            // Use timestamp for cache busting in development
            return (string) time();
        }
        return defined('ACMS_VERSION') ? ACMS_VERSION : '1.0.0';
    }

    // Prevent cloning
    private function __clone() {}
}
