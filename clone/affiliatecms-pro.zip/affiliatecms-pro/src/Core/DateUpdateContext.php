<?php
/**
 * Date Update Context Manager
 *
 * Manages context-based date placeholder replacement to ensure accurate updates.
 * Instead of searching for placeholders (%year%, %month%, etc.), this tracks the
 * exact context where date values appear, allowing precise replacement over time.
 *
 * Example:
 * - Original: "Best Coffee Maker %month_text% %year%"
 * - After replace: "Best Coffee Maker January 2026"
 * - Context stored: "Best Coffee Maker January 2026 Reviews"
 * - Next month: Replace "January 2026" → "February 2026" only in this context
 *
 * @package AffiliateCMS\Pro\Core
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro\Core;

class DateUpdateContext
{
    /**
     * Meta key for storing context map
     */
    public const META_KEY = '_acms_date_update_map';

    /**
     * Meta key for storing generation date
     */
    public const META_KEY_GENERATED_DATE = '_acms_generated_date';

    /**
     * Number of words to capture before the date value
     */
    private const CONTEXT_WORDS_BEFORE = 5;

    /**
     * Number of words to capture after the date value
     */
    private const CONTEXT_WORDS_AFTER = 5;

    /**
     * Capture contexts from replaced text
     *
     * Finds all occurrences of date values and captures surrounding context.
     *
     * @param string $originalText Text with placeholders (before replacement)
     * @param string $replacedText Text after placeholder replacement
     * @param array $datePlaceholders Map of placeholder => value (e.g., ['%year%' => '2026'])
     * @return array Array of context items with structure:
     *               [
     *                 'context' => 'surrounding text with value',
     *                 'old_value' => 'January 2026',
     *                 'placeholder_types' => ['month_text', 'year']
     *               ]
     */
    public static function captureContexts(
        string $originalText,
        string $replacedText,
        array $datePlaceholders
    ): array {
        if (empty($datePlaceholders) || empty($replacedText)) {
            return [];
        }

        $contexts = [];

        // Group placeholders by their combination in original text
        $placeholderGroups = self::findPlaceholderGroups($originalText, $datePlaceholders);

        foreach ($placeholderGroups as $group) {
            // Get the combined value (e.g., "January 2026")
            $combinedValue = $group['value'];

            // Find all occurrences of this value in replaced text
            $offset = 0;
            while (($pos = mb_strpos($replacedText, $combinedValue, $offset)) !== false) {
                // Extract context around this occurrence
                $context = self::extractContext($replacedText, $pos, mb_strlen($combinedValue));

                // Only add if context is unique
                if (!self::contextExists($contexts, $context)) {
                    $contexts[] = [
                        'context' => $context,
                        'old_value' => $combinedValue,
                        'placeholder_types' => $group['types'],
                    ];
                }

                $offset = $pos + mb_strlen($combinedValue);
            }
        }

        return $contexts;
    }

    /**
     * Find placeholder groups in original text
     *
     * Groups adjacent placeholders that appear together.
     * Example: "%month_text% %year%" becomes one group
     *
     * @param string $text Original text with placeholders
     * @param array $datePlaceholders Map of placeholder => value
     * @return array Array of groups with 'value' and 'types'
     */
    private static function findPlaceholderGroups(string $text, array $datePlaceholders): array
    {
        $groups = [];
        $placeholderPattern = '/%[a-z_]+%/';

        // Find all date placeholder sequences
        if (preg_match_all($placeholderPattern, $text, $matches, PREG_OFFSET_CAPTURE)) {
            $currentGroup = null;
            $lastOffset = -1;

            foreach ($matches[0] as $match) {
                $placeholder = $match[0];
                $offset = $match[1];

                // Check if this is a date placeholder
                if (!isset($datePlaceholders[$placeholder])) {
                    // End current group if exists
                    if ($currentGroup !== null) {
                        $groups[] = $currentGroup;
                        $currentGroup = null;
                    }
                    continue;
                }

                // Check if adjacent to previous placeholder (within 5 characters)
                $isAdjacent = ($lastOffset >= 0) && ($offset - $lastOffset <= 5);

                if ($isAdjacent && $currentGroup !== null) {
                    // Add to current group
                    $currentGroup['value'] .= ' ' . $datePlaceholders[$placeholder];
                    $currentGroup['types'][] = self::getPlaceholderType($placeholder);
                } else {
                    // Start new group
                    if ($currentGroup !== null) {
                        $groups[] = $currentGroup;
                    }

                    $currentGroup = [
                        'value' => $datePlaceholders[$placeholder],
                        'types' => [self::getPlaceholderType($placeholder)],
                    ];
                }

                $lastOffset = $offset + mb_strlen($placeholder);
            }

            // Add last group
            if ($currentGroup !== null) {
                $groups[] = $currentGroup;
            }
        }

        return $groups;
    }

    /**
     * Extract context around a position in text
     *
     * @param string $text Full text
     * @param int $position Position of the value
     * @param int $valueLength Length of the value
     * @return string Context string (N words before + value + N words after)
     */
    private static function extractContext(string $text, int $position, int $valueLength): string
    {
        // Extract the value itself
        $value = mb_substr($text, $position, $valueLength);

        // Extract text before
        $textBefore = mb_substr($text, 0, $position);
        $wordsBefore = self::extractLastWords($textBefore, self::CONTEXT_WORDS_BEFORE);

        // Extract text after
        $textAfter = mb_substr($text, $position + $valueLength);
        $wordsAfter = self::extractFirstWords($textAfter, self::CONTEXT_WORDS_AFTER);

        // Combine: before + value + after
        return trim($wordsBefore . ' ' . $value . ' ' . $wordsAfter);
    }

    /**
     * Extract last N words from text
     *
     * @param string $text Text to extract from
     * @param int $count Number of words
     * @return string Last N words
     */
    private static function extractLastWords(string $text, int $count): string
    {
        // Split by whitespace and punctuation boundaries
        $words = preg_split('/\s+/', trim($text), -1, PREG_SPLIT_NO_EMPTY);
        if (empty($words)) {
            return '';
        }

        $lastWords = array_slice($words, -$count);
        return implode(' ', $lastWords);
    }

    /**
     * Extract first N words from text
     *
     * @param string $text Text to extract from
     * @param int $count Number of words
     * @return string First N words
     */
    private static function extractFirstWords(string $text, int $count): string
    {
        // Split by whitespace
        $words = preg_split('/\s+/', trim($text), -1, PREG_SPLIT_NO_EMPTY);
        if (empty($words)) {
            return '';
        }

        $firstWords = array_slice($words, 0, $count);
        return implode(' ', $firstWords);
    }

    /**
     * Check if context already exists in array
     *
     * @param array $contexts Array of existing contexts
     * @param string $context Context to check
     * @return bool
     */
    private static function contextExists(array $contexts, string $context): bool
    {
        foreach ($contexts as $item) {
            if ($item['context'] === $context) {
                return true;
            }
        }
        return false;
    }

    /**
     * Get placeholder type name without % symbols
     *
     * @param string $placeholder Placeholder with % (e.g., '%year%')
     * @return string Type name (e.g., 'year')
     */
    private static function getPlaceholderType(string $placeholder): string
    {
        return trim($placeholder, '%');
    }

    /**
     * Replace old date values with new ones using context matching
     *
     * @param string $text Current text content
     * @param array $contextMap Context map from metadata
     * @param array $newDateValues New date placeholder values
     * @return array ['text' => updated text, 'context_map' => updated context map]
     */
    public static function replaceWithContext(
        string $text,
        array $contextMap,
        array $newDateValues
    ): array {
        if (empty($contextMap) || empty($text)) {
            return ['text' => $text, 'context_map' => $contextMap];
        }

        $updatedText = $text;
        $updatedContextMap = [];

        foreach ($contextMap as $contextItem) {
            $oldContext = $contextItem['context'] ?? '';
            $oldValue = $contextItem['old_value'] ?? '';
            $types = $contextItem['placeholder_types'] ?? [];

            if (empty($oldContext) || empty($oldValue)) {
                continue;
            }

            // Build new value from placeholder types
            $newValue = self::buildValueFromTypes($types, $newDateValues);

            if ($newValue === $oldValue) {
                // No change needed, keep old context
                $updatedContextMap[] = $contextItem;
                continue;
            }

            // Replace old value with new value in the context
            $newContext = str_replace($oldValue, $newValue, $oldContext);

            // Find and replace the old context in text
            if (mb_strpos($updatedText, $oldContext) !== false) {
                $updatedText = str_replace($oldContext, $newContext, $updatedText);

                // Update context map with new values
                $updatedContextMap[] = [
                    'context' => $newContext,
                    'old_value' => $newValue,
                    'placeholder_types' => $types,
                ];
            } else {
                // Context not found, keep old (might have been manually edited)
                $updatedContextMap[] = $contextItem;
            }
        }

        return [
            'text' => $updatedText,
            'context_map' => $updatedContextMap,
        ];
    }

    /**
     * Build date value from placeholder types
     *
     * @param array $types Array of placeholder type names (e.g., ['month_text', 'year'])
     * @param array $dateValues Map of date placeholder values
     * @return string Combined value (e.g., "February 2026")
     */
    private static function buildValueFromTypes(array $types, array $dateValues): string
    {
        $parts = [];

        foreach ($types as $type) {
            $placeholder = "%{$type}%";
            if (isset($dateValues[$placeholder])) {
                $parts[] = $dateValues[$placeholder];
            }
        }

        return implode(' ', $parts);
    }

    /**
     * Save context map to post meta
     *
     * @param int $postId Post ID
     * @param array $contextMap Full context map (title, content, excerpt, etc.)
     * @param string $generatedDate Date string (Y-m format, e.g., "2026-01")
     */
    public static function saveToPost(int $postId, array $contextMap, string $generatedDate): void
    {
        // Only save if there are contexts
        if (!empty($contextMap)) {
            update_post_meta($postId, self::META_KEY, wp_json_encode($contextMap));
            update_post_meta($postId, self::META_KEY_GENERATED_DATE, $generatedDate);
        }
    }

    /**
     * Load context map from post meta
     *
     * @param int $postId Post ID
     * @return array|null Context map or null if not found
     */
    public static function loadFromPost(int $postId): ?array
    {
        $json = get_post_meta($postId, self::META_KEY, true);
        if (empty($json)) {
            return null;
        }

        $contextMap = json_decode($json, true);
        return is_array($contextMap) ? $contextMap : null;
    }

    /**
     * Get generated date from post meta
     *
     * @param int $postId Post ID
     * @return string|null Date string (Y-m format) or null
     */
    public static function getGeneratedDate(int $postId): ?string
    {
        $date = get_post_meta($postId, self::META_KEY_GENERATED_DATE, true);
        return !empty($date) ? $date : null;
    }

    /**
     * Check if post needs date update
     *
     * @param int $postId Post ID
     * @return bool True if post has context map and needs update
     */
    public static function needsUpdate(int $postId): bool
    {
        $generatedDate = self::getGeneratedDate($postId);
        if ($generatedDate === null) {
            return false;
        }

        $currentDate = date('Y-m');
        return $generatedDate !== $currentDate;
    }
}
