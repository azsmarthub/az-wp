<?php
/**
 * Meta Boxes Manager
 *
 * Handles custom meta boxes for Review post type including noindex setting.
 *
 * @package AffiliateCMS\Pro\Core
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro\Core;

class MetaBoxes
{
    private static ?MetaBoxes $instance = null;

    /**
     * Get singleton instance
     */
    public static function instance(): MetaBoxes
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Register hooks
     */
    public function register(): void
    {
        // Add meta box to post editor
        add_action('add_meta_boxes', [$this, 'addMetaBoxes']);

        // Save meta box data
        add_action('save_post', [$this, 'saveMetaBox'], 10, 2);

        // Output noindex meta tag on frontend
        add_action('wp_head', [$this, 'outputNoindexMeta'], 1);
    }

    /**
     * Add meta boxes to Review post types
     */
    public function addMetaBoxes(): void
    {
        $settings = PostTypeManager::getSettings();

        foreach ($settings as $type => $config) {
            if (empty($config['enabled'])) {
                continue;
            }

            $postType = 'acms_' . $type;

            // Add SEO Settings meta box
            add_meta_box(
                'acms_seo_settings',
                __('SEO Settings', 'affiliatecms-pro'),
                [$this, 'renderSeoMetaBox'],
                $postType,
                'side',
                'high'
            );
        }
    }

    /**
     * Render SEO settings meta box
     *
     * @param \WP_Post $post Current post object
     */
    public function renderSeoMetaBox(\WP_Post $post): void
    {
        // Add nonce for security
        wp_nonce_field('acms_seo_meta_box', 'acms_seo_meta_box_nonce');

        // Get current noindex value
        $noindex = get_post_meta($post->ID, '_acms_noindex', true);

        // Check for Yoast/RankMath values if our meta is empty
        if ($noindex === '') {
            if (defined('WPSEO_VERSION')) {
                $yoastNoindex = get_post_meta($post->ID, '_yoast_wpseo_meta-robots-noindex', true);
                $noindex = ($yoastNoindex === '1') ? '1' : '';
            } elseif (defined('RANK_MATH_VERSION')) {
                $rankMathRobots = get_post_meta($post->ID, 'rank_math_robots', true);
                if (is_array($rankMathRobots) && in_array('noindex', $rankMathRobots)) {
                    $noindex = '1';
                }
            }
        }
        ?>
        <div class="acms-seo-settings">
            <p>
                <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
                    <input type="checkbox" name="acms_noindex" value="1" <?php checked($noindex, '1'); ?> />
                    <span><?php _e('Set as noindex', 'affiliatecms-pro'); ?></span>
                </label>
            </p>
            <p class="description" style="margin-top: 8px; color: #666;">
                <?php _e('When enabled, search engines will not index this post.', 'affiliatecms-pro'); ?>
            </p>

            <?php if (defined('WPSEO_VERSION') || defined('RANK_MATH_VERSION')): ?>
                <p class="description" style="margin-top: 8px; padding: 8px; background: #f5f5f5; border-radius: 4px;">
                    <span class="dashicons dashicons-info" style="color: #0073aa; vertical-align: middle;"></span>
                    <?php
                    if (defined('WPSEO_VERSION')) {
                        _e('Yoast SEO detected - settings will sync automatically.', 'affiliatecms-pro');
                    } elseif (defined('RANK_MATH_VERSION')) {
                        _e('Rank Math detected - settings will sync automatically.', 'affiliatecms-pro');
                    }
                    ?>
                </p>
            <?php endif; ?>
        </div>
        <?php
    }

    /**
     * Save meta box data
     *
     * @param int $postId Post ID
     * @param \WP_Post $post Post object
     */
    public function saveMetaBox(int $postId, \WP_Post $post): void
    {
        // Check nonce
        if (!isset($_POST['acms_seo_meta_box_nonce']) ||
            !wp_verify_nonce($_POST['acms_seo_meta_box_nonce'], 'acms_seo_meta_box')) {
            return;
        }

        // Check autosave
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        // Check permissions
        if (!current_user_can('edit_post', $postId)) {
            return;
        }

        // Check if this is our post type
        $settings = PostTypeManager::getSettings();
        $ourPostTypes = [];
        foreach ($settings as $type => $config) {
            if (!empty($config['enabled'])) {
                $ourPostTypes[] = 'acms_' . $type;
            }
        }

        if (!in_array($post->post_type, $ourPostTypes)) {
            return;
        }

        // Get the noindex value
        $noindex = isset($_POST['acms_noindex']) ? '1' : '';

        // Save our meta
        if ($noindex === '1') {
            update_post_meta($postId, '_acms_noindex', '1');
        } else {
            delete_post_meta($postId, '_acms_noindex');
        }

        // Sync with Yoast SEO if active
        if (defined('WPSEO_VERSION')) {
            if ($noindex === '1') {
                update_post_meta($postId, '_yoast_wpseo_meta-robots-noindex', '1');
            } else {
                delete_post_meta($postId, '_yoast_wpseo_meta-robots-noindex');
            }
        }

        // Sync with Rank Math if active
        if (defined('RANK_MATH_VERSION')) {
            if ($noindex === '1') {
                update_post_meta($postId, 'rank_math_robots', ['noindex']);
            } else {
                update_post_meta($postId, 'rank_math_robots', ['index']);
            }
        }
    }

    /**
     * Output noindex meta tag on frontend
     */
    public function outputNoindexMeta(): void
    {
        // Only on singular posts
        if (!is_singular()) {
            return;
        }

        $postId = get_queried_object_id();
        if (!$postId) {
            return;
        }

        // Check if this is our post type
        $postType = get_post_type($postId);
        $settings = PostTypeManager::getSettings();
        $ourPostTypes = [];
        foreach ($settings as $type => $config) {
            if (!empty($config['enabled'])) {
                $ourPostTypes[] = 'acms_' . $type;
            }
        }

        if (!in_array($postType, $ourPostTypes)) {
            return;
        }

        // Check noindex meta
        $noindex = get_post_meta($postId, '_acms_noindex', true);

        if ($noindex === '1') {
            // Don't output if Yoast or RankMath is active (they handle it)
            if (defined('WPSEO_VERSION') || defined('RANK_MATH_VERSION')) {
                return;
            }

            echo '<meta name="robots" content="noindex, follow" />' . "\n";
        }
    }
}
