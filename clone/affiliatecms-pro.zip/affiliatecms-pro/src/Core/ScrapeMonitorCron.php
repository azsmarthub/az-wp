<?php
/**
 * Scrape Monitor Cron Job
 *
 * Monitors queue items that have linked ASINs and checks if scraping is complete.
 * When scrape progress reaches threshold, marks the queue item as ready for AI post generation.
 *
 * Flow:
 * 1. Queue item searches ASINs (status = 'processing' or 'pending' with linked_asins)
 * 2. Products are scraped in background
 * 3. ScrapeMonitorCron checks scrape progress every 5 minutes
 * 4. When threshold reached (default 80%), marks ai_post_status = 'queued'
 * 5. PostAiCron picks up items with ai_post_status = 'queued' and scraped products
 *
 * NOTE: Only checks scrape status, NOT Product AI status.
 * Raw scraped data (title, features, specs, reviews) is sufficient for AI post generation.
 *
 * @package AffiliateCMS\Pro\Core
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro\Core;

use AffiliateCMS\Pro\Database\Schema;

class ScrapeMonitorCron
{
    /**
     * Hook name for the cron job
     */
    public const CRON_HOOK = 'acms_scrape_monitor';

    /**
     * Scrape progress threshold to consider ready (percentage)
     */
    private const SCRAPE_THRESHOLD = 80;

    /**
     * Queue items to check per run
     */
    private const BATCH_SIZE = 10;

    /**
     * Singleton instance
     */
    private static ?ScrapeMonitorCron $instance = null;

    /**
     * Get singleton instance
     */
    public static function instance(): ScrapeMonitorCron
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Register the cron job
     */
    public function register(): void
    {
        add_action(self::CRON_HOOK, [$this, 'monitorScrapeProgress']);

        // WP-Cron as safety net (server cron is primary)
        if (!wp_next_scheduled(self::CRON_HOOK)) {
            wp_schedule_event(time(), 'every_5_minutes', self::CRON_HOOK);
        }
    }

    /**
     * Monitor scrape progress for queue items
     *
     * Finds queue items that:
     * - Have linked_asins
     * - status is 'completed' (post created) OR 'processing'
     * - ai_post_status is NULL or 'not_generated'
     *
     * When scrape threshold reached (80% products scraped):
     * - Sets ai_post_status = 'queued' for PostAiCron to pick up
     * - Raw scraped data is sufficient for AI post generation
     */
    public function monitorScrapeProgress(): void
    {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[ACMS ScrapeMonitorCron] Starting scrape progress monitoring');
        }

        // Get queue items needing monitoring
        $queueItems = $this->getQueueItemsToMonitor();

        if (empty($queueItems)) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('[ACMS ScrapeMonitorCron] No queue items need monitoring');
            }
            return;
        }

        $readyCount = 0;
        $pendingCount = 0;

        foreach ($queueItems as $item) {
            $result = $this->checkAndUpdateItem($item);
            if ($result === 'ready') {
                $readyCount++;
            } else {
                $pendingCount++;
            }
        }

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("[ACMS ScrapeMonitorCron] Completed. Ready: {$readyCount}, Still pending: {$pendingCount}");
        }
    }

    /**
     * Get queue items that need scrape progress monitoring
     *
     * @return array Queue items
     */
    private function getQueueItemsToMonitor(): array
    {
        global $wpdb;
        $queueTable = Schema::queueTable();

        // Find queue items that:
        // 1. Have linked ASINs
        // 2. Are completed (post created) or still processing
        // 3. Don't have AI post generated yet
        $sql = $wpdb->prepare(
            "SELECT * FROM {$queueTable}
             WHERE linked_asins IS NOT NULL
             AND JSON_LENGTH(linked_asins) > 0
             AND (ai_post_status IS NULL OR ai_post_status IN ('not_generated', 'queued'))
             AND status IN ('completed', 'processing')
             ORDER BY created_at ASC
             LIMIT %d",
            self::BATCH_SIZE
        );

        $rows = $wpdb->get_results($sql, ARRAY_A);

        return $rows ?: [];
    }

    /**
     * Check scrape progress and update queue item if ready
     *
     * @param array $item Queue item
     * @return string 'ready' if threshold reached, 'pending' otherwise
     */
    private function checkAndUpdateItem(array $item): string
    {
        global $wpdb;
        $productsTable = Schema::productsTable();
        $queueTable = Schema::queueTable();

        $queueId = (int) $item['id'];
        // Handle both JSON string and already-decoded array
        $linkedAsins = isset($item['linked_asins'])
            ? (is_array($item['linked_asins']) ? $item['linked_asins'] : json_decode($item['linked_asins'], true))
            : [];

        if (empty($linkedAsins)) {
            return 'pending';
        }

        $totalAsins = count($linkedAsins);

        // Build IN clause for ASINs
        $asinPlaceholders = implode(',', array_fill(0, $totalAsins, '%s'));

        // Count scraped products (raw data is sufficient for AI post generation)
        $scrapedCount = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$productsTable}
             WHERE asin IN ({$asinPlaceholders})
             AND status = 'scraped'",
            ...$linkedAsins
        ));

        // Calculate scrape progress
        $scrapeProgress = $totalAsins > 0 ? round(($scrapedCount / $totalAsins) * 100) : 0;

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("[ACMS ScrapeMonitorCron] Queue #{$queueId}: Scrape {$scrapeProgress}% ({$scrapedCount}/{$totalAsins})");
        }

        // Check if ready for AI post generation
        // Only requirement: Scrape progress >= threshold
        // Raw scraped data (title, features, specs, reviews) is sufficient for AI
        if ($scrapeProgress >= self::SCRAPE_THRESHOLD) {
            // Mark as ready for AI post generation
            $wpdb->update(
                $queueTable,
                [
                    'ai_post_status' => 'queued',
                    'ai_post_error' => null,
                ],
                ['id' => $queueId],
                ['%s', '%s'],
                ['%d']
            );

            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("[ACMS ScrapeMonitorCron] Queue #{$queueId} marked as ready for AI post generation (scrape {$scrapeProgress}% >= {self::SCRAPE_THRESHOLD}%)");
            }

            // Fire event so AI Bootstrap can trigger post generation immediately
            do_action('acms_post_ai_queued', $queueId);

            return 'ready';
        }

        return 'pending';
    }

    /**
     * Unschedule the cron job
     */
    public function unschedule(): void
    {
        $timestamp = wp_next_scheduled(self::CRON_HOOK);
        if ($timestamp) {
            wp_unschedule_event($timestamp, self::CRON_HOOK);
        }
    }

    /**
     * Run monitoring manually (for testing or manual trigger)
     *
     * @return array Result
     */
    public function runManually(): array
    {
        $startTime = microtime(true);

        ob_start();
        $this->monitorScrapeProgress();
        $output = ob_get_clean();

        $duration = round((microtime(true) - $startTime) * 1000);

        return [
            'success' => true,
            'message' => 'Scrape monitoring completed',
            'duration_ms' => $duration,
            'log' => $output,
        ];
    }

    /**
     * Get next scheduled run time
     *
     * @return int|false Unix timestamp or false if not scheduled
     */
    public function getNextRun()
    {
        return wp_next_scheduled(self::CRON_HOOK);
    }

    /**
     * Get statistics about queue items
     *
     * @return array Statistics
     */
    public function getStats(): array
    {
        global $wpdb;
        $queueTable = Schema::queueTable();
        $productsTable = Schema::productsTable();

        // Count items with linked ASINs
        $withAsins = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$queueTable}
             WHERE linked_asins IS NOT NULL
             AND JSON_LENGTH(linked_asins) > 0"
        );

        // Count items waiting for scraping
        $waitingScrape = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$queueTable}
             WHERE linked_asins IS NOT NULL
             AND JSON_LENGTH(linked_asins) > 0
             AND (ai_post_status IS NULL OR ai_post_status = 'not_generated')
             AND status IN ('completed', 'processing')"
        );

        // Count items ready for AI (queued)
        $readyForAi = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$queueTable}
             WHERE ai_post_status = 'queued'"
        );

        return [
            'with_asins' => $withAsins,
            'waiting_scrape' => $waitingScrape,
            'ready_for_ai' => $readyForAi,
            'scrape_threshold' => self::SCRAPE_THRESHOLD,
            'next_run' => $this->getNextRun(),
            'batch_size' => self::BATCH_SIZE,
        ];
    }
}
