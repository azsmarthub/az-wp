<?php
/**
 * Amazon Product Advertising API Provider
 *
 * Uses official Amazon PA-API 5.0
 * https://webservices.amazon.com/paapi5/documentation/
 *
 * SIMPLIFIED: No key rotation, no retry logic with multiple keys
 *
 * Response structure from PA-API GetItems:
 * {
 *   "ItemsResult": {
 *     "Items": [{
 *       "ASIN": "B0D7PPG25F",
 *       "ItemInfo": {
 *         "Title": {"DisplayValue": "Product Title"},
 *         "Features": {"DisplayValues": [...]},
 *         "ByLineInfo": {"Brand": {"DisplayValue": "Brand"}},
 *         "Classifications": {"ProductGroup": {"DisplayValue": "Category"}}
 *       },
 *       "Offers": {
 *         "Listings": [{
 *           "Price": {"Amount": 449.99, "Currency": "USD"},
 *           "SavingBasis": {"Amount": 799.00},
 *           "Availability": {"Type": "Now"},
 *           "DeliveryInfo": {"IsPrimeEligible": true}
 *         }]
 *       },
 *       "Images": {"Primary": {"Large": {"URL": "https://..."}}},
 *       "BrowseNodeInfo": {"BrowseNodes": [...]}
 *     }]
 *   }
 * }
 *
 * NOTE: PA-API does NOT provide rating or reviews_count.
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro\Core;

class PaapiProvider
{
    private const TIMEOUT = 30;

    /**
     * PA-API endpoints and regions by marketplace
     */
    private const REGIONS = [
        'com' => ['host' => 'webservices.amazon.com', 'region' => 'us-east-1'],
        'co.uk' => ['host' => 'webservices.amazon.co.uk', 'region' => 'eu-west-1'],
        'de' => ['host' => 'webservices.amazon.de', 'region' => 'eu-west-1'],
        'fr' => ['host' => 'webservices.amazon.fr', 'region' => 'eu-west-1'],
        'it' => ['host' => 'webservices.amazon.it', 'region' => 'eu-west-1'],
        'es' => ['host' => 'webservices.amazon.es', 'region' => 'eu-west-1'],
        'co.jp' => ['host' => 'webservices.amazon.co.jp', 'region' => 'us-west-2'],
        'ca' => ['host' => 'webservices.amazon.ca', 'region' => 'us-east-1'],
        'com.au' => ['host' => 'webservices.amazon.com.au', 'region' => 'us-west-2'],
        'in' => ['host' => 'webservices.amazon.in', 'region' => 'eu-west-1'],
        'com.mx' => ['host' => 'webservices.amazon.com.mx', 'region' => 'us-east-1'],
        'com.br' => ['host' => 'webservices.amazon.com.br', 'region' => 'us-east-1'],
    ];

    private string $accessKey;
    private string $secretKey;
    private string $partnerTag;
    private string $marketplace;
    private ?string $lastError = null;

    /**
     * Constructor
     *
     * @param string $accessKey AWS Access Key ID
     * @param string $secretKey AWS Secret Access Key
     * @param string $partnerTag Amazon Associates Partner Tag
     * @param string $marketplace Marketplace code (com, co.uk, de, etc.)
     */
    public function __construct(
        string $accessKey,
        string $secretKey,
        string $partnerTag,
        string $marketplace = 'com'
    ) {
        $this->accessKey = $accessKey;
        $this->secretKey = $secretKey;
        $this->partnerTag = $partnerTag;
        $this->marketplace = $marketplace;
    }

    /**
     * Fetch product data from Amazon PA-API
     *
     * @param string $asin Amazon product ASIN
     * @return array|null Normalized product data or null on failure
     */
    public function fetch(string $asin): ?array
    {
        $this->lastError = null;

        $regionConfig = self::REGIONS[$this->marketplace] ?? self::REGIONS['com'];
        $host = $regionConfig['host'];
        $region = $regionConfig['region'];

        $payload = $this->buildRequest($asin);
        $payloadJson = wp_json_encode($payload);

        $headers = $this->signRequest(
            $host,
            '/paapi5/getitems',
            $payloadJson,
            $region
        );

        $response = wp_remote_post("https://{$host}/paapi5/getitems", [
            'headers' => $headers,
            'body' => $payloadJson,
            'timeout' => self::TIMEOUT,
        ]);

        if (is_wp_error($response)) {
            $this->lastError = $response->get_error_message();
            return null;
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);

        if ($code !== 200) {
            $error = json_decode($body, true);
            $this->lastError = $error['Errors'][0]['Message'] ?? "HTTP {$code}";
            return null;
        }

        return $this->parseResponse($body);
    }

    /**
     * Quick fetch - fetch only dynamic data (price, stock)
     *
     * Much faster than full fetch. Only requests price and availability fields.
     * Note: PA-API does NOT provide rating or reviews_count data.
     *
     * @param string $asin Amazon product ASIN
     * @return array|null Dynamic data (price, in_stock, is_prime) or null on failure
     */
    public function quickFetch(string $asin): ?array
    {
        $this->lastError = null;

        $regionConfig = self::REGIONS[$this->marketplace] ?? self::REGIONS['com'];
        $host = $regionConfig['host'];
        $region = $regionConfig['region'];

        $payload = $this->buildQuickRequest($asin);
        $payloadJson = wp_json_encode($payload);

        $headers = $this->signRequest(
            $host,
            '/paapi5/getitems',
            $payloadJson,
            $region
        );

        $response = wp_remote_post("https://{$host}/paapi5/getitems", [
            'headers' => $headers,
            'body' => $payloadJson,
            'timeout' => self::TIMEOUT,
        ]);

        if (is_wp_error($response)) {
            $this->lastError = $response->get_error_message();
            return null;
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);

        if ($code !== 200) {
            $error = json_decode($body, true);
            $this->lastError = $error['Errors'][0]['Message'] ?? "HTTP {$code}";
            return null;
        }

        return $this->parseQuickResponse($body);
    }

    /**
     * Build PA-API GetItems request for quick fetch (minimal resources)
     *
     * @param string $asin Amazon product ASIN
     * @return array Request payload
     */
    private function buildQuickRequest(string $asin): array
    {
        return [
            'ItemIds' => [$asin],
            'PartnerTag' => $this->partnerTag,
            'PartnerType' => 'Associates',
            'Marketplace' => "www.amazon.{$this->marketplace}",
            'Resources' => [
                'Offers.Listings.Price',
                'Offers.Listings.SavingBasis',
                'Offers.Listings.DeliveryInfo.IsPrimeEligible',
                'Offers.Listings.Availability.Type',
            ],
        ];
    }

    /**
     * Parse PA-API response for quick scrape (dynamic data only)
     *
     * @param string $response Raw JSON response
     * @return array|null Dynamic data or null on failure
     */
    private function parseQuickResponse(string $response): ?array
    {
        $data = json_decode($response, true);

        if (!isset($data['ItemsResult']['Items'][0])) {
            $this->lastError = 'Product not found';
            return null;
        }

        $item = $data['ItemsResult']['Items'][0];
        $offers = $item['Offers']['Listings'][0] ?? [];

        // PA-API doesn't provide rating or reviews_count
        return [
            'price' => $this->extractPrice($offers),
            'original_price' => $this->extractOriginalPrice($offers),
            'in_stock' => $this->extractAvailability($offers),
            'is_prime' => $offers['DeliveryInfo']['IsPrimeEligible'] ?? false,
            'rating' => null,
            'reviews_count' => null,
        ];
    }

    /**
     * Build PA-API GetItems request payload
     *
     * @param string $asin Amazon product ASIN
     * @return array Request payload
     */
    private function buildRequest(string $asin): array
    {
        return [
            'ItemIds' => [$asin],
            'PartnerTag' => $this->partnerTag,
            'PartnerType' => 'Associates',
            'Marketplace' => "www.amazon.{$this->marketplace}",
            'Resources' => [
                'Images.Primary.Large',
                'Images.Variants.Large',
                'ItemInfo.Title',
                'ItemInfo.ByLineInfo',
                'ItemInfo.Features',
                'ItemInfo.ProductInfo',
                'ItemInfo.TechnicalInfo',
                'ItemInfo.Classifications',
                'Offers.Listings.Price',
                'Offers.Listings.SavingBasis',
                'Offers.Listings.DeliveryInfo.IsPrimeEligible',
                'Offers.Listings.Availability.Type',
                'Offers.Listings.MerchantInfo',
                'BrowseNodeInfo.BrowseNodes',
            ],
        ];
    }

    /**
     * Sign request using AWS Signature Version 4
     *
     * @param string $host API host
     * @param string $path API path
     * @param string $payload Request body
     * @param string $region AWS region
     * @return array HTTP headers including authorization
     */
    private function signRequest(
        string $host,
        string $path,
        string $payload,
        string $region
    ): array {
        $service = 'ProductAdvertisingAPI';
        $method = 'POST';
        $timestamp = gmdate('Ymd\THis\Z');
        $date = gmdate('Ymd');

        $contentType = 'application/json; charset=utf-8';
        $target = 'com.amazon.paapi5.v1.ProductAdvertisingAPIv1.GetItems';

        // Create canonical headers
        $canonicalHeaders = implode("\n", [
            "content-encoding:amz-1.0",
            "content-type:{$contentType}",
            "host:{$host}",
            "x-amz-date:{$timestamp}",
            "x-amz-target:{$target}",
        ]) . "\n";

        $signedHeaders = 'content-encoding;content-type;host;x-amz-date;x-amz-target';

        // Create canonical request
        $payloadHash = hash('sha256', $payload);
        $canonicalRequest = implode("\n", [
            $method,
            $path,
            '', // query string
            $canonicalHeaders,
            $signedHeaders,
            $payloadHash,
        ]);

        // Create string to sign
        $algorithm = 'AWS4-HMAC-SHA256';
        $credentialScope = "{$date}/{$region}/{$service}/aws4_request";
        $stringToSign = implode("\n", [
            $algorithm,
            $timestamp,
            $credentialScope,
            hash('sha256', $canonicalRequest),
        ]);

        // Calculate signature
        $signature = $this->getSignature($stringToSign, $date, $region, $service);

        // Create authorization header
        $authorization = "{$algorithm} Credential={$this->accessKey}/{$credentialScope}, SignedHeaders={$signedHeaders}, Signature={$signature}";

        return [
            'Content-Type' => $contentType,
            'Content-Encoding' => 'amz-1.0',
            'Host' => $host,
            'X-Amz-Date' => $timestamp,
            'X-Amz-Target' => $target,
            'Authorization' => $authorization,
        ];
    }

    /**
     * Generate AWS Signature V4 signature
     *
     * @param string $stringToSign String to sign
     * @param string $date Date in Ymd format
     * @param string $region AWS region
     * @param string $service AWS service name
     * @return string Signature
     */
    private function getSignature(
        string $stringToSign,
        string $date,
        string $region,
        string $service
    ): string {
        $kSecret = 'AWS4' . $this->secretKey;
        $kDate = hash_hmac('sha256', $date, $kSecret, true);
        $kRegion = hash_hmac('sha256', $region, $kDate, true);
        $kService = hash_hmac('sha256', $service, $kRegion, true);
        $kSigning = hash_hmac('sha256', 'aws4_request', $kService, true);

        return hash_hmac('sha256', $stringToSign, $kSigning);
    }

    /**
     * Parse PA-API response
     *
     * @param string $response Raw JSON response
     * @return array|null Normalized product data or null on failure
     */
    private function parseResponse(string $response): ?array
    {
        $data = json_decode($response, true);

        if (!isset($data['ItemsResult']['Items'][0])) {
            $this->lastError = 'Product not found';
            return null;
        }

        $item = $data['ItemsResult']['Items'][0];

        return $this->normalizeProduct($item);
    }

    /**
     * Normalize product data to standard format
     *
     * @param array $item PA-API item data
     * @return array Normalized product data
     */
    private function normalizeProduct(array $item): array
    {
        $itemInfo = $item['ItemInfo'] ?? [];
        $offers = $item['Offers']['Listings'][0] ?? [];
        $browseNodes = $item['BrowseNodeInfo']['BrowseNodes'] ?? [];

        // === CORE FIELDS ===
        $product = [
            'title' => $itemInfo['Title']['DisplayValue'] ?? '',
            'brand' => $itemInfo['ByLineInfo']['Brand']['DisplayValue']
                ?? $itemInfo['ByLineInfo']['Manufacturer']['DisplayValue']
                ?? '',
            'price' => $this->extractPrice($offers),
            'original_price' => $this->extractOriginalPrice($offers),
            'currency' => $offers['Price']['Currency'] ?? 'USD',
            'rating' => null, // PA-API doesn't provide rating
            'reviews_count' => 0, // PA-API doesn't provide reviews count
            'in_stock' => $this->extractAvailability($offers),
            'is_prime' => $offers['DeliveryInfo']['IsPrimeEligible'] ?? false,
        ];

        // === IMAGES ===
        $allImages = $this->extractAllImages($item);
        $product['image_url'] = !empty($allImages) ? $allImages[0] : '';
        $product['images_gallery'] = $allImages;

        // === DESCRIPTION ===
        $product['description'] = '';
        $product['features'] = $itemInfo['Features']['DisplayValues'] ?? [];

        // === CATEGORY ===
        $categoryData = $this->extractCategoryData($browseNodes);
        $product['category'] = $categoryData['category'];
        $product['category_path'] = $categoryData['category_path'];
        $product['category_tree'] = $categoryData['category_tree'];
        $product['category_ids'] = $categoryData['category_ids'];

        // === SPECIFICATIONS ===
        $product['product_information'] = $this->extractProductInformation($itemInfo);
        $product['specifications'] = $this->extractSpecifications($itemInfo);
        $product['best_sellers_rank'] = null; // PA-API doesn't provide this

        // === SELLER INFO ===
        $product['seller_info'] = $this->extractSellerInfo($offers);

        // === REVIEWS (PA-API doesn't provide) ===
        $product['reviews_data'] = null;
        $product['top_reviews'] = null;
        $product['reviews_summary'] = null;

        return $product;
    }

    /**
     * Extract price from offers
     */
    private function extractPrice(array $offers): ?float
    {
        if (isset($offers['Price']['Amount'])) {
            return round((float) $offers['Price']['Amount'], 2);
        }
        return null;
    }

    /**
     * Extract original price from offers
     */
    private function extractOriginalPrice(array $offers): ?float
    {
        if (isset($offers['SavingBasis']['Amount'])) {
            return round((float) $offers['SavingBasis']['Amount'], 2);
        }
        return null;
    }

    /**
     * Extract availability from offers
     */
    private function extractAvailability(array $offers): bool
    {
        if (isset($offers['Availability']['Type'])) {
            return $offers['Availability']['Type'] !== 'OutOfStock';
        }
        return true;
    }

    /**
     * Extract all images from PA-API response
     */
    private function extractAllImages(array $item): array
    {
        $images = [];

        // Primary image
        if (isset($item['Images']['Primary']['Large']['URL'])) {
            $images[] = $item['Images']['Primary']['Large']['URL'];
        }

        // Variant images
        $variants = $item['Images']['Variants'] ?? [];
        foreach ($variants as $variant) {
            if (isset($variant['Large']['URL'])) {
                $images[] = $variant['Large']['URL'];
            }
        }

        return array_values(array_unique($images));
    }

    /**
     * Extract category data from BrowseNodes
     */
    private function extractCategoryData(array $browseNodes): array
    {
        $result = [
            'category' => '',
            'category_path' => '',
            'category_tree' => [],
            'category_ids' => null,
        ];

        if (empty($browseNodes)) {
            return $result;
        }

        $firstNode = $browseNodes[0];
        $ancestors = $firstNode['Ancestors'] ?? [];

        // Build tree from ancestors (top to bottom)
        $tree = [];
        $ids = [];

        foreach (array_reverse($ancestors) as $node) {
            $name = $node['DisplayName'] ?? $node['ContextFreeName'] ?? '';
            if ($name) {
                $tree[] = ['name' => $name, 'link' => null];
                if (isset($node['Id'])) {
                    $ids[] = $node['Id'];
                }
            }
        }

        // Add current node
        if (isset($firstNode['DisplayName'])) {
            $tree[] = ['name' => $firstNode['DisplayName'], 'link' => null];
            if (isset($firstNode['Id'])) {
                $ids[] = $firstNode['Id'];
            }
        }

        if (!empty($tree)) {
            $names = array_column($tree, 'name');
            $result['category'] = end($names);
            $result['category_path'] = implode(' > ', $names);
            $result['category_tree'] = $tree;
            $result['category_ids'] = !empty($ids) ? implode(',', $ids) : null;
        }

        return $result;
    }

    /**
     * Extract product information
     */
    private function extractProductInformation(array $itemInfo): array
    {
        $info = [];

        // ProductInfo
        if (isset($itemInfo['ProductInfo'])) {
            $productInfo = $itemInfo['ProductInfo'];

            if (isset($productInfo['Color']['DisplayValue'])) {
                $info['Color'] = $productInfo['Color']['DisplayValue'];
            }
            if (isset($productInfo['Size']['DisplayValue'])) {
                $info['Size'] = $productInfo['Size']['DisplayValue'];
            }
            if (isset($productInfo['ItemDimensions'])) {
                $dims = $productInfo['ItemDimensions'];
                if (isset($dims['Height']['DisplayValue'], $dims['Width']['DisplayValue'], $dims['Length']['DisplayValue'])) {
                    $info['Dimensions'] = sprintf(
                        '%s x %s x %s %s',
                        $dims['Length']['DisplayValue'],
                        $dims['Width']['DisplayValue'],
                        $dims['Height']['DisplayValue'],
                        $dims['Height']['Unit'] ?? ''
                    );
                }
                if (isset($dims['Weight']['DisplayValue'])) {
                    $info['Weight'] = $dims['Weight']['DisplayValue'] . ' ' . ($dims['Weight']['Unit'] ?? '');
                }
            }
        }

        // TechnicalInfo
        if (isset($itemInfo['TechnicalInfo']['Formats']['DisplayValues'])) {
            $info['Formats'] = implode(', ', $itemInfo['TechnicalInfo']['Formats']['DisplayValues']);
        }

        // Classifications
        if (isset($itemInfo['Classifications']['ProductGroup']['DisplayValue'])) {
            $info['Product Group'] = $itemInfo['Classifications']['ProductGroup']['DisplayValue'];
        }
        if (isset($itemInfo['Classifications']['Binding']['DisplayValue'])) {
            $info['Binding'] = $itemInfo['Classifications']['Binding']['DisplayValue'];
        }

        return $info;
    }

    /**
     * Extract specifications as array of {name, value}
     */
    private function extractSpecifications(array $itemInfo): array
    {
        $specs = [];
        $productInfo = $this->extractProductInformation($itemInfo);

        foreach ($productInfo as $name => $value) {
            $specs[] = ['name' => $name, 'value' => $value];
        }

        return $specs;
    }

    /**
     * Extract seller info from offers
     */
    private function extractSellerInfo(array $offers): ?array
    {
        if (empty($offers)) {
            return null;
        }

        return [
            'sellerID' => $offers['MerchantInfo']['Id'] ?? null,
            'name' => $offers['MerchantInfo']['Name'] ?? null,
            'link' => null,
            'shipsFrom' => null,
        ];
    }

    /**
     * Search products on Amazon via PA-API SearchItems
     *
     * @param string $query Search query
     * @param int $page Page number (1-10, PA-API max is 10 pages)
     * @return array|null Array of products or null on failure
     */
    public function search(string $query, int $page = 1): ?array
    {
        $this->lastError = null;

        // PA-API limits to 10 pages max
        $page = min(max(1, $page), 10);

        $regionConfig = self::REGIONS[$this->marketplace] ?? self::REGIONS['com'];
        $host = $regionConfig['host'];
        $region = $regionConfig['region'];

        $payload = $this->buildSearchRequest($query, $page);
        $payloadJson = wp_json_encode($payload);

        $headers = $this->signSearchRequest(
            $host,
            '/paapi5/searchitems',
            $payloadJson,
            $region
        );

        $response = wp_remote_post("https://{$host}/paapi5/searchitems", [
            'headers' => $headers,
            'body' => $payloadJson,
            'timeout' => self::TIMEOUT,
        ]);

        if (is_wp_error($response)) {
            $this->lastError = $response->get_error_message();
            return null;
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);

        if ($code !== 200) {
            $error = json_decode($body, true);
            $this->lastError = $error['Errors'][0]['Message'] ?? "HTTP {$code}";
            return null;
        }

        return $this->parseSearchResponse($body);
    }

    /**
     * Build PA-API SearchItems request payload
     *
     * @param string $query Search query
     * @param int $page Page number (1-based)
     * @return array Request payload
     */
    private function buildSearchRequest(string $query, int $page = 1): array
    {
        $payload = [
            'Keywords' => $query,
            'PartnerTag' => $this->partnerTag,
            'PartnerType' => 'Associates',
            'Marketplace' => "www.amazon.{$this->marketplace}",
            'ItemCount' => 10,
            'Resources' => [
                'Images.Primary.Medium',
                'ItemInfo.Title',
                'ItemInfo.ByLineInfo',
                'Offers.Listings.Price',
                'Offers.Listings.DeliveryInfo.IsPrimeEligible',
                'CustomerReviews.StarRating',
                'CustomerReviews.Count',
            ],
        ];

        // Add ItemPage for pagination (only for page > 1)
        if ($page > 1) {
            $payload['ItemPage'] = $page;
        }

        return $payload;
    }

    /**
     * Sign search request using AWS Signature Version 4
     */
    private function signSearchRequest(
        string $host,
        string $path,
        string $payload,
        string $region
    ): array {
        $service = 'ProductAdvertisingAPI';
        $method = 'POST';
        $timestamp = gmdate('Ymd\THis\Z');
        $date = gmdate('Ymd');

        $contentType = 'application/json; charset=utf-8';
        $target = 'com.amazon.paapi5.v1.ProductAdvertisingAPIv1.SearchItems';

        // Create canonical headers
        $canonicalHeaders = implode("\n", [
            "content-encoding:amz-1.0",
            "content-type:{$contentType}",
            "host:{$host}",
            "x-amz-date:{$timestamp}",
            "x-amz-target:{$target}",
        ]) . "\n";

        $signedHeaders = 'content-encoding;content-type;host;x-amz-date;x-amz-target';

        // Create canonical request
        $payloadHash = hash('sha256', $payload);
        $canonicalRequest = implode("\n", [
            $method,
            $path,
            '', // query string
            $canonicalHeaders,
            $signedHeaders,
            $payloadHash,
        ]);

        // Create string to sign
        $algorithm = 'AWS4-HMAC-SHA256';
        $credentialScope = "{$date}/{$region}/{$service}/aws4_request";
        $stringToSign = implode("\n", [
            $algorithm,
            $timestamp,
            $credentialScope,
            hash('sha256', $canonicalRequest),
        ]);

        // Calculate signature
        $signature = $this->getSignature($stringToSign, $date, $region, $service);

        // Create authorization header
        $authorization = "{$algorithm} Credential={$this->accessKey}/{$credentialScope}, SignedHeaders={$signedHeaders}, Signature={$signature}";

        return [
            'Content-Type' => $contentType,
            'Content-Encoding' => 'amz-1.0',
            'Host' => $host,
            'X-Amz-Date' => $timestamp,
            'X-Amz-Target' => $target,
            'Authorization' => $authorization,
        ];
    }

    /**
     * Parse PA-API SearchItems response
     */
    private function parseSearchResponse(string $response): ?array
    {
        $data = json_decode($response, true);

        if (!isset($data['SearchResult']['Items'])) {
            $this->lastError = 'No results found';
            return [];
        }

        $products = [];
        foreach ($data['SearchResult']['Items'] as $item) {
            $products[] = $this->normalizeSearchResult($item);
        }

        return $products;
    }

    /**
     * Normalize search result to simple format for display
     */
    private function normalizeSearchResult(array $item): array
    {
        $itemInfo = $item['ItemInfo'] ?? [];
        $offers = $item['Offers']['Listings'][0] ?? [];
        $customerReviews = $item['CustomerReviews'] ?? [];

        return [
            'asin' => $item['ASIN'] ?? '',
            'title' => $itemInfo['Title']['DisplayValue'] ?? '',
            'image' => $item['Images']['Primary']['Medium']['URL'] ?? '',
            'price' => isset($offers['Price']['Amount']) ? round((float) $offers['Price']['Amount'], 2) : null,
            'rating' => isset($customerReviews['StarRating']['Value']) ? (float) $customerReviews['StarRating']['Value'] : null,
            'reviews' => $customerReviews['Count'] ?? 0,
            'isPrime' => $offers['DeliveryInfo']['IsPrimeEligible'] ?? false,
            'brand' => $itemInfo['ByLineInfo']['Brand']['DisplayValue'] ?? '',
        ];
    }

    /**
     * Test API connection
     *
     * @return array Test result with 'success' and 'message'
     */
    public function test(): array
    {
        // Use a known ASIN for testing (Amazon Basics product)
        $testAsin = 'B07NPKN7Z6';

        $result = $this->fetch($testAsin);

        if ($result && !empty($result['title'])) {
            return [
                'success' => true,
                'message' => 'PA-API is working correctly',
                'data' => [
                    'title' => $result['title'],
                    'price' => $result['price'] ?? null,
                ],
            ];
        }

        return [
            'success' => false,
            'message' => $this->lastError ?? 'Unknown error',
        ];
    }

    /**
     * Get last error message
     */
    public function getLastError(): ?string
    {
        return $this->lastError;
    }

    /**
     * Get current marketplace
     */
    public function getMarketplace(): string
    {
        return $this->marketplace;
    }

    /**
     * Get partner tag
     */
    public function getPartnerTag(): string
    {
        return $this->partnerTag;
    }
}
