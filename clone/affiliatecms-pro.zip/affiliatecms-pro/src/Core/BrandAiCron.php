<?php
/**
 * Brand AI Content Generation Cron Job
 *
 * Uses parallel self-chaining workers (same pattern as ProductAiCron).
 * Each worker claims one brand atomically, processes it via OpenRouter,
 * then self-spawns the next worker — creating a continuous chain
 * until queue is empty.
 *
 * Default: 5 parallel workers → ~5 brands processed simultaneously
 * Each brand takes ~10s (API call) → throughput ~30 brands/min
 *
 * This is part of the AI generation system:
 * 1. ProductAiCron - Product content (parallel workers)
 * 2. PostAiCron - Review post generation
 * 3. CategoryAiCron - Category content (parallel workers)
 * 4. BrandAiCron - Brand content (parallel workers, this file)
 *
 * Output Fields:
 * - description - Brief brand summary
 * - content_intro - Intro paragraph
 * - content_main - Main content (comprehensive HTML)
 * - content_faq - FAQ section (JSON)
 * - seo_title - SEO optimized title
 * - seo_description - Meta description
 *
 * When AI generation completes, brand is automatically published.
 *
 * @package AffiliateCMS\Pro\Core
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro\Core;

use AffiliateCMS\Pro\Repositories\BrandRepository;
use AffiliateCMS\Pro\Database\Schema;

class BrandAiCron
{
    /**
     * Hook name for the cron job
     */
    public const CRON_HOOK = 'acms_brand_ai_generation';

    /**
     * Brands to process per batch (legacy, used by getStats)
     */
    private const BATCH_SIZE = 5;

    /**
     * Maximum execution time per single brand processing (seconds)
     */
    private const MAX_EXECUTION_TIME = 180;

    /**
     * Minimum product count required for AI generation
     */
    private const MIN_PRODUCT_COUNT = 1;

    /**
     * Default number of parallel brand AI workers
     */
    private const DEFAULT_BRAND_WORKERS = 5;

    /**
     * Maximum number of parallel brand AI workers
     */
    private const MAX_BRAND_WORKERS = 10;

    /**
     * Singleton instance
     */
    private static ?BrandAiCron $instance = null;

    private BrandRepository $brandRepo;

    /**
     * Get singleton instance
     */
    public static function instance(): BrandAiCron
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Private constructor for singleton
     */
    private function __construct()
    {
        $this->brandRepo = BrandRepository::instance();
    }

    /**
     * Register the cron job
     */
    public function register(): void
    {
        add_filter('cron_schedules', [$this, 'registerSchedule']);
        add_action(self::CRON_HOOK, [$this, 'generateContent']);

        // WP-Cron as safety net (server cron is primary)
        if (!wp_next_scheduled(self::CRON_HOOK)) {
            wp_schedule_event(time(), 'every_20_minutes', self::CRON_HOOK);
        }
    }

    /**
     * Register custom cron schedule
     *
     * @param array $schedules Existing schedules
     * @return array Modified schedules
     */
    public function registerSchedule(array $schedules): array
    {
        if (!isset($schedules['every_20_minutes'])) {
            $schedules['every_20_minutes'] = [
                'interval' => 20 * 60,
                'display' => __('Every 20 minutes', 'affiliatecms-pro'),
            ];
        }
        return $schedules;
    }

    // ─── Worker Management ───────────────────────────────────────────

    /**
     * Get configurable brand AI worker count
     *
     * Uses acms_automation settings. Default 5, max 10.
     */
    public function getBrandWorkerCount(): int
    {
        $settings = get_option('acms_automation', []);
        $count = (int) ($settings['brand_ai_worker_count'] ?? self::DEFAULT_BRAND_WORKERS);
        return max(1, min(self::MAX_BRAND_WORKERS, $count));
    }

    /**
     * Spawn parallel brand AI workers
     *
     * Each worker claims one brand atomically, processes it, then self-spawns
     * the next worker — creating a continuous processing chain until queue is empty.
     *
     * @param int|null $count Number of workers to spawn (null = use setting)
     */
    public function spawnBrandAiWorkers(?int $count = null): void
    {
        $count = $count ?? $this->getBrandWorkerCount();
        $available = $this->countBrandsNeedingAi();

        $workersToSpawn = min($count, $available);

        if ($workersToSpawn <= 0) {
            return;
        }

        for ($i = 0; $i < $workersToSpawn; $i++) {
            $this->spawnBrandAiWorker();

            // Small delay between spawns to avoid thundering herd
            if ($i < $workersToSpawn - 1) {
                usleep(100000); // 100ms
            }
        }
    }

    /**
     * Spawn a single brand AI worker via non-blocking HTTP request
     *
     * Mirrors ProductAiCron::spawnAiWorker() pattern — fires and forgets.
     * The worker endpoint handles claiming, processing, and self-spawning.
     */
    private function spawnBrandAiWorker(): void
    {
        $apiToken = get_option('acms_api_token', '');
        $endpoint = rest_url('acms/v1/cron/brand-ai-worker');

        wp_remote_post($endpoint, [
            'timeout'   => 0.01,
            'blocking'  => false,
            'sslverify' => false,
            'headers'   => [
                'X-ACMS-Token' => $apiToken,
            ],
        ]);
    }

    /**
     * Process the next queued brand (single worker execution)
     *
     * Called by the /cron/brand-ai-worker REST endpoint. Each invocation:
     * 1. Atomically claims one brand (claimNextBrand)
     * 2. Creates AI job + processes inline (OpenRouter API call, ~10s)
     * 3. If more queued → self-spawns next worker (chain continues)
     *
     * @return array Result with status info
     */
    public function processNextQueuedBrand(): array
    {
        @set_time_limit(300);
        @ini_set('max_execution_time', '300');

        // Step 1: Atomically claim one brand
        $brand = $this->claimNextBrand();

        if (!$brand) {
            return ['status' => 'idle', 'message' => 'No brands queued for AI'];
        }

        // Step 2: Generate content (create job + process inline)
        try {
            $success = $this->generateBrandContent($brand);

            // Step 3: Self-spawn next worker if more brands queued
            $this->spawnNextBrandIfNeeded();

            return [
                'status' => $success ? 'processed' : 'failed',
                'brand_id' => (int) $brand['id'],
                'brand_name' => $brand['name'],
            ];
        } catch (\Throwable $e) {
            error_log("[ACMS BrandAI Worker] Brand #{$brand['id']} exception: " . $e->getMessage());
            $this->brandRepo->update((int) $brand['id'], [
                'content_status' => 'empty',
                'ai_error_message' => substr($e->getMessage(), 0, 500),
            ]);

            $this->spawnNextBrandIfNeeded();

            return [
                'status' => 'failed',
                'brand_id' => (int) $brand['id'],
                'error' => $e->getMessage(),
            ];
        }
    }

    /**
     * Atomically claim the next brand for processing
     *
     * Fetches candidates (brands with products, content_status = 'empty'),
     * then attempts to claim via UPDATE WHERE content_status = 'empty'.
     * Only one worker can claim each brand — losers move to next candidate.
     *
     * @return array|null Brand data or null if none available
     */
    private function claimNextBrand(): ?array
    {
        global $wpdb;
        $table = Schema::brandsTable();
        $productsTable = Schema::productsTable();

        // Fetch more candidates than workers to handle race conditions
        $candidates = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT b.*, COUNT(p.id) AS real_product_count
                 FROM {$table} b
                 INNER JOIN {$productsTable} p ON p.brand = b.name AND p.status = 'scraped'
                 WHERE b.content_status = 'empty'
                 GROUP BY b.id
                 HAVING COUNT(p.id) >= %d
                 ORDER BY COUNT(p.id) DESC, b.id ASC
                 LIMIT %d",
                self::MIN_PRODUCT_COUNT,
                self::MAX_BRAND_WORKERS * 2
            ),
            ARRAY_A
        );

        foreach ($candidates as $brand) {
            // Atomic claim: only succeeds if still 'empty'
            $claimed = $wpdb->query($wpdb->prepare(
                "UPDATE {$table} SET content_status = 'ai_generating', ai_generating_at = %s, ai_error_message = NULL
                 WHERE id = %d AND content_status = 'empty'",
                current_time('mysql'),
                (int) $brand['id']
            ));

            if ($claimed > 0) {
                return $brand;
            }
        }

        return null;
    }

    /**
     * Spawn next brand AI worker if more brands are queued
     */
    private function spawnNextBrandIfNeeded(): void
    {
        $remaining = $this->countBrandsNeedingAi();

        if ($remaining > 0) {
            $this->spawnBrandAiWorker();
        }
    }

    /**
     * Count brands that need AI content generation
     */
    public function countBrandsNeedingAi(): int
    {
        global $wpdb;
        $table = Schema::brandsTable();
        $productsTable = Schema::productsTable();

        return (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM (
                    SELECT b.id
                    FROM {$table} b
                    INNER JOIN {$productsTable} p ON p.brand = b.name AND p.status = 'scraped'
                    WHERE b.content_status = 'empty'
                    GROUP BY b.id
                    HAVING COUNT(p.id) >= %d
                ) sub",
                self::MIN_PRODUCT_COUNT
            )
        );
    }

    // ─── Dispatcher (called by cron/WP-Cron) ────────────────────────

    /**
     * Generate AI content for brands — parallel worker dispatcher
     *
     * Lightweight dispatcher that:
     * 1. Resets stuck brands
     * 2. Syncs brands from products
     * 3. Spawns parallel workers to process the queue
     *
     * @param int $maxBrands Ignored (kept for backward compat)
     */
    public function generateContent(int $maxBrands = 0): void
    {
        if (!get_option('acms_ai_seo_brand_enabled', true)) {
            return;
        }

        // STEP 1: Reset stuck brands (>5 min in ai_generating)
        $this->resetStuckBrands();

        // STEP 2: Sync brands from products (throttled every 5 min)
        $this->syncBrandsFromProducts();

        // STEP 3: Spawn parallel workers
        $this->spawnBrandAiWorkers();
    }

    /**
     * Sync brands from products table (throttled every 5 minutes)
     */
    private function syncBrandsFromProducts(): void
    {
        $lastSync = get_transient('acms_brand_count_synced');
        if ($lastSync) {
            return;
        }

        set_transient('acms_brand_count_synced', time(), 300); // 5 min

        try {
            $this->brandRepo->importBrandsFromProducts();
            $this->brandRepo->updateAllProductCounts();
        } catch (\Throwable $e) {
            error_log('[ACMS BrandAI] Brand sync error: ' . $e->getMessage());
        }
    }

    /**
     * Reset brands stuck in ai_generating state for > 5 minutes
     */
    private function resetStuckBrands(): void
    {
        global $wpdb;
        $table = Schema::brandsTable();

        $stuck = $wpdb->query(
            "UPDATE {$table} SET content_status = 'empty', ai_error_message = 'Reset: stuck in ai_generating > 5 min'
             WHERE content_status = 'ai_generating'
             AND ai_generating_at < DATE_SUB(NOW(), INTERVAL 5 MINUTE)"
        );

        if ($stuck > 0) {
            error_log("[ACMS BrandAI] Reset {$stuck} stuck brand(s)");
        }

        // Also reset corresponding stuck jobs
        $jobsTable = $wpdb->prefix . 'acms_ai_jobs';
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $jobsTable)) === $jobsTable) {
            $stuckJobs = $wpdb->query(
                "UPDATE {$jobsTable}
                 SET status = 'failed', error_message = 'Auto-reset: processing > 5 min'
                 WHERE type = 'generate_seo_brand'
                 AND status = 'processing'
                 AND processing_at < DATE_SUB(NOW(), INTERVAL 5 MINUTE)"
            );
            if ($stuckJobs > 0) {
                error_log("[ACMS BrandAI] Reset {$stuckJobs} stuck brand job(s)");
            }
        }
    }

    // ─── Single Brand Processing ─────────────────────────────────────

    /**
     * Generate AI content for a single brand
     *
     * Called by processNextQueuedBrand() after brand is already claimed
     * (content_status = 'ai_generating'). Creates an AI job and processes inline.
     *
     * @param array $brand Brand data (already claimed)
     * @return bool True if job created and processed successfully
     */
    private function generateBrandContent(array $brand): bool
    {
        global $wpdb;

        $brandId = (int) $brand['id'];
        $brandName = $brand['name'];

        // --- STEP 1: Check prerequisites ---
        $jobsTable = $wpdb->prefix . 'acms_ai_jobs';
        $tableExists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $jobsTable));
        if ($tableExists !== $jobsTable) {
            return false;
        }

        $existingJob = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$jobsTable}
             WHERE type = 'generate_seo_brand'
             AND target_type = 'seo_brand'
             AND target_id = %s
             AND status IN ('pending', 'processing')",
            (string) $brandId
        ));

        if ($existingJob) {
            return false;
        }

        // --- STEP 2: Prepare data ---
        $products = $this->getBrandProducts($brandName);
        $brandCategoryLinks = $this->getBrandCategoryLinks($brandName);

        $inputData = [
            'brand_id' => $brandId,
            'brand_name' => $brandName,
            'brand_slug' => $brand['slug'] ?? '',
            'website_url' => $brand['website_url'] ?? '',
            'products' => $products,
            'current_description' => $brand['description'] ?? '',
            'total_product_count' => (int) ($brand['product_count'] ?? 0),
            'brand_category_links' => $brandCategoryLinks,
        ];

        $jsonInput = wp_json_encode($inputData);
        if ($jsonInput === false) {
            $jsonError = json_last_error_msg();
            $this->brandRepo->update($brandId, [
                'content_status' => 'empty',
                'ai_error_message' => "JSON encode failed: {$jsonError}",
            ]);
            return false;
        }

        // --- STEP 3: Create job in DB ---
        $inserted = $wpdb->insert($jobsTable, [
            'type' => 'generate_seo_brand',
            'status' => 'pending',
            'priority' => 35,
            'target_type' => 'seo_brand',
            'target_id' => (string) $brandId,
            'input_data' => $jsonInput,
            'created_at' => current_time('mysql'),
        ]);

        if (!$inserted) {
            error_log("[ACMS BrandAI] Brand #{$brandId}: DB insert error: " . $wpdb->last_error);
            $this->brandRepo->update($brandId, [
                'content_status' => 'empty',
                'ai_error_message' => 'DB insert failed: ' . substr($wpdb->last_error, 0, 200),
            ]);
            return false;
        }

        $jobId = (int) $wpdb->insert_id;

        // --- STEP 4: Process job INLINE ---
        $success = $this->processJobInline($jobId, $brandId, $inputData);

        return true;
    }

    /**
     * Process a brand AI job inline with full flow logging
     */
    private function processJobInline(int $jobId, int $brandId, array $inputData): bool
    {
        global $wpdb;
        $jobsTable = $wpdb->prefix . 'acms_ai_jobs';

        // Check API key
        $apiKey = get_option('acms_ai_api_key', '');
        if (empty($apiKey)) {
            return false;
        }

        $model = get_option('acms_ai_default_model', 'openai/gpt-4o-mini');

        // --- Generate prompt ---
        $prompt = $this->buildBrandPrompt($inputData);

        // Mark job as processing
        $wpdb->update($jobsTable, [
            'status' => 'processing',
            'processing_at' => current_time('mysql'),
            'attempts' => 1,
        ], ['id' => $jobId]);

        // --- Call OpenRouter API ---
        $siteName = get_bloginfo('name') ?: 'AffiliateCMS';
        $requestBody = [
            'model' => $model,
            'messages' => [
                ['role' => 'system', 'content' => 'You are an expert SEO content writer. Always respond with valid JSON only, no markdown code fences or extra text.'],
                ['role' => 'user', 'content' => $prompt],
            ],
            'temperature' => 0.7,
            'max_tokens' => 4096,
        ];

        $encodedBody = wp_json_encode($requestBody);
        $startTime = microtime(true);
        $response = wp_remote_post('https://openrouter.ai/api/v1/chat/completions', [
            'headers' => [
                'Authorization' => 'Bearer ' . $apiKey,
                'Content-Type' => 'application/json',
                'HTTP-Referer' => get_site_url() ?: 'https://affiliatecms.com',
                'X-Title' => $siteName,
            ],
            'body' => $encodedBody,
            'timeout' => 180,
        ]);
        $duration = round(microtime(true) - $startTime, 1);

        if (is_wp_error($response)) {
            $err = $response->get_error_message();
            $this->failJob($jobId, $brandId, "API error: {$err}");
            return false;
        }

        $httpCode = wp_remote_retrieve_response_code($response);
        $rawBody = wp_remote_retrieve_body($response);

        // --- Parse API response ---
        $body = json_decode($rawBody, true);
        if ($body === null) {
            $this->failJob($jobId, $brandId, "Response JSON decode failed");
            return false;
        }

        if (isset($body['error'])) {
            $apiError = $body['error']['message'] ?? wp_json_encode($body['error']);
            $this->failJob($jobId, $brandId, "API error: {$apiError}");
            return false;
        }

        $content = $body['choices'][0]['message']['content'] ?? '';
        $usage = $body['usage'] ?? [];
        $tokensIn = $usage['prompt_tokens'] ?? 0;
        $tokensOut = $usage['completion_tokens'] ?? 0;

        if (empty($content)) {
            $this->failJob($jobId, $brandId, "API returned empty content (HTTP {$httpCode})");
            return false;
        }

        // --- Parse JSON from content ---
        $jsonMatch = [];
        if (preg_match('/\{[\s\S]*\}/', $content, $jsonMatch)) {
            $data = json_decode($jsonMatch[0], true);
        } else {
            $data = null;
        }

        if ($data === null) {
            $this->failJob($jobId, $brandId, "JSON parse failed: " . json_last_error_msg());
            return false;
        }

        // --- STEP 5: Save to database ---

        $updateData = [
            'content_status' => 'ai_generated',
            'content_updated_at' => current_time('mysql'),
            'ai_generating_at' => null,
            'ai_error_message' => null,
            'status' => 'publish',
        ];

        $savedFields = [];

        if (!empty($data['description'])) {
            $updateData['description'] = sanitize_text_field($data['description']);
            $savedFields[] = 'description(' . strlen($data['description']) . 'ch)';
        }
        if (!empty($data['seo_title'])) {
            $updateData['seo_title'] = sanitize_text_field($data['seo_title']);
            $savedFields[] = 'seo_title';
        }
        if (!empty($data['seo_description'])) {
            $updateData['seo_description'] = sanitize_textarea_field($data['seo_description']);
            $savedFields[] = 'seo_description';
        }
        if (!empty($data['content_intro'])) {
            $updateData['content_intro'] = wp_kses_post($data['content_intro']);
            $savedFields[] = 'content_intro(' . strlen($data['content_intro']) . 'ch)';
        }
        if (!empty($data['content_main'])) {
            $updateData['content_main'] = wp_kses_post($data['content_main']);
            $savedFields[] = 'content_main(' . strlen($data['content_main']) . 'ch)';
        }
        if (!empty($data['content_faq'])) {
            if (is_array($data['content_faq'])) {
                $updateData['content_faq'] = wp_json_encode($data['content_faq']);
            } else {
                $updateData['content_faq'] = $data['content_faq'];
            }
            $savedFields[] = 'content_faq';
        }

        if (empty($savedFields)) {
            error_log("[ACMS BrandAI] Brand #{$brandId}: WARNING - No content fields from AI response");
        }

        $updated = $this->brandRepo->update($brandId, $updateData);

        if (!$updated) {
            error_log("[ACMS BrandAI] Brand #{$brandId}: update FAILED: " . ($wpdb->last_error ?: 'none'));
        }

        // Update job status
        $wpdb->update($jobsTable, [
            'status' => 'completed',
            'output_data' => wp_json_encode($data),
            'model' => $model,
            'tokens_used' => $tokensIn + $tokensOut,
            'cost' => 0,
            'completed_at' => current_time('mysql'),
        ], ['id' => $jobId]);

        return true;
    }

    /**
     * Build the brand SEO prompt (self-contained, no dependency on JobProcessor)
     */
    private function buildBrandPrompt(array $data): string
    {
        $brandName = $data['brand_name'] ?? '';
        $websiteUrl = $data['website_url'] ?? '';
        $products = $data['products'] ?? [];
        $totalProductCount = $data['total_product_count'] ?? count($products);

        // Products context
        $productsContext = '';
        if (!empty($products)) {
            $productsContext = "Sample products from this brand ({$totalProductCount} total):\n";
            foreach (array_slice($products, 0, 15) as $product) {
                $productsContext .= "- {$product['title']}";
                if (!empty($product['rating'])) {
                    $productsContext .= " (Rating: {$product['rating']}/5)";
                }
                $productsContext .= "\n";
            }
        }

        // Categories context
        $categories = [];
        foreach ($products as $product) {
            if (!empty($product['category_path'])) {
                $categories[] = $product['category_path'];
            }
        }
        $categories = array_unique($categories);
        $categoriesContext = !empty($categories)
            ? "Product categories: " . implode(', ', array_slice($categories, 0, 5))
            : '';

        // Format brand category links for internal linking
        $brandCategoryLinks = $data['brand_category_links'] ?? [];
        $brandCategoryLinksContext = $this->formatBrandCategoryLinksForPrompt($brandCategoryLinks);

        // Check for custom template from settings
        $template = get_option('acms_ai_seo_brand_prompt_template', '');

        if (empty($template)) {
            $websiteContext = !empty($websiteUrl) ? "Official Website: {$websiteUrl}" : '';

            $template = "You are an expert SEO content writer for an affiliate product review website. Create comprehensive, engaging content for a brand page.

Brand: {$brandName}
{$websiteContext}
{$categoriesContext}
{$productsContext}

{$brandCategoryLinksContext}

Generate the following content in JSON format:

1. **description**: Brief brand description (1-2 sentences, max 200 characters).
2. **seo_title**: SEO-optimized title (50-60 characters). Include the brand name.
3. **seo_description**: Meta description (150-160 characters).
4. **content_main**: Complete page content (600-1000 words) in HTML format. Structure as a single cohesive article:
   - Opening paragraph: introduce the brand, what they're known for, types of products they make
   - Main body: brand overview, what makes them stand out, product quality and reputation, who their products are best for, key product categories
   - FAQ section: 3-5 frequently asked questions about the brand with answers, using <h3> for questions and <p> for answers
   - Naturally include 3-5 internal links to related category pages from the list above
   - Use <a href=\"/c/slug/\">Category Name</a> format for internal links
   - Use <h2>, <h3>, <p>, <ul>, <li> tags appropriately. NEVER use <h1> — the page already has an H1 from the brand name
   - Start content with a <p> paragraph, not a heading
   - Make content scannable with clear structure and headings

Response format:
{
    \"description\": \"...\",
    \"seo_title\": \"...\",
    \"seo_description\": \"...\",
    \"content_main\": \"<complete html content with intro, body, FAQ, and internal links>\",
    \"internal_links_used\": [\"/c/slug1/\", \"/c/slug2/\"]
}

IMPORTANT:
- NEVER include <h1> tags in content_main — the page title is already the H1
- Write in a helpful, authoritative tone
- Focus on brand reputation and product quality
- Avoid making up specific facts about the brand
- If unsure about brand history, focus on products and value
- Don't mention specific prices or promotions
- Make content scannable with clear structure
- Include internal links naturally — don't force them where they don't fit
- Link to category pages where contextually relevant (e.g., mentioning product types the brand sells)
- Return ONLY valid JSON, no markdown code blocks";

            return $template;
        }

        // Use custom template with variable substitution
        $websiteContext = !empty($websiteUrl) ? "Official Website: {$websiteUrl}" : '';
        $template = str_replace('{{brand_name}}', $brandName, $template);
        $template = str_replace('{{brand_slug}}', $data['brand_slug'] ?? '', $template);
        $template = str_replace('{{website_context}}', $websiteContext, $template);
        $template = str_replace('{{categories_context}}', $categoriesContext, $template);
        $template = str_replace('{{products_context}}', $productsContext, $template);
        $template = str_replace('{{product_count}}', (string) $totalProductCount, $template);
        $template = str_replace('{{brand_category_links}}', $brandCategoryLinksContext, $template);

        return $template;
    }

    /**
     * Format brand category links for prompt context
     *
     * @param array<array{name: string, slug: string, brand_product_count: int}> $categoryLinks
     */
    private function formatBrandCategoryLinksForPrompt(array $categoryLinks): string
    {
        if (empty($categoryLinks)) {
            return '';
        }

        $output = "## Related Category Pages for Internal Linking\n";
        $output .= "Naturally embed 3-5 internal links in content_main to these category pages where contextually relevant.\n";
        $output .= "Link format: <a href=\"/c/{slug}/\">{Category Name}</a>\n\n";
        $output .= "Categories this brand's products appear in:\n";

        foreach ($categoryLinks as $cat) {
            $output .= "- [{$cat['name']}](/c/{$cat['slug']}/)";
            if (!empty($cat['brand_product_count'])) {
                $output .= " ({$cat['brand_product_count']} products)";
            }
            $output .= "\n";
        }

        return $output;
    }

    /**
     * Mark a job and brand as failed
     */
    private function failJob(int $jobId, int $brandId, string $error): void
    {
        global $wpdb;

        // Update job
        $wpdb->update($wpdb->prefix . 'acms_ai_jobs', [
            'status' => 'failed',
            'error_message' => substr($error, 0, 500),
        ], ['id' => $jobId]);

        // Reset brand
        $this->brandRepo->update($brandId, [
            'content_status' => 'empty',
            'ai_error_message' => substr($error, 0, 500),
        ]);

        error_log("[ACMS BrandAI] Brand #{$brandId} FAILED: {$error}");
    }

    /**
     * Get products for a brand for AI context
     */
    private function getBrandProducts(string $brandName): array
    {
        global $wpdb;

        $productsTable = Schema::productsTable();

        $products = $wpdb->get_results($wpdb->prepare(
            "SELECT asin, title, category_path, rating, reviews_count, price
             FROM {$productsTable}
             WHERE brand = %s AND status = 'scraped'
             ORDER BY rating DESC, reviews_count DESC
             LIMIT 15",
            $brandName
        ), ARRAY_A);

        return $products ?: [];
    }

    /**
     * Get categories containing this brand's products (for internal linking)
     *
     * @return array<array{name: string, slug: string, product_count: int}>
     */
    private function getBrandCategoryLinks(string $brandName): array
    {
        global $wpdb;

        $productsTable = Schema::productsTable();
        $catProductsTable = $wpdb->prefix . 'acms_category_products';
        $categoriesTable = $wpdb->prefix . 'acms_categories';

        $tableExists = $wpdb->get_var("SHOW TABLES LIKE '{$categoriesTable}'");
        if (!$tableExists) {
            return [];
        }

        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT c.name, c.slug, COUNT(DISTINCT p.id) as brand_product_count
             FROM {$categoriesTable} c
             INNER JOIN {$catProductsTable} cp ON c.id = cp.category_id
             INNER JOIN {$productsTable} p ON cp.product_id = p.id
             WHERE p.brand = %s AND c.status = 'publish'
             GROUP BY c.id, c.name, c.slug
             ORDER BY brand_product_count DESC
             LIMIT 15",
            $brandName
        ), ARRAY_A);

        return $results ?: [];
    }

    /**
     * Unschedule the cron job
     */
    public function unschedule(): void
    {
        $timestamp = wp_next_scheduled(self::CRON_HOOK);
        if ($timestamp) {
            wp_unschedule_event($timestamp, self::CRON_HOOK);
        }
    }

    /**
     * Run the generation manually (for testing or manual trigger)
     *
     * Spawns brand AI workers to process queued brands.
     *
     * @return array Result with count of processed brands
     */
    public function runManually(): array
    {
        $startTime = microtime(true);

        if (!get_option('acms_ai_seo_brand_enabled', true)) {
            return ['success' => true, 'message' => 'Brand AI is disabled', 'duration_ms' => 0];
        }

        // Reset stuck + sync (lightweight operations)
        $this->resetStuckBrands();
        $this->syncBrandsFromProducts();

        // Count queued and spawn workers
        $available = $this->countBrandsNeedingAi();

        if ($available > 0) {
            $this->spawnBrandAiWorkers();
        }

        $duration = round((microtime(true) - $startTime) * 1000);
        $workerCount = $available > 0 ? min($this->getBrandWorkerCount(), $available) : 0;

        return [
            'success' => true,
            'message' => $available > 0
                ? "Spawned {$workerCount} brand AI workers for {$available} queued brands"
                : 'No brands queued for AI',
            'duration_ms' => $duration,
            'queued' => $available,
            'workers' => $workerCount,
        ];
    }

    /**
     * Get next scheduled run time
     *
     * @return int|false Unix timestamp or false if not scheduled
     */
    public function getNextRun()
    {
        return wp_next_scheduled(self::CRON_HOOK);
    }

    /**
     * Get statistics about brands needing AI content
     *
     * @return array Statistics
     */
    public function getStats(): array
    {
        global $wpdb;
        $table = Schema::brandsTable();

        $empty = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$table}
             WHERE content_status = 'empty' AND product_count >= %d",
            self::MIN_PRODUCT_COUNT
        ));

        $generating = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$table} WHERE content_status = 'ai_generating'"
        );

        $generated = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$table} WHERE content_status = 'ai_generated'"
        );

        $manual = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$table} WHERE content_status = 'manual'"
        );

        $failed = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$table}
             WHERE content_status = 'empty' AND ai_error_message IS NOT NULL"
        );

        return [
            'empty' => (int) $empty,
            'generating' => (int) $generating,
            'generated' => (int) $generated,
            'manual' => (int) $manual,
            'failed' => (int) $failed,
            'next_run' => $this->getNextRun(),
            'batch_size' => self::BATCH_SIZE,
            'min_products' => self::MIN_PRODUCT_COUNT,
            'brand_worker_count' => $this->getBrandWorkerCount(),
        ];
    }
}
