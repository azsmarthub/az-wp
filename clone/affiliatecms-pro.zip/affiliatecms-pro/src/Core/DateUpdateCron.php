<?php
/**
 * Date Update Cron Job
 *
 * Monthly cron job that updates date-based placeholders in published posts.
 * This keeps content like "Best Products in January 2026" always current.
 *
 * @package AffiliateCMS\Pro\Core
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro\Core;

use AffiliateCMS\Pro\Database\Schema;

class DateUpdateCron
{
    /**
     * Hook name for the cron job
     */
    public const CRON_HOOK = 'acms_update_date_placeholders';

    /**
     * Meta key to track posts that need date updates
     */
    public const META_KEY_HAS_DATE_PLACEHOLDERS = '_acms_has_date_placeholders';

    /**
     * Meta key for template ID reference
     */
    public const META_KEY_TEMPLATE_ID = '_acms_template_id';

    /**
     * Singleton instance
     */
    private static ?DateUpdateCron $instance = null;

    /**
     * Get singleton instance
     */
    public static function instance(): DateUpdateCron
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Private constructor for singleton
     */
    private function __construct()
    {
    }

    /**
     * Register the cron job
     */
    public function register(): void
    {
        add_filter('cron_schedules', [$this, 'addMonthlySchedule']);
        add_action(self::CRON_HOOK, [$this, 'updateDatePlaceholders']);

        // WP-Cron as safety net (server cron is primary via /cron/date-update)
        if (!wp_next_scheduled(self::CRON_HOOK)) {
            $nextMonth = strtotime('first day of next month midnight');
            wp_schedule_event($nextMonth, 'monthly', self::CRON_HOOK);
        }
    }

    /**
     * Add monthly schedule to WordPress cron schedules
     *
     * @param array $schedules Existing schedules
     * @return array Modified schedules
     */
    public function addMonthlySchedule(array $schedules): array
    {
        if (!isset($schedules['monthly'])) {
            $schedules['monthly'] = [
                'interval' => 30 * DAY_IN_SECONDS, // ~30 days
                'display' => __('Once Monthly', 'affiliatecms-pro'),
            ];
        }
        return $schedules;
    }

    /**
     * Update date placeholders in all applicable posts
     *
     * This runs monthly and updates:
     * - Post title (if contains date placeholders)
     * - Post content (if contains date placeholders)
     * - SEO meta fields (if contains date placeholders)
     *
     * Uses context-based replacement to accurately update only the date values
     * that were originally generated from placeholders.
     */
    public function updateDatePlaceholders(): void
    {
        global $wpdb;

        // Find posts that need date updates (have context map and generated_date != current month)
        // Use WordPress timezone for current month
        $currentMonth = wp_date('Y-m');
        $postsToUpdate = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT p.ID
                 FROM {$wpdb->posts} p
                 INNER JOIN {$wpdb->postmeta} pm1 ON p.ID = pm1.post_id AND pm1.meta_key = %s
                 INNER JOIN {$wpdb->postmeta} pm2 ON p.ID = pm2.post_id AND pm2.meta_key = %s
                 WHERE pm2.meta_value != %s
                 AND p.post_status IN ('publish', 'draft')
                 LIMIT 500",
                DateUpdateContext::META_KEY,
                DateUpdateContext::META_KEY_GENERATED_DATE,
                $currentMonth
            ),
            ARRAY_A
        );

        if (empty($postsToUpdate)) {
            return;
        }

        $updatedCount = 0;
        $newDateValues = $this->getCurrentDateValues();

        foreach ($postsToUpdate as $row) {
            $postId = (int) $row['ID'];

            try {
                $updated = $this->updatePostWithContext($postId, $newDateValues);
                if ($updated) {
                    $updatedCount++;
                    error_log("[ACMS DateUpdateCron] Updated post ID: {$postId}");
                }
            } catch (\Exception $e) {
                error_log("[ACMS DateUpdateCron] Error updating post {$postId}: " . $e->getMessage());
            }
        }

        error_log("[ACMS DateUpdateCron] Completed. Updated {$updatedCount} posts.");
    }

    /**
     * Update a single post using context-based replacement
     *
     * @param int $postId Post ID
     * @param array $newDateValues New date placeholder values
     * @return bool True if post was updated
     */
    private function updatePostWithContext(int $postId, array $newDateValues): bool
    {
        $post = get_post($postId);
        if (!$post) {
            return false;
        }

        // Load context map
        $contextMap = DateUpdateContext::loadFromPost($postId);
        if (empty($contextMap)) {
            return false;
        }

        $needsUpdate = false;
        $updateData = [];

        // Update title
        if (!empty($contextMap['title'])) {
            $result = DateUpdateContext::replaceWithContext(
                $post->post_title,
                $contextMap['title'],
                $newDateValues
            );
            if ($result['text'] !== $post->post_title) {
                $updateData['post_title'] = $result['text'];
                $contextMap['title'] = $result['context_map'];
                $needsUpdate = true;
            }
        }

        // Update content
        if (!empty($contextMap['content'])) {
            $result = DateUpdateContext::replaceWithContext(
                $post->post_content,
                $contextMap['content'],
                $newDateValues
            );
            if ($result['text'] !== $post->post_content) {
                $updateData['post_content'] = $result['text'];
                $contextMap['content'] = $result['context_map'];
                $needsUpdate = true;
            }
        }

        // Update excerpt
        if (!empty($contextMap['excerpt'])) {
            $result = DateUpdateContext::replaceWithContext(
                $post->post_excerpt,
                $contextMap['excerpt'],
                $newDateValues
            );
            if ($result['text'] !== $post->post_excerpt) {
                $updateData['post_excerpt'] = $result['text'];
                $contextMap['excerpt'] = $result['context_map'];
                $needsUpdate = true;
            }
        }

        // Update the post if needed
        if ($needsUpdate) {
            $updateData['ID'] = $postId;
            wp_update_post($updateData);

            // Update SEO meta fields
            $this->updateSeoMetaWithContext($postId, $contextMap, $newDateValues);

            // Save updated context map and generation date (use WordPress timezone)
            $currentMonth = wp_date('Y-m');
            DateUpdateContext::saveToPost($postId, $contextMap, $currentMonth);

            return true;
        }

        return false;
    }

    /**
     * Get current date placeholder values
     *
     * @return array Map of placeholder => value
     */
    private function getCurrentDateValues(): array
    {
        $timestamp = current_time('timestamp');

        return [
            '%year%' => date('Y', $timestamp),
            '%month_text%' => date_i18n('F', $timestamp),
            '%month_number%' => date('m', $timestamp),
            '%month_short%' => date_i18n('M', $timestamp),
            '%day%' => date('d', $timestamp),
            '%date_full%' => date_i18n(get_option('date_format'), $timestamp),
        ];
    }

    /**
     * Update SEO meta fields using context-based replacement
     *
     * @param int $postId Post ID
     * @param array $contextMap Context map (passed by reference, will be updated)
     * @param array $newDateValues New date placeholder values
     */
    private function updateSeoMetaWithContext(int $postId, array &$contextMap, array $newDateValues): void
    {
        // Update meta title
        $metaTitle = get_post_meta($postId, '_acms_meta_title', true);
        if (!empty($metaTitle) && !empty($contextMap['meta_title'])) {
            $result = DateUpdateContext::replaceWithContext(
                $metaTitle,
                $contextMap['meta_title'],
                $newDateValues
            );

            if ($result['text'] !== $metaTitle) {
                $newMetaTitle = $result['text'];
                $contextMap['meta_title'] = $result['context_map'];

                update_post_meta($postId, '_acms_meta_title', $newMetaTitle);

                // Yoast SEO
                if (defined('WPSEO_VERSION')) {
                    update_post_meta($postId, '_yoast_wpseo_title', $newMetaTitle);
                }

                // Rank Math
                if (defined('RANK_MATH_VERSION')) {
                    update_post_meta($postId, 'rank_math_title', $newMetaTitle);
                }
            }
        }

        // Update meta description
        $metaDescription = get_post_meta($postId, '_acms_meta_description', true);
        if (!empty($metaDescription) && !empty($contextMap['meta_description'])) {
            $result = DateUpdateContext::replaceWithContext(
                $metaDescription,
                $contextMap['meta_description'],
                $newDateValues
            );

            if ($result['text'] !== $metaDescription) {
                $newMetaDescription = $result['text'];
                $contextMap['meta_description'] = $result['context_map'];

                update_post_meta($postId, '_acms_meta_description', $newMetaDescription);

                // Yoast SEO
                if (defined('WPSEO_VERSION')) {
                    update_post_meta($postId, '_yoast_wpseo_metadesc', $newMetaDescription);
                }

                // Rank Math
                if (defined('RANK_MATH_VERSION')) {
                    update_post_meta($postId, 'rank_math_description', $newMetaDescription);
                }
            }
        }
    }

    /**
     * Update SEO meta fields with new date values (legacy method)
     *
     * @deprecated Use updateSeoMetaWithContext() instead
     * @param int $postId Post ID
     */
    private function updateSeoMeta(int $postId): void
    {
        // Our custom meta fields
        $metaTitle = get_post_meta($postId, '_acms_meta_title', true);
        $metaDescription = get_post_meta($postId, '_acms_meta_description', true);

        if (!empty($metaTitle) && TemplatePlaceholders::hasDatePlaceholders($metaTitle)) {
            $newMetaTitle = TemplatePlaceholders::updateDatePlaceholders($metaTitle);
            update_post_meta($postId, '_acms_meta_title', $newMetaTitle);

            // Yoast SEO
            if (defined('WPSEO_VERSION')) {
                update_post_meta($postId, '_yoast_wpseo_title', $newMetaTitle);
            }

            // Rank Math
            if (defined('RANK_MATH_VERSION')) {
                update_post_meta($postId, 'rank_math_title', $newMetaTitle);
            }
        }

        if (!empty($metaDescription) && TemplatePlaceholders::hasDatePlaceholders($metaDescription)) {
            $newMetaDescription = TemplatePlaceholders::updateDatePlaceholders($metaDescription);
            update_post_meta($postId, '_acms_meta_description', $newMetaDescription);

            // Yoast SEO
            if (defined('WPSEO_VERSION')) {
                update_post_meta($postId, '_yoast_wpseo_metadesc', $newMetaDescription);
            }

            // Rank Math
            if (defined('RANK_MATH_VERSION')) {
                update_post_meta($postId, 'rank_math_description', $newMetaDescription);
            }
        }
    }

    /**
     * Unschedule the cron job
     */
    public function unschedule(): void
    {
        $timestamp = wp_next_scheduled(self::CRON_HOOK);
        if ($timestamp) {
            wp_unschedule_event($timestamp, self::CRON_HOOK);
        }
    }

    /**
     * Run the update manually (for testing or manual trigger)
     *
     * @return array Result with count of updated posts
     */
    public function runManually(): array
    {
        $startTime = microtime(true);

        ob_start();
        $this->updateDatePlaceholders();
        $output = ob_get_clean();

        $duration = round((microtime(true) - $startTime) * 1000);

        return [
            'success' => true,
            'message' => 'Date placeholders updated',
            'duration_ms' => $duration,
            'log' => $output,
        ];
    }

    /**
     * Get next scheduled run time
     *
     * @return int|false Unix timestamp or false if not scheduled
     */
    public function getNextRun()
    {
        return wp_next_scheduled(self::CRON_HOOK);
    }

    /**
     * Check if a post has date placeholders that need updating
     *
     * @param int $postId Post ID
     * @return bool
     */
    public static function postHasDatePlaceholders(int $postId): bool
    {
        $post = get_post($postId);
        if (!$post) {
            return false;
        }

        return TemplatePlaceholders::hasDatePlaceholders($post->post_title)
            || TemplatePlaceholders::hasDatePlaceholders($post->post_content)
            || TemplatePlaceholders::hasDatePlaceholders($post->post_excerpt);
    }
}
