<?php
/**
 * Template Placeholders Handler
 *
 * Handles replacement of template placeholders with actual content.
 * All placeholders are "baked" at generation time (not dynamic).
 *
 * Available placeholders:
 *
 * KEYWORD:
 * - %keyword%           : The queue item keyword (lowercase)
 * - %Keyword%           : Title case keyword
 * - %KEYWORD%           : Title case keyword (for readability)
 * - %keyword_title%     : Title case keyword
 * - %keyword_upper%     : Uppercase keyword
 *
 * DATE:
 * - %year%              : Current year (e.g., 2026)
 * - %month_text%        : Current month name (e.g., January)
 * - %month_number%      : Current month number (e.g., 01)
 * - %month_short%       : Short month name (e.g., Jan)
 * - %day%               : Day of month (e.g., 25)
 * - %date_full%         : Full date per WP settings
 *
 * PRODUCT STATS:
 * - %product_count%     : Number of linked products
 * - %review_count%      : Total reviews across all products
 * - %review_count_formatted% : Formatted (e.g., 5.2K)
 * - %brand_list%        : Comma-separated list of unique brands
 * - %price_min%         : Lowest product price (formatted)
 * - %price_max%         : Highest product price (formatted)
 * - %price_range%       : Price range (e.g., "$29.99 - $149.99")
 * - %product_min%       : Alias for %price_min%
 * - %product_max%       : Alias for %price_max%
 *
 * AUTHOR:
 * - %author%            : Author display name or site name
 * - %author_name%       : Same as %author%
 * - %site_name%         : Site/blog name
 *
 * @package AffiliateCMS\Pro\Core
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro\Core;

class TemplatePlaceholders
{
    /**
     * Queue item data
     */
    private array $queueItem = [];

    /**
     * Content settings from queue item
     */
    private array $contentSettings = [];

    /**
     * Product stats (cached from ASIN search)
     */
    private array $productStats = [];

    /**
     * Currency symbol for price formatting
     */
    private string $currencySymbol = '$';

    /**
     * Constructor
     *
     * @param array $queueItem Queue item data from database
     */
    public function __construct(array $queueItem)
    {
        $this->queueItem = $queueItem;

        // Parse content_settings JSON
        if (!empty($queueItem['content_settings'])) {
            $this->contentSettings = is_string($queueItem['content_settings'])
                ? json_decode($queueItem['content_settings'], true) ?? []
                : $queueItem['content_settings'];
        }

        // Get cached product stats
        $this->productStats = $this->contentSettings['product_stats'] ?? [];
    }

    /**
     * Replace all placeholders in content
     *
     * @param string $content Content with placeholders
     * @return string Content with placeholders replaced
     */
    public function replaceAll(string $content): string
    {
        $placeholders = $this->getAllPlaceholders();

        return str_replace(
            array_keys($placeholders),
            array_values($placeholders),
            $content
        );
    }

    /**
     * Replace all placeholders and capture context for date values
     *
     * Returns both the replaced content and context information for date updates.
     * Use this instead of replaceAll() when generating content that needs date updates.
     *
     * @param string $content Content with placeholders
     * @return array ['text' => replaced content, 'contexts' => array of date contexts]
     */
    public function replaceAllWithContext(string $content): array
    {
        $originalContent = $content;
        $allPlaceholders = $this->getAllPlaceholders();
        $datePlaceholders = $this->getDatePlaceholders();

        // Replace all placeholders
        $replacedContent = str_replace(
            array_keys($allPlaceholders),
            array_values($allPlaceholders),
            $content
        );

        // Capture contexts for date placeholders
        $contexts = DateUpdateContext::captureContexts(
            $originalContent,
            $replacedContent,
            $datePlaceholders
        );

        return [
            'text' => $replacedContent,
            'contexts' => $contexts,
        ];
    }

    /**
     * Get all placeholder values
     *
     * @return array Associative array of placeholder => value
     */
    public function getAllPlaceholders(): array
    {
        return array_merge(
            $this->getKeywordPlaceholders(),
            $this->getDatePlaceholders(),
            $this->getProductStatPlaceholders(),
            $this->getAuthorPlaceholders()
        );
    }

    /**
     * Get author-related placeholders
     *
     * @return array
     */
    private function getAuthorPlaceholders(): array
    {
        // Get author ID from content settings
        $authorId = $this->contentSettings['author_id'] ?? null;

        // Handle 'random' author selection
        if ($authorId === 'random' || empty($authorId)) {
            // Get site name as fallback
            $authorName = get_bloginfo('name');
        } else {
            // Get actual author name
            $user = get_userdata((int) $authorId);
            $authorName = $user ? $user->display_name : get_bloginfo('name');
        }

        return [
            '%author%' => $authorName,
            '%author_name%' => $authorName,
            '%site_name%' => get_bloginfo('name'),
        ];
    }

    /**
     * Get keyword-related placeholders
     *
     * Supports multiple case variants:
     * - %keyword%, %Keyword%, %KEYWORD%
     *
     * @return array
     */
    private function getKeywordPlaceholders(): array
    {
        $keyword = $this->queueItem['keyword'] ?? '';
        $keywordTitle = ucwords($keyword);
        $keywordUpper = strtoupper($keyword);

        return [
            // Standard
            '%keyword%' => $keyword,
            '%keyword_title%' => $keywordTitle,
            '%keyword_upper%' => $keywordUpper,
            // Case variants (for template compatibility)
            '%Keyword%' => $keywordTitle,
            '%KEYWORD%' => $keywordTitle, // Use title case for readability
        ];
    }

    /**
     * Get date-related placeholders
     *
     * @return array
     */
    private function getDatePlaceholders(): array
    {
        $timestamp = current_time('timestamp');

        return [
            '%year%' => date('Y', $timestamp),
            '%month_text%' => date_i18n('F', $timestamp),
            '%month_number%' => date('m', $timestamp),
            '%month_short%' => date_i18n('M', $timestamp),
            '%day%' => date('d', $timestamp),
            '%date_full%' => date_i18n(get_option('date_format'), $timestamp),
        ];
    }

    /**
     * Get product statistics placeholders
     *
     * @return array
     */
    private function getProductStatPlaceholders(): array
    {
        $productCount = $this->productStats['product_count'] ?? 0;
        $reviewTotal = $this->productStats['review_total'] ?? 0;
        $priceMin = $this->productStats['price_min'] ?? null;
        $priceMax = $this->productStats['price_max'] ?? null;
        $brands = $this->productStats['brands'] ?? [];

        // Format brand list
        $brandList = '';
        if (!empty($brands)) {
            if (count($brands) > 3) {
                // Show first 3 brands + "and more"
                $brandList = implode(', ', array_slice($brands, 0, 3)) . ' ' . __('and more', 'affiliatecms-pro');
            } else {
                $brandList = implode(', ', $brands);
            }
        }

        // Format prices
        $priceMinFormatted = $priceMin !== null ? $this->formatPrice($priceMin) : '';
        $priceMaxFormatted = $priceMax !== null ? $this->formatPrice($priceMax) : '';

        // Format price range
        $priceRange = '';
        if ($priceMin !== null && $priceMax !== null) {
            if ($priceMin === $priceMax) {
                $priceRange = $priceMinFormatted;
            } else {
                $priceRange = $priceMinFormatted . ' - ' . $priceMaxFormatted;
            }
        } elseif ($priceMin !== null) {
            $priceRange = sprintf(__('From %s', 'affiliatecms-pro'), $priceMinFormatted);
        } elseif ($priceMax !== null) {
            $priceRange = sprintf(__('Up to %s', 'affiliatecms-pro'), $priceMaxFormatted);
        }

        // Format review count
        $reviewFormatted = $this->formatNumber($reviewTotal);

        return [
            '%product_count%' => (string) $productCount,
            '%review_count%' => (string) $reviewTotal,
            '%review_count_formatted%' => $reviewFormatted,
            '%brand_list%' => $brandList,
            '%price_min%' => $priceMinFormatted,
            '%price_max%' => $priceMaxFormatted,
            '%price_range%' => $priceRange,
            // Aliases for backward compatibility
            '%product_min%' => $priceMinFormatted,
            '%product_max%' => $priceMaxFormatted,
        ];
    }

    /**
     * Format price with currency symbol
     *
     * @param float $price
     * @return string
     */
    private function formatPrice(float $price): string
    {
        return $this->currencySymbol . number_format($price, 2);
    }

    /**
     * Format large numbers (e.g., 5200 -> 5.2K)
     *
     * @param int $number
     * @return string
     */
    private function formatNumber(int $number): string
    {
        if ($number >= 1000000) {
            return number_format($number / 1000000, 1) . 'M';
        }
        if ($number >= 1000) {
            return number_format($number / 1000, 1) . 'K';
        }
        return (string) $number;
    }

    /**
     * Set currency symbol for price formatting
     *
     * @param string $symbol
     * @return self
     */
    public function setCurrencySymbol(string $symbol): self
    {
        $this->currencySymbol = $symbol;
        return $this;
    }

    /**
     * Get product stats
     *
     * @return array
     */
    public function getProductStats(): array
    {
        return $this->productStats;
    }

    /**
     * Update product stats (recalculate from scraped products)
     *
     * This method recalculates stats from actual scraped product data.
     * Use this when products have been scraped and have more accurate data.
     *
     * @param array $products Array of product data from database
     * @return self
     */
    public function updateStatsFromProducts(array $products): self
    {
        if (empty($products)) {
            return $this;
        }

        $priceMin = null;
        $priceMax = null;
        $reviewTotal = 0;
        $brands = [];

        foreach ($products as $product) {
            // Price
            $price = isset($product['price']) ? floatval($product['price']) : null;
            if ($price !== null && $price > 0) {
                if ($priceMin === null || $price < $priceMin) {
                    $priceMin = $price;
                }
                if ($priceMax === null || $price > $priceMax) {
                    $priceMax = $price;
                }
            }

            // Reviews
            $reviewTotal += isset($product['reviews_count']) ? intval($product['reviews_count']) : 0;

            // Brands
            $brand = $product['brand'] ?? '';
            if (!empty($brand) && !in_array($brand, $brands)) {
                $brands[] = $brand;
            }
        }

        $this->productStats = [
            'product_count' => count($products),
            'price_min' => $priceMin,
            'price_max' => $priceMax,
            'review_total' => $reviewTotal,
            'brands' => $brands,
        ];

        return $this;
    }

    /**
     * Static helper to update date placeholders in existing content
     *
     * Used by the monthly cron job to update date-based content.
     *
     * @param string $content Content with date placeholders
     * @param int|null $timestamp Optional timestamp (defaults to current time)
     * @return string Updated content
     */
    public static function updateDatePlaceholders(string $content, ?int $timestamp = null): string
    {
        $timestamp = $timestamp ?? current_time('timestamp');

        $replacements = [
            '%year%' => date('Y', $timestamp),
            '%month_text%' => date_i18n('F', $timestamp),
            '%month_number%' => date('m', $timestamp),
            '%month_short%' => date_i18n('M', $timestamp),
            '%day%' => date('d', $timestamp),
            '%date_full%' => date_i18n(get_option('date_format'), $timestamp),
        ];

        return str_replace(
            array_keys($replacements),
            array_values($replacements),
            $content
        );
    }

    /**
     * Check if content contains any date placeholders
     *
     * @param string $content
     * @return bool
     */
    public static function hasDatePlaceholders(string $content): bool
    {
        $datePlaceholders = ['%year%', '%month_text%', '%month_number%', '%month_short%', '%day%', '%date_full%'];

        foreach ($datePlaceholders as $placeholder) {
            if (strpos($content, $placeholder) !== false) {
                return true;
            }
        }

        return false;
    }
}
