<?php
/**
 * Crawlbase Provider
 *
 * Scrapes Amazon products using Crawlbase API
 * https://crawlbase.com/
 *
 * SIMPLIFIED: No key rotation, no status tracking, no health monitoring
 *
 * Crawlbase Response structure:
 * [
 *   {
 *     "pc_status": 200,
 *     "body": {
 *       "name": "Product title",
 *       "rawPrice": 449.99,
 *       "originalPrice": "$799.00",
 *       "currency": "USD",
 *       "inStock": true,
 *       "brand": "BrandName",
 *       "images": [...],
 *       "highResolutionImages": [...],
 *       "customerReview": "4.6 out of 5 stars",
 *       "customerReviewCount": 2452,
 *       "breadCrumbs": [{"name": "Electronics", "link": "...?node=123"}],
 *       "productDetails": [{name, value}],
 *       "productInformation": [{name, value}],
 *       "soldBy": {sellerID, name, link},
 *       "reviews": [...],
 *       "productReviewTop": {"5 star": "45%", ...}
 *     }
 *   }
 * ]
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro\Core;

class CrawlbaseProvider
{
    private const API_URL = 'https://api.crawlbase.com/';
    private const TIMEOUT = 120;

    /** US market only — reject any non-USD response */
    private const REQUIRED_CURRENCY = 'USD';
    private const REQUIRED_DOMAIN = 'amazon.com';

    private string $token;
    private ?string $lastError = null;
    private array $fieldLog = [];

    /**
     * Constructor
     *
     * @param string $token Crawlbase API token
     */
    public function __construct(string $token)
    {
        $this->token = $token;
    }

    /**
     * Fetch product data from Amazon via Crawlbase
     *
     * @param string $asin Amazon product ASIN
     * @param string $domain Amazon domain (e.g., amazon.com, amazon.co.uk)
     * @return array|null Normalized product data or null on failure
     */
    public function fetch(string $asin, string $domain = 'amazon.com'): ?array
    {
        $this->lastError = null;
        $this->fieldLog = [];
        $domain = self::REQUIRED_DOMAIN; // Force US market

        $url = $this->buildUrl($asin, $domain);

        $response = wp_remote_get($url, [
            'timeout' => self::TIMEOUT,
            'headers' => [
                'Accept' => 'application/json',
            ],
        ]);

        if (is_wp_error($response)) {
            $this->lastError = 'WP HTTP Error: ' . $response->get_error_message();
            return null;
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);

        if ($code !== 200) {
            $this->lastError = $this->buildHttpError($code, $body);
            return null;
        }

        return $this->parseResponse($body);
    }

    /**
     * Quick fetch - fetch only dynamic data (price, rating, stock)
     *
     * Much faster than full fetch. Returns only frequently-changing fields.
     * Used for scheduled updates of existing products.
     *
     * @param string $asin Amazon product ASIN
     * @param string $domain Amazon domain (e.g., amazon.com)
     * @return array|null Dynamic data (price, rating, reviews_count, in_stock, is_prime) or null on failure
     */
    public function quickFetch(string $asin, string $domain = 'amazon.com'): ?array
    {
        $this->lastError = null;
        $domain = self::REQUIRED_DOMAIN; // Force US market

        $url = $this->buildUrl($asin, $domain);

        $response = wp_remote_get($url, [
            'timeout' => self::TIMEOUT,
            'headers' => [
                'Accept' => 'application/json',
            ],
        ]);

        if (is_wp_error($response)) {
            $this->lastError = 'WP HTTP Error: ' . $response->get_error_message();
            return null;
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);

        if ($code !== 200) {
            $this->lastError = $this->buildHttpError($code, $body);
            return null;
        }

        return $this->parseQuickResponse($body);
    }

    /**
     * Parse Crawlbase API response for quick scrape (dynamic data only)
     *
     * @param string $response Raw JSON response
     * @return array|null Dynamic data or null on failure
     */
    private function parseQuickResponse(string $response): ?array
    {
        $data = json_decode($response, true);

        if (!$data) {
            $this->lastError = 'Invalid JSON response';
            return null;
        }

        // Crawlbase returns array, get first element
        if (isset($data[0])) {
            $data = $data[0];
        }

        // Check pc_status
        if (isset($data['pc_status']) && $data['pc_status'] !== 200) {
            $this->lastError = "Crawlbase status: {$data['pc_status']}";
            return null;
        }

        if (!isset($data['body'])) {
            $this->lastError = 'No body in response';
            return null;
        }

        $body = $data['body'];

        if (!is_array($body)) {
            $this->lastError = 'Response body is not an object (got ' . gettype($body) . ')';
            return null;
        }

        // Validate currency matches expected market
        $responseCurrency = $this->extractCurrency($body);
        if ($responseCurrency !== self::REQUIRED_CURRENCY) {
            $this->lastError = "Wrong market: got {$responseCurrency}, expected " . self::REQUIRED_CURRENCY;
            return null;
        }

        // Extract only dynamic fields
        return [
            'price' => $this->extractPrice($body),
            'original_price' => $this->extractOriginalPrice($body),
            'rating' => $this->extractRating($body),
            'reviews_count' => $this->extractReviewCount($body),
            'in_stock' => $this->extractAvailability($body),
            'is_prime' => $this->extractPrime($body),
        ];
    }

    /**
     * Build Crawlbase API URL
     *
     * @param string $asin Amazon product ASIN
     * @param string $domain Amazon domain
     * @return string Full API URL
     */
    private function buildUrl(string $asin, string $domain): string
    {
        $amazonUrl = "https://www.{$domain}/dp/{$asin}";

        $params = [
            'token' => $this->token,
            'url' => $amazonUrl,
            'scraper' => 'amazon-product-details',
            'country' => 'us',
        ];

        return self::API_URL . '?' . http_build_query($params);
    }

    /**
     * Convert domain to country code
     *
     * @param string $domain Amazon domain
     * @return string Country code
     */
    private function domainToCountry(string $domain): string
    {
        $map = [
            'amazon.com' => 'us',
            'amazon.co.uk' => 'uk',
            'amazon.de' => 'de',
            'amazon.fr' => 'fr',
            'amazon.it' => 'it',
            'amazon.es' => 'es',
            'amazon.co.jp' => 'jp',
            'amazon.ca' => 'ca',
            'amazon.com.au' => 'au',
            'amazon.in' => 'in',
            'amazon.com.mx' => 'mx',
            'amazon.com.br' => 'br',
        ];

        return $map[$domain] ?? 'us';
    }

    /**
     * Parse Crawlbase API response
     *
     * @param string $response Raw JSON response
     * @return array|null Normalized product data or null on failure
     */
    private function parseResponse(string $response): ?array
    {
        $data = json_decode($response, true);

        if (!$data) {
            $this->lastError = 'Invalid JSON response (length=' . strlen($response) . ')';
            return null;
        }

        // Crawlbase returns array, get first element
        if (isset($data[0])) {
            $data = $data[0];
        }

        // Log top-level keys for debugging
        $topKeys = array_keys($data);
        $pcStatus = $data['pc_status'] ?? 'missing';
        $origStatus = $data['original_status'] ?? 'missing';
        $this->logField('_api_response', implode(', ', $topKeys), "pc_status={$pcStatus}, original_status={$origStatus}", 'api', 'Crawlbase response structure');

        // Check pc_status (product crawl status)
        if (isset($data['pc_status']) && $data['pc_status'] !== 200) {
            $origInfo = isset($data['original_status']) ? ", original_status={$data['original_status']}" : '';
            $this->lastError = "Crawlbase pc_status: {$data['pc_status']}{$origInfo}";
            return null;
        }

        if (!isset($data['body'])) {
            $this->lastError = 'No body in response (keys: ' . implode(', ', $topKeys) . ')';
            return null;
        }

        $body = $data['body'];

        // Validate body is an array (Crawlbase sometimes returns string on error)
        if (!is_array($body)) {
            $this->lastError = 'Response body is not an object (got ' . gettype($body) . '): ' . substr((string) $body, 0, 150);
            return null;
        }

        $this->logField('_response_keys', array_keys($body), count($body), 'body', 'Available fields in response');

        // Check for product title (can be 'name' or 'title')
        $title = $body['name'] ?? $body['title'] ?? '';
        if (empty($title)) {
            $this->lastError = 'Product not found or blocked';
            return null;
        }

        // Validate currency matches expected market
        // Crawlbase sometimes routes through wrong geo, returning INR for amazon.com etc.
        $responseCurrency = $this->extractCurrency($body);
        if ($responseCurrency !== self::REQUIRED_CURRENCY) {
            $this->lastError = "Wrong market: got {$responseCurrency}, expected " . self::REQUIRED_CURRENCY . ". Crawlbase returned data from wrong region.";
            $this->logField('_currency_mismatch', $responseCurrency, self::REQUIRED_CURRENCY, 'currency', 'REJECTED: wrong market');
            return null;
        }

        return $this->normalizeProduct($body);
    }

    /**
     * Normalize product data to standard format
     *
     * @param array $body Crawlbase response body
     * @return array Normalized product data
     */
    private function normalizeProduct(array $body): array
    {
        // === CORE FIELDS ===
        $product = [
            'title' => $body['name'] ?? $body['title'] ?? '',
            'brand' => $this->extractBrand($body),
            'price' => $this->extractPrice($body),
            'original_price' => $this->extractOriginalPrice($body),
            'currency' => $this->extractCurrency($body),
            'rating' => $this->extractRating($body),
            'reviews_count' => $this->extractReviewCount($body),
            'in_stock' => $this->extractAvailability($body),
            'is_prime' => $this->extractPrime($body),
        ];

        // Log core fields
        $this->logField('title', $body['name'] ?? $body['title'] ?? null, $product['title'], 'name/title', 'Direct extraction');
        $this->logField('brand', $body['brand'] ?? $body['byLineInfo']['name'] ?? null, $product['brand'], 'brand/byLineInfo/productDetails', 'extractBrand()');
        $this->logField('price', $body['rawPrice'] ?? $body['price'] ?? $body['currentPrice'] ?? null, $product['price'], 'rawPrice/price/currentPrice/asinVariationValues/merchantInfo/deliveryMessages', 'extractPrice()');
        $this->logField('original_price', $body['originalPrice'] ?? $body['listPrice'] ?? $body['wasPrice'] ?? null, $product['original_price'], 'originalPrice/listPrice/wasPrice', 'extractOriginalPrice()');
        $this->logField('currency', $body['currency'] ?? null, $product['currency'], 'currency', 'extractCurrency()');
        $this->logField('rating', $body['customerReview'] ?? $body['rating'] ?? $body['averageRating'] ?? null, $product['rating'], 'customerReview/rating/averageRating/productReviewTop/reviews[]', 'extractRating()');
        $this->logField('reviews_count', $body['customerReviewCount'] ?? $body['reviewCount'] ?? $body['reviewsCount'] ?? null, $product['reviews_count'], 'customerReviewCount/reviewCount/reviewsCount/reviews[]', 'extractReviewCount()');
        $this->logField('in_stock', $body['inStock'] ?? $body['in_stock'] ?? $body['stockDetail'] ?? $body['availability'] ?? null, $product['in_stock'], 'inStock/in_stock/stockDetail/availability', 'extractAvailability()');
        $this->logField('is_prime', $body['isPrime'] ?? $body['is_prime'] ?? null, $product['is_prime'], 'isPrime/is_prime', 'extractPrime()');

        // === IMAGES ===
        $allImages = $this->extractAllImages($body);
        $product['image_url'] = !empty($allImages) ? $allImages[0] : '';
        $product['images_gallery'] = $allImages;
        $hiRes = is_array($body['highResolutionImages'] ?? null) ? $body['highResolutionImages'] : [];
        $mfrImg = is_array($body['manufacturerProductImages'] ?? null) ? $body['manufacturerProductImages'] : [];
        $imgArr = is_array($body['images'] ?? null) ? $body['images'] : [];
        $this->logField('images', [
            'highResolutionImages' => count($hiRes),
            'manufacturerProductImages' => count($mfrImg),
            'images' => count($imgArr),
        ], count($allImages), 'highResolutionImages/manufacturerProductImages/images', 'extractAllImages() - merged & deduplicated');

        // === DESCRIPTION ===
        $features = $body['features'] ?? $body['featureBullets'] ?? [];
        if (!is_array($features)) {
            $features = !empty($features) ? [(string) $features] : [];
        }
        $product['features'] = $features;
        $this->logField('features', $body['features'] ?? $body['featureBullets'] ?? null, count($features), 'features/featureBullets', count($features) . ' items');

        $description = $this->extractDescription($body);
        $descSource = !empty($body['description']) ? 'description' : (!empty($body['aboutThisItem']) ? 'aboutThisItem' : (!empty($body['manufacturerProductDescription']) ? 'manufacturerProductDescription' : 'none'));
        if (empty($description) && !empty($features)) {
            $description = implode("\n\n", array_slice($features, 0, 3));
            $descSource = 'features fallback';
        }
        $product['description'] = $description;
        $this->logField('description', substr($description, 0, 200), strlen($description), $descSource, 'extractDescription() - ' . strlen($description) . ' chars');

        // === CATEGORY ===
        $categoryData = $this->extractCategoryData($body);
        $product['category'] = $categoryData['category'];
        $product['category_path'] = $categoryData['category_path'];
        $product['category_tree'] = $categoryData['category_tree'];
        $product['category_ids'] = $categoryData['category_ids'];
        $this->logField('category_path', $body['breadCrumbs'] ?? $body['categories'] ?? null, $categoryData['category_path'], 'breadCrumbs/categories', 'extractCategoryData() - ' . count($categoryData['category_tree']) . ' levels');

        // === SPECIFICATIONS ===
        $specs = $body['productInformation'] ?? [];
        $product['specifications'] = is_array($specs) ? $specs : [];
        $details = $body['productDetails'] ?? [];
        $product['product_information'] = is_array($details) ? $details : [];
        $product['best_sellers_rank'] = $this->extractBestSellersRank($body);
        $this->logField('specifications', null, count($product['specifications']), 'productInformation', count($product['specifications']) . ' items');
        $this->logField('product_information', null, count($product['product_information']), 'productDetails', count($product['product_information']) . ' items');
        $this->logField('best_sellers_rank', null, $product['best_sellers_rank'], 'productDetails', 'extractBestSellersRank()');

        // === SELLER INFO ===
        $product['seller_info'] = $this->extractSellerInfo($body);
        $this->logField('seller_info', $body['soldBy'] ?? null, $product['seller_info'] !== null ? ($product['seller_info']['name'] ?? 'unknown') : null, 'soldBy', 'extractSellerInfo()');

        // === REVIEWS ===
        $reviews = $body['reviews'] ?? [];
        if (!is_array($reviews)) {
            $reviews = [];
        }
        $product['reviews_data'] = $reviews;
        $product['top_reviews'] = array_slice($reviews, 0, 10);
        $product['reviews_summary'] = $this->extractReviewsSummary($body);
        $this->logField('reviews_data', null, count($reviews), 'reviews', count($reviews) . ' reviews found');
        $this->logField('reviews_summary', $body['productReviewTop'] ?? null, $product['reviews_summary'] !== null ? 'present' : 'null', 'productReviewTop', 'extractReviewsSummary()');

        return $product;
    }

    /**
     * Max sane price for Amazon products (USD).
     * Anything above this is almost certainly garbage data from the API.
     */
    private const MAX_SANE_PRICE = 15000.00;

    /**
     * Extract price from response
     */
    private function extractPrice(array $body): ?float
    {
        // Priority 1: price string (most reliable — formatted with currency symbol)
        if (!empty($body['price'])) {
            $price = $this->parsePrice((string) $body['price']);
            if ($price !== null) return $price;
        }

        // Priority 2: rawPrice (numeric, but Crawlbase sometimes returns cents or garbage)
        if (isset($body['rawPrice']) && is_numeric($body['rawPrice'])) {
            $raw = round((float) $body['rawPrice'], 2);
            if ($raw > 0 && $raw <= self::MAX_SANE_PRICE) {
                return $raw;
            }
            // rawPrice might be in cents — try dividing by 100
            if ($raw > self::MAX_SANE_PRICE && ($raw / 100) <= self::MAX_SANE_PRICE) {
                return round($raw / 100, 2);
            }
        }

        // Priority 3: currentPrice
        if (!empty($body['currentPrice'])) {
            $price = $this->parsePrice((string) $body['currentPrice']);
            if ($price !== null) return $price;
        }

        // Fallback: try asinVariationValues (variant pricing)
        if (!empty($body['asinVariationValues']) && is_array($body['asinVariationValues'])) {
            foreach ($body['asinVariationValues'] as $variant) {
                if (is_array($variant) && !empty($variant['price'])) {
                    $price = $this->parsePrice((string) $variant['price']);
                    if ($price !== null) return $price;
                }
            }
        }

        // Fallback: try merchantInfo price
        if (!empty($body['merchantInfo']) && is_array($body['merchantInfo'])) {
            if (!empty($body['merchantInfo']['price'])) {
                $price = $this->parsePrice((string) $body['merchantInfo']['price']);
                if ($price !== null) return $price;
            }
        }

        // Fallback: try deliveryMessages for embedded price
        if (!empty($body['deliveryMessages']) && is_array($body['deliveryMessages'])) {
            foreach ($body['deliveryMessages'] as $msg) {
                $msgStr = is_string($msg) ? $msg : ($msg['message'] ?? '');
                if (preg_match('/\$\s?(\d+[\d,.]*\d)/', $msgStr, $m)) {
                    $price = $this->parsePrice($m[1]);
                    if ($price !== null && $price > 0) return $price;
                }
            }
        }

        return null;
    }

    /**
     * Extract original/list price
     */
    private function extractOriginalPrice(array $body): ?float
    {
        if (isset($body['originalPrice'])) {
            return $this->parsePrice((string) $body['originalPrice']);
        }

        if (isset($body['listPrice'])) {
            return $this->parsePrice((string) $body['listPrice']);
        }

        if (isset($body['wasPrice'])) {
            return $this->parsePrice((string) $body['wasPrice']);
        }

        return null;
    }

    /**
     * Parse price string to float
     */
    private function parsePrice(string $price): ?float
    {
        // Remove currency symbols and whitespace
        $price = preg_replace('/[^0-9.,]/', '', $price);

        if (empty($price)) {
            return null;
        }

        // Handle European format (1.234,56) vs US format (1,234.56)
        if (preg_match('/,\d{2}$/', $price)) {
            // European format
            $price = str_replace('.', '', $price);
            $price = str_replace(',', '.', $price);
        } else {
            // US format
            $price = str_replace(',', '', $price);
        }

        $result = round((float) $price, 2);

        // Sanity check: reject absurd prices
        if ($result <= 0 || $result > self::MAX_SANE_PRICE) {
            return null;
        }

        return $result;
    }

    /**
     * Extract currency
     */
    private function extractCurrency(array $body): string
    {
        if (isset($body['currency'])) {
            $currency = $body['currency'];
            return match ($currency) {
                '$' => 'USD',
                '€' => 'EUR',
                '£' => 'GBP',
                '¥' => 'JPY',
                default => strlen($currency) === 3 ? $currency : 'USD',
            };
        }
        return 'USD';
    }

    /**
     * Extract rating from response
     */
    private function extractRating(array $body): ?float
    {
        // Try customerReview string "4.6 out of 5 stars"
        if (isset($body['customerReview'])) {
            if (preg_match('/(\d+\.?\d*)\s+out\s+of\s+5/i', $body['customerReview'], $matches)) {
                return round((float) $matches[1], 1);
            }
        }

        // Try direct rating field
        if (isset($body['rating']) && is_numeric($body['rating'])) {
            return round((float) $body['rating'], 1);
        }

        // Try averageRating
        if (isset($body['averageRating']) && is_numeric($body['averageRating'])) {
            return round((float) $body['averageRating'], 1);
        }

        // Fallback: calculate weighted average from productReviewTop star distribution
        // e.g. {"5 star": "65%", "4 star": "20%", "3 star": "8%", "2 star": "4%", "1 star": "3%"}
        $reviewTop = $body['productReviewTop'] ?? [];
        if (!empty($reviewTop) && is_array($reviewTop)) {
            $weightedSum = 0;
            $totalPercent = 0;
            for ($star = 5; $star >= 1; $star--) {
                $key = $star . ' star';
                if (isset($reviewTop[$key])) {
                    $percent = (float) preg_replace('/[^0-9.]/', '', (string) $reviewTop[$key]);
                    $weightedSum += $star * $percent;
                    $totalPercent += $percent;
                }
            }
            if ($totalPercent > 0) {
                return round($weightedSum / $totalPercent, 1);
            }
        }

        // Fallback: average rating from individual reviews array
        if (!empty($body['reviews']) && is_array($body['reviews'])) {
            $sum = 0;
            $count = 0;
            foreach ($body['reviews'] as $review) {
                if (is_array($review) && isset($review['rating'])) {
                    $rating = (float) preg_replace('/[^0-9.]/', '', (string) $review['rating']);
                    if ($rating > 0 && $rating <= 5) {
                        $sum += $rating;
                        $count++;
                    }
                }
            }
            if ($count > 0) {
                return round($sum / $count, 1);
            }
        }

        return null;
    }

    /**
     * Extract review count
     */
    private function extractReviewCount(array $body): int
    {
        if (isset($body['customerReviewCount'])) {
            $count = (int) preg_replace('/[^0-9]/', '', (string) $body['customerReviewCount']);
            if ($count > 0) return $count;
        }

        if (isset($body['reviewCount'])) {
            $count = (int) preg_replace('/[^0-9]/', '', (string) $body['reviewCount']);
            if ($count > 0) return $count;
        }

        if (isset($body['reviewsCount'])) {
            $count = (int) preg_replace('/[^0-9]/', '', (string) $body['reviewsCount']);
            if ($count > 0) return $count;
        }

        // Fallback: count from reviews array
        if (!empty($body['reviews']) && is_array($body['reviews'])) {
            $count = count($body['reviews']);
            if ($count > 0) return $count;
        }

        return 0;
    }

    /**
     * Extract brand
     */
    private function extractBrand(array $body): string
    {
        if (!empty($body['brand'])) {
            return $this->cleanBrandName($body['brand']);
        }

        // Try byLineInfo
        if (isset($body['byLineInfo']['name'])) {
            return $this->cleanBrandName($body['byLineInfo']['name']);
        }

        // Try productDetails or productInformation for Brand
        $pd = is_array($body['productDetails'] ?? null) ? $body['productDetails'] : [];
        $pi = is_array($body['productInformation'] ?? null) ? $body['productInformation'] : [];
        $details = array_merge($pd, $pi);
        foreach ($details as $detail) {
            if (is_array($detail) && isset($detail['name'])) {
                if (strcasecmp($detail['name'], 'Brand') === 0 && !empty($detail['value'])) {
                    return $this->cleanBrandName($detail['value']);
                }
            }
        }

        // Fallback to Manufacturer
        foreach ($details as $detail) {
            if (is_array($detail) && isset($detail['name'])) {
                if (strcasecmp($detail['name'], 'Manufacturer') === 0 && !empty($detail['value'])) {
                    return $this->cleanBrandName($detail['value']);
                }
            }
        }

        return '';
    }

    /**
     * Clean brand name - remove "Store" suffix and patterns
     */
    private function cleanBrandName(string $brand): string
    {
        // Remove "Store" suffix
        $brand = preg_replace('/\s+Store$/i', '', $brand);
        // Remove "Visit the ... Store" pattern
        if (preg_match('/^Visit the (.+?) Store$/i', $brand, $matches)) {
            $brand = $matches[1];
        }
        return trim($brand);
    }

    /**
     * Extract all images
     */
    private function extractAllImages(array $body): array
    {
        $highRes = is_array($body['highResolutionImages'] ?? null) ? $body['highResolutionImages'] : [];
        $mfrImages = is_array($body['manufacturerProductImages'] ?? null) ? $body['manufacturerProductImages'] : [];
        $images = is_array($body['images'] ?? null) ? $body['images'] : [];

        $allImages = array_merge($highRes, $mfrImages, $images);
        return array_values(array_unique(array_filter($allImages)));
    }

    /**
     * Extract description from multiple sources
     */
    private function extractDescription(array $body): string
    {
        $descriptions = [];

        if (!empty($body['description'])) {
            $descriptions[] = $body['description'];
        }

        if (!empty($body['aboutThisItem'])) {
            $descriptions[] = $body['aboutThisItem'];
        }

        if (!empty($body['manufacturerProductDescription']) && is_array($body['manufacturerProductDescription'])) {
            foreach ($body['manufacturerProductDescription'] as $item) {
                if (is_array($item) && !empty($item['media_text'])) {
                    $descriptions[] = $item['media_text'];
                }
            }
        }

        return implode("\n\n", $descriptions);
    }

    /**
     * Extract availability
     */
    private function extractAvailability(array $body): ?bool
    {
        if (isset($body['inStock'])) {
            return (bool) $body['inStock'];
        }

        if (isset($body['in_stock'])) {
            return (bool) $body['in_stock'];
        }

        if (isset($body['stockDetail'])) {
            return $this->parseAvailabilityString($body['stockDetail']);
        }

        if (isset($body['availability'])) {
            return $this->parseAvailabilityString($body['availability']);
        }

        // Return null when no stock data is found (will trigger retry)
        return null;
    }

    /**
     * Parse availability string
     */
    private function parseAvailabilityString(string $text): bool
    {
        $lower = strtolower($text);

        if (strpos($lower, 'in stock') !== false || strpos($lower, 'ships from') !== false) {
            return true;
        }

        if (strpos($lower, 'out of stock') !== false ||
            strpos($lower, 'unavailable') !== false ||
            strpos($lower, 'currently unavailable') !== false) {
            return false;
        }

        return true;
    }

    /**
     * Extract Prime eligibility
     */
    private function extractPrime(array $body): bool
    {
        if (isset($body['isPrime'])) {
            return (bool) $body['isPrime'];
        }

        if (isset($body['is_prime'])) {
            return (bool) $body['is_prime'];
        }

        return false;
    }

    /**
     * Extract category data from breadcrumbs
     */
    private function extractCategoryData(array $body): array
    {
        $result = [
            'category' => '',
            'category_path' => '',
            'category_tree' => [],
            'category_ids' => '',
        ];

        $breadcrumbs = $body['breadCrumbs'] ?? [];
        if (!is_array($breadcrumbs)) {
            $breadcrumbs = [];
        }

        if (empty($breadcrumbs)) {
            // Fallback to categories string
            if (!empty($body['categories']) && is_string($body['categories'])) {
                $result['category'] = $body['categories'];
                $result['category_path'] = $body['categories'];
            }
            return $result;
        }

        $names = [];
        $ids = [];
        $tree = [];

        foreach ($breadcrumbs as $crumb) {
            if (is_string($crumb)) {
                $names[] = $crumb;
                $tree[] = ['name' => $crumb, 'link' => null];
            } elseif (is_array($crumb)) {
                $name = $crumb['name'] ?? '';
                $link = $crumb['link'] ?? '';

                if (!empty($name)) {
                    $names[] = $name;
                    $tree[] = ['name' => $name, 'link' => $link];

                    // Extract node ID from link
                    if (preg_match('/node=(\d+)/', $link, $matches)) {
                        $ids[] = $matches[1];
                    }
                }
            }
        }

        $result['category'] = !empty($names) ? end($names) : '';
        $result['category_path'] = implode(' > ', $names);
        $result['category_tree'] = $tree;
        $result['category_ids'] = implode(',', $ids);

        return $result;
    }

    /**
     * Extract Best Sellers Rank from productDetails
     */
    private function extractBestSellersRank(array $body): ?string
    {
        $details = is_array($body['productDetails'] ?? null) ? $body['productDetails'] : [];

        foreach ($details as $detail) {
            if (is_array($detail) && isset($detail['name'])) {
                if (stripos($detail['name'], 'Best Sellers Rank') !== false) {
                    return $detail['value'] ?? null;
                }
            }
        }

        return null;
    }

    /**
     * Extract seller info
     */
    private function extractSellerInfo(array $body): ?array
    {
        $soldBy = $body['soldBy'] ?? null;

        if (empty($soldBy)) {
            return null;
        }

        return [
            'sellerID' => $soldBy['sellerID'] ?? null,
            'name' => $soldBy['name'] ?? null,
            'link' => $soldBy['link'] ?? null,
            'shipsFrom' => null,
        ];
    }

    /**
     * Extract reviews summary (star distribution)
     */
    private function extractReviewsSummary(array $body): ?array
    {
        $reviewTop = $body['productReviewTop'] ?? [];

        if (empty($reviewTop)) {
            return null;
        }

        return [
            '5_star' => $reviewTop['5 star'] ?? null,
            '4_star' => $reviewTop['4 star'] ?? null,
            '3_star' => $reviewTop['3 star'] ?? null,
            '2_star' => $reviewTop['2 star'] ?? null,
            '1_star' => $reviewTop['1 star'] ?? null,
        ];
    }

    /**
     * Search products on Amazon via Crawlbase SERP scraper
     *
     * @param string $query Search query
     * @param string $domain Amazon domain (e.g., amazon.com)
     * @param int $page Page number (1-based, default: 1)
     * @return array|null Array of products or null on failure
     */
    public function search(string $query, string $domain = 'amazon.com', int $page = 1): ?array
    {
        $this->lastError = null;

        $url = $this->buildSearchUrl($query, $domain, $page);

        $response = wp_remote_get($url, [
            'timeout' => self::TIMEOUT,
            'headers' => [
                'Accept' => 'application/json',
            ],
        ]);

        if (is_wp_error($response)) {
            $this->lastError = 'WP HTTP Error: ' . $response->get_error_message();
            return null;
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);

        if ($code !== 200) {
            $this->lastError = $this->buildHttpError($code, $body);
            return null;
        }

        return $this->parseSearchResponse($body);
    }

    /**
     * Build Crawlbase search URL
     *
     * @param string $query Search query
     * @param string $domain Amazon domain
     * @param int $page Page number (1-based)
     * @return string Full API URL
     */
    private function buildSearchUrl(string $query, string $domain, int $page = 1): string
    {
        $amazonUrl = "https://www.{$domain}/s?k=" . urlencode($query);

        // Add page parameter for pagination (Amazon uses page=N)
        if ($page > 1) {
            $amazonUrl .= "&page=" . $page;
        }

        $country = 'us';

        $params = [
            'token' => $this->token,
            'url' => $amazonUrl,
            'scraper' => 'amazon-serp',
            'country' => $country,
        ];

        return self::API_URL . '?' . http_build_query($params);
    }

    /**
     * Parse Crawlbase search response
     *
     * amazon-serp response structure:
     * {
     *   "pc_status": 200,
     *   "body": {
     *     "products": [
     *       {
     *         "name": "Product title",
     *         "image": "https://...",
     *         "price": "$99.99",
     *         "customerReview": "4.5",
     *         "customerReviewCount": "1,234",
     *         "url": "/dp/B0XXXXXX/...",
     *         "category": "Electronics"
     *       }
     *     ]
     *   }
     * }
     */
    private function parseSearchResponse(string $response): ?array
    {
        $data = json_decode($response, true);

        if (!$data) {
            $this->lastError = 'Invalid JSON response';
            return null;
        }

        // Crawlbase returns array, get first element
        if (isset($data[0])) {
            $data = $data[0];
        }

        // Check pc_status
        if (isset($data['pc_status']) && $data['pc_status'] !== 200) {
            $this->lastError = "Crawlbase status: {$data['pc_status']}";
            return null;
        }

        if (!isset($data['body'])) {
            $this->lastError = 'No body in response';
            return null;
        }

        $body = $data['body'];
        if (!is_array($body)) {
            $this->lastError = 'Search response body is not an object (got ' . gettype($body) . ')';
            return null;
        }

        $products = [];

        // amazon-serp returns products in body.products
        // Fallback to other possible field names for compatibility
        $items = $body['products'] ?? $body['amazonProducts'] ?? $body['items'] ?? $body['results'] ?? [];
        if (!is_array($items)) {
            $items = [];
        }

        foreach ($items as $item) {
            if (!is_array($item)) {
                continue;
            }
            $product = $this->normalizeSearchResult($item);
            if (!empty($product['asin'])) {
                $products[] = $product;
            }
        }

        return $products;
    }

    /**
     * Normalize search result to simple format
     *
     * amazon-serp fields: name, image, price, customerReview, customerReviewCount, url
     */
    private function normalizeSearchResult(array $item): array
    {
        // Extract ASIN from URL if not directly provided
        $asin = $item['asin'] ?? '';
        if (empty($asin)) {
            // Try url field (amazon-serp format: /dp/ASIN/...)
            $url = $item['url'] ?? $item['link'] ?? '';
            if (preg_match('/\/dp\/([A-Z0-9]{10})/', $url, $matches)) {
                $asin = $matches[1];
            }
        }

        // Extract rating - try customerReview (amazon-serp) or rating
        $rating = null;
        $ratingField = $item['customerReview'] ?? $item['rating'] ?? null;
        if ($ratingField !== null) {
            if (is_numeric($ratingField)) {
                $rating = (float) $ratingField;
            } elseif (preg_match('/(\d+\.?\d*)/', (string) $ratingField, $matches)) {
                $rating = (float) $matches[1];
            }
        }

        // Extract review count - try customerReviewCount (amazon-serp) or reviewCount/reviews
        $reviews = 0;
        $reviewField = $item['customerReviewCount'] ?? $item['reviewCount'] ?? $item['reviewsCount'] ?? $item['reviews'] ?? null;
        if ($reviewField !== null) {
            $reviews = (int) preg_replace('/[^0-9]/', '', (string) $reviewField);
        }

        // Extract price
        $price = null;
        if (isset($item['rawPrice']) && is_numeric($item['rawPrice'])) {
            $price = round((float) $item['rawPrice'], 2);
        } elseif (isset($item['price'])) {
            $price = $this->parsePrice((string) $item['price']);
        }

        return [
            'asin' => $asin,
            'title' => $item['name'] ?? $item['title'] ?? '',
            'image' => $item['image'] ?? $item['thumbnail'] ?? $item['imageUrl'] ?? '',
            'price' => $price,
            'rating' => $rating,
            'reviews' => $reviews,
            'isPrime' => $item['isPrime'] ?? $item['is_prime'] ?? false,
            'brand' => $item['brand'] ?? '',
        ];
    }

    /**
     * Test API connection
     *
     * @return array Test result with 'success' and 'message'
     */
    public function test(): array
    {
        // Use a known ASIN for testing (Amazon Basics product)
        $testAsin = 'B07NPKN7Z6';

        $result = $this->fetch($testAsin, 'amazon.com');

        if ($result && !empty($result['title'])) {
            return [
                'success' => true,
                'message' => 'Crawlbase API is working correctly',
                'data' => [
                    'title' => $result['title'],
                    'price' => $result['price'] ?? null,
                ],
            ];
        }

        return [
            'success' => false,
            'message' => $this->lastError ?? 'Unknown error',
            'token_prefix' => substr($this->token, 0, 8) . '...',
            'field_log' => $this->fieldLog,
        ];
    }

    /**
     * Build detailed HTTP error message from Crawlbase response
     *
     * Crawlbase HTTP status codes (from docs):
     * - 400: Bad request / invalid parameters
     * - 401: Invalid token
     * - 403: Account restricted or unsupported feature
     * - 429: Rate limit exceeded
     * - 499: Client closed connection (need to wait 90s)
     * - 500: Crawlbase internal error
     * - 520: Generic failure (check pc_status and original_status)
     */
    private function buildHttpError(int $code, string $body): string
    {
        // Friendly messages for known Crawlbase status codes
        $knownErrors = [
            400 => 'Bad request - invalid parameters sent to Crawlbase',
            401 => 'Invalid API token - check your Crawlbase token in Settings',
            403 => 'Account restricted or unsupported feature for your plan',
            429 => 'Rate limit exceeded - too many API calls',
            499 => 'Connection closed too early - Crawlbase needs up to 90s',
            500 => 'Crawlbase internal error - their service may be temporarily down',
            520 => 'Generic scrape failure - check pc_status for details',
        ];

        $friendlyMsg = $knownErrors[$code] ?? '';

        // Try to parse JSON error body for more details
        $detail = '';
        if (!empty($body)) {
            $json = json_decode($body, true);
            if (is_array($json)) {
                // Crawlbase returns pc_status and original_status in error responses
                $pcStatus = $json['pc_status'] ?? ($json[0]['pc_status'] ?? null);
                $origStatus = $json['original_status'] ?? ($json[0]['original_status'] ?? null);
                $errorMsg = $json['error'] ?? ($json[0]['error'] ?? null);

                $parts = [];
                if ($pcStatus) {
                    $parts[] = "pc_status={$pcStatus}";
                }
                if ($origStatus) {
                    $parts[] = "original_status={$origStatus}";
                }
                if ($errorMsg) {
                    $parts[] = "error={$errorMsg}";
                }
                if (!empty($parts)) {
                    $detail = ' [' . implode(', ', $parts) . ']';
                }
            } else {
                // Not JSON - include raw body preview
                $bodyPreview = substr(trim($body), 0, 150);
                if (!empty($bodyPreview)) {
                    $detail = ' [' . $bodyPreview . ']';
                }
            }
        }

        if (!empty($friendlyMsg)) {
            return "HTTP {$code}: {$friendlyMsg}{$detail}";
        }

        return "HTTP {$code}: Unexpected error{$detail}";
    }

    /**
     * Get last error message
     */
    public function getLastError(): ?string
    {
        return $this->lastError;
    }

    /**
     * Log a field extraction for diagnostics
     *
     * @param string $field Field name
     * @param mixed $rawValue Raw value from API response
     * @param mixed $parsedValue Parsed/normalized value
     * @param string $source Source key(s) in the response
     * @param string $notes Additional notes
     */
    private function logField(string $field, mixed $rawValue, mixed $parsedValue, string $source = '', string $notes = ''): void
    {
        // Truncate raw values that are too long
        $rawStr = is_array($rawValue) ? wp_json_encode($rawValue) : (string) ($rawValue ?? '');
        if (strlen($rawStr) > 500) {
            $rawStr = substr($rawStr, 0, 500) . '...[truncated]';
        }
        $this->fieldLog[] = [
            'field' => $field,
            'raw' => $rawStr,
            'parsed' => $parsedValue,
            'source' => $source,
            'notes' => $notes,
        ];
    }

    /**
     * Get the field extraction log
     *
     * @return array Field log entries
     */
    public function getFieldLog(): array
    {
        return $this->fieldLog;
    }
}
