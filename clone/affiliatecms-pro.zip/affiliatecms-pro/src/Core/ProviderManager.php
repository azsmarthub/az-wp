<?php
/**
 * Provider Manager
 *
 * Simplified provider management for scraping Amazon products
 * Only supports Crawlbase and PA-API (no key rotation, no multiple keys)
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro\Core;

class ProviderManager
{
    private static ?ProviderManager $instance = null;

    private ?CrawlbaseProvider $crawlbase = null;
    private ?PaapiProvider $paapi = null;

    /**
     * wp_options keys
     */
    private const OPTION_CRAWLBASE_TOKEN = 'acms_crawlbase_token';
    private const OPTION_PAAPI_CREDENTIALS = 'acms_paapi_credentials';

    /**
     * Provider identifiers
     */
    public const PROVIDER_CRAWLBASE = 'crawlbase';
    public const PROVIDER_PAAPI = 'paapi';

    /**
     * Get singleton instance
     */
    public static function instance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Private constructor for singleton
     */
    private function __construct()
    {
        $this->initProviders();
    }

    /**
     * Initialize providers if configured
     */
    private function initProviders(): void
    {
        // Initialize Crawlbase if configured
        $crawlbaseToken = $this->getCrawlbaseToken();
        if ($crawlbaseToken) {
            $this->crawlbase = new CrawlbaseProvider($crawlbaseToken);
        }

        // Initialize PA-API if configured
        $paapiCredentials = $this->getPaapiCredentials();
        if ($paapiCredentials) {
            $this->paapi = new PaapiProvider(
                $paapiCredentials['access_key'],
                $paapiCredentials['secret_key'],
                $paapiCredentials['partner_tag'],
                $paapiCredentials['region'] ?? 'com'
            );
        }
    }

    /**
     * Retry settings
     * PA-API: 3 retries, 2s delay (rate limited, transient failures)
     * Crawlbase: 2 retries, 1s delay (generally more stable)
     */
    private const PAAPI_MAX_RETRIES = 3;
    private const PAAPI_RETRY_DELAY = 2; // seconds

    private const CRAWLBASE_MAX_RETRIES = 3;  // Increased to handle missing data retries
    private const CRAWLBASE_RETRY_DELAY = 1; // seconds

    /**
     * Overall timeout (seconds) - prevent hanging
     */
    private const SCRAPE_TIMEOUT = 90; // 90 seconds max per ASIN

    /**
     * Last error message
     */
    private ?string $lastError = null;
    private ?string $lastSuccessProvider = null;

    /**
     * Scrape log for debugging
     */
    private array $scrapeLog = [];

    /**
     * Main scraping method - uses provider priority from settings
     *
     * Flow (sequential, one-way):
     * 1. Get primary/fallback provider from settings
     * 2. Try primary provider (with retries)
     * 3. If fail and fallback configured AND available, try fallback
     * 4. Return result or null
     *
     * Features:
     * - Respects provider priority settings
     * - Skips unconfigured providers automatically
     * - Retry logic for both providers (PA-API: 3x 2s, Crawlbase: 2x 1s)
     * - Logs all attempts for debugging
     *
     * @param string $asin Amazon product ASIN
     * @param string $domain Amazon domain (default: amazon.com)
     * @return array|null Product data with 'provider' key or null on failure
     */
    public function scrape(string $asin, string $domain = 'amazon.com'): ?array
    {
        $this->lastError = null;
        $this->scrapeLog = [];
        $startTime = time();

        $this->log("SCRAPE START: ASIN={$asin}, Domain={$domain}");

        // Get provider settings
        $settings = get_option('acms_general_settings', []);
        $primaryProvider = $settings['default_provider'] ?? 'crawlbase';
        $fallbackProvider = $settings['fallback_provider'] ?? 'none';

        $this->log("Settings: Primary={$primaryProvider}, Fallback={$fallbackProvider}");

        // Check if primary provider is configured
        if (!$this->isProviderConfigured($primaryProvider)) {
            $this->log("Primary [{$primaryProvider}]: NOT CONFIGURED - skipping");

            // If primary not configured but fallback is, use fallback as primary
            if ($fallbackProvider !== 'none' && $this->isProviderConfigured($fallbackProvider)) {
                $this->log("Using fallback [{$fallbackProvider}] as primary");
                $primaryProvider = $fallbackProvider;
                $fallbackProvider = 'none';
            } else {
                $this->lastError = "No provider configured";
                $this->log("SCRAPE FAILED: No provider configured");
                return null;
            }
        }

        // Try primary provider with retry
        $this->log("Trying primary [{$primaryProvider}]...");
        $result = $this->scrapeWithRetry($primaryProvider, $asin, $domain, $startTime);
        if ($result !== null) {
            $this->log("SUCCESS via {$primaryProvider}");
            return array_merge($result, [
                'provider' => $primaryProvider,
                'log' => $this->scrapeLog,
                'field_log' => ($primaryProvider === self::PROVIDER_CRAWLBASE && $this->crawlbase && method_exists($this->crawlbase, 'getFieldLog'))
                    ? $this->crawlbase->getFieldLog()
                    : [],
            ]);
        }

        // Check timeout before fallback
        if ($this->isTimedOut($startTime)) {
            $this->lastError = "Scrape timeout exceeded";
            $this->log("SCRAPE FAILED: Timeout exceeded");
            return null;
        }

        // Try fallback if configured AND available
        if ($fallbackProvider !== 'none' && $this->isProviderConfigured($fallbackProvider)) {
            $this->log("Primary failed. Trying fallback [{$fallbackProvider}]...");
            $result = $this->scrapeWithRetry($fallbackProvider, $asin, $domain, $startTime);
            if ($result !== null) {
                $this->log("SUCCESS via {$fallbackProvider} (fallback)");
                return array_merge($result, [
                    'provider' => $fallbackProvider,
                    'log' => $this->scrapeLog,
                    'field_log' => ($fallbackProvider === self::PROVIDER_CRAWLBASE && $this->crawlbase && method_exists($this->crawlbase, 'getFieldLog'))
                        ? $this->crawlbase->getFieldLog()
                        : [],
                ]);
            }
        } elseif ($fallbackProvider !== 'none') {
            $this->log("Fallback [{$fallbackProvider}]: NOT CONFIGURED - skipping");
        }

        $this->lastError = "All providers failed for ASIN: {$asin}";
        $this->log("SCRAPE FAILED: All providers exhausted");
        return null;
    }

    /**
     * Quick scrape - fetch only dynamic data (price, rating, stock)
     *
     * Much faster than full scrape. Used for scheduled updates of existing products.
     * Only fetches: price, original_price, rating, reviews_count, in_stock, is_prime
     *
     * Flow:
     * 1. Get primary/fallback provider from settings
     * 2. Try primary provider (with retries)
     * 3. If fail and fallback configured AND available, try fallback
     * 4. Return dynamic data or null
     *
     * @param string $asin Amazon product ASIN
     * @param string $domain Amazon domain (default: amazon.com)
     * @return array|null Dynamic data with 'provider' key or null on failure
     */
    public function quickScrape(string $asin, string $domain = 'amazon.com'): ?array
    {
        $this->lastError = null;
        $this->scrapeLog = [];
        $startTime = time();

        $this->log("QUICK SCRAPE START: ASIN={$asin}, Domain={$domain}");

        // Get provider settings
        $settings = get_option('acms_general_settings', []);
        $primaryProvider = $settings['default_provider'] ?? 'crawlbase';
        $fallbackProvider = $settings['fallback_provider'] ?? 'none';

        $this->log("Settings: Primary={$primaryProvider}, Fallback={$fallbackProvider}");

        // Check if primary provider is configured
        if (!$this->isProviderConfigured($primaryProvider)) {
            $this->log("Primary [{$primaryProvider}]: NOT CONFIGURED - skipping");

            // If primary not configured but fallback is, use fallback as primary
            if ($fallbackProvider !== 'none' && $this->isProviderConfigured($fallbackProvider)) {
                $this->log("Using fallback [{$fallbackProvider}] as primary");
                $primaryProvider = $fallbackProvider;
                $fallbackProvider = 'none';
            } else {
                $this->lastError = "No provider configured";
                $this->log("QUICK SCRAPE FAILED: No provider configured");
                return null;
            }
        }

        // Try primary provider with retry
        $this->log("Trying primary [{$primaryProvider}] for quick scrape...");
        $result = $this->quickScrapeWithRetry($primaryProvider, $asin, $domain, $startTime);
        if ($result !== null) {
            $this->log("SUCCESS via {$primaryProvider}");
            return array_merge($result, ['provider' => $primaryProvider, 'log' => $this->scrapeLog]);
        }

        // Check timeout before fallback
        if ($this->isTimedOut($startTime)) {
            $this->lastError = "Quick scrape timeout exceeded";
            $this->log("QUICK SCRAPE FAILED: Timeout exceeded");
            return null;
        }

        // Try fallback if configured AND available
        if ($fallbackProvider !== 'none' && $this->isProviderConfigured($fallbackProvider)) {
            $this->log("Primary failed. Trying fallback [{$fallbackProvider}]...");
            $result = $this->quickScrapeWithRetry($fallbackProvider, $asin, $domain, $startTime);
            if ($result !== null) {
                $this->log("SUCCESS via {$fallbackProvider} (fallback)");
                return array_merge($result, ['provider' => $fallbackProvider, 'log' => $this->scrapeLog]);
            }
        } elseif ($fallbackProvider !== 'none') {
            $this->log("Fallback [{$fallbackProvider}]: NOT CONFIGURED - skipping");
        }

        $this->lastError = "Quick scrape failed for ASIN: {$asin}";
        $this->log("QUICK SCRAPE FAILED: All providers exhausted");
        return null;
    }

    /**
     * Quick scrape with specific provider including retry logic
     *
     * @param string $provider Provider name
     * @param string $asin Amazon product ASIN
     * @param string $domain Amazon domain
     * @param int $startTime Start timestamp for timeout check
     * @return array|null Dynamic data or null on failure
     */
    private function quickScrapeWithRetry(string $provider, string $asin, string $domain, int $startTime): ?array
    {
        $maxRetries = ($provider === self::PROVIDER_CRAWLBASE) ? self::CRAWLBASE_MAX_RETRIES : self::PAAPI_MAX_RETRIES;
        $retryDelay = ($provider === self::PROVIDER_CRAWLBASE) ? self::CRAWLBASE_RETRY_DELAY : self::PAAPI_RETRY_DELAY;

        for ($attempt = 1; $attempt <= $maxRetries; $attempt++) {
            // Check timeout
            if ($this->isTimedOut($startTime)) {
                $this->log("  {$provider}: Timeout - aborting");
                return null;
            }

            $this->log("  {$provider} quick scrape attempt {$attempt}/{$maxRetries}");

            $result = null;
            if ($provider === self::PROVIDER_CRAWLBASE && $this->crawlbase) {
                $result = $this->crawlbase->quickFetch($asin, $domain);
            } elseif ($provider === self::PROVIDER_PAAPI && $this->paapi) {
                $result = $this->paapi->quickFetch($asin);
            }

            if ($result !== null) {
                $this->log("  {$provider}: SUCCESS (quick scrape)");
                return $result;
            }

            $error = ($provider === self::PROVIDER_CRAWLBASE)
                ? ($this->crawlbase?->getLastError() ?? 'Unknown error')
                : ($this->paapi?->getLastError() ?? 'Unknown error');
            $this->log("  {$provider}: FAILED - {$error}");

            // Wait before retry (except on last attempt)
            if ($attempt < $maxRetries) {
                $this->log("  Waiting {$retryDelay}s before retry...");
                sleep($retryDelay);
            }
        }

        return null;
    }

    /**
     * Check if a provider is configured
     */
    private function isProviderConfigured(string $provider): bool
    {
        if ($provider === self::PROVIDER_CRAWLBASE) {
            return $this->crawlbase !== null;
        }
        if ($provider === self::PROVIDER_PAAPI) {
            return $this->paapi !== null;
        }
        return false;
    }

    /**
     * Check if overall timeout exceeded
     */
    private function isTimedOut(int $startTime): bool
    {
        return (time() - $startTime) >= self::SCRAPE_TIMEOUT;
    }

    /**
     * Scrape with specific provider including retry logic
     *
     * @param string $provider Provider name
     * @param string $asin Amazon product ASIN
     * @param string $domain Amazon domain
     * @param int $startTime Start timestamp for timeout check
     * @return array|null Product data or null on failure
     */
    private function scrapeWithRetry(string $provider, string $asin, string $domain, int $startTime): ?array
    {
        if ($provider === self::PROVIDER_CRAWLBASE && $this->crawlbase) {
            return $this->scrapeWithCrawlbaseRetry($asin, $domain, $startTime);
        }

        if ($provider === self::PROVIDER_PAAPI && $this->paapi) {
            return $this->scrapeWithPaapiRetry($asin, $startTime);
        }

        return null;
    }

    /**
     * Critical fields that should be present in scrape result
     * If missing, we'll retry the scrape to get complete data
     */
    private const CRITICAL_FIELDS = ['price', 'in_stock', 'rating'];

    /**
     * Check if scrape result has critical data (price, stock)
     *
     * @param array $result Scrape result
     * @return array Missing critical fields
     */
    private function getMissingCriticalFields(array $result): array
    {
        $missing = [];
        foreach (self::CRITICAL_FIELDS as $field) {
            if (!isset($result[$field]) || $result[$field] === null || $result[$field] === '') {
                $missing[] = $field;
            }
        }
        return $missing;
    }

    /**
     * Count how many critical fields are present in result
     *
     * @param array|null $result Scrape result
     * @return int Number of critical fields present
     */
    private function countCriticalFields(?array $result): int
    {
        if ($result === null) {
            return 0;
        }
        return count(self::CRITICAL_FIELDS) - count($this->getMissingCriticalFields($result));
    }

    /**
     * Scrape with Crawlbase including retry logic
     * Retry up to 3 times with 1s delay between attempts
     * Also retries if critical data (price, stock) is missing
     * Merges data from multiple attempts to get the best result
     *
     * @param string $asin Amazon product ASIN
     * @param string $domain Amazon domain
     * @param int $startTime Start timestamp for timeout check
     * @return array|null Product data or null on failure
     */
    private function scrapeWithCrawlbaseRetry(string $asin, string $domain, int $startTime): ?array
    {
        $mergedResult = null;

        for ($attempt = 1; $attempt <= self::CRAWLBASE_MAX_RETRIES; $attempt++) {
            // Check timeout
            if ($this->isTimedOut($startTime)) {
                $this->log("  Crawlbase: Timeout - aborting");
                return $mergedResult;
            }

            $this->log("  Crawlbase attempt {$attempt}/" . self::CRAWLBASE_MAX_RETRIES);
            $result = $this->crawlbase->fetch($asin, $domain);

            if ($result !== null) {
                // Merge with previous results - fill in missing critical fields
                if ($mergedResult === null) {
                    $mergedResult = $result;
                } else {
                    // Merge: use new values only if the old value is missing
                    foreach (self::CRITICAL_FIELDS as $field) {
                        $oldValue = $mergedResult[$field] ?? null;
                        $newValue = $result[$field] ?? null;
                        // If old is missing but new has value, use new
                        if (($oldValue === null || $oldValue === '') && $newValue !== null && $newValue !== '') {
                            $mergedResult[$field] = $newValue;
                            $this->log("  Merged {$field} from attempt {$attempt}");
                        }
                    }
                }

                // Check if merged result has all critical fields
                $missingFields = $this->getMissingCriticalFields($mergedResult);

                if (empty($missingFields)) {
                    // All critical fields present - success!
                    $this->log("  Crawlbase: SUCCESS (all critical data present)");
                    return $mergedResult;
                }

                // Some critical fields still missing
                $missingStr = implode(', ', $missingFields);
                $this->log("  Crawlbase: Data incomplete - missing: {$missingStr}");

                // Log what we have so far
                $priceInfo = isset($mergedResult['price']) && $mergedResult['price'] !== null
                    ? "\${$mergedResult['price']}" : 'N/A';
                $stockInfo = isset($mergedResult['in_stock']) && $mergedResult['in_stock'] !== null
                    ? ($mergedResult['in_stock'] ? 'In Stock' : 'Out of Stock') : 'N/A';
                $ratingInfo = isset($mergedResult['rating']) && $mergedResult['rating'] !== null
                    ? "{$mergedResult['rating']}★" : 'N/A';
                $this->log("  Current data: price={$priceInfo}, stock={$stockInfo}, rating={$ratingInfo}");

                // If this is not the last attempt, retry
                if ($attempt < self::CRAWLBASE_MAX_RETRIES) {
                    $this->log("  Retrying for missing data...");
                    sleep(self::CRAWLBASE_RETRY_DELAY);
                    continue;
                }

                // Last attempt - return merged result
                $this->log("  Crawlbase: Max retries reached, using best available data");
                return $mergedResult;
            }

            $error = $this->crawlbase->getLastError() ?? 'Unknown error';
            $this->log("  Crawlbase: FAILED - {$error}");

            // Wait before retry (except on last attempt)
            if ($attempt < self::CRAWLBASE_MAX_RETRIES) {
                $this->log("  Waiting " . self::CRAWLBASE_RETRY_DELAY . "s before retry...");
                sleep(self::CRAWLBASE_RETRY_DELAY);
            }
        }

        // Return merged result if we have one, otherwise null
        return $mergedResult;
    }

    /**
     * Scrape with PA-API including retry logic
     * Retry up to 3 times with 2s delay between attempts
     *
     * @param string $asin Amazon product ASIN
     * @param int $startTime Start timestamp for timeout check
     * @return array|null Product data or null on failure
     */
    private function scrapeWithPaapiRetry(string $asin, int $startTime = 0): ?array
    {
        if (!$this->paapi) {
            return null;
        }

        if ($startTime === 0) {
            $startTime = time();
        }

        for ($attempt = 1; $attempt <= self::PAAPI_MAX_RETRIES; $attempt++) {
            // Check timeout
            if ($this->isTimedOut($startTime)) {
                $this->log("  PA-API: Timeout - aborting");
                return null;
            }

            $this->log("  PA-API attempt {$attempt}/" . self::PAAPI_MAX_RETRIES);
            $result = $this->paapi->fetch($asin);

            if ($result !== null) {
                $this->log("  PA-API: SUCCESS");
                return $result;
            }

            $error = $this->paapi->getLastError() ?? 'Unknown error';
            $this->log("  PA-API: FAILED - {$error}");

            // Wait before retry (except on last attempt)
            if ($attempt < self::PAAPI_MAX_RETRIES) {
                $this->log("  Waiting " . self::PAAPI_RETRY_DELAY . "s before retry...");
                sleep(self::PAAPI_RETRY_DELAY);
            }
        }

        return null;
    }

    /**
     * Add log entry
     */
    private function log(string $message): void
    {
        $timestamp = date('H:i:s');
        $this->scrapeLog[] = "[{$timestamp}] {$message}";
    }

    /**
     * Get scrape log
     */
    public function getScrapeLog(): array
    {
        return $this->scrapeLog;
    }

    /**
     * Scrape using Crawlbase provider directly with retry (bypasses settings)
     *
     * @param string $asin Amazon product ASIN
     * @param string $domain Amazon domain
     * @return array|null Product data or null on failure
     */
    public function scrapeWithCrawlbase(string $asin, string $domain = 'amazon.com'): ?array
    {
        if (!$this->crawlbase) {
            return null;
        }

        return $this->scrapeWithCrawlbaseRetry($asin, $domain, time());
    }

    /**
     * Scrape using PA-API provider directly with retry (bypasses settings)
     *
     * @param string $asin Amazon product ASIN
     * @return array|null Product data or null on failure
     */
    public function scrapeWithPaapi(string $asin): ?array
    {
        return $this->scrapeWithPaapiRetry($asin, time());
    }

    /**
     * Get last error message from scrape operation
     */
    public function getLastError(): ?string
    {
        return $this->lastError;
    }

    /**
     * Get the last successfully used provider name
     */
    public function getLastUsedProvider(): ?string
    {
        return $this->lastSuccessProvider;
    }

    /**
     * Check if Crawlbase is configured
     */
    public function isCrawlbaseConfigured(): bool
    {
        return $this->crawlbase !== null;
    }

    /**
     * Check if PA-API is configured
     */
    public function isPaapiConfigured(): bool
    {
        return $this->paapi !== null;
    }

    /**
     * Check if any provider is available
     */
    public function hasAnyProvider(): bool
    {
        return $this->isCrawlbaseConfigured() || $this->isPaapiConfigured();
    }

    /**
     * Alias for isPaapiConfigured
     */
    public function hasPaapi(): bool
    {
        return $this->isPaapiConfigured();
    }

    /**
     * Alias for isCrawlbaseConfigured
     */
    public function hasCrawlbase(): bool
    {
        return $this->isCrawlbaseConfigured();
    }

    /**
     * Search products using configured provider priority
     *
     * Flow (sequential):
     * 1. Try primary provider (with retries)
     * 2. If fail and fallback configured AND available, try fallback
     *
     * @param string $query Search query
     * @param string $domain Amazon domain
     * @return array|null Array of products or null on failure
     */
    public function searchProducts(string $query, string $domain = 'amazon.com'): ?array
    {
        return $this->searchProductsWithPage($query, $domain, 1);
    }

    /**
     * Search products with pagination support
     *
     * Flow (sequential):
     * 1. Try primary provider (with retries)
     * 2. If fail and fallback configured AND available, try fallback
     *
     * @param string $query Search query
     * @param string $domain Amazon domain
     * @param int $page Page number (1-based)
     * @return array|null Array of products or null on failure
     */
    public function searchProductsWithPage(string $query, string $domain = 'amazon.com', int $page = 1): ?array
    {
        $this->lastError = null;
        $startTime = time();

        // Get provider settings
        $settings = get_option('acms_general_settings', []);
        $primaryProvider = $settings['default_provider'] ?? 'crawlbase';
        $fallbackProvider = $settings['fallback_provider'] ?? 'none';

        // Check if primary provider is configured
        if (!$this->isProviderConfigured($primaryProvider)) {
            // If primary not configured but fallback is, use fallback as primary
            if ($fallbackProvider !== 'none' && $this->isProviderConfigured($fallbackProvider)) {
                $primaryProvider = $fallbackProvider;
                $fallbackProvider = 'none';
            } else {
                $this->lastError = "No provider configured";
                return null;
            }
        }

        // Try primary provider first
        $result = $this->searchWithProviderRetry($primaryProvider, $query, $domain, $startTime, $page);
        if ($result !== null) {
            $this->lastSuccessProvider = $primaryProvider;
            return $result;
        }

        // Check timeout before fallback
        if ($this->isTimedOut($startTime)) {
            $this->lastError = "Search timeout exceeded";
            return null;
        }

        // Try fallback if configured AND available
        if ($fallbackProvider !== 'none' && $this->isProviderConfigured($fallbackProvider)) {
            $result = $this->searchWithProviderRetry($fallbackProvider, $query, $domain, $startTime, $page);
            if ($result !== null) {
                $this->lastSuccessProvider = $fallbackProvider;
                return $result;
            }
        }

        $this->lastError = "Search failed for query: {$query}";
        return null;
    }

    /**
     * Search with specific provider (with retry)
     *
     * @param string $provider Provider name
     * @param string $query Search query
     * @param string $domain Amazon domain
     * @param int $startTime Start timestamp for timeout check
     * @param int $page Page number (1-based)
     * @return array|null Array of products or null on failure
     */
    private function searchWithProviderRetry(string $provider, string $query, string $domain, int $startTime, int $page = 1): ?array
    {
        if ($provider === self::PROVIDER_CRAWLBASE && $this->crawlbase) {
            // Crawlbase: 2 retries, 1s delay
            for ($attempt = 1; $attempt <= self::CRAWLBASE_MAX_RETRIES; $attempt++) {
                if ($this->isTimedOut($startTime)) {
                    return null;
                }

                $result = $this->crawlbase->search($query, $domain, $page);
                if ($result !== null) {
                    return $result;
                }

                if ($attempt < self::CRAWLBASE_MAX_RETRIES) {
                    sleep(self::CRAWLBASE_RETRY_DELAY);
                }
            }
            return null;
        }

        if ($provider === self::PROVIDER_PAAPI && $this->paapi) {
            // PA-API: 3 retries, 2s delay
            for ($attempt = 1; $attempt <= self::PAAPI_MAX_RETRIES; $attempt++) {
                if ($this->isTimedOut($startTime)) {
                    return null;
                }

                $result = $this->paapi->search($query, $page);
                if ($result !== null) {
                    return $result;
                }

                if ($attempt < self::PAAPI_MAX_RETRIES) {
                    sleep(self::PAAPI_RETRY_DELAY);
                }
            }
            return null;
        }

        return null;
    }

    /**
     * Get available providers list
     *
     * @return array List of available provider names
     */
    public function getAvailableProviders(): array
    {
        $providers = [];

        if ($this->isCrawlbaseConfigured()) {
            $providers[] = self::PROVIDER_CRAWLBASE;
        }

        if ($this->isPaapiConfigured()) {
            $providers[] = self::PROVIDER_PAAPI;
        }

        return $providers;
    }

    /**
     * Test Crawlbase connection
     *
     * @return array Test result with 'success' and 'message'
     */
    public function testCrawlbase(): array
    {
        if (!$this->crawlbase) {
            return [
                'success' => false,
                'message' => 'Crawlbase is not configured',
            ];
        }

        return $this->crawlbase->test();
    }

    /**
     * Test PA-API connection
     *
     * @return array Test result with 'success' and 'message'
     */
    public function testPaapi(): array
    {
        if (!$this->paapi) {
            return [
                'success' => false,
                'message' => 'PA-API is not configured',
            ];
        }

        return $this->paapi->test();
    }

    /**
     * Get Crawlbase token from wp_options
     *
     * @return string|null Token or null if not configured
     */
    private function getCrawlbaseToken(): ?string
    {
        $token = get_option(self::OPTION_CRAWLBASE_TOKEN, '');
        return !empty($token) ? $token : null;
    }

    /**
     * Get PA-API credentials from wp_options
     *
     * @return array|null Credentials array or null if not configured
     */
    private function getPaapiCredentials(): ?array
    {
        $json = get_option(self::OPTION_PAAPI_CREDENTIALS, '');
        if (empty($json)) {
            return null;
        }

        $credentials = is_string($json) ? json_decode($json, true) : $json;

        if (!is_array($credentials)) {
            return null;
        }

        // Validate required fields
        if (empty($credentials['access_key']) ||
            empty($credentials['secret_key']) ||
            empty($credentials['partner_tag'])) {
            return null;
        }

        return $credentials;
    }

    /**
     * Save Crawlbase token to wp_options
     *
     * @param string $token Crawlbase API token
     * @return bool Success
     */
    public function saveCrawlbaseToken(string $token): bool
    {
        $result = update_option(self::OPTION_CRAWLBASE_TOKEN, $token);

        // Reinitialize providers
        if ($result) {
            $this->crawlbase = !empty($token) ? new CrawlbaseProvider($token) : null;
        }

        return $result;
    }

    /**
     * Save PA-API credentials to wp_options
     *
     * @param array $credentials Array with access_key, secret_key, partner_tag, region
     * @return bool Success
     */
    public function savePaapiCredentials(array $credentials): bool
    {
        $result = update_option(self::OPTION_PAAPI_CREDENTIALS, wp_json_encode($credentials));

        // Reinitialize providers
        if ($result && !empty($credentials['access_key']) &&
            !empty($credentials['secret_key']) && !empty($credentials['partner_tag'])) {
            $this->paapi = new PaapiProvider(
                $credentials['access_key'],
                $credentials['secret_key'],
                $credentials['partner_tag'],
                $credentials['region'] ?? 'com'
            );
        }

        return $result;
    }

    /**
     * Get last error from Crawlbase provider
     */
    public function getCrawlbaseError(): ?string
    {
        return $this->crawlbase?->getLastError();
    }

    /**
     * Get last error from PA-API provider
     */
    public function getPaapiError(): ?string
    {
        return $this->paapi?->getLastError();
    }
}
