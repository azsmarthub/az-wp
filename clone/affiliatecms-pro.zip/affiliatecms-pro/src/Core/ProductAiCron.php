<?php
/**
 * Product AI Content Generation Cron Job
 *
 * Continuously finds products ready for AI content generation and processes them.
 * Runs every 10 minutes to find products with:
 * - status = 'scraped'
 * - ai_status = 'queued' (automatically set when scrape completes)
 *
 * This is part of the 3-tier AI generation system:
 * 1. ProductAiCron - Product content (custom_title, custom_description, pros/cons)
 * 2. PostAiCron - Review post generation from keywords
 * 3. CategoryAiCron - Category content generation
 *
 * Performance optimizations for large datasets (400k+ ASINs):
 * - Uses composite index (status, ai_status) for fast queries
 * - Processes in small batches (5 products per run)
 * - Uses LIMIT with ORDER BY for efficient pagination
 *
 * @package AffiliateCMS\Pro\Core
 * @see docs/ai-generation-architecture.md
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro\Core;

use AffiliateCMS\Pro\Repositories\ProductRepository;
use AffiliateCMS\Pro\Repositories\ProductLinkRepository;

class ProductAiCron
{
    /**
     * Hook name for the cron job
     */
    public const CRON_HOOK = 'acms_product_ai_generation';

    /**
     * Products to process per run
     */
    private const BATCH_SIZE = 10;

    /**
     * Singleton instance
     */
    private static ?ProductAiCron $instance = null;

    private ProductRepository $productRepo;

    /**
     * Get singleton instance
     */
    public static function instance(): ProductAiCron
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Private constructor for singleton
     */
    private function __construct()
    {
        $this->productRepo = ProductRepository::instance();
    }

    /**
     * Register the cron job
     */
    public function register(): void
    {
        add_action(self::CRON_HOOK, [$this, 'generateContent']);
        add_action('acms_ai_asin_enhanced', [self::class, 'handleAiResult'], 10, 2);

        // WP-Cron as safety net (server cron is primary)
        if (!wp_next_scheduled(self::CRON_HOOK)) {
            wp_schedule_event(time(), 'every_10_minutes', self::CRON_HOOK);
        }
    }

    /**
     * Default number of AI workers
     */
    private const DEFAULT_AI_WORKERS = 3;

    /**
     * Maximum number of AI workers (hard cap)
     */
    private const MAX_AI_WORKERS = 20;

    /**
     * Get configurable AI worker count.
     *
     * Adaptive strategy: when scrape queue is idle (no pending/scheduled/processing),
     * AI workers can borrow scrape worker slots up to scrape worker_count.
     * When scraping is active, use only the configured ai_worker_count.
     */
    public function getAiWorkerCount(): int
    {
        global $wpdb;

        $settings       = get_option('acms_automation', []);
        $aiCount        = (int) ($settings['ai_worker_count'] ?? self::DEFAULT_AI_WORKERS);
        $scrapeCount    = (int) ($settings['worker_count'] ?? 3);

        // Check if scrape queue is active
        $table = \AffiliateCMS\Pro\Database\Schema::productsTable();
        $activeScrape = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$table} WHERE status IN ('pending','scheduled','processing')"
        );

        if ($activeScrape === 0) {
            // Scrape workers are idle — AI can use the combined pool
            $effective = max($aiCount, min($scrapeCount, self::MAX_AI_WORKERS));
        } else {
            // Scraping is active — use only configured AI slots
            $effective = $aiCount;
        }

        return max(1, min(self::MAX_AI_WORKERS, $effective));
    }

    /**
     * Spawn parallel AI workers to process queued products
     *
     * Follows the same pattern as Bootstrap::spawnParallelWorkers() for scraping.
     * Each worker claims one product atomically, processes it, then self-spawns
     * the next worker — creating a continuous processing chain until queue is empty.
     *
     * Called from:
     * - onProductScraped() hook (after each scrape completes)
     * - generateContent() safety net (periodic sweep)
     * - Manual cron trigger
     *
     * @param int|null $count Number of workers to spawn (null = use setting)
     */
    public function spawnAiWorkers(?int $count = null): void
    {
        global $wpdb;

        $maxWorkers = $count ?? $this->getAiWorkerCount();
        $queued = $this->productRepo->countQueuedForAi();

        // Concurrency control: check how many are already generating
        $currentGenerating = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM " . \AffiliateCMS\Pro\Database\Schema::productsTable() .
            " WHERE ai_status = 'generating'"
        );
        $availableSlots = max(0, $maxWorkers - $currentGenerating);
        $workersToSpawn = min($availableSlots, $queued);

        if ($workersToSpawn <= 0) {
            return;
        }

        error_log("[ACMS AI] spawnAiWorkers: max={$maxWorkers}, generating={$currentGenerating}, queued={$queued}, spawning={$workersToSpawn}");

        for ($i = 0; $i < $workersToSpawn; $i++) {
            $this->spawnAiWorker();
        }
    }

    /**
     * Spawn a single AI worker via non-blocking HTTP request
     *
     * Mirrors Bootstrap::spawnWorker() pattern — fires and forgets.
     * The worker endpoint handles claiming, processing, and self-spawning.
     */
    private function spawnAiWorker(): void
    {
        $apiToken = get_option('acms_api_token', '');
        $endpoint = rest_url('acms/v1/cron/ai-worker');

        // blocking=true with short timeout: sends POST then times out.
        // Worker continues via ignore_user_abort(true).
        // CURLOPT_RESOLVE applied by Bootstrap::resolveLoopbackLocal().
        wp_remote_post($endpoint, [
            'timeout'   => 0.1,
            'blocking'  => true,
            'sslverify' => false,
            'headers'   => [
                'X-ACMS-Token' => $apiToken,
            ],
        ]);
    }

    /**
     * Process the next queued AI product (single worker execution)
     *
     * Called by the /cron/ai-worker REST endpoint. Each invocation:
     * 1. Atomically claims one product (claimQueuedAiProduct)
     * 2. Creates AI job
     * 3. Processes inline (OpenRouter API call, 10-30s)
     * 4. Marks result (generated/failed)
     * 5. If more queued → self-spawns next worker (chain continues)
     *
     * This creates a self-sustaining worker chain: each worker processes
     * exactly one product then spawns the next, preventing stuck workers
     * from blocking the entire queue.
     *
     * @return array Result with status info
     */
    public function processNextQueuedAi(): array
    {
        // Process exactly ONE product per request — prevents memory accumulation.
        // Self-chaining pattern: after processing, spawn next worker if queue remains.
        ignore_user_abort(true);
        @set_time_limit(120);
        @ini_set('max_execution_time', '120');

        $maxWorkers = $this->getAiWorkerCount();

        // Concurrency guard: check generating count
        global $wpdb;
        $currentGenerating = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM " . \AffiliateCMS\Pro\Database\Schema::productsTable() .
            " WHERE ai_status = 'generating'"
        );
        if ($currentGenerating >= $maxWorkers) {
            return ['status' => 'concurrency_limit', 'message' => "Already {$currentGenerating} workers generating"];
        }

        // Claim exactly ONE product
        $product = $this->productRepo->claimQueuedAiProduct();
        if (!$product) {
            return ['status' => 'idle', 'message' => 'No products queued for AI'];
        }

        $startTime = time();

        // Check if AI plugin is active
        if (!$this->isAiPluginActive()) {
            $this->productRepo->update($product->id, [
                'ai_status' => 'generated',
                'ai_generated_at' => current_time('mysql'),
                'ai_error_message' => 'AI plugin not active - skipped',
            ]);
            $this->spawnNextIfNeeded();
            return ['status' => 'skipped', 'asin' => $product->asin, 'reason' => 'AI plugin not active'];
        }

        // Create AI job
        $result = $this->createAiJob($product);

        if (is_string($result)) {
            error_log("[ACMS AI Worker] Job creation FAILED for ASIN {$product->asin}: {$result}");
            $this->productRepo->update($product->id, [
                'ai_status' => 'failed',
                'ai_error_message' => $result,
            ]);
            $this->spawnNextIfNeeded();
            return ['status' => 'failed', 'asin' => $product->asin, 'error' => $result];
        }

        if ($result === 0) {
            error_log("[ACMS AI Worker] Duplicate job for ASIN {$product->asin}, skipping");
            $this->spawnNextIfNeeded();
            return ['status' => 'duplicate', 'asin' => $product->asin];
        }

        // Process inline (AI API call, 10-30s)
        $this->processJobInline($result);

        // Spawn next worker AFTER processing completes (self-chaining)
        $this->spawnNextIfNeeded();

        $duration = time() - $startTime;
        error_log("[ACMS AI Worker] Processed ASIN {$product->asin} in {$duration}s");
        return ['status' => 'processed', 'processed' => 1, 'last_asin' => $product->asin];
    }

    /**
     * Spawn next AI worker if more products are queued
     *
     * Called at the end of each worker execution to maintain the processing chain.
     * Only spawns one worker — each worker handles exactly one product.
     */
    private function spawnNextIfNeeded(): void
    {
        global $wpdb;

        $remaining = $this->productRepo->countQueuedForAi();
        if ($remaining <= 0) {
            return;
        }

        // Concurrency guard: don't spawn if already at max generating
        $maxWorkers = $this->getAiWorkerCount();
        $currentGenerating = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM " . \AffiliateCMS\Pro\Database\Schema::productsTable() .
            " WHERE ai_status = 'generating'"
        );

        if ($currentGenerating < $maxWorkers) {
            $this->spawnAiWorker();
        }
    }

    /**
     * Reset products stuck in 'generating' status for too long
     *
     * When FPM kills a worker (request_terminate_timeout=300s) or OpenRouter
     * API credit runs out, products stay in 'generating' forever.
     * This resets them back to 'queued' so workers can retry.
     *
     * Threshold: 10 minutes (AI calls typically take 10-30s, max 5 min)
     *
     * @return int Number of products reset
     */
    public function resetStuckGenerating(): int
    {
        global $wpdb;
        $table = \AffiliateCMS\Pro\Database\Schema::productsTable();

        // updated_at is set when product is claimed (ai_status → generating)
        // Uses gmdate() with current_time('timestamp') to avoid double timezone offset
        $threshold = gmdate('Y-m-d H:i:s', current_time('timestamp') - 600); // 10 minutes ago

        $reset = (int) $wpdb->query($wpdb->prepare(
            "UPDATE {$table}
             SET ai_status = 'queued', ai_error_message = 'Reset: stuck in generating >10min'
             WHERE ai_status = 'generating' AND updated_at < %s",
            $threshold
        ));

        if ($reset > 0) {
            error_log("[ACMS ProductAiCron] Reset {$reset} products stuck in 'generating' (threshold: {$threshold})");
        }

        return $reset;
    }

    /**
     * Generate AI content for products that need it (safety net)
     *
     * This is now a lightweight dispatcher that spawns AI workers.
     * No longer processes inline — workers handle everything.
     *
     * Runs periodically to:
     * 1. Reset stuck generating products (FPM killed workers, API timeout, etc.)
     * 2. Backfill retail links for enhanced products
     * 3. Spawn AI workers for any queued products (catches products
     *    missed by the immediate scrape → worker trigger)
     */
    public function generateContent(): void
    {
        // Reset products stuck in 'generating' for >10 minutes
        $this->resetStuckGenerating();

        // Backfill retail search links for enhanced products that don't have them yet
        self::backfillRetailLinks();

        // Spawn AI workers for any queued products
        // This catches products missed by the immediate trigger (hook didn't fire, etc.)
        $queued = $this->productRepo->countQueuedForAi();

        if ($queued === 0) {
            return;
        }

        error_log("[ACMS ProductAiCron] Spawning workers for {$queued} queued products");
        $this->spawnAiWorkers();
    }

    /**
     * Process a job inline using JobProcessor (same as AS handler but synchronous)
     *
     * Uses atomic claim (UPDATE WHERE status=pending) to prevent double-processing
     * if AS runner also picks up the same job concurrently.
     */
    private function processJobInline(int $jobId): void
    {
        if (!class_exists(\AffiliateCMS\AI\Core\JobProcessor::class)) {
            error_log("[ACMS ProductAiCron] JobProcessor class not available, skipping inline for job #{$jobId}");
            return;
        }

        global $wpdb;
        $table = $wpdb->prefix . 'acms_ai_jobs';

        // Atomic claim — prevents race condition if multiple cron triggers overlap
        $claimed = $wpdb->query($wpdb->prepare(
            "UPDATE {$table} SET status = 'processing', processing_at = %s
             WHERE id = %d AND status = 'pending'",
            current_time('mysql'),
            $jobId
        ));

        if ($claimed === 0) {
            error_log("[ACMS ProductAiCron] Job #{$jobId} already claimed by AS runner, skipping inline");
            return;
        }

        try {
            $job = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$table} WHERE id = %d",
                $jobId
            ), ARRAY_A);

            if (!$job) {
                error_log("[ACMS ProductAiCron] Job #{$jobId} not found after claim");
                return;
            }

            $processor = new \AffiliateCMS\AI\Core\JobProcessor();
            $processor->processSingleJob($job);
        } catch (\Throwable $e) {
            error_log("[ACMS ProductAiCron] Inline processing failed for job #{$jobId}: " . $e->getMessage());

            // Mark failed — resetStuckProducts() will retry next cycle
            $wpdb->update($table, [
                'status' => 'failed',
                'error_message' => 'Inline error: ' . substr($e->getMessage(), 0, 500),
            ], ['id' => $jobId]);

            $this->productRepo->update(
                (int) ($job['target_id'] ?? 0),
                ['ai_status' => 'failed', 'ai_error_message' => substr($e->getMessage(), 0, 500)]
            );
        }
    }

    /**
     * Check if AI plugin is active
     */
    private function isAiPluginActive(): bool
    {
        global $wpdb;
        $table = $wpdb->prefix . 'acms_ai_jobs';

        // Check if table exists
        $tableExists = $wpdb->get_var(
            $wpdb->prepare("SHOW TABLES LIKE %s", $table)
        );

        return $tableExists === $table;
    }

    /**
     * Create an AI job for product enhancement
     *
     * @return int|string Job ID on success, error string on failure, 0 if duplicate exists
     */
    private function createAiJob(\AffiliateCMS\Pro\Models\Product $product): int|string
    {
        global $wpdb;
        $table = $wpdb->prefix . 'acms_ai_jobs';

        // Check for existing pending/processing job for this ASIN
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$table}
             WHERE type = 'enhance_asin' AND target_id = %s AND status IN ('pending', 'processing')
             LIMIT 1",
            $product->asin
        ));

        if ($existing) {
            error_log("[ACMS ProductAiCron] Duplicate job exists for ASIN {$product->asin} (job #{$existing}), skipping");
            return 0; // Not an error, job already exists
        }

        // Check if API key is configured BEFORE creating the job
        $apiKey = get_option('acms_ai_api_key', '');
        if (empty($apiKey)) {
            return 'OpenRouter API key not configured (acms_ai_api_key is empty)';
        }

        // Prepare input data for AI with all available product fields
        $inputData = [
            // Basic info
            'asin' => $product->asin,
            'product_id' => $product->id,
            'title' => $product->title,
            'brand' => $product->brand,
            'category' => $product->category,
            'category_path' => $product->categoryPath ?? '',
            // Pricing
            'price' => $product->price,
            'original_price' => $product->originalPrice ?? null,
            'currency' => $product->currency ?? 'USD',
            // Availability
            'in_stock' => $product->inStock ?? true,
            'is_prime' => $product->isPrime ?? false,
            // Ratings
            'rating' => $product->rating,
            'reviews_count' => $product->reviewsCount,
            'score' => $product->score ?? null,
            // Content
            'description' => $product->description,
            'features' => $product->features ?? [],
            // Details
            'specifications' => $product->specifications ?? null,
            'product_information' => $product->productInformation ?? null,
            'best_sellers_rank' => $product->bestSellersRank ?? null,
            // Reviews
            'top_reviews' => $product->topReviews ?? null,
            'reviews_summary' => $product->reviewsSummary ?? null,
            // Seller
            'seller_info' => $product->sellerInfo ?? null,
            // Media
            'image_url' => $product->imageUrl ?? '',
            'images_gallery' => $product->imagesGallery ?? null,
        ];

        // Sanitize input data to ensure valid UTF-8
        $inputData = $this->sanitizeForJson($inputData);

        // Try encoding with ignore flag for invalid chars (PHP 7.2+)
        $encodedInput = wp_json_encode($inputData, JSON_INVALID_UTF8_IGNORE);
        
        if ($encodedInput === false) {
            $err = 'wp_json_encode failed: ' . json_last_error_msg();
            error_log("[ACMS ProductAiCron] {$err} for ASIN {$product->asin}");
            
            // Try one more time with aggressive cleaning if first attempt failed
            $inputData = $this->sanitizeForJson($inputData, true);
            $encodedInput = wp_json_encode($inputData, JSON_INVALID_UTF8_IGNORE);
            
            if ($encodedInput === false) {
                 return 'JSON encoding failed even after sanitization: ' . json_last_error_msg();
            }
        }

        $result = $wpdb->insert($table, [
            'type' => 'enhance_asin',
            'target_type' => 'asin',
            'target_id' => $product->asin,
            'input_data' => $encodedInput,
            'status' => 'pending',
            'priority' => 30,
            'max_attempts' => 3,
            'created_at' => current_time('mysql'),
        ]);

        if ($result === false) {
            $err = 'DB insert failed: ' . $wpdb->last_error;
            error_log("[ACMS ProductAiCron] {$err} for ASIN {$product->asin}");
            return $err;
        }

        $jobId = (int) $wpdb->insert_id;

        return $jobId;
    }

    /**
     * Recursively sanitize data for JSON encoding
     * 
     * @param mixed $data Data to sanitize
     * @param bool $aggressive If true, strips invalid characters instead of just converting
     * @return mixed Sanitized data
     */
    private function sanitizeForJson($data, bool $aggressive = false)
    {
        if (is_string($data)) {
            // Ensure valid UTF-8
            if ($aggressive) {
                // Strip invalid characters
                return mb_convert_encoding($data, 'UTF-8', 'UTF-8');
            } else {
                // Determine encoding and convert
                $encoding = mb_detect_encoding($data, 'UTF-8, ISO-8859-1, WINDOWS-1252', true);
                return $encoding ? mb_convert_encoding($data, 'UTF-8', $encoding) : mb_convert_encoding($data, 'UTF-8');
            }
        }

        if (is_array($data)) {
            $sanitized = [];
            foreach ($data as $key => $value) {
                $sanitized[$key] = $this->sanitizeForJson($value, $aggressive);
            }
            return $sanitized;
        }

        if (is_object($data)) {
            // Convert objects to arrays for sanitization
            return $this->sanitizeForJson((array) $data, $aggressive);
        }

        return $data;
    }

    /**
     * Handle AI job result (called via action hook from AI plugin)
     *
     * Maps AI output to product custom_* fields:
     * - custom_title: Enhanced product title
     * - short_review → ai_short_review: Concise product review
     * - search_keyword → BestBuy/Walmart search links (acms_product_links)
     * - selling_points → custom_features: Enhanced feature bullets
     * - pros → custom_pros: Product advantages
     * - cons → custom_cons: Product drawbacks
     * - custom_tabs: Optional additional content sections
     *
     * @param string $asin Product ASIN
     * @param array $result AI generation result
     */
    public static function handleAiResult(string $asin, array $result): void
    {
        $repo = ProductRepository::instance();
        $product = $repo->findByAsin($asin);

        if (!$product) {
            error_log("[ACMS ProductAiCron] Product not found for ASIN: {$asin}");
            return;
        }

        // Extract AI-generated content
        $updateData = [
            'ai_status' => 'generated',
            'ai_generated_at' => current_time('mysql'),
            'ai_error_message' => null,
        ];

        // Save generation_id from OpenRouter for tracking
        if (!empty($result['_generation_id'])) {
            $updateData['ai_generation_id'] = sanitize_text_field($result['_generation_id']);
        }

        // Custom Title
        if (!empty($result['custom_title'])) {
            $updateData['custom_title'] = sanitize_text_field($result['custom_title']);
        }

        // Short Review (ai_short_review is unique to AI)
        if (!empty($result['short_review'])) {
            $updateData['ai_short_review'] = wp_kses_post($result['short_review']);
        } elseif (!empty($result['summary'])) {
            $updateData['ai_short_review'] = wp_kses_post($result['summary']);
        }

        // Selling Points → Custom Features
        if (!empty($result['selling_points']) && is_array($result['selling_points'])) {
            $updateData['custom_features'] = wp_json_encode(
                array_map('sanitize_text_field', $result['selling_points'])
            );
        }

        // Pros → Custom Pros
        if (!empty($result['pros']) && is_array($result['pros'])) {
            $updateData['custom_pros'] = wp_json_encode(
                array_map('sanitize_text_field', $result['pros'])
            );
        }

        // Cons → Custom Cons
        if (!empty($result['cons']) && is_array($result['cons'])) {
            $updateData['custom_cons'] = wp_json_encode(
                array_map('sanitize_text_field', $result['cons'])
            );
        }

        // Custom Tabs (optional - only if explicitly provided and not null)
        if (isset($result['custom_tabs']) && is_array($result['custom_tabs']) && !empty($result['custom_tabs'])) {
            // Sanitize each tab
            $sanitizedTabs = array_map(function ($tab) {
                return [
                    'title' => sanitize_text_field($tab['title'] ?? ''),
                    'content' => wp_kses_post($tab['content'] ?? ''),
                    'icon' => sanitize_text_field($tab['icon'] ?? 'bi-card-text'),
                ];
            }, $result['custom_tabs']);
            $updateData['custom_tabs'] = wp_json_encode($sanitizedTabs);
        }

        $repo->update($product->id, $updateData);

        // Create BestBuy/Walmart search links
        // Use AI-extracted keyword if available, otherwise extract from product title
        $searchKeyword = !empty($result['search_keyword'])
            ? sanitize_text_field($result['search_keyword'])
            : self::extractSearchKeyword($product->title ?? '');

        if (!empty($searchKeyword)) {
            self::createRetailSearchLinks($product->id, $searchKeyword);
        }

        if (defined('WP_DEBUG') && WP_DEBUG) {
            $fieldsUpdated = array_keys($updateData);
            error_log("[ACMS ProductAiCron] AI result applied to product {$asin}. Fields: " . implode(', ', $fieldsUpdated));
        }
    }

    /**
     * Extract a search-friendly keyword from product title (PHP fallback)
     *
     * Takes the meaningful part of a long Amazon title and converts it
     * to a URL-ready search keyword with + separators.
     *
     * Strategy:
     * 1. Split on " - " or " | " (Amazon titles use these to separate marketing fluff)
     * 2. Take the first part (brand + model + key specs)
     * 3. Remove parenthetical text like "(Renewed)" or "(Pack of 2)"
     * 4. Trim to reasonable length (~12 words max)
     * 5. Replace spaces with +
     *
     * @param string $title Product title
     * @return string Search keyword with + separators
     */
    private static function extractSearchKeyword(string $title): string
    {
        if (empty($title)) {
            return '';
        }

        // Split on common Amazon title delimiters
        // " - " and " | " usually separate main info from marketing text
        $parts = preg_split('/\s+[-|]\s+/', $title, 2);
        $main = trim($parts[0] ?? $title);

        // Also split on " , " after the first comma-separated spec group
        // e.g. "Brand Model, Spec1, Spec2, Color Name" → keep up to ~3 comma segments
        $commaSegments = explode(',', $main);
        if (count($commaSegments) > 4) {
            $main = implode(',', array_slice($commaSegments, 0, 4));
        }

        // Remove parenthetical text: (Renewed), (Pack of 2), etc.
        $main = preg_replace('/\s*\([^)]*\)\s*/', ' ', $main);

        // Remove common trailing descriptors/colors
        $main = preg_replace('/\b(Black|White|Silver|Gray|Grey|Blue|Red|Green|Gold|Pink|Purple|Rose Gold|Space Gray)\s*$/i', '', $main);

        // Clean up
        $main = trim($main, " ,\t\n\r");

        // Limit to ~12 words (enough for specific search, not too long)
        $words = preg_split('/\s+/', $main);
        if (count($words) > 12) {
            $words = array_slice($words, 0, 12);
        }

        // Join with + for URL search parameter
        return implode('+', $words);
    }

    /**
     * Create BestBuy and Walmart search links from AI-extracted keyword
     *
     * Only creates links if they don't already exist for this product+provider.
     * Uses search URLs so users land on the retailer's search results page.
     *
     * @param int $productId Product ID
     * @param string $keyword Search keyword with + separators (e.g., "gaming+pc+RTX+3060")
     */
    private static function createRetailSearchLinks(int $productId, string $keyword): void
    {
        $linkRepo = ProductLinkRepository::instance();
        $existingLinks = $linkRepo->getByProductId($productId);

        // Build lookup of existing providers
        $existingProviders = [];
        foreach ($existingLinks as $link) {
            $existingProviders[$link->provider] = true;
        }

        $linksToCreate = [
            [
                'provider' => 'bestbuy',
                'provider_name' => 'Best Buy',
                'url' => 'https://www.bestbuy.com/site/searchpage.jsp?st=' . $keyword,
            ],
            [
                'provider' => 'walmart',
                'provider_name' => 'Walmart',
                'url' => 'https://www.walmart.com/search?q=' . $keyword,
            ],
        ];

        $created = 0;
        foreach ($linksToCreate as $idx => $linkDef) {
            // Skip if this provider already has a link for this product
            if (isset($existingProviders[$linkDef['provider']])) {
                continue;
            }

            $linkRepo->create([
                'product_id' => $productId,
                'provider' => $linkDef['provider'],
                'provider_name' => $linkDef['provider_name'],
                'affiliate_url' => $linkDef['url'],
                'is_primary' => 0,
                'sort_order' => $idx + 1,
            ]);
            $created++;
        }

        if ($created > 0 && defined('WP_DEBUG') && WP_DEBUG) {
            error_log("[ACMS ProductAiCron] Created {$created} retail search links for product {$productId}: {$keyword}");
        }
    }

    /**
     * Backfill retail search links for already-enhanced products
     *
     * Finds products with ai_status='generated' that have NO entries in
     * acms_product_links, and creates BestBuy/Walmart search links using
     * the PHP keyword extraction fallback.
     *
     * Processes up to 20 products per run to avoid blocking.
     */
    private static function backfillRetailLinks(): void
    {
        global $wpdb;

        $products_table = $wpdb->prefix . 'acms_products';
        $links_table = $wpdb->prefix . 'acms_product_links';

        // Find enhanced products that have zero entries in product_links
        $products = $wpdb->get_results(
            "SELECT p.id, p.title
             FROM {$products_table} p
             LEFT JOIN {$links_table} pl ON p.id = pl.product_id
             WHERE p.status = 'scraped'
               AND p.ai_status = 'generated'
               AND pl.id IS NULL
             ORDER BY p.id ASC
             LIMIT 20"
        );

        if (empty($products)) {
            return;
        }

        $count = 0;
        foreach ($products as $p) {
            $keyword = self::extractSearchKeyword($p->title ?? '');
            if (!empty($keyword)) {
                self::createRetailSearchLinks((int) $p->id, $keyword);
                $count++;
            }
        }

        if ($count > 0 && defined('WP_DEBUG') && WP_DEBUG) {
            error_log("[ACMS ProductAiCron] Backfilled retail links for {$count} products");
        }
    }

    /**
     * Unschedule the cron job
     */
    public function unschedule(): void
    {
        $timestamp = wp_next_scheduled(self::CRON_HOOK);
        if ($timestamp) {
            wp_unschedule_event($timestamp, self::CRON_HOOK);
        }
    }

    /**
     * Run the generation manually (for testing or manual trigger)
     *
     * Spawns AI workers to process queued products.
     *
     * @return array Result with count of processed products
     */
    public function runManually(): array
    {
        $startTime = microtime(true);

        // Reset products stuck in 'generating' for >10 minutes
        $stuckReset = $this->resetStuckGenerating();

        // Backfill retail links
        self::backfillRetailLinks();

        // Count queued and spawn workers (includes freshly-reset products)
        $queued = $this->productRepo->countQueuedForAi();

        if ($queued > 0) {
            $this->spawnAiWorkers();
        }

        $duration = round((microtime(true) - $startTime) * 1000);

        return [
            'success' => true,
            'message' => $queued > 0
                ? "Spawned AI workers for {$queued} queued products"
                : 'No products queued for AI',
            'duration_ms' => $duration,
            'queued' => $queued,
            'stuck_reset' => $stuckReset,
            'workers' => $queued > 0 ? min($this->getAiWorkerCount(), $queued) : 0,
        ];
    }

    /**
     * Get next scheduled run time
     *
     * @return int|false Unix timestamp or false if not scheduled
     */
    public function getNextRun()
    {
        return wp_next_scheduled(self::CRON_HOOK);
    }

    /**
     * Get statistics about products needing AI content
     *
     * @return array Statistics
     */
    public function getStats(): array
    {
        global $wpdb;
        $table = $this->productRepo->getTable();

        // Count scraped products pending AI (includes legacy 'not_generated' and new 'queued')
        $pending = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$table}
             WHERE status = 'scraped'
             AND (ai_status IS NULL OR ai_status = 'not_generated' OR ai_status = 'queued')"
        );

        $queued = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$table}
             WHERE status = 'scraped' AND ai_status = 'queued'"
        );

        $generating = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$table} WHERE ai_status = 'generating'"
        );

        $generated = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$table} WHERE ai_status = 'generated'"
        );

        $failed = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$table} WHERE ai_status = 'failed'"
        );

        return [
            'pending' => (int) $pending, // Total waiting for AI (queued + legacy not_generated)
            'queued' => (int) $queued,   // Ready for AI processing
            'generating' => (int) $generating,
            'generated' => (int) $generated,
            'failed' => (int) $failed,
            'total_scraped' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE status = 'scraped'"),
            'next_run' => $this->getNextRun(),
            'ai_worker_count' => $this->getAiWorkerCount(),
            'claimable' => $this->productRepo->countQueuedForAi(),
        ];
    }
}
