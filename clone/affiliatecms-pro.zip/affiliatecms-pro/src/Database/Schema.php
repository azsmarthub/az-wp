<?php
/**
 * Database Schema Management for AffiliateCMS Pro
 *
 * Handles creation and management of plugin database tables
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro\Database;

class Schema
{
    private static ?Schema $instance = null;

    /**
     * Get singleton instance
     */
    public static function instance(): Schema
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Get products table name
     */
    public static function productsTable(): string
    {
        global $wpdb;
        return $wpdb->prefix . 'acms_products';
    }

    /**
     * Get queue table name
     */
    public static function queueTable(): string
    {
        global $wpdb;
        return $wpdb->prefix . 'acms_queue';
    }

    /**
     * Get product links table name
     */
    public static function productLinksTable(): string
    {
        global $wpdb;
        return $wpdb->prefix . 'acms_product_links';
    }

    /**
     * Get brands table name
     */
    public static function brandsTable(): string
    {
        global $wpdb;
        return $wpdb->prefix . 'acms_brands';
    }

    /**
     * Get cache URLs table name
     */
    public static function cacheUrlsTable(): string
    {
        global $wpdb;
        return $wpdb->prefix . 'acms_cache_urls';
    }

    /**
     * Check if the core Pro tables exist
     */
    public static function tablesExist(): bool
    {
        global $wpdb;
        $table = $wpdb->prefix . 'acms_products';
        return $wpdb->get_var("SHOW TABLES LIKE '{$table}'") === $table;
    }

    /**
     * Get current database version
     */
    public function getVersion(): string
    {
        return get_option('acms_db_version', '0');
    }

    /**
     * Check if database upgrade is needed
     */
    public function needsUpgrade(): bool
    {
        $currentVersion = $this->getVersion();
        return version_compare($currentVersion, ACMS_VERSION, '<');
    }

    /**
     * Install database tables
     */
    public function install(): void
    {
        global $wpdb;

        $charsetCollate = $wpdb->get_charset_collate();

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        // Products table
        $productsTable = self::productsTable();
        $sql = "CREATE TABLE {$productsTable} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            asin VARCHAR(20) NOT NULL,
            title VARCHAR(500) DEFAULT '',
            brand VARCHAR(255) DEFAULT '',
            brand_term_id BIGINT UNSIGNED DEFAULT NULL,
            price DECIMAL(10,2) DEFAULT NULL,
            original_price DECIMAL(10,2) DEFAULT NULL,
            currency VARCHAR(10) DEFAULT 'USD',
            rating DECIMAL(2,1) DEFAULT NULL,
            reviews_count INT UNSIGNED DEFAULT 0,
            score TINYINT UNSIGNED DEFAULT 70,
            in_stock TINYINT(1) DEFAULT 1,
            is_prime TINYINT(1) DEFAULT 0,
            image_url VARCHAR(1000) DEFAULT '',
            images_gallery JSON DEFAULT NULL,
            description LONGTEXT DEFAULT NULL,
            features JSON DEFAULT NULL,
            category VARCHAR(255) DEFAULT '',
            category_path VARCHAR(500) DEFAULT '',
            custom_category_paths JSON DEFAULT NULL,
            product_information JSON DEFAULT NULL,
            specifications JSON DEFAULT NULL,
            best_sellers_rank VARCHAR(500) DEFAULT NULL,
            seller_info JSON DEFAULT NULL,
            reviews_data JSON DEFAULT NULL,
            top_reviews JSON DEFAULT NULL,
            reviews_summary JSON DEFAULT NULL,
            custom_title VARCHAR(500) DEFAULT NULL,
            custom_description TEXT DEFAULT NULL,
            custom_features JSON DEFAULT NULL,
            custom_pros JSON DEFAULT NULL,
            custom_cons JSON DEFAULT NULL,
            custom_tabs JSON DEFAULT NULL,
            status ENUM('pending', 'scheduled', 'processing', 'scraped', 'failed', 'update', 'updating') DEFAULT 'pending',
            last_provider VARCHAR(50) DEFAULT NULL,
            last_scraped_at DATETIME DEFAULT NULL,
            error_message TEXT DEFAULT NULL,
            scrape_log LONGTEXT DEFAULT NULL,
            quick_update_at DATETIME DEFAULT NULL,
            quick_update_count INT UNSIGNED DEFAULT 0,
            ai_status ENUM('not_generated', 'queued', 'generating', 'generated', 'failed') DEFAULT NULL,
            ai_generated_at DATETIME DEFAULT NULL,
            ai_error_message TEXT DEFAULT NULL,
            ai_features JSON DEFAULT NULL,
            ai_short_review TEXT DEFAULT NULL,
            ai_description TEXT DEFAULT NULL,
            ai_generation_id VARCHAR(100) DEFAULT NULL,
            source_post_id BIGINT UNSIGNED DEFAULT NULL,
            post_ids TEXT DEFAULT NULL,
            post_count INT UNSIGNED DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY asin (asin),
            KEY status (status),
            KEY last_scraped_at (last_scraped_at),
            KEY brand (brand(191)),
            KEY brand_term_id (brand_term_id),
            KEY category (category(191)),
            KEY ai_status (ai_status),
            KEY status_ai_status (status, ai_status),
            KEY ai_generated_at (ai_generated_at),
            KEY post_count (post_count),
            KEY in_stock (in_stock)
        ) ENGINE=InnoDB {$charsetCollate};";

        dbDelta($sql);

        // Queue table (for auto content keywords)
        $queueTable = self::queueTable();
        $sql = "CREATE TABLE {$queueTable} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            keyword VARCHAR(500) NOT NULL,
            post_type VARCHAR(50) DEFAULT 'acms_reviews',
            category_id BIGINT UNSIGNED DEFAULT NULL,
            brand_id BIGINT UNSIGNED DEFAULT NULL,
            tags VARCHAR(500) DEFAULT NULL,
            template VARCHAR(100) DEFAULT 'default',
            content_settings JSON DEFAULT NULL,
            status ENUM('pending', 'processing', 'completed', 'failed', 'paused') DEFAULT 'pending',
            priority INT DEFAULT 0,
            attempts INT UNSIGNED DEFAULT 0,
            max_attempts INT UNSIGNED DEFAULT 3,
            generated_post_id BIGINT UNSIGNED DEFAULT NULL,
            error_message TEXT DEFAULT NULL,
            processing_log JSON DEFAULT NULL,
            auto_search_asins TINYINT(1) DEFAULT 0,
            search_limit INT DEFAULT 15,
            linked_asins JSON DEFAULT NULL,
            search_results_count INT DEFAULT 0,
            search_provider VARCHAR(50) DEFAULT NULL,
            searched_at DATETIME DEFAULT NULL,
            ai_post_status ENUM('not_generated', 'queued', 'generating', 'generated', 'failed') DEFAULT NULL,
            ai_post_generating_at DATETIME DEFAULT NULL,
            ai_post_generated_at DATETIME DEFAULT NULL,
            ai_post_id BIGINT UNSIGNED DEFAULT NULL,
            ai_post_error TEXT DEFAULT NULL,
            scheduled_at DATETIME DEFAULT NULL,
            started_at DATETIME DEFAULT NULL,
            completed_at DATETIME DEFAULT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY status (status),
            KEY priority (priority),
            KEY post_type (post_type),
            KEY scheduled_at (scheduled_at),
            KEY created_at (created_at),
            KEY ai_post_status (ai_post_status),
            KEY status_ai_post (status, ai_post_status)
        ) ENGINE=InnoDB {$charsetCollate};";

        dbDelta($sql);

        // Product links table (affiliate links from various providers)
        $productLinksTable = self::productLinksTable();
        $sql = "CREATE TABLE {$productLinksTable} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            product_id BIGINT UNSIGNED NOT NULL,
            provider VARCHAR(100) NOT NULL,
            provider_name VARCHAR(100) NOT NULL,
            affiliate_url VARCHAR(1000) NOT NULL,
            price DECIMAL(10,2) DEFAULT NULL,
            currency VARCHAR(10) DEFAULT 'USD',
            in_stock TINYINT(1) DEFAULT NULL,
            is_primary TINYINT(1) DEFAULT 0,
            sort_order INT DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY product_id (product_id),
            KEY provider (provider),
            KEY is_primary (is_primary),
            KEY sort_order (sort_order)
        ) ENGINE=InnoDB {$charsetCollate};";

        dbDelta($sql);

        // Brands table (SEO brand pages)
        $brandsTable = self::brandsTable();
        $sql = "CREATE TABLE {$brandsTable} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            term_id BIGINT UNSIGNED DEFAULT NULL,
            name VARCHAR(255) NOT NULL,
            slug VARCHAR(255) NOT NULL,
            description TEXT DEFAULT NULL,
            logo_url VARCHAR(1000) DEFAULT NULL,
            banner_url VARCHAR(1000) DEFAULT NULL,
            website_url VARCHAR(500) DEFAULT NULL,
            seo_title VARCHAR(255) DEFAULT NULL,
            seo_description TEXT DEFAULT NULL,
            seo_keywords VARCHAR(500) DEFAULT NULL,
            content_intro TEXT DEFAULT NULL,
            content_main LONGTEXT DEFAULT NULL,
            content_faq JSON DEFAULT NULL,
            content_status ENUM('empty', 'ai_generating', 'ai_generated', 'manual', 'template') DEFAULT 'empty',
            content_updated_at DATETIME DEFAULT NULL,
            ai_generating_at DATETIME DEFAULT NULL,
            ai_error_message TEXT DEFAULT NULL,
            product_count INT UNSIGNED DEFAULT 0,
            status ENUM('publish', 'draft') DEFAULT 'draft',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY name (name(191)),
            UNIQUE KEY slug (slug(191)),
            KEY term_id (term_id),
            KEY content_status (content_status),
            KEY status (status),
            KEY product_count (product_count)
        ) ENGINE=InnoDB {$charsetCollate};";

        dbDelta($sql);

        // Cache URLs table (preload queue with per-URL tracking)
        $cacheUrlsTable = self::cacheUrlsTable();
        $sql = "CREATE TABLE {$cacheUrlsTable} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            url VARCHAR(2048) NOT NULL,
            url_type ENUM('homepage','post','page','category','archive','other') DEFAULT 'other',
            status ENUM('pending','cached','failed','timeout','skipped') DEFAULT 'pending',
            priority TINYINT UNSIGNED DEFAULT 50,
            http_code SMALLINT UNSIGNED DEFAULT NULL,
            response_time_ms INT UNSIGNED DEFAULT NULL,
            attempts TINYINT UNSIGNED DEFAULT 0,
            last_warmed_at DATETIME DEFAULT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY url_hash (url(191)),
            KEY status_priority (status, priority DESC),
            KEY url_type (url_type),
            KEY status (status)
        ) ENGINE=InnoDB {$charsetCollate};";

        dbDelta($sql);

        // Run migrations for existing installations
        $this->runMigrations();

        // Update database version
        update_option('acms_db_version', ACMS_VERSION);
    }

    /**
     * Run database migrations for upgrades
     */
    private function runMigrations(): void
    {
        global $wpdb;

        $productsTable = self::productsTable();

        // Migration: Add score column if it doesn't exist
        $column = $wpdb->get_results($wpdb->prepare(
            "SHOW COLUMNS FROM `{$productsTable}` LIKE %s",
            'score'
        ));

        if (empty($column)) {
            $wpdb->query(
                "ALTER TABLE `{$productsTable}`
                 ADD COLUMN `score` TINYINT UNSIGNED DEFAULT 75
                 AFTER `reviews_count`"
            );

            // Calculate scores for existing products
            $this->recalculateAllScores();
        }

        // Migration: Add 'scheduled' to status ENUM if not exists
        $this->migrateStatusEnum();

        // Migration: Add custom_tabs column if it doesn't exist
        $column = $wpdb->get_results($wpdb->prepare(
            "SHOW COLUMNS FROM `{$productsTable}` LIKE %s",
            'custom_tabs'
        ));

        if (empty($column)) {
            $wpdb->query(
                "ALTER TABLE `{$productsTable}`
                 ADD COLUMN `custom_tabs` JSON DEFAULT NULL
                 AFTER `custom_cons`"
            );
        }

        // Migration: Add quick_update_at column if it doesn't exist
        $column = $wpdb->get_results($wpdb->prepare(
            "SHOW COLUMNS FROM `{$productsTable}` LIKE %s",
            'quick_update_at'
        ));

        if (empty($column)) {
            $wpdb->query(
                "ALTER TABLE `{$productsTable}`
                 ADD COLUMN `quick_update_at` DATETIME DEFAULT NULL
                 AFTER `error_message`"
            );
        }

        // Migration: Add quick_update_count column if it doesn't exist
        $column = $wpdb->get_results($wpdb->prepare(
            "SHOW COLUMNS FROM `{$productsTable}` LIKE %s",
            'quick_update_count'
        ));

        if (empty($column)) {
            $wpdb->query(
                "ALTER TABLE `{$productsTable}`
                 ADD COLUMN `quick_update_count` INT UNSIGNED DEFAULT 0
                 AFTER `quick_update_at`"
            );
        }

        // Migration: Add ai_status column if it doesn't exist
        $column = $wpdb->get_results($wpdb->prepare(
            "SHOW COLUMNS FROM `{$productsTable}` LIKE %s",
            'ai_status'
        ));

        if (empty($column)) {
            $wpdb->query(
                "ALTER TABLE `{$productsTable}`
                 ADD COLUMN `ai_status` ENUM('not_generated', 'queued', 'generating', 'generated', 'failed') DEFAULT NULL
                 AFTER `quick_update_count`"
            );

            // Add indexes for AI status queries
            $wpdb->query("ALTER TABLE `{$productsTable}` ADD INDEX `ai_status` (`ai_status`)");
            $wpdb->query("ALTER TABLE `{$productsTable}` ADD INDEX `status_ai_status` (`status`, `ai_status`)");
        }

        // Migration: Add ai_generated_at column if it doesn't exist
        $column = $wpdb->get_results($wpdb->prepare(
            "SHOW COLUMNS FROM `{$productsTable}` LIKE %s",
            'ai_generated_at'
        ));

        if (empty($column)) {
            $wpdb->query(
                "ALTER TABLE `{$productsTable}`
                 ADD COLUMN `ai_generated_at` DATETIME DEFAULT NULL
                 AFTER `ai_status`"
            );

            // Add index for sorting by generation date
            $wpdb->query("ALTER TABLE `{$productsTable}` ADD INDEX `ai_generated_at` (`ai_generated_at`)");
        }

        // Migration: Add ai_error_message column if it doesn't exist
        $column = $wpdb->get_results($wpdb->prepare(
            "SHOW COLUMNS FROM `{$productsTable}` LIKE %s",
            'ai_error_message'
        ));

        if (empty($column)) {
            $wpdb->query(
                "ALTER TABLE `{$productsTable}`
                 ADD COLUMN `ai_error_message` TEXT DEFAULT NULL
                 AFTER `ai_generated_at`"
            );
        }

        // Migration: Add AI content columns if they don't exist
        $column = $wpdb->get_results($wpdb->prepare(
            "SHOW COLUMNS FROM `{$productsTable}` LIKE %s",
            'ai_features'
        ));

        if (empty($column)) {
            $wpdb->query(
                "ALTER TABLE `{$productsTable}`
                 ADD COLUMN `ai_features` JSON DEFAULT NULL
                 AFTER `ai_error_message`"
            );
        }

        $column = $wpdb->get_results($wpdb->prepare(
            "SHOW COLUMNS FROM `{$productsTable}` LIKE %s",
            'ai_short_review'
        ));

        if (empty($column)) {
            $wpdb->query(
                "ALTER TABLE `{$productsTable}`
                 ADD COLUMN `ai_short_review` TEXT DEFAULT NULL
                 AFTER `ai_features`"
            );
        }

        $column = $wpdb->get_results($wpdb->prepare(
            "SHOW COLUMNS FROM `{$productsTable}` LIKE %s",
            'ai_description'
        ));

        if (empty($column)) {
            $wpdb->query(
                "ALTER TABLE `{$productsTable}`
                 ADD COLUMN `ai_description` TEXT DEFAULT NULL
                 AFTER `ai_short_review`"
            );
        }

        // Migration: Add ai_generation_id column for OpenRouter tracking
        $column = $wpdb->get_results($wpdb->prepare(
            "SHOW COLUMNS FROM `{$productsTable}` LIKE %s",
            'ai_generation_id'
        ));

        if (empty($column)) {
            $wpdb->query(
                "ALTER TABLE `{$productsTable}`
                 ADD COLUMN `ai_generation_id` VARCHAR(100) DEFAULT NULL
                 AFTER `ai_description`"
            );
        }

        // Migration: Add custom_category_paths for AI-assigned categories
        $column = $wpdb->get_results($wpdb->prepare(
            "SHOW COLUMNS FROM `{$productsTable}` LIKE %s",
            'custom_category_paths'
        ));

        if (empty($column)) {
            $wpdb->query(
                "ALTER TABLE `{$productsTable}`
                 ADD COLUMN `custom_category_paths` JSON DEFAULT NULL
                 AFTER `category_path`"
            );
        }

        // Migration: Add AI post generation columns to queue table
        $queueTable = self::queueTable();

        // Add ai_post_status column
        $column = $wpdb->get_results($wpdb->prepare(
            "SHOW COLUMNS FROM `{$queueTable}` LIKE %s",
            'ai_post_status'
        ));

        if (empty($column)) {
            $wpdb->query(
                "ALTER TABLE `{$queueTable}`
                 ADD COLUMN `ai_post_status` ENUM('not_generated', 'queued', 'generating', 'generated', 'failed') DEFAULT NULL
                 AFTER `searched_at`"
            );

            // Add indexes for AI post status queries
            $wpdb->query("ALTER TABLE `{$queueTable}` ADD INDEX `ai_post_status` (`ai_post_status`)");
            $wpdb->query("ALTER TABLE `{$queueTable}` ADD INDEX `status_ai_post` (`status`, `ai_post_status`)");
        }

        // Add ai_post_generating_at column (tracks when generation started for timeout detection)
        $column = $wpdb->get_results($wpdb->prepare(
            "SHOW COLUMNS FROM `{$queueTable}` LIKE %s",
            'ai_post_generating_at'
        ));

        if (empty($column)) {
            $wpdb->query(
                "ALTER TABLE `{$queueTable}`
                 ADD COLUMN `ai_post_generating_at` DATETIME DEFAULT NULL
                 AFTER `ai_post_status`"
            );
        }

        // Add ai_post_generated_at column
        $column = $wpdb->get_results($wpdb->prepare(
            "SHOW COLUMNS FROM `{$queueTable}` LIKE %s",
            'ai_post_generated_at'
        ));

        if (empty($column)) {
            $wpdb->query(
                "ALTER TABLE `{$queueTable}`
                 ADD COLUMN `ai_post_generated_at` DATETIME DEFAULT NULL
                 AFTER `ai_post_generating_at`"
            );
        }

        // Add ai_post_id column (link to created post)
        $column = $wpdb->get_results($wpdb->prepare(
            "SHOW COLUMNS FROM `{$queueTable}` LIKE %s",
            'ai_post_id'
        ));

        if (empty($column)) {
            $wpdb->query(
                "ALTER TABLE `{$queueTable}`
                 ADD COLUMN `ai_post_id` BIGINT UNSIGNED DEFAULT NULL
                 AFTER `ai_post_generated_at`"
            );
        }

        // Add ai_post_error column
        $column = $wpdb->get_results($wpdb->prepare(
            "SHOW COLUMNS FROM `{$queueTable}` LIKE %s",
            'ai_post_error'
        ));

        if (empty($column)) {
            $wpdb->query(
                "ALTER TABLE `{$queueTable}`
                 ADD COLUMN `ai_post_error` TEXT DEFAULT NULL
                 AFTER `ai_post_id`"
            );
        }

        // Migration: Add term_id column to brands table for taxonomy sync
        $brandsTable = self::brandsTable();
        $column = $wpdb->get_results($wpdb->prepare(
            "SHOW COLUMNS FROM `{$brandsTable}` LIKE %s",
            'term_id'
        ));

        if (empty($column)) {
            $wpdb->query(
                "ALTER TABLE `{$brandsTable}`
                 ADD COLUMN `term_id` BIGINT UNSIGNED DEFAULT NULL
                 AFTER `id`"
            );

            // Add index for term_id
            $wpdb->query("ALTER TABLE `{$brandsTable}` ADD INDEX `term_id` (`term_id`)");
        }

        // DATA MIGRATION: Set ai_status = 'queued' for existing scraped products with no ai_status
        // This ensures old products get picked up by ProductAiCron
        $affectedRows = $wpdb->query(
            "UPDATE `{$productsTable}`
             SET `ai_status` = 'queued'
             WHERE `status` = 'scraped'
             AND (`ai_status` IS NULL OR `ai_status` = '')"
        );

        if ($affectedRows > 0 && defined('WP_DEBUG') && WP_DEBUG) {
            error_log("[ACMS Migration] Set ai_status='queued' for {$affectedRows} existing scraped products");
        }

        // DATA MIGRATION: Set ai_post_status = 'queued' for existing completed queue items with no ai_post_status
        // This ensures old queue items get picked up by PostAiCron
        $affectedQueueRows = $wpdb->query(
            "UPDATE `{$queueTable}`
             SET `ai_post_status` = 'queued'
             WHERE `status` = 'completed'
             AND (`ai_post_status` IS NULL OR `ai_post_status` = '')"
        );

        if ($affectedQueueRows > 0 && defined('WP_DEBUG') && WP_DEBUG) {
            error_log("[ACMS Migration] Set ai_post_status='queued' for {$affectedQueueRows} existing completed queue items");
        }

        // Migration: Add scrape_log column for diagnostic data
        $column = $wpdb->get_results($wpdb->prepare(
            "SHOW COLUMNS FROM `{$productsTable}` LIKE %s",
            'scrape_log'
        ));
        if (empty($column)) {
            $wpdb->query("ALTER TABLE `{$productsTable}` ADD COLUMN `scrape_log` LONGTEXT DEFAULT NULL AFTER `error_message`");
        }

        // Migration: Add performance indexes for stats queries
        $idx = $wpdb->get_var("SHOW INDEX FROM `{$productsTable}` WHERE Key_name = 'post_count'");
        if (!$idx) {
            $wpdb->query("ALTER TABLE `{$productsTable}` ADD INDEX `post_count` (`post_count`)");
        }
        $idx = $wpdb->get_var("SHOW INDEX FROM `{$productsTable}` WHERE Key_name = 'in_stock'");
        if (!$idx) {
            $wpdb->query("ALTER TABLE `{$productsTable}` ADD INDEX `in_stock` (`in_stock`)");
        }
    }

    /**
     * Migrate status ENUM to include 'scheduled'
     */
    private function migrateStatusEnum(): void
    {
        global $wpdb;

        $productsTable = self::productsTable();

        // Check current ENUM values
        $column = $wpdb->get_row("SHOW COLUMNS FROM `{$productsTable}` WHERE Field = 'status'");

        if (!$column) {
            return;
        }

        // Always ensure ENUM has all values including 'update' and 'updating'
        if (strpos($column->Type, 'update') === false) {
            $wpdb->query(
                "ALTER TABLE `{$productsTable}`
                 MODIFY COLUMN `status` ENUM('pending', 'scheduled', 'processing', 'scraped', 'failed', 'update', 'updating') DEFAULT 'pending'"
            );
        }
    }

    /**
     * Recalculate scores for all existing products
     * Can be called manually to fix scores for existing products
     */
    public function recalculateAllScores(): void
    {
        global $wpdb;

        $scoreManager = \AffiliateCMS\Pro\Services\ScoreManager::instance();
        $productsTable = self::productsTable();

        // Get all products with ratings
        $products = $wpdb->get_results(
            "SELECT id, rating FROM `{$productsTable}` WHERE status = 'scraped'",
            ARRAY_A
        );

        foreach ($products as $product) {
            $rating = isset($product['rating']) ? floatval($product['rating']) : null;
            $score = $scoreManager->calculateScore($rating);

            $wpdb->update(
                $productsTable,
                ['score' => $score],
                ['id' => $product['id']],
                ['%d'],
                ['%d']
            );
        }
    }

    /**
     * Uninstall database tables (for complete removal)
     *
     * WARNING: This method permanently deletes ALL plugin data.
     * It is NOT called automatically on plugin deactivation or deletion.
     * Only call this method when user explicitly requests data deletion.
     *
     * Data preservation policy:
     * - Plugin deactivation: Data is preserved (only transients cleaned)
     * - Plugin deletion: Data is preserved (no uninstall.php)
     * - Manual cleanup: Call this method only when user confirms
     */
    public function uninstall(): void
    {
        global $wpdb;

        // Drop product links first (foreign key dependency)
        $productLinksTable = self::productLinksTable();
        $wpdb->query("DROP TABLE IF EXISTS {$productLinksTable}");

        $productsTable = self::productsTable();
        $wpdb->query("DROP TABLE IF EXISTS {$productsTable}");

        $queueTable = self::queueTable();
        $wpdb->query("DROP TABLE IF EXISTS {$queueTable}");

        $brandsTable = self::brandsTable();
        $wpdb->query("DROP TABLE IF EXISTS {$brandsTable}");

        $cacheUrlsTable = self::cacheUrlsTable();
        $wpdb->query("DROP TABLE IF EXISTS {$cacheUrlsTable}");

        // Clean up all plugin options
        $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE 'acms_%'");

        // Clean up transients
        $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_acms_%'");
        $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_acms_%'");

        // Clean up post meta
        $wpdb->query("DELETE FROM {$wpdb->postmeta} WHERE meta_key LIKE '_acms_%'");

        // Clean up scheduled cron events
        wp_clear_scheduled_hook('acms_cron_scrape');
        wp_clear_scheduled_hook('acms_date_update_cron');
    }

    /**
     * Run migrations if needed
     */
    public function migrate(): void
    {
        if ($this->needsUpgrade() || !self::tablesExist()) {
            $this->install();
        }
    }

    /**
     * Get database status info
     */
    public function getDatabaseStatus(): array
    {
        global $wpdb;

        $productsTable = self::productsTable();
        $exists = self::tablesExist();

        $status = [
            'table_name' => $productsTable,
            'exists' => $exists,
            'columns' => [],
            'row_count' => 0,
            'db_version' => $this->getVersion(),
            'plugin_version' => defined('ACMS_VERSION') ? ACMS_VERSION : '1.0.0',
        ];

        if ($exists) {
            // Get columns
            $columnsResult = $wpdb->get_results("SHOW COLUMNS FROM {$productsTable}");
            foreach ($columnsResult as $col) {
                $status['columns'][] = [
                    'name' => $col->Field,
                    'type' => $col->Type,
                    'null' => $col->Null,
                    'key' => $col->Key,
                    'default' => $col->Default,
                ];
            }

            // Get row count
            $status['row_count'] = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$productsTable}");
        }

        return $status;
    }
}
