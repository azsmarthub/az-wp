<?php
/**
 * Brand Repository
 *
 * Handles database operations for the acms_brands table.
 * Brands are flat (no hierarchy) - simpler than categories.
 *
 * @package AffiliateCMS\Pro\Repositories
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro\Repositories;

use AffiliateCMS\Pro\Database\Schema;

class BrandRepository
{
    private static ?BrandRepository $instance = null;

    /**
     * Valid columns for insert/update operations
     */
    private const VALID_COLUMNS = [
        'term_id',
        'name',
        'slug',
        'description',
        'logo_url',
        'banner_url',
        'website_url',
        'seo_title',
        'seo_description',
        'content_intro',
        'content_main',
        'content_faq',
        'content_status',
        'content_updated_at',
        'ai_generating_at',
        'ai_error_message',
        'product_count',
        'status',
    ];

    /**
     * JSON columns that need encoding/decoding
     */
    private const JSON_COLUMNS = ['content_faq'];

    /**
     * Get singleton instance
     */
    public static function instance(): BrandRepository
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Get table name
     */
    private function table(): string
    {
        return Schema::brandsTable();
    }

    // =========================================
    // CRUD Operations
    // =========================================

    /**
     * Create a new brand
     *
     * @param array $data Brand data
     * @return int|false Insert ID or false on failure
     */
    public function create(array $data): int|false
    {
        global $wpdb;

        // Filter valid columns
        $data = array_intersect_key($data, array_flip(self::VALID_COLUMNS));

        // Generate slug if not provided
        if (empty($data['slug']) && !empty($data['name'])) {
            $data['slug'] = $this->generateUniqueSlug($data['name']);
        }

        // Encode JSON fields
        foreach (self::JSON_COLUMNS as $field) {
            if (isset($data[$field]) && is_array($data[$field])) {
                $data[$field] = wp_json_encode($data[$field]);
            }
        }

        $result = $wpdb->insert($this->table(), $data);

        if ($result === false) {
            return false;
        }

        return (int) $wpdb->insert_id;
    }

    /**
     * Find a brand by ID
     *
     * @param int $id Brand ID
     * @return array|null Brand data or null if not found
     */
    public function find(int $id): ?array
    {
        global $wpdb;

        $row = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$this->table()} WHERE id = %d", $id),
            ARRAY_A
        );

        if (!$row) {
            return null;
        }

        return $this->hydrate($row);
    }

    /**
     * Find a brand by slug
     *
     * @param string $slug Brand slug
     * @return array|null Brand data or null if not found
     */
    public function findBySlug(string $slug): ?array
    {
        global $wpdb;

        $row = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$this->table()} WHERE slug = %s", $slug),
            ARRAY_A
        );

        if (!$row) {
            return null;
        }

        return $this->hydrate($row);
    }

    /**
     * Find a brand by name
     *
     * @param string $name Brand name
     * @return array|null Brand data or null if not found
     */
    public function findByName(string $name): ?array
    {
        global $wpdb;

        $row = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$this->table()} WHERE name = %s", $name),
            ARRAY_A
        );

        if (!$row) {
            return null;
        }

        return $this->hydrate($row);
    }

    /**
     * Get all brands with optional filtering
     *
     * @param array $args Query arguments
     * @return array Brands with pagination info
     */
    public function all(array $args = []): array
    {
        global $wpdb;

        $defaults = [
            'status' => '',
            'content_status' => '',
            'search' => '',
            'orderby' => 'name',
            'order' => 'ASC',
            'page' => 1,
            'per_page' => 50,
        ];

        $args = wp_parse_args($args, $defaults);

        $where = ['1=1'];
        $params = [];

        // Status filter
        if (!empty($args['status']) && $args['status'] !== 'all') {
            $where[] = 'status = %s';
            $params[] = $args['status'];
        }

        // Content status filter
        if (!empty($args['content_status']) && $args['content_status'] !== 'all') {
            $where[] = 'content_status = %s';
            $params[] = $args['content_status'];
        }

        // Search filter (name + slug only, no description LIKE for performance)
        if (!empty($args['search'])) {
            $where[] = '(name LIKE %s OR slug LIKE %s)';
            $searchTerm = '%' . $wpdb->esc_like($args['search']) . '%';
            $params[] = $searchTerm;
            $params[] = $searchTerm;
        }

        $whereClause = implode(' AND ', $where);

        // Validate orderby
        $allowedOrderBy = ['id', 'name', 'slug', 'product_count', 'status', 'created_at', 'updated_at'];
        $orderby = in_array($args['orderby'], $allowedOrderBy) ? $args['orderby'] : 'name';
        $order = strtoupper($args['order']) === 'DESC' ? 'DESC' : 'ASC';

        // Pagination
        $page = max(1, (int) $args['page']);
        $perPage = min(1000, max(1, (int) $args['per_page']));
        $offset = ($page - 1) * $perPage;

        // Count total
        $countSql = "SELECT COUNT(*) FROM {$this->table()} WHERE {$whereClause}";
        if (!empty($params)) {
            $countSql = $wpdb->prepare($countSql, ...$params);
        }
        $total = (int) $wpdb->get_var($countSql);

        // Get brands
        $sql = "SELECT * FROM {$this->table()} WHERE {$whereClause} ORDER BY {$orderby} {$order} LIMIT %d OFFSET %d";
        $params[] = $perPage;
        $params[] = $offset;

        $rows = $wpdb->get_results($wpdb->prepare($sql, ...$params), ARRAY_A);

        $brands = array_map([$this, 'hydrate'], $rows ?: []);

        return [
            'items' => $brands,
            'total' => $total,
            'page' => $page,
            'per_page' => $perPage,
            'total_pages' => (int) ceil($total / $perPage),
        ];
    }

    /**
     * Update a brand
     *
     * @param int $id Brand ID
     * @param array $data Data to update
     * @return bool Success
     */
    public function update(int $id, array $data): bool
    {
        global $wpdb;

        // Filter valid columns
        $data = array_intersect_key($data, array_flip(self::VALID_COLUMNS));

        if (empty($data)) {
            return false;
        }

        // Handle slug regeneration
        if (isset($data['slug']) && empty($data['slug']) && !empty($data['name'])) {
            $data['slug'] = $this->generateUniqueSlug($data['name'], $id);
        }

        // Encode JSON fields
        foreach (self::JSON_COLUMNS as $field) {
            if (isset($data[$field])) {
                if (is_array($data[$field])) {
                    $data[$field] = wp_json_encode($data[$field]);
                } elseif (empty($data[$field])) {
                    $data[$field] = null;
                }
            }
        }

        $result = $wpdb->update(
            $this->table(),
            $data,
            ['id' => $id],
        );

        return $result !== false;
    }

    /**
     * Delete a brand
     *
     * @param int $id Brand ID
     * @return bool Success
     */
    public function delete(int $id): bool
    {
        global $wpdb;

        $result = $wpdb->delete($this->table(), ['id' => $id], ['%d']);

        return $result !== false;
    }

    // =========================================
    // Query Methods
    // =========================================

    /**
     * Count brands with optional filtering
     *
     * @param array $args Filter arguments
     * @return int Count
     */
    public function count(array $args = []): int
    {
        global $wpdb;

        $where = ['1=1'];
        $params = [];

        if (!empty($args['status'])) {
            $where[] = 'status = %s';
            $params[] = $args['status'];
        }

        if (!empty($args['content_status'])) {
            $where[] = 'content_status = %s';
            $params[] = $args['content_status'];
        }

        $whereClause = implode(' AND ', $where);
        $sql = "SELECT COUNT(*) FROM {$this->table()} WHERE {$whereClause}";

        if (!empty($params)) {
            $sql = $wpdb->prepare($sql, ...$params);
        }

        return (int) $wpdb->get_var($sql);
    }

    /**
     * Search brands
     *
     * @param string $term Search term
     * @param int $limit Max results
     * @return array Matching brands
     */
    public function search(string $term, int $limit = 20): array
    {
        global $wpdb;

        $searchTerm = '%' . $wpdb->esc_like($term) . '%';

        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$this->table()}
             WHERE name LIKE %s OR slug LIKE %s
             ORDER BY name ASC
             LIMIT %d",
            $searchTerm,
            $searchTerm,
            $limit
        ), ARRAY_A);

        return array_map([$this, 'hydrate'], $rows ?: []);
    }

    /**
     * Get brands needing AI content generation
     *
     * @param int $limit Max results
     * @return array Brands
     */
    public function getBrandsNeedingAiContent(int $limit = 5): array
    {
        global $wpdb;

        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$this->table()}
             WHERE content_status = 'empty'
             AND product_count > 0
             AND status = 'publish'
             AND (ai_error_message IS NULL OR ai_generating_at < DATE_SUB(NOW(), INTERVAL 1 HOUR))
             ORDER BY product_count DESC, id ASC
             LIMIT %d",
            $limit
        ), ARRAY_A);

        return array_map([$this, 'hydrate'], $rows ?: []);
    }

    /**
     * Get statistics
     *
     * @return array Statistics
     */
    public function getStats(): array
    {
        global $wpdb;

        $table = $this->table();

        $row = $wpdb->get_row(
            "SELECT
                COUNT(*) AS total,
                SUM(status = 'publish') AS published,
                SUM(status = 'draft') AS draft,
                SUM(content_status IN ('ai_generated', 'manual')) AS with_content,
                SUM(content_status = 'empty') AS empty_content,
                SUM(content_status = 'ai_generating') AS ai_generating,
                COALESCE(SUM(product_count), 0) AS total_products
             FROM {$table}",
            ARRAY_A
        );

        return [
            'total' => (int) ($row['total'] ?? 0),
            'published' => (int) ($row['published'] ?? 0),
            'draft' => (int) ($row['draft'] ?? 0),
            'with_content' => (int) ($row['with_content'] ?? 0),
            'empty_content' => (int) ($row['empty_content'] ?? 0),
            'ai_generating' => (int) ($row['ai_generating'] ?? 0),
            'total_products' => (int) ($row['total_products'] ?? 0),
        ];
    }

    // =========================================
    // Product Integration
    // =========================================

    /**
     * Get or create brand from product data
     * Also creates/links taxonomy term for backward compatibility
     *
     * @param string $brandName Brand name from product
     * @return int|null Brand ID or null on failure
     */
    public function getOrCreateFromProduct(string $brandName): ?int
    {
        if (empty($brandName)) {
            return null;
        }

        // Check if brand exists
        $existing = $this->findByName($brandName);
        if ($existing) {
            // Ensure taxonomy term is linked
            if (empty($existing['term_id'])) {
                $termId = $this->getOrCreateTaxonomyTerm($brandName);
                if ($termId) {
                    $this->update((int) $existing['id'], ['term_id' => $termId]);
                }
            }
            return (int) $existing['id'];
        }

        // Create taxonomy term first
        $termId = $this->getOrCreateTaxonomyTerm($brandName);

        // Create new brand with term_id link
        $id = $this->create([
            'term_id' => $termId,
            'name' => $brandName,
            'slug' => $this->generateUniqueSlug($brandName),
            'status' => 'draft', // Start as draft, can be published later
            'content_status' => 'empty',
        ]);

        return $id !== false ? $id : null;
    }

    /**
     * Get or create taxonomy term for brand
     *
     * @param string $brandName Brand name
     * @return int|null Term ID or null
     */
    private function getOrCreateTaxonomyTerm(string $brandName): ?int
    {
        $taxonomy = 'acms_reviews_brand';

        // Check if taxonomy is registered
        if (!taxonomy_exists($taxonomy)) {
            return null;
        }

        // Check if term exists
        $term = term_exists($brandName, $taxonomy);
        if ($term) {
            return (int) $term['term_id'];
        }

        // Create new term
        $result = wp_insert_term($brandName, $taxonomy, [
            'slug' => sanitize_title($brandName),
        ]);

        if (is_wp_error($result)) {
            return null;
        }

        return (int) $result['term_id'];
    }

    /**
     * Find brand by taxonomy term ID
     *
     * @param int $termId Term ID
     * @return array|null Brand data or null
     */
    public function findByTermId(int $termId): ?array
    {
        global $wpdb;

        $row = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$this->table()} WHERE term_id = %d", $termId),
            ARRAY_A
        );

        if (!$row) {
            return null;
        }

        return $this->hydrate($row);
    }

    /**
     * Update product count for a brand
     *
     * @param int $brandId Brand ID
     * @return bool Success
     */
    public function updateProductCount(int $brandId): bool
    {
        global $wpdb;

        $productsTable = Schema::productsTable();
        $brandsTable = $this->table();

        // Single query: count products and update brand in one shot
        $result = $wpdb->query($wpdb->prepare(
            "UPDATE {$brandsTable} b
             SET b.product_count = (
                 SELECT COUNT(*) FROM {$productsTable}
                 WHERE brand = b.name AND status = 'scraped'
             )
             WHERE b.id = %d",
            $brandId
        ));

        return $result !== false;
    }

    /**
     * Import brands from existing products
     * Creates brand entries for all unique brand names in products table
     *
     * @return array ['created' => int, 'existing' => int]
     */
    public function importBrandsFromProducts(): array
    {
        global $wpdb;

        $productsTable = Schema::productsTable();
        $brandsTable = $this->table();

        // Get all unique brand names from products
        $brandNames = $wpdb->get_col(
            "SELECT DISTINCT brand FROM {$productsTable}
             WHERE brand IS NOT NULL AND brand != '' AND status = 'scraped'"
        );

        if (empty($brandNames)) {
            return ['created' => 0, 'existing' => 0];
        }

        // Get all existing brand names in one query
        $existingNames = $wpdb->get_col("SELECT name FROM {$brandsTable}");
        $existingNameMap = array_flip($existingNames);

        $created = 0;
        $existing = 0;

        foreach ($brandNames as $brandName) {
            $brandName = trim($brandName);
            if (empty($brandName)) {
                continue;
            }

            if (isset($existingNameMap[$brandName])) {
                $existing++;
                continue;
            }

            // Create new brand
            $id = $this->create([
                'name' => $brandName,
                'status' => 'draft',
                'content_status' => 'empty',
            ]);

            if ($id) {
                $created++;
                $existingNameMap[$brandName] = true; // Prevent duplicates within batch
            }
        }

        return [
            'created' => $created,
            'existing' => $existing,
        ];
    }

    /**
     * Update all brand product counts
     *
     * @return int Number of brands updated
     */
    public function updateAllProductCounts(): int
    {
        global $wpdb;

        $table = $this->table();
        $productsTable = Schema::productsTable();

        // Two-step approach to avoid locking the products table during UPDATE.
        // The old single UPDATE...LEFT JOIN held row locks on products for 2+ minutes,
        // blocking all scraping workers and freezing the entire pipeline.

        // Step 1: SELECT counts (read-only, no locks on products table)
        $counts = $wpdb->get_results(
            "SELECT brand, COUNT(*) AS cnt
             FROM {$productsTable}
             WHERE status = 'scraped' AND brand IS NOT NULL AND brand != ''
             GROUP BY brand",
            ARRAY_A
        );

        if ($counts === null) {
            return 0;
        }

        // Step 2: Reset all brand counts to 0 (only locks brands table)
        $wpdb->query("UPDATE {$table} SET product_count = 0 WHERE product_count > 0");

        // Step 3: Batch update brands with their counts (only locks brands table)
        $updated = 0;
        $batch = [];
        foreach ($counts as $row) {
            $batch[$row['brand']] = (int) $row['cnt'];

            if (count($batch) >= 100) {
                $updated += $this->batchUpdateBrandCounts($table, $batch);
                $batch = [];
            }
        }
        if (!empty($batch)) {
            $updated += $this->batchUpdateBrandCounts($table, $batch);
        }

        return $updated;
    }

    /**
     * Batch update brand product counts using CASE WHEN
     */
    private function batchUpdateBrandCounts(string $table, array $batch): int
    {
        global $wpdb;

        if (empty($batch)) {
            return 0;
        }

        $cases = [];
        $names = [];
        foreach ($batch as $brand => $count) {
            $cases[] = $wpdb->prepare("WHEN name = %s THEN %d", $brand, $count);
            $names[] = $wpdb->prepare("%s", $brand);
        }

        $casesSql = implode(' ', $cases);
        $namesSql = implode(',', $names);

        $result = $wpdb->query(
            "UPDATE {$table}
             SET product_count = CASE {$casesSql} ELSE product_count END
             WHERE name IN ({$namesSql})"
        );

        return $result !== false ? (int) $result : 0;
    }

    /**
     * Get products for a brand
     *
     * @param int $brandId Brand ID
     * @param int $limit Max results
     * @param int $offset Offset
     * @return array Products
     */
    public function getProducts(int $brandId, int $limit = 20, int $offset = 0): array
    {
        global $wpdb;

        $productsTable = Schema::productsTable();
        $brandsTable = $this->table();

        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT p.* FROM {$productsTable} p
             INNER JOIN {$brandsTable} b ON p.brand = b.name
             WHERE b.id = %d AND p.status = 'scraped'
             ORDER BY p.rating DESC, p.reviews_count DESC
             LIMIT %d OFFSET %d",
            $brandId,
            $limit,
            $offset
        ), ARRAY_A);

        return $rows ?: [];
    }

    // =========================================
    // Taxonomy Sync Methods
    // =========================================

    /**
     * Import taxonomy terms into brands table
     * Links existing terms to SEO brands or creates new brands from terms
     *
     * @return array ['imported' => int, 'linked' => int, 'skipped' => int]
     */
    public function importFromTaxonomy(): array
    {
        $taxonomy = 'acms_reviews_brand';
        $result = ['imported' => 0, 'linked' => 0, 'skipped' => 0];

        if (!taxonomy_exists($taxonomy)) {
            return $result;
        }

        // Get all taxonomy terms
        $terms = get_terms([
            'taxonomy' => $taxonomy,
            'hide_empty' => false,
        ]);

        if (is_wp_error($terms) || empty($terms)) {
            return $result;
        }

        foreach ($terms as $term) {
            // Check if already linked
            $existingByTermId = $this->findByTermId($term->term_id);
            if ($existingByTermId) {
                $result['skipped']++;
                continue;
            }

            // Check if brand exists by name
            $existingByName = $this->findByName($term->name);
            if ($existingByName) {
                // Link existing brand to term
                $this->update((int) $existingByName['id'], ['term_id' => $term->term_id]);
                $this->syncMetadataFromTerm($term->term_id, (int) $existingByName['id']);
                $result['linked']++;
                continue;
            }

            // Create new brand from taxonomy term
            $brandData = [
                'term_id' => $term->term_id,
                'name' => $term->name,
                'slug' => $term->slug,
                'description' => $term->description,
                'status' => 'draft',
                'content_status' => 'empty',
            ];

            // Get term metadata
            $logo = get_term_meta($term->term_id, 'brand_logo', true);
            $website = get_term_meta($term->term_id, 'brand_website', true);
            $content = get_term_meta($term->term_id, 'brand_content', true);

            if ($logo) {
                $brandData['logo_url'] = $logo;
            }
            if ($website) {
                $brandData['website_url'] = $website;
            }
            if ($content) {
                $brandData['content_intro'] = $content;
                $brandData['content_status'] = 'manual';
            }

            $id = $this->create($brandData);
            if ($id) {
                $result['imported']++;
            }
        }

        return $result;
    }

    /**
     * Sync metadata from taxonomy term to brand
     *
     * @param int $termId Term ID
     * @param int $brandId Brand ID
     * @return bool Success
     */
    public function syncMetadataFromTerm(int $termId, int $brandId): bool
    {
        $brand = $this->find($brandId);
        if (!$brand) {
            return false;
        }

        $updates = [];

        // Sync logo if brand doesn't have one
        if (empty($brand['logo_url'])) {
            $logo = get_term_meta($termId, 'brand_logo', true);
            if ($logo) {
                $updates['logo_url'] = $logo;
            }
        }

        // Sync website if brand doesn't have one
        if (empty($brand['website_url'])) {
            $website = get_term_meta($termId, 'brand_website', true);
            if ($website) {
                $updates['website_url'] = $website;
            }
        }

        // Sync content if brand content is empty
        if ($brand['content_status'] === 'empty') {
            $content = get_term_meta($termId, 'brand_content', true);
            if ($content) {
                $updates['content_intro'] = $content;
                $updates['content_status'] = 'manual';
            }
        }

        if (!empty($updates)) {
            return $this->update($brandId, $updates);
        }

        return true;
    }

    /**
     * Sync metadata from brand to taxonomy term
     *
     * @param int $brandId Brand ID
     * @return bool Success
     */
    public function syncMetadataToTerm(int $brandId): bool
    {
        $brand = $this->find($brandId);
        if (!$brand || empty($brand['term_id'])) {
            return false;
        }

        $termId = (int) $brand['term_id'];

        // Sync logo
        if (!empty($brand['logo_url'])) {
            update_term_meta($termId, 'brand_logo', $brand['logo_url']);
        }

        // Sync website
        if (!empty($brand['website_url'])) {
            update_term_meta($termId, 'brand_website', $brand['website_url']);
        }

        // Sync content intro to taxonomy content
        if (!empty($brand['content_intro'])) {
            update_term_meta($termId, 'brand_content', $brand['content_intro']);
        }

        return true;
    }

    // =========================================
    // Helper Methods
    // =========================================

    /**
     * Generate unique slug
     *
     * @param string $name Brand name
     * @param int|null $excludeId ID to exclude from uniqueness check
     * @return string Unique slug
     */
    private function generateUniqueSlug(string $name, ?int $excludeId = null): string
    {
        global $wpdb;

        $baseSlug = sanitize_title($name);
        $slug = $baseSlug;
        $counter = 1;

        while (true) {
            $sql = "SELECT id FROM {$this->table()} WHERE slug = %s";
            $params = [$slug];

            if ($excludeId !== null) {
                $sql .= " AND id != %d";
                $params[] = $excludeId;
            }

            $existing = $wpdb->get_var($wpdb->prepare($sql, ...$params));

            if (!$existing) {
                break;
            }

            $slug = $baseSlug . '-' . $counter;
            $counter++;
        }

        return $slug;
    }

    /**
     * Hydrate a database row
     *
     * @param array $row Database row
     * @return array Hydrated brand data
     */
    private function hydrate(array $row): array
    {
        // Decode JSON fields
        foreach (self::JSON_COLUMNS as $field) {
            if (isset($row[$field]) && is_string($row[$field])) {
                $row[$field] = json_decode($row[$field], true);
            }
        }

        // Ensure integer types
        $row['id'] = (int) $row['id'];
        $row['product_count'] = (int) ($row['product_count'] ?? 0);

        return $row;
    }
}
