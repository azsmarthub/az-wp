<?php
/**
 * Product Repository
 *
 * Handles all database operations for products
 * Uses {prefix}acms_products table
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro\Repositories;

use AffiliateCMS\Pro\Models\Product;

class ProductRepository
{
    private static ?ProductRepository $instance = null;

    private \wpdb $db;
    private string $table;

    /**
     * Valid database columns - used to filter incoming data
     */
    private const VALID_COLUMNS = [
        'asin',
        'title',
        'brand',
        'price',
        'original_price',
        'currency',
        'rating',
        'reviews_count',
        'score',
        'in_stock',
        'is_prime',
        'image_url',
        'images_gallery',
        'description',
        'features',
        'category',
        'category_path',
        'custom_category_paths',
        'product_information',
        'specifications',
        'best_sellers_rank',
        'seller_info',
        'reviews_data',
        'top_reviews',
        'reviews_summary',
        'custom_title',
        'custom_description',
        'custom_features',
        'custom_pros',
        'custom_cons',
        'custom_tabs',
        'status',
        'last_provider',
        'last_scraped_at',
        'error_message',
        'scrape_log',
        'quick_update_at',
        'quick_update_count',
        'ai_status',
        'ai_generated_at',
        'ai_error_message',
        'ai_features',
        'ai_short_review',
        'ai_description',
        'ai_generation_id',
        'source_post_id',
        'post_ids',
        'post_count',
        'created_at',
        'updated_at',
    ];

    /**
     * Get singleton instance
     */
    public static function instance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct()
    {
        global $wpdb;
        $this->db = $wpdb;
        $this->table = $wpdb->prefix . 'acms_products';
    }

    /**
     * Get table name
     */
    public function getTable(): string
    {
        return $this->table;
    }

    /**
     * Columns needed for product table listing.
     * Excludes heavy LONGTEXT/JSON columns (description, features, reviews_data, etc.)
     * to reduce data transfer by ~90%.
     */
    private const LIST_COLUMNS = 'id, asin, title, brand, price, original_price, currency, rating, reviews_count, score, in_stock, is_prime, image_url, category, category_path, status, last_provider, last_scraped_at, error_message, ai_status, ai_generated_at, ai_error_message, post_ids, post_count, quick_update_at, quick_update_count, created_at, updated_at';

    // =========================================================================
    // CRUD OPERATIONS
    // =========================================================================

    /**
     * Find product by ID
     *
     * @param int $id Product ID
     * @return Product|null
     */
    public function find(int $id): ?Product
    {
        $row = $this->db->get_row(
            $this->db->prepare(
                "SELECT * FROM {$this->table} WHERE id = %d",
                $id
            )
        );

        return $row ? Product::fromRow($row) : null;
    }

    /**
     * Find product by ASIN
     *
     * @param string $asin Amazon ASIN
     * @return Product|null
     */
    public function findByAsin(string $asin): ?Product
    {
        $row = $this->db->get_row(
            $this->db->prepare(
                "SELECT * FROM {$this->table} WHERE asin = %s",
                strtoupper($asin)
            )
        );

        return $row ? Product::fromRow($row) : null;
    }

    /**
     * Get all products with filtering and pagination
     *
     * @param array $args Query arguments
     * @return array ['products' => Product[], 'total' => int, 'page' => int, 'per_page' => int, 'total_pages' => int]
     */
    public function all(array $args = []): array
    {
        $defaults = [
            'page' => 1,
            'per_page' => 20,
            'search' => '',
            'status' => '',
            'category' => '',
            'brand' => '',
            'in_stock' => null,
            'orderby' => 'id',
            'order' => 'DESC',
        ];

        $args = wp_parse_args($args, $defaults);

        // Build query
        $where = ['1=1'];
        $values = [];

        // Search filter
        if (!empty($args['search'])) {
            $search = '%' . $this->db->esc_like($args['search']) . '%';
            $where[] = "(asin LIKE %s OR title LIKE %s OR brand LIKE %s)";
            $values[] = $search;
            $values[] = $search;
            $values[] = $search;
        }

        // Status filter
        if (!empty($args['status'])) {
            $where[] = "status = %s";
            $values[] = $args['status'];
        }

        // Category filter
        if (!empty($args['category'])) {
            $where[] = "category = %s";
            $values[] = $args['category'];
        }

        // Brand filter
        if (!empty($args['brand'])) {
            $where[] = "brand = %s";
            $values[] = $args['brand'];
        }

        // Stock filter
        if ($args['in_stock'] !== null) {
            $where[] = "in_stock = %d";
            $values[] = (int) $args['in_stock'];
        }

        $whereClause = implode(' AND ', $where);

        // Count total
        $countQuery = "SELECT COUNT(*) FROM {$this->table} WHERE {$whereClause}";
        if (!empty($values)) {
            $countQuery = $this->db->prepare($countQuery, $values);
        }
        $total = (int) $this->db->get_var($countQuery);

        // Sort
        $allowedOrderBy = ['id', 'asin', 'title', 'brand', 'price', 'rating', 'reviews_count', 'status', 'post_count', 'created_at', 'updated_at', 'last_scraped_at'];
        $orderBy = in_array($args['orderby'], $allowedOrderBy) ? $args['orderby'] : 'created_at';
        $order = strtoupper($args['order']) === 'ASC' ? 'ASC' : 'DESC';

        // Pagination
        $page = max(1, (int) $args['page']);
        $perPage = max(1, min(1000, (int) $args['per_page']));
        $offset = ($page - 1) * $perPage;

        // Execute query
        $query = "SELECT * FROM {$this->table} WHERE {$whereClause} ORDER BY {$orderBy} {$order} LIMIT {$perPage} OFFSET {$offset}";
        if (!empty($values)) {
            $query = $this->db->prepare($query, $values);
        }

        $rows = $this->db->get_results($query);
        $products = array_map(fn($row) => Product::fromRow($row), $rows ?: []);

        return [
            'products' => $products,
            'total' => $total,
            'page' => $page,
            'per_page' => $perPage,
            'total_pages' => (int) ceil($total / $perPage),
        ];
    }

    /**
     * Get products for table listing (lightweight - excludes heavy columns)
     *
     * Returns raw associative arrays instead of Product objects to avoid
     * loading/serializing 20+ heavy LONGTEXT/JSON columns not used in the table.
     *
     * @param array $args Same query arguments as all()
     * @return array ['products' => array[], 'total' => int, 'page' => int, 'per_page' => int, 'total_pages' => int]
     */
    public function allForListing(array $args = []): array
    {
        $defaults = [
            'page' => 1,
            'per_page' => 20,
            'search' => '',
            'status' => '',
            'ai_status' => '',
            'category' => '',
            'brand' => '',
            'in_stock' => null,
            'orderby' => 'id',
            'order' => 'DESC',
        ];

        $args = wp_parse_args($args, $defaults);

        // Build WHERE clause
        $where = ['1=1'];
        $values = [];

        if (!empty($args['search'])) {
            $search = '%' . $this->db->esc_like($args['search']) . '%';
            $where[] = "(asin LIKE %s OR title LIKE %s OR brand LIKE %s)";
            $values[] = $search;
            $values[] = $search;
            $values[] = $search;
        }

        if (!empty($args['status'])) {
            $where[] = "status = %s";
            $values[] = $args['status'];
        }

        if (!empty($args['ai_status'])) {
            $where[] = "ai_status = %s";
            $values[] = $args['ai_status'];
        }

        if (!empty($args['category'])) {
            $where[] = "category = %s";
            $values[] = $args['category'];
        }

        if (!empty($args['brand'])) {
            $where[] = "brand = %s";
            $values[] = $args['brand'];
        }

        if ($args['in_stock'] !== null) {
            $where[] = "in_stock = %d";
            $values[] = (int) $args['in_stock'];
        }

        $whereClause = implode(' AND ', $where);

        // Count total
        $countQuery = "SELECT COUNT(*) FROM {$this->table} WHERE {$whereClause}";
        if (!empty($values)) {
            $countQuery = $this->db->prepare($countQuery, $values);
        }
        $total = (int) $this->db->get_var($countQuery);

        // Sort
        $allowedOrderBy = ['id', 'asin', 'title', 'brand', 'price', 'rating', 'reviews_count', 'status', 'post_count', 'created_at', 'updated_at', 'last_scraped_at'];
        $orderBy = in_array($args['orderby'], $allowedOrderBy) ? $args['orderby'] : 'created_at';
        $order = strtoupper($args['order']) === 'ASC' ? 'ASC' : 'DESC';

        // Pagination
        $page = max(1, (int) $args['page']);
        $perPage = max(1, min(1000, (int) $args['per_page']));
        $offset = ($page - 1) * $perPage;

        // Select only listing columns (no heavy LONGTEXT/JSON)
        $columns = self::LIST_COLUMNS;
        $query = "SELECT {$columns} FROM {$this->table} WHERE {$whereClause} ORDER BY {$orderBy} {$order} LIMIT {$perPage} OFFSET {$offset}";
        if (!empty($values)) {
            $query = $this->db->prepare($query, $values);
        }

        $rows = $this->db->get_results($query, ARRAY_A);

        // Cast numeric fields to proper types (MySQL returns all as strings,
        // which causes JS "2" + "0" = "20" instead of 2 + 0 = 2)
        $intFields = ['id', 'reviews_count', 'score', 'in_stock', 'is_prime', 'post_count', 'quick_update_count'];
        $floatFields = ['price', 'original_price', 'rating'];
        foreach ($rows as &$row) {
            foreach ($intFields as $f) {
                if (isset($row[$f])) {
                    $row[$f] = (int) $row[$f];
                }
            }
            foreach ($floatFields as $f) {
                if (isset($row[$f]) && $row[$f] !== null) {
                    $row[$f] = (float) $row[$f];
                }
            }
        }
        unset($row);

        return [
            'products' => $rows ?: [],
            'total' => $total,
            'page' => $page,
            'per_page' => $perPage,
            'total_pages' => (int) ceil($total / $perPage),
        ];
    }

    /**
     * Create new product
     *
     * @param array $data Product data
     * @return int|false Insert ID or false on failure
     */
    public function create(array $data): int|false
    {
        $now = current_time('mysql');

        // Calculate score from rating
        $rating = $data['rating'] ?? null;
        $scoreManager = \AffiliateCMS\Pro\Services\ScoreManager::instance();
        $score = $scoreManager->calculateScore($rating !== null ? floatval($rating) : null);

        $insertData = [
            'asin' => strtoupper($data['asin'] ?? ''),
            'title' => $data['title'] ?? null,
            'brand' => $data['brand'] ?? null,
            'price' => $data['price'] ?? null,
            'original_price' => $data['original_price'] ?? null,
            'currency' => $data['currency'] ?? 'USD',
            'rating' => $data['rating'] ?? null,
            'reviews_count' => (int) ($data['reviews_count'] ?? 0),
            'score' => $data['score'] ?? $score, // Use provided score or calculated score
            'in_stock' => isset($data['in_stock']) ? (int) $data['in_stock'] : 1,
            'is_prime' => isset($data['is_prime']) ? (int) $data['is_prime'] : 0,
            'image_url' => $data['image_url'] ?? null,
            'images_gallery' => isset($data['images_gallery']) ? wp_json_encode($data['images_gallery']) : null,
            'description' => $data['description'] ?? null,
            'features' => isset($data['features']) ? wp_json_encode($data['features']) : null,
            'category' => $data['category'] ?? null,
            'category_path' => $data['category_path'] ?? null,
            'product_information' => isset($data['product_information']) ? wp_json_encode($data['product_information']) : null,
            'specifications' => isset($data['specifications']) ? wp_json_encode($data['specifications']) : null,
            'best_sellers_rank' => $data['best_sellers_rank'] ?? null,
            'seller_info' => isset($data['seller_info']) ? wp_json_encode($data['seller_info']) : null,
            'reviews_data' => isset($data['reviews_data']) ? wp_json_encode($data['reviews_data']) : null,
            'top_reviews' => isset($data['top_reviews']) ? wp_json_encode($data['top_reviews']) : null,
            'reviews_summary' => isset($data['reviews_summary']) ? wp_json_encode($data['reviews_summary']) : null,
            'custom_title' => $data['custom_title'] ?? null,
            'custom_description' => $data['custom_description'] ?? null,
            'custom_features' => isset($data['custom_features']) ? wp_json_encode($data['custom_features']) : null,
            'custom_pros' => isset($data['custom_pros']) ? wp_json_encode($data['custom_pros']) : null,
            'custom_cons' => isset($data['custom_cons']) ? wp_json_encode($data['custom_cons']) : null,
            'status' => $data['status'] ?? 'pending',
            'last_provider' => $data['last_provider'] ?? null,
            'last_scraped_at' => $data['last_scraped_at'] ?? null,
            'error_message' => $data['error_message'] ?? null,
            'source_post_id' => $data['source_post_id'] ?? null,
            'post_ids' => $data['post_ids'] ?? null,
            'post_count' => (int) ($data['post_count'] ?? 0),
            'created_at' => $now,
            'updated_at' => $now,
        ];

        $result = $this->db->insert($this->table, $insertData);

        return $result ? (int) $this->db->insert_id : false;
    }

    /**
     * Update product
     *
     * @param int $id Product ID
     * @param array $data Data to update
     * @return bool Success
     */
    public function update(int $id, array $data): bool
    {
        // Filter out invalid columns (fields not in database)
        $data = array_intersect_key($data, array_flip(self::VALID_COLUMNS));

        // JSON encode array fields - also convert empty strings to null for JSON columns
        $jsonFields = ['images_gallery', 'features', 'product_information', 'specifications', 'seller_info', 'reviews_data', 'top_reviews', 'reviews_summary', 'custom_features', 'custom_pros', 'custom_cons', 'custom_tabs', 'ai_features', 'custom_category_paths', 'scrape_log'];
        foreach ($jsonFields as $field) {
            if (isset($data[$field])) {
                if (is_array($data[$field])) {
                    $data[$field] = wp_json_encode($data[$field]);
                } elseif ($data[$field] === '' || $data[$field] === null) {
                    // Empty string or null -> set to null for JSON columns
                    $data[$field] = null;
                }
            }
        }

        $data['updated_at'] = current_time('mysql');

        // Remove id if present
        unset($data['id']);

        $result = $this->db->update($this->table, $data, ['id' => $id]);

        // Log any database errors for debugging
        if ($result === false && defined('WP_DEBUG') && WP_DEBUG) {
            error_log('ACMS Product Update Error: ' . $this->db->last_error);
            error_log('ACMS Product Update Data: ' . print_r($data, true));
        }

        return $result !== false;
    }

    /**
     * Append category paths to a product's custom_category_paths field
     *
     * Safely merges new paths with existing ones (no duplicates, no overwrites).
     * This is the ONLY method that should be used to add paths programmatically.
     * One ASIN can belong to multiple categories/queue items, so paths accumulate.
     *
     * @param int $productId Product ID
     * @param array $newPaths One or more category path strings to add
     * @return bool True if any paths were added
     */
    public function appendCategoryPaths(int $productId, array $newPaths): bool
    {
        if (empty($newPaths)) {
            return false;
        }

        // Read current paths from DB
        $raw = $this->db->get_var($this->db->prepare(
            "SELECT custom_category_paths FROM {$this->table} WHERE id = %d",
            $productId
        ));

        $existingPaths = [];
        if ($raw) {
            $existingPaths = is_array($raw) ? $raw : json_decode($raw, true);
            if (!is_array($existingPaths)) {
                $existingPaths = [];
            }
        }

        // Merge: add only paths not already present
        $added = false;
        foreach ($newPaths as $path) {
            $path = trim((string) $path);
            if ($path !== '' && !in_array($path, $existingPaths, true)) {
                $existingPaths[] = $path;
                $added = true;
            }
        }

        if (!$added) {
            return false;
        }

        $this->db->update($this->table, [
            'custom_category_paths' => wp_json_encode($existingPaths),
            'updated_at' => current_time('mysql'),
        ], ['id' => $productId]);

        return true;
    }

    /**
     * Delete product
     *
     * @param int $id Product ID
     * @return bool Success
     */
    public function delete(int $id): bool
    {
        // Cascade delete all related data first
        $this->cascadeDeleteRelatedData([$id]);

        $result = $this->db->delete($this->table, ['id' => $id]);
        return $result !== false;
    }

    // =========================================================================
    // BULK OPERATIONS
    // =========================================================================

    /**
     * Bulk delete products
     *
     * @param array $ids Product IDs
     * @return int Number of deleted rows
     */
    public function bulkDelete(array $ids): int
    {
        if (empty($ids)) {
            return 0;
        }

        $ids = array_map('intval', $ids);

        // Cascade delete all related data first
        $this->cascadeDeleteRelatedData($ids);

        $placeholders = implode(',', array_fill(0, count($ids), '%d'));

        $result = $this->db->query(
            $this->db->prepare(
                "DELETE FROM {$this->table} WHERE id IN ({$placeholders})",
                $ids
            )
        );

        return $result !== false ? $result : 0;
    }

    /**
     * Cascade delete all related data across all tables for given product IDs
     *
     * Tables cleaned:
     * - acms_product_links (by product_id)
     * - acms_category_products (by product_id)
     * - acms_product_reviews (by product_id or asin)
     * - acms_ai_jobs (by target_id = asin, target_type = 'product')
     * - acms_queue.linked_asins (remove asin from JSON array)
     * - acms_cat_queue.linked_asins (remove asin from JSON array)
     *
     * @param array $ids Product IDs (already intval'd)
     */
    private function cascadeDeleteRelatedData(array $ids): void
    {
        if (empty($ids)) {
            return;
        }

        $ids = array_map('intval', $ids);
        $placeholders = implode(',', array_fill(0, count($ids), '%d'));

        // 1. Get ASINs for these products (needed for JSON cleanup and ai_jobs)
        $asins = $this->db->get_col(
            $this->db->prepare(
                "SELECT asin FROM {$this->table} WHERE id IN ({$placeholders}) AND asin IS NOT NULL AND asin != ''",
                $ids
            )
        );

        // 2. Delete from acms_product_links
        $linksTable = $this->db->prefix . 'acms_product_links';
        $this->db->query(
            $this->db->prepare(
                "DELETE FROM {$linksTable} WHERE product_id IN ({$placeholders})",
                $ids
            )
        );

        // 3. Delete from acms_category_products (junction table)
        $categoryProductsTable = $this->db->prefix . 'acms_category_products';
        if ($this->db->get_var($this->db->prepare("SHOW TABLES LIKE %s", $categoryProductsTable)) === $categoryProductsTable) {
            $this->db->query(
                $this->db->prepare(
                    "DELETE FROM {$categoryProductsTable} WHERE product_id IN ({$placeholders})",
                    $ids
                )
            );
        }

        // 4. Delete from acms_product_reviews (by product_id)
        $reviewsTable = $this->db->prefix . 'acms_product_reviews';
        if ($this->db->get_var($this->db->prepare("SHOW TABLES LIKE %s", $reviewsTable)) === $reviewsTable) {
            $this->db->query(
                $this->db->prepare(
                    "DELETE FROM {$reviewsTable} WHERE product_id IN ({$placeholders})",
                    $ids
                )
            );
        }

        if (!empty($asins)) {
            $asinPlaceholders = implode(',', array_fill(0, count($asins), '%s'));

            // 5. Also delete reviews by ASIN (in case product_id wasn't set)
            if ($this->db->get_var($this->db->prepare("SHOW TABLES LIKE %s", $reviewsTable)) === $reviewsTable) {
                $this->db->query(
                    $this->db->prepare(
                        "DELETE FROM {$reviewsTable} WHERE asin IN ({$asinPlaceholders})",
                        $asins
                    )
                );
            }

            // 6. Delete from acms_ai_jobs (where target_type = 'product' and target_id = asin)
            $aiJobsTable = $this->db->prefix . 'acms_ai_jobs';
            if ($this->db->get_var($this->db->prepare("SHOW TABLES LIKE %s", $aiJobsTable)) === $aiJobsTable) {
                $this->db->query(
                    $this->db->prepare(
                        "DELETE FROM {$aiJobsTable} WHERE target_type = 'product' AND target_id IN ({$asinPlaceholders})",
                        $asins
                    )
                );
            }

            // 7. Clean ASINs from acms_queue.linked_asins (JSON array)
            $queueTable = $this->db->prefix . 'acms_queue';
            $this->cleanAsinsFromJsonColumn($queueTable, 'linked_asins', $asins);

            // 8. Clean ASINs from acms_cat_queue.linked_asins (JSON array)
            $catQueueTable = $this->db->prefix . 'acms_cat_queue';
            $this->cleanAsinsFromJsonColumn($catQueueTable, 'linked_asins', $asins);
        }
    }

    /**
     * Remove specific ASINs from a JSON array column in a table
     *
     * @param string $table Table name
     * @param string $column JSON column name
     * @param array $asins ASINs to remove
     */
    private function cleanAsinsFromJsonColumn(string $table, string $column, array $asins): void
    {
        if ($this->db->get_var($this->db->prepare("SHOW TABLES LIKE %s", $table)) !== $table) {
            return;
        }

        foreach ($asins as $asin) {
            // Use JSON_REMOVE + JSON_SEARCH to remove ASIN from JSON array
            $this->db->query(
                $this->db->prepare(
                    "UPDATE {$table} SET {$column} = JSON_REMOVE({$column}, JSON_UNQUOTE(JSON_SEARCH({$column}, 'one', %s)))
                     WHERE JSON_SEARCH({$column}, 'one', %s) IS NOT NULL",
                    $asin,
                    $asin
                )
            );
        }
    }

    /**
     * Delete orphan products by ASINs
     * Only deletes products that have post_count = 0 or NULL
     *
     * @param array $asins Array of ASINs to check and delete
     * @return array ['deleted' => int, 'skipped' => int, 'deleted_asins' => array, 'skipped_asins' => array]
     */
    public function deleteOrphansByAsins(array $asins): array
    {
        if (empty($asins)) {
            return ['deleted' => 0, 'skipped' => 0, 'deleted_asins' => [], 'skipped_asins' => []];
        }

        $asins = array_map('strtoupper', array_map('trim', $asins));
        $placeholders = implode(',', array_fill(0, count($asins), '%s'));

        // Find orphan products (post_count = 0 or NULL)
        $orphans = $this->db->get_results(
            $this->db->prepare(
                "SELECT id, asin FROM {$this->table}
                 WHERE asin IN ({$placeholders})
                 AND (post_count = 0 OR post_count IS NULL)",
                $asins
            )
        );

        // Find non-orphan products (in use)
        $inUse = $this->db->get_results(
            $this->db->prepare(
                "SELECT id, asin FROM {$this->table}
                 WHERE asin IN ({$placeholders})
                 AND post_count > 0",
                $asins
            )
        );

        $deletedAsins = [];
        $skippedAsins = [];

        // Delete orphans
        if (!empty($orphans)) {
            $orphanIds = array_column($orphans, 'id');
            $deletedAsins = array_column($orphans, 'asin');
            $this->bulkDelete($orphanIds);
        }

        // Track skipped (in use)
        if (!empty($inUse)) {
            $skippedAsins = array_column($inUse, 'asin');
        }

        return [
            'deleted' => count($deletedAsins),
            'skipped' => count($skippedAsins),
            'deleted_asins' => $deletedAsins,
            'skipped_asins' => $skippedAsins,
        ];
    }

    /**
     * Check if ASINs are orphans (not used in any posts)
     *
     * @param array $asins Array of ASINs to check
     * @return array ['orphan' => array, 'in_use' => array]
     */
    public function checkOrphanStatus(array $asins): array
    {
        if (empty($asins)) {
            return ['orphan' => [], 'in_use' => []];
        }

        $asins = array_map('strtoupper', array_map('trim', $asins));
        $placeholders = implode(',', array_fill(0, count($asins), '%s'));

        $results = $this->db->get_results(
            $this->db->prepare(
                "SELECT asin, post_count FROM {$this->table}
                 WHERE asin IN ({$placeholders})",
                $asins
            )
        );

        $orphan = [];
        $inUse = [];

        foreach ($results as $row) {
            if ((int) $row->post_count > 0) {
                $inUse[] = $row->asin;
            } else {
                $orphan[] = $row->asin;
            }
        }

        return ['orphan' => $orphan, 'in_use' => $inUse];
    }

    /**
     * Bulk update status
     *
     * @param array $ids Product IDs
     * @param string $status New status
     * @return int Number of updated rows
     */
    public function bulkUpdateStatus(array $ids, string $status): int
    {
        if (empty($ids)) {
            return 0;
        }

        $allowedStatuses = ['pending', 'processing', 'scraped', 'failed'];
        if (!in_array($status, $allowedStatuses)) {
            return 0;
        }

        $ids = array_map('intval', $ids);
        $placeholders = implode(',', array_fill(0, count($ids), '%d'));
        $now = current_time('mysql');

        $result = $this->db->query(
            $this->db->prepare(
                "UPDATE {$this->table} SET status = %s, updated_at = %s WHERE id IN ({$placeholders})",
                array_merge([$status, $now], $ids)
            )
        );

        return $result !== false ? $result : 0;
    }

    // =========================================================================
    // QUERY HELPERS
    // =========================================================================

    /**
     * Count products
     *
     * @param array $args Filter arguments
     * @return int Count
     */
    public function count(array $args = []): int
    {
        $where = ['1=1'];
        $values = [];

        if (!empty($args['status'])) {
            $where[] = "status = %s";
            $values[] = $args['status'];
        }

        if (!empty($args['category'])) {
            $where[] = "category = %s";
            $values[] = $args['category'];
        }

        if (!empty($args['brand'])) {
            $where[] = "brand = %s";
            $values[] = $args['brand'];
        }

        $whereClause = implode(' AND ', $where);
        $query = "SELECT COUNT(*) FROM {$this->table} WHERE {$whereClause}";

        if (!empty($values)) {
            $query = $this->db->prepare($query, $values);
        }

        return (int) $this->db->get_var($query);
    }

    /**
     * Get products by status
     *
     * @param string $status Status filter
     * @param int $limit Limit
     * @return Product[]
     */
    public function getByStatus(string $status, int $limit = 50): array
    {
        $rows = $this->db->get_results(
            $this->db->prepare(
                "SELECT * FROM {$this->table} WHERE status = %s ORDER BY created_at ASC LIMIT %d",
                $status,
                $limit
            )
        );

        return array_map(fn($row) => Product::fromRow($row), $rows ?: []);
    }

    /**
     * Get pending products (shortcut)
     *
     * @param int $limit Limit
     * @return Product[]
     */
    public function getPending(int $limit = 50): array
    {
        return $this->getByStatus('pending', $limit);
    }

    /**
     * Search products
     *
     * @param string $term Search term
     * @param int $limit Limit
     * @return Product[]
     */
    public function search(string $term, int $limit = 20): array
    {
        $search = '%' . $this->db->esc_like($term) . '%';

        $rows = $this->db->get_results(
            $this->db->prepare(
                "SELECT * FROM {$this->table}
                 WHERE asin LIKE %s OR title LIKE %s OR brand LIKE %s
                 ORDER BY
                    CASE WHEN asin = %s THEN 0
                         WHEN asin LIKE %s THEN 1
                         ELSE 2
                    END,
                    title ASC
                 LIMIT %d",
                $search,
                $search,
                $search,
                strtoupper($term),
                strtoupper($term) . '%',
                $limit
            )
        );

        return array_map(fn($row) => Product::fromRow($row), $rows ?: []);
    }

    // =========================================================================
    // STATISTICS
    // =========================================================================

    /**
     * Get product statistics (single query with conditional aggregation)
     *
     * @return array Statistics
     */
    public function getStats(): array
    {
        $row = $this->db->get_row(
            "SELECT
                COUNT(*) as total,
                SUM(status = 'pending') as pending,
                SUM(status = 'scheduled') as scheduled,
                SUM(status = 'processing') as processing,
                SUM(status = 'scraped') as scraped,
                SUM(status = 'failed') as failed,
                SUM(status = 'update') as update_queued,
                SUM(status = 'updating') as updating,
                SUM(in_stock = 1) as in_stock,
                SUM(in_stock = 0) as out_of_stock,
                SUM(post_count > 0) as with_posts,
                SUM(post_count = 0 OR post_count IS NULL) as orphan
             FROM {$this->table}"
        );

        if (!$row) {
            return [
                'total' => 0, 'pending' => 0, 'scheduled' => 0, 'processing' => 0,
                'scraped' => 0, 'failed' => 0, 'in_stock' => 0, 'out_of_stock' => 0,
                'with_posts' => 0, 'orphan' => 0,
            ];
        }

        return [
            'total' => (int) $row->total,
            'pending' => (int) $row->pending,
            'scheduled' => (int) $row->scheduled,
            'processing' => (int) $row->processing,
            'scraped' => (int) $row->scraped,
            'failed' => (int) $row->failed,
            'in_stock' => (int) $row->in_stock,
            'out_of_stock' => (int) $row->out_of_stock,
            'with_posts' => (int) $row->with_posts,
            'orphan' => (int) $row->orphan,
        ];
    }

    /**
     * Get distinct categories with counts
     *
     * @return array Categories [['name' => string, 'count' => int], ...]
     */
    public function getCategories(): array
    {
        $results = $this->db->get_results(
            "SELECT category as name, COUNT(*) as count
             FROM {$this->table}
             WHERE category IS NOT NULL AND category != ''
             GROUP BY category
             ORDER BY count DESC, category ASC"
        );

        return array_map(fn($row) => [
            'name' => $row->name,
            'count' => (int) $row->count,
        ], $results ?: []);
    }

    /**
     * Get distinct brands with counts
     *
     * @return array Brands [['name' => string, 'count' => int], ...]
     */
    public function getBrands(): array
    {
        $results = $this->db->get_results(
            "SELECT brand as name, COUNT(*) as count
             FROM {$this->table}
             WHERE brand IS NOT NULL AND brand != ''
             GROUP BY brand
             ORDER BY count DESC, brand ASC"
        );

        return array_map(fn($row) => [
            'name' => $row->name,
            'count' => (int) $row->count,
        ], $results ?: []);
    }

    // =========================================================================
    // SCRAPE MANAGEMENT
    // =========================================================================

    /**
     * Mark product as processing
     *
     * @param int $id Product ID
     * @return bool Success
     */
    public function markAsProcessing(int $id): bool
    {
        return $this->update($id, [
            'status' => 'processing',
            'error_message' => null,
        ]);
    }

    /**
     * Atomically claim one scheduled product for processing
     *
     * Uses MySQL's LAST_INSERT_ID() trick to atomically update and identify
     * the claimed row. This prevents race conditions when multiple workers
     * try to claim products simultaneously.
     *
     * Priority order:
     * 1. Normal scheduled products (status='scheduled')
     * 2. Stuck processing > 15 min (auto-recovery for killed workers)
     *
     * @return Product|null The claimed product, or null if none available
     */
    public function claimScheduledProduct(): ?Product
    {
        $now = current_time('mysql');

        // Atomically claim one scheduled product.
        // ORDER BY id ASC uses the (status, id) index path — no filesort.
        // Stuck processing cleanup is handled separately by triggerScrape().
        $result = $this->db->query(
            "UPDATE {$this->table}
             SET status = 'processing',
                 error_message = NULL,
                 updated_at = '{$now}',
                 id = LAST_INSERT_ID(id)
             WHERE status = 'scheduled'
             ORDER BY id ASC
             LIMIT 1"
        );

        if (!$result || $this->db->rows_affected === 0) {
            return null;
        }

        // Get the ID of the claimed product
        $claimedId = $this->db->get_var("SELECT LAST_INSERT_ID()");

        if (!$claimedId) {
            return null;
        }

        return $this->find((int) $claimedId);
    }

    /**
     * Atomically claim one product queued for price/stock update.
     *
     * Products with status='update' are waiting to be processed.
     * This method transitions: update → updating (atomic).
     * Also reclaims products stuck in 'updating' > 10 min.
     *
     * @return Product|null Claimed product or null if queue is empty
     */
    public function claimUpdateProduct(): ?Product
    {
        $now = current_time('mysql');
        $stuckThreshold = date('Y-m-d H:i:s', current_time('timestamp') - 600); // 10 min

        $result = $this->db->query(
            "UPDATE {$this->table}
             SET status = 'updating',
                 updated_at = '{$now}',
                 id = LAST_INSERT_ID(id)
             WHERE (
                 status = 'update'
                 OR (status = 'updating' AND updated_at < '{$stuckThreshold}')
             )
             ORDER BY
                 CASE WHEN status = 'update' THEN 0 ELSE 1 END ASC,
                 COALESCE(quick_update_at, last_scraped_at, created_at) ASC
             LIMIT 1"
        );

        if (!$result || $this->db->rows_affected === 0) {
            return null;
        }

        $claimedId = $this->db->get_var("SELECT LAST_INSERT_ID()");

        if (!$claimedId) {
            return null;
        }

        return $this->find((int) $claimedId);
    }

    /**
     * Count products queued for update (status='update').
     *
     * @return int Number of products waiting to be updated
     */
    public function countUpdateQueued(): int
    {
        return (int) $this->db->get_var(
            "SELECT COUNT(*) FROM {$this->table} WHERE status = 'update'"
        );
    }

    /**
     * Atomically claim one product queued for AI processing
     *
     * Uses the same LAST_INSERT_ID(id) trick as claimScheduledProduct() to
     * prevent race conditions when multiple AI workers run concurrently.
     *
     * Priority order (single query with CASE-based sorting):
     * 1. Normal queued products (ai_status='queued', status='scraped')
     * 2. Stuck generating > 10 min (self-healing)
     * 3. Failed > 1 hour (auto-retry)
     *
     * @return \AffiliateCMS\Pro\Models\Product|null Claimed product or null
     */
    public function claimQueuedAiProduct(): ?\AffiliateCMS\Pro\Models\Product
    {
        $now = current_time('mysql');

        // Simple claim: only 'queued' products. Uses (status_ai_status) composite index.
        // Stuck generating + failed retry handled by resetStuckGenerating() in ProductAiCron.
        $result = $this->db->query($this->db->prepare(
            "UPDATE {$this->table}
             SET ai_status = 'generating',
                 ai_error_message = NULL,
                 updated_at = %s,
                 id = LAST_INSERT_ID(id)
             WHERE status = 'scraped'
               AND ai_status = 'queued'
             ORDER BY id ASC
             LIMIT 1",
            $now
        ));

        if (!$result || $this->db->rows_affected === 0) {
            return null;
        }

        $claimedId = $this->db->get_var("SELECT LAST_INSERT_ID()");

        if (!$claimedId) {
            return null;
        }

        return $this->find((int) $claimedId);
    }

    /**
     * Count products queued for AI processing
     *
     * Includes queued, stuck generating (>10 min), and failed (>1h) products.
     *
     * @return int Number of products available for AI workers
     */
    public function countQueuedForAi(): int
    {
        $localTs = current_time('timestamp');
        $stuckThreshold = date('Y-m-d H:i:s', $localTs - 600);
        $retryThreshold = date('Y-m-d H:i:s', $localTs - 3600);

        return (int) $this->db->get_var($this->db->prepare(
            "SELECT COUNT(*) FROM {$this->table}
             WHERE status = 'scraped'
             AND (
                 ai_status = 'queued'
                 OR (ai_status = 'generating' AND updated_at < %s)
                 OR (ai_status = 'failed' AND updated_at < %s)
             )",
            $stuckThreshold,
            $retryThreshold
        ));
    }

    /**
     * Mark product as scraped with data
     *
     * @param int $id Product ID
     * @param array $data Scraped product data
     * @param string $provider Provider name
     * @return bool Success
     */
    public function markAsScraped(int $id, array $data, string $provider): bool
    {
        // Calculate score from rating
        $scoreManager = \AffiliateCMS\Pro\Services\ScoreManager::instance();
        $rating = isset($data['rating']) ? floatval($data['rating']) : null;
        $score = $scoreManager->calculateScore($rating);

        $updateData = array_merge($data, [
            'status' => 'scraped',
            'score' => $score,
            'last_provider' => $provider,
            'last_scraped_at' => current_time('mysql'),
            'error_message' => null,
            'ai_status' => 'queued', // Queue for AI content generation immediately
        ]);

        $updated = $this->update($id, $updateData);

        // Auto-create brand term and assign to associated posts
        if ($updated && !empty($data['brand'])) {
            // 1. Create brand taxonomy term (for acms_reviews posts)
            $termId = \AffiliateCMS\Pro\Core\PostTypeManager::getOrCreateBrand($data['brand']);

            // Assign brand to associated acms_reviews posts
            if ($termId) {
                $product = $this->find($id);
                if ($product && !empty($product->postIds)) {
                    $postIds = array_filter(array_map('intval', explode(',', $product->postIds)));
                    foreach ($postIds as $postId) {
                        if (get_post_type($postId) === 'acms_reviews') {
                            // Append brand (don't replace existing brands)
                            wp_set_object_terms($postId, [(int) $termId], 'acms_reviews_brand', true);
                        }
                    }
                }
            }

            // 2. Create brand in acms_brands table (for SEO brand pages)
            $brandRepo = BrandRepository::instance();
            $brandRepo->getOrCreateFromProduct($data['brand']);
        }

        // Fire hook to trigger immediate AI processing
        if ($updated) {
            $product = $this->find($id);
            if ($product) {
                do_action('acms_product_scraped', $product->asin, $data);
            }
        }

        return $updated;
    }

    /**
     * Update dynamic data only (quick update)
     *
     * Updates only frequently-changing fields: price, rating, reviews_count, in_stock, is_prime.
     * This is much faster than a full scrape and is used for scheduled updates.
     *
     * @param int $id Product ID
     * @param array $data Dynamic field data (price, rating, reviews_count, in_stock, is_prime)
     * @param string $provider Provider name
     * @return bool Success
     */
    public function updateDynamicData(int $id, array $data, string $provider): bool
    {
        // Get current quick_update_count
        $product = $this->find($id);
        if (!$product) {
            return false;
        }

        // Calculate score from rating if rating provided
        $scoreManager = \AffiliateCMS\Pro\Services\ScoreManager::instance();
        $rating = isset($data['rating']) ? floatval($data['rating']) : null;
        $score = $rating !== null ? $scoreManager->calculateScore($rating) : null;

        // Build update data - only dynamic fields
        $updateData = [];

        // Price fields
        if (isset($data['price'])) {
            $updateData['price'] = $data['price'];
        }
        if (isset($data['original_price'])) {
            $updateData['original_price'] = $data['original_price'];
        }

        // Rating and reviews
        if (isset($data['rating'])) {
            $updateData['rating'] = $rating;
            if ($score !== null) {
                $updateData['score'] = $score;
            }
        }
        if (isset($data['reviews_count'])) {
            $updateData['reviews_count'] = (int) $data['reviews_count'];
        }

        // Stock status
        if (isset($data['in_stock'])) {
            $updateData['in_stock'] = (int) $data['in_stock'];
        }
        if (isset($data['is_prime'])) {
            $updateData['is_prime'] = (int) $data['is_prime'];
        }

        // Quick update tracking
        $updateData['quick_update_at'] = current_time('mysql');
        $updateData['quick_update_count'] = (int) ($product->quickUpdateCount ?? 0) + 1;
        $updateData['last_provider'] = $provider;

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("=== ACMS Quick Update - Product ID: $id ===");
            error_log("Provider: $provider");
            error_log("Update data: " . json_encode($updateData));
        }

        return $this->update($id, $updateData);
    }

    /**
     * Mark product as failed
     *
     * @param int $id Product ID
     * @param string $error Error message
     * @return bool Success
     */
    public function markAsFailed(int $id, string $error): bool
    {
        return $this->update($id, [
            'status' => 'failed',
            'error_message' => $error,
        ]);
    }

    /**
     * Get products that need updating
     *
     * @param int $limit Limit
     * @param int $hoursThreshold Hours since last scrape
     * @return Product[]
     */
    public function getStale(int $limit = 50, int $hoursThreshold = 24): array
    {
        // Use WordPress timezone for threshold (last_scraped_at stored via current_time('mysql'))
        $threshold = gmdate('Y-m-d H:i:s', current_time('timestamp') - ($hoursThreshold * 3600));

        $rows = $this->db->get_results(
            $this->db->prepare(
                "SELECT * FROM {$this->table}
                 WHERE (last_scraped_at IS NULL OR last_scraped_at < %s)
                 AND status NOT IN ('processing', 'failed')
                 ORDER BY last_scraped_at ASC
                 LIMIT %d",
                $threshold,
                $limit
            )
        );

        return array_map(fn($row) => Product::fromRow($row), $rows ?: []);
    }

    /**
     * Create or update product from search results
     *
     * This is used when saving search results from queue processing.
     * If product exists, it returns the existing ID without updating.
     * If product doesn't exist, it creates a new one with basic search data.
     *
     * @param string $asin Product ASIN
     * @param array $searchData Search result data (title, brand, price, rating, etc.)
     * @param string|null $provider Provider name that performed the search
     * @return int Product ID (existing or newly created)
     */
    public function createOrUpdateFromSearch(string $asin, array $searchData, ?string $provider = null): int
    {
        // Check if product already exists
        $existing = $this->findByAsin($asin);

        if ($existing) {
            // Product exists - return its ID without updating
            // (preserves any manual edits or previously scraped full data)
            return $existing->id;
        }

        // Product doesn't exist - create new with basic search data
        $rating = isset($searchData['rating']) ? floatval($searchData['rating']) : null;

        // Calculate score from rating (even for search results)
        $scoreManager = \AffiliateCMS\Pro\Services\ScoreManager::instance();
        $score = $scoreManager->calculateScore($rating);

        // DEBUG: Log Queue product creation
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("=== ACMS Queue Product Creation - ASIN: $asin ===");
            error_log("Search rating: " . var_export($rating, true));
            error_log("Calculated score: $score");
        }

        $productData = [
            'asin' => $asin,
            'title' => $searchData['title'] ?? '',
            'brand' => $searchData['brand'] ?? '',
            'price' => isset($searchData['price']) ? floatval($searchData['price']) : null,
            'rating' => $rating,
            'reviews_count' => isset($searchData['reviews']) ? intval($searchData['reviews']) : 0,
            'image_url' => $searchData['image'] ?? '',
            'is_prime' => !empty($searchData['isPrime']) ? 1 : 0,
            'score' => $score, // Calculate score from search rating
            'status' => 'pending', // Awaiting full scrape
            'last_provider' => $provider,
        ];

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("Product data score: " . $productData['score']);
            error_log("Product status: " . $productData['status']);
        }

        $id = $this->create($productData);

        if (!$id) {
            throw new \Exception("Failed to create product with ASIN: {$asin}");
        }

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("Product created with ID: $id");
            error_log("=== End Queue Product Creation ===");
        }

        // Auto-create brand term if brand name is present
        if (!empty($searchData['brand'])) {
            \AffiliateCMS\Pro\Core\PostTypeManager::getOrCreateBrand($searchData['brand']);
        }

        return $id;
    }
}
