<?php
/**
 * ProductLink Repository
 *
 * Handles all database operations for product affiliate links
 * Uses {prefix}acms_product_links table
 */

declare(strict_types=1);

namespace AffiliateCMS\Pro\Repositories;

use AffiliateCMS\Pro\Models\ProductLink;
use AffiliateCMS\Pro\Database\Schema;

class ProductLinkRepository
{
    private static ?ProductLinkRepository $instance = null;

    private \wpdb $db;
    private string $table;

    /**
     * Get singleton instance
     */
    public static function instance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct()
    {
        global $wpdb;
        $this->db = $wpdb;
        $this->table = Schema::productLinksTable();
    }

    /**
     * Get table name
     */
    public function getTable(): string
    {
        return $this->table;
    }

    // =========================================================================
    // CRUD OPERATIONS
    // =========================================================================

    /**
     * Find link by ID
     *
     * @param int $id Link ID
     * @return ProductLink|null
     */
    public function find(int $id): ?ProductLink
    {
        $row = $this->db->get_row(
            $this->db->prepare(
                "SELECT * FROM {$this->table} WHERE id = %d",
                $id
            )
        );

        return $row ? ProductLink::fromRow($row) : null;
    }

    /**
     * Get all links for a product
     *
     * @param int $productId Product ID
     * @return ProductLink[]
     */
    public function getByProductId(int $productId): array
    {
        $rows = $this->db->get_results(
            $this->db->prepare(
                "SELECT * FROM {$this->table}
                 WHERE product_id = %d
                 ORDER BY is_primary DESC, sort_order ASC, id ASC",
                $productId
            )
        );

        return array_map(fn($row) => ProductLink::fromRow($row), $rows ?: []);
    }

    /**
     * Get links for multiple products
     *
     * @param array $productIds Product IDs
     * @return array [productId => ProductLink[]]
     */
    public function getByProductIds(array $productIds): array
    {
        if (empty($productIds)) {
            return [];
        }

        $productIds = array_map('intval', $productIds);
        $placeholders = implode(',', array_fill(0, count($productIds), '%d'));

        $rows = $this->db->get_results(
            $this->db->prepare(
                "SELECT * FROM {$this->table}
                 WHERE product_id IN ({$placeholders})
                 ORDER BY is_primary DESC, sort_order ASC, id ASC",
                $productIds
            )
        );

        $result = array_fill_keys($productIds, []);
        foreach ($rows ?: [] as $row) {
            $link = ProductLink::fromRow($row);
            $result[$link->productId][] = $link;
        }

        return $result;
    }

    /**
     * Get primary link for a product
     *
     * @param int $productId Product ID
     * @return ProductLink|null
     */
    public function getPrimary(int $productId): ?ProductLink
    {
        $row = $this->db->get_row(
            $this->db->prepare(
                "SELECT * FROM {$this->table}
                 WHERE product_id = %d AND is_primary = 1
                 LIMIT 1",
                $productId
            )
        );

        return $row ? ProductLink::fromRow($row) : null;
    }

    /**
     * Create new product link
     *
     * @param array $data Link data
     * @return int|false Insert ID or false on failure
     */
    public function create(array $data): int|false
    {
        $now = current_time('mysql');

        $insertData = [
            'product_id' => (int) ($data['product_id'] ?? 0),
            'provider' => $data['provider'] ?? '',
            'provider_name' => $data['provider_name'] ?? '',
            'affiliate_url' => $data['affiliate_url'] ?? '',
            'price' => $data['price'] ?? null,
            'currency' => $data['currency'] ?? 'USD',
            'in_stock' => isset($data['in_stock']) ? (int) $data['in_stock'] : null,
            'is_primary' => isset($data['is_primary']) ? (int) $data['is_primary'] : 0,
            'sort_order' => (int) ($data['sort_order'] ?? 0),
            'created_at' => $now,
            'updated_at' => $now,
        ];

        // If this is set as primary, unset other primaries first
        if ($insertData['is_primary']) {
            $this->clearPrimary($insertData['product_id']);
        }

        $result = $this->db->insert($this->table, $insertData);

        return $result ? (int) $this->db->insert_id : false;
    }

    /**
     * Update product link
     *
     * @param int $id Link ID
     * @param array $data Data to update
     * @return bool Success
     */
    public function update(int $id, array $data): bool
    {
        $link = $this->find($id);
        if (!$link) {
            return false;
        }

        // If setting as primary, unset other primaries first
        if (isset($data['is_primary']) && $data['is_primary']) {
            $this->clearPrimary($link->productId, $id);
        }

        $updateData = [];

        if (isset($data['provider'])) {
            $updateData['provider'] = $data['provider'];
        }
        if (isset($data['provider_name'])) {
            $updateData['provider_name'] = $data['provider_name'];
        }
        if (isset($data['affiliate_url'])) {
            $updateData['affiliate_url'] = $data['affiliate_url'];
        }
        if (array_key_exists('price', $data)) {
            $updateData['price'] = $data['price'];
        }
        if (isset($data['currency'])) {
            $updateData['currency'] = $data['currency'];
        }
        if (array_key_exists('in_stock', $data)) {
            $updateData['in_stock'] = $data['in_stock'] !== null ? (int) $data['in_stock'] : null;
        }
        if (isset($data['is_primary'])) {
            $updateData['is_primary'] = (int) $data['is_primary'];
        }
        if (isset($data['sort_order'])) {
            $updateData['sort_order'] = (int) $data['sort_order'];
        }

        $updateData['updated_at'] = current_time('mysql');

        $result = $this->db->update($this->table, $updateData, ['id' => $id]);

        return $result !== false;
    }

    /**
     * Delete product link
     *
     * @param int $id Link ID
     * @return bool Success
     */
    public function delete(int $id): bool
    {
        $result = $this->db->delete($this->table, ['id' => $id]);
        return $result !== false;
    }

    /**
     * Delete all links for a product
     *
     * @param int $productId Product ID
     * @return int Number of deleted rows
     */
    public function deleteByProductId(int $productId): int
    {
        $result = $this->db->delete($this->table, ['product_id' => $productId]);
        return $result !== false ? $result : 0;
    }

    // =========================================================================
    // HELPER METHODS
    // =========================================================================

    /**
     * Clear primary flag for all links of a product
     *
     * @param int $productId Product ID
     * @param int|null $exceptId Link ID to exclude
     */
    private function clearPrimary(int $productId, ?int $exceptId = null): void
    {
        $sql = "UPDATE {$this->table} SET is_primary = 0 WHERE product_id = %d";
        $params = [$productId];

        if ($exceptId !== null) {
            $sql .= " AND id != %d";
            $params[] = $exceptId;
        }

        $this->db->query($this->db->prepare($sql, $params));
    }

    /**
     * Set a link as primary
     *
     * @param int $id Link ID
     * @return bool Success
     */
    public function setPrimary(int $id): bool
    {
        $link = $this->find($id);
        if (!$link) {
            return false;
        }

        // Clear other primaries
        $this->clearPrimary($link->productId, $id);

        // Set this one as primary
        return $this->update($id, ['is_primary' => 1]);
    }

    /**
     * Update sort order for multiple links
     *
     * @param array $order [linkId => sortOrder, ...]
     * @return bool Success
     */
    public function updateSortOrder(array $order): bool
    {
        foreach ($order as $id => $sortOrder) {
            $this->db->update(
                $this->table,
                ['sort_order' => (int) $sortOrder, 'updated_at' => current_time('mysql')],
                ['id' => (int) $id]
            );
        }

        return true;
    }

    /**
     * Count links for a product
     *
     * @param int $productId Product ID
     * @return int Count
     */
    public function countByProductId(int $productId): int
    {
        return (int) $this->db->get_var(
            $this->db->prepare(
                "SELECT COUNT(*) FROM {$this->table} WHERE product_id = %d",
                $productId
            )
        );
    }

    /**
     * Check if a provider link exists for a product
     *
     * @param int $productId Product ID
     * @param string $provider Provider slug
     * @return bool
     */
    public function hasProvider(int $productId, string $provider): bool
    {
        $result = $this->db->get_var(
            $this->db->prepare(
                "SELECT 1 FROM {$this->table} WHERE product_id = %d AND provider = %s LIMIT 1",
                $productId,
                $provider
            )
        );

        return $result !== null;
    }

    /**
     * Get link by product and provider
     *
     * @param int $productId Product ID
     * @param string $provider Provider slug
     * @return ProductLink|null
     */
    public function getByProvider(int $productId, string $provider): ?ProductLink
    {
        $row = $this->db->get_row(
            $this->db->prepare(
                "SELECT * FROM {$this->table} WHERE product_id = %d AND provider = %s LIMIT 1",
                $productId,
                $provider
            )
        );

        return $row ? ProductLink::fromRow($row) : null;
    }

    /**
     * Bulk save links for a product (replace all)
     *
     * @param int $productId Product ID
     * @param array $links Array of link data
     * @return bool Success
     */
    public function saveAll(int $productId, array $links): bool
    {
        // Delete existing links
        $this->deleteByProductId($productId);

        // Insert new links
        foreach ($links as $index => $linkData) {
            $linkData['product_id'] = $productId;
            $linkData['sort_order'] = $linkData['sort_order'] ?? $index;
            $this->create($linkData);
        }

        return true;
    }
}
